namespace be.BEL_4_Base {
/* IO:File: source/build/Constants.be */
public sealed class BEC_2_5_9_BuildConstants : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildConstants() { }
static BEC_2_5_9_BuildConstants() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x62,0x72,0x61,0x63,0x65,0x73};
private static byte[] bels_1 = {0x63,0x61,0x6C,0x6C};
private static byte[] bels_2 = {0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_3 = {0x70,0x61,0x72,0x65,0x6E,0x73};
private static byte[] bels_4 = {0x4E,0x4F,0x54};
private static byte[] bels_5 = {0x4F,0x4E,0x43,0x45};
private static byte[] bels_6 = {0x4D,0x41,0x4E,0x59};
private static byte[] bels_7 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bels_8 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bels_9 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59};
private static byte[] bels_10 = {0x44,0x49,0x56,0x49,0x44,0x45};
private static byte[] bels_11 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53};
private static byte[] bels_12 = {0x41,0x44,0x44};
private static byte[] bels_13 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54};
private static byte[] bels_14 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52};
private static byte[] bels_15 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_16 = {0x4C,0x45,0x53,0x53,0x45,0x52};
private static byte[] bels_17 = {0x4C,0x45,0x53,0x53,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_18 = {0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_19 = {0x4E,0x4F,0x54,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_20 = {0x41,0x4E,0x44};
private static byte[] bels_21 = {0x4F,0x52};
private static byte[] bels_22 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x41,0x4E,0x44};
private static byte[] bels_23 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x4F,0x52};
private static byte[] bels_24 = {0x49,0x4E};
private static byte[] bels_25 = {0x41,0x44,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_26 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_27 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_28 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_29 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_30 = {0x44,0x49,0x56,0x49,0x44,0x45,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_31 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_32 = {0x41,0x4E,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_33 = {0x4F,0x52,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_34 = {0x41,0x53,0x53,0x49,0x47,0x4E};
private static byte[] bels_35 = {0x20};
private static BEC_2_6_6_SystemObject bevo_0 = (new BEC_2_4_6_TextString(bels_35, 1));
private static byte[] bels_36 = {0x2F};
private static byte[] bels_37 = {0x7B};
private static byte[] bels_38 = {0x7D};
private static byte[] bels_39 = {0x28};
private static byte[] bels_40 = {0x29};
private static byte[] bels_41 = {0x3B};
private static byte[] bels_42 = {0x3A};
private static byte[] bels_43 = {0x2C};
private static byte[] bels_44 = {0x2B};
private static byte[] bels_45 = {};
private static byte[] bels_46 = {0x2D};
private static byte[] bels_47 = {0x40};
private static byte[] bels_48 = {0x23};
private static byte[] bels_49 = {0x75,0x73,0x65};
private static byte[] bels_50 = {0x61,0x73};
private static byte[] bels_51 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bels_52 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_53 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_54 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_55 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bels_56 = {0x76,0x61,0x72};
private static byte[] bels_57 = {0x69,0x66};
private static byte[] bels_58 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_59 = {0x65,0x6C,0x69,0x66};
private static byte[] bels_60 = {0x65,0x6C,0x73,0x65};
private static byte[] bels_61 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bels_62 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bels_63 = {0x77,0x68,0x69,0x6C,0x65};
private static byte[] bels_64 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bels_65 = {0x66,0x6F,0x72};
private static byte[] bels_66 = {0x66,0x6F,0x72,0x65,0x61,0x63,0x68};
private static byte[] bels_67 = {0x69,0x6E};
private static byte[] bels_68 = {0x65,0x6D,0x69,0x74};
private static byte[] bels_69 = {0x69,0x66,0x45,0x6D,0x69,0x74};
private static byte[] bels_70 = {0x69,0x66,0x4E,0x6F,0x74,0x45,0x6D,0x69,0x74};
private static byte[] bels_71 = {0x62,0x72,0x65,0x61,0x6B};
private static byte[] bels_72 = {0x63,0x6F,0x6E,0x74,0x69,0x6E,0x75,0x65};
private static byte[] bels_73 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_74 = {0x74,0x72,0x75,0x65};
private static byte[] bels_75 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_76 = {0x74,0x72,0x79};
private static byte[] bels_77 = {0x63,0x61,0x74,0x63,0x68};
public static new BEC_2_5_9_BuildConstants bevs_inst;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public BEC_2_4_3_MathInt bevp_maxargs;
public BEC_2_4_3_MathInt bevp_extraSlots;
public BEC_2_4_3_MathInt bevp_mtdxPad;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_9_3_ContainerMap bevp_unwindTo;
public BEC_2_9_3_ContainerMap bevp_unwindOk;
public BEC_2_9_3_ContainerMap bevp_oper;
public BEC_2_9_3_ContainerMap bevp_operNames;
public BEC_2_9_3_ContainerMap bevp_conTypes;
public BEC_2_9_3_ContainerMap bevp_parensReq;
public BEC_2_9_3_ContainerMap bevp_anchorTypes;
public BEC_2_5_9_BuildConstants bem_new_1(BEC_2_6_6_SystemObject beva_build) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_107_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_109_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_114_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_124_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_129_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_131_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_133_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_135_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_136_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_139_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_142_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_143_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_144_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_146_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_147_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_148_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_149_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_150_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_151_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_153_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_154_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_155_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_159_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_160_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_161_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_162_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_163_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_164_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_166_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_167_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_168_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_169_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_171_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_172_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_173_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_174_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_175_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_176_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_177_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_178_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_179_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_180_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_181_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_182_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_183_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_184_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_185_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_186_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_187_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_188_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_189_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_190_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_191_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_192_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_193_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_194_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_195_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_197_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_198_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_199_tmpvar_phold = null;
bevp_maxargs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevp_extraSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_mtdxPad = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(26));
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) BEC_2_5_9_BuildNodeTypes.bevs_inst;
bevp_unwindTo = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_unwindOk = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_oper = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_operNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_conTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parensReq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_0));
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_unwindTo.bem_put_2(bevt_0_tmpvar_phold, bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_1));
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_2));
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_3));
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_6_tmpvar_phold, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevp_ntypes.bem_NOTGet_0();
bevt_9_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_11_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_10_tmpvar_phold, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_ntypes.bem_MANYGet_0();
bevt_13_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_15_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_14_tmpvar_phold, bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_17_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_16_tmpvar_phold, bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_19_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_18_tmpvar_phold, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_21_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_20_tmpvar_phold, bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_23_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_22_tmpvar_phold, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_25_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_27_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_26_tmpvar_phold, bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_29_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_28_tmpvar_phold, bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_31_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_33_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_32_tmpvar_phold, bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_35_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_37_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_36_tmpvar_phold, bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_39_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_38_tmpvar_phold, bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_41_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_40_tmpvar_phold, bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_43_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_42_tmpvar_phold, bevt_43_tmpvar_phold);
bevt_44_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevt_45_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_44_tmpvar_phold, bevt_45_tmpvar_phold);
bevt_46_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevt_47_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_46_tmpvar_phold, bevt_47_tmpvar_phold);
bevt_48_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_49_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_48_tmpvar_phold, bevt_49_tmpvar_phold);
bevt_50_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_51_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_50_tmpvar_phold, bevt_51_tmpvar_phold);
bevt_52_tmpvar_phold = bevp_ntypes.bem_INGet_0();
bevt_53_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
bevp_oper.bem_put_2(bevt_52_tmpvar_phold, bevt_53_tmpvar_phold);
bevt_54_tmpvar_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_55_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_54_tmpvar_phold, bevt_55_tmpvar_phold);
bevt_56_tmpvar_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_57_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_56_tmpvar_phold, bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_59_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_58_tmpvar_phold, bevt_59_tmpvar_phold);
bevt_60_tmpvar_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_61_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_60_tmpvar_phold, bevt_61_tmpvar_phold);
bevt_62_tmpvar_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_63_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_62_tmpvar_phold, bevt_63_tmpvar_phold);
bevt_64_tmpvar_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_65_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_64_tmpvar_phold, bevt_65_tmpvar_phold);
bevt_66_tmpvar_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_67_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_66_tmpvar_phold, bevt_67_tmpvar_phold);
bevt_68_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_69_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_oper.bem_put_2(bevt_68_tmpvar_phold, bevt_69_tmpvar_phold);
bevt_70_tmpvar_phold = bevp_ntypes.bem_NOTGet_0();
bevt_71_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_4));
bevp_operNames.bem_put_2(bevt_70_tmpvar_phold, bevt_71_tmpvar_phold);
bevt_72_tmpvar_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_73_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_5));
bevp_operNames.bem_put_2(bevt_72_tmpvar_phold, bevt_73_tmpvar_phold);
bevt_74_tmpvar_phold = bevp_ntypes.bem_MANYGet_0();
bevt_75_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_6));
bevp_operNames.bem_put_2(bevt_74_tmpvar_phold, bevt_75_tmpvar_phold);
bevt_76_tmpvar_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_77_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_7));
bevp_operNames.bem_put_2(bevt_76_tmpvar_phold, bevt_77_tmpvar_phold);
bevt_78_tmpvar_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_79_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_8));
bevp_operNames.bem_put_2(bevt_78_tmpvar_phold, bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_81_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_9));
bevp_operNames.bem_put_2(bevt_80_tmpvar_phold, bevt_81_tmpvar_phold);
bevt_82_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_83_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_10));
bevp_operNames.bem_put_2(bevt_82_tmpvar_phold, bevt_83_tmpvar_phold);
bevt_84_tmpvar_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_85_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_11));
bevp_operNames.bem_put_2(bevt_84_tmpvar_phold, bevt_85_tmpvar_phold);
bevt_86_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_87_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_12));
bevp_operNames.bem_put_2(bevt_86_tmpvar_phold, bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_89_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_13));
bevp_operNames.bem_put_2(bevt_88_tmpvar_phold, bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_91_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_14));
bevp_operNames.bem_put_2(bevt_90_tmpvar_phold, bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_93_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_15));
bevp_operNames.bem_put_2(bevt_92_tmpvar_phold, bevt_93_tmpvar_phold);
bevt_94_tmpvar_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_95_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_16));
bevp_operNames.bem_put_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevt_96_tmpvar_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_97_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_17));
bevp_operNames.bem_put_2(bevt_96_tmpvar_phold, bevt_97_tmpvar_phold);
bevt_98_tmpvar_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_99_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_18));
bevp_operNames.bem_put_2(bevt_98_tmpvar_phold, bevt_99_tmpvar_phold);
bevt_100_tmpvar_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_101_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_19));
bevp_operNames.bem_put_2(bevt_100_tmpvar_phold, bevt_101_tmpvar_phold);
bevt_102_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevt_103_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_20));
bevp_operNames.bem_put_2(bevt_102_tmpvar_phold, bevt_103_tmpvar_phold);
bevt_104_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevt_105_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_21));
bevp_operNames.bem_put_2(bevt_104_tmpvar_phold, bevt_105_tmpvar_phold);
bevt_106_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_107_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_22));
bevp_operNames.bem_put_2(bevt_106_tmpvar_phold, bevt_107_tmpvar_phold);
bevt_108_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_109_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_23));
bevp_operNames.bem_put_2(bevt_108_tmpvar_phold, bevt_109_tmpvar_phold);
bevt_110_tmpvar_phold = bevp_ntypes.bem_INGet_0();
bevt_111_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_24));
bevp_operNames.bem_put_2(bevt_110_tmpvar_phold, bevt_111_tmpvar_phold);
bevt_112_tmpvar_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_113_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_25));
bevp_operNames.bem_put_2(bevt_112_tmpvar_phold, bevt_113_tmpvar_phold);
bevt_114_tmpvar_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_115_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_26));
bevp_operNames.bem_put_2(bevt_114_tmpvar_phold, bevt_115_tmpvar_phold);
bevt_116_tmpvar_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_117_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_27));
bevp_operNames.bem_put_2(bevt_116_tmpvar_phold, bevt_117_tmpvar_phold);
bevt_118_tmpvar_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_119_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_28));
bevp_operNames.bem_put_2(bevt_118_tmpvar_phold, bevt_119_tmpvar_phold);
bevt_120_tmpvar_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_121_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_29));
bevp_operNames.bem_put_2(bevt_120_tmpvar_phold, bevt_121_tmpvar_phold);
bevt_122_tmpvar_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_123_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_30));
bevp_operNames.bem_put_2(bevt_122_tmpvar_phold, bevt_123_tmpvar_phold);
bevt_124_tmpvar_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_125_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_31));
bevp_operNames.bem_put_2(bevt_124_tmpvar_phold, bevt_125_tmpvar_phold);
bevt_126_tmpvar_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_127_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_32));
bevp_operNames.bem_put_2(bevt_126_tmpvar_phold, bevt_127_tmpvar_phold);
bevt_128_tmpvar_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_129_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_33));
bevp_operNames.bem_put_2(bevt_128_tmpvar_phold, bevt_129_tmpvar_phold);
bevt_130_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_131_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_34));
bevp_operNames.bem_put_2(bevt_130_tmpvar_phold, bevt_131_tmpvar_phold);
bevt_132_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevt_133_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_132_tmpvar_phold, bevt_133_tmpvar_phold);
bevt_134_tmpvar_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_135_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_134_tmpvar_phold, bevt_135_tmpvar_phold);
bevt_136_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_137_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_136_tmpvar_phold, bevt_137_tmpvar_phold);
bevt_138_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
bevt_139_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_138_tmpvar_phold, bevt_139_tmpvar_phold);
bevt_140_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_141_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_140_tmpvar_phold, bevt_141_tmpvar_phold);
bevt_142_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
bevt_143_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_142_tmpvar_phold, bevt_143_tmpvar_phold);
bevt_144_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_145_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_144_tmpvar_phold, bevt_145_tmpvar_phold);
bevt_146_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_147_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_146_tmpvar_phold, bevt_147_tmpvar_phold);
bevt_148_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_149_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_148_tmpvar_phold, bevt_149_tmpvar_phold);
bevt_150_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_151_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_150_tmpvar_phold, bevt_151_tmpvar_phold);
bevt_152_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_153_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_152_tmpvar_phold, bevt_153_tmpvar_phold);
bevt_154_tmpvar_phold = bevp_ntypes.bem_TRYGet_0();
bevt_155_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_154_tmpvar_phold, bevt_155_tmpvar_phold);
bevt_156_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevt_157_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_156_tmpvar_phold, bevt_157_tmpvar_phold);
bevt_158_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_159_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_158_tmpvar_phold, bevt_159_tmpvar_phold);
bevt_160_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_161_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_160_tmpvar_phold, bevt_161_tmpvar_phold);
bevt_162_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_163_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_162_tmpvar_phold, bevt_163_tmpvar_phold);
bevt_164_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_165_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_164_tmpvar_phold, bevt_165_tmpvar_phold);
bevt_166_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_167_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_166_tmpvar_phold, bevt_167_tmpvar_phold);
bevt_168_tmpvar_phold = bevp_ntypes.bem_IDXGet_0();
bevt_169_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_168_tmpvar_phold, bevt_169_tmpvar_phold);
bevt_170_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevt_171_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_170_tmpvar_phold, bevt_171_tmpvar_phold);
bevt_172_tmpvar_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_173_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_172_tmpvar_phold, bevt_173_tmpvar_phold);
bevt_174_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_175_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_174_tmpvar_phold, bevt_175_tmpvar_phold);
bevt_176_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
bevt_177_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_176_tmpvar_phold, bevt_177_tmpvar_phold);
bevt_178_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_179_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_178_tmpvar_phold, bevt_179_tmpvar_phold);
bevt_180_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
bevt_181_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_180_tmpvar_phold, bevt_181_tmpvar_phold);
bevt_182_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_183_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_182_tmpvar_phold, bevt_183_tmpvar_phold);
bevt_184_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_185_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_184_tmpvar_phold, bevt_185_tmpvar_phold);
bevt_186_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_187_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_186_tmpvar_phold, bevt_187_tmpvar_phold);
bevt_188_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevt_189_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_188_tmpvar_phold, bevt_189_tmpvar_phold);
bevt_190_tmpvar_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_191_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_190_tmpvar_phold, bevt_191_tmpvar_phold);
bevt_192_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_193_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_192_tmpvar_phold, bevt_193_tmpvar_phold);
bevt_194_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
bevt_195_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_194_tmpvar_phold, bevt_195_tmpvar_phold);
bevt_196_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_197_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_196_tmpvar_phold, bevt_197_tmpvar_phold);
bevt_198_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_199_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_198_tmpvar_phold, bevt_199_tmpvar_phold);
this.bem_prepare_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepare_0() {
BEC_2_6_6_SystemObject bevl_space = null;
BEC_2_6_6_SystemObject bevl_ntok = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpvar_phold = null;
bevp_matchMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_space = bevo_0;
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_36));
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_twtok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2((BEC_2_4_6_TextString) bevl_ntok, bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_1_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_37));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_2_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_2_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_38));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_3_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_3_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_39));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_4_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_4_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_40));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_5_tmpvar_phold = bevp_ntypes.bem_RPARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_5_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_41));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_6_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_6_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_42));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_7_tmpvar_phold = bevp_ntypes.bem_COLONGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_7_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_43));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_8_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_8_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_44));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_9_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_9_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(0, bels_45));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_10_tmpvar_phold = bevp_ntypes.bem_ATYPEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_10_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_46));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_11_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_11_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_47));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_12_tmpvar_phold = bevp_ntypes.bem_ONCEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_12_tmpvar_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_48));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_13_tmpvar_phold = bevp_ntypes.bem_MANYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(92));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_14_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_15_tmpvar_phold = bevp_ntypes.bem_FSLASHGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_16_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_17_tmpvar_phold = bevp_ntypes.bem_STRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(39));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_18_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_19_tmpvar_phold = bevp_ntypes.bem_WSTRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_20_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_21_tmpvar_phold = bevp_ntypes.bem_IDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(93));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_22_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_23_tmpvar_phold = bevp_ntypes.bem_RIDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(37));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_24_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_25_tmpvar_phold = bevp_ntypes.bem_MODULUSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(61));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_26_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_27_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(62));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_28_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_29_tmpvar_phold = bevp_ntypes.bem_GREATERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(60));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_30_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_31_tmpvar_phold = bevp_ntypes.bem_LESSERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(33));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_32_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_33_tmpvar_phold = bevp_ntypes.bem_NOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(38));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_34_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_35_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(124));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_36_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_37_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(42));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_38_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_39_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(46));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_40_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_41_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_42_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_43_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_43_tmpvar_phold);
bevt_44_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_44_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_45_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_45_tmpvar_phold);
bevt_46_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_ntok = bevt_46_tmpvar_phold.bem_newlineGet_0();
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_47_tmpvar_phold = bevp_ntypes.bem_NEWLINEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_47_tmpvar_phold);
bevp_rwords = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_48_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_49));
bevt_49_tmpvar_phold = bevp_ntypes.bem_USEGet_0();
bevp_rwords.bem_put_2(bevt_48_tmpvar_phold, bevt_49_tmpvar_phold);
bevt_50_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_50));
bevt_51_tmpvar_phold = bevp_ntypes.bem_ASGet_0();
bevp_rwords.bem_put_2(bevt_50_tmpvar_phold, bevt_51_tmpvar_phold);
bevt_52_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_51));
bevt_53_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevp_rwords.bem_put_2(bevt_52_tmpvar_phold, bevt_53_tmpvar_phold);
bevt_54_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_52));
bevt_55_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevp_rwords.bem_put_2(bevt_54_tmpvar_phold, bevt_55_tmpvar_phold);
bevt_56_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_53));
bevt_57_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_56_tmpvar_phold, bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_54));
bevt_59_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_58_tmpvar_phold, bevt_59_tmpvar_phold);
bevt_60_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_55));
bevt_61_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_60_tmpvar_phold, bevt_61_tmpvar_phold);
bevt_62_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_56));
bevt_63_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_62_tmpvar_phold, bevt_63_tmpvar_phold);
bevt_64_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_57));
bevt_65_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_64_tmpvar_phold, bevt_65_tmpvar_phold);
bevt_66_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_58));
bevt_67_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_66_tmpvar_phold, bevt_67_tmpvar_phold);
bevt_68_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_59));
bevt_69_tmpvar_phold = bevp_ntypes.bem_ELIFGet_0();
bevp_rwords.bem_put_2(bevt_68_tmpvar_phold, bevt_69_tmpvar_phold);
bevt_70_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_60));
bevt_71_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevp_rwords.bem_put_2(bevt_70_tmpvar_phold, bevt_71_tmpvar_phold);
bevt_72_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_61));
bevt_73_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevp_rwords.bem_put_2(bevt_72_tmpvar_phold, bevt_73_tmpvar_phold);
bevt_74_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_62));
bevt_75_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevp_rwords.bem_put_2(bevt_74_tmpvar_phold, bevt_75_tmpvar_phold);
bevt_76_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_63));
bevt_77_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_76_tmpvar_phold, bevt_77_tmpvar_phold);
bevt_78_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_64));
bevt_79_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_78_tmpvar_phold, bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_65));
bevt_81_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
bevp_rwords.bem_put_2(bevt_80_tmpvar_phold, bevt_81_tmpvar_phold);
bevt_82_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_66));
bevt_83_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
bevp_rwords.bem_put_2(bevt_82_tmpvar_phold, bevt_83_tmpvar_phold);
bevt_84_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_67));
bevt_85_tmpvar_phold = bevp_ntypes.bem_INGet_0();
bevp_rwords.bem_put_2(bevt_84_tmpvar_phold, bevt_85_tmpvar_phold);
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_68));
bevt_87_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
bevp_rwords.bem_put_2(bevt_86_tmpvar_phold, bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_69));
bevt_89_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_88_tmpvar_phold, bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_70));
bevt_91_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_90_tmpvar_phold, bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_71));
bevt_93_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevp_rwords.bem_put_2(bevt_92_tmpvar_phold, bevt_93_tmpvar_phold);
bevt_94_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_72));
bevt_95_tmpvar_phold = bevp_ntypes.bem_CONTINUEGet_0();
bevp_rwords.bem_put_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevt_96_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_73));
bevt_97_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevp_rwords.bem_put_2(bevt_96_tmpvar_phold, bevt_97_tmpvar_phold);
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_74));
bevt_99_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevp_rwords.bem_put_2(bevt_98_tmpvar_phold, bevt_99_tmpvar_phold);
bevt_100_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_75));
bevt_101_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevp_rwords.bem_put_2(bevt_100_tmpvar_phold, bevt_101_tmpvar_phold);
bevt_102_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_76));
bevt_103_tmpvar_phold = bevp_ntypes.bem_TRYGet_0();
bevp_rwords.bem_put_2(bevt_102_tmpvar_phold, bevt_103_tmpvar_phold);
bevt_104_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_77));
bevt_105_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevp_rwords.bem_put_2(bevt_104_tmpvar_phold, bevt_105_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_6_6_SystemObject bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() {
return bevp_matchMap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() {
return bevp_rwords;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxargsGet_0() {
return bevp_maxargs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_maxargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_maxargs = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_extraSlotsGet_0() {
return bevp_extraSlots;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extraSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extraSlots = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxPadGet_0() {
return bevp_mtdxPad;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mtdxPadSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mtdxPad = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindToGet_0() {
return bevp_unwindTo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_unwindToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_unwindTo = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindOkGet_0() {
return bevp_unwindOk;
} /*method end*/
public BEC_2_6_6_SystemObject bem_unwindOkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_unwindOk = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operGet_0() {
return bevp_oper;
} /*method end*/
public BEC_2_6_6_SystemObject bem_operSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_oper = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operNamesGet_0() {
return bevp_operNames;
} /*method end*/
public BEC_2_6_6_SystemObject bem_operNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_operNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_conTypesGet_0() {
return bevp_conTypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_conTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_conTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_parensReqGet_0() {
return bevp_parensReq;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parensReqSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parensReq = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anchorTypesGet_0() {
return bevp_anchorTypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {21, 22, 25, 26, 27, 28, 29, 30, 31, 32, 33, 37, 37, 37, 39, 39, 39, 40, 40, 40, 41, 41, 41, 43, 43, 43, 44, 44, 44, 45, 45, 45, 46, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 49, 50, 50, 50, 51, 51, 51, 52, 52, 52, 53, 53, 53, 54, 54, 54, 55, 55, 55, 56, 56, 56, 57, 57, 57, 58, 58, 58, 59, 59, 59, 60, 60, 60, 61, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64, 64, 65, 65, 65, 66, 66, 66, 67, 67, 67, 68, 68, 68, 69, 69, 69, 70, 70, 70, 71, 71, 71, 72, 72, 72, 73, 73, 73, 75, 75, 75, 76, 76, 76, 77, 77, 77, 78, 78, 78, 79, 79, 79, 80, 80, 80, 81, 81, 81, 82, 82, 82, 83, 83, 83, 84, 84, 84, 85, 85, 85, 86, 86, 86, 87, 87, 87, 88, 88, 88, 89, 89, 89, 90, 90, 90, 91, 91, 91, 92, 92, 92, 93, 93, 93, 94, 94, 94, 95, 95, 95, 96, 96, 96, 97, 97, 97, 98, 98, 98, 99, 99, 99, 100, 100, 100, 101, 101, 101, 102, 102, 102, 103, 103, 103, 104, 104, 104, 105, 105, 105, 107, 107, 107, 108, 108, 108, 109, 109, 109, 110, 110, 110, 111, 111, 111, 112, 112, 112, 113, 113, 113, 114, 114, 114, 115, 115, 115, 116, 116, 116, 117, 117, 117, 118, 118, 118, 119, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 125, 125, 125, 127, 127, 127, 128, 128, 128, 129, 129, 129, 130, 130, 130, 131, 131, 131, 132, 132, 132, 133, 133, 133, 134, 134, 134, 135, 135, 135, 137, 137, 137, 138, 138, 138, 139, 139, 139, 140, 140, 140, 141, 141, 141, 142, 142, 142, 144, 150, 151, 153, 154, 154, 155, 155, 157, 158, 159, 159, 161, 162, 163, 163, 165, 166, 167, 167, 169, 170, 171, 171, 173, 174, 175, 175, 177, 178, 179, 179, 181, 182, 183, 183, 185, 186, 187, 187, 189, 190, 191, 191, 193, 194, 195, 195, 197, 198, 199, 199, 201, 202, 203, 203, 207, 207, 209, 210, 210, 212, 212, 214, 215, 215, 217, 217, 219, 220, 220, 222, 222, 224, 225, 225, 227, 227, 229, 230, 230, 232, 232, 234, 235, 235, 237, 237, 239, 240, 240, 242, 242, 244, 245, 245, 247, 247, 249, 250, 250, 252, 252, 254, 255, 255, 257, 257, 259, 260, 260, 262, 262, 264, 265, 265, 267, 267, 269, 270, 270, 272, 272, 274, 275, 275, 277, 277, 279, 280, 280, 282, 282, 284, 285, 285, 287, 287, 289, 290, 290, 293, 294, 294, 294, 295, 295, 295, 296, 296, 296, 297, 297, 297, 298, 298, 298, 299, 299, 299, 300, 300, 300, 301, 301, 301, 303, 303, 303, 304, 304, 304, 305, 305, 305, 306, 306, 306, 307, 307, 307, 309, 309, 309, 310, 310, 310, 311, 311, 311, 312, 312, 312, 313, 313, 313, 314, 314, 314, 315, 315, 315, 316, 316, 316, 317, 317, 317, 318, 318, 318, 319, 319, 319, 320, 320, 320, 321, 321, 321, 322, 322, 322, 323, 323, 323, 324, 324, 324, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 957, 960, 964, 967, 971, 974, 978, 981, 985, 988, 992, 995, 999, 1002, 1006, 1009, 1013, 1016, 1020, 1023, 1027, 1030, 1034, 1037, 1041, 1044, 1048, 1051};
/* BEGIN LINEINFO 
assign 1 21 303
new 0 21 303
assign 1 22 304
new 0 22 304
assign 1 25 305
new 0 25 305
assign 1 26 306
new 0 26 306
assign 1 27 307
new 0 27 307
assign 1 28 308
new 0 28 308
assign 1 29 309
new 0 29 309
assign 1 30 310
new 0 30 310
assign 1 31 311
new 0 31 311
assign 1 32 312
new 0 32 312
assign 1 33 313
new 0 33 313
assign 1 37 314
new 0 37 314
assign 1 37 315
new 0 37 315
put 2 37 316
assign 1 39 317
new 0 39 317
assign 1 39 318
new 0 39 318
put 2 39 319
assign 1 40 320
new 0 40 320
assign 1 40 321
new 0 40 321
put 2 40 322
assign 1 41 323
new 0 41 323
assign 1 41 324
new 0 41 324
put 2 41 325
assign 1 43 326
NOTGet 0 43 326
assign 1 43 327
new 0 43 327
put 2 43 328
assign 1 44 329
ONCEGet 0 44 329
assign 1 44 330
new 0 44 330
put 2 44 331
assign 1 45 332
MANYGet 0 45 332
assign 1 45 333
new 0 45 333
put 2 45 334
assign 1 46 335
INCREMENTGet 0 46 335
assign 1 46 336
new 0 46 336
put 2 46 337
assign 1 47 338
DECREMENTGet 0 47 338
assign 1 47 339
new 0 47 339
put 2 47 340
assign 1 48 341
INCREMENT_ASSIGNGet 0 48 341
assign 1 48 342
new 0 48 342
put 2 48 343
assign 1 49 344
DECREMENT_ASSIGNGet 0 49 344
assign 1 49 345
new 0 49 345
put 2 49 346
assign 1 50 347
MULTIPLYGet 0 50 347
assign 1 50 348
new 0 50 348
put 2 50 349
assign 1 51 350
DIVIDEGet 0 51 350
assign 1 51 351
new 0 51 351
put 2 51 352
assign 1 52 353
MODULUSGet 0 52 353
assign 1 52 354
new 0 52 354
put 2 52 355
assign 1 53 356
ADDGet 0 53 356
assign 1 53 357
new 0 53 357
put 2 53 358
assign 1 54 359
SUBTRACTGet 0 54 359
assign 1 54 360
new 0 54 360
put 2 54 361
assign 1 55 362
GREATERGet 0 55 362
assign 1 55 363
new 0 55 363
put 2 55 364
assign 1 56 365
GREATER_EQUALSGet 0 56 365
assign 1 56 366
new 0 56 366
put 2 56 367
assign 1 57 368
LESSERGet 0 57 368
assign 1 57 369
new 0 57 369
put 2 57 370
assign 1 58 371
LESSER_EQUALSGet 0 58 371
assign 1 58 372
new 0 58 372
put 2 58 373
assign 1 59 374
EQUALSGet 0 59 374
assign 1 59 375
new 0 59 375
put 2 59 376
assign 1 60 377
NOT_EQUALSGet 0 60 377
assign 1 60 378
new 0 60 378
put 2 60 379
assign 1 61 380
ANDGet 0 61 380
assign 1 61 381
new 0 61 381
put 2 61 382
assign 1 62 383
ORGet 0 62 383
assign 1 62 384
new 0 62 384
put 2 62 385
assign 1 63 386
LOGICAL_ANDGet 0 63 386
assign 1 63 387
new 0 63 387
put 2 63 388
assign 1 64 389
LOGICAL_ORGet 0 64 389
assign 1 64 390
new 0 64 390
put 2 64 391
assign 1 65 392
INGet 0 65 392
assign 1 65 393
new 0 65 393
put 2 65 394
assign 1 66 395
ADD_ASSIGNGet 0 66 395
assign 1 66 396
new 0 66 396
put 2 66 397
assign 1 67 398
SUBTRACT_ASSIGNGet 0 67 398
assign 1 67 399
new 0 67 399
put 2 67 400
assign 1 68 401
MULTIPLY_ASSIGNGet 0 68 401
assign 1 68 402
new 0 68 402
put 2 68 403
assign 1 69 404
DIVIDE_ASSIGNGet 0 69 404
assign 1 69 405
new 0 69 405
put 2 69 406
assign 1 70 407
MODULUS_ASSIGNGet 0 70 407
assign 1 70 408
new 0 70 408
put 2 70 409
assign 1 71 410
AND_ASSIGNGet 0 71 410
assign 1 71 411
new 0 71 411
put 2 71 412
assign 1 72 413
OR_ASSIGNGet 0 72 413
assign 1 72 414
new 0 72 414
put 2 72 415
assign 1 73 416
ASSIGNGet 0 73 416
assign 1 73 417
new 0 73 417
put 2 73 418
assign 1 75 419
NOTGet 0 75 419
assign 1 75 420
new 0 75 420
put 2 75 421
assign 1 76 422
ONCEGet 0 76 422
assign 1 76 423
new 0 76 423
put 2 76 424
assign 1 77 425
MANYGet 0 77 425
assign 1 77 426
new 0 77 426
put 2 77 427
assign 1 78 428
INCREMENTGet 0 78 428
assign 1 78 429
new 0 78 429
put 2 78 430
assign 1 79 431
DECREMENTGet 0 79 431
assign 1 79 432
new 0 79 432
put 2 79 433
assign 1 80 434
MULTIPLYGet 0 80 434
assign 1 80 435
new 0 80 435
put 2 80 436
assign 1 81 437
DIVIDEGet 0 81 437
assign 1 81 438
new 0 81 438
put 2 81 439
assign 1 82 440
MODULUSGet 0 82 440
assign 1 82 441
new 0 82 441
put 2 82 442
assign 1 83 443
ADDGet 0 83 443
assign 1 83 444
new 0 83 444
put 2 83 445
assign 1 84 446
SUBTRACTGet 0 84 446
assign 1 84 447
new 0 84 447
put 2 84 448
assign 1 85 449
GREATERGet 0 85 449
assign 1 85 450
new 0 85 450
put 2 85 451
assign 1 86 452
GREATER_EQUALSGet 0 86 452
assign 1 86 453
new 0 86 453
put 2 86 454
assign 1 87 455
LESSERGet 0 87 455
assign 1 87 456
new 0 87 456
put 2 87 457
assign 1 88 458
LESSER_EQUALSGet 0 88 458
assign 1 88 459
new 0 88 459
put 2 88 460
assign 1 89 461
EQUALSGet 0 89 461
assign 1 89 462
new 0 89 462
put 2 89 463
assign 1 90 464
NOT_EQUALSGet 0 90 464
assign 1 90 465
new 0 90 465
put 2 90 466
assign 1 91 467
ANDGet 0 91 467
assign 1 91 468
new 0 91 468
put 2 91 469
assign 1 92 470
ORGet 0 92 470
assign 1 92 471
new 0 92 471
put 2 92 472
assign 1 93 473
LOGICAL_ANDGet 0 93 473
assign 1 93 474
new 0 93 474
put 2 93 475
assign 1 94 476
LOGICAL_ORGet 0 94 476
assign 1 94 477
new 0 94 477
put 2 94 478
assign 1 95 479
INGet 0 95 479
assign 1 95 480
new 0 95 480
put 2 95 481
assign 1 96 482
ADD_ASSIGNGet 0 96 482
assign 1 96 483
new 0 96 483
put 2 96 484
assign 1 97 485
SUBTRACT_ASSIGNGet 0 97 485
assign 1 97 486
new 0 97 486
put 2 97 487
assign 1 98 488
INCREMENT_ASSIGNGet 0 98 488
assign 1 98 489
new 0 98 489
put 2 98 490
assign 1 99 491
DECREMENT_ASSIGNGet 0 99 491
assign 1 99 492
new 0 99 492
put 2 99 493
assign 1 100 494
MULTIPLY_ASSIGNGet 0 100 494
assign 1 100 495
new 0 100 495
put 2 100 496
assign 1 101 497
DIVIDE_ASSIGNGet 0 101 497
assign 1 101 498
new 0 101 498
put 2 101 499
assign 1 102 500
MODULUS_ASSIGNGet 0 102 500
assign 1 102 501
new 0 102 501
put 2 102 502
assign 1 103 503
AND_ASSIGNGet 0 103 503
assign 1 103 504
new 0 103 504
put 2 103 505
assign 1 104 506
OR_ASSIGNGet 0 104 506
assign 1 104 507
new 0 104 507
put 2 104 508
assign 1 105 509
ASSIGNGet 0 105 509
assign 1 105 510
new 0 105 510
put 2 105 511
assign 1 107 512
IFGet 0 107 512
assign 1 107 513
new 0 107 513
put 2 107 514
assign 1 108 515
ELIFGet 0 108 515
assign 1 108 516
new 0 108 516
put 2 108 517
assign 1 109 518
WHILEGet 0 109 518
assign 1 109 519
new 0 109 519
put 2 109 520
assign 1 110 521
FORGet 0 110 521
assign 1 110 522
new 0 110 522
put 2 110 523
assign 1 111 524
FOREACHGet 0 111 524
assign 1 111 525
new 0 111 525
put 2 111 526
assign 1 112 527
EMITGet 0 112 527
assign 1 112 528
new 0 112 528
put 2 112 529
assign 1 113 530
IFEMITGet 0 113 530
assign 1 113 531
new 0 113 531
put 2 113 532
assign 1 114 533
METHODGet 0 114 533
assign 1 114 534
new 0 114 534
put 2 114 535
assign 1 115 536
CLASSGet 0 115 536
assign 1 115 537
new 0 115 537
put 2 115 538
assign 1 116 539
EXPRGet 0 116 539
assign 1 116 540
new 0 116 540
put 2 116 541
assign 1 117 542
ELSEGet 0 117 542
assign 1 117 543
new 0 117 543
put 2 117 544
assign 1 118 545
TRYGet 0 118 545
assign 1 118 546
new 0 118 546
put 2 118 547
assign 1 119 548
LOOPGet 0 119 548
assign 1 119 549
new 0 119 549
put 2 119 550
assign 1 120 551
PROPERTIESGet 0 120 551
assign 1 120 552
new 0 120 552
put 2 120 553
assign 1 121 554
CATCHGet 0 121 554
assign 1 121 555
new 0 121 555
put 2 121 556
assign 1 122 557
TRANSUNITGet 0 122 557
assign 1 122 558
new 0 122 558
put 2 122 559
assign 1 123 560
BRACESGet 0 123 560
assign 1 123 561
new 0 123 561
put 2 123 562
assign 1 124 563
PARENSGet 0 124 563
assign 1 124 564
new 0 124 564
put 2 124 565
assign 1 125 566
IDXGet 0 125 566
assign 1 125 567
new 0 125 567
put 2 125 568
assign 1 127 569
IFGet 0 127 569
assign 1 127 570
new 0 127 570
put 2 127 571
assign 1 128 572
ELIFGet 0 128 572
assign 1 128 573
new 0 128 573
put 2 128 574
assign 1 129 575
WHILEGet 0 129 575
assign 1 129 576
new 0 129 576
put 2 129 577
assign 1 130 578
FORGet 0 130 578
assign 1 130 579
new 0 130 579
put 2 130 580
assign 1 131 581
FOREACHGet 0 131 581
assign 1 131 582
new 0 131 582
put 2 131 583
assign 1 132 584
EMITGet 0 132 584
assign 1 132 585
new 0 132 585
put 2 132 586
assign 1 133 587
IFEMITGet 0 133 587
assign 1 133 588
new 0 133 588
put 2 133 589
assign 1 134 590
METHODGet 0 134 590
assign 1 134 591
new 0 134 591
put 2 134 592
assign 1 135 593
CATCHGet 0 135 593
assign 1 135 594
new 0 135 594
put 2 135 595
assign 1 137 596
IFGet 0 137 596
assign 1 137 597
new 0 137 597
put 2 137 598
assign 1 138 599
ELIFGet 0 138 599
assign 1 138 600
new 0 138 600
put 2 138 601
assign 1 139 602
WHILEGet 0 139 602
assign 1 139 603
new 0 139 603
put 2 139 604
assign 1 140 605
FORGet 0 140 605
assign 1 140 606
new 0 140 606
put 2 140 607
assign 1 141 608
FOREACHGet 0 141 608
assign 1 141 609
new 0 141 609
put 2 141 610
assign 1 142 611
EXPRGet 0 142 611
assign 1 142 612
new 0 142 612
put 2 142 613
prepare 0 144 614
assign 1 150 726
new 0 150 726
assign 1 151 727
new 0 151 727
assign 1 153 728
new 0 153 728
assign 1 154 729
new 0 154 729
assign 1 154 730
new 2 154 730
assign 1 155 731
DIVIDEGet 0 155 731
put 2 155 732
assign 1 157 733
new 0 157 733
addToken 1 158 734
assign 1 159 735
BRACESGet 0 159 735
put 2 159 736
assign 1 161 737
new 0 161 737
addToken 1 162 738
assign 1 163 739
RBRACESGet 0 163 739
put 2 163 740
assign 1 165 741
new 0 165 741
addToken 1 166 742
assign 1 167 743
PARENSGet 0 167 743
put 2 167 744
assign 1 169 745
new 0 169 745
addToken 1 170 746
assign 1 171 747
RPARENSGet 0 171 747
put 2 171 748
assign 1 173 749
new 0 173 749
addToken 1 174 750
assign 1 175 751
SEMIGet 0 175 751
put 2 175 752
assign 1 177 753
new 0 177 753
addToken 1 178 754
assign 1 179 755
COLONGet 0 179 755
put 2 179 756
assign 1 181 757
new 0 181 757
addToken 1 182 758
assign 1 183 759
COMMAGet 0 183 759
put 2 183 760
assign 1 185 761
new 0 185 761
addToken 1 186 762
assign 1 187 763
ADDGet 0 187 763
put 2 187 764
assign 1 189 765
new 0 189 765
addToken 1 190 766
assign 1 191 767
ATYPEGet 0 191 767
put 2 191 768
assign 1 193 769
new 0 193 769
addToken 1 194 770
assign 1 195 771
SUBTRACTGet 0 195 771
put 2 195 772
assign 1 197 773
new 0 197 773
addToken 1 198 774
assign 1 199 775
ONCEGet 0 199 775
put 2 199 776
assign 1 201 777
new 0 201 777
addToken 1 202 778
assign 1 203 779
MANYGet 0 203 779
put 2 203 780
assign 1 207 781
new 0 207 781
assign 1 207 782
codeNew 1 207 782
addToken 1 209 783
assign 1 210 784
FSLASHGet 0 210 784
put 2 210 785
assign 1 212 786
new 0 212 786
assign 1 212 787
codeNew 1 212 787
addToken 1 214 788
assign 1 215 789
STRQGet 0 215 789
put 2 215 790
assign 1 217 791
new 0 217 791
assign 1 217 792
codeNew 1 217 792
addToken 1 219 793
assign 1 220 794
WSTRQGet 0 220 794
put 2 220 795
assign 1 222 796
new 0 222 796
assign 1 222 797
codeNew 1 222 797
addToken 1 224 798
assign 1 225 799
IDXGet 0 225 799
put 2 225 800
assign 1 227 801
new 0 227 801
assign 1 227 802
codeNew 1 227 802
addToken 1 229 803
assign 1 230 804
RIDXGet 0 230 804
put 2 230 805
assign 1 232 806
new 0 232 806
assign 1 232 807
codeNew 1 232 807
addToken 1 234 808
assign 1 235 809
MODULUSGet 0 235 809
put 2 235 810
assign 1 237 811
new 0 237 811
assign 1 237 812
codeNew 1 237 812
addToken 1 239 813
assign 1 240 814
ASSIGNGet 0 240 814
put 2 240 815
assign 1 242 816
new 0 242 816
assign 1 242 817
codeNew 1 242 817
addToken 1 244 818
assign 1 245 819
GREATERGet 0 245 819
put 2 245 820
assign 1 247 821
new 0 247 821
assign 1 247 822
codeNew 1 247 822
addToken 1 249 823
assign 1 250 824
LESSERGet 0 250 824
put 2 250 825
assign 1 252 826
new 0 252 826
assign 1 252 827
codeNew 1 252 827
addToken 1 254 828
assign 1 255 829
NOTGet 0 255 829
put 2 255 830
assign 1 257 831
new 0 257 831
assign 1 257 832
codeNew 1 257 832
addToken 1 259 833
assign 1 260 834
ANDGet 0 260 834
put 2 260 835
assign 1 262 836
new 0 262 836
assign 1 262 837
codeNew 1 262 837
addToken 1 264 838
assign 1 265 839
ORGet 0 265 839
put 2 265 840
assign 1 267 841
new 0 267 841
assign 1 267 842
codeNew 1 267 842
addToken 1 269 843
assign 1 270 844
MULTIPLYGet 0 270 844
put 2 270 845
assign 1 272 846
new 0 272 846
assign 1 272 847
codeNew 1 272 847
addToken 1 274 848
assign 1 275 849
DOTGet 0 275 849
put 2 275 850
assign 1 277 851
new 0 277 851
assign 1 277 852
codeNew 1 277 852
addToken 1 279 853
assign 1 280 854
SPACEGet 0 280 854
put 2 280 855
assign 1 282 856
new 0 282 856
assign 1 282 857
codeNew 1 282 857
addToken 1 284 858
assign 1 285 859
SPACEGet 0 285 859
put 2 285 860
assign 1 287 861
new 0 287 861
assign 1 287 862
newlineGet 0 287 862
addToken 1 289 863
assign 1 290 864
NEWLINEGet 0 290 864
put 2 290 865
assign 1 293 866
new 0 293 866
assign 1 294 867
new 0 294 867
assign 1 294 868
USEGet 0 294 868
put 2 294 869
assign 1 295 870
new 0 295 870
assign 1 295 871
ASGet 0 295 871
put 2 295 872
assign 1 296 873
new 0 296 873
assign 1 296 874
CLASSGet 0 296 874
put 2 296 875
assign 1 297 876
new 0 297 876
assign 1 297 877
METHODGet 0 297 877
put 2 297 878
assign 1 298 879
new 0 298 879
assign 1 298 880
DEFMODGet 0 298 880
put 2 298 881
assign 1 299 882
new 0 299 882
assign 1 299 883
DEFMODGet 0 299 883
put 2 299 884
assign 1 300 885
new 0 300 885
assign 1 300 886
DEFMODGet 0 300 886
put 2 300 887
assign 1 301 888
new 0 301 888
assign 1 301 889
VARGet 0 301 889
put 2 301 890
assign 1 303 891
new 0 303 891
assign 1 303 892
IFGet 0 303 892
put 2 303 893
assign 1 304 894
new 0 304 894
assign 1 304 895
IFGet 0 304 895
put 2 304 896
assign 1 305 897
new 0 305 897
assign 1 305 898
ELIFGet 0 305 898
put 2 305 899
assign 1 306 900
new 0 306 900
assign 1 306 901
ELSEGet 0 306 901
put 2 306 902
assign 1 307 903
new 0 307 903
assign 1 307 904
LOOPGet 0 307 904
put 2 307 905
assign 1 309 906
new 0 309 906
assign 1 309 907
PROPERTIESGet 0 309 907
put 2 309 908
assign 1 310 909
new 0 310 909
assign 1 310 910
WHILEGet 0 310 910
put 2 310 911
assign 1 311 912
new 0 311 912
assign 1 311 913
WHILEGet 0 311 913
put 2 311 914
assign 1 312 915
new 0 312 915
assign 1 312 916
FORGet 0 312 916
put 2 312 917
assign 1 313 918
new 0 313 918
assign 1 313 919
FOREACHGet 0 313 919
put 2 313 920
assign 1 314 921
new 0 314 921
assign 1 314 922
INGet 0 314 922
put 2 314 923
assign 1 315 924
new 0 315 924
assign 1 315 925
EMITGet 0 315 925
put 2 315 926
assign 1 316 927
new 0 316 927
assign 1 316 928
IFEMITGet 0 316 928
put 2 316 929
assign 1 317 930
new 0 317 930
assign 1 317 931
IFEMITGet 0 317 931
put 2 317 932
assign 1 318 933
new 0 318 933
assign 1 318 934
BREAKGet 0 318 934
put 2 318 935
assign 1 319 936
new 0 319 936
assign 1 319 937
CONTINUEGet 0 319 937
put 2 319 938
assign 1 320 939
new 0 320 939
assign 1 320 940
NULLGet 0 320 940
put 2 320 941
assign 1 321 942
new 0 321 942
assign 1 321 943
TRUEGet 0 321 943
put 2 321 944
assign 1 322 945
new 0 322 945
assign 1 322 946
FALSEGet 0 322 946
put 2 322 947
assign 1 323 948
new 0 323 948
assign 1 323 949
TRYGet 0 323 949
put 2 323 950
assign 1 324 951
new 0 324 951
assign 1 324 952
CATCHGet 0 324 952
put 2 324 953
return 1 0 957
assign 1 0 960
return 1 0 964
assign 1 0 967
return 1 0 971
assign 1 0 974
return 1 0 978
assign 1 0 981
return 1 0 985
assign 1 0 988
return 1 0 992
assign 1 0 995
return 1 0 999
assign 1 0 1002
return 1 0 1006
assign 1 0 1009
return 1 0 1013
assign 1 0 1016
return 1 0 1020
assign 1 0 1023
return 1 0 1027
assign 1 0 1030
return 1 0 1034
assign 1 0 1037
return 1 0 1041
assign 1 0 1044
return 1 0 1048
assign 1 0 1051
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 499424269: return bem_operNamesGet_0();
case -1323554192: return bem_matchMapGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case -485024848: return bem_conTypesGet_0();
case -845792839: return bem_iteratorGet_0();
case 1638254553: return bem_operGet_0();
case 1284159779: return bem_anchorTypesGet_0();
case -1012494862: return bem_once_0();
case 1820417453: return bem_create_0();
case -729571811: return bem_serializeToString_0();
case -667821230: return bem_parensReqGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case -1081412016: return bem_many_0();
case -1260156474: return bem_maxargsGet_0();
case -1011420424: return bem_prepare_0();
case -634261936: return bem_rwordsGet_0();
case -314718434: return bem_print_0();
case -614472113: return bem_mtdxPadGet_0();
case -644675716: return bem_ntypesGet_0();
case 104713553: return bem_new_0();
case -416660294: return bem_objectIteratorGet_0();
case -1308786538: return bem_echo_0();
case 287040793: return bem_hashGet_0();
case 521161323: return bem_unwindToGet_0();
case 264093610: return bem_unwindOkGet_0();
case 2055025483: return bem_serializeContents_0();
case 1503762842: return bem_twtokGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -895284094: return bem_extraSlotsGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1514845095: return bem_twtokSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -656738977: return bem_parensReqSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 510506522: return bem_operNamesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1249074221: return bem_maxargsSet_1(bevd_0);
case -623179683: return bem_rwordsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -603389860: return bem_mtdxPadSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1649336806: return bem_operSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1295242032: return bem_anchorTypesSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -884201841: return bem_extraSlotsSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1312471939: return bem_matchMapSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 532243576: return bem_unwindToSet_1(bevd_0);
case -473942595: return bem_conTypesSet_1(bevd_0);
case 275175863: return bem_unwindOkSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildConstants();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildConstants.bevs_inst = (BEC_2_5_9_BuildConstants)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildConstants.bevs_inst;
}
}
}
