namespace be.BEL_4_Base {
/* IO:File: source/base/Float.be */
public class BEC_4_5_MathFloat : BEC_6_6_SystemObject {
public BEC_4_5_MathFloat() { }
static BEC_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2D};
private static byte[] bels_1 = {0x2E};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(10));
private static byte[] bels_2 = {0x2E};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 1));
public static new BEC_4_5_MathFloat bevs_inst;
public BEC_6_6_SystemObject bevp_vfloat;
public virtual BEC_6_6_SystemObject bem_vfloatGet_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_vfloatSet_0() {
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_4_5_MathFloat bem_new_1(BEC_6_6_SystemObject beva_si) {
BEC_5_4_LogicBool bevl_neg = null;
BEC_4_3_MathInt bevl_dec = null;
BEC_4_3_MathInt bevl_lhs = null;
BEC_4_3_MathInt bevl_rhs = null;
BEC_4_3_MathInt bevl_divby = null;
BEC_4_5_MathFloat bevl_rhsf = null;
BEC_4_5_MathFloat bevl_lhsf = null;
BEC_4_5_MathFloat bevl_res = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_5_MathFloat bevt_21_tmpvar_phold = null;
BEC_4_5_MathFloat bevt_22_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_0));
bevt_0_tmpvar_phold = beva_si.bemd_1(1489442332, BEL_4_Base.bevn_begins_1, bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 63 */ {
bevl_neg = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
beva_si = beva_si.bemd_1(1250088509, BEL_4_Base.bevn_substring_1, bevt_2_tmpvar_phold);
} /* Line: 65 */
 else  /* Line: 66 */ {
bevl_neg = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 67 */
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_1));
bevl_dec = (BEC_4_3_MathInt) beva_si.bemd_1(1274448085, BEL_4_Base.bevn_find_1, bevt_3_tmpvar_phold);
if (bevl_dec == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 70 */ {
bevt_6_tmpvar_phold = bevo_0;
bevt_5_tmpvar_phold = bevl_dec.bem_greater_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 71 */ {
bevt_8_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_7_tmpvar_phold = beva_si.bemd_2(1250088508, BEL_4_Base.bevn_substring_2, bevt_8_tmpvar_phold, bevl_dec);
bevl_lhs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(bevt_7_tmpvar_phold);
} /* Line: 72 */
 else  /* Line: 73 */ {
bevl_lhs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
} /* Line: 74 */
bevt_11_tmpvar_phold = bevo_1;
bevt_10_tmpvar_phold = bevl_dec.bem_add_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = beva_si.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_lesser_1((BEC_4_3_MathInt) bevt_12_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 76 */ {
bevt_15_tmpvar_phold = bevo_2;
bevt_14_tmpvar_phold = bevl_dec.bem_add_1(bevt_15_tmpvar_phold);
bevt_13_tmpvar_phold = beva_si.bemd_1(1250088509, BEL_4_Base.bevn_substring_1, bevt_14_tmpvar_phold);
bevl_rhs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(bevt_13_tmpvar_phold);
} /* Line: 77 */
 else  /* Line: 78 */ {
bevl_rhs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
} /* Line: 79 */
} /* Line: 76 */
 else  /* Line: 81 */ {
bevl_lhs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
} /* Line: 83 */
bevt_16_tmpvar_phold = bevo_3;
bevt_18_tmpvar_phold = bevl_rhs.bem_toString_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_sizeGet_0();
bevl_divby = bevt_16_tmpvar_phold.bem_power_1(bevt_17_tmpvar_phold);
if (bevl_neg.bevi_bool) /* Line: 86 */ {
bevt_19_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_tmpvar_phold);
} /* Line: 88 */
bevt_21_tmpvar_phold = bevl_rhs.bem_toFloat_0();
bevt_22_tmpvar_phold = bevl_divby.bem_toFloat_0();
bevl_rhsf = bevt_21_tmpvar_phold.bem_divide_1(bevt_22_tmpvar_phold);
bevl_lhsf = bevl_lhs.bem_toFloat_0();
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_4_5_MathFloat) bevl_res;
} /*method end*/
public override BEC_6_6_SystemObject bem_create_0() {
BEC_4_5_MathFloat bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_5_MathFloat) (new BEC_4_5_MathFloat()).bem_new_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_serializeToString_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) {
this.bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_5_4_LogicBool bem_serializeContents_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_toInt_0() {
BEC_4_3_MathInt bevl_ii = null;
bevl_ii = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
return bevl_ii;
} /*method end*/
public override BEC_4_3_MathInt bem_hashGet_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toInt_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
BEC_4_3_MathInt bevl_lhi = null;
BEC_4_5_MathFloat bevl_rh = null;
BEC_4_3_MathInt bevl_rhi = null;
BEC_4_5_MathFloat bevt_0_tmpvar_phold = null;
BEC_4_5_MathFloat bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevl_lhi = this.bem_toInt_0();
bevt_0_tmpvar_phold = bevl_lhi.bem_toFloat_0();
bevl_rh = this.bem_subtract_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_4_5_MathFloat) (new BEC_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_tmpvar_phold);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_tmpvar_phold = bevl_lhi.bem_toString_0();
bevt_5_tmpvar_phold = bevo_4;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevl_rhi.bem_toString_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_6_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_4_5_MathFloat bem_increment_0() {
BEC_4_5_MathFloat bevl_res = null;
BEC_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 143 */ {
bevl_res = (BEC_4_5_MathFloat) (new BEC_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 150 */
} /*method end*/
public virtual BEC_4_5_MathFloat bem_decrement_0() {
BEC_4_5_MathFloat bevl_res = null;
BEC_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 158 */ {
bevl_res = (BEC_4_5_MathFloat) (new BEC_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 165 */
} /*method end*/
public virtual BEC_4_5_MathFloat bem_add_1(BEC_4_5_MathFloat beva_xi) {
BEC_4_5_MathFloat bevl_res = null;
BEC_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 173 */ {
bevl_res = (BEC_4_5_MathFloat) (new BEC_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 180 */
} /*method end*/
public virtual BEC_4_5_MathFloat bem_subtract_1(BEC_4_5_MathFloat beva_xi) {
BEC_4_5_MathFloat bevl_res = null;
BEC_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 188 */ {
bevl_res = (BEC_4_5_MathFloat) (new BEC_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 195 */
} /*method end*/
public virtual BEC_4_5_MathFloat bem_multiply_1(BEC_4_5_MathFloat beva_xi) {
BEC_4_5_MathFloat bevl_res = null;
BEC_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 203 */ {
bevl_res = (BEC_4_5_MathFloat) (new BEC_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 210 */
} /*method end*/
public virtual BEC_4_5_MathFloat bem_divide_1(BEC_4_5_MathFloat beva_xi) {
BEC_4_5_MathFloat bevl_res = null;
BEC_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 218 */ {
bevl_res = (BEC_4_5_MathFloat) (new BEC_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 225 */
} /*method end*/
public virtual BEC_4_5_MathFloat bem_modulus_1(BEC_4_5_MathFloat beva_xi) {
BEC_4_5_MathFloat bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_5_MathFloat) (new BEC_4_5_MathFloat(0.0f));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_xi) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      var bevls_xi = beva_xi as BEC_4_5_MathFloat;
      if (bevls_xi != null && this.bevi_float == bevls_xi.bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_xi) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      var bevls_xi = beva_xi as BEC_4_5_MathFloat;
      if (bevls_xi == null || this.bevi_float != bevls_xi.bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_greater_1(BEC_4_5_MathFloat beva_xi) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_lesser_1(BEC_4_5_MathFloat beva_xi) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_greaterEquals_1(BEC_4_5_MathFloat beva_xi) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_lesserEquals_1(BEC_4_5_MathFloat beva_xi) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_vfloatSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_vfloat = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {63, 63, 64, 65, 65, 67, 69, 69, 70, 70, 71, 71, 72, 72, 72, 74, 76, 76, 76, 76, 77, 77, 77, 77, 79, 82, 83, 85, 85, 85, 85, 87, 87, 88, 88, 90, 90, 90, 91, 92, 93, 96, 96, 99, 99, 103, 107, 107, 118, 126, 131, 131, 135, 136, 136, 137, 137, 138, 139, 139, 139, 139, 139, 139, 144, 150, 159, 165, 174, 180, 189, 195, 204, 210, 219, 225, 233, 233, 262, 262, 291, 291, 312, 312, 333, 333, 354, 354, 375, 375, 0};
public static new int[] bevs_smnlec
 = new int[] {64, 65, 67, 68, 69, 72, 74, 75, 76, 81, 82, 83, 85, 86, 87, 90, 92, 93, 94, 95, 97, 98, 99, 100, 103, 107, 108, 110, 111, 112, 113, 115, 116, 117, 118, 120, 121, 122, 123, 124, 125, 129, 130, 134, 135, 138, 143, 144, 148, 149, 153, 154, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 184, 187, 194, 197, 204, 207, 214, 217, 224, 227, 234, 237, 242, 243, 253, 254, 264, 265, 274, 275, 284, 285, 294, 295, 304, 305, 308};
/* BEGIN LINEINFO 
assign 1 63 64
new 0 63 64
assign 1 63 65
begins 1 63 65
assign 1 64 67
new 0 64 67
assign 1 65 68
new 0 65 68
assign 1 65 69
substring 1 65 69
assign 1 67 72
new 0 67 72
assign 1 69 74
new 0 69 74
assign 1 69 75
find 1 69 75
assign 1 70 76
def 1 70 81
assign 1 71 82
new 0 71 82
assign 1 71 83
greater 1 71 83
assign 1 72 85
new 0 72 85
assign 1 72 86
substring 2 72 86
assign 1 72 87
new 1 72 87
assign 1 74 90
new 0 74 90
assign 1 76 92
new 0 76 92
assign 1 76 93
add 1 76 93
assign 1 76 94
sizeGet 0 76 94
assign 1 76 95
lesser 1 76 95
assign 1 77 97
new 0 77 97
assign 1 77 98
add 1 77 98
assign 1 77 99
substring 1 77 99
assign 1 77 100
new 1 77 100
assign 1 79 103
new 0 79 103
assign 1 82 107
new 1 82 107
assign 1 83 108
new 0 83 108
assign 1 85 110
new 0 85 110
assign 1 85 111
toString 0 85 111
assign 1 85 112
sizeGet 0 85 112
assign 1 85 113
power 1 85 113
assign 1 87 115
new 0 87 115
multiplyValue 1 87 116
assign 1 88 117
new 0 88 117
multiplyValue 1 88 118
assign 1 90 120
toFloat 0 90 120
assign 1 90 121
toFloat 0 90 121
assign 1 90 122
divide 1 90 122
assign 1 91 123
toFloat 0 91 123
assign 1 92 124
add 1 92 124
return 1 93 125
assign 1 96 129
new 0 96 129
return 1 96 130
assign 1 99 134
toString 0 99 134
return 1 99 135
new 1 103 138
assign 1 107 143
new 0 107 143
return 1 107 144
assign 1 118 148
new 0 118 148
return 1 126 149
assign 1 131 153
toInt 0 131 153
return 1 131 154
assign 1 135 167
toInt 0 135 167
assign 1 136 168
toFloat 0 136 168
assign 1 136 169
subtract 1 136 169
assign 1 137 170
new 0 137 170
assign 1 137 171
multiply 1 137 171
assign 1 138 172
toInt 0 138 172
assign 1 139 173
toString 0 139 173
assign 1 139 174
new 0 139 174
assign 1 139 175
add 1 139 175
assign 1 139 176
toString 0 139 176
assign 1 139 177
add 1 139 177
return 1 139 178
assign 1 144 184
new 0 144 184
return 1 150 187
assign 1 159 194
new 0 159 194
return 1 165 197
assign 1 174 204
new 0 174 204
return 1 180 207
assign 1 189 214
new 0 189 214
return 1 195 217
assign 1 204 224
new 0 204 224
return 1 210 227
assign 1 219 234
new 0 219 234
return 1 225 237
assign 1 233 242
new 0 233 242
return 1 233 243
assign 1 262 253
new 0 262 253
return 1 262 254
assign 1 291 264
new 0 291 264
return 1 291 265
assign 1 312 274
new 0 312 274
return 1 312 275
assign 1 333 284
new 0 333 284
return 1 333 285
assign 1 354 294
new 0 354 294
return 1 354 295
assign 1 375 304
new 0 375 304
return 1 375 305
assign 1 0 308
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 1046151292: return bem_decrement_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1175111131: return bem_toInt_0();
case 443668840: return bem_methodNotDefined_0();
case 1679729549: return bem_vfloatSet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1085372256: return bem_increment_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 1668647297: return bem_vfloatGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 92659731: return bem_add_1((BEC_4_5_MathFloat) bevd_0);
case 1551584407: return bem_modulus_1((BEC_4_5_MathFloat) bevd_0);
case 81310150: return bem_subtract_1((BEC_4_5_MathFloat) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 364269035: return bem_divide_1((BEC_4_5_MathFloat) bevd_0);
case 1265088726: return bem_multiply_1((BEC_4_5_MathFloat) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_4_5_MathFloat) bevd_0);
case 2090192440: return bem_lesser_1((BEC_4_5_MathFloat) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1220624855: return bem_lesserEquals_1((BEC_4_5_MathFloat) bevd_0);
case 1679729550: return bem_vfloatSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 979186229: return bem_greaterEquals_1((BEC_4_5_MathFloat) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_4_5_MathFloat();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_4_5_MathFloat.bevs_inst = (BEC_4_5_MathFloat)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_4_5_MathFloat.bevs_inst;
}
}
}
