namespace be.BEL_4_Base {
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet : BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
static BEC_2_9_3_ContainerSet() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_2_9_3_ContainerSet bevs_inst;
public BEC_2_9_5_ContainerArray bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
if (bevp_size.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 241 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
if (bevp_size.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /* Line: 248 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_3_9_3_21_ContainerSetSerializationIterator) (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_5_ContainerArray beva_ninner, BEC_2_9_5_ContainerArray beva_ir) {
BEC_3_9_5_8_ContainerArrayIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
 /* Line: 266 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevt_4_tmpvar_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpvar_phold = this.bem_innerPut_4(bevt_4_tmpvar_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 269 */ {
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 270 */
} /* Line: 269 */
} /* Line: 268 */
 else  /* Line: 266 */ {
break;
} /* Line: 266 */
} /* Line: 266 */
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_5_ContainerArray beva_slt) {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_5_ContainerArray bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpvar_phold = bevo_2;
bevl_nslots = bevt_0_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
bevl_ninner = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 281 */ {
bevt_4_tmpvar_phold = this.bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_1(bevl_nslots);
} /* Line: 283 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
return bevl_ninner;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (beva_other == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 289 */ {
bevt_4_tmpvar_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpvar_phold = this.bem_sizeGet_0();
if (bevt_4_tmpvar_phold.bevi_int != bevt_5_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 289 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 289 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 289 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 290 */
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 292 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevl_i = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_9_tmpvar_phold = beva_other.bem_has_1(bevl_i);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevt_10_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_10_tmpvar_phold;
} /* Line: 293 */
} /* Line: 293 */
 else  /* Line: 292 */ {
break;
} /* Line: 292 */
} /* Line: 292 */
bevt_11_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_5_ContainerArray beva_slt) {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_3;
if (bevl_hval.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 302 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 303 */
} /* Line: 302 */
 else  /* Line: 305 */ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(449328306, BEL_4_Base.bevn_hvalGet_0);
} /* Line: 306 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 310 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 312 */ {
if (beva_inode == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_6_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_tmpvar_phold.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpvar_phold);
} /* Line: 314 */
 else  /* Line: 315 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 316 */
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 319 */
 else  /* Line: 312 */ {
bevt_10_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_9_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 320 */ {
bevt_11_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /* Line: 321 */
 else  /* Line: 312 */ {
bevt_13_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpvar_phold, beva_k);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 322 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_14_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_14_tmpvar_phold;
} /* Line: 326 */
 else  /* Line: 327 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 329 */ {
bevt_16_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_16_tmpvar_phold;
} /* Line: 330 */
} /* Line: 329 */
} /* Line: 312 */
} /* Line: 312 */
} /* Line: 312 */
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 337 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 340 */ {
bevt_3_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 340 */ {
bevl_slt = (BEC_2_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
} /* Line: 341 */
 else  /* Line: 340 */ {
break;
} /* Line: 340 */
} /* Line: 340 */
bevp_slots = bevl_slt;
} /* Line: 343 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 345 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 346 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_4;
if (bevl_hval.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 355 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 359 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 361 */ {
return null;
} /* Line: 362 */
 else  /* Line: 361 */ {
bevt_5_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_4_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 363 */ {
return null;
} /* Line: 364 */
 else  /* Line: 361 */ {
bevt_7_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpvar_phold, beva_k);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 365 */ {
bevt_8_tmpvar_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpvar_phold;
} /* Line: 366 */
 else  /* Line: 367 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 369 */ {
return null;
} /* Line: 370 */
} /* Line: 369 */
} /* Line: 361 */
} /* Line: 361 */
} /* Line: 361 */
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_5;
if (bevl_hval.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 381 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 385 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 387 */ {
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 388 */
 else  /* Line: 387 */ {
bevt_6_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_5_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /* Line: 390 */
 else  /* Line: 387 */ {
bevt_9_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpvar_phold, beva_k);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 391 */ {
bevt_10_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 392 */
 else  /* Line: 393 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 395 */ {
bevt_12_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /* Line: 396 */
} /* Line: 395 */
} /* Line: 387 */
} /* Line: 387 */
} /* Line: 387 */
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_6;
if (bevl_hval.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 408 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 412 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 414 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 415 */
 else  /* Line: 414 */ {
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_6_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 416 */ {
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 417 */
 else  /* Line: 414 */ {
bevt_10_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpvar_phold, beva_k);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 418 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 422 */ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 422 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 424 */ {
bevt_15_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_14_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 424 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 424 */ {
bevt_16_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_16_tmpvar_phold;
} /* Line: 425 */
 else  /* Line: 426 */ {
bevt_18_tmpvar_phold = bevo_7;
bevt_17_tmpvar_phold = bevl_sl.bem_subtract_1(bevt_18_tmpvar_phold);
bevl_slt.bem_put_2(bevt_17_tmpvar_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 428 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 430 */
 else  /* Line: 422 */ {
break;
} /* Line: 422 */
} /* Line: 422 */
bevt_19_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_19_tmpvar_phold;
} /* Line: 432 */
 else  /* Line: 433 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 435 */ {
bevt_21_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_21_tmpvar_phold;
} /* Line: 436 */
} /* Line: 435 */
} /* Line: 414 */
} /* Line: 414 */
} /* Line: 414 */
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
bevl_other = this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = (BEC_2_9_5_ContainerArray) bevp_slots.bem_copy_0();
bevl_other.bemd_1(365988447, BEL_4_Base.bevn_slotsSet_1, bevt_0_tmpvar_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 446 */ {
bevt_2_tmpvar_phold = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 446 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 448 */ {
bevt_4_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_6_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_tmpvar_phold.bem_new_3(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_4_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_5_tmpvar_phold);
} /* Line: 449 */
 else  /* Line: 450 */ {
bevt_10_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_10_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, null);
} /* Line: 451 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 446 */
 else  /* Line: 446 */ {
break;
} /* Line: 446 */
} /* Line: 446 */
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_clear_0() {
bevp_slots.bem_clear_0();
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_keyIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_nodeIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 489 */ {
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 490 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 490 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_3_tmpvar_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 491 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 492 */
} /* Line: 491 */
 else  /* Line: 490 */ {
break;
} /* Line: 490 */
} /* Line: 490 */
} /* Line: 490 */
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 501 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 501 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 502 */
 else  /* Line: 501 */ {
break;
} /* Line: 501 */
} /* Line: 501 */
if (beva_other == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 504 */ {
bevt_1_tmpvar_loop = beva_other.bem_setIteratorGet_0();
while (true)
 /* Line: 505 */ {
bevt_4_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 505 */ {
bevl_x = bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 506 */
 else  /* Line: 505 */ {
break;
} /* Line: 505 */
} /* Line: 505 */
} /* Line: 505 */
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = (BEC_2_9_3_ContainerSet) this.bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 519 */ {
bevt_2_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 520 */ {
bevt_0_tmpvar_loop = beva_other.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 521 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 521 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_put_1(bevl_x);
} /* Line: 522 */
 else  /* Line: 521 */ {
break;
} /* Line: 521 */
} /* Line: 521 */
} /* Line: 521 */
 else  /* Line: 520 */ {
bevt_4_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 524 */ {
bevt_5_tmpvar_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
this.bem_put_1(bevt_5_tmpvar_phold);
} /* Line: 525 */
 else  /* Line: 526 */ {
this.bem_put_1(beva_other);
} /* Line: 527 */
} /* Line: 520 */
} /* Line: 520 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_slotsGet_0() {
return bevp_slots;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_slots = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_moduGet_0() {
return bevp_modu;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_multiGet_0() {
return bevp_multi;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() {
return bevp_rel;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() {
return bevp_baseNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() {
return bevp_innerPutAdded;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {222, 222, 228, 229, 230, 231, 232, 233, 234, 240, 240, 240, 241, 241, 243, 243, 247, 247, 247, 248, 248, 250, 250, 254, 254, 258, 258, 262, 262, 266, 266, 267, 268, 268, 269, 269, 269, 270, 270, 274, 274, 279, 279, 279, 279, 280, 281, 281, 282, 283, 285, 289, 289, 0, 289, 289, 289, 289, 0, 0, 290, 290, 292, 0, 292, 292, 293, 293, 293, 293, 295, 295, 299, 300, 300, 301, 302, 302, 302, 303, 306, 308, 309, 311, 312, 312, 313, 313, 314, 314, 314, 316, 318, 319, 319, 320, 320, 320, 320, 321, 321, 322, 322, 323, 325, 326, 326, 328, 329, 329, 330, 330, 337, 337, 338, 339, 340, 340, 341, 343, 346, 351, 352, 353, 354, 354, 354, 355, 357, 358, 360, 361, 361, 362, 363, 363, 363, 363, 364, 365, 365, 366, 366, 368, 369, 369, 370, 377, 378, 379, 380, 380, 380, 381, 383, 384, 386, 387, 387, 388, 388, 389, 389, 389, 389, 390, 390, 391, 391, 392, 392, 394, 395, 395, 396, 396, 403, 404, 406, 407, 407, 407, 408, 410, 411, 413, 414, 414, 415, 415, 416, 416, 416, 416, 417, 417, 418, 418, 419, 420, 421, 422, 422, 423, 424, 424, 0, 424, 424, 424, 424, 0, 0, 425, 425, 427, 427, 427, 428, 430, 432, 432, 434, 435, 435, 436, 436, 443, 444, 445, 445, 446, 446, 446, 446, 447, 448, 448, 449, 449, 449, 449, 449, 449, 449, 451, 451, 446, 454, 459, 460, 464, 464, 468, 468, 472, 472, 476, 476, 480, 480, 484, 484, 488, 489, 489, 490, 0, 490, 490, 491, 492, 496, 500, 501, 0, 501, 501, 502, 504, 504, 505, 0, 505, 505, 506, 509, 513, 514, 515, 519, 519, 520, 521, 0, 521, 521, 522, 524, 525, 525, 527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 31, 32, 33, 34, 35, 36, 37, 45, 46, 51, 52, 53, 55, 56, 63, 64, 69, 70, 71, 73, 74, 78, 79, 83, 84, 89, 90, 102, 105, 107, 108, 113, 114, 115, 116, 118, 119, 127, 128, 138, 139, 140, 141, 142, 145, 146, 148, 149, 155, 171, 176, 177, 180, 181, 182, 187, 188, 191, 195, 196, 198, 198, 201, 203, 204, 205, 207, 208, 215, 216, 241, 242, 247, 248, 249, 250, 255, 256, 260, 262, 263, 266, 267, 272, 273, 278, 279, 280, 281, 284, 286, 287, 288, 291, 292, 293, 298, 299, 300, 303, 304, 306, 307, 308, 309, 312, 313, 318, 319, 320, 333, 334, 336, 337, 340, 341, 343, 349, 352, 373, 374, 375, 376, 377, 382, 383, 385, 386, 389, 390, 395, 396, 399, 400, 401, 406, 407, 410, 411, 413, 414, 417, 418, 423, 424, 451, 452, 453, 454, 455, 460, 461, 463, 464, 467, 468, 473, 474, 475, 478, 479, 480, 485, 486, 487, 490, 491, 493, 494, 497, 498, 503, 504, 505, 541, 542, 543, 544, 545, 550, 551, 553, 554, 557, 558, 563, 564, 565, 568, 569, 570, 575, 576, 577, 580, 581, 583, 584, 585, 588, 593, 594, 595, 600, 601, 604, 605, 606, 611, 612, 615, 619, 620, 623, 624, 625, 626, 628, 634, 635, 638, 639, 644, 645, 646, 668, 669, 670, 671, 672, 675, 676, 681, 682, 683, 688, 689, 690, 691, 692, 693, 694, 695, 698, 699, 701, 707, 710, 711, 716, 717, 721, 722, 726, 727, 731, 732, 736, 737, 741, 742, 751, 752, 757, 758, 758, 761, 763, 764, 766, 774, 784, 785, 785, 788, 790, 791, 797, 802, 803, 803, 806, 808, 809, 816, 820, 821, 822, 832, 837, 838, 840, 840, 843, 845, 846, 854, 856, 857, 860, 867, 870, 874, 877, 881, 884, 888, 891, 895, 898, 902, 905, 909, 912};
/* BEGIN LINEINFO 
assign 1 222 26
new 0 222 26
new 1 222 27
assign 1 228 31
new 1 228 31
assign 1 229 32
assign 1 230 33
new 0 230 33
assign 1 231 34
new 0 231 34
assign 1 232 35
new 0 232 35
assign 1 233 36
new 0 233 36
assign 1 234 37
new 0 234 37
assign 1 240 45
new 0 240 45
assign 1 240 46
equals 1 240 51
assign 1 241 52
new 0 241 52
return 1 241 53
assign 1 243 55
new 0 243 55
return 1 243 56
assign 1 247 63
new 0 247 63
assign 1 247 64
equals 1 247 69
assign 1 248 70
new 0 248 70
return 1 248 71
assign 1 250 73
new 0 250 73
return 1 250 74
assign 1 254 78
toString 0 254 78
return 1 254 79
assign 1 258 83
new 1 258 83
new 1 258 84
assign 1 262 89
new 1 262 89
return 1 262 90
assign 1 266 102
arrayIteratorGet 0 266 102
assign 1 266 105
hasNextGet 0 266 105
assign 1 267 107
nextGet 0 267 107
assign 1 268 108
def 1 268 113
assign 1 269 114
keyGet 0 269 114
assign 1 269 115
innerPut 4 269 115
assign 1 269 116
not 0 269 116
assign 1 270 118
new 0 270 118
return 1 270 119
assign 1 274 127
new 0 274 127
return 1 274 128
assign 1 279 138
sizeGet 0 279 138
assign 1 279 139
multiply 1 279 139
assign 1 279 140
new 0 279 140
assign 1 279 141
add 1 279 141
assign 1 280 142
new 1 280 142
assign 1 281 145
insertAll 2 281 145
assign 1 281 146
not 0 281 146
assign 1 282 148
increment 0 282 148
assign 1 283 149
new 1 283 149
return 1 285 155
assign 1 289 171
undef 1 289 176
assign 1 0 177
assign 1 289 180
sizeGet 0 289 180
assign 1 289 181
sizeGet 0 289 181
assign 1 289 182
notEquals 1 289 187
assign 1 0 188
assign 1 0 191
assign 1 290 195
new 0 290 195
return 1 290 196
assign 1 292 198
setIteratorGet 0 0 198
assign 1 292 201
hasNextGet 0 292 201
assign 1 292 203
nextGet 0 292 203
assign 1 293 204
has 1 293 204
assign 1 293 205
not 0 293 205
assign 1 293 207
new 0 293 207
return 1 293 208
assign 1 295 215
new 0 295 215
return 1 295 216
assign 1 299 241
sizeGet 0 299 241
assign 1 300 242
undef 1 300 247
assign 1 301 248
getHash 1 301 248
assign 1 302 249
new 0 302 249
assign 1 302 250
lesser 1 302 255
assign 1 303 256
abs 0 303 256
assign 1 306 260
hvalGet 0 306 260
assign 1 308 262
modulus 1 308 262
assign 1 309 263
assign 1 311 266
get 1 311 266
assign 1 312 267
undef 1 312 272
assign 1 313 273
undef 1 313 278
assign 1 314 279
create 0 314 279
assign 1 314 280
new 3 314 280
put 2 314 281
put 2 316 284
assign 1 318 286
new 0 318 286
assign 1 319 287
new 0 319 287
return 1 319 288
assign 1 320 291
hvalGet 0 320 291
assign 1 320 292
modulus 1 320 292
assign 1 320 293
notEquals 1 320 298
assign 1 321 299
new 0 321 299
return 1 321 300
assign 1 322 303
keyGet 0 322 303
assign 1 322 304
isEqual 2 322 304
putTo 2 323 306
assign 1 325 307
new 0 325 307
assign 1 326 308
new 0 326 308
return 1 326 309
assign 1 328 312
increment 0 328 312
assign 1 329 313
greaterEquals 1 329 318
assign 1 330 319
new 0 330 319
return 1 330 320
assign 1 337 333
innerPut 4 337 333
assign 1 337 334
not 0 337 334
assign 1 338 336
assign 1 339 337
rehash 1 339 337
assign 1 340 340
innerPut 4 340 340
assign 1 340 341
not 0 340 341
assign 1 341 343
rehash 1 341 343
assign 1 343 349
assign 1 346 352
increment 0 346 352
assign 1 351 373
assign 1 352 374
sizeGet 0 352 374
assign 1 353 375
getHash 1 353 375
assign 1 354 376
new 0 354 376
assign 1 354 377
lesser 1 354 382
assign 1 355 383
abs 0 355 383
assign 1 357 385
modulus 1 357 385
assign 1 358 386
assign 1 360 389
get 1 360 389
assign 1 361 390
undef 1 361 395
return 1 362 396
assign 1 363 399
hvalGet 0 363 399
assign 1 363 400
modulus 1 363 400
assign 1 363 401
notEquals 1 363 406
return 1 364 407
assign 1 365 410
keyGet 0 365 410
assign 1 365 411
isEqual 2 365 411
assign 1 366 413
getFrom 0 366 413
return 1 366 414
assign 1 368 417
increment 0 368 417
assign 1 369 418
greaterEquals 1 369 423
return 1 370 424
assign 1 377 451
assign 1 378 452
sizeGet 0 378 452
assign 1 379 453
getHash 1 379 453
assign 1 380 454
new 0 380 454
assign 1 380 455
lesser 1 380 460
assign 1 381 461
abs 0 381 461
assign 1 383 463
modulus 1 383 463
assign 1 384 464
assign 1 386 467
get 1 386 467
assign 1 387 468
undef 1 387 473
assign 1 388 474
new 0 388 474
return 1 388 475
assign 1 389 478
hvalGet 0 389 478
assign 1 389 479
modulus 1 389 479
assign 1 389 480
notEquals 1 389 485
assign 1 390 486
new 0 390 486
return 1 390 487
assign 1 391 490
keyGet 0 391 490
assign 1 391 491
isEqual 2 391 491
assign 1 392 493
new 0 392 493
return 1 392 494
assign 1 394 497
increment 0 394 497
assign 1 395 498
greaterEquals 1 395 503
assign 1 396 504
new 0 396 504
return 1 396 505
assign 1 403 541
assign 1 404 542
sizeGet 0 404 542
assign 1 406 543
getHash 1 406 543
assign 1 407 544
new 0 407 544
assign 1 407 545
lesser 1 407 550
assign 1 408 551
abs 0 408 551
assign 1 410 553
modulus 1 410 553
assign 1 411 554
assign 1 413 557
get 1 413 557
assign 1 414 558
undef 1 414 563
assign 1 415 564
new 0 415 564
return 1 415 565
assign 1 416 568
hvalGet 0 416 568
assign 1 416 569
modulus 1 416 569
assign 1 416 570
notEquals 1 416 575
assign 1 417 576
new 0 417 576
return 1 417 577
assign 1 418 580
keyGet 0 418 580
assign 1 418 581
isEqual 2 418 581
put 2 419 583
assign 1 420 584
decrement 0 420 584
assign 1 421 585
increment 0 421 585
assign 1 422 588
lesser 1 422 593
assign 1 423 594
get 1 423 594
assign 1 424 595
undef 1 424 600
assign 1 0 601
assign 1 424 604
hvalGet 0 424 604
assign 1 424 605
modulus 1 424 605
assign 1 424 606
notEquals 1 424 611
assign 1 0 612
assign 1 0 615
assign 1 425 619
new 0 425 619
return 1 425 620
assign 1 427 623
new 0 427 623
assign 1 427 624
subtract 1 427 624
put 2 427 625
put 2 428 626
assign 1 430 628
increment 0 430 628
assign 1 432 634
new 0 432 634
return 1 432 635
assign 1 434 638
increment 0 434 638
assign 1 435 639
greaterEquals 1 435 644
assign 1 436 645
new 0 436 645
return 1 436 646
assign 1 443 668
create 0 443 668
copyTo 1 444 669
assign 1 445 670
copy 0 445 670
slotsSet 1 445 671
assign 1 446 672
new 0 446 672
assign 1 446 675
lengthGet 0 446 675
assign 1 446 676
lesser 1 446 681
assign 1 447 682
get 1 447 682
assign 1 448 683
def 1 448 688
assign 1 449 689
slotsGet 0 449 689
assign 1 449 690
create 0 449 690
assign 1 449 691
hvalGet 0 449 691
assign 1 449 692
keyGet 0 449 692
assign 1 449 693
getFrom 0 449 693
assign 1 449 694
new 3 449 694
put 2 449 695
assign 1 451 698
slotsGet 0 451 698
put 2 451 699
assign 1 446 701
increment 0 446 701
return 1 454 707
clear 0 459 710
assign 1 460 711
new 0 460 711
assign 1 464 716
new 1 464 716
return 1 464 717
assign 1 468 721
new 1 468 721
return 1 468 722
assign 1 472 726
new 1 472 726
return 1 472 727
assign 1 476 731
keyIteratorGet 0 476 731
return 1 476 732
assign 1 480 736
new 1 480 736
return 1 480 737
assign 1 484 741
nodeIteratorGet 0 484 741
return 1 484 742
assign 1 488 751
new 0 488 751
assign 1 489 752
def 1 489 757
assign 1 490 758
setIteratorGet 0 0 758
assign 1 490 761
hasNextGet 0 490 761
assign 1 490 763
nextGet 0 490 763
assign 1 491 764
has 1 491 764
put 1 492 766
return 1 496 774
assign 1 500 784
new 0 500 784
assign 1 501 785
setIteratorGet 0 0 785
assign 1 501 788
hasNextGet 0 501 788
assign 1 501 790
nextGet 0 501 790
put 1 502 791
assign 1 504 797
def 1 504 802
assign 1 505 803
setIteratorGet 0 0 803
assign 1 505 806
hasNextGet 0 505 806
assign 1 505 808
nextGet 0 505 808
put 1 506 809
return 1 509 816
assign 1 513 820
copy 0 513 820
addValue 1 514 821
return 1 515 822
assign 1 519 832
def 1 519 837
assign 1 520 838
sameType 1 520 838
assign 1 521 840
iteratorGet 0 0 840
assign 1 521 843
hasNextGet 0 521 843
assign 1 521 845
nextGet 0 521 845
put 1 522 846
assign 1 524 854
sameType 1 524 854
assign 1 525 856
keyGet 0 525 856
put 1 525 857
put 1 527 860
return 1 0 867
assign 1 0 870
return 1 0 874
assign 1 0 877
return 1 0 881
assign 1 0 884
return 1 0 888
assign 1 0 891
return 1 0 895
assign 1 0 898
return 1 0 902
assign 1 0 905
return 1 0 909
assign 1 0 912
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 712928736: return bem_innerPutAddedGet_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1586230380: return bem_moduGet_0();
case 1114073101: return bem_keysGet_0();
case 104713553: return bem_new_0();
case 2086347094: return bem_nodesGet_0();
case 287040793: return bem_hashGet_0();
case 2056412570: return bem_keyIteratorGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case 2142483603: return bem_notEmptyGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1431826729: return bem_nodeIteratorGet_0();
case 1820417453: return bem_create_0();
case 1227011022: return bem_multiGet_0();
case 578884498: return bem_relGet_0();
case 786424307: return bem_tagGet_0();
case 235611348: return bem_baseNodeGet_0();
case 499932279: return bem_setIteratorGet_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1575148127: return bem_moduSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 567802245: return bem_relSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 79841285: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 286659903: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 668984013: return bem_rehash_1((BEC_2_9_5_ContainerArray) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 131089957: return bem_insertAll_2((BEC_2_9_5_ContainerArray) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_5_ContainerArray) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_3_ContainerSet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_3_ContainerSet.bevs_inst = (BEC_2_9_3_ContainerSet)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_3_ContainerSet.bevs_inst;
}
}
}
