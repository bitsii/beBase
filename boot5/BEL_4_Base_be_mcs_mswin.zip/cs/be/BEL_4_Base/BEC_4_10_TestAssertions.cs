namespace be.BEL_4_Base {
/* IO:File: source/base/Test.be */
public class BEC_4_10_TestAssertions : BEC_6_6_SystemObject {
public BEC_4_10_TestAssertions() { }
static BEC_4_10_TestAssertions() { }
private static byte[] becc_clname = {0x54,0x65,0x73,0x74,0x3A,0x41,0x73,0x73,0x65,0x72,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bels_1 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bels_2 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bels_3 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73};
private static byte[] bels_4 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bels_5 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bels_6 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x2E};
private static byte[] bels_7 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bels_8 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bels_9 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 36));
private static byte[] bels_10 = {0x20};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_10, 1));
private static byte[] bels_11 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x55,0x4E,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74};
private static byte[] bels_12 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bels_13 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bels_14 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x4F,0x54,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bels_15 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x54,0x52,0x55,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bels_16 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x46,0x41,0x4C,0x53,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
public static new BEC_4_10_TestAssertions bevs_inst;
public override BEC_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_4_10_TestAssertions bem_default_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assertHas_2(BEC_6_6_SystemObject beva_v1, BEC_6_6_SystemObject beva_v2) {
BEC_4_6_TextString bevl_msg = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_7_TestFailure bevt_10_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_v1.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_v2);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 33 */ {
bevl_msg = (BEC_4_6_TextString) (new BEC_4_6_TextString(46, bels_0));
if (beva_v1 == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 35 */ {
if (beva_v2 == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 35 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 35 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 35 */
 else  /* Line: 35 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 35 */ {
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_1));
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevl_msg.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(beva_v1);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_2));
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_5_tmpvar_phold.bem_addValue_1(beva_v2);
} /* Line: 36 */
bevt_10_tmpvar_phold = (BEC_4_7_TestFailure) (new BEC_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BELS_Base.BECS_ThrowBack(bevt_10_tmpvar_phold);
} /* Line: 38 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assertNotHas_2(BEC_6_6_SystemObject beva_v1, BEC_6_6_SystemObject beva_v2) {
BEC_4_6_TextString bevl_msg = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_7_TestFailure bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_v1.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_v2);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 42 */ {
bevl_msg = (BEC_4_6_TextString) (new BEC_4_6_TextString(46, bels_3));
if (beva_v1 == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 44 */ {
if (beva_v2 == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 44 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 44 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 44 */
 else  /* Line: 44 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 44 */ {
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_4));
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevl_msg.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(beva_v1);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_5));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_4_tmpvar_phold.bem_addValue_1(beva_v2);
} /* Line: 45 */
bevt_9_tmpvar_phold = (BEC_4_7_TestFailure) (new BEC_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BELS_Base.BECS_ThrowBack(bevt_9_tmpvar_phold);
} /* Line: 47 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assertEquals_2(BEC_6_6_SystemObject beva_v1, BEC_6_6_SystemObject beva_v2) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_assertEqual_2(beva_v1, beva_v2);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assertNotEquals_2(BEC_6_6_SystemObject beva_v1, BEC_6_6_SystemObject beva_v2) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_assertNotEqual_2(beva_v1, beva_v2);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assertEqual_2(BEC_6_6_SystemObject beva_v1, BEC_6_6_SystemObject beva_v2) {
BEC_4_6_TextString bevl_v1v = null;
BEC_4_6_TextString bevl_v2v = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_7_TestFailure bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
if (beva_v1 == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(56, bels_6));
bevt_1_tmpvar_phold = (BEC_4_7_TestFailure) (new BEC_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 58 */
bevt_3_tmpvar_phold = beva_v1.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, beva_v2);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 60 */ {
if (beva_v1 == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 61 */ {
bevl_v1v = (BEC_4_6_TextString) beva_v1.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 62 */
 else  /* Line: 63 */ {
bevl_v1v = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_7));
} /* Line: 64 */
if (beva_v2 == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 66 */ {
bevl_v2v = (BEC_4_6_TextString) beva_v2.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 67 */
 else  /* Line: 68 */ {
bevl_v2v = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_8));
} /* Line: 69 */
bevt_10_tmpvar_phold = bevo_0;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevl_v1v);
bevt_11_tmpvar_phold = bevo_1;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevl_v2v);
bevt_6_tmpvar_phold = (BEC_4_7_TestFailure) (new BEC_4_7_TestFailure()).bem_new_1(bevt_7_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_6_tmpvar_phold);
} /* Line: 71 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assertNotEqual_2(BEC_6_6_SystemObject beva_v1, BEC_6_6_SystemObject beva_v2) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v1.bemd_1(581408689, BEL_4_Base.bevn_equals_1, beva_v2);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 75 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(36, bels_11));
bevt_1_tmpvar_phold = (BEC_4_7_TestFailure) (new BEC_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 76 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assertNull_1(BEC_6_6_SystemObject beva_v) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
if (beva_v == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 80 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_12));
bevt_1_tmpvar_phold = (BEC_4_7_TestFailure) (new BEC_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 81 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assertIsNull_1(BEC_6_6_SystemObject beva_v) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
if (beva_v == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 85 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_13));
bevt_1_tmpvar_phold = (BEC_4_7_TestFailure) (new BEC_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 86 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assertNotNull_1(BEC_6_6_SystemObject beva_v) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
if (beva_v == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 90 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(35, bels_14));
bevt_1_tmpvar_phold = (BEC_4_7_TestFailure) (new BEC_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 91 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assertTrue_1(BEC_6_6_SystemObject beva_v) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_7_TestFailure bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 95 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_15));
bevt_1_tmpvar_phold = (BEC_4_7_TestFailure) (new BEC_4_7_TestFailure()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 96 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assertFalse_1(BEC_6_6_SystemObject beva_v) {
BEC_4_7_TestFailure bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
if (beva_v != null && beva_v is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)beva_v).bevi_bool) /* Line: 100 */ {
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(32, bels_16));
bevt_0_tmpvar_phold = (BEC_4_7_TestFailure) (new BEC_4_7_TestFailure()).bem_new_1(bevt_1_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_0_tmpvar_phold);
} /* Line: 101 */
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {33, 33, 34, 35, 35, 35, 35, 0, 0, 0, 36, 36, 36, 36, 36, 36, 38, 38, 42, 43, 44, 44, 44, 44, 0, 0, 0, 45, 45, 45, 45, 45, 45, 47, 47, 51, 51, 54, 54, 57, 57, 58, 58, 58, 60, 61, 61, 62, 64, 66, 66, 67, 69, 71, 71, 71, 71, 71, 71, 71, 75, 76, 76, 76, 80, 80, 81, 81, 81, 85, 85, 86, 86, 86, 90, 90, 91, 91, 91, 95, 96, 96, 96, 101, 101, 101};
public static new int[] bevs_smnlec
 = new int[] {47, 48, 50, 51, 56, 57, 62, 63, 66, 70, 73, 74, 75, 76, 77, 78, 80, 81, 97, 99, 100, 105, 106, 111, 112, 115, 119, 122, 123, 124, 125, 126, 127, 129, 130, 136, 137, 141, 142, 159, 164, 165, 166, 167, 169, 171, 176, 177, 180, 182, 187, 188, 191, 193, 194, 195, 196, 197, 198, 199, 207, 209, 210, 211, 219, 224, 225, 226, 227, 235, 240, 241, 242, 243, 251, 256, 257, 258, 259, 267, 269, 270, 271, 279, 280, 281};
/* BEGIN LINEINFO 
assign 1 33 47
has 1 33 47
assign 1 33 48
not 0 33 48
assign 1 34 50
new 0 34 50
assign 1 35 51
def 1 35 56
assign 1 35 57
def 1 35 62
assign 1 0 63
assign 1 0 66
assign 1 0 70
assign 1 36 73
new 0 36 73
assign 1 36 74
addValue 1 36 74
assign 1 36 75
addValue 1 36 75
assign 1 36 76
new 0 36 76
assign 1 36 77
addValue 1 36 77
addValue 1 36 78
assign 1 38 80
new 1 38 80
throw 1 38 81
assign 1 42 97
has 1 42 97
assign 1 43 99
new 0 43 99
assign 1 44 100
def 1 44 105
assign 1 44 106
def 1 44 111
assign 1 0 112
assign 1 0 115
assign 1 0 119
assign 1 45 122
new 0 45 122
assign 1 45 123
addValue 1 45 123
assign 1 45 124
addValue 1 45 124
assign 1 45 125
new 0 45 125
assign 1 45 126
addValue 1 45 126
addValue 1 45 127
assign 1 47 129
new 1 47 129
throw 1 47 130
assign 1 51 136
assertEqual 2 51 136
return 1 51 137
assign 1 54 141
assertNotEqual 2 54 141
return 1 54 142
assign 1 57 159
undef 1 57 164
assign 1 58 165
new 0 58 165
assign 1 58 166
new 1 58 166
throw 1 58 167
assign 1 60 169
notEquals 1 60 169
assign 1 61 171
def 1 61 176
assign 1 62 177
toString 0 62 177
assign 1 64 180
new 0 64 180
assign 1 66 182
def 1 66 187
assign 1 67 188
toString 0 67 188
assign 1 69 191
new 0 69 191
assign 1 71 193
new 0 71 193
assign 1 71 194
add 1 71 194
assign 1 71 195
new 0 71 195
assign 1 71 196
add 1 71 196
assign 1 71 197
add 1 71 197
assign 1 71 198
new 1 71 198
throw 1 71 199
assign 1 75 207
equals 1 75 207
assign 1 76 209
new 0 76 209
assign 1 76 210
new 1 76 210
throw 1 76 211
assign 1 80 219
def 1 80 224
assign 1 81 225
new 0 81 225
assign 1 81 226
new 1 81 226
throw 1 81 227
assign 1 85 235
def 1 85 240
assign 1 86 241
new 0 86 241
assign 1 86 242
new 1 86 242
throw 1 86 243
assign 1 90 251
undef 1 90 256
assign 1 91 257
new 0 91 257
assign 1 91 258
new 1 91 258
throw 1 91 259
assign 1 95 267
not 0 95 267
assign 1 96 269
new 0 96 269
assign 1 96 270
new 1 96 270
throw 1 96 271
assign 1 101 279
new 0 101 279
assign 1 101 280
new 1 101 280
throw 1 101 281
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1397518831: return bem_assertFalse_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1801614214: return bem_assertNotNull_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 754733399: return bem_assertIsNull_1(bevd_0);
case 815800737: return bem_assertNull_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 646535002: return bem_assertTrue_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 187025688: return bem_assertEquals_2(bevd_0, bevd_1);
case 1160364576: return bem_assertNotHas_2(bevd_0, bevd_1);
case 1328041857: return bem_assertNotEquals_2(bevd_0, bevd_1);
case 975863745: return bem_assertEqual_2(bevd_0, bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 383195175: return bem_assertHas_2(bevd_0, bevd_1);
case 511348602: return bem_assertNotEqual_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_4_10_TestAssertions();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_4_10_TestAssertions.bevs_inst = (BEC_4_10_TestAssertions)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_4_10_TestAssertions.bevs_inst;
}
}
}
