namespace be.BEL_4_Base {
/* IO:File: source/build/Pass9.be */
public sealed class BEC_3_5_5_5_BuildVisitPass9 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass9() { }
static BEC_3_5_5_5_BuildVisitPass9() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x39};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x39,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x66,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x74,0x6F,0x6F,0x20,0x67,0x72,0x65,0x61,0x74,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 44));
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x53,0x45,0x54};
private static byte[] bels_3 = {0x47,0x45,0x54};
private static byte[] bels_4 = {0x53,0x45,0x54};
private static byte[] bels_5 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_6 = {0x70,0x75,0x74};
private static byte[] bels_7 = {0x67,0x65,0x74};
private static byte[] bels_8 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bels_9 = {0x69,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_11 = {0x68,0x61,0x73,0x4E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bels_12 = {0x6E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bels_13 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_14 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bels_15 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_16 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x66,0x6F,0x72,0x20,0x6C,0x6F,0x6F,0x70,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x74,0x77,0x6F,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64};
public static new BEC_3_5_5_5_BuildVisitPass9 bevs_inst;
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_lbrnode = null;
BEC_2_6_6_SystemObject bevl_loopif = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_6_6_SystemObject bevl_cond = null;
BEC_2_6_6_SystemObject bevl_atStep = null;
BEC_2_6_6_SystemObject bevl_estr = null;
BEC_2_6_6_SystemObject bevl_ac = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevl_ntarg = null;
BEC_2_6_6_SystemObject bevl_isPut = null;
BEC_2_5_4_BuildNode bevl_narg2 = null;
BEC_2_5_4_BuildNode bevl_narg3 = null;
BEC_2_6_6_SystemObject bevl_lin = null;
BEC_2_6_6_SystemObject bevl_lvar = null;
BEC_2_6_6_SystemObject bevl_toit = null;
BEC_2_6_6_SystemObject bevl_tmpn = null;
BEC_2_6_6_SystemObject bevl_tmpv = null;
BEC_2_6_6_SystemObject bevl_gin = null;
BEC_2_6_6_SystemObject bevl_gic = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_asc = null;
BEC_2_6_6_SystemObject bevl_tmpnt = null;
BEC_2_6_6_SystemObject bevl_tcn = null;
BEC_2_6_6_SystemObject bevl_tcc = null;
BEC_2_6_6_SystemObject bevl_tmpng = null;
BEC_2_6_6_SystemObject bevl_iagn = null;
BEC_2_6_6_SystemObject bevl_iagc = null;
BEC_2_6_6_SystemObject bevl_iasn = null;
BEC_2_6_6_SystemObject bevl_iasc = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_22_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_44_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_49_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_50_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_58_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_67_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_72_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_73_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_74_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_75_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_78_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_83_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_113_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_114_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_119_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_121_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_125_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_135_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_141_tmpvar_phold = null;
bevt_6_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_7_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_6_tmpvar_phold.bevi_int == bevt_7_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 34 */ {
beva_node.bem_initContained_0();
bevt_8_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_it = bevt_8_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 39 */ {
bevt_9_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 39 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_11_tmpvar_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 42 */ {
bevt_15_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(1696089045, BEL_4_Base.bevn_firstNodeGet_0);
if (bevt_14_tmpvar_phold == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 43 */ {
bevt_17_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_i.bemd_1(-1671186230, BEL_4_Base.bevn_beforeInsert_1, bevt_16_tmpvar_phold);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 45 */
 else  /* Line: 46 */ {
bevt_18_tmpvar_phold = bevo_0;
bevt_21_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_estr = bevt_18_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevl_estr, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_22_tmpvar_phold);
} /* Line: 48 */
} /* Line: 43 */
} /* Line: 42 */
 else  /* Line: 39 */ {
break;
} /* Line: 39 */
} /* Line: 39 */
bevt_23_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_23_tmpvar_phold;
} /* Line: 52 */
 else  /* Line: 34 */ {
bevt_25_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
if (bevt_25_tmpvar_phold.bevi_int == bevt_26_tmpvar_phold.bevi_int) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_27_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_c.bemd_1(-671626972, BEL_4_Base.bevn_wasAccessorSet_1, bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_typenameGet_0();
bevt_31_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_29_tmpvar_phold.bevi_int == bevt_31_tmpvar_phold.bevi_int) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_35_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bem_heldGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_1));
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_36_tmpvar_phold);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevt_37_tmpvar_phold = beva_node.bem_isFirstGet_0();
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevt_38_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_2));
bevl_c.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_38_tmpvar_phold);
} /* Line: 61 */
 else  /* Line: 62 */ {
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_3));
bevl_c.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_39_tmpvar_phold);
} /* Line: 63 */
bevt_40_tmpvar_phold = bevl_ac.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_40_tmpvar_phold);
bevl_c.bemd_0(-173192194, BEL_4_Base.bevn_toAccessorName_0);
bevt_42_tmpvar_phold = bevl_c.bemd_0(783669222, BEL_4_Base.bevn_accessorTypeGet_0);
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_4));
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_43_tmpvar_phold);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 67 */ {
bevt_44_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_44_tmpvar_phold.bem_heldSet_1(bevl_c);
bevt_45_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_45_tmpvar_phold.bem_firstGet_0();
bevt_46_tmpvar_phold = bevl_ntarg.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
beva_node.bem_typenameSet_1(bevt_46_tmpvar_phold);
bevt_47_tmpvar_phold = bevl_ntarg.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_47_tmpvar_phold);
bevt_48_tmpvar_phold = bevl_ntarg.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
beva_node.bem_containedSet_1(bevt_48_tmpvar_phold);
bevt_50_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_nextDescendGet_0();
return bevt_49_tmpvar_phold;
} /* Line: 74 */
 else  /* Line: 75 */ {
bevt_51_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_51_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 77 */
bevt_52_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_52_tmpvar_phold;
} /* Line: 79 */
 else  /* Line: 34 */ {
bevt_54_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpvar_phold = bevp_ntypes.bem_IDXACCGet_0();
if (bevt_54_tmpvar_phold.bevi_int == bevt_55_tmpvar_phold.bevi_int) {
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 80 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_58_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_typenameGet_0();
bevt_59_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_57_tmpvar_phold.bevi_int == bevt_59_tmpvar_phold.bevi_int) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 84 */ {
bevt_63_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_heldGet_0();
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_64_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_5));
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_64_tmpvar_phold);
if (bevt_60_tmpvar_phold != null && bevt_60_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_60_tmpvar_phold).bevi_bool) /* Line: 84 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
 else  /* Line: 84 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 84 */ {
bevt_65_tmpvar_phold = beva_node.bem_isFirstGet_0();
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 84 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
 else  /* Line: 84 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 84 */ {
bevl_isPut = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 86 */
 else  /* Line: 87 */ {
bevl_isPut = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 89 */
if (bevl_isPut != null && bevl_isPut is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_isPut).bevi_bool) /* Line: 91 */ {
bevt_66_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_6));
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_66_tmpvar_phold);
bevt_67_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_67_tmpvar_phold.bem_heldSet_1(bevl_c);
bevt_68_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_68_tmpvar_phold.bem_firstGet_0();
bevl_narg2 = (BEC_2_5_4_BuildNode) bevl_ntarg.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_narg3 = beva_node.bem_nextPeerGet_0();
bevl_narg2.bem_delete_0();
bevl_narg3.bem_delete_0();
bevt_69_tmpvar_phold = bevl_ntarg.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
beva_node.bem_typenameSet_1(bevt_69_tmpvar_phold);
bevt_70_tmpvar_phold = bevl_ntarg.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_70_tmpvar_phold);
bevt_71_tmpvar_phold = bevl_ntarg.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
beva_node.bem_containedSet_1(bevt_71_tmpvar_phold);
bevt_72_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_72_tmpvar_phold.bem_addValue_1(bevl_narg2);
bevt_73_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_73_tmpvar_phold.bem_addValue_1(bevl_narg3);
bevt_75_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bem_nextDescendGet_0();
return bevt_74_tmpvar_phold;
} /* Line: 109 */
 else  /* Line: 110 */ {
bevt_76_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_7));
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_77_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 117 */
bevt_78_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_78_tmpvar_phold;
} /* Line: 119 */
} /* Line: 34 */
} /* Line: 34 */
bevt_80_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_81_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
if (bevt_80_tmpvar_phold.bevi_int == bevt_81_tmpvar_phold.bevi_int) {
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_82_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
beva_node.bem_typenameSet_1(bevt_82_tmpvar_phold);
bevt_83_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_83_tmpvar_phold.bem_firstGet_0();
bevl_brnode = beva_node.bem_secondGet_0();
bevt_84_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_lin = bevt_84_tmpvar_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_85_tmpvar_phold = bevl_lin.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_lvar = bevt_85_tmpvar_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_toit = bevl_lin.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_pnode.bemd_1(443337441, BEL_4_Base.bevn_containedSet_1, null);
bevl_tmpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_86_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_8));
bevl_tmpv = beva_node.bem_tmpVar_2(bevt_87_tmpvar_phold, bevp_build);
bevl_tmpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_gin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_88_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_gin.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_88_tmpvar_phold);
bevl_gic = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_gin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gic);
bevt_89_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_9));
bevl_gic.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gic.bemd_1(666017654, BEL_4_Base.bevn_wasForeachGennedSet_1, bevt_90_tmpvar_phold);
bevl_gin.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_toit);
bevl_asn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_91_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_91_tmpvar_phold);
bevl_asc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_asn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_asc);
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_10));
bevl_asc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_92_tmpvar_phold);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpn);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_gin);
beva_node.bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevl_asn);
bevl_tmpn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_tmpnt = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_93_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpnt.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_93_tmpvar_phold);
bevl_tmpnt.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_tcn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tcn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_94_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_tcn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_94_tmpvar_phold);
bevl_tcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_tcn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tcc);
bevt_95_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_11));
bevl_tcc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_95_tmpvar_phold);
bevl_tcn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpnt);
bevl_pnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tcn);
bevl_tmpng = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpng.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_96_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpng.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_96_tmpvar_phold);
bevl_tmpng.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_iagn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iagn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_97_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iagn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_97_tmpvar_phold);
bevl_iagc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iagn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_iagc);
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_12));
bevl_iagc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_98_tmpvar_phold);
bevl_iagn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpng);
bevl_iasn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iasn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_99_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iasn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_99_tmpvar_phold);
bevl_iasc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iasn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_iasc);
bevt_100_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_13));
bevl_iasc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_100_tmpvar_phold);
bevl_iasn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lvar);
bevl_iasn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_iagn);
bevl_brnode.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_iasn);
return (BEC_2_5_4_BuildNode) bevl_toit;
} /* Line: 211 */
bevt_102_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_103_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
if (bevt_102_tmpvar_phold.bevi_int == bevt_103_tmpvar_phold.bevi_int) {
bevt_101_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_101_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_101_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_104_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_104_tmpvar_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_105_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_105_tmpvar_phold);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lbrnode);
bevl_loopif = beva_node;
bevt_106_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_106_tmpvar_phold);
bevl_lbrnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_loopif);
bevt_108_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_108_tmpvar_phold == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevt_110_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_111_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_14));
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_111_tmpvar_phold);
if (bevt_109_tmpvar_phold != null && bevt_109_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_109_tmpvar_phold).bevi_bool) /* Line: 225 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 225 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 225 */
 else  /* Line: 225 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 225 */ {
bevt_112_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_15));
bevl_loopif.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_112_tmpvar_phold);
} /* Line: 226 */
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_113_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_113_tmpvar_phold);
bevl_loopif.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_114_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_114_tmpvar_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_115_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_115_tmpvar_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_116_tmpvar_phold = bevl_lnode.bemd_0(-1779180144, BEL_4_Base.bevn_nextDescendGet_0);
return (BEC_2_5_4_BuildNode) bevt_116_tmpvar_phold;
} /* Line: 240 */
 else  /* Line: 213 */ {
bevt_118_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_119_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
if (bevt_118_tmpvar_phold.bevi_int == bevt_119_tmpvar_phold.bevi_int) {
bevt_117_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_117_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 241 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_120_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_120_tmpvar_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevt_121_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_121_tmpvar_phold.bem_firstGet_0();
bevl_pnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_124_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_125_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_125_tmpvar_phold);
if (bevt_122_tmpvar_phold != null && bevt_122_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_122_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevt_127_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bels_16));
bevt_126_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_127_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_126_tmpvar_phold);
} /* Line: 249 */
bevt_128_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_init = bevt_128_tmpvar_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_cond = bevl_pnode.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_atStep = null;
bevt_131_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_130_tmpvar_phold = bevt_131_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_132_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_129_tmpvar_phold = bevt_130_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_132_tmpvar_phold);
if (bevt_129_tmpvar_phold != null && bevt_129_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_129_tmpvar_phold).bevi_bool) /* Line: 254 */ {
bevl_atStep = bevl_pnode.bemd_0(-978128800, BEL_4_Base.bevn_thirdGet_0);
bevl_atStep.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 256 */
bevl_init.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevl_lnode.bemd_1(-1671186230, BEL_4_Base.bevn_beforeInsert_1, bevl_init);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_133_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_133_tmpvar_phold);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lbrnode);
bevl_loopif = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_loopif.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_134_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_134_tmpvar_phold);
bevl_loopif.bemd_1(875977779, BEL_4_Base.bevn_takeContents_1, beva_node);
if (bevl_atStep == null) {
bevt_135_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_135_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_135_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_137_tmpvar_phold = bevl_loopif.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_136_tmpvar_phold = bevt_137_tmpvar_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_136_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_atStep);
} /* Line: 272 */
bevl_loopif.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_pnode);
bevl_lbrnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_loopif);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_138_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_138_tmpvar_phold);
bevl_loopif.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_139_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_139_tmpvar_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_140_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_140_tmpvar_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
return (BEC_2_5_4_BuildNode) bevl_init;
} /* Line: 289 */
} /* Line: 213 */
bevt_141_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_141_tmpvar_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {34, 34, 34, 34, 38, 39, 39, 39, 41, 42, 42, 42, 43, 43, 43, 43, 44, 44, 44, 45, 47, 47, 47, 47, 47, 48, 48, 52, 52, 53, 53, 53, 53, 57, 58, 59, 59, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 0, 0, 0, 60, 0, 0, 0, 61, 61, 63, 63, 65, 65, 66, 67, 67, 67, 68, 68, 69, 69, 71, 71, 72, 72, 73, 73, 74, 74, 74, 76, 76, 77, 79, 79, 80, 80, 80, 80, 82, 83, 84, 84, 84, 84, 84, 84, 84, 84, 84, 84, 0, 0, 0, 84, 0, 0, 0, 86, 89, 92, 92, 93, 93, 94, 94, 97, 98, 100, 101, 103, 103, 104, 104, 105, 105, 107, 107, 108, 108, 109, 109, 109, 115, 115, 116, 116, 117, 119, 119, 121, 121, 121, 121, 122, 122, 123, 123, 124, 125, 125, 126, 126, 127, 128, 147, 148, 149, 149, 150, 150, 151, 153, 154, 154, 155, 156, 157, 157, 158, 158, 159, 161, 162, 163, 163, 164, 165, 166, 166, 167, 168, 170, 171, 173, 174, 175, 175, 176, 178, 179, 180, 180, 181, 182, 183, 183, 184, 186, 188, 189, 190, 190, 191, 193, 194, 195, 195, 196, 197, 198, 198, 199, 201, 202, 203, 203, 204, 205, 206, 206, 207, 208, 210, 211, 213, 213, 213, 213, 214, 215, 216, 216, 217, 218, 219, 220, 220, 221, 222, 223, 223, 224, 225, 225, 225, 225, 225, 225, 0, 0, 0, 226, 226, 228, 229, 230, 230, 231, 232, 233, 234, 234, 235, 236, 237, 238, 238, 239, 240, 240, 241, 241, 241, 241, 242, 243, 244, 244, 245, 246, 246, 247, 248, 248, 248, 248, 249, 249, 249, 251, 251, 252, 253, 254, 254, 254, 254, 255, 256, 258, 260, 261, 263, 264, 265, 265, 266, 267, 268, 269, 269, 270, 271, 271, 272, 272, 272, 274, 275, 276, 277, 278, 278, 279, 280, 281, 282, 282, 283, 284, 285, 286, 286, 287, 289, 291, 291};
public static new int[] bevs_smnlec
 = new int[] {207, 208, 209, 214, 215, 216, 217, 220, 222, 223, 224, 225, 227, 228, 229, 234, 235, 236, 237, 238, 241, 242, 243, 244, 245, 246, 247, 255, 256, 259, 260, 261, 266, 267, 268, 269, 270, 271, 272, 273, 274, 279, 280, 281, 282, 283, 284, 286, 289, 293, 296, 298, 301, 305, 308, 309, 312, 313, 315, 316, 317, 318, 319, 320, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 337, 338, 339, 341, 342, 345, 346, 347, 352, 353, 354, 355, 356, 357, 358, 363, 364, 365, 366, 367, 368, 370, 373, 377, 380, 382, 385, 389, 392, 395, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 423, 424, 425, 426, 427, 429, 430, 434, 435, 436, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 524, 525, 526, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 552, 553, 554, 555, 557, 560, 564, 567, 568, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 589, 590, 591, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 610, 611, 612, 614, 615, 616, 617, 618, 619, 620, 621, 623, 624, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 644, 645, 646, 647, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 669, 670};
/* BEGIN LINEINFO 
assign 1 34 207
typenameGet 0 34 207
assign 1 34 208
CALLGet 0 34 208
assign 1 34 209
equals 1 34 214
initContained 0 38 215
assign 1 39 216
containedGet 0 39 216
assign 1 39 217
iteratorGet 0 39 217
assign 1 39 220
hasNextGet 0 39 220
assign 1 41 222
nextGet 0 41 222
assign 1 42 223
typenameGet 0 42 223
assign 1 42 224
PARENSGet 0 42 224
assign 1 42 225
equals 1 42 225
assign 1 43 227
containedGet 0 43 227
assign 1 43 228
firstNodeGet 0 43 228
assign 1 43 229
def 1 43 234
assign 1 44 235
containedGet 0 44 235
assign 1 44 236
firstGet 0 44 236
beforeInsert 1 44 237
delete 0 45 238
assign 1 47 241
new 0 47 241
assign 1 47 242
containedGet 0 47 242
assign 1 47 243
lengthGet 0 47 243
assign 1 47 244
toString 0 47 244
assign 1 47 245
add 1 47 245
assign 1 48 246
new 2 48 246
throw 1 48 247
assign 1 52 255
nextDescendGet 0 52 255
return 1 52 256
assign 1 53 259
typenameGet 0 53 259
assign 1 53 260
ACCESSORGet 0 53 260
assign 1 53 261
equals 1 53 266
assign 1 57 267
heldGet 0 57 267
assign 1 58 268
new 0 58 268
assign 1 59 269
new 0 59 269
wasAccessorSet 1 59 270
assign 1 60 271
containerGet 0 60 271
assign 1 60 272
typenameGet 0 60 272
assign 1 60 273
CALLGet 0 60 273
assign 1 60 274
equals 1 60 279
assign 1 60 280
containerGet 0 60 280
assign 1 60 281
heldGet 0 60 281
assign 1 60 282
nameGet 0 60 282
assign 1 60 283
new 0 60 283
assign 1 60 284
equals 1 60 284
assign 1 0 286
assign 1 0 289
assign 1 0 293
assign 1 60 296
isFirstGet 0 60 296
assign 1 0 298
assign 1 0 301
assign 1 0 305
assign 1 61 308
new 0 61 308
accessorTypeSet 1 61 309
assign 1 63 312
new 0 63 312
accessorTypeSet 1 63 313
assign 1 65 315
nameGet 0 65 315
nameSet 1 65 316
toAccessorName 0 66 317
assign 1 67 318
accessorTypeGet 0 67 318
assign 1 67 319
new 0 67 319
assign 1 67 320
equals 1 67 320
assign 1 68 322
containerGet 0 68 322
heldSet 1 68 323
assign 1 69 324
containedGet 0 69 324
assign 1 69 325
firstGet 0 69 325
assign 1 71 326
typenameGet 0 71 326
typenameSet 1 71 327
assign 1 72 328
heldGet 0 72 328
heldSet 1 72 329
assign 1 73 330
containedGet 0 73 330
containedSet 1 73 331
assign 1 74 332
containerGet 0 74 332
assign 1 74 333
nextDescendGet 0 74 333
return 1 74 334
assign 1 76 337
CALLGet 0 76 337
typenameSet 1 76 338
heldSet 1 77 339
assign 1 79 341
nextDescendGet 0 79 341
return 1 79 342
assign 1 80 345
typenameGet 0 80 345
assign 1 80 346
IDXACCGet 0 80 346
assign 1 80 347
equals 1 80 352
assign 1 82 353
heldGet 0 82 353
assign 1 83 354
new 0 83 354
assign 1 84 355
containerGet 0 84 355
assign 1 84 356
typenameGet 0 84 356
assign 1 84 357
CALLGet 0 84 357
assign 1 84 358
equals 1 84 363
assign 1 84 364
containerGet 0 84 364
assign 1 84 365
heldGet 0 84 365
assign 1 84 366
nameGet 0 84 366
assign 1 84 367
new 0 84 367
assign 1 84 368
equals 1 84 368
assign 1 0 370
assign 1 0 373
assign 1 0 377
assign 1 84 380
isFirstGet 0 84 380
assign 1 0 382
assign 1 0 385
assign 1 0 389
assign 1 86 392
new 0 86 392
assign 1 89 395
new 0 89 395
assign 1 92 398
new 0 92 398
nameSet 1 92 399
assign 1 93 400
containerGet 0 93 400
heldSet 1 93 401
assign 1 94 402
containedGet 0 94 402
assign 1 94 403
firstGet 0 94 403
assign 1 97 404
nextPeerGet 0 97 404
assign 1 98 405
nextPeerGet 0 98 405
delete 0 100 406
delete 0 101 407
assign 1 103 408
typenameGet 0 103 408
typenameSet 1 103 409
assign 1 104 410
heldGet 0 104 410
heldSet 1 104 411
assign 1 105 412
containedGet 0 105 412
containedSet 1 105 413
assign 1 107 414
containerGet 0 107 414
addValue 1 107 415
assign 1 108 416
containerGet 0 108 416
addValue 1 108 417
assign 1 109 418
containerGet 0 109 418
assign 1 109 419
nextDescendGet 0 109 419
return 1 109 420
assign 1 115 423
new 0 115 423
nameSet 1 115 424
assign 1 116 425
CALLGet 0 116 425
typenameSet 1 116 426
heldSet 1 117 427
assign 1 119 429
nextDescendGet 0 119 429
return 1 119 430
assign 1 121 434
typenameGet 0 121 434
assign 1 121 435
FOREACHGet 0 121 435
assign 1 121 436
equals 1 121 441
assign 1 122 442
WHILEGet 0 122 442
typenameSet 1 122 443
assign 1 123 444
containedGet 0 123 444
assign 1 123 445
firstGet 0 123 445
assign 1 124 446
secondGet 0 124 446
assign 1 125 447
containedGet 0 125 447
assign 1 125 448
firstGet 0 125 448
assign 1 126 449
containedGet 0 126 449
assign 1 126 450
firstGet 0 126 450
assign 1 127 451
secondGet 0 127 451
containedSet 1 128 452
assign 1 147 453
new 1 147 453
copyLoc 1 148 454
assign 1 149 455
VARGet 0 149 455
typenameSet 1 149 456
assign 1 150 457
new 0 150 457
assign 1 150 458
tmpVar 2 150 458
heldSet 1 151 459
assign 1 153 460
new 1 153 460
assign 1 154 461
CALLGet 0 154 461
typenameSet 1 154 462
assign 1 155 463
new 0 155 463
heldSet 1 156 464
assign 1 157 465
new 0 157 465
nameSet 1 157 466
assign 1 158 467
new 0 158 467
wasForeachGennedSet 1 158 468
addValue 1 159 469
assign 1 161 470
new 1 161 470
copyLoc 1 162 471
assign 1 163 472
CALLGet 0 163 472
typenameSet 1 163 473
assign 1 164 474
new 0 164 474
heldSet 1 165 475
assign 1 166 476
new 0 166 476
nameSet 1 166 477
addValue 1 167 478
addValue 1 168 479
beforeInsert 1 170 480
addVariable 0 171 481
assign 1 173 482
new 1 173 482
copyLoc 1 174 483
assign 1 175 484
VARGet 0 175 484
typenameSet 1 175 485
heldSet 1 176 486
assign 1 178 487
new 1 178 487
copyLoc 1 179 488
assign 1 180 489
CALLGet 0 180 489
typenameSet 1 180 490
assign 1 181 491
new 0 181 491
heldSet 1 182 492
assign 1 183 493
new 0 183 493
nameSet 1 183 494
addValue 1 184 495
addValue 1 186 496
assign 1 188 497
new 1 188 497
copyLoc 1 189 498
assign 1 190 499
VARGet 0 190 499
typenameSet 1 190 500
heldSet 1 191 501
assign 1 193 502
new 1 193 502
copyLoc 1 194 503
assign 1 195 504
CALLGet 0 195 504
typenameSet 1 195 505
assign 1 196 506
new 0 196 506
heldSet 1 197 507
assign 1 198 508
new 0 198 508
nameSet 1 198 509
addValue 1 199 510
assign 1 201 511
new 1 201 511
copyLoc 1 202 512
assign 1 203 513
CALLGet 0 203 513
typenameSet 1 203 514
assign 1 204 515
new 0 204 515
heldSet 1 205 516
assign 1 206 517
new 0 206 517
nameSet 1 206 518
addValue 1 207 519
addValue 1 208 520
prepend 1 210 521
return 1 211 522
assign 1 213 524
typenameGet 0 213 524
assign 1 213 525
WHILEGet 0 213 525
assign 1 213 526
equals 1 213 531
assign 1 214 532
new 1 214 532
copyLoc 1 215 533
assign 1 216 534
LOOPGet 0 216 534
typenameSet 1 216 535
replaceWith 1 217 536
assign 1 218 537
new 1 218 537
copyLoc 1 219 538
assign 1 220 539
BRACESGet 0 220 539
typenameSet 1 220 540
addValue 1 221 541
assign 1 222 542
assign 1 223 543
IFGet 0 223 543
typenameSet 1 223 544
addValue 1 224 545
assign 1 225 546
heldGet 0 225 546
assign 1 225 547
def 1 225 552
assign 1 225 553
heldGet 0 225 553
assign 1 225 554
new 0 225 554
assign 1 225 555
equals 1 225 555
assign 1 0 557
assign 1 0 560
assign 1 0 564
assign 1 226 567
new 0 226 567
heldSet 1 226 568
assign 1 228 570
new 1 228 570
copyLoc 1 229 571
assign 1 230 572
ELSEGet 0 230 572
typenameSet 1 230 573
addValue 1 231 574
assign 1 232 575
new 1 232 575
copyLoc 1 233 576
assign 1 234 577
BRACESGet 0 234 577
typenameSet 1 234 578
addValue 1 235 579
assign 1 236 580
new 1 236 580
copyLoc 1 237 581
assign 1 238 582
BREAKGet 0 238 582
typenameSet 1 238 583
addValue 1 239 584
assign 1 240 585
nextDescendGet 0 240 585
return 1 240 586
assign 1 241 589
typenameGet 0 241 589
assign 1 241 590
FORGet 0 241 590
assign 1 241 591
equals 1 241 596
assign 1 242 597
new 1 242 597
copyLoc 1 243 598
assign 1 244 599
LOOPGet 0 244 599
typenameSet 1 244 600
replaceWith 1 245 601
assign 1 246 602
containedGet 0 246 602
assign 1 246 603
firstGet 0 246 603
delete 0 247 604
assign 1 248 605
containedGet 0 248 605
assign 1 248 606
lengthGet 0 248 606
assign 1 248 607
new 0 248 607
assign 1 248 608
lesser 1 248 608
assign 1 249 610
new 0 249 610
assign 1 249 611
new 2 249 611
throw 1 249 612
assign 1 251 614
containedGet 0 251 614
assign 1 251 615
firstGet 0 251 615
assign 1 252 616
secondGet 0 252 616
assign 1 253 617
assign 1 254 618
containedGet 0 254 618
assign 1 254 619
lengthGet 0 254 619
assign 1 254 620
new 0 254 620
assign 1 254 621
greater 1 254 621
assign 1 255 623
thirdGet 0 255 623
delete 0 256 624
delete 0 258 626
replaceWith 1 260 627
beforeInsert 1 261 628
assign 1 263 629
new 1 263 629
copyLoc 1 264 630
assign 1 265 631
BRACESGet 0 265 631
typenameSet 1 265 632
addValue 1 266 633
assign 1 267 634
new 1 267 634
copyLoc 1 268 635
assign 1 269 636
IFGet 0 269 636
typenameSet 1 269 637
takeContents 1 270 638
assign 1 271 639
def 1 271 644
assign 1 272 645
containedGet 0 272 645
assign 1 272 646
firstGet 0 272 646
addValue 1 272 647
prepend 1 274 649
addValue 1 275 650
assign 1 276 651
new 1 276 651
copyLoc 1 277 652
assign 1 278 653
ELSEGet 0 278 653
typenameSet 1 278 654
addValue 1 279 655
assign 1 280 656
new 1 280 656
copyLoc 1 281 657
assign 1 282 658
BRACESGet 0 282 658
typenameSet 1 282 659
addValue 1 283 660
assign 1 284 661
new 1 284 661
copyLoc 1 285 662
assign 1 286 663
BREAKGet 0 286 663
typenameSet 1 286 664
addValue 1 287 665
return 1 289 666
assign 1 291 669
nextDescendGet 0 291 669
return 1 291 670
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass9();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass9.bevs_inst = (BEC_3_5_5_5_BuildVisitPass9)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass9.bevs_inst;
}
}
}
