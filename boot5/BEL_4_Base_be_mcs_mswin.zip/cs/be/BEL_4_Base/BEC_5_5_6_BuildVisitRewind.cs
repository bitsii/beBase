namespace be.BEL_4_Base {
/* IO:File: source/build/Pass12.be */
public class BEC_5_5_6_BuildVisitRewind : BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_6_BuildVisitRewind() { }
static BEC_5_5_6_BuildVisitRewind() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_1, 11));
private static byte[] bels_2 = {0x5F,0x30};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 2));
private static byte[] bels_3 = {0x5F,0x30};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_3, 2));
private static byte[] bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_6 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_6, 27));
private static byte[] bels_7 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_8 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_4_6_TextString bevo_6 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_8, 13));
private static byte[] bels_9 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 10));
private static byte[] bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_5_5_6_BuildVisitRewind bevs_inst;
public BEC_6_6_SystemObject bevp_tvmap;
public BEC_6_6_SystemObject bevp_rmap;
public BEC_6_6_SystemObject bevp_inClass;
public BEC_6_6_SystemObject bevp_inClassNp;
public BEC_6_6_SystemObject bevp_inClassSyn;
public BEC_6_6_SystemObject bevp_nl;
public BEC_6_6_SystemObject bevp_emitter;
public override BEC_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) {
BEC_5_8_BuildNamePath bevl_fgnp = null;
BEC_4_6_TextString bevl_fgcn = null;
BEC_4_6_TextString bevl_fgin = null;
BEC_5_8_BuildClassSyn bevl_fgsy = null;
BEC_5_6_BuildMtdSyn bevl_fgms = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_34_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_79_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_80_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_83_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_84_tmpvar_phold = null;
BEC_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_86_tmpvar_phold = null;
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_12_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(654935401, BEL_4_Base.bevn_wasForeachGennedGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 247 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 247 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 247 */
 else  /* Line: 247 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 247 */ {
bevt_15_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_typenameGet_0();
bevt_16_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 249 */ {
bevt_20_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_0));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 249 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 249 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 249 */
 else  /* Line: 249 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 249 */ {
bevt_22_tmpvar_phold = beva_node.bem_isSecondGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 249 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 249 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 249 */
 else  /* Line: 249 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 249 */ {
bevt_26_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_firstGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_27_tmpvar_phold);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 251 */ {
bevt_31_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_firstGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 251 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 251 */ {
bevt_34_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_firstGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_fgnp = (BEC_5_8_BuildNamePath) bevt_32_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpvar_phold = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_4_6_TextString) bevt_35_tmpvar_phold.bem_lastGet_0();
bevt_39_tmpvar_phold = bevo_0;
bevt_40_tmpvar_phold = bevo_1;
bevt_38_tmpvar_phold = bevl_fgcn.bem_substring_2(bevt_39_tmpvar_phold, bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) bevt_38_tmpvar_phold.bem_lowerValue_0();
bevt_42_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_41_tmpvar_phold = bevl_fgcn.bem_substring_1(bevt_42_tmpvar_phold);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_add_1(bevt_41_tmpvar_phold);
bevt_43_tmpvar_phold = bevo_2;
bevl_fgin = bevt_36_tmpvar_phold.bem_add_1(bevt_43_tmpvar_phold);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_tmpvar_phold = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_tmpvar_phold = bevo_3;
bevt_45_tmpvar_phold = bevl_fgin.bem_add_1(bevt_46_tmpvar_phold);
bevl_fgms = (BEC_5_6_BuildMtdSyn) bevt_44_tmpvar_phold.bem_get_1(bevt_45_tmpvar_phold);
if (bevl_fgms == null) {
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 258 */ {
bevt_48_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_48_tmpvar_phold.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_fgin);
bevt_49_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_51_tmpvar_phold = bevo_4;
bevt_50_tmpvar_phold = bevl_fgin.bem_add_1(bevt_51_tmpvar_phold);
bevt_49_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_50_tmpvar_phold);
} /* Line: 261 */
} /* Line: 258 */
} /* Line: 251 */
} /* Line: 249 */
bevt_53_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_54_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_equals_1(bevt_54_tmpvar_phold);
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevp_inClass = beva_node;
bevt_55_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_56_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 269 */
bevt_58_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_59_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_equals_1(bevt_59_tmpvar_phold);
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevp_tvmap = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_9_3_ContainerMap()).bem_new_0();
} /* Line: 273 */
 else  /* Line: 271 */ {
bevt_61_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_62_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_equals_1(bevt_62_tmpvar_phold);
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 274 */ {
bevt_64_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 274 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 274 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 274 */
 else  /* Line: 274 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 274 */ {
bevt_66_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_67_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_65_tmpvar_phold, bevt_67_tmpvar_phold);
bevt_69_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_68_tmpvar_phold);
if (bevl_ll == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevl_ll = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_rmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_71_tmpvar_phold, bevl_ll);
} /* Line: 279 */
bevl_ll.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
} /* Line: 281 */
 else  /* Line: 271 */ {
bevt_74_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_75_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bem_equals_1(bevt_75_tmpvar_phold);
if (bevt_73_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_77_tmpvar_phold = beva_node.bem_containerGet_0();
if (bevt_77_tmpvar_phold == null) {
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
 else  /* Line: 282 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 282 */ {
bevt_80_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_containerGet_0();
if (bevt_79_tmpvar_phold == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
 else  /* Line: 282 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 282 */ {
bevt_84_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_containerGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_typenameGet_0();
bevt_85_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bem_equals_1(bevt_85_tmpvar_phold);
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
 else  /* Line: 282 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 282 */ {
this.bem_processTmps_0();
} /* Line: 284 */
} /* Line: 271 */
} /* Line: 271 */
bevt_86_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_86_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_processTmps_0() {
BEC_6_6_SystemObject bevl_foundone = null;
BEC_6_6_SystemObject bevl_targ = null;
BEC_6_6_SystemObject bevl_tvar = null;
BEC_6_6_SystemObject bevl_tcall = null;
BEC_5_8_BuildClassSyn bevl_syn = null;
BEC_6_6_SystemObject bevl_targNp = null;
BEC_6_6_SystemObject bevl_mtdc = null;
BEC_6_6_SystemObject bevl_ovar = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_nv = null;
BEC_6_6_SystemObject bevl_nvname = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_6_6_SystemObject bevl_k = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_90_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_91_tmpvar_phold = null;
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
while (true)
 /* Line: 298 */ {
if (bevl_foundone != null && bevl_foundone is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevl_foundone).bevi_bool) /* Line: 298 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(2145224760, BEL_4_Base.bevn_valueIteratorGet_0);
while (true)
 /* Line: 300 */ {
bevt_8_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 300 */ {
bevl_nv = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_nv.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 303 */ {
bevl_nvname = bevl_nv.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_nvname);
bevt_0_tmpvar_loop = bevl_ll.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 308 */ {
bevt_11_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 308 */ {
bevl_k = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_15_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_16_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 309 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 309 */
 else  /* Line: 309 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 309 */ {
bevt_20_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_4));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 309 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 309 */
 else  /* Line: 309 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 309 */ {
bevt_25_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_26_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_26_tmpvar_phold);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 309 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 309 */
 else  /* Line: 309 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 309 */ {
bevt_27_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevl_tcall = bevt_27_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targNp = null;
bevt_30_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_29_tmpvar_phold == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_31_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_targNp = bevt_31_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
} /* Line: 314 */
 else  /* Line: 315 */ {
bevt_32_tmpvar_phold = bevl_tcall.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_targ = bevt_32_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_34_tmpvar_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 320 */ {
bevl_tvar = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 321 */
 else  /* Line: 322 */ {
bevt_36_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_38_tmpvar_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_37_tmpvar_phold);
bevl_tvar = bevt_35_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 323 */
bevt_39_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 326 */ {
bevl_targNp = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 327 */
} /* Line: 326 */
if (bevl_targNp == null) {
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 330 */ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_41_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_43_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_41_tmpvar_phold.bem_get_1(bevt_42_tmpvar_phold);
if (bevl_mtdc == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 334 */ {
bevl_ovar = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevl_ovar == null) {
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 337 */ {
bevt_46_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 337 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 337 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 337 */
 else  /* Line: 337 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 337 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_47_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 340 */ {
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_targNp);
} /* Line: 341 */
 else  /* Line: 342 */ {
bevt_48_tmpvar_phold = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_48_tmpvar_phold);
} /* Line: 343 */
bevt_49_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_49_tmpvar_phold);
bevt_50_tmpvar_phold = bevp_inClass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_50_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_51_tmpvar_phold);
bevt_54_tmpvar_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_55_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_5));
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_55_tmpvar_phold);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 347 */ {
bevt_57_tmpvar_phold = bevo_5;
bevt_58_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 347 */
} /* Line: 347 */
} /* Line: 337 */
 else  /* Line: 334 */ {
bevt_61_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_62_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_7));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_62_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 349 */ {
bevt_67_tmpvar_phold = bevo_6;
bevt_69_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevt_68_tmpvar_phold);
bevt_70_tmpvar_phold = bevo_7;
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bem_add_1(bevt_70_tmpvar_phold);
bevt_71_tmpvar_phold = bevl_targNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bem_add_1(bevt_71_tmpvar_phold);
bevt_63_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_64_tmpvar_phold, bevl_tcall);
throw new be.BELS_Base.BECS_ThrowBack(bevt_63_tmpvar_phold);
} /* Line: 350 */
} /* Line: 334 */
} /* Line: 334 */
} /* Line: 330 */
 else  /* Line: 309 */ {
bevt_72_tmpvar_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_72_tmpvar_phold != null && bevt_72_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_72_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_75_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 355 */
 else  /* Line: 355 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 355 */ {
bevt_80_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_78_tmpvar_phold = bevt_79_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_81_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_10));
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpvar_phold);
if (bevt_77_tmpvar_phold != null && bevt_77_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_77_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 355 */
 else  /* Line: 355 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 355 */ {
bevt_85_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_84_tmpvar_phold = bevt_85_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_86_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_86_tmpvar_phold);
if (bevt_82_tmpvar_phold != null && bevt_82_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_82_tmpvar_phold).bevi_bool) /* Line: 355 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 355 */
 else  /* Line: 355 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 355 */ {
bevt_88_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targ = bevt_87_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_89_tmpvar_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_89_tmpvar_phold != null && bevt_89_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_89_tmpvar_phold).bevi_bool) /* Line: 358 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_90_tmpvar_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = bevl_targ.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_91_tmpvar_phold);
} /* Line: 363 */
} /* Line: 358 */
} /* Line: 309 */
} /* Line: 309 */
 else  /* Line: 308 */ {
break;
} /* Line: 308 */
} /* Line: 308 */
} /* Line: 308 */
} /* Line: 303 */
 else  /* Line: 300 */ {
break;
} /* Line: 300 */
} /* Line: 300 */
} /* Line: 300 */
 else  /* Line: 298 */ {
break;
} /* Line: 298 */
} /* Line: 298 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_tvmapGet_0() {
return bevp_tvmap;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_tvmapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_tvmap = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_rmapGet_0() {
return bevp_rmap;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_rmapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rmap = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClass = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassNp = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassSynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassSyn = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {247, 247, 247, 247, 247, 0, 0, 0, 249, 249, 249, 249, 249, 249, 249, 249, 249, 0, 0, 0, 249, 0, 0, 0, 251, 251, 251, 251, 251, 251, 251, 251, 251, 0, 0, 0, 252, 252, 252, 252, 253, 253, 254, 254, 254, 254, 254, 254, 254, 254, 254, 256, 257, 257, 257, 257, 258, 258, 260, 260, 261, 261, 261, 261, 266, 266, 266, 267, 268, 268, 269, 269, 271, 271, 271, 272, 273, 274, 274, 274, 274, 274, 0, 0, 0, 275, 275, 275, 275, 276, 276, 276, 277, 277, 278, 279, 279, 279, 281, 282, 282, 282, 282, 282, 282, 0, 0, 0, 282, 282, 282, 282, 0, 0, 0, 282, 282, 282, 282, 282, 0, 0, 0, 284, 286, 286, 290, 299, 300, 300, 301, 303, 303, 306, 307, 308, 0, 308, 308, 309, 309, 309, 309, 309, 0, 0, 0, 309, 309, 309, 309, 309, 0, 0, 0, 309, 309, 309, 309, 309, 0, 0, 0, 311, 311, 312, 313, 313, 313, 313, 314, 314, 316, 316, 320, 320, 321, 323, 323, 323, 323, 323, 326, 327, 330, 330, 332, 333, 333, 333, 333, 334, 334, 336, 337, 337, 337, 0, 0, 0, 338, 340, 341, 343, 343, 345, 345, 346, 346, 346, 347, 347, 347, 347, 347, 347, 347, 347, 349, 349, 349, 349, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 355, 355, 355, 355, 355, 0, 0, 0, 355, 355, 355, 355, 355, 0, 0, 0, 355, 355, 355, 355, 355, 0, 0, 0, 356, 356, 356, 358, 360, 362, 362, 363, 363, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {132, 133, 134, 136, 137, 139, 142, 146, 149, 150, 151, 152, 154, 155, 156, 157, 158, 160, 163, 167, 170, 172, 175, 179, 182, 183, 184, 185, 186, 188, 189, 190, 191, 193, 196, 200, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 228, 229, 230, 231, 232, 233, 234, 239, 240, 241, 243, 244, 245, 246, 247, 249, 250, 251, 253, 254, 257, 258, 259, 261, 262, 264, 267, 271, 274, 275, 276, 277, 278, 279, 280, 281, 286, 287, 288, 289, 290, 292, 295, 296, 297, 299, 300, 305, 306, 309, 313, 316, 317, 318, 323, 324, 327, 331, 334, 335, 336, 337, 338, 340, 343, 347, 350, 354, 355, 463, 467, 468, 471, 473, 474, 475, 477, 478, 479, 479, 482, 484, 485, 487, 488, 489, 490, 492, 495, 499, 502, 503, 504, 505, 506, 508, 511, 515, 518, 519, 520, 521, 522, 524, 527, 531, 534, 535, 536, 537, 538, 539, 544, 545, 546, 549, 550, 551, 552, 554, 557, 558, 559, 560, 561, 563, 565, 568, 573, 574, 575, 576, 577, 578, 579, 584, 585, 586, 591, 592, 594, 597, 601, 604, 605, 607, 610, 611, 613, 614, 615, 616, 617, 618, 619, 620, 621, 623, 624, 625, 626, 631, 632, 633, 634, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 651, 653, 654, 655, 656, 658, 661, 665, 668, 669, 670, 671, 672, 674, 677, 681, 684, 685, 686, 687, 688, 690, 693, 697, 700, 701, 702, 703, 705, 706, 707, 708, 709, 732, 735, 739, 742, 746, 749, 753, 756, 760, 763, 767, 770, 774, 777};
/* BEGIN LINEINFO 
assign 1 247 132
typenameGet 0 247 132
assign 1 247 133
CALLGet 0 247 133
assign 1 247 134
equals 1 247 134
assign 1 247 136
heldGet 0 247 136
assign 1 247 137
wasForeachGennedGet 0 247 137
assign 1 0 139
assign 1 0 142
assign 1 0 146
assign 1 249 149
containerGet 0 249 149
assign 1 249 150
typenameGet 0 249 150
assign 1 249 151
CALLGet 0 249 151
assign 1 249 152
equals 1 249 152
assign 1 249 154
containerGet 0 249 154
assign 1 249 155
heldGet 0 249 155
assign 1 249 156
orgNameGet 0 249 156
assign 1 249 157
new 0 249 157
assign 1 249 158
equals 1 249 158
assign 1 0 160
assign 1 0 163
assign 1 0 167
assign 1 249 170
isSecondGet 0 249 170
assign 1 0 172
assign 1 0 175
assign 1 0 179
assign 1 251 182
containedGet 0 251 182
assign 1 251 183
firstGet 0 251 183
assign 1 251 184
typenameGet 0 251 184
assign 1 251 185
VARGet 0 251 185
assign 1 251 186
equals 1 251 186
assign 1 251 188
containedGet 0 251 188
assign 1 251 189
firstGet 0 251 189
assign 1 251 190
heldGet 0 251 190
assign 1 251 191
isTypedGet 0 251 191
assign 1 0 193
assign 1 0 196
assign 1 0 200
assign 1 252 203
containedGet 0 252 203
assign 1 252 204
firstGet 0 252 204
assign 1 252 205
heldGet 0 252 205
assign 1 252 206
namepathGet 0 252 206
assign 1 253 207
stepsGet 0 253 207
assign 1 253 208
lastGet 0 253 208
assign 1 254 209
new 0 254 209
assign 1 254 210
new 0 254 210
assign 1 254 211
substring 2 254 211
assign 1 254 212
lowerValue 0 254 212
assign 1 254 213
new 0 254 213
assign 1 254 214
substring 1 254 214
assign 1 254 215
add 1 254 215
assign 1 254 216
new 0 254 216
assign 1 254 217
add 1 254 217
assign 1 256 218
getSynNp 1 256 218
assign 1 257 219
mtdMapGet 0 257 219
assign 1 257 220
new 0 257 220
assign 1 257 221
add 1 257 221
assign 1 257 222
get 1 257 222
assign 1 258 223
def 1 258 228
assign 1 260 229
heldGet 0 260 229
orgNameSet 1 260 230
assign 1 261 231
heldGet 0 261 231
assign 1 261 232
new 0 261 232
assign 1 261 233
add 1 261 233
nameSet 1 261 234
assign 1 266 239
typenameGet 0 266 239
assign 1 266 240
CLASSGet 0 266 240
assign 1 266 241
equals 1 266 241
assign 1 267 243
assign 1 268 244
heldGet 0 268 244
assign 1 268 245
namepathGet 0 268 245
assign 1 269 246
heldGet 0 269 246
assign 1 269 247
synGet 0 269 247
assign 1 271 249
typenameGet 0 271 249
assign 1 271 250
METHODGet 0 271 250
assign 1 271 251
equals 1 271 251
assign 1 272 253
new 0 272 253
assign 1 273 254
new 0 273 254
assign 1 274 257
typenameGet 0 274 257
assign 1 274 258
VARGet 0 274 258
assign 1 274 259
equals 1 274 259
assign 1 274 261
heldGet 0 274 261
assign 1 274 262
isTmpVarGet 0 274 262
assign 1 0 264
assign 1 0 267
assign 1 0 271
assign 1 275 274
heldGet 0 275 274
assign 1 275 275
nameGet 0 275 275
assign 1 275 276
heldGet 0 275 276
put 2 275 277
assign 1 276 278
heldGet 0 276 278
assign 1 276 279
nameGet 0 276 279
assign 1 276 280
get 1 276 280
assign 1 277 281
undef 1 277 286
assign 1 278 287
new 0 278 287
assign 1 279 288
heldGet 0 279 288
assign 1 279 289
nameGet 0 279 289
put 2 279 290
addValue 1 281 292
assign 1 282 295
typenameGet 0 282 295
assign 1 282 296
RBRACESGet 0 282 296
assign 1 282 297
equals 1 282 297
assign 1 282 299
containerGet 0 282 299
assign 1 282 300
def 1 282 305
assign 1 0 306
assign 1 0 309
assign 1 0 313
assign 1 282 316
containerGet 0 282 316
assign 1 282 317
containerGet 0 282 317
assign 1 282 318
def 1 282 323
assign 1 0 324
assign 1 0 327
assign 1 0 331
assign 1 282 334
containerGet 0 282 334
assign 1 282 335
containerGet 0 282 335
assign 1 282 336
typenameGet 0 282 336
assign 1 282 337
METHODGet 0 282 337
assign 1 282 338
equals 1 282 338
assign 1 0 340
assign 1 0 343
assign 1 0 347
processTmps 0 284 350
assign 1 286 354
nextDescendGet 0 286 354
return 1 286 355
assign 1 290 463
new 0 290 463
assign 1 299 467
new 0 299 467
assign 1 300 468
valueIteratorGet 0 300 468
assign 1 300 471
hasNextGet 0 300 471
assign 1 301 473
nextGet 0 301 473
assign 1 303 474
isTypedGet 0 303 474
assign 1 303 475
not 0 303 475
assign 1 306 477
nameGet 0 306 477
assign 1 307 478
get 1 307 478
assign 1 308 479
iteratorGet 0 0 479
assign 1 308 482
hasNextGet 0 308 482
assign 1 308 484
nextGet 0 308 484
assign 1 309 485
isFirstGet 0 309 485
assign 1 309 487
containerGet 0 309 487
assign 1 309 488
typenameGet 0 309 488
assign 1 309 489
CALLGet 0 309 489
assign 1 309 490
equals 1 309 490
assign 1 0 492
assign 1 0 495
assign 1 0 499
assign 1 309 502
containerGet 0 309 502
assign 1 309 503
heldGet 0 309 503
assign 1 309 504
orgNameGet 0 309 504
assign 1 309 505
new 0 309 505
assign 1 309 506
equals 1 309 506
assign 1 0 508
assign 1 0 511
assign 1 0 515
assign 1 309 518
containerGet 0 309 518
assign 1 309 519
secondGet 0 309 519
assign 1 309 520
typenameGet 0 309 520
assign 1 309 521
CALLGet 0 309 521
assign 1 309 522
equals 1 309 522
assign 1 0 524
assign 1 0 527
assign 1 0 531
assign 1 311 534
containerGet 0 311 534
assign 1 311 535
secondGet 0 311 535
assign 1 312 536
assign 1 313 537
heldGet 0 313 537
assign 1 313 538
newNpGet 0 313 538
assign 1 313 539
def 1 313 544
assign 1 314 545
heldGet 0 314 545
assign 1 314 546
newNpGet 0 314 546
assign 1 316 549
containedGet 0 316 549
assign 1 316 550
firstGet 0 316 550
assign 1 320 551
heldGet 0 320 551
assign 1 320 552
isDeclaredGet 0 320 552
assign 1 321 554
heldGet 0 321 554
assign 1 323 557
ptyMapGet 0 323 557
assign 1 323 558
heldGet 0 323 558
assign 1 323 559
nameGet 0 323 559
assign 1 323 560
get 1 323 560
assign 1 323 561
memSynGet 0 323 561
assign 1 326 563
isTypedGet 0 326 563
assign 1 327 565
namepathGet 0 327 565
assign 1 330 568
def 1 330 573
assign 1 332 574
getSynNp 1 332 574
assign 1 333 575
mtdMapGet 0 333 575
assign 1 333 576
heldGet 0 333 576
assign 1 333 577
nameGet 0 333 577
assign 1 333 578
get 1 333 578
assign 1 334 579
def 1 334 584
assign 1 336 585
rsynGet 0 336 585
assign 1 337 586
def 1 337 591
assign 1 337 592
isTypedGet 0 337 592
assign 1 0 594
assign 1 0 597
assign 1 0 601
assign 1 338 604
new 0 338 604
assign 1 340 605
isSelfGet 0 340 605
namepathSet 1 341 607
assign 1 343 610
namepathGet 0 343 610
namepathSet 1 343 611
assign 1 345 613
isTypedGet 0 345 613
isTypedSet 1 345 614
assign 1 346 615
heldGet 0 346 615
assign 1 346 616
namepathGet 0 346 616
addUsed 1 346 617
assign 1 347 618
namepathGet 0 347 618
assign 1 347 619
toString 0 347 619
assign 1 347 620
new 0 347 620
assign 1 347 621
equals 1 347 621
assign 1 347 623
new 0 347 623
assign 1 347 624
isSelfGet 0 347 624
assign 1 347 625
add 1 347 625
print 0 347 626
assign 1 349 631
heldGet 0 349 631
assign 1 349 632
orgNameGet 0 349 632
assign 1 349 633
new 0 349 633
assign 1 349 634
notEquals 1 349 634
assign 1 350 636
new 0 350 636
assign 1 350 637
heldGet 0 350 637
assign 1 350 638
nameGet 0 350 638
assign 1 350 639
add 1 350 639
assign 1 350 640
new 0 350 640
assign 1 350 641
add 1 350 641
assign 1 350 642
toString 0 350 642
assign 1 350 643
add 1 350 643
assign 1 350 644
new 2 350 644
throw 1 350 645
assign 1 355 651
isFirstGet 0 355 651
assign 1 355 653
containerGet 0 355 653
assign 1 355 654
typenameGet 0 355 654
assign 1 355 655
CALLGet 0 355 655
assign 1 355 656
equals 1 355 656
assign 1 0 658
assign 1 0 661
assign 1 0 665
assign 1 355 668
containerGet 0 355 668
assign 1 355 669
heldGet 0 355 669
assign 1 355 670
orgNameGet 0 355 670
assign 1 355 671
new 0 355 671
assign 1 355 672
equals 1 355 672
assign 1 0 674
assign 1 0 677
assign 1 0 681
assign 1 355 684
containerGet 0 355 684
assign 1 355 685
secondGet 0 355 685
assign 1 355 686
typenameGet 0 355 686
assign 1 355 687
VARGet 0 355 687
assign 1 355 688
equals 1 355 688
assign 1 0 690
assign 1 0 693
assign 1 0 697
assign 1 356 700
containerGet 0 356 700
assign 1 356 701
secondGet 0 356 701
assign 1 356 702
heldGet 0 356 702
assign 1 358 703
isTypedGet 0 358 703
assign 1 360 705
new 0 360 705
assign 1 362 706
isTypedGet 0 362 706
isTypedSet 1 362 707
assign 1 363 708
namepathGet 0 363 708
namepathSet 1 363 709
return 1 0 732
assign 1 0 735
return 1 0 739
assign 1 0 742
return 1 0 746
assign 1 0 749
return 1 0 753
assign 1 0 756
return 1 0 760
assign 1 0 763
return 1 0 767
assign 1 0 770
return 1 0 774
assign 1 0 777
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 2028575047: return bem_emitterGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2001798761: return bem_nlGet_0();
case 2055025483: return bem_serializeContents_0();
case 2041762316: return bem_inClassGet_0();
case 304475661: return bem_tvmapGet_0();
case 1012494862: return bem_once_0();
case 997464046: return bem_inClassSynGet_0();
case 1081412016: return bem_many_0();
case 1344145980: return bem_processTmps_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
case 265089021: return bem_rmapGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 315557914: return bem_tvmapSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 276171274: return bem_rmapSet_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_5_6_BuildVisitRewind();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_5_6_BuildVisitRewind.bevs_inst = (BEC_5_5_6_BuildVisitRewind)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_5_6_BuildVisitRewind.bevs_inst;
}
}
}
