namespace be.BEL_4_Base {
/* IO:File: source/build/Transport.be */
public sealed class BEC_2_5_9_BuildTransport : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransport() { }
static BEC_2_5_9_BuildTransport() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65,0x3A};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 38));
private static byte[] bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 10));
private static byte[] bels_3 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_4, 10));
private static byte[] bels_5 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bels_6 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_7 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bels_8 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_9 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_10 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static new BEC_2_5_9_BuildTransport bevs_inst;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_5_4_BuildNode bevp_outermost;
public BEC_2_5_4_BuildNode bevp_current;
public BEC_2_5_9_BuildTransport bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
BEC_2_5_9_BuildConstants bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_new_2(BEC_2_5_5_BuildBuild beva__build, BEC_2_5_4_BuildNode beva__outermost) {
BEC_2_5_9_BuildConstants bevt_0_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_traverse_1(BEC_3_5_5_7_BuildVisitVisitor beva_visitor) {
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
try  /* Line: 38 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 43 */ {
if (bevl_node == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 43 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 44 */
 else  /* Line: 43 */ {
break;
} /* Line: 43 */
} /* Line: 43 */
beva_visitor.bem_end_1(this);
} /* Line: 47 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 49 */ {
bevt_2_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold.bem_print_0();
bevl_node.bem_print_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_3_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
} /* Line: 53 */
 else  /* Line: 54 */ {
bevt_4_tmpvar_phold = bevo_2;
bevt_4_tmpvar_phold.bem_print_0();
bevt_5_tmpvar_phold = bevo_3;
bevt_5_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
} /* Line: 57 */
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 59 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_contain_0() {
BEC_2_9_3_ContainerMap bevl_conTypes = null;
BEC_2_5_4_BuildNode bevl_curr = null;
BEC_2_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_5_4_BuildNode bevl_wf = null;
BEC_2_5_4_BuildNode bevl_cnode = null;
BEC_2_5_4_BuildNode bevl_mnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_9_BuildConstants bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_69_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpvar_phold = null;
bevt_7_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_tmpvar_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 68 */ {
bevt_8_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 68 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevl_i.bem_nextGet_0();
bevt_10_tmpvar_phold = bevl_node.bem_delayDeleteGet_0();
if (bevt_10_tmpvar_phold.bevi_bool) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 72 */ {
bevt_12_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_13_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_12_tmpvar_phold.bevi_int == bevt_13_tmpvar_phold.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevt_15_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_16_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_15_tmpvar_phold.bevi_int == bevt_16_tmpvar_phold.bevi_int) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
 else  /* Line: 73 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 73 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 77 */ {
if (bevl_wf == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevt_19_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_20_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_19_tmpvar_phold.bevi_int == bevt_20_tmpvar_phold.bevi_int) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_22_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_23_tmpvar_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_22_tmpvar_phold.bevi_int == bevt_23_tmpvar_phold.bevi_int) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 77 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_25_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
if (bevt_25_tmpvar_phold.bevi_int == bevt_26_tmpvar_phold.bevi_int) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 78 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 77 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 77 */
 else  /* Line: 77 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 78 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 79 */
 else  /* Line: 77 */ {
break;
} /* Line: 77 */
} /* Line: 77 */
if (bevl_wf == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_29_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_30_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_29_tmpvar_phold.bevi_int == bevt_30_tmpvar_phold.bevi_int) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_32_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_33_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_32_tmpvar_phold.bevi_int == bevt_33_tmpvar_phold.bevi_int) {
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 81 */ {
bevl_cnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_5));
bevl_cnode.bem_heldSet_1(bevt_35_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 88 */
} /* Line: 81 */
bevt_37_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_38_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_37_tmpvar_phold.bevi_int == bevt_38_tmpvar_phold.bevi_int) {
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_41_tmpvar_phold = bevl_curr.bem_containerGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_typenameGet_0();
bevt_42_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_40_tmpvar_phold.bevi_int == bevt_42_tmpvar_phold.bevi_int) {
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 91 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 91 */
 else  /* Line: 91 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 91 */ {
bevt_44_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_45_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_44_tmpvar_phold.bevi_int == bevt_45_tmpvar_phold.bevi_int) {
bevt_43_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_43_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 91 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 91 */
 else  /* Line: 91 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 91 */ {
bevl_mnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_6));
bevl_mnode.bem_heldSet_1(bevt_47_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 97 */
bevt_49_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_50_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_49_tmpvar_phold.bevi_int == bevt_50_tmpvar_phold.bevi_int) {
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_52_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_53_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_52_tmpvar_phold.bevi_int == bevt_53_tmpvar_phold.bevi_int) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 100 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 100 */
 else  /* Line: 100 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 100 */ {
bevl_mnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_7));
bevl_mnode.bem_heldSet_1(bevt_55_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 106 */
bevt_57_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_58_tmpvar_phold = bevp_ntypes.bem_RPARENSGet_0();
if (bevt_57_tmpvar_phold.bevi_int == bevt_58_tmpvar_phold.bevi_int) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 110 */
 else  /* Line: 109 */ {
bevt_60_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_61_tmpvar_phold = bevp_ntypes.bem_RIDXGet_0();
if (bevt_60_tmpvar_phold.bevi_int == bevt_61_tmpvar_phold.bevi_int) {
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpvar_phold.bevi_bool) /* Line: 111 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 112 */
 else  /* Line: 109 */ {
bevt_63_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_64_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_63_tmpvar_phold.bevi_int == bevt_64_tmpvar_phold.bevi_int) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevt_67_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bels_8));
bevt_66_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_67_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_66_tmpvar_phold);
} /* Line: 116 */
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 119 */ {
bevt_70_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bels_9));
bevt_69_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_70_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_69_tmpvar_phold);
} /* Line: 120 */
} /* Line: 119 */
 else  /* Line: 122 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 123 */
} /* Line: 109 */
} /* Line: 109 */
bevt_72_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_71_tmpvar_phold = bevl_conTypes.bem_has_1(bevt_72_tmpvar_phold);
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 125 */ {
bevl_curr = bevl_node;
} /* Line: 126 */
} /* Line: 125 */
} /* Line: 72 */
 else  /* Line: 68 */ {
break;
} /* Line: 68 */
} /* Line: 68 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_stepBack_1(BEC_2_5_4_BuildNode beva_curr) {
BEC_2_5_4_BuildNode bevl_hop = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 134 */ {
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bels_10));
bevt_1_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpvar_phold, beva_curr);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 135 */
return bevl_hop;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_outermostGet_0() {
return bevp_outermost;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outermostSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {20, 21, 21, 22, 23, 25, 25, 26, 26, 30, 31, 31, 32, 33, 39, 41, 43, 43, 44, 47, 49, 49, 50, 50, 51, 52, 52, 53, 55, 55, 56, 56, 57, 59, 64, 64, 65, 66, 67, 68, 68, 71, 72, 72, 72, 73, 73, 73, 73, 73, 73, 73, 73, 0, 0, 0, 76, 77, 77, 77, 77, 77, 77, 0, 77, 77, 77, 77, 0, 0, 0, 78, 78, 78, 78, 0, 0, 0, 0, 0, 79, 81, 81, 81, 81, 81, 81, 0, 81, 81, 81, 81, 0, 0, 0, 0, 0, 84, 85, 85, 86, 86, 87, 88, 91, 91, 91, 91, 91, 91, 91, 91, 91, 0, 0, 0, 91, 91, 91, 91, 0, 0, 0, 93, 94, 94, 95, 95, 96, 97, 100, 100, 100, 100, 100, 100, 100, 100, 0, 0, 0, 102, 103, 103, 104, 104, 105, 106, 109, 109, 109, 109, 110, 111, 111, 111, 111, 112, 113, 113, 113, 113, 114, 115, 115, 116, 116, 116, 118, 119, 119, 120, 120, 120, 123, 125, 125, 126, 133, 134, 134, 135, 135, 135, 137, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {32, 33, 34, 35, 36, 37, 38, 39, 40, 45, 46, 47, 48, 49, 62, 63, 66, 71, 72, 78, 82, 87, 88, 89, 90, 91, 92, 93, 96, 97, 98, 99, 100, 102, 188, 189, 190, 191, 192, 193, 196, 198, 199, 200, 205, 206, 207, 208, 213, 214, 215, 216, 221, 222, 225, 229, 232, 235, 240, 241, 242, 243, 248, 249, 252, 253, 254, 259, 260, 263, 267, 270, 271, 272, 277, 278, 281, 285, 288, 292, 295, 301, 306, 307, 308, 309, 314, 315, 318, 319, 320, 325, 326, 329, 333, 336, 340, 343, 344, 345, 346, 347, 348, 349, 352, 353, 354, 359, 360, 361, 362, 363, 368, 369, 372, 376, 379, 380, 381, 386, 387, 390, 394, 397, 398, 399, 400, 401, 402, 403, 405, 406, 407, 412, 413, 414, 415, 420, 421, 424, 428, 431, 432, 433, 434, 435, 436, 437, 439, 440, 441, 446, 447, 450, 451, 452, 457, 458, 461, 462, 463, 468, 469, 470, 475, 476, 477, 478, 480, 481, 486, 487, 488, 489, 493, 497, 498, 500, 515, 516, 521, 522, 523, 524, 526, 529, 532, 536, 539, 543, 546, 550, 553};
/* BEGIN LINEINFO 
assign 1 20 32
assign 1 21 33
constantsGet 0 21 33
assign 1 21 34
ntypesGet 0 21 34
assign 1 22 35
new 1 22 35
assign 1 23 36
assign 1 25 37
TRANSUNITGet 0 25 37
typenameSet 1 25 38
assign 1 26 39
new 0 26 39
heldSet 1 26 40
assign 1 30 45
assign 1 31 46
constantsGet 0 31 46
assign 1 31 47
ntypesGet 0 31 47
assign 1 32 48
assign 1 33 49
begin 1 39 62
assign 1 41 63
accept 1 41 63
assign 1 43 66
def 1 43 71
assign 1 44 72
accept 1 44 72
end 1 47 78
assign 1 49 82
def 1 49 87
assign 1 50 88
new 0 50 88
print 0 50 89
print 0 51 90
assign 1 52 91
new 0 52 91
print 0 52 92
print 0 53 93
assign 1 55 96
new 0 55 96
print 0 55 97
assign 1 56 98
new 0 56 98
print 0 56 99
print 0 57 100
throw 1 59 102
assign 1 64 188
constantsGet 0 64 188
assign 1 64 189
conTypesGet 0 64 189
assign 1 65 190
assign 1 66 191
containedGet 0 66 191
containedSet 1 67 192
assign 1 68 193
linkedListIteratorGet 0 68 193
assign 1 68 196
hasNextGet 0 68 196
assign 1 71 198
nextGet 0 71 198
assign 1 72 199
delayDeleteGet 0 72 199
assign 1 72 200
not 0 72 205
assign 1 73 206
typenameGet 0 73 206
assign 1 73 207
TRANSUNITGet 0 73 207
assign 1 73 208
equals 1 73 213
assign 1 73 214
typenameGet 0 73 214
assign 1 73 215
IDGet 0 73 215
assign 1 73 216
equals 1 73 221
assign 1 0 222
assign 1 0 225
assign 1 0 229
assign 1 76 232
assign 1 77 235
def 1 77 240
assign 1 77 241
typenameGet 0 77 241
assign 1 77 242
IDGet 0 77 242
assign 1 77 243
equals 1 77 248
assign 1 0 249
assign 1 77 252
typenameGet 0 77 252
assign 1 77 253
COLONGet 0 77 253
assign 1 77 254
equals 1 77 259
assign 1 0 260
assign 1 0 263
assign 1 0 267
assign 1 78 270
typenameGet 0 78 270
assign 1 78 271
SPACEGet 0 78 271
assign 1 78 272
equals 1 78 277
assign 1 0 278
assign 1 0 281
assign 1 0 285
assign 1 0 288
assign 1 0 292
assign 1 79 295
nextPeerGet 0 79 295
assign 1 81 301
def 1 81 306
assign 1 81 307
typenameGet 0 81 307
assign 1 81 308
PARENSGet 0 81 308
assign 1 81 309
equals 1 81 314
assign 1 0 315
assign 1 81 318
typenameGet 0 81 318
assign 1 81 319
BRACESGet 0 81 319
assign 1 81 320
equals 1 81 325
assign 1 0 326
assign 1 0 329
assign 1 0 333
assign 1 0 336
assign 1 0 340
assign 1 84 343
new 1 84 343
assign 1 85 344
CLASSGet 0 85 344
typenameSet 1 85 345
assign 1 86 346
new 0 86 346
heldSet 1 86 347
addValue 1 87 348
assign 1 88 349
assign 1 91 352
typenameGet 0 91 352
assign 1 91 353
BRACESGet 0 91 353
assign 1 91 354
equals 1 91 359
assign 1 91 360
containerGet 0 91 360
assign 1 91 361
typenameGet 0 91 361
assign 1 91 362
CLASSGet 0 91 362
assign 1 91 363
equals 1 91 368
assign 1 0 369
assign 1 0 372
assign 1 0 376
assign 1 91 379
typenameGet 0 91 379
assign 1 91 380
IDGet 0 91 380
assign 1 91 381
equals 1 91 386
assign 1 0 387
assign 1 0 390
assign 1 0 394
assign 1 93 397
new 1 93 397
assign 1 94 398
METHODGet 0 94 398
typenameSet 1 94 399
assign 1 95 400
new 0 95 400
heldSet 1 95 401
addValue 1 96 402
assign 1 97 403
assign 1 100 405
typenameGet 0 100 405
assign 1 100 406
BRACESGet 0 100 406
assign 1 100 407
equals 1 100 412
assign 1 100 413
typenameGet 0 100 413
assign 1 100 414
BRACESGet 0 100 414
assign 1 100 415
equals 1 100 420
assign 1 0 421
assign 1 0 424
assign 1 0 428
assign 1 102 431
new 1 102 431
assign 1 103 432
PROPERTIESGet 0 103 432
typenameSet 1 103 433
assign 1 104 434
new 0 104 434
heldSet 1 104 435
addValue 1 105 436
assign 1 106 437
assign 1 109 439
typenameGet 0 109 439
assign 1 109 440
RPARENSGet 0 109 440
assign 1 109 441
equals 1 109 446
assign 1 110 447
stepBack 1 110 447
assign 1 111 450
typenameGet 0 111 450
assign 1 111 451
RIDXGet 0 111 451
assign 1 111 452
equals 1 111 457
assign 1 112 458
stepBack 1 112 458
assign 1 113 461
typenameGet 0 113 461
assign 1 113 462
RBRACESGet 0 113 462
assign 1 113 463
equals 1 113 468
assign 1 114 469
stepBack 1 114 469
assign 1 115 470
undef 1 115 475
assign 1 116 476
new 0 116 476
assign 1 116 477
new 2 116 477
throw 1 116 478
assign 1 118 480
stepBack 1 118 480
assign 1 119 481
undef 1 119 486
assign 1 120 487
new 0 120 487
assign 1 120 488
new 2 120 488
throw 1 120 489
addValue 1 123 493
assign 1 125 497
typenameGet 0 125 497
assign 1 125 498
has 1 125 498
assign 1 126 500
assign 1 133 515
containerGet 0 133 515
assign 1 134 516
undef 1 134 521
assign 1 135 522
new 0 135 522
assign 1 135 523
new 2 135 523
throw 1 135 524
return 1 137 526
return 1 0 529
assign 1 0 532
return 1 0 536
assign 1 0 539
return 1 0 543
assign 1 0 546
return 1 0 550
assign 1 0 553
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case -410956923: return bem_contain_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case -1081412016: return bem_many_0();
case -1380522583: return bem_outermostGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -2101994299: return bem_stepBack_1((BEC_2_5_4_BuildNode) bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1369440330: return bem_outermostSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 688372900: return bem_traverse_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_5_5_BuildBuild) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildTransport();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildTransport.bevs_inst = (BEC_2_5_9_BuildTransport)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildTransport.bevs_inst;
}
}
}
