namespace be.BEL_4_Base {

using System.IO;
using System;
    /* File: source/base/String.be */
public class BEC_4_6_TextString : BEC_6_6_SystemObject {
public BEC_4_6_TextString() { }
static BEC_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_4_6_TextString(byte[] bevi_bytes) { 
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_bytes.Length);
    }
    public BEC_4_6_TextString(byte[] bevi_bytes, int bevi_length) { 
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_length);
    }
    public BEC_4_6_TextString(int bevi_length, byte[] bevi_bytes) { 
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_length);
    }
    public BEC_4_6_TextString(string bevi_string) {
        byte[] bevi_bytes = System.Text.Encoding.UTF8.GetBytes(bevi_string);
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_bytes.Length);
    }
    public string bems_toCsString() {
        string csString = System.Text.Encoding.UTF8.GetString(bevi_bytes, 0, bevp_size.bevi_int);
        return csString;
    }
    
   private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x42,0x75,0x66,0x66,0x65,0x72,0x20,0x72,0x65,0x61,0x6C,0x6C,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(16));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_1 = {0x0A};
private static BEC_4_3_MathInt bevo_5 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_6 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_7 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_8 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(57));
private static BEC_4_3_MathInt bevo_9 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(48));
private static BEC_4_3_MathInt bevo_10 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(64));
private static BEC_4_3_MathInt bevo_11 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(91));
private static BEC_4_3_MathInt bevo_12 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(96));
private static BEC_4_3_MathInt bevo_13 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(123));
private static BEC_4_3_MathInt bevo_14 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_15 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_16 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_17 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_18 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_19 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_20 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_21 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_22 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_23 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_24 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_25 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_26 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(-1));
private static BEC_4_3_MathInt bevo_27 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_28 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_2 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_4_3_MathInt bevo_29 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_30 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
public static new BEC_4_6_TextString bevs_inst;
public BEC_6_6_SystemObject bevp_vstring;
public BEC_4_3_MathInt bevp_size;
public BEC_4_3_MathInt bevp_capacity;
public BEC_4_3_MathInt bevp_leni;
public BEC_4_3_MathInt bevp_sizi;
public virtual BEC_6_6_SystemObject bem_vstringGet_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_vstringSet_0() {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_new_1(BEC_4_3_MathInt beva__capacity) {
this.bem_capacitySet_1(beva__capacity);
bevp_size = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_new_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_capacitySet_1(BEC_4_3_MathInt beva_ncap) {
BEC_4_6_TextString bevl_failed = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_9_SystemException bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
if (bevp_capacity == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_3_tmpvar_phold = bevp_capacity.bem_equals_1(beva_ncap);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 204 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 204 */
 else  /* Line: 204 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 204 */ {
return this;
} /* Line: 205 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        byte[] bevls_bytes = new byte[beva_ncap.bevi_int];
        Array.Copy(this.bevi_bytes, bevls_bytes, Math.Min(this.bevi_bytes.Length, bevls_bytes.Length));
        this.bevi_bytes = bevls_bytes;
      }
      if (bevl_failed == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 256 */ {
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(26, bels_0));
bevt_5_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_6_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 257 */
if (bevp_size == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 259 */ {
bevt_8_tmpvar_phold = bevp_size.bem_greater_1(beva_ncap);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 259 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 259 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 259 */ {
bevp_size = (BEC_4_3_MathInt) beva_ncap.bem_copy_0();
} /* Line: 260 */
bevp_capacity = beva_ncap;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_hexNew_1(BEC_4_6_TextString beva_val) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpvar_phold);
bevp_size = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_setHex_2(bevt_1_tmpvar_phold, beva_val);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_getHex_1(BEC_4_3_MathInt beva_pos) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_1_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_4_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevt_5_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(16));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_toString_3(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_setHex_2(BEC_4_3_MathInt beva_pos, BEC_4_6_TextString beva_hval) {
BEC_4_3_MathInt bevl_val = null;
bevl_val = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_hexNew_1(beva_hval);
this.bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_addValue_1(BEC_6_6_SystemObject beva_astr) {
BEC_4_6_TextString bevl_str = null;
BEC_4_3_MathInt bevl_nsize = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_5_SystemTypes bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_6_5_SystemTypes) BEC_6_5_SystemTypes.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_stringGet_0();
bevt_1_tmpvar_phold = beva_astr.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevl_str = (BEC_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 282 */
 else  /* Line: 283 */ {
bevl_str = (BEC_4_6_TextString) beva_astr;
} /* Line: 284 */
if (bevp_leni == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 286 */ {
bevp_leni = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevp_sizi = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 288 */
bevt_5_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bem_setValue_1(bevt_5_tmpvar_phold);
bevp_sizi.bem_addValue_1(bevp_size);
bevt_6_tmpvar_phold = bevp_capacity.bem_lesser_1(bevp_sizi);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevt_9_tmpvar_phold = bevo_0;
bevt_8_tmpvar_phold = bevp_sizi.bem_add_1(bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_1;
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_multiply_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_2;
bevl_nsize = bevt_7_tmpvar_phold.bem_divide_1(bevt_11_tmpvar_phold);
this.bem_capacitySet_1(bevl_nsize);
} /* Line: 295 */
bevt_12_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_13_tmpvar_phold = bevl_str.bem_sizeGet_0();
this.bem_copyValue_4(bevl_str, bevt_12_tmpvar_phold, bevt_13_tmpvar_phold, bevp_size);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_readBuffer_0() {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_readString_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_write_1(BEC_6_6_SystemObject beva_stri) {
this.bem_addValue_1(beva_stri);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_writeTo_1(BEC_6_6_SystemObject beva_w) {
beva_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, this);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_open_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_close_0() {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_extractString_0() {
BEC_4_6_TextString bevl_str = null;
bevl_str = (BEC_4_6_TextString) this.bem_copy_0();
this.bem_clear_0();
return bevl_str;
} /*method end*/
public virtual BEC_4_6_TextString bem_clear_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevp_size.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 331 */ {
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_3_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_setIntUnchecked_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevp_size = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
} /* Line: 333 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_codeNew_1(BEC_6_6_SystemObject beva_codei) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpvar_phold);
bevp_size = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_setCodeUnchecked_2(bevt_1_tmpvar_phold, (BEC_4_3_MathInt) beva_codei);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_chomp_0() {
BEC_4_6_TextString bevl_nl = null;
BEC_6_15_SystemCurrentPlatform bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpvar_phold.bem_newlineGet_0();
bevt_1_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 345 */ {
bevt_3_tmpvar_phold = bevo_4;
bevt_5_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevp_size.bem_subtract_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold = this.bem_substring_2(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /* Line: 346 */
bevl_nl = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_1));
bevt_6_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 349 */ {
bevt_8_tmpvar_phold = bevo_5;
bevt_10_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevp_size.bem_subtract_1(bevt_10_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_substring_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
return bevt_7_tmpvar_phold;
} /* Line: 350 */
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_copy_0() {
BEC_4_6_TextString bevl_c = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_6;
bevt_0_tmpvar_phold = bevp_size.bem_add_1(bevt_1_tmpvar_phold);
bevl_c = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_c.bem_addValue_1(this);
return bevl_c;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_begins_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevl_found = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_found = this.bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 363 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 363 */ {
bevt_3_tmpvar_phold = bevo_7;
bevt_2_tmpvar_phold = bevl_found.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 363 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 363 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 363 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 363 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 364 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_ends_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevl_found = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_str == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 370 */ {
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 370 */
bevt_3_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevp_size.bem_subtract_1(bevt_3_tmpvar_phold);
bevl_found = this.bem_find_2(beva_str, bevt_2_tmpvar_phold);
if (bevl_found == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 372 */ {
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 373 */
bevt_6_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_has_1(BEC_4_6_TextString beva_str) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_str == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 379 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 379 */ {
bevt_3_tmpvar_phold = this.bem_find_1(beva_str);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 379 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 379 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 379 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 379 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 380 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isInteger_0() {
BEC_4_3_MathInt bevl_ic = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
bevl_ic = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 387 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 387 */ {
this.bem_getInt_2(bevl_j, bevl_ic);
bevt_3_tmpvar_phold = bevo_8;
bevt_2_tmpvar_phold = bevl_ic.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 389 */ {
bevt_5_tmpvar_phold = bevo_9;
bevt_4_tmpvar_phold = bevl_ic.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 389 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 389 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 389 */ {
bevt_6_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 390 */
bevl_j.bem_incrementValue_0();
} /* Line: 387 */
 else  /* Line: 387 */ {
break;
} /* Line: 387 */
} /* Line: 387 */
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_lowerValue_0() {
BEC_4_3_MathInt bevl_vc = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 398 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 398 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_10;
bevt_2_tmpvar_phold = bevl_vc.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 400 */ {
bevt_5_tmpvar_phold = bevo_11;
bevt_4_tmpvar_phold = bevl_vc.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 400 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 400 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 400 */
 else  /* Line: 400 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 400 */ {
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(32));
bevl_vc.bem_addValue_1(bevt_6_tmpvar_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 402 */
bevl_j.bem_incrementValue_0();
} /* Line: 398 */
 else  /* Line: 398 */ {
break;
} /* Line: 398 */
} /* Line: 398 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_lower_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_copy_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1903477087, BEL_4_Base.bevn_lowerValue_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_upperValue_0() {
BEC_4_3_MathInt bevl_vc = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 413 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 413 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_12;
bevt_2_tmpvar_phold = bevl_vc.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 415 */ {
bevt_5_tmpvar_phold = bevo_13;
bevt_4_tmpvar_phold = bevl_vc.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 415 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 415 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 415 */
 else  /* Line: 415 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 415 */ {
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpvar_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 417 */
bevl_j.bem_incrementValue_0();
} /* Line: 413 */
 else  /* Line: 413 */ {
break;
} /* Line: 413 */
} /* Line: 413 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_upper_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_copy_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1163089440, BEL_4_Base.bevn_upperValue_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_swap_2(BEC_4_6_TextString beva_from, BEC_4_6_TextString beva_to) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = this.bem_split_1(beva_from);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_to, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_getPoint_1(BEC_4_3_MathInt beva_posi) {
BEC_4_6_TextString bevl_buf = null;
BEC_6_6_SystemObject bevl_j = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_6_TextString bevl_y = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevl_buf = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_j = this.bem_mbiterGet_0();
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 434 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(beva_posi);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 434 */ {
bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 434 */
 else  /* Line: 434 */ {
break;
} /* Line: 434 */
} /* Line: 434 */
bevt_2_tmpvar_phold = bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_y = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
return bevl_y;
} /*method end*/
public virtual BEC_4_3_MathInt bem_hashValue_1(BEC_4_3_MathInt beva_into) {
BEC_4_3_MathInt bevl_c = null;
BEC_4_3_MathInt bevl_j = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevl_c = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
beva_into.bem_setValue_1(bevt_0_tmpvar_phold);
bevl_j = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 444 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 444 */ {
this.bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpvar_phold);
beva_into.bem_addValue_1(bevl_c);
bevl_j.bem_incrementValue_0();
} /* Line: 444 */
 else  /* Line: 444 */ {
break;
} /* Line: 444 */
} /* Line: 444 */
bevt_3_tmpvar_phold = beva_into.bem_absValue_0();
return bevt_3_tmpvar_phold;
} /*method end*/
public override BEC_4_3_MathInt bem_hashGet_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_hashValue_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_getCode_1(BEC_4_3_MathInt beva_pos) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_getInt_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_14;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 467 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 467 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 467 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 467 */
 else  /* Line: 467 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 467 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int > 127) {
            beva_into.bevi_int -= 256;
         }
         } /* Line: 487 */
 else  /* Line: 495 */ {
return null;
} /* Line: 496 */
return beva_into;
} /*method end*/
public virtual BEC_4_3_MathInt bem_getCode_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_15;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 509 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 509 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 509 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 509 */
 else  /* Line: 509 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 509 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 533 */
 else  /* Line: 538 */ {
return null;
} /* Line: 539 */
return beva_into;
} /*method end*/
public virtual BEC_4_6_TextString bem_setInt_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_16;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 545 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 545 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 545 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 545 */
 else  /* Line: 545 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 545 */ {
this.bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 546 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_setCode_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_17;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 551 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 551 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 551 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 551 */
 else  /* Line: 551 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 551 */ {
this.bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 552 */
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isEmptyGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_18;
bevt_0_tmpvar_phold = bevp_size.bem_lesserEquals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 557 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 558 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_setIntUnchecked_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b < 0) {
        twvls_b += 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_setCodeUnchecked_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_reverseFind_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_rfind_1(beva_str);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_rfind_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevl_rpos = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_copy_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(800915430, BEL_4_Base.bevn_reverseBytes_0);
bevt_3_tmpvar_phold = beva_str.bem_copy_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(800915430, BEL_4_Base.bevn_reverseBytes_0);
bevl_rpos = (BEC_4_3_MathInt) bevt_0_tmpvar_phold.bemd_1(1274448085, BEL_4_Base.bevn_find_1, bevt_2_tmpvar_phold);
if (bevl_rpos == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 651 */ {
bevt_5_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpvar_phold;
} /* Line: 653 */
return null;
} /*method end*/
public virtual BEC_4_3_MathInt bem_find_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_19;
bevt_0_tmpvar_phold = this.bem_find_2(beva_str, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_find_2(BEC_4_6_TextString beva_str, BEC_4_3_MathInt beva_start) {
BEC_4_3_MathInt bevl_end = null;
BEC_4_3_MathInt bevl_current = null;
BEC_4_3_MathInt bevl_myval = null;
BEC_4_3_MathInt bevl_strfirst = null;
BEC_4_3_MathInt bevl_strsize = null;
BEC_4_3_MathInt bevl_strval = null;
BEC_4_3_MathInt bevl_current2 = null;
BEC_4_3_MathInt bevl_end2 = null;
BEC_4_3_MathInt bevl_currentstr2 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
if (beva_str == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
if (beva_start == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_9_tmpvar_phold = bevo_20;
bevt_8_tmpvar_phold = beva_start.bem_lesser_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_10_tmpvar_phold = beva_start.bem_greaterEquals_1(bevp_size);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_12_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_greater_1(bevp_size);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_14_tmpvar_phold = bevo_21;
bevt_13_tmpvar_phold = bevp_size.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_16_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpvar_phold = bevo_22;
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_equals_1(bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
return null;
} /* Line: 666 */
bevl_end = bevp_size;
bevl_current = (BEC_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_strfirst = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_18_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpvar_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpvar_phold = bevo_23;
bevt_19_tmpvar_phold = bevl_strsize.bem_greater_1(bevt_20_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 677 */ {
bevl_strval = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_current2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_end2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 680 */
while (true)
 /* Line: 683 */ {
bevt_21_tmpvar_phold = bevl_current.bem_lesser_1(bevl_end);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 683 */ {
this.bem_getInt_2(bevl_current, bevl_myval);
bevt_22_tmpvar_phold = bevl_myval.bem_equals_1(bevl_strfirst);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 685 */ {
bevt_24_tmpvar_phold = bevo_24;
bevt_23_tmpvar_phold = bevl_strsize.bem_equals_1(bevt_24_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 686 */ {
return bevl_current;
} /* Line: 687 */
bevl_current2.bem_setValue_1(bevl_current);
bevl_current2.bem_incrementValue_0();
bevl_end2.bem_setValue_1(bevl_current);
bevt_25_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_end2.bem_addValue_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = bevl_end2.bem_greater_1(bevp_size);
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 693 */ {
return null;
} /* Line: 694 */
bevl_currentstr2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 697 */ {
bevt_27_tmpvar_phold = bevl_current2.bem_lesser_1(bevl_end2);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 697 */ {
this.bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
bevt_28_tmpvar_phold = bevl_myval.bem_notEquals_1(bevl_strval);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 700 */ {
break;
} /* Line: 701 */
bevl_current2.bem_incrementValue_0();
bevl_currentstr2.bem_incrementValue_0();
} /* Line: 704 */
 else  /* Line: 697 */ {
break;
} /* Line: 697 */
} /* Line: 697 */
bevt_29_tmpvar_phold = bevl_current2.bem_equals_1(bevl_end2);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 706 */ {
return bevl_current;
} /* Line: 707 */
} /* Line: 706 */
bevl_current.bem_incrementValue_0();
} /* Line: 710 */
 else  /* Line: 683 */ {
break;
} /* Line: 683 */
} /* Line: 683 */
return null;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_split_1(BEC_4_6_TextString beva_delim) {
BEC_9_10_ContainerLinkedList bevl_splits = null;
BEC_4_3_MathInt bevl_last = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_ds = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
bevl_splits = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_i = this.bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 720 */ {
if (bevl_i == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 720 */ {
bevt_1_tmpvar_phold = this.bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpvar_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = this.bem_find_2(beva_delim, bevl_last);
} /* Line: 723 */
 else  /* Line: 720 */ {
break;
} /* Line: 720 */
} /* Line: 720 */
bevt_2_tmpvar_phold = bevl_last.bem_lesser_1(bevp_size);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 725 */ {
bevt_3_tmpvar_phold = this.bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpvar_phold);
} /* Line: 726 */
return bevl_splits;
} /*method end*/
public virtual BEC_4_6_TextString bem_join_2(BEC_4_6_TextString beva_delim, BEC_6_6_SystemObject beva_splits) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_splitLines_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_9_TextTokenizer bevt_1_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_lineSplitterGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_tokenize_1(this);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_compare_1(BEC_6_6_SystemObject beva_stri) {
BEC_4_3_MathInt bevl_mysize = null;
BEC_4_3_MathInt bevl_osize = null;
BEC_4_3_MathInt bevl_maxsize = null;
BEC_4_3_MathInt bevl_myret = null;
BEC_4_3_MathInt bevl_mv = null;
BEC_4_3_MathInt bevl_ov = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
if (beva_stri == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 748 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 748 */ {
bevt_2_tmpvar_phold = beva_stri.bemd_1(1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 748 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 748 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 748 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 748 */ {
return null;
} /* Line: 749 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_4_3_MathInt) beva_stri.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevt_3_tmpvar_phold = bevl_mysize.bem_greater_1(bevl_osize);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 753 */ {
bevl_maxsize = bevl_osize;
} /* Line: 754 */
 else  /* Line: 755 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 756 */
bevl_myret = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_mv = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_ov = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 761 */ {
bevt_4_tmpvar_phold = bevl_i.bem_lesser_1(bevl_maxsize);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 761 */ {
this.bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(340923734, BEL_4_Base.bevn_getCode_2, bevl_i, bevl_ov);
bevt_5_tmpvar_phold = bevl_mv.bem_notEquals_1(bevl_ov);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 764 */ {
bevt_6_tmpvar_phold = bevl_mv.bem_greater_1(bevl_ov);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 765 */ {
bevt_7_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
return bevt_7_tmpvar_phold;
} /* Line: 766 */
 else  /* Line: 767 */ {
bevt_8_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(-1));
return bevt_8_tmpvar_phold;
} /* Line: 768 */
} /* Line: 765 */
bevl_i.bem_incrementValue_0();
} /* Line: 761 */
 else  /* Line: 761 */ {
break;
} /* Line: 761 */
} /* Line: 761 */
bevt_10_tmpvar_phold = bevo_25;
bevt_9_tmpvar_phold = bevl_myret.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 772 */ {
bevt_11_tmpvar_phold = bevl_mysize.bem_greater_1(bevl_osize);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 773 */ {
bevl_myret = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
} /* Line: 774 */
 else  /* Line: 773 */ {
bevt_12_tmpvar_phold = bevl_osize.bem_greater_1(bevl_mysize);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 775 */ {
bevl_myret = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(-1));
} /* Line: 776 */
} /* Line: 773 */
} /* Line: 773 */
return bevl_myret;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_lesser_1(BEC_4_6_TextString beva_stri) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 783 */ {
return null;
} /* Line: 783 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_26;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 784 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 785 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_greater_1(BEC_4_6_TextString beva_stri) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 791 */ {
return null;
} /* Line: 791 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_27;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 792 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 793 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_stri) {
BEC_4_3_MathInt bevl_mysize = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_stri == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 806 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /* Line: 807 */

  var bevls_stri = beva_stri as BEC_4_6_TextString;
  if (bevls_stri != null) {
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BELS_Base.BECS_Runtime.boolFalse;
          }
       }
       return be.BELS_Base.BECS_Runtime.boolTrue;
   }
  }
  bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_str) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_str);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_add_1(BEC_6_6_SystemObject beva_astr) {
BEC_4_6_TextString bevl_str = null;
BEC_4_6_TextString bevl_res = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_5_SystemTypes bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_6_5_SystemTypes) BEC_6_5_SystemTypes.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_stringGet_0();
bevt_1_tmpvar_phold = beva_astr.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 875 */ {
bevl_str = (BEC_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 876 */
 else  /* Line: 877 */ {
bevl_str = (BEC_4_6_TextString) beva_astr;
} /* Line: 878 */
bevt_5_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevp_size.bem_add_1(bevt_5_tmpvar_phold);
bevl_res = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_7_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_6_tmpvar_phold, bevp_size, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_9_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold, bevp_size);
return bevl_res;
} /*method end*/
public override BEC_6_6_SystemObject bem_create_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_copyValue_4(BEC_4_6_TextString beva_org, BEC_4_3_MathInt beva_starti, BEC_4_3_MathInt beva_endi, BEC_4_3_MathInt beva_dstarti) {
BEC_4_3_MathInt bevl_mleni = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_6_9_SystemException bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_28;
bevt_1_tmpvar_phold = beva_starti.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 911 */ {
bevt_4_tmpvar_phold = beva_org.bem_sizeGet_0();
bevt_3_tmpvar_phold = beva_starti.bem_greater_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 911 */ {
bevt_6_tmpvar_phold = beva_org.bem_sizeGet_0();
bevt_5_tmpvar_phold = beva_endi.bem_greater_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 911 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 911 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 911 */ {
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_2));
bevt_7_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_8_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 912 */
 else  /* Line: 913 */ {
if (bevp_leni == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 916 */ {
bevp_leni = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevp_sizi = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 918 */
bevp_leni.bem_setValue_1(beva_endi);
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bem_setValue_1(beva_dstarti);
bevp_sizi.bem_addValue_1(bevp_leni);
bevt_10_tmpvar_phold = bevp_sizi.bem_greater_1(bevp_capacity);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 927 */ {
bevt_11_tmpvar_phold = bevp_sizi.bem_copy_0();
this.bem_capacitySet_1((BEC_4_3_MathInt) bevt_11_tmpvar_phold);
} /* Line: 928 */

         //source, sourceStart, dest, destStart, length
         Array.Copy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         bevt_12_tmpvar_phold = bevp_sizi.bem_greater_1(bevp_size);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 983 */ {
bevp_size = (BEC_4_3_MathInt) bevp_sizi.bem_copy_0();
} /* Line: 987 */
return this;
} /* Line: 989 */
} /*method end*/
public virtual BEC_4_6_TextString bem_substring_1(BEC_4_3_MathInt beva_starti) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sizeGet_0();
bevt_0_tmpvar_phold = this.bem_substring_2(beva_starti, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_substring_2(BEC_4_3_MathInt beva_starti, BEC_4_3_MathInt beva_endi) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_output_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevi_bytes.Length - 1);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_print_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevp_size.bevi_int);
stdout.WriteByte(10);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_echo_0() {
this.bem_output_0();
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_iteratorGet_0() {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_17_TextMultiByteIterator) (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_12_TextByteIterator bem_byteIteratorGet_0() {
BEC_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_12_TextByteIterator) (new BEC_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_17_TextMultiByteIterator) (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_12_TextByteIterator bem_biterGet_0() {
BEC_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_12_TextByteIterator) (new BEC_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_17_TextMultiByteIterator bem_mbiterGet_0() {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_17_TextMultiByteIterator) (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_serializeToString_0() {
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
if (beva_snw == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1111 */ {
this.bem_new_0();
} /* Line: 1112 */
 else  /* Line: 1113 */ {
bevt_2_tmpvar_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevo_29;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
this.bem_new_1(bevt_1_tmpvar_phold);
this.bem_addValue_1(beva_snw);
} /* Line: 1115 */
return this;
} /*method end*/
public override BEC_5_4_LogicBool bem_serializeContents_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_strip_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_strip_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_reverseBytes_0() {
BEC_4_3_MathInt bevl_vb = null;
BEC_4_3_MathInt bevl_ve = null;
BEC_4_3_MathInt bevl_b = null;
BEC_4_3_MathInt bevl_e = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevl_vb = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_ve = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_b = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = bevo_30;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpvar_phold);
while (true)
 /* Line: 1132 */ {
bevt_1_tmpvar_phold = bevl_e.bem_greater_1(bevl_b);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1132 */ {
this.bem_getInt_2(bevl_b, bevl_vb);
this.bem_getInt_2(bevl_e, bevl_ve);
this.bem_setInt_2(bevl_b, bevl_ve);
this.bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bem_incrementValue_0();
bevl_e.bem_decrementValue_0();
} /* Line: 1138 */
 else  /* Line: 1132 */ {
break;
} /* Line: 1132 */
} /* Line: 1132 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_vstringSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_vstring = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_sizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_size = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public virtual BEC_4_3_MathInt bem_leniGet_0() {
return bevp_leni;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_leniSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_leni = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_siziGet_0() {
return bevp_sizi;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_siziSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_sizi = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {176, 186, 190, 190, 204, 204, 204, 0, 0, 0, 205, 256, 256, 257, 257, 257, 259, 259, 0, 259, 0, 0, 260, 262, 266, 266, 267, 268, 268, 272, 272, 272, 272, 272, 272, 272, 276, 277, 281, 281, 281, 281, 282, 284, 286, 286, 287, 288, 290, 290, 291, 293, 294, 294, 294, 294, 294, 294, 295, 297, 297, 297, 302, 306, 310, 314, 325, 326, 327, 331, 331, 332, 332, 332, 333, 338, 338, 339, 340, 340, 344, 344, 345, 346, 346, 346, 346, 346, 348, 349, 350, 350, 350, 350, 350, 352, 356, 356, 356, 357, 358, 362, 363, 363, 0, 363, 363, 0, 0, 364, 364, 366, 366, 370, 370, 370, 370, 371, 371, 371, 372, 372, 373, 373, 375, 375, 379, 379, 0, 379, 379, 379, 0, 0, 380, 380, 382, 382, 386, 387, 387, 388, 389, 389, 0, 389, 389, 0, 0, 390, 390, 387, 393, 393, 397, 398, 398, 399, 400, 400, 400, 400, 0, 0, 0, 401, 401, 402, 398, 408, 408, 408, 412, 413, 413, 414, 415, 415, 415, 415, 0, 0, 0, 416, 416, 417, 413, 423, 423, 423, 427, 427, 427, 427, 432, 432, 433, 434, 434, 435, 434, 437, 437, 438, 442, 443, 443, 444, 444, 445, 446, 446, 447, 444, 449, 449, 453, 453, 453, 457, 457, 457, 467, 467, 467, 0, 0, 0, 496, 498, 509, 509, 509, 0, 0, 0, 539, 541, 545, 545, 545, 0, 0, 0, 546, 551, 551, 551, 0, 0, 0, 552, 557, 557, 558, 558, 560, 560, 643, 643, 649, 649, 649, 649, 649, 651, 651, 652, 652, 653, 653, 655, 659, 659, 659, 665, 665, 0, 665, 665, 0, 0, 0, 665, 665, 0, 0, 0, 665, 0, 0, 0, 665, 665, 0, 0, 0, 665, 665, 0, 0, 0, 665, 665, 665, 0, 0, 666, 669, 670, 671, 672, 673, 673, 675, 677, 677, 678, 679, 680, 683, 684, 685, 686, 686, 687, 689, 690, 691, 692, 692, 693, 694, 696, 697, 698, 699, 700, 703, 704, 706, 707, 710, 712, 716, 717, 718, 719, 720, 720, 721, 721, 722, 723, 725, 726, 726, 728, 732, 732, 732, 736, 736, 736, 736, 740, 748, 748, 0, 748, 0, 0, 749, 751, 752, 753, 754, 756, 758, 759, 760, 761, 761, 762, 763, 764, 765, 766, 766, 768, 768, 761, 772, 772, 773, 774, 775, 776, 779, 783, 783, 783, 784, 784, 784, 785, 785, 787, 787, 791, 791, 791, 792, 792, 792, 793, 793, 795, 795, 806, 806, 807, 807, 866, 866, 871, 871, 871, 875, 875, 875, 875, 876, 878, 880, 880, 880, 881, 881, 881, 882, 882, 882, 883, 886, 886, 911, 911, 0, 911, 911, 0, 911, 911, 0, 0, 0, 0, 912, 912, 912, 916, 916, 917, 918, 920, 921, 922, 924, 925, 927, 928, 928, 983, 987, 989, 994, 994, 994, 998, 998, 998, 998, 998, 1083, 1087, 1087, 1091, 1091, 1095, 1095, 1099, 1099, 1103, 1103, 1107, 1111, 1111, 1112, 1114, 1114, 1114, 1114, 1115, 1120, 1120, 1124, 1124, 1124, 1128, 1129, 1130, 1131, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {90, 91, 96, 97, 111, 116, 117, 119, 122, 126, 129, 139, 144, 145, 146, 147, 149, 154, 155, 158, 160, 163, 167, 169, 175, 176, 177, 178, 179, 189, 190, 191, 192, 193, 194, 195, 199, 200, 220, 221, 222, 223, 225, 228, 230, 235, 236, 237, 239, 240, 241, 242, 244, 245, 246, 247, 248, 249, 250, 252, 253, 254, 258, 261, 264, 268, 279, 280, 281, 288, 289, 291, 292, 293, 294, 301, 302, 303, 304, 305, 321, 322, 323, 325, 326, 327, 328, 329, 331, 332, 334, 335, 336, 337, 338, 340, 346, 347, 348, 349, 350, 360, 361, 366, 367, 370, 371, 373, 376, 380, 381, 383, 384, 395, 400, 401, 402, 404, 405, 406, 407, 412, 413, 414, 416, 417, 426, 431, 432, 435, 436, 441, 442, 445, 449, 450, 452, 453, 466, 467, 470, 472, 473, 474, 476, 479, 480, 482, 485, 489, 490, 492, 498, 499, 511, 512, 515, 517, 518, 519, 521, 522, 524, 527, 531, 534, 535, 536, 538, 549, 550, 551, 563, 564, 567, 569, 570, 571, 573, 574, 576, 579, 583, 586, 587, 588, 590, 601, 602, 603, 609, 610, 611, 612, 622, 623, 624, 625, 628, 630, 631, 637, 638, 639, 648, 649, 650, 651, 654, 656, 657, 658, 659, 660, 666, 667, 672, 673, 674, 679, 680, 681, 688, 689, 691, 693, 696, 700, 710, 712, 719, 720, 722, 724, 727, 731, 738, 740, 747, 748, 750, 752, 755, 759, 762, 771, 772, 774, 776, 779, 783, 786, 795, 796, 798, 799, 801, 802, 820, 821, 832, 833, 834, 835, 836, 837, 842, 843, 844, 845, 846, 848, 853, 854, 855, 897, 902, 903, 906, 911, 912, 915, 919, 922, 923, 925, 928, 932, 935, 937, 940, 944, 947, 948, 950, 953, 957, 960, 961, 963, 966, 970, 973, 974, 975, 977, 980, 984, 986, 987, 988, 989, 990, 991, 992, 993, 994, 996, 997, 998, 1002, 1004, 1005, 1007, 1008, 1010, 1012, 1013, 1014, 1015, 1016, 1017, 1019, 1021, 1024, 1026, 1027, 1028, 1032, 1033, 1039, 1041, 1044, 1050, 1061, 1062, 1063, 1064, 1067, 1072, 1073, 1074, 1075, 1076, 1082, 1084, 1085, 1087, 1092, 1093, 1094, 1100, 1101, 1102, 1103, 1106, 1129, 1134, 1135, 1138, 1140, 1143, 1147, 1149, 1150, 1151, 1153, 1156, 1158, 1159, 1160, 1161, 1164, 1166, 1167, 1168, 1170, 1172, 1173, 1176, 1177, 1180, 1186, 1187, 1189, 1191, 1194, 1196, 1200, 1209, 1214, 1215, 1217, 1218, 1219, 1221, 1222, 1224, 1225, 1234, 1239, 1240, 1242, 1243, 1244, 1246, 1247, 1249, 1250, 1262, 1267, 1268, 1269, 1283, 1284, 1289, 1290, 1291, 1306, 1307, 1308, 1309, 1311, 1314, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1329, 1330, 1348, 1349, 1351, 1354, 1355, 1357, 1360, 1361, 1363, 1366, 1370, 1373, 1377, 1378, 1379, 1382, 1387, 1388, 1389, 1391, 1392, 1393, 1394, 1395, 1396, 1398, 1399, 1404, 1406, 1408, 1414, 1415, 1416, 1423, 1424, 1425, 1426, 1427, 1443, 1448, 1449, 1453, 1454, 1458, 1459, 1463, 1464, 1468, 1469, 1472, 1479, 1484, 1485, 1488, 1489, 1490, 1491, 1492, 1498, 1499, 1504, 1505, 1506, 1515, 1516, 1517, 1518, 1519, 1522, 1524, 1525, 1526, 1527, 1528, 1529, 1538, 1542, 1545, 1549, 1552, 1555, 1559, 1562};
/* BEGIN LINEINFO 
capacitySet 1 176 90
assign 1 186 91
new 0 186 91
assign 1 190 96
new 0 190 96
new 1 190 97
assign 1 204 111
def 1 204 116
assign 1 204 117
equals 1 204 117
assign 1 0 119
assign 1 0 122
assign 1 0 126
return 1 205 129
assign 1 256 139
def 1 256 144
assign 1 257 145
new 0 257 145
assign 1 257 146
new 1 257 146
throw 1 257 147
assign 1 259 149
undef 1 259 154
assign 1 0 155
assign 1 259 158
greater 1 259 158
assign 1 0 160
assign 1 0 163
assign 1 260 167
copy 0 260 167
assign 1 262 169
assign 1 266 175
new 0 266 175
new 1 266 176
assign 1 267 177
new 0 267 177
assign 1 268 178
new 0 268 178
setHex 2 268 179
assign 1 272 189
new 0 272 189
assign 1 272 190
getCode 2 272 190
assign 1 272 191
new 0 272 191
assign 1 272 192
new 0 272 192
assign 1 272 193
new 0 272 193
assign 1 272 194
toString 3 272 194
return 1 272 195
assign 1 276 199
hexNew 1 276 199
setCode 2 277 200
assign 1 281 220
new 0 281 220
assign 1 281 221
stringGet 0 281 221
assign 1 281 222
sameType 1 281 222
assign 1 281 223
not 0 281 223
assign 1 282 225
toString 0 282 225
assign 1 284 228
assign 1 286 230
undef 1 286 235
assign 1 287 236
new 0 287 236
assign 1 288 237
new 0 288 237
assign 1 290 239
sizeGet 0 290 239
setValue 1 290 240
addValue 1 291 241
assign 1 293 242
lesser 1 293 242
assign 1 294 244
new 0 294 244
assign 1 294 245
add 1 294 245
assign 1 294 246
new 0 294 246
assign 1 294 247
multiply 1 294 247
assign 1 294 248
new 0 294 248
assign 1 294 249
divide 1 294 249
capacitySet 1 295 250
assign 1 297 252
new 0 297 252
assign 1 297 253
sizeGet 0 297 253
copyValue 4 297 254
return 1 302 258
return 1 306 261
addValue 1 310 264
write 1 314 268
assign 1 325 279
copy 0 325 279
clear 0 326 280
return 1 327 281
assign 1 331 288
new 0 331 288
assign 1 331 289
greater 1 331 289
assign 1 332 291
new 0 332 291
assign 1 332 292
new 0 332 292
setIntUnchecked 2 332 293
assign 1 333 294
new 0 333 294
assign 1 338 301
new 0 338 301
new 1 338 302
assign 1 339 303
new 0 339 303
assign 1 340 304
new 0 340 304
setCodeUnchecked 2 340 305
assign 1 344 321
new 0 344 321
assign 1 344 322
newlineGet 0 344 322
assign 1 345 323
ends 1 345 323
assign 1 346 325
new 0 346 325
assign 1 346 326
sizeGet 0 346 326
assign 1 346 327
subtract 1 346 327
assign 1 346 328
substring 2 346 328
return 1 346 329
assign 1 348 331
new 0 348 331
assign 1 349 332
ends 1 349 332
assign 1 350 334
new 0 350 334
assign 1 350 335
sizeGet 0 350 335
assign 1 350 336
subtract 1 350 336
assign 1 350 337
substring 2 350 337
return 1 350 338
return 1 352 340
assign 1 356 346
new 0 356 346
assign 1 356 347
add 1 356 347
assign 1 356 348
new 1 356 348
addValue 1 357 349
return 1 358 350
assign 1 362 360
find 1 362 360
assign 1 363 361
undef 1 363 366
assign 1 0 367
assign 1 363 370
new 0 363 370
assign 1 363 371
notEquals 1 363 371
assign 1 0 373
assign 1 0 376
assign 1 364 380
new 0 364 380
return 1 364 381
assign 1 366 383
new 0 366 383
return 1 366 384
assign 1 370 395
undef 1 370 400
assign 1 370 401
new 0 370 401
return 1 370 402
assign 1 371 404
sizeGet 0 371 404
assign 1 371 405
subtract 1 371 405
assign 1 371 406
find 2 371 406
assign 1 372 407
undef 1 372 412
assign 1 373 413
new 0 373 413
return 1 373 414
assign 1 375 416
new 0 375 416
return 1 375 417
assign 1 379 426
undef 1 379 431
assign 1 0 432
assign 1 379 435
find 1 379 435
assign 1 379 436
undef 1 379 441
assign 1 0 442
assign 1 0 445
assign 1 380 449
new 0 380 449
return 1 380 450
assign 1 382 452
new 0 382 452
return 1 382 453
assign 1 386 466
new 0 386 466
assign 1 387 467
new 0 387 467
assign 1 387 470
lesser 1 387 470
getInt 2 388 472
assign 1 389 473
new 0 389 473
assign 1 389 474
greater 1 389 474
assign 1 0 476
assign 1 389 479
new 0 389 479
assign 1 389 480
lesser 1 389 480
assign 1 0 482
assign 1 0 485
assign 1 390 489
new 0 390 489
return 1 390 490
incrementValue 0 387 492
assign 1 393 498
new 0 393 498
return 1 393 499
assign 1 397 511
new 0 397 511
assign 1 398 512
new 0 398 512
assign 1 398 515
lesser 1 398 515
getInt 2 399 517
assign 1 400 518
new 0 400 518
assign 1 400 519
greater 1 400 519
assign 1 400 521
new 0 400 521
assign 1 400 522
lesser 1 400 522
assign 1 0 524
assign 1 0 527
assign 1 0 531
assign 1 401 534
new 0 401 534
addValue 1 401 535
setIntUnchecked 2 402 536
incrementValue 0 398 538
assign 1 408 549
copy 0 408 549
assign 1 408 550
lowerValue 0 408 550
return 1 408 551
assign 1 412 563
new 0 412 563
assign 1 413 564
new 0 413 564
assign 1 413 567
lesser 1 413 567
getInt 2 414 569
assign 1 415 570
new 0 415 570
assign 1 415 571
greater 1 415 571
assign 1 415 573
new 0 415 573
assign 1 415 574
lesser 1 415 574
assign 1 0 576
assign 1 0 579
assign 1 0 583
assign 1 416 586
new 0 416 586
subtractValue 1 416 587
setIntUnchecked 2 417 588
incrementValue 0 413 590
assign 1 423 601
copy 0 423 601
assign 1 423 602
upperValue 0 423 602
return 1 423 603
assign 1 427 609
new 0 427 609
assign 1 427 610
split 1 427 610
assign 1 427 611
join 2 427 611
return 1 427 612
assign 1 432 622
new 0 432 622
assign 1 432 623
new 1 432 623
assign 1 433 624
mbiterGet 0 433 624
assign 1 434 625
new 0 434 625
assign 1 434 628
lesser 1 434 628
next 1 435 630
assign 1 434 631
increment 0 434 631
assign 1 437 637
next 1 437 637
assign 1 437 638
toString 0 437 638
return 1 438 639
assign 1 442 648
new 0 442 648
assign 1 443 649
new 0 443 649
setValue 1 443 650
assign 1 444 651
new 0 444 651
assign 1 444 654
lesser 1 444 654
getInt 2 445 656
assign 1 446 657
new 0 446 657
multiplyValue 1 446 658
addValue 1 447 659
incrementValue 0 444 660
assign 1 449 666
absValue 0 449 666
return 1 449 667
assign 1 453 672
new 0 453 672
assign 1 453 673
hashValue 1 453 673
return 1 453 674
assign 1 457 679
new 0 457 679
assign 1 457 680
getCode 2 457 680
return 1 457 681
assign 1 467 688
new 0 467 688
assign 1 467 689
greaterEquals 1 467 689
assign 1 467 691
greater 1 467 691
assign 1 0 693
assign 1 0 696
assign 1 0 700
return 1 496 710
return 1 498 712
assign 1 509 719
new 0 509 719
assign 1 509 720
greaterEquals 1 509 720
assign 1 509 722
greater 1 509 722
assign 1 0 724
assign 1 0 727
assign 1 0 731
return 1 539 738
return 1 541 740
assign 1 545 747
new 0 545 747
assign 1 545 748
greaterEquals 1 545 748
assign 1 545 750
greater 1 545 750
assign 1 0 752
assign 1 0 755
assign 1 0 759
setIntUnchecked 2 546 762
assign 1 551 771
new 0 551 771
assign 1 551 772
greaterEquals 1 551 772
assign 1 551 774
greater 1 551 774
assign 1 0 776
assign 1 0 779
assign 1 0 783
setCodeUnchecked 2 552 786
assign 1 557 795
new 0 557 795
assign 1 557 796
lesserEquals 1 557 796
assign 1 558 798
new 0 558 798
return 1 558 799
assign 1 560 801
new 0 560 801
return 1 560 802
assign 1 643 820
rfind 1 643 820
return 1 643 821
assign 1 649 832
copy 0 649 832
assign 1 649 833
reverseBytes 0 649 833
assign 1 649 834
copy 0 649 834
assign 1 649 835
reverseBytes 0 649 835
assign 1 649 836
find 1 649 836
assign 1 651 837
def 1 651 842
assign 1 652 843
sizeGet 0 652 843
addValue 1 652 844
assign 1 653 845
subtract 1 653 845
return 1 653 846
return 1 655 848
assign 1 659 853
new 0 659 853
assign 1 659 854
find 2 659 854
return 1 659 855
assign 1 665 897
undef 1 665 902
assign 1 0 903
assign 1 665 906
undef 1 665 911
assign 1 0 912
assign 1 0 915
assign 1 0 919
assign 1 665 922
new 0 665 922
assign 1 665 923
lesser 1 665 923
assign 1 0 925
assign 1 0 928
assign 1 0 932
assign 1 665 935
greaterEquals 1 665 935
assign 1 0 937
assign 1 0 940
assign 1 0 944
assign 1 665 947
sizeGet 0 665 947
assign 1 665 948
greater 1 665 948
assign 1 0 950
assign 1 0 953
assign 1 0 957
assign 1 665 960
new 0 665 960
assign 1 665 961
equals 1 665 961
assign 1 0 963
assign 1 0 966
assign 1 0 970
assign 1 665 973
sizeGet 0 665 973
assign 1 665 974
new 0 665 974
assign 1 665 975
equals 1 665 975
assign 1 0 977
assign 1 0 980
return 1 666 984
assign 1 669 986
assign 1 670 987
copy 0 670 987
assign 1 671 988
new 0 671 988
assign 1 672 989
new 0 672 989
assign 1 673 990
new 0 673 990
getInt 2 673 991
assign 1 675 992
sizeGet 0 675 992
assign 1 677 993
new 0 677 993
assign 1 677 994
greater 1 677 994
assign 1 678 996
new 0 678 996
assign 1 679 997
new 0 679 997
assign 1 680 998
new 0 680 998
assign 1 683 1002
lesser 1 683 1002
getInt 2 684 1004
assign 1 685 1005
equals 1 685 1005
assign 1 686 1007
new 0 686 1007
assign 1 686 1008
equals 1 686 1008
return 1 687 1010
setValue 1 689 1012
incrementValue 0 690 1013
setValue 1 691 1014
assign 1 692 1015
sizeGet 0 692 1015
addValue 1 692 1016
assign 1 693 1017
greater 1 693 1017
return 1 694 1019
assign 1 696 1021
new 0 696 1021
assign 1 697 1024
lesser 1 697 1024
getInt 2 698 1026
getInt 2 699 1027
assign 1 700 1028
notEquals 1 700 1028
incrementValue 0 703 1032
incrementValue 0 704 1033
assign 1 706 1039
equals 1 706 1039
return 1 707 1041
incrementValue 0 710 1044
return 1 712 1050
assign 1 716 1061
new 0 716 1061
assign 1 717 1062
new 0 717 1062
assign 1 718 1063
find 2 718 1063
assign 1 719 1064
sizeGet 0 719 1064
assign 1 720 1067
def 1 720 1072
assign 1 721 1073
substring 2 721 1073
addValue 1 721 1074
assign 1 722 1075
add 1 722 1075
assign 1 723 1076
find 2 723 1076
assign 1 725 1082
lesser 1 725 1082
assign 1 726 1084
substring 2 726 1084
addValue 1 726 1085
return 1 728 1087
assign 1 732 1092
new 0 732 1092
assign 1 732 1093
join 2 732 1093
return 1 732 1094
assign 1 736 1100
new 0 736 1100
assign 1 736 1101
lineSplitterGet 0 736 1101
assign 1 736 1102
tokenize 1 736 1102
return 1 736 1103
return 1 740 1106
assign 1 748 1129
undef 1 748 1134
assign 1 0 1135
assign 1 748 1138
otherType 1 748 1138
assign 1 0 1140
assign 1 0 1143
return 1 749 1147
assign 1 751 1149
assign 1 752 1150
sizeGet 0 752 1150
assign 1 753 1151
greater 1 753 1151
assign 1 754 1153
assign 1 756 1156
assign 1 758 1158
new 0 758 1158
assign 1 759 1159
new 0 759 1159
assign 1 760 1160
new 0 760 1160
assign 1 761 1161
new 0 761 1161
assign 1 761 1164
lesser 1 761 1164
getCode 2 762 1166
getCode 2 763 1167
assign 1 764 1168
notEquals 1 764 1168
assign 1 765 1170
greater 1 765 1170
assign 1 766 1172
new 0 766 1172
return 1 766 1173
assign 1 768 1176
new 0 768 1176
return 1 768 1177
incrementValue 0 761 1180
assign 1 772 1186
new 0 772 1186
assign 1 772 1187
equals 1 772 1187
assign 1 773 1189
greater 1 773 1189
assign 1 774 1191
new 0 774 1191
assign 1 775 1194
greater 1 775 1194
assign 1 776 1196
new 0 776 1196
return 1 779 1200
assign 1 783 1209
undef 1 783 1214
return 1 783 1215
assign 1 784 1217
compare 1 784 1217
assign 1 784 1218
new 0 784 1218
assign 1 784 1219
equals 1 784 1219
assign 1 785 1221
new 0 785 1221
return 1 785 1222
assign 1 787 1224
new 0 787 1224
return 1 787 1225
assign 1 791 1234
undef 1 791 1239
return 1 791 1240
assign 1 792 1242
compare 1 792 1242
assign 1 792 1243
new 0 792 1243
assign 1 792 1244
equals 1 792 1244
assign 1 793 1246
new 0 793 1246
return 1 793 1247
assign 1 795 1249
new 0 795 1249
return 1 795 1250
assign 1 806 1262
undef 1 806 1267
assign 1 807 1268
new 0 807 1268
return 1 807 1269
assign 1 866 1283
new 0 866 1283
return 1 866 1284
assign 1 871 1289
equals 1 871 1289
assign 1 871 1290
not 0 871 1290
return 1 871 1291
assign 1 875 1306
new 0 875 1306
assign 1 875 1307
stringGet 0 875 1307
assign 1 875 1308
sameType 1 875 1308
assign 1 875 1309
not 0 875 1309
assign 1 876 1311
toString 0 876 1311
assign 1 878 1314
assign 1 880 1316
sizeGet 0 880 1316
assign 1 880 1317
add 1 880 1317
assign 1 880 1318
new 1 880 1318
assign 1 881 1319
new 0 881 1319
assign 1 881 1320
new 0 881 1320
copyValue 4 881 1321
assign 1 882 1322
new 0 882 1322
assign 1 882 1323
sizeGet 0 882 1323
copyValue 4 882 1324
return 1 883 1325
assign 1 886 1329
new 0 886 1329
return 1 886 1330
assign 1 911 1348
new 0 911 1348
assign 1 911 1349
lesser 1 911 1349
assign 1 0 1351
assign 1 911 1354
sizeGet 0 911 1354
assign 1 911 1355
greater 1 911 1355
assign 1 0 1357
assign 1 911 1360
sizeGet 0 911 1360
assign 1 911 1361
greater 1 911 1361
assign 1 0 1363
assign 1 0 1366
assign 1 0 1370
assign 1 0 1373
assign 1 912 1377
new 0 912 1377
assign 1 912 1378
new 1 912 1378
throw 1 912 1379
assign 1 916 1382
undef 1 916 1387
assign 1 917 1388
new 0 917 1388
assign 1 918 1389
new 0 918 1389
setValue 1 920 1391
subtractValue 1 921 1392
assign 1 922 1393
setValue 1 924 1394
addValue 1 925 1395
assign 1 927 1396
greater 1 927 1396
assign 1 928 1398
copy 0 928 1398
capacitySet 1 928 1399
assign 1 983 1404
greater 1 983 1404
assign 1 987 1406
copy 0 987 1406
return 1 989 1408
assign 1 994 1414
sizeGet 0 994 1414
assign 1 994 1415
substring 2 994 1415
return 1 994 1416
assign 1 998 1423
subtract 1 998 1423
assign 1 998 1424
new 1 998 1424
assign 1 998 1425
new 0 998 1425
assign 1 998 1426
copyValue 4 998 1426
return 1 998 1427
output 0 1083 1443
assign 1 1087 1448
new 1 1087 1448
return 1 1087 1449
assign 1 1091 1453
new 1 1091 1453
return 1 1091 1454
assign 1 1095 1458
new 1 1095 1458
return 1 1095 1459
assign 1 1099 1463
new 1 1099 1463
return 1 1099 1464
assign 1 1103 1468
new 1 1103 1468
return 1 1103 1469
return 1 1107 1472
assign 1 1111 1479
undef 1 1111 1484
new 0 1112 1485
assign 1 1114 1488
sizeGet 0 1114 1488
assign 1 1114 1489
new 0 1114 1489
assign 1 1114 1490
add 1 1114 1490
new 1 1114 1491
addValue 1 1115 1492
assign 1 1120 1498
new 0 1120 1498
return 1 1120 1499
assign 1 1124 1504
new 0 1124 1504
assign 1 1124 1505
strip 1 1124 1505
return 1 1124 1506
assign 1 1128 1515
new 0 1128 1515
assign 1 1129 1516
new 0 1129 1516
assign 1 1130 1517
new 0 1130 1517
assign 1 1131 1518
new 0 1131 1518
assign 1 1131 1519
subtract 1 1131 1519
assign 1 1132 1522
greater 1 1132 1522
getInt 2 1133 1524
getInt 2 1134 1525
setInt 2 1135 1526
setInt 2 1136 1527
incrementValue 0 1137 1528
decrementValue 0 1138 1529
assign 1 0 1538
return 1 0 1542
assign 1 0 1545
return 1 0 1549
return 1 0 1552
assign 1 0 1555
return 1 0 1559
assign 1 0 1562
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 751851582: return bem_chomp_0();
case 1325881255: return bem_readBuffer_0();
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 1670870885: return bem_isInteger_0();
case 825000908: return bem_vstringSet_0();
case 813918656: return bem_vstringGet_0();
case 1163089440: return bem_upperValue_0();
case 856777406: return bem_clear_0();
case 347960120: return bem_readString_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 223231021: return bem_upper_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 1424677667: return bem_extractString_0();
case 855090856: return bem_multiByteIteratorGet_0();
case 1903477087: return bem_lowerValue_0();
case 70183026: return bem_output_0();
case 195899181: return bem_biterGet_0();
case 1010579589: return bem_open_0();
case 357005938: return bem_lower_0();
case 866536361: return bem_close_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 588679298: return bem_siziGet_0();
case 729571811: return bem_serializeToString_0();
case 1343944081: return bem_byteIteratorGet_0();
case 1881757495: return bem_strip_0();
case 139115914: return bem_splitLines_0();
case 1751843603: return bem_capacityGet_0();
case 1896696666: return bem_mbiterGet_0();
case 800915430: return bem_reverseBytes_0();
case 1354714650: return bem_copy_0();
case 85457677: return bem_leniGet_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 599761551: return bem_siziSet_1(bevd_0);
case 1274448085: return bem_find_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1143153819: return bem_codeNew_1(bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_4_3_MathInt) bevd_0);
case 1954998871: return bem_getHex_1((BEC_4_3_MathInt) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1406325780: return bem_writeTo_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2001811380: return bem_split_1((BEC_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1320649901: return bem_reverseFind_1((BEC_4_6_TextString) bevd_0);
case 636254476: return bem_getPoint_1((BEC_4_3_MathInt) bevd_0);
case 1958502700: return bem_greater_1((BEC_4_6_TextString) bevd_0);
case 1250088509: return bem_substring_1((BEC_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1603004369: return bem_write_1(bevd_0);
case 1489442332: return bem_begins_1((BEC_4_6_TextString) bevd_0);
case 74375424: return bem_leniSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 1298743126: return bem_ends_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 340923733: return bem_getCode_1((BEC_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 825000909: return bem_vstringSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1412717737: return bem_compare_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1274753013: return bem_hashValue_1((BEC_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 1116723741: return bem_rfind_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 477101321: return bem_hexNew_1((BEC_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1395074208: return bem_setInt_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 2110339634: return bem_setCodeUnchecked_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1154529699: return bem_join_2((BEC_4_6_TextString) bevd_0, bevd_1);
case 889715578: return bem_swap_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1393886412: return bem_setHex_2((BEC_4_3_MathInt) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 761715532: return bem_setIntUnchecked_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1250088508: return bem_substring_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 126306658: return bem_setCode_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1274448084: return bem_find_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 340923734: return bem_getCode_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1956186668: return bem_getInt_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) {
switch (callHash) {
case 391213135: return bem_copyValue_4((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_4_6_TextString();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_4_6_TextString.bevs_inst = (BEC_4_6_TextString)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_4_6_TextString.bevs_inst;
}
}
}
