namespace be.BEL_4_Base {

using System;
using System.IO;
using System.Collections.Generic;
    /* IO:File: source/extended/EcPlat.be */
public class BEC_2_4_17_IOFileDirectoryIterator : BEC_6_6_SystemObject {
public BEC_2_4_17_IOFileDirectoryIterator() { }
static BEC_2_4_17_IOFileDirectoryIterator() { }

   
    public IEnumerator<string> bevi_dir;
    
   private static byte[] becc_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static new BEC_2_4_17_IOFileDirectoryIterator bevs_inst;
public BEC_2_4_IOFile bevp_dir;
public BEC_5_4_LogicBool bevp_opened;
public BEC_5_4_LogicBool bevp_closed;
public BEC_2_4_IOFile bevp_current;
public override BEC_6_6_SystemObject bem_new_0() {
bevp_opened = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_closed = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_current = null;
return this;
} /*method end*/
public virtual BEC_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_4_IOFile beva__dir) {
this.bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public virtual BEC_2_4_17_IOFileDirectoryIterator bem_open_0() {
BEC_4_6_TextString bevl_path = null;
BEC_4_6_TextString bevl_newName = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_1_tmpvar_phold = null;
BEC_6_9_SystemException bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_9_SystemException bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_6_9_SystemException bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
if (bevp_dir == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 490 */ {
bevt_1_tmpvar_phold = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_tmpvar_phold.bem_toString_0();
} /* Line: 491 */
 else  /* Line: 493 */ {
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(33, bels_0));
bevt_2_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_3_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_2_tmpvar_phold);
} /* Line: 494 */
if (bevp_closed.bevi_bool) /* Line: 497 */ {
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(64, bels_1));
bevt_4_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 499 */
if (bevp_opened.bevi_bool) /* Line: 501 */ {
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_2));
bevt_6_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_7_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_6_tmpvar_phold);
} /* Line: 502 */

      bevi_dir = Directory.EnumerateFileSystemEntries(bevl_path.bems_toCsString(), "*", SearchOption.TopDirectoryOnly).GetEnumerator();
      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 523 */ {
bevp_opened = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_4_IOFile) (new BEC_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 526 */
 else  /* Line: 527 */ {
bevp_opened = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_closed = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 530 */
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_hasNextGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_closed.bevi_bool) /* Line: 535 */ {
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /* Line: 535 */
bevt_1_tmpvar_phold = bevp_opened.bem_not_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 536 */ {
this.bem_open_0();
} /* Line: 536 */
if (bevp_current == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
return bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_IOFile bem_nextGet_0() {
BEC_2_4_IOFile bevl_toRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_closed.bevi_bool) /* Line: 541 */ {
return null;
} /* Line: 541 */
bevt_0_tmpvar_phold = bevp_opened.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 542 */ {
this.bem_open_0();
} /* Line: 542 */
bevl_toRet = bevp_current;
this.bem_advance_0();
return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_17_IOFileDirectoryIterator bem_advance_0() {
BEC_4_6_TextString bevl_newName = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_closed.bevi_bool) /* Line: 552 */ {
return this;
} /* Line: 552 */
bevt_0_tmpvar_phold = bevp_opened.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 553 */ {
return this;
} /* Line: 553 */
if (bevp_current == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 554 */ {
return this;
} /* Line: 554 */

      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 570 */ {
bevp_opened = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_4_IOFile) (new BEC_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 572 */
 else  /* Line: 573 */ {
bevp_opened = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_closed = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 576 */
return this;
} /*method end*/
public virtual BEC_2_4_17_IOFileDirectoryIterator bem_close_0() {

      bevi_dir.Dispose();
      bevi_dir = null;
      return this;
} /*method end*/
public virtual BEC_2_4_IOFile bem_dirGet_0() {
return bevp_dir;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_dirSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dir = (BEC_2_4_IOFile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_openedGet_0() {
return bevp_opened;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_openedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_opened = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_closedGet_0() {
return bevp_closed;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_closedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closed = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_IOFile bem_currentGet_0() {
return bevp_current;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_currentSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_current = (BEC_2_4_IOFile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {473, 474, 475, 481, 482, 490, 490, 491, 491, 494, 494, 494, 499, 499, 499, 502, 502, 502, 523, 523, 525, 526, 529, 530, 535, 535, 536, 536, 537, 537, 541, 542, 542, 543, 544, 545, 552, 553, 553, 554, 554, 554, 570, 570, 571, 572, 574, 575, 576, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 27, 31, 32, 47, 52, 53, 54, 57, 58, 59, 62, 63, 64, 67, 68, 69, 76, 81, 82, 83, 86, 87, 96, 97, 99, 101, 103, 108, 114, 116, 118, 120, 121, 122, 130, 132, 134, 136, 141, 142, 148, 153, 154, 155, 158, 159, 160, 171, 174, 178, 181, 185, 188, 192, 195};
/* BEGIN LINEINFO 
assign 1 473 25
new 0 473 25
assign 1 474 26
new 0 474 26
assign 1 475 27
new 0 481 31
assign 1 482 32
assign 1 490 47
def 1 490 52
assign 1 491 53
pathGet 0 491 53
assign 1 491 54
toString 0 491 54
assign 1 494 57
new 0 494 57
assign 1 494 58
new 1 494 58
throw 1 494 59
assign 1 499 62
new 0 499 62
assign 1 499 63
new 1 499 63
throw 1 499 64
assign 1 502 67
new 0 502 67
assign 1 502 68
new 1 502 68
throw 1 502 69
assign 1 523 76
def 1 523 81
assign 1 525 82
new 0 525 82
assign 1 526 83
apNew 1 526 83
assign 1 529 86
new 0 529 86
assign 1 530 87
new 0 530 87
assign 1 535 96
new 0 535 96
return 1 535 97
assign 1 536 99
not 0 536 99
open 0 536 101
assign 1 537 103
def 1 537 108
return 1 537 108
return 1 541 114
assign 1 542 116
not 0 542 116
open 0 542 118
assign 1 543 120
advance 0 544 121
return 1 545 122
return 1 552 130
assign 1 553 132
not 0 553 132
return 1 553 134
assign 1 554 136
undef 1 554 141
return 1 554 142
assign 1 570 148
def 1 570 153
assign 1 571 154
new 0 571 154
assign 1 572 155
apNew 1 572 155
assign 1 574 158
new 0 574 158
assign 1 575 159
new 0 575 159
assign 1 576 160
return 1 0 171
assign 1 0 174
return 1 0 178
assign 1 0 181
return 1 0 185
assign 1 0 188
return 1 0 192
assign 1 0 195
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1010579589: return bem_open_0();
case 513687198: return bem_openedGet_0();
case 1774940957: return bem_toString_0();
case 1354714650: return bem_copy_0();
case 866536361: return bem_close_0();
case 1446310798: return bem_currentGet_0();
case 218396922: return bem_dirGet_0();
case 809133133: return bem_advance_0();
case 1308786538: return bem_echo_0();
case 108485850: return bem_hasNextGet_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1194623572: return bem_nextGet_0();
case 786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case 617762683: return bem_closedGet_0();
case 1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 845792839: return bem_iteratorGet_0();
case 314718434: return bem_print_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 524769451: return bem_openedSet_1(bevd_0);
case 628844936: return bem_closedSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 229479175: return bem_dirSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_IOFile) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_2_4_17_IOFileDirectoryIterator();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_2_4_17_IOFileDirectoryIterator.bevs_inst = (BEC_2_4_17_IOFileDirectoryIterator)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_17_IOFileDirectoryIterator.bevs_inst;
}
}
}
