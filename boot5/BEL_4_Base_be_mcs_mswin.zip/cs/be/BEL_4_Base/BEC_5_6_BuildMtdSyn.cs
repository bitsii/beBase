namespace be.BEL_4_Base {
/* IO:File: source/build/Syns.be */
public class BEC_5_6_BuildMtdSyn : BEC_6_6_SystemObject {
public BEC_5_6_BuildMtdSyn() { }
static BEC_5_6_BuildMtdSyn() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x74,0x64,0x53,0x79,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_0, 6));
private static byte[] bels_1 = {0x6E,0x61,0x6D,0x65};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_1, 4));
private static byte[] bels_2 = {0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 7));
private static byte[] bels_3 = {0x6E,0x75,0x6D,0x61,0x72,0x67,0x73};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_3, 7));
private static byte[] bels_4 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bels_5 = {0x6C,0x61,0x73,0x74,0x44,0x65,0x66};
private static byte[] bels_6 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bels_7 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_8 = {0x69,0x73,0x47,0x65,0x6E,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_9 = {0x72,0x73,0x79,0x6E};
private static byte[] bels_10 = {0x76,0x61,0x72};
private static byte[] bels_11 = {0x61,0x72,0x67,0x54,0x79,0x70,0x65};
private static byte[] bels_12 = {0x76,0x61,0x72};
public static new BEC_5_6_BuildMtdSyn bevs_inst;
public BEC_4_3_MathInt bevp_hpos;
public BEC_4_3_MathInt bevp_mtdx;
public BEC_4_3_MathInt bevp_numargs;
public BEC_4_6_TextString bevp_name;
public BEC_4_6_TextString bevp_orgName;
public BEC_5_4_LogicBool bevp_isGenAccessor;
public BEC_9_5_ContainerArray bevp_argSyns;
public BEC_5_8_BuildNamePath bevp_origin;
public BEC_5_8_BuildNamePath bevp_declaration;
public BEC_5_4_LogicBool bevp_lastDef;
public BEC_5_4_LogicBool bevp_isOverride;
public BEC_5_4_LogicBool bevp_isFinal;
public BEC_4_6_TextString bevp_propertyName;
public BEC_5_6_BuildVarSyn bevp_rsyn;
public virtual BEC_5_6_BuildMtdSyn bem_new_2(BEC_6_6_SystemObject beva_snode, BEC_6_6_SystemObject beva__origin) {
BEC_6_6_SystemObject bevl_s = null;
BEC_6_6_SystemObject bevl_args = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_5_6_BuildVarSyn bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
bevl_s = beva_snode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_numargs = (BEC_4_3_MathInt) bevl_s.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevp_name = (BEC_4_6_TextString) bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_orgName = (BEC_4_6_TextString) bevl_s.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevp_isGenAccessor = (BEC_5_4_LogicBool) bevl_s.bemd_0(1714571098, BEL_4_Base.bevn_isGenAccessorGet_0);
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevp_numargs.bem_add_1(bevt_1_tmpvar_phold);
bevp_argSyns = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
bevp_origin = (BEC_5_8_BuildNamePath) beva__origin;
bevp_lastDef = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_isOverride = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isFinal = (BEC_5_4_LogicBool) bevl_s.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
bevt_3_tmpvar_phold = bevl_s.bemd_0(1041978190, BEL_4_Base.bevn_propertyGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 453 */ {
bevt_4_tmpvar_phold = bevl_s.bemd_0(1041978190, BEL_4_Base.bevn_propertyGet_0);
bevp_propertyName = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
} /* Line: 454 */
bevt_6_tmpvar_phold = bevl_s.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 456 */ {
bevt_7_tmpvar_phold = bevl_s.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevp_rsyn = (BEC_5_6_BuildVarSyn) (new BEC_5_6_BuildVarSyn()).bem_varNew_1((BEC_5_3_BuildVar) bevt_7_tmpvar_phold);
} /* Line: 457 */
bevt_9_tmpvar_phold = beva_snode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_args = bevt_8_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 462 */ {
bevt_11_tmpvar_phold = bevp_argSyns.bem_lengthGet_0();
bevt_10_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_11_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 462 */ {
bevt_14_tmpvar_phold = bevl_args.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_12_tmpvar_phold = (BEC_5_6_BuildVarSyn) (new BEC_5_6_BuildVarSyn()).bem_varNew_1((BEC_5_3_BuildVar) bevt_13_tmpvar_phold);
bevp_argSyns.bem_put_2((BEC_4_3_MathInt) bevl_i, bevt_12_tmpvar_phold);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 462 */
 else  /* Line: 462 */ {
break;
} /* Line: 462 */
} /* Line: 462 */
return this;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
BEC_6_6_SystemObject bevl_nl = null;
BEC_6_6_SystemObject bevl_toRet = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_arg = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevl_nl = bevt_1_tmpvar_phold.bem_newlineGet_0();
bevt_14_tmpvar_phold = bevo_1;
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevl_nl);
bevt_15_tmpvar_phold = bevo_2;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevl_nl);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_name);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevl_nl);
bevt_16_tmpvar_phold = bevo_3;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_16_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevl_nl);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_orgName);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevl_nl);
bevt_17_tmpvar_phold = bevo_4;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevl_nl);
bevt_18_tmpvar_phold = bevp_numargs.bem_toString_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_18_tmpvar_phold);
bevl_toRet = bevt_2_tmpvar_phold.bem_add_1(bevl_nl);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_4));
bevt_21_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_22_tmpvar_phold);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_23_tmpvar_phold = bevp_origin.bem_toString_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpvar_phold);
bevl_toRet = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_27_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_5));
bevt_26_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_28_tmpvar_phold = bevp_lastDef.bem_toString_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_28_tmpvar_phold);
bevl_toRet = bevt_24_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_6));
bevt_31_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_32_tmpvar_phold);
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_33_tmpvar_phold = bevp_isFinal.bem_toString_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_33_tmpvar_phold);
bevl_toRet = bevt_29_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
if (bevp_propertyName == null) {
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 474 */ {
bevt_38_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_7));
bevt_37_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_38_tmpvar_phold);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_propertyName);
bevl_toRet = bevt_35_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 475 */
bevt_42_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_8));
bevt_41_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_42_tmpvar_phold);
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_43_tmpvar_phold = bevp_isGenAccessor.bem_toString_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_43_tmpvar_phold);
bevl_toRet = bevt_39_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_45_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_9));
bevt_44_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_45_tmpvar_phold);
bevl_toRet = bevt_44_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
if (bevp_rsyn == null) {
bevt_46_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_47_tmpvar_phold = bevp_rsyn.bem_isTypedGet_0();
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 479 */
 else  /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 479 */ {
bevt_50_tmpvar_phold = bevp_rsyn.bem_namepathGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_toString_0();
bevt_48_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_49_tmpvar_phold);
bevl_toRet = bevt_48_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 480 */
 else  /* Line: 481 */ {
bevt_52_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_10));
bevt_51_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_52_tmpvar_phold);
bevl_toRet = bevt_51_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 482 */
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 484 */ {
bevt_54_tmpvar_phold = bevp_argSyns.bem_lengthGet_0();
bevt_53_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_54_tmpvar_phold);
if (bevt_53_tmpvar_phold != null && bevt_53_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_53_tmpvar_phold).bevi_bool) /* Line: 484 */ {
bevl_arg = bevp_argSyns.bem_get_1((BEC_4_3_MathInt) bevl_i);
bevt_56_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_11));
bevt_55_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_56_tmpvar_phold);
bevl_toRet = bevt_55_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_57_tmpvar_phold = bevl_arg.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_57_tmpvar_phold != null && bevt_57_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_57_tmpvar_phold).bevi_bool) /* Line: 488 */ {
bevt_60_tmpvar_phold = bevl_arg.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_58_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_59_tmpvar_phold);
bevl_toRet = bevt_58_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 489 */
 else  /* Line: 490 */ {
bevt_62_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_12));
bevt_61_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_62_tmpvar_phold);
bevl_toRet = bevt_61_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 491 */
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 484 */
 else  /* Line: 484 */ {
break;
} /* Line: 484 */
} /* Line: 484 */
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_getEmitReturnType_2(BEC_5_8_BuildClassSyn beva_csyn, BEC_5_5_BuildBuild beva_build) {
BEC_5_4_LogicBool bevl_covariantReturns = null;
BEC_5_10_BuildEmitCommon bevl_ec = null;
BEC_5_8_BuildClassSyn bevl_cs = null;
BEC_5_6_BuildMtdSyn bevl_ms = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_3_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_6_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_7_tmpvar_phold = null;
BEC_5_6_BuildVarSyn bevt_8_tmpvar_phold = null;
bevl_covariantReturns = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_ec = beva_build.bem_emitCommonGet_0();
if (bevl_ec == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 500 */ {
bevl_covariantReturns = (BEC_5_4_LogicBool) bevl_ec.bem_covariantReturnsGet_0();
} /* Line: 501 */
if (bevp_rsyn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 503 */ {
if (bevl_covariantReturns.bevi_bool) /* Line: 504 */ {
bevt_2_tmpvar_phold = bevp_rsyn.bem_isSelfGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 505 */ {
bevt_3_tmpvar_phold = beva_csyn.bem_namepathGet_0();
return bevt_3_tmpvar_phold;
} /* Line: 506 */
 else  /* Line: 507 */ {
bevt_4_tmpvar_phold = bevp_rsyn.bem_namepathGet_0();
return bevt_4_tmpvar_phold;
} /* Line: 508 */
} /* Line: 505 */
 else  /* Line: 510 */ {
bevt_5_tmpvar_phold = bevp_rsyn.bem_isSelfGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 511 */ {
return bevp_declaration;
} /* Line: 512 */
 else  /* Line: 513 */ {
bevl_cs = beva_build.bem_getSynNp_1(bevp_declaration);
bevt_6_tmpvar_phold = bevl_cs.bem_mtdMapGet_0();
bevl_ms = (BEC_5_6_BuildMtdSyn) bevt_6_tmpvar_phold.bem_get_1(bevp_name);
bevt_8_tmpvar_phold = bevl_ms.bem_rsynGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_namepathGet_0();
return bevt_7_tmpvar_phold;
} /* Line: 516 */
} /* Line: 511 */
} /* Line: 504 */
return null;
} /*method end*/
public virtual BEC_4_3_MathInt bem_hposGet_0() {
return bevp_hpos;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_hposSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_hpos = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_mtdxGet_0() {
return bevp_mtdx;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_mtdxSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mtdx = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_numargsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_numargs = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_name = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_orgNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_orgName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isGenAccessorGet_0() {
return bevp_isGenAccessor;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isGenAccessorSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isGenAccessor = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_argSynsGet_0() {
return bevp_argSyns;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_argSynsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_argSyns = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_originGet_0() {
return bevp_origin;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_originSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_origin = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_declarationGet_0() {
return bevp_declaration;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_declarationSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_declaration = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_lastDefGet_0() {
return bevp_lastDef;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastDefSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastDef = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isOverrideGet_0() {
return bevp_isOverride;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isOverrideSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isOverride = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isFinalSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isFinal = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_propertyNameGet_0() {
return bevp_propertyName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_propertyNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_propertyName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_6_BuildVarSyn bem_rsynGet_0() {
return bevp_rsyn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_rsynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rsyn = (BEC_5_6_BuildVarSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {436, 442, 443, 444, 445, 446, 448, 450, 451, 452, 453, 454, 456, 457, 461, 462, 463, 462, 469, 470, 471, 472, 473, 474, 475, 477, 478, 479, 0, 480, 482, 484, 485, 487, 488, 489, 491, 484, 494, 498, 499, 500, 501, 503, 505, 506, 508, 511, 512, 514, 515, 516, 520, 0};
public static new int[] bevs_smnlec
 = new int[] {60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60};
/* BEGIN LINEINFO 
assign 1 436 60
heldGet 0 436 60
assign 1 442 60
numargsGet 0 442 60
assign 1 443 60
nameGet 0 443 60
assign 1 444 60
orgNameGet 0 444 60
assign 1 445 60
isGenAccessorGet 0 445 60
assign 1 446 60
new 0 446 60
assign 1 446 60
add 1 446 60
assign 1 446 60
new 1 446 60
assign 1 448 60
assign 1 450 60
new 0 450 60
assign 1 451 60
new 0 451 60
assign 1 452 60
isFinalGet 0 452 60
assign 1 453 60
propertyGet 0 453 60
assign 1 453 60
def 1 453 60
assign 1 454 60
propertyGet 0 454 60
assign 1 454 60
nameGet 0 454 60
assign 1 456 60
rtypeGet 0 456 60
assign 1 456 60
def 1 456 60
assign 1 457 60
rtypeGet 0 457 60
assign 1 457 60
varNew 1 457 60
assign 1 461 60
containedGet 0 461 60
assign 1 461 60
firstGet 0 461 60
assign 1 461 60
containedGet 0 461 60
assign 1 462 60
new 0 462 60
assign 1 462 60
lengthGet 0 462 60
assign 1 462 60
lesser 1 462 60
assign 1 463 60
get 1 463 60
assign 1 463 60
heldGet 0 463 60
assign 1 463 60
varNew 1 463 60
put 2 463 60
assign 1 462 60
increment 0 462 60
assign 1 469 60
new 0 469 60
assign 1 469 60
newlineGet 0 469 60
assign 1 470 60
new 0 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
new 0 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
new 0 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
new 0 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
toString 0 470 60
assign 1 470 60
add 1 470 60
assign 1 470 60
add 1 470 60
assign 1 471 60
new 0 471 60
assign 1 471 60
add 1 471 60
assign 1 471 60
add 1 471 60
assign 1 471 60
toString 0 471 60
assign 1 471 60
add 1 471 60
assign 1 471 60
add 1 471 60
assign 1 472 60
new 0 472 60
assign 1 472 60
add 1 472 60
assign 1 472 60
add 1 472 60
assign 1 472 60
toString 0 472 60
assign 1 472 60
add 1 472 60
assign 1 472 60
add 1 472 60
assign 1 473 60
new 0 473 60
assign 1 473 60
add 1 473 60
assign 1 473 60
add 1 473 60
assign 1 473 60
toString 0 473 60
assign 1 473 60
add 1 473 60
assign 1 473 60
add 1 473 60
assign 1 474 60
def 1 474 60
assign 1 475 60
new 0 475 60
assign 1 475 60
add 1 475 60
assign 1 475 60
add 1 475 60
assign 1 475 60
add 1 475 60
assign 1 475 60
add 1 475 60
assign 1 477 60
new 0 477 60
assign 1 477 60
add 1 477 60
assign 1 477 60
add 1 477 60
assign 1 477 60
toString 0 477 60
assign 1 477 60
add 1 477 60
assign 1 477 60
add 1 477 60
assign 1 478 60
new 0 478 60
assign 1 478 60
add 1 478 60
assign 1 478 60
add 1 478 60
assign 1 479 60
def 1 479 60
assign 1 479 60
isTypedGet 0 479 60
assign 1 0 60
assign 1 0 60
assign 1 0 60
assign 1 480 60
namepathGet 0 480 60
assign 1 480 60
toString 0 480 60
assign 1 480 60
add 1 480 60
assign 1 480 60
add 1 480 60
assign 1 482 60
new 0 482 60
assign 1 482 60
add 1 482 60
assign 1 482 60
add 1 482 60
assign 1 484 60
new 0 484 60
assign 1 484 60
lengthGet 0 484 60
assign 1 484 60
lesser 1 484 60
assign 1 485 60
get 1 485 60
assign 1 487 60
new 0 487 60
assign 1 487 60
add 1 487 60
assign 1 487 60
add 1 487 60
assign 1 488 60
isTypedGet 0 488 60
assign 1 489 60
namepathGet 0 489 60
assign 1 489 60
toString 0 489 60
assign 1 489 60
add 1 489 60
assign 1 489 60
add 1 489 60
assign 1 491 60
new 0 491 60
assign 1 491 60
add 1 491 60
assign 1 491 60
add 1 491 60
assign 1 484 60
increment 0 484 60
return 1 494 60
assign 1 498 60
new 0 498 60
assign 1 499 60
emitCommonGet 0 499 60
assign 1 500 60
def 1 500 60
assign 1 501 60
covariantReturnsGet 0 501 60
assign 1 503 60
def 1 503 60
assign 1 505 60
isSelfGet 0 505 60
assign 1 506 60
namepathGet 0 506 60
return 1 506 60
assign 1 508 60
namepathGet 0 508 60
return 1 508 60
assign 1 511 60
isSelfGet 0 511 60
return 1 512 60
assign 1 514 60
getSynNp 1 514 60
assign 1 515 60
mtdMapGet 0 515 60
assign 1 515 60
get 1 515 60
assign 1 516 60
rsynGet 0 516 60
assign 1 516 60
namepathGet 0 516 60
return 1 516 60
return 1 520 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
return 1 0 60
assign 1 0 60
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1820417453: return bem_create_0();
case 1187343513: return bem_propertyNameGet_0();
case 1211273660: return bem_nameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 1376225844: return bem_mtdxGet_0();
case 786424307: return bem_tagGet_0();
case 82450415: return bem_isOverrideGet_0();
case 845792839: return bem_iteratorGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1707345409: return bem_originGet_0();
case 1714571098: return bem_isGenAccessorGet_0();
case 1081412016: return bem_many_0();
case 1391492296: return bem_orgNameGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 287367803: return bem_isFinalGet_0();
case 287040793: return bem_hashGet_0();
case 729571811: return bem_serializeToString_0();
case 1900010001: return bem_rsynGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1354714650: return bem_copy_0();
case 104713553: return bem_new_0();
case 548714012: return bem_numargsGet_0();
case 896461779: return bem_declarationGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 815066086: return bem_argSynsGet_0();
case 314718434: return bem_print_0();
case 1719265275: return bem_hposGet_0();
case 1100651208: return bem_lastDefGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1911092254: return bem_rsynSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1718427662: return bem_originSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 826148339: return bem_argSynsSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 71368162: return bem_isOverrideSet_1(bevd_0);
case 1365143591: return bem_mtdxSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1730347528: return bem_hposSet_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case 1380410043: return bem_orgNameSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 537631759: return bem_numargsSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1089568955: return bem_lastDefSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 1725653351: return bem_isGenAccessorSet_1(bevd_0);
case 1176261260: return bem_propertyNameSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 885379526: return bem_declarationSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case 583049050: return bem_getEmitReturnType_2((BEC_5_8_BuildClassSyn) bevd_0, (BEC_5_5_BuildBuild) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_6_BuildMtdSyn();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_6_BuildMtdSyn.bevs_inst = (BEC_5_6_BuildMtdSyn)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_6_BuildMtdSyn.bevs_inst;
}
}
}
