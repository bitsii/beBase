namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet : BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
static BEC_2_9_3_ContainerSet() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_2_9_3_ContainerSet bevs_inst;
public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_0;
if (bevp_size.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 234 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_1;
if (bevp_size.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /* Line: 241 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_3_21_ContainerSetSerializationIterator) (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
 /* Line: 259 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_4_tmpany_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpany_phold = this.bem_innerPut_4(bevt_4_tmpany_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 263 */
} /* Line: 262 */
} /* Line: 261 */
 else  /* Line: 259 */ {
break;
} /* Line: 259 */
} /* Line: 259 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpany_phold = bevo_2;
bevl_nslots = bevt_0_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevl_ninner = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 274 */ {
bevt_4_tmpany_phold = this.bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 274 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
} /* Line: 276 */
 else  /* Line: 274 */ {
break;
} /* Line: 274 */
} /* Line: 274 */
return bevl_ninner;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_other == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_4_tmpany_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpany_phold = this.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int != bevt_5_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 282 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 283 */
bevt_0_tmpany_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 285 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevl_i = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_9_tmpany_phold = beva_other.bem_has_1(bevl_i);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /* Line: 286 */
} /* Line: 286 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 293 */ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpany_phold = bevo_3;
if (bevl_hval.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 295 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 296 */
} /* Line: 295 */
 else  /* Line: 298 */ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(-449328306, BEL_4_Base.bevn_hvalGet_0);
} /* Line: 299 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 303 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 305 */ {
if (beva_inode == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_6_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_tmpany_phold.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpany_phold);
} /* Line: 307 */
 else  /* Line: 308 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 309 */
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 312 */
 else  /* Line: 305 */ {
bevt_10_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_9_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 313 */ {
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /* Line: 314 */
 else  /* Line: 305 */ {
bevt_13_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpany_phold, beva_k);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 315 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_14_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_14_tmpany_phold;
} /* Line: 319 */
 else  /* Line: 320 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevt_16_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_16_tmpany_phold;
} /* Line: 323 */
} /* Line: 322 */
} /* Line: 305 */
} /* Line: 305 */
} /* Line: 305 */
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 330 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 333 */ {
bevt_3_tmpany_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 333 */ {
bevl_slt = (BEC_2_9_4_ContainerList) this.bem_rehash_1(bevl_slt);
} /* Line: 334 */
 else  /* Line: 333 */ {
break;
} /* Line: 333 */
} /* Line: 333 */
bevp_slots = bevl_slt;
} /* Line: 336 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 338 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 339 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpany_phold = bevo_4;
if (bevl_hval.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 347 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 348 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 352 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 354 */ {
return null;
} /* Line: 355 */
 else  /* Line: 354 */ {
bevt_5_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_4_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 356 */ {
return null;
} /* Line: 357 */
 else  /* Line: 354 */ {
bevt_7_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpany_phold, beva_k);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 358 */ {
bevt_8_tmpany_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpany_phold;
} /* Line: 359 */
 else  /* Line: 360 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 362 */ {
return null;
} /* Line: 363 */
} /* Line: 362 */
} /* Line: 354 */
} /* Line: 354 */
} /* Line: 354 */
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpany_phold = bevo_5;
if (bevl_hval.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 374 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 378 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 380 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /* Line: 381 */
 else  /* Line: 380 */ {
bevt_6_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_5_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /* Line: 383 */
 else  /* Line: 380 */ {
bevt_9_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpany_phold, beva_k);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 384 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 385 */
 else  /* Line: 386 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /* Line: 389 */
} /* Line: 388 */
} /* Line: 380 */
} /* Line: 380 */
} /* Line: 380 */
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpany_phold = bevo_6;
if (bevl_hval.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 400 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 401 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 405 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 407 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 408 */
 else  /* Line: 407 */ {
bevt_7_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_6_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 409 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 410 */
 else  /* Line: 407 */ {
bevt_10_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpany_phold, beva_k);
if (bevt_9_tmpany_phold != null && bevt_9_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 415 */ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 417 */ {
bevt_15_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_14_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 417 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 417 */ {
bevt_16_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_16_tmpany_phold;
} /* Line: 418 */
 else  /* Line: 419 */ {
bevt_18_tmpany_phold = bevo_7;
bevt_17_tmpany_phold = bevl_sl.bem_subtract_1(bevt_18_tmpany_phold);
bevl_slt.bem_put_2(bevt_17_tmpany_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 421 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 423 */
 else  /* Line: 415 */ {
break;
} /* Line: 415 */
} /* Line: 415 */
bevt_19_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_19_tmpany_phold;
} /* Line: 425 */
 else  /* Line: 426 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 428 */ {
bevt_21_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_21_tmpany_phold;
} /* Line: 429 */
} /* Line: 428 */
} /* Line: 407 */
} /* Line: 407 */
} /* Line: 407 */
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
bevl_other = this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bevp_slots.bem_copy_0();
bevl_other.bemd_1(365988447, BEL_4_Base.bevn_slotsSet_1, bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 439 */ {
bevt_2_tmpany_phold = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 441 */ {
bevt_4_tmpany_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_6_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpany_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_tmpany_phold.bem_new_3(bevt_7_tmpany_phold, bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_4_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_5_tmpany_phold);
} /* Line: 442 */
 else  /* Line: 443 */ {
bevt_10_tmpany_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_10_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, null);
} /* Line: 444 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 439 */
 else  /* Line: 439 */ {
break;
} /* Line: 439 */
} /* Line: 439 */
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_clear_0() {
bevp_slots.bem_clear_0();
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_keyIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_nodeIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 482 */ {
bevt_0_tmpany_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 483 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 483 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 485 */
} /* Line: 484 */
 else  /* Line: 483 */ {
break;
} /* Line: 483 */
} /* Line: 483 */
} /* Line: 483 */
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpany_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 494 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 494 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 495 */
 else  /* Line: 494 */ {
break;
} /* Line: 494 */
} /* Line: 494 */
if (beva_other == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 497 */ {
bevt_1_tmpany_loop = beva_other.bem_setIteratorGet_0();
while (true)
 /* Line: 498 */ {
bevt_4_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 498 */ {
bevl_x = bevt_1_tmpany_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 499 */
 else  /* Line: 498 */ {
break;
} /* Line: 498 */
} /* Line: 498 */
} /* Line: 498 */
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = (BEC_2_9_3_ContainerSet) this.bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 512 */ {
bevt_2_tmpany_phold = beva_other.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 513 */ {
bevt_0_tmpany_loop = beva_other.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 514 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 514 */ {
bevl_x = bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_put_1(bevl_x);
} /* Line: 515 */
 else  /* Line: 514 */ {
break;
} /* Line: 514 */
} /* Line: 514 */
} /* Line: 514 */
 else  /* Line: 513 */ {
bevt_4_tmpany_phold = beva_other.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpany_phold).bevi_bool) /* Line: 517 */ {
bevt_5_tmpany_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
this.bem_put_1(bevt_5_tmpany_phold);
} /* Line: 518 */
 else  /* Line: 519 */ {
this.bem_put_1(beva_other);
} /* Line: 520 */
} /* Line: 513 */
} /* Line: 513 */
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_slotsGet_0() {
return bevp_slots;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_moduGet_0() {
return bevp_modu;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_multiGet_0() {
return bevp_multi;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() {
return bevp_rel;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() {
return bevp_baseNode;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() {
return bevp_innerPutAdded;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {215, 215, 221, 222, 223, 224, 225, 226, 227, 233, 233, 233, 234, 234, 236, 236, 240, 240, 240, 241, 241, 243, 243, 247, 247, 251, 251, 255, 255, 259, 259, 260, 261, 261, 262, 262, 262, 263, 263, 267, 267, 272, 272, 272, 272, 273, 274, 274, 275, 276, 278, 282, 282, 0, 282, 282, 282, 282, 0, 0, 283, 283, 285, 0, 285, 285, 286, 286, 286, 286, 286, 288, 288, 292, 293, 293, 294, 295, 295, 295, 296, 299, 301, 302, 304, 305, 305, 306, 306, 307, 307, 307, 309, 311, 312, 312, 313, 313, 313, 313, 314, 314, 315, 315, 316, 318, 319, 319, 321, 322, 322, 323, 323, 330, 330, 331, 332, 333, 333, 334, 336, 339, 344, 345, 346, 347, 347, 347, 348, 350, 351, 353, 354, 354, 355, 356, 356, 356, 356, 357, 358, 358, 359, 359, 361, 362, 362, 363, 370, 371, 372, 373, 373, 373, 374, 376, 377, 379, 380, 380, 381, 381, 382, 382, 382, 382, 383, 383, 384, 384, 385, 385, 387, 388, 388, 389, 389, 396, 397, 399, 400, 400, 400, 401, 403, 404, 406, 407, 407, 408, 408, 409, 409, 409, 409, 410, 410, 411, 411, 412, 413, 414, 415, 415, 416, 417, 417, 0, 417, 417, 417, 417, 0, 0, 418, 418, 420, 420, 420, 421, 423, 425, 425, 427, 428, 428, 429, 429, 436, 437, 438, 438, 439, 439, 439, 439, 440, 441, 441, 442, 442, 442, 442, 442, 442, 442, 444, 444, 439, 447, 452, 453, 457, 457, 461, 461, 465, 465, 469, 469, 473, 473, 477, 477, 481, 482, 482, 483, 0, 483, 483, 484, 485, 489, 493, 494, 0, 494, 494, 495, 497, 497, 498, 0, 498, 498, 499, 502, 506, 507, 508, 512, 512, 513, 514, 0, 514, 514, 515, 517, 518, 518, 520, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 31, 32, 33, 34, 35, 36, 37, 45, 46, 51, 52, 53, 55, 56, 63, 64, 69, 70, 71, 73, 74, 78, 79, 83, 84, 89, 90, 102, 105, 107, 108, 113, 114, 115, 116, 118, 119, 127, 128, 138, 139, 140, 141, 142, 145, 146, 148, 149, 155, 171, 176, 177, 180, 181, 182, 187, 188, 191, 195, 196, 198, 198, 201, 203, 204, 205, 210, 211, 212, 219, 220, 245, 246, 251, 252, 253, 254, 259, 260, 264, 266, 267, 270, 271, 276, 277, 282, 283, 284, 285, 288, 290, 291, 292, 295, 296, 297, 302, 303, 304, 307, 308, 310, 311, 312, 313, 316, 317, 322, 323, 324, 337, 338, 340, 341, 344, 345, 347, 353, 356, 377, 378, 379, 380, 381, 386, 387, 389, 390, 393, 394, 399, 400, 403, 404, 405, 410, 411, 414, 415, 417, 418, 421, 422, 427, 428, 455, 456, 457, 458, 459, 464, 465, 467, 468, 471, 472, 477, 478, 479, 482, 483, 484, 489, 490, 491, 494, 495, 497, 498, 501, 502, 507, 508, 509, 545, 546, 547, 548, 549, 554, 555, 557, 558, 561, 562, 567, 568, 569, 572, 573, 574, 579, 580, 581, 584, 585, 587, 588, 589, 592, 597, 598, 599, 604, 605, 608, 609, 610, 615, 616, 619, 623, 624, 627, 628, 629, 630, 632, 638, 639, 642, 643, 648, 649, 650, 672, 673, 674, 675, 676, 679, 680, 685, 686, 687, 692, 693, 694, 695, 696, 697, 698, 699, 702, 703, 705, 711, 714, 715, 720, 721, 725, 726, 730, 731, 735, 736, 740, 741, 745, 746, 755, 756, 761, 762, 762, 765, 767, 768, 770, 778, 788, 789, 789, 792, 794, 795, 801, 806, 807, 807, 810, 812, 813, 820, 824, 825, 826, 836, 841, 842, 844, 844, 847, 849, 850, 858, 860, 861, 864, 871, 874, 878, 881, 885, 888, 892, 895, 899, 902, 906, 909, 913, 916};
/* BEGIN LINEINFO 
assign 1 215 26
new 0 215 26
new 1 215 27
assign 1 221 31
new 1 221 31
assign 1 222 32
assign 1 223 33
new 0 223 33
assign 1 224 34
new 0 224 34
assign 1 225 35
new 0 225 35
assign 1 226 36
new 0 226 36
assign 1 227 37
new 0 227 37
assign 1 233 45
new 0 233 45
assign 1 233 46
equals 1 233 51
assign 1 234 52
new 0 234 52
return 1 234 53
assign 1 236 55
new 0 236 55
return 1 236 56
assign 1 240 63
new 0 240 63
assign 1 240 64
equals 1 240 69
assign 1 241 70
new 0 241 70
return 1 241 71
assign 1 243 73
new 0 243 73
return 1 243 74
assign 1 247 78
toString 0 247 78
return 1 247 79
assign 1 251 83
new 1 251 83
new 1 251 84
assign 1 255 89
new 1 255 89
return 1 255 90
assign 1 259 102
arrayIteratorGet 0 259 102
assign 1 259 105
hasNextGet 0 259 105
assign 1 260 107
nextGet 0 260 107
assign 1 261 108
def 1 261 113
assign 1 262 114
keyGet 0 262 114
assign 1 262 115
innerPut 4 262 115
assign 1 262 116
not 0 262 116
assign 1 263 118
new 0 263 118
return 1 263 119
assign 1 267 127
new 0 267 127
return 1 267 128
assign 1 272 138
sizeGet 0 272 138
assign 1 272 139
multiply 1 272 139
assign 1 272 140
new 0 272 140
assign 1 272 141
add 1 272 141
assign 1 273 142
new 1 273 142
assign 1 274 145
insertAll 2 274 145
assign 1 274 146
not 0 274 146
assign 1 275 148
increment 0 275 148
assign 1 276 149
new 1 276 149
return 1 278 155
assign 1 282 171
undef 1 282 176
assign 1 0 177
assign 1 282 180
sizeGet 0 282 180
assign 1 282 181
sizeGet 0 282 181
assign 1 282 182
notEquals 1 282 187
assign 1 0 188
assign 1 0 191
assign 1 283 195
new 0 283 195
return 1 283 196
assign 1 285 198
setIteratorGet 0 0 198
assign 1 285 201
hasNextGet 0 285 201
assign 1 285 203
nextGet 0 285 203
assign 1 286 204
has 1 286 204
assign 1 286 205
not 0 286 210
assign 1 286 211
new 0 286 211
return 1 286 212
assign 1 288 219
new 0 288 219
return 1 288 220
assign 1 292 245
sizeGet 0 292 245
assign 1 293 246
undef 1 293 251
assign 1 294 252
getHash 1 294 252
assign 1 295 253
new 0 295 253
assign 1 295 254
lesser 1 295 259
assign 1 296 260
abs 0 296 260
assign 1 299 264
hvalGet 0 299 264
assign 1 301 266
modulus 1 301 266
assign 1 302 267
assign 1 304 270
get 1 304 270
assign 1 305 271
undef 1 305 276
assign 1 306 277
undef 1 306 282
assign 1 307 283
create 0 307 283
assign 1 307 284
new 3 307 284
put 2 307 285
put 2 309 288
assign 1 311 290
new 0 311 290
assign 1 312 291
new 0 312 291
return 1 312 292
assign 1 313 295
hvalGet 0 313 295
assign 1 313 296
modulus 1 313 296
assign 1 313 297
notEquals 1 313 302
assign 1 314 303
new 0 314 303
return 1 314 304
assign 1 315 307
keyGet 0 315 307
assign 1 315 308
isEqual 2 315 308
putTo 2 316 310
assign 1 318 311
new 0 318 311
assign 1 319 312
new 0 319 312
return 1 319 313
assign 1 321 316
increment 0 321 316
assign 1 322 317
greaterEquals 1 322 322
assign 1 323 323
new 0 323 323
return 1 323 324
assign 1 330 337
innerPut 4 330 337
assign 1 330 338
not 0 330 338
assign 1 331 340
assign 1 332 341
rehash 1 332 341
assign 1 333 344
innerPut 4 333 344
assign 1 333 345
not 0 333 345
assign 1 334 347
rehash 1 334 347
assign 1 336 353
assign 1 339 356
increment 0 339 356
assign 1 344 377
assign 1 345 378
sizeGet 0 345 378
assign 1 346 379
getHash 1 346 379
assign 1 347 380
new 0 347 380
assign 1 347 381
lesser 1 347 386
assign 1 348 387
abs 0 348 387
assign 1 350 389
modulus 1 350 389
assign 1 351 390
assign 1 353 393
get 1 353 393
assign 1 354 394
undef 1 354 399
return 1 355 400
assign 1 356 403
hvalGet 0 356 403
assign 1 356 404
modulus 1 356 404
assign 1 356 405
notEquals 1 356 410
return 1 357 411
assign 1 358 414
keyGet 0 358 414
assign 1 358 415
isEqual 2 358 415
assign 1 359 417
getFrom 0 359 417
return 1 359 418
assign 1 361 421
increment 0 361 421
assign 1 362 422
greaterEquals 1 362 427
return 1 363 428
assign 1 370 455
assign 1 371 456
sizeGet 0 371 456
assign 1 372 457
getHash 1 372 457
assign 1 373 458
new 0 373 458
assign 1 373 459
lesser 1 373 464
assign 1 374 465
abs 0 374 465
assign 1 376 467
modulus 1 376 467
assign 1 377 468
assign 1 379 471
get 1 379 471
assign 1 380 472
undef 1 380 477
assign 1 381 478
new 0 381 478
return 1 381 479
assign 1 382 482
hvalGet 0 382 482
assign 1 382 483
modulus 1 382 483
assign 1 382 484
notEquals 1 382 489
assign 1 383 490
new 0 383 490
return 1 383 491
assign 1 384 494
keyGet 0 384 494
assign 1 384 495
isEqual 2 384 495
assign 1 385 497
new 0 385 497
return 1 385 498
assign 1 387 501
increment 0 387 501
assign 1 388 502
greaterEquals 1 388 507
assign 1 389 508
new 0 389 508
return 1 389 509
assign 1 396 545
assign 1 397 546
sizeGet 0 397 546
assign 1 399 547
getHash 1 399 547
assign 1 400 548
new 0 400 548
assign 1 400 549
lesser 1 400 554
assign 1 401 555
abs 0 401 555
assign 1 403 557
modulus 1 403 557
assign 1 404 558
assign 1 406 561
get 1 406 561
assign 1 407 562
undef 1 407 567
assign 1 408 568
new 0 408 568
return 1 408 569
assign 1 409 572
hvalGet 0 409 572
assign 1 409 573
modulus 1 409 573
assign 1 409 574
notEquals 1 409 579
assign 1 410 580
new 0 410 580
return 1 410 581
assign 1 411 584
keyGet 0 411 584
assign 1 411 585
isEqual 2 411 585
put 2 412 587
assign 1 413 588
decrement 0 413 588
assign 1 414 589
increment 0 414 589
assign 1 415 592
lesser 1 415 597
assign 1 416 598
get 1 416 598
assign 1 417 599
undef 1 417 604
assign 1 0 605
assign 1 417 608
hvalGet 0 417 608
assign 1 417 609
modulus 1 417 609
assign 1 417 610
notEquals 1 417 615
assign 1 0 616
assign 1 0 619
assign 1 418 623
new 0 418 623
return 1 418 624
assign 1 420 627
new 0 420 627
assign 1 420 628
subtract 1 420 628
put 2 420 629
put 2 421 630
assign 1 423 632
increment 0 423 632
assign 1 425 638
new 0 425 638
return 1 425 639
assign 1 427 642
increment 0 427 642
assign 1 428 643
greaterEquals 1 428 648
assign 1 429 649
new 0 429 649
return 1 429 650
assign 1 436 672
create 0 436 672
copyTo 1 437 673
assign 1 438 674
copy 0 438 674
slotsSet 1 438 675
assign 1 439 676
new 0 439 676
assign 1 439 679
lengthGet 0 439 679
assign 1 439 680
lesser 1 439 685
assign 1 440 686
get 1 440 686
assign 1 441 687
def 1 441 692
assign 1 442 693
slotsGet 0 442 693
assign 1 442 694
create 0 442 694
assign 1 442 695
hvalGet 0 442 695
assign 1 442 696
keyGet 0 442 696
assign 1 442 697
getFrom 0 442 697
assign 1 442 698
new 3 442 698
put 2 442 699
assign 1 444 702
slotsGet 0 444 702
put 2 444 703
assign 1 439 705
increment 0 439 705
return 1 447 711
clear 0 452 714
assign 1 453 715
new 0 453 715
assign 1 457 720
new 1 457 720
return 1 457 721
assign 1 461 725
new 1 461 725
return 1 461 726
assign 1 465 730
new 1 465 730
return 1 465 731
assign 1 469 735
keyIteratorGet 0 469 735
return 1 469 736
assign 1 473 740
new 1 473 740
return 1 473 741
assign 1 477 745
nodeIteratorGet 0 477 745
return 1 477 746
assign 1 481 755
new 0 481 755
assign 1 482 756
def 1 482 761
assign 1 483 762
setIteratorGet 0 0 762
assign 1 483 765
hasNextGet 0 483 765
assign 1 483 767
nextGet 0 483 767
assign 1 484 768
has 1 484 768
put 1 485 770
return 1 489 778
assign 1 493 788
new 0 493 788
assign 1 494 789
setIteratorGet 0 0 789
assign 1 494 792
hasNextGet 0 494 792
assign 1 494 794
nextGet 0 494 794
put 1 495 795
assign 1 497 801
def 1 497 806
assign 1 498 807
setIteratorGet 0 0 807
assign 1 498 810
hasNextGet 0 498 810
assign 1 498 812
nextGet 0 498 812
put 1 499 813
return 1 502 820
assign 1 506 824
copy 0 506 824
addValue 1 507 825
return 1 508 826
assign 1 512 836
def 1 512 841
assign 1 513 842
sameType 1 513 842
assign 1 514 844
iteratorGet 0 0 844
assign 1 514 847
hasNextGet 0 514 847
assign 1 514 849
nextGet 0 514 849
put 1 515 850
assign 1 517 858
sameType 1 517 858
assign 1 518 860
keyGet 0 518 860
put 1 518 861
put 1 520 864
return 1 0 871
assign 1 0 874
return 1 0 878
assign 1 0 881
return 1 0 885
assign 1 0 888
return 1 0 892
assign 1 0 895
return 1 0 899
assign 1 0 902
return 1 0 906
assign 1 0 909
return 1 0 913
assign 1 0 916
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -712928736: return bem_innerPutAddedGet_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1586230380: return bem_moduGet_0();
case -1114073101: return bem_keysGet_0();
case 104713553: return bem_new_0();
case 2086347094: return bem_nodesGet_0();
case 287040793: return bem_hashGet_0();
case 2056412570: return bem_keyIteratorGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case -2142483603: return bem_notEmptyGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case -1431826729: return bem_nodeIteratorGet_0();
case 1820417453: return bem_create_0();
case 1227011022: return bem_multiGet_0();
case -578884498: return bem_relGet_0();
case -786424307: return bem_tagGet_0();
case 235611348: return bem_baseNodeGet_0();
case 499932279: return bem_setIteratorGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -1575148127: return bem_moduSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case -567802245: return bem_relSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -79841285: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case -286659903: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case -868745803: return bem_forwardCall_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -668984013: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -131089957: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_3_ContainerSet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_3_ContainerSet.bevs_inst = (BEC_2_9_3_ContainerSet)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_3_ContainerSet.bevs_inst;
}
}
}
