namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet : BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
static BEC_2_9_3_ContainerSet() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_2_9_3_ContainerSet bevs_inst;
public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
if (bevp_size.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 236 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 237 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
if (bevp_size.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /* Line: 244 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_3_9_3_21_ContainerSetSerializationIterator) (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
 /* Line: 262 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevt_4_tmpvar_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpvar_phold = this.bem_innerPut_4(bevt_4_tmpvar_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 265 */ {
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 266 */
} /* Line: 265 */
} /* Line: 264 */
 else  /* Line: 262 */ {
break;
} /* Line: 262 */
} /* Line: 262 */
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpvar_phold = bevo_2;
bevl_nslots = bevt_0_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
bevl_ninner = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 277 */ {
bevt_4_tmpvar_phold = this.bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 277 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
} /* Line: 279 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
return bevl_ninner;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (beva_other == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 285 */ {
bevt_4_tmpvar_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpvar_phold = this.bem_sizeGet_0();
if (bevt_4_tmpvar_phold.bevi_int != bevt_5_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 285 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 285 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 285 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 286 */
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 288 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 288 */ {
bevl_i = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_9_tmpvar_phold = beva_other.bem_has_1(bevl_i);
if (bevt_9_tmpvar_phold.bevi_bool) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_10_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_10_tmpvar_phold;
} /* Line: 289 */
} /* Line: 289 */
 else  /* Line: 288 */ {
break;
} /* Line: 288 */
} /* Line: 288 */
bevt_11_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 296 */ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_3;
if (bevl_hval.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 298 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 299 */
} /* Line: 298 */
 else  /* Line: 301 */ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(-449328306, BEL_4_Base.bevn_hvalGet_0);
} /* Line: 302 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 306 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 308 */ {
if (beva_inode == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 309 */ {
bevt_6_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_tmpvar_phold.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpvar_phold);
} /* Line: 310 */
 else  /* Line: 311 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 312 */
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 315 */
 else  /* Line: 308 */ {
bevt_10_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_9_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 316 */ {
bevt_11_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /* Line: 317 */
 else  /* Line: 308 */ {
bevt_13_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpvar_phold, beva_k);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 318 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_14_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_14_tmpvar_phold;
} /* Line: 322 */
 else  /* Line: 323 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 325 */ {
bevt_16_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_16_tmpvar_phold;
} /* Line: 326 */
} /* Line: 325 */
} /* Line: 308 */
} /* Line: 308 */
} /* Line: 308 */
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 333 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 336 */ {
bevt_3_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 336 */ {
bevl_slt = (BEC_2_9_4_ContainerList) this.bem_rehash_1(bevl_slt);
} /* Line: 337 */
 else  /* Line: 336 */ {
break;
} /* Line: 336 */
} /* Line: 336 */
bevp_slots = bevl_slt;
} /* Line: 339 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 341 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 342 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_4;
if (bevl_hval.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 351 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 355 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 357 */ {
return null;
} /* Line: 358 */
 else  /* Line: 357 */ {
bevt_5_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_4_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 359 */ {
return null;
} /* Line: 360 */
 else  /* Line: 357 */ {
bevt_7_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpvar_phold, beva_k);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 361 */ {
bevt_8_tmpvar_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpvar_phold;
} /* Line: 362 */
 else  /* Line: 363 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 365 */ {
return null;
} /* Line: 366 */
} /* Line: 365 */
} /* Line: 357 */
} /* Line: 357 */
} /* Line: 357 */
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_5;
if (bevl_hval.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 376 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 377 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 381 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 383 */ {
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 384 */
 else  /* Line: 383 */ {
bevt_6_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_5_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /* Line: 386 */
 else  /* Line: 383 */ {
bevt_9_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpvar_phold, beva_k);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 387 */ {
bevt_10_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 388 */
 else  /* Line: 389 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevt_12_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /* Line: 392 */
} /* Line: 391 */
} /* Line: 383 */
} /* Line: 383 */
} /* Line: 383 */
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_6;
if (bevl_hval.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 404 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 408 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 410 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 411 */
 else  /* Line: 410 */ {
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_6_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 412 */ {
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 413 */
 else  /* Line: 410 */ {
bevt_10_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpvar_phold, beva_k);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 414 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 418 */ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 420 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 420 */ {
bevt_15_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_14_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 420 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 420 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 420 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 420 */ {
bevt_16_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_16_tmpvar_phold;
} /* Line: 421 */
 else  /* Line: 422 */ {
bevt_18_tmpvar_phold = bevo_7;
bevt_17_tmpvar_phold = bevl_sl.bem_subtract_1(bevt_18_tmpvar_phold);
bevl_slt.bem_put_2(bevt_17_tmpvar_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 424 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 426 */
 else  /* Line: 418 */ {
break;
} /* Line: 418 */
} /* Line: 418 */
bevt_19_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_19_tmpvar_phold;
} /* Line: 428 */
 else  /* Line: 429 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 431 */ {
bevt_21_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_21_tmpvar_phold;
} /* Line: 432 */
} /* Line: 431 */
} /* Line: 410 */
} /* Line: 410 */
} /* Line: 410 */
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
bevl_other = this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = (BEC_2_9_4_ContainerList) bevp_slots.bem_copy_0();
bevl_other.bemd_1(365988447, BEL_4_Base.bevn_slotsSet_1, bevt_0_tmpvar_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 442 */ {
bevt_2_tmpvar_phold = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 442 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 444 */ {
bevt_4_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_6_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_tmpvar_phold.bem_new_3(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_4_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_5_tmpvar_phold);
} /* Line: 445 */
 else  /* Line: 446 */ {
bevt_10_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_10_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, null);
} /* Line: 447 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 442 */
 else  /* Line: 442 */ {
break;
} /* Line: 442 */
} /* Line: 442 */
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_clear_0() {
bevp_slots.bem_clear_0();
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_keyIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_nodeIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 485 */ {
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 486 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 486 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_3_tmpvar_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 487 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 488 */
} /* Line: 487 */
 else  /* Line: 486 */ {
break;
} /* Line: 486 */
} /* Line: 486 */
} /* Line: 486 */
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 497 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 497 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 498 */
 else  /* Line: 497 */ {
break;
} /* Line: 497 */
} /* Line: 497 */
if (beva_other == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 500 */ {
bevt_1_tmpvar_loop = beva_other.bem_setIteratorGet_0();
while (true)
 /* Line: 501 */ {
bevt_4_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 501 */ {
bevl_x = bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 502 */
 else  /* Line: 501 */ {
break;
} /* Line: 501 */
} /* Line: 501 */
} /* Line: 501 */
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = (BEC_2_9_3_ContainerSet) this.bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 515 */ {
bevt_2_tmpvar_phold = beva_other.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 516 */ {
bevt_0_tmpvar_loop = beva_other.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 517 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 517 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_put_1(bevl_x);
} /* Line: 518 */
 else  /* Line: 517 */ {
break;
} /* Line: 517 */
} /* Line: 517 */
} /* Line: 517 */
 else  /* Line: 516 */ {
bevt_4_tmpvar_phold = beva_other.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 520 */ {
bevt_5_tmpvar_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
this.bem_put_1(bevt_5_tmpvar_phold);
} /* Line: 521 */
 else  /* Line: 522 */ {
this.bem_put_1(beva_other);
} /* Line: 523 */
} /* Line: 516 */
} /* Line: 516 */
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_slotsGet_0() {
return bevp_slots;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_moduGet_0() {
return bevp_modu;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_multiGet_0() {
return bevp_multi;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() {
return bevp_rel;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() {
return bevp_baseNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() {
return bevp_innerPutAdded;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {218, 218, 224, 225, 226, 227, 228, 229, 230, 236, 236, 236, 237, 237, 239, 239, 243, 243, 243, 244, 244, 246, 246, 250, 250, 254, 254, 258, 258, 262, 262, 263, 264, 264, 265, 265, 265, 266, 266, 270, 270, 275, 275, 275, 275, 276, 277, 277, 278, 279, 281, 285, 285, 0, 285, 285, 285, 285, 0, 0, 286, 286, 288, 0, 288, 288, 289, 289, 289, 289, 289, 291, 291, 295, 296, 296, 297, 298, 298, 298, 299, 302, 304, 305, 307, 308, 308, 309, 309, 310, 310, 310, 312, 314, 315, 315, 316, 316, 316, 316, 317, 317, 318, 318, 319, 321, 322, 322, 324, 325, 325, 326, 326, 333, 333, 334, 335, 336, 336, 337, 339, 342, 347, 348, 349, 350, 350, 350, 351, 353, 354, 356, 357, 357, 358, 359, 359, 359, 359, 360, 361, 361, 362, 362, 364, 365, 365, 366, 373, 374, 375, 376, 376, 376, 377, 379, 380, 382, 383, 383, 384, 384, 385, 385, 385, 385, 386, 386, 387, 387, 388, 388, 390, 391, 391, 392, 392, 399, 400, 402, 403, 403, 403, 404, 406, 407, 409, 410, 410, 411, 411, 412, 412, 412, 412, 413, 413, 414, 414, 415, 416, 417, 418, 418, 419, 420, 420, 0, 420, 420, 420, 420, 0, 0, 421, 421, 423, 423, 423, 424, 426, 428, 428, 430, 431, 431, 432, 432, 439, 440, 441, 441, 442, 442, 442, 442, 443, 444, 444, 445, 445, 445, 445, 445, 445, 445, 447, 447, 442, 450, 455, 456, 460, 460, 464, 464, 468, 468, 472, 472, 476, 476, 480, 480, 484, 485, 485, 486, 0, 486, 486, 487, 488, 492, 496, 497, 0, 497, 497, 498, 500, 500, 501, 0, 501, 501, 502, 505, 509, 510, 511, 515, 515, 516, 517, 0, 517, 517, 518, 520, 521, 521, 523, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 31, 32, 33, 34, 35, 36, 37, 45, 46, 51, 52, 53, 55, 56, 63, 64, 69, 70, 71, 73, 74, 78, 79, 83, 84, 89, 90, 102, 105, 107, 108, 113, 114, 115, 116, 118, 119, 127, 128, 138, 139, 140, 141, 142, 145, 146, 148, 149, 155, 171, 176, 177, 180, 181, 182, 187, 188, 191, 195, 196, 198, 198, 201, 203, 204, 205, 210, 211, 212, 219, 220, 245, 246, 251, 252, 253, 254, 259, 260, 264, 266, 267, 270, 271, 276, 277, 282, 283, 284, 285, 288, 290, 291, 292, 295, 296, 297, 302, 303, 304, 307, 308, 310, 311, 312, 313, 316, 317, 322, 323, 324, 337, 338, 340, 341, 344, 345, 347, 353, 356, 377, 378, 379, 380, 381, 386, 387, 389, 390, 393, 394, 399, 400, 403, 404, 405, 410, 411, 414, 415, 417, 418, 421, 422, 427, 428, 455, 456, 457, 458, 459, 464, 465, 467, 468, 471, 472, 477, 478, 479, 482, 483, 484, 489, 490, 491, 494, 495, 497, 498, 501, 502, 507, 508, 509, 545, 546, 547, 548, 549, 554, 555, 557, 558, 561, 562, 567, 568, 569, 572, 573, 574, 579, 580, 581, 584, 585, 587, 588, 589, 592, 597, 598, 599, 604, 605, 608, 609, 610, 615, 616, 619, 623, 624, 627, 628, 629, 630, 632, 638, 639, 642, 643, 648, 649, 650, 672, 673, 674, 675, 676, 679, 680, 685, 686, 687, 692, 693, 694, 695, 696, 697, 698, 699, 702, 703, 705, 711, 714, 715, 720, 721, 725, 726, 730, 731, 735, 736, 740, 741, 745, 746, 755, 756, 761, 762, 762, 765, 767, 768, 770, 778, 788, 789, 789, 792, 794, 795, 801, 806, 807, 807, 810, 812, 813, 820, 824, 825, 826, 836, 841, 842, 844, 844, 847, 849, 850, 858, 860, 861, 864, 871, 874, 878, 881, 885, 888, 892, 895, 899, 902, 906, 909, 913, 916};
/* BEGIN LINEINFO 
assign 1 218 26
new 0 218 26
new 1 218 27
assign 1 224 31
new 1 224 31
assign 1 225 32
assign 1 226 33
new 0 226 33
assign 1 227 34
new 0 227 34
assign 1 228 35
new 0 228 35
assign 1 229 36
new 0 229 36
assign 1 230 37
new 0 230 37
assign 1 236 45
new 0 236 45
assign 1 236 46
equals 1 236 51
assign 1 237 52
new 0 237 52
return 1 237 53
assign 1 239 55
new 0 239 55
return 1 239 56
assign 1 243 63
new 0 243 63
assign 1 243 64
equals 1 243 69
assign 1 244 70
new 0 244 70
return 1 244 71
assign 1 246 73
new 0 246 73
return 1 246 74
assign 1 250 78
toString 0 250 78
return 1 250 79
assign 1 254 83
new 1 254 83
new 1 254 84
assign 1 258 89
new 1 258 89
return 1 258 90
assign 1 262 102
arrayIteratorGet 0 262 102
assign 1 262 105
hasNextGet 0 262 105
assign 1 263 107
nextGet 0 263 107
assign 1 264 108
def 1 264 113
assign 1 265 114
keyGet 0 265 114
assign 1 265 115
innerPut 4 265 115
assign 1 265 116
not 0 265 116
assign 1 266 118
new 0 266 118
return 1 266 119
assign 1 270 127
new 0 270 127
return 1 270 128
assign 1 275 138
sizeGet 0 275 138
assign 1 275 139
multiply 1 275 139
assign 1 275 140
new 0 275 140
assign 1 275 141
add 1 275 141
assign 1 276 142
new 1 276 142
assign 1 277 145
insertAll 2 277 145
assign 1 277 146
not 0 277 146
assign 1 278 148
increment 0 278 148
assign 1 279 149
new 1 279 149
return 1 281 155
assign 1 285 171
undef 1 285 176
assign 1 0 177
assign 1 285 180
sizeGet 0 285 180
assign 1 285 181
sizeGet 0 285 181
assign 1 285 182
notEquals 1 285 187
assign 1 0 188
assign 1 0 191
assign 1 286 195
new 0 286 195
return 1 286 196
assign 1 288 198
setIteratorGet 0 0 198
assign 1 288 201
hasNextGet 0 288 201
assign 1 288 203
nextGet 0 288 203
assign 1 289 204
has 1 289 204
assign 1 289 205
not 0 289 210
assign 1 289 211
new 0 289 211
return 1 289 212
assign 1 291 219
new 0 291 219
return 1 291 220
assign 1 295 245
sizeGet 0 295 245
assign 1 296 246
undef 1 296 251
assign 1 297 252
getHash 1 297 252
assign 1 298 253
new 0 298 253
assign 1 298 254
lesser 1 298 259
assign 1 299 260
abs 0 299 260
assign 1 302 264
hvalGet 0 302 264
assign 1 304 266
modulus 1 304 266
assign 1 305 267
assign 1 307 270
get 1 307 270
assign 1 308 271
undef 1 308 276
assign 1 309 277
undef 1 309 282
assign 1 310 283
create 0 310 283
assign 1 310 284
new 3 310 284
put 2 310 285
put 2 312 288
assign 1 314 290
new 0 314 290
assign 1 315 291
new 0 315 291
return 1 315 292
assign 1 316 295
hvalGet 0 316 295
assign 1 316 296
modulus 1 316 296
assign 1 316 297
notEquals 1 316 302
assign 1 317 303
new 0 317 303
return 1 317 304
assign 1 318 307
keyGet 0 318 307
assign 1 318 308
isEqual 2 318 308
putTo 2 319 310
assign 1 321 311
new 0 321 311
assign 1 322 312
new 0 322 312
return 1 322 313
assign 1 324 316
increment 0 324 316
assign 1 325 317
greaterEquals 1 325 322
assign 1 326 323
new 0 326 323
return 1 326 324
assign 1 333 337
innerPut 4 333 337
assign 1 333 338
not 0 333 338
assign 1 334 340
assign 1 335 341
rehash 1 335 341
assign 1 336 344
innerPut 4 336 344
assign 1 336 345
not 0 336 345
assign 1 337 347
rehash 1 337 347
assign 1 339 353
assign 1 342 356
increment 0 342 356
assign 1 347 377
assign 1 348 378
sizeGet 0 348 378
assign 1 349 379
getHash 1 349 379
assign 1 350 380
new 0 350 380
assign 1 350 381
lesser 1 350 386
assign 1 351 387
abs 0 351 387
assign 1 353 389
modulus 1 353 389
assign 1 354 390
assign 1 356 393
get 1 356 393
assign 1 357 394
undef 1 357 399
return 1 358 400
assign 1 359 403
hvalGet 0 359 403
assign 1 359 404
modulus 1 359 404
assign 1 359 405
notEquals 1 359 410
return 1 360 411
assign 1 361 414
keyGet 0 361 414
assign 1 361 415
isEqual 2 361 415
assign 1 362 417
getFrom 0 362 417
return 1 362 418
assign 1 364 421
increment 0 364 421
assign 1 365 422
greaterEquals 1 365 427
return 1 366 428
assign 1 373 455
assign 1 374 456
sizeGet 0 374 456
assign 1 375 457
getHash 1 375 457
assign 1 376 458
new 0 376 458
assign 1 376 459
lesser 1 376 464
assign 1 377 465
abs 0 377 465
assign 1 379 467
modulus 1 379 467
assign 1 380 468
assign 1 382 471
get 1 382 471
assign 1 383 472
undef 1 383 477
assign 1 384 478
new 0 384 478
return 1 384 479
assign 1 385 482
hvalGet 0 385 482
assign 1 385 483
modulus 1 385 483
assign 1 385 484
notEquals 1 385 489
assign 1 386 490
new 0 386 490
return 1 386 491
assign 1 387 494
keyGet 0 387 494
assign 1 387 495
isEqual 2 387 495
assign 1 388 497
new 0 388 497
return 1 388 498
assign 1 390 501
increment 0 390 501
assign 1 391 502
greaterEquals 1 391 507
assign 1 392 508
new 0 392 508
return 1 392 509
assign 1 399 545
assign 1 400 546
sizeGet 0 400 546
assign 1 402 547
getHash 1 402 547
assign 1 403 548
new 0 403 548
assign 1 403 549
lesser 1 403 554
assign 1 404 555
abs 0 404 555
assign 1 406 557
modulus 1 406 557
assign 1 407 558
assign 1 409 561
get 1 409 561
assign 1 410 562
undef 1 410 567
assign 1 411 568
new 0 411 568
return 1 411 569
assign 1 412 572
hvalGet 0 412 572
assign 1 412 573
modulus 1 412 573
assign 1 412 574
notEquals 1 412 579
assign 1 413 580
new 0 413 580
return 1 413 581
assign 1 414 584
keyGet 0 414 584
assign 1 414 585
isEqual 2 414 585
put 2 415 587
assign 1 416 588
decrement 0 416 588
assign 1 417 589
increment 0 417 589
assign 1 418 592
lesser 1 418 597
assign 1 419 598
get 1 419 598
assign 1 420 599
undef 1 420 604
assign 1 0 605
assign 1 420 608
hvalGet 0 420 608
assign 1 420 609
modulus 1 420 609
assign 1 420 610
notEquals 1 420 615
assign 1 0 616
assign 1 0 619
assign 1 421 623
new 0 421 623
return 1 421 624
assign 1 423 627
new 0 423 627
assign 1 423 628
subtract 1 423 628
put 2 423 629
put 2 424 630
assign 1 426 632
increment 0 426 632
assign 1 428 638
new 0 428 638
return 1 428 639
assign 1 430 642
increment 0 430 642
assign 1 431 643
greaterEquals 1 431 648
assign 1 432 649
new 0 432 649
return 1 432 650
assign 1 439 672
create 0 439 672
copyTo 1 440 673
assign 1 441 674
copy 0 441 674
slotsSet 1 441 675
assign 1 442 676
new 0 442 676
assign 1 442 679
lengthGet 0 442 679
assign 1 442 680
lesser 1 442 685
assign 1 443 686
get 1 443 686
assign 1 444 687
def 1 444 692
assign 1 445 693
slotsGet 0 445 693
assign 1 445 694
create 0 445 694
assign 1 445 695
hvalGet 0 445 695
assign 1 445 696
keyGet 0 445 696
assign 1 445 697
getFrom 0 445 697
assign 1 445 698
new 3 445 698
put 2 445 699
assign 1 447 702
slotsGet 0 447 702
put 2 447 703
assign 1 442 705
increment 0 442 705
return 1 450 711
clear 0 455 714
assign 1 456 715
new 0 456 715
assign 1 460 720
new 1 460 720
return 1 460 721
assign 1 464 725
new 1 464 725
return 1 464 726
assign 1 468 730
new 1 468 730
return 1 468 731
assign 1 472 735
keyIteratorGet 0 472 735
return 1 472 736
assign 1 476 740
new 1 476 740
return 1 476 741
assign 1 480 745
nodeIteratorGet 0 480 745
return 1 480 746
assign 1 484 755
new 0 484 755
assign 1 485 756
def 1 485 761
assign 1 486 762
setIteratorGet 0 0 762
assign 1 486 765
hasNextGet 0 486 765
assign 1 486 767
nextGet 0 486 767
assign 1 487 768
has 1 487 768
put 1 488 770
return 1 492 778
assign 1 496 788
new 0 496 788
assign 1 497 789
setIteratorGet 0 0 789
assign 1 497 792
hasNextGet 0 497 792
assign 1 497 794
nextGet 0 497 794
put 1 498 795
assign 1 500 801
def 1 500 806
assign 1 501 807
setIteratorGet 0 0 807
assign 1 501 810
hasNextGet 0 501 810
assign 1 501 812
nextGet 0 501 812
put 1 502 813
return 1 505 820
assign 1 509 824
copy 0 509 824
addValue 1 510 825
return 1 511 826
assign 1 515 836
def 1 515 841
assign 1 516 842
sameType 1 516 842
assign 1 517 844
iteratorGet 0 0 844
assign 1 517 847
hasNextGet 0 517 847
assign 1 517 849
nextGet 0 517 849
put 1 518 850
assign 1 520 858
sameType 1 520 858
assign 1 521 860
keyGet 0 521 860
put 1 521 861
put 1 523 864
return 1 0 871
assign 1 0 874
return 1 0 878
assign 1 0 881
return 1 0 885
assign 1 0 888
return 1 0 892
assign 1 0 895
return 1 0 899
assign 1 0 902
return 1 0 906
assign 1 0 909
return 1 0 913
assign 1 0 916
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -712928736: return bem_innerPutAddedGet_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1586230380: return bem_moduGet_0();
case -1114073101: return bem_keysGet_0();
case 104713553: return bem_new_0();
case 2086347094: return bem_nodesGet_0();
case 287040793: return bem_hashGet_0();
case 2056412570: return bem_keyIteratorGet_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case -2142483603: return bem_notEmptyGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case -1431826729: return bem_nodeIteratorGet_0();
case 1820417453: return bem_create_0();
case 1227011022: return bem_multiGet_0();
case -578884498: return bem_relGet_0();
case -786424307: return bem_tagGet_0();
case 235611348: return bem_baseNodeGet_0();
case 499932279: return bem_setIteratorGet_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -1575148127: return bem_moduSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case -567802245: return bem_relSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -79841285: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case -286659903: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -668984013: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -131089957: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_3_ContainerSet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_3_ContainerSet.bevs_inst = (BEC_2_9_3_ContainerSet)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_3_ContainerSet.bevs_inst;
}
}
}
