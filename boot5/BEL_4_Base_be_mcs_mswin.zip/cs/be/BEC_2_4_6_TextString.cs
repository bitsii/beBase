namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_6_TextString : BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }
static BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) { 
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) { 
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) { 
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(string bevi_string) {
        byte[] bevi_bytes = System.Text.Encoding.UTF8.GetBytes(bevi_string);
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public string bems_toCsString() {
        string csString = System.Text.Encoding.UTF8.GetString(bevi_bytes, 0, bevp_size.bevi_int);
        return csString;
    }
    
   private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_11 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_0 = {0x0A};
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_16 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_17 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_18 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(43));
private static BEC_2_4_3_MathInt bevo_19 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bevo_20 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(57));
private static BEC_2_4_3_MathInt bevo_21 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bevo_22 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_23 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bevo_24 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bevo_25 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bevo_26 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_27 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_28 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_29 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_30 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_31 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bevo_32 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bevo_33 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bevo_34 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bevo_35 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_36 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_37 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_38 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_39 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_40 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_41 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_42 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_43 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_44 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_45 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
private static BEC_2_4_3_MathInt bevo_46 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_47 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_2_4_3_MathInt bevo_48 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_49 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_2_4_6_TextString bevs_inst;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_leni;
public BEC_2_4_3_MathInt bevp_sizi;
public BEC_2_4_6_TextString bem_vstringGet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
this.bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_capacity == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevp_capacity = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 187 */
 else  /* Line: 186 */ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 188 */ {
return this;
} /* Line: 189 */
} /* Line: 186 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        byte[] bevls_bytes = new byte[beva_ncap.bevi_int];
        Array.Copy(this.bevi_bytes, bevls_bytes, Math.Min(this.bevi_bytes.Length, bevls_bytes.Length));
        this.bevi_bytes = bevls_bytes;
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 221 */
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_1;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
this.bem_new_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = bevo_2;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevt_5_tmpany_phold = bevo_3;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
this.bem_setHex_2(bevt_4_tmpany_phold, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_1_tmpany_phold = this.bem_getCode_2(beva_pos, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_toString_3(bevt_3_tmpany_phold, bevt_4_tmpany_phold, bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
this.bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
if (bevp_leni == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 245 */
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevp_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevp_sizi.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 250 */ {
bevt_5_tmpany_phold = bevo_4;
bevt_4_tmpany_phold = bevp_sizi.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bevo_5;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_multiply_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevo_6;
bevl_nsize = bevt_3_tmpany_phold.bem_divide_1(bevt_7_tmpany_phold);
this.bem_capacitySet_1(bevl_nsize);
} /* Line: 252 */
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_9_tmpany_phold = bevl_str.bem_sizeGet_0();
this.bem_copyValue_4(bevl_str, bevt_8_tmpany_phold, bevt_9_tmpany_phold, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) {
this.bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) {
beva_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = (BEC_2_4_6_TextString) this.bem_copy_0();
this.bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_7;
if (bevp_size.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_3_tmpany_phold = bevo_8;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bevo_9;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
this.bem_setIntUnchecked_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
bevt_7_tmpany_phold = bevo_10;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_6_tmpany_phold.bevi_int;
} /* Line: 288 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bevo_11;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = bevo_12;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
this.bem_setCodeUnchecked_2(bevt_3_tmpany_phold, (BEC_2_4_3_MathInt) beva_codei);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpany_phold.bem_newlineGet_0();
bevt_1_tmpany_phold = this.bem_ends_1(bevl_nl);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_3_tmpany_phold = bevo_13;
bevt_5_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpany_phold = bevp_size.bem_subtract_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold = this.bem_substring_2(bevt_3_tmpany_phold, bevt_4_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 301 */
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevt_6_tmpany_phold = this.bem_ends_1(bevl_nl);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevt_8_tmpany_phold = bevo_14;
bevt_10_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpany_phold = bevp_size.bem_subtract_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = this.bem_substring_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
return bevt_7_tmpany_phold;
} /* Line: 305 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_15;
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_c = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_c.bem_addValue_1(this);
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_found = this.bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_3_tmpany_phold = bevo_16;
if (bevl_found.bevi_int != bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 318 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 318 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 319 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_str == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 325 */
bevt_3_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpany_phold = bevp_size.bem_subtract_1(bevt_3_tmpany_phold);
bevl_found = this.bem_find_2(beva_str, bevt_2_tmpany_phold);
if (bevl_found == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 328 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_3_tmpany_phold = this.bem_find_1(beva_str);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 334 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 334 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 335 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 342 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 342 */ {
this.bem_getInt_2(bevl_j, bevl_ic);
bevt_4_tmpany_phold = bevo_17;
if (bevl_j.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_6_tmpany_phold = bevo_18;
if (bevl_ic.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_8_tmpany_phold = bevo_19;
if (bevl_ic.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 344 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 344 */
 else  /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 344 */ {
} /* Line: 344 */
 else  /* Line: 344 */ {
bevt_10_tmpany_phold = bevo_20;
if (bevl_ic.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
bevt_12_tmpany_phold = bevo_21;
if (bevl_ic.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 346 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 346 */ {
bevt_13_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_13_tmpany_phold;
} /* Line: 347 */
} /* Line: 344 */
bevl_j.bevi_int++;
} /* Line: 342 */
 else  /* Line: 342 */ {
break;
} /* Line: 342 */
} /* Line: 342 */
bevt_14_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_14_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 355 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 355 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bevo_22;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_5_tmpany_phold = bevo_23;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 357 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 357 */
 else  /* Line: 357 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 357 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_tmpany_phold.bevi_int;
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 359 */
bevl_j.bevi_int++;
} /* Line: 355 */
 else  /* Line: 355 */ {
break;
} /* Line: 355 */
} /* Line: 355 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_lowerValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 370 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 370 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bevo_24;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevt_5_tmpany_phold = bevo_25;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 372 */
 else  /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 372 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpany_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 374 */
bevl_j.bevi_int++;
} /* Line: 370 */
 else  /* Line: 370 */ {
break;
} /* Line: 370 */
} /* Line: 370 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_upperValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap0_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_2_tmpany_phold = this.bem_split_1(beva_from);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_to, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 393 */ {
if (bevl_nxt == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 393 */ {
bevl_nxt = this.bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 395 */ {
bevt_2_tmpany_phold = this.bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_tmpany_phold);
bevl_res.bem_addValue_1(beva_to);
bevt_3_tmpany_phold = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 398 */
 else  /* Line: 400 */ {
bevt_5_tmpany_phold = this.bem_sizeGet_0();
bevt_4_tmpany_phold = this.bem_substring_2(bevl_last, bevt_5_tmpany_phold);
bevl_res.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 401 */
} /* Line: 395 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_j = this.bem_mbiterGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 412 */ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 412 */ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 412 */
 else  /* Line: 412 */ {
break;
} /* Line: 412 */
} /* Line: 412 */
bevt_2_tmpany_phold = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_tmpany_phold.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_tmpany_phold.bevi_int;
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 422 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 422 */ {
this.bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpany_phold);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 422 */
 else  /* Line: 422 */ {
break;
} /* Line: 422 */
} /* Line: 422 */
return beva_into;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = this.bem_hashValue_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = this.bem_getCode_2(beva_pos, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_26;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 446 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 446 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 446 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 446 */
 else  /* Line: 446 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 446 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int > 127) {
            beva_into.bevi_int -= 256;
         }
         } /* Line: 466 */
 else  /* Line: 474 */ {
return null;
} /* Line: 475 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_27;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 488 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 488 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 488 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 488 */
 else  /* Line: 488 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 488 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 512 */
 else  /* Line: 517 */ {
return null;
} /* Line: 518 */
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_28;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 524 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 524 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 524 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 524 */
 else  /* Line: 524 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 524 */ {
this.bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 525 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_29;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 530 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 530 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 530 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 530 */
 else  /* Line: 530 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 530 */ {
this.bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 531 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevl_input = this;
bevt_3_tmpany_phold = bevl_input.bem_sizeGet_0();
bevl_insz = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_copy_0();
bevl_output = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_p = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 541 */ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 541 */ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_tmpany_phold = bevo_30;
if (bevl_c.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_8_tmpany_phold = bevo_31;
if (bevl_c.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
 else  /* Line: 543 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_10_tmpany_phold = bevo_32;
if (bevl_c.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_12_tmpany_phold = bevo_33;
if (bevl_c.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
 else  /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_14_tmpany_phold = bevo_34;
if (bevl_c.bevi_int > bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_16_tmpany_phold = bevo_35;
if (bevl_c.bevi_int < bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
 else  /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 543 */ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 545 */
bevl_i.bevi_int++;
} /* Line: 541 */
 else  /* Line: 541 */ {
break;
} /* Line: 541 */
} /* Line: 541 */
bevl_output.bem_sizeSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_36;
if (bevp_size.bevi_int <= bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 553 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 554 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b < 0) {
        twvls_b += 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_rfind_1(beva_str);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_reverseBytes_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) beva_str.bem_copy_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_reverseBytes_0();
bevl_rpos = bevt_0_tmpany_phold.bem_find_1(bevt_2_tmpany_phold);
if (bevl_rpos == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 647 */ {
bevt_5_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpany_phold;
} /* Line: 649 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_37;
bevt_0_tmpany_phold = this.bem_find_2(beva_str, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
if (beva_str == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
if (beva_start == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 661 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_9_tmpany_phold = bevo_38;
if (beva_start.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 661 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 661 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_12_tmpany_phold = beva_str.bem_sizeGet_0();
if (bevt_12_tmpany_phold.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 661 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_14_tmpany_phold = bevo_39;
if (bevp_size.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 661 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_16_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpany_phold = bevo_40;
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 661 */ {
return null;
} /* Line: 662 */
bevl_end = bevp_size;
bevl_current = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_strfirst = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_18_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpany_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpany_phold = bevo_41;
if (bevl_strsize.bevi_int > bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 673 */ {
bevl_strval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_current2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_end2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 676 */
bevl_currentstr2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 679 */ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 679 */ {
this.bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 681 */ {
bevt_24_tmpany_phold = bevo_42;
if (bevl_strsize.bevi_int == bevt_24_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 682 */ {
return bevl_current;
} /* Line: 683 */
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_tmpany_phold.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 689 */ {
return null;
} /* Line: 690 */
bevt_28_tmpany_phold = bevo_43;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
bevl_currentstr2.bevi_int = bevt_27_tmpany_phold.bevi_int;
while (true)
 /* Line: 693 */ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 693 */ {
this.bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 696 */ {
break;
} /* Line: 697 */
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 700 */
 else  /* Line: 693 */ {
break;
} /* Line: 693 */
} /* Line: 693 */
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 702 */ {
return bevl_current;
} /* Line: 703 */
} /* Line: 702 */
bevl_current.bevi_int++;
} /* Line: 706 */
 else  /* Line: 679 */ {
break;
} /* Line: 679 */
} /* Line: 679 */
return null;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = this.bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 716 */ {
if (bevl_i == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 716 */ {
bevt_1_tmpany_phold = this.bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpany_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = this.bem_find_2(beva_delim, bevl_last);
} /* Line: 719 */
 else  /* Line: 716 */ {
break;
} /* Line: 716 */
} /* Line: 716 */
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 721 */ {
bevt_3_tmpany_phold = this.bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 722 */
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitLines_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_9_TextTokenizer bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_lineSplitterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_tokenize_1(this);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_stri == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 744 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 744 */ {
bevt_2_tmpany_phold = beva_stri.bemd_1(-1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 744 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 744 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 744 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 744 */ {
return null;
} /* Line: 745 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 749 */ {
bevl_maxsize = bevl_osize;
} /* Line: 750 */
 else  /* Line: 751 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 752 */
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_mv = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ov = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 757 */ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 757 */ {
this.bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(340923734, BEL_4_Base.bevn_getCode_2, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 760 */ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 761 */ {
bevt_7_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_7_tmpany_phold;
} /* Line: 762 */
 else  /* Line: 763 */ {
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_8_tmpany_phold;
} /* Line: 764 */
} /* Line: 761 */
bevl_i.bevi_int++;
} /* Line: 757 */
 else  /* Line: 757 */ {
break;
} /* Line: 757 */
} /* Line: 757 */
bevt_10_tmpany_phold = bevo_44;
if (bevl_myret.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 768 */ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 769 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 770 */
 else  /* Line: 769 */ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 771 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 772 */
} /* Line: 769 */
} /* Line: 769 */
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 779 */ {
return null;
} /* Line: 779 */
bevt_2_tmpany_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bevo_45;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 780 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 781 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 787 */ {
return null;
} /* Line: 787 */
bevt_2_tmpany_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bevo_46;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 788 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 789 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

  var bevls_stri = beva_stri as BEC_2_4_6_TextString;
  //if (bevls_stri != null) {
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  //}
  bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_equals_1(beva_str);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_tmpany_phold, bevp_size, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_tmpany_phold, bevt_5_tmpany_phold, bevp_size);
return bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) {
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_47;
if (beva_starti.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 880 */ {
bevt_4_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 880 */ {
bevt_6_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 880 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 880 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 880 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bels_1));
bevt_7_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 881 */
 else  /* Line: 882 */ {
if (bevp_leni == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 885 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 887 */
bevp_leni.bevi_int = beva_endi.bevi_int;
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bevi_int = beva_dstarti.bevi_int;
bevp_sizi.bevi_int += bevp_leni.bevi_int;
if (bevp_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 896 */ {
this.bem_capacitySet_1(bevp_sizi);
} /* Line: 897 */

         //source, sourceStart, dest, destStart, length
         Array.Copy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevp_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 952 */ {
bevp_size.bevi_int = bevp_sizi.bevi_int;
} /* Line: 956 */
return this;
} /* Line: 958 */
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_sizeGet_0();
bevt_0_tmpany_phold = this.bem_substring_2(beva_starti, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevi_bytes.Length - 1);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_print_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevp_size.bevi_int);
stdout.WriteByte(10);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_echo_0() {
this.bem_output_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_snw == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1084 */ {
this.bem_new_0();
} /* Line: 1085 */
 else  /* Line: 1086 */ {
bevt_2_tmpany_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpany_phold = bevo_48;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
this.bem_new_1(bevt_1_tmpany_phold);
this.bem_addValue_1(beva_snw);
} /* Line: 1088 */
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_strip_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevl_vb = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ve = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_b = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bevo_49;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpany_phold);
while (true)
 /* Line: 1105 */ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1105 */ {
this.bem_getInt_2(bevl_b, bevl_vb);
this.bem_getInt_2(bevl_e, bevl_ve);
this.bem_setInt_2(bevl_b, bevl_ve);
this.bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1111 */
 else  /* Line: 1105 */ {
break;
} /* Line: 1105 */
} /* Line: 1105 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGet_0() {
return bevp_leni;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGet_0() {
return bevp_sizi;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {168, 169, 182, 182, 182, 186, 186, 187, 188, 188, 189, 220, 220, 221, 223, 227, 227, 227, 228, 228, 228, 229, 229, 229, 233, 233, 233, 233, 233, 233, 233, 237, 238, 242, 243, 243, 244, 245, 247, 247, 248, 250, 250, 251, 251, 251, 251, 251, 251, 252, 254, 254, 254, 258, 262, 266, 270, 280, 281, 282, 286, 286, 286, 287, 287, 287, 287, 287, 288, 288, 288, 293, 293, 294, 294, 294, 295, 295, 295, 299, 299, 300, 301, 301, 301, 301, 301, 303, 304, 305, 305, 305, 305, 305, 307, 311, 311, 311, 312, 313, 317, 318, 318, 0, 318, 318, 318, 0, 0, 319, 319, 321, 321, 325, 325, 325, 325, 326, 326, 326, 327, 327, 328, 328, 330, 330, 334, 334, 0, 334, 334, 334, 0, 0, 335, 335, 337, 337, 341, 342, 342, 342, 343, 344, 344, 344, 344, 344, 344, 0, 344, 344, 344, 0, 0, 0, 0, 0, 346, 346, 346, 0, 346, 346, 346, 0, 0, 347, 347, 342, 350, 350, 354, 355, 355, 355, 356, 357, 357, 357, 357, 357, 357, 0, 0, 0, 358, 358, 359, 355, 365, 365, 365, 369, 370, 370, 370, 371, 372, 372, 372, 372, 372, 372, 0, 0, 0, 373, 373, 374, 370, 380, 380, 380, 384, 384, 384, 384, 390, 391, 392, 393, 393, 394, 395, 395, 396, 396, 397, 398, 398, 401, 401, 401, 405, 410, 410, 411, 412, 412, 412, 413, 412, 415, 415, 416, 420, 421, 421, 422, 422, 422, 423, 424, 424, 425, 422, 428, 432, 432, 432, 436, 436, 436, 446, 446, 446, 446, 446, 0, 0, 0, 475, 477, 488, 488, 488, 488, 488, 0, 0, 0, 518, 520, 524, 524, 524, 524, 524, 0, 0, 0, 525, 530, 530, 530, 530, 530, 0, 0, 0, 531, 536, 537, 537, 538, 539, 540, 541, 541, 541, 542, 543, 543, 543, 543, 543, 543, 0, 0, 0, 0, 543, 543, 543, 543, 543, 543, 0, 0, 0, 0, 0, 0, 543, 543, 543, 543, 543, 543, 0, 0, 0, 0, 0, 544, 545, 541, 548, 549, 553, 553, 553, 554, 554, 556, 556, 639, 639, 645, 645, 645, 645, 645, 647, 647, 648, 648, 649, 649, 651, 655, 655, 655, 661, 661, 0, 661, 661, 0, 0, 0, 661, 661, 661, 0, 0, 0, 661, 661, 0, 0, 0, 661, 661, 661, 0, 0, 0, 661, 661, 661, 0, 0, 0, 661, 661, 661, 661, 0, 0, 662, 665, 666, 667, 668, 669, 669, 671, 673, 673, 673, 674, 675, 676, 678, 679, 679, 680, 681, 681, 682, 682, 682, 683, 685, 686, 687, 688, 688, 689, 689, 690, 692, 692, 692, 693, 693, 694, 695, 696, 696, 699, 700, 702, 702, 703, 706, 708, 712, 713, 714, 715, 716, 716, 717, 717, 718, 719, 721, 721, 722, 722, 724, 728, 728, 728, 732, 732, 732, 732, 736, 744, 744, 0, 744, 0, 0, 745, 747, 748, 749, 749, 750, 752, 754, 755, 756, 757, 757, 757, 758, 759, 760, 760, 761, 761, 762, 762, 764, 764, 757, 768, 768, 768, 769, 769, 770, 771, 771, 772, 775, 779, 779, 779, 780, 780, 780, 780, 781, 781, 783, 783, 787, 787, 787, 788, 788, 788, 788, 789, 789, 791, 791, 840, 840, 844, 844, 844, 848, 849, 849, 849, 850, 850, 850, 851, 851, 851, 852, 855, 855, 880, 880, 880, 0, 880, 880, 880, 0, 880, 880, 880, 0, 0, 0, 0, 881, 881, 881, 885, 885, 886, 887, 889, 890, 891, 893, 894, 896, 896, 897, 952, 952, 956, 958, 963, 963, 963, 967, 967, 967, 967, 967, 1052, 1056, 1056, 1060, 1060, 1064, 1064, 1068, 1068, 1072, 1072, 1076, 1076, 1080, 1084, 1084, 1085, 1087, 1087, 1087, 1087, 1088, 1093, 1093, 1097, 1097, 1097, 1101, 1102, 1103, 1104, 1104, 1105, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {107, 108, 114, 115, 116, 123, 128, 129, 132, 137, 138, 149, 154, 155, 157, 167, 168, 169, 170, 171, 172, 173, 174, 175, 185, 186, 187, 188, 189, 190, 191, 195, 196, 212, 213, 218, 219, 220, 222, 223, 224, 225, 230, 231, 232, 233, 234, 235, 236, 237, 239, 240, 241, 245, 248, 251, 255, 266, 267, 268, 279, 280, 285, 286, 287, 288, 289, 290, 291, 292, 293, 303, 304, 305, 306, 307, 308, 309, 310, 326, 327, 328, 330, 331, 332, 333, 334, 336, 337, 339, 340, 341, 342, 343, 345, 351, 352, 353, 354, 355, 365, 366, 371, 372, 375, 376, 381, 382, 385, 389, 390, 392, 393, 404, 409, 410, 411, 413, 414, 415, 416, 421, 422, 423, 425, 426, 435, 440, 441, 444, 445, 450, 451, 454, 458, 459, 461, 462, 482, 483, 486, 491, 492, 493, 494, 499, 500, 501, 506, 507, 510, 511, 516, 517, 520, 524, 527, 531, 536, 537, 542, 543, 546, 547, 552, 553, 556, 560, 561, 564, 570, 571, 583, 584, 587, 592, 593, 594, 595, 600, 601, 602, 607, 608, 611, 615, 618, 619, 620, 622, 633, 634, 635, 647, 648, 651, 656, 657, 658, 659, 664, 665, 666, 671, 672, 675, 679, 682, 683, 684, 686, 697, 698, 699, 705, 706, 707, 708, 720, 721, 722, 725, 730, 731, 732, 737, 738, 739, 740, 741, 742, 745, 746, 747, 754, 764, 765, 766, 767, 770, 775, 776, 777, 783, 784, 785, 793, 794, 795, 796, 799, 804, 805, 806, 807, 808, 809, 815, 820, 821, 822, 827, 828, 829, 836, 837, 842, 843, 848, 849, 852, 856, 866, 868, 875, 876, 881, 882, 887, 888, 891, 895, 902, 904, 911, 912, 917, 918, 923, 924, 927, 931, 934, 943, 944, 949, 950, 955, 956, 959, 963, 966, 994, 995, 996, 997, 998, 999, 1000, 1003, 1008, 1009, 1010, 1011, 1016, 1017, 1018, 1023, 1024, 1027, 1031, 1034, 1037, 1038, 1043, 1044, 1045, 1050, 1051, 1054, 1058, 1061, 1064, 1068, 1071, 1072, 1077, 1078, 1079, 1084, 1085, 1088, 1092, 1095, 1098, 1102, 1103, 1105, 1111, 1112, 1119, 1120, 1125, 1126, 1127, 1129, 1130, 1148, 1149, 1160, 1161, 1162, 1163, 1164, 1165, 1170, 1171, 1172, 1173, 1174, 1176, 1181, 1182, 1183, 1227, 1232, 1233, 1236, 1241, 1242, 1245, 1249, 1252, 1253, 1258, 1259, 1262, 1266, 1269, 1274, 1275, 1278, 1282, 1285, 1286, 1291, 1292, 1295, 1299, 1302, 1303, 1308, 1309, 1312, 1316, 1319, 1320, 1321, 1326, 1327, 1330, 1334, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1349, 1350, 1351, 1352, 1354, 1357, 1362, 1363, 1364, 1369, 1370, 1371, 1376, 1377, 1379, 1380, 1381, 1382, 1383, 1384, 1389, 1390, 1392, 1393, 1394, 1397, 1402, 1403, 1404, 1405, 1410, 1413, 1414, 1420, 1425, 1426, 1429, 1435, 1446, 1447, 1448, 1449, 1452, 1457, 1458, 1459, 1460, 1461, 1467, 1472, 1473, 1474, 1476, 1481, 1482, 1483, 1489, 1490, 1491, 1492, 1495, 1518, 1523, 1524, 1527, 1529, 1532, 1536, 1538, 1539, 1540, 1545, 1546, 1549, 1551, 1552, 1553, 1554, 1557, 1562, 1563, 1564, 1565, 1570, 1571, 1576, 1577, 1578, 1581, 1582, 1585, 1591, 1592, 1597, 1598, 1603, 1604, 1607, 1612, 1613, 1617, 1626, 1631, 1632, 1634, 1635, 1636, 1641, 1642, 1643, 1645, 1646, 1655, 1660, 1661, 1663, 1664, 1665, 1670, 1671, 1672, 1674, 1675, 1691, 1692, 1697, 1698, 1703, 1714, 1715, 1716, 1717, 1718, 1719, 1720, 1721, 1722, 1723, 1724, 1728, 1729, 1746, 1747, 1752, 1753, 1756, 1757, 1762, 1763, 1766, 1767, 1772, 1773, 1776, 1780, 1783, 1787, 1788, 1789, 1792, 1797, 1798, 1799, 1801, 1802, 1803, 1804, 1805, 1806, 1811, 1812, 1817, 1822, 1823, 1825, 1831, 1832, 1833, 1840, 1841, 1842, 1843, 1844, 1860, 1865, 1866, 1870, 1871, 1875, 1876, 1880, 1881, 1885, 1886, 1890, 1891, 1894, 1901, 1906, 1907, 1910, 1911, 1912, 1913, 1914, 1920, 1921, 1926, 1927, 1928, 1937, 1938, 1939, 1940, 1941, 1944, 1949, 1950, 1951, 1952, 1953, 1954, 1955, 1964, 1967, 1971, 1974, 1977, 1981, 1984};
/* BEGIN LINEINFO 
assign 1 168 107
new 0 168 107
capacitySet 1 169 108
assign 1 182 114
new 0 182 114
assign 1 182 115
once 0 182 115
new 1 182 116
assign 1 186 123
undef 1 186 128
assign 1 187 129
new 0 187 129
assign 1 188 132
equals 1 188 137
return 1 189 138
assign 1 220 149
greater 1 220 154
setValue 1 221 155
setValue 1 223 157
assign 1 227 167
new 0 227 167
assign 1 227 168
once 0 227 168
new 1 227 169
assign 1 228 170
new 0 228 170
assign 1 228 171
once 0 228 171
setValue 1 228 172
assign 1 229 173
new 0 229 173
assign 1 229 174
once 0 229 174
setHex 2 229 175
assign 1 233 185
new 0 233 185
assign 1 233 186
getCode 2 233 186
assign 1 233 187
new 0 233 187
assign 1 233 188
new 0 233 188
assign 1 233 189
new 0 233 189
assign 1 233 190
toString 3 233 190
return 1 233 191
assign 1 237 195
hexNew 1 237 195
setCode 2 238 196
assign 1 242 212
toString 0 242 212
assign 1 243 213
undef 1 243 218
assign 1 244 219
new 0 244 219
assign 1 245 220
new 0 245 220
assign 1 247 222
sizeGet 0 247 222
setValue 1 247 223
addValue 1 248 224
assign 1 250 225
lesser 1 250 230
assign 1 251 231
new 0 251 231
assign 1 251 232
add 1 251 232
assign 1 251 233
new 0 251 233
assign 1 251 234
multiply 1 251 234
assign 1 251 235
new 0 251 235
assign 1 251 236
divide 1 251 236
capacitySet 1 252 237
assign 1 254 239
new 0 254 239
assign 1 254 240
sizeGet 0 254 240
copyValue 4 254 241
return 1 258 245
return 1 262 248
addValue 1 266 251
write 1 270 255
assign 1 280 266
copy 0 280 266
clear 0 281 267
return 1 282 268
assign 1 286 279
new 0 286 279
assign 1 286 280
greater 1 286 285
assign 1 287 286
new 0 287 286
assign 1 287 287
once 0 287 287
assign 1 287 288
new 0 287 288
assign 1 287 289
once 0 287 289
setIntUnchecked 2 287 290
assign 1 288 291
new 0 288 291
assign 1 288 292
once 0 288 292
setValue 1 288 293
assign 1 293 303
new 0 293 303
new 1 293 304
assign 1 294 305
new 0 294 305
assign 1 294 306
once 0 294 306
setValue 1 294 307
assign 1 295 308
new 0 295 308
assign 1 295 309
once 0 295 309
setCodeUnchecked 2 295 310
assign 1 299 326
new 0 299 326
assign 1 299 327
newlineGet 0 299 327
assign 1 300 328
ends 1 300 328
assign 1 301 330
new 0 301 330
assign 1 301 331
sizeGet 0 301 331
assign 1 301 332
subtract 1 301 332
assign 1 301 333
substring 2 301 333
return 1 301 334
assign 1 303 336
new 0 303 336
assign 1 304 337
ends 1 304 337
assign 1 305 339
new 0 305 339
assign 1 305 340
sizeGet 0 305 340
assign 1 305 341
subtract 1 305 341
assign 1 305 342
substring 2 305 342
return 1 305 343
return 1 307 345
assign 1 311 351
new 0 311 351
assign 1 311 352
add 1 311 352
assign 1 311 353
new 1 311 353
addValue 1 312 354
return 1 313 355
assign 1 317 365
find 1 317 365
assign 1 318 366
undef 1 318 371
assign 1 0 372
assign 1 318 375
new 0 318 375
assign 1 318 376
notEquals 1 318 381
assign 1 0 382
assign 1 0 385
assign 1 319 389
new 0 319 389
return 1 319 390
assign 1 321 392
new 0 321 392
return 1 321 393
assign 1 325 404
undef 1 325 409
assign 1 325 410
new 0 325 410
return 1 325 411
assign 1 326 413
sizeGet 0 326 413
assign 1 326 414
subtract 1 326 414
assign 1 326 415
find 2 326 415
assign 1 327 416
undef 1 327 421
assign 1 328 422
new 0 328 422
return 1 328 423
assign 1 330 425
new 0 330 425
return 1 330 426
assign 1 334 435
undef 1 334 440
assign 1 0 441
assign 1 334 444
find 1 334 444
assign 1 334 445
undef 1 334 450
assign 1 0 451
assign 1 0 454
assign 1 335 458
new 0 335 458
return 1 335 459
assign 1 337 461
new 0 337 461
return 1 337 462
assign 1 341 482
new 0 341 482
assign 1 342 483
new 0 342 483
assign 1 342 486
lesser 1 342 491
getInt 2 343 492
assign 1 344 493
new 0 344 493
assign 1 344 494
equals 1 344 499
assign 1 344 500
new 0 344 500
assign 1 344 501
equals 1 344 506
assign 1 0 507
assign 1 344 510
new 0 344 510
assign 1 344 511
equals 1 344 516
assign 1 0 517
assign 1 0 520
assign 1 0 524
assign 1 0 527
assign 1 0 531
assign 1 346 536
new 0 346 536
assign 1 346 537
greater 1 346 542
assign 1 0 543
assign 1 346 546
new 0 346 546
assign 1 346 547
lesser 1 346 552
assign 1 0 553
assign 1 0 556
assign 1 347 560
new 0 347 560
return 1 347 561
incrementValue 0 342 564
assign 1 350 570
new 0 350 570
return 1 350 571
assign 1 354 583
new 0 354 583
assign 1 355 584
new 0 355 584
assign 1 355 587
lesser 1 355 592
getInt 2 356 593
assign 1 357 594
new 0 357 594
assign 1 357 595
greater 1 357 600
assign 1 357 601
new 0 357 601
assign 1 357 602
lesser 1 357 607
assign 1 0 608
assign 1 0 611
assign 1 0 615
assign 1 358 618
new 0 358 618
addValue 1 358 619
setIntUnchecked 2 359 620
incrementValue 0 355 622
assign 1 365 633
copy 0 365 633
assign 1 365 634
lowerValue 0 365 634
return 1 365 635
assign 1 369 647
new 0 369 647
assign 1 370 648
new 0 370 648
assign 1 370 651
lesser 1 370 656
getInt 2 371 657
assign 1 372 658
new 0 372 658
assign 1 372 659
greater 1 372 664
assign 1 372 665
new 0 372 665
assign 1 372 666
lesser 1 372 671
assign 1 0 672
assign 1 0 675
assign 1 0 679
assign 1 373 682
new 0 373 682
subtractValue 1 373 683
setIntUnchecked 2 374 684
incrementValue 0 370 686
assign 1 380 697
copy 0 380 697
assign 1 380 698
upperValue 0 380 698
return 1 380 699
assign 1 384 705
new 0 384 705
assign 1 384 706
split 1 384 706
assign 1 384 707
join 2 384 707
return 1 384 708
assign 1 390 720
new 0 390 720
assign 1 391 721
new 0 391 721
assign 1 392 722
new 0 392 722
assign 1 393 725
def 1 393 730
assign 1 394 731
find 2 394 731
assign 1 395 732
def 1 395 737
assign 1 396 738
substring 2 396 738
addValue 1 396 739
addValue 1 397 740
assign 1 398 741
sizeGet 0 398 741
assign 1 398 742
add 1 398 742
assign 1 401 745
sizeGet 0 401 745
assign 1 401 746
substring 2 401 746
addValue 1 401 747
return 1 405 754
assign 1 410 764
new 0 410 764
assign 1 410 765
new 1 410 765
assign 1 411 766
mbiterGet 0 411 766
assign 1 412 767
new 0 412 767
assign 1 412 770
lesser 1 412 775
next 1 413 776
incrementValue 0 412 777
assign 1 415 783
next 1 415 783
assign 1 415 784
toString 0 415 784
return 1 416 785
assign 1 420 793
new 0 420 793
assign 1 421 794
new 0 421 794
setValue 1 421 795
assign 1 422 796
new 0 422 796
assign 1 422 799
lesser 1 422 804
getInt 2 423 805
assign 1 424 806
new 0 424 806
multiplyValue 1 424 807
addValue 1 425 808
incrementValue 0 422 809
return 1 428 815
assign 1 432 820
new 0 432 820
assign 1 432 821
hashValue 1 432 821
return 1 432 822
assign 1 436 827
new 0 436 827
assign 1 436 828
getCode 2 436 828
return 1 436 829
assign 1 446 836
new 0 446 836
assign 1 446 837
greaterEquals 1 446 842
assign 1 446 843
greater 1 446 848
assign 1 0 849
assign 1 0 852
assign 1 0 856
return 1 475 866
return 1 477 868
assign 1 488 875
new 0 488 875
assign 1 488 876
greaterEquals 1 488 881
assign 1 488 882
greater 1 488 887
assign 1 0 888
assign 1 0 891
assign 1 0 895
return 1 518 902
return 1 520 904
assign 1 524 911
new 0 524 911
assign 1 524 912
greaterEquals 1 524 917
assign 1 524 918
greater 1 524 923
assign 1 0 924
assign 1 0 927
assign 1 0 931
setIntUnchecked 2 525 934
assign 1 530 943
new 0 530 943
assign 1 530 944
greaterEquals 1 530 949
assign 1 530 950
greater 1 530 955
assign 1 0 956
assign 1 0 959
assign 1 0 963
setCodeUnchecked 2 531 966
assign 1 536 994
assign 1 537 995
sizeGet 0 537 995
assign 1 537 996
copy 0 537 996
assign 1 538 997
new 1 538 997
assign 1 539 998
new 0 539 998
assign 1 540 999
new 0 540 999
assign 1 541 1000
new 0 541 1000
assign 1 541 1003
lesser 1 541 1008
getInt 2 542 1009
assign 1 543 1010
new 0 543 1010
assign 1 543 1011
greater 1 543 1016
assign 1 543 1017
new 0 543 1017
assign 1 543 1018
lesser 1 543 1023
assign 1 0 1024
assign 1 0 1027
assign 1 0 1031
assign 1 0 1034
assign 1 543 1037
new 0 543 1037
assign 1 543 1038
greater 1 543 1043
assign 1 543 1044
new 0 543 1044
assign 1 543 1045
lesser 1 543 1050
assign 1 0 1051
assign 1 0 1054
assign 1 0 1058
assign 1 0 1061
assign 1 0 1064
assign 1 0 1068
assign 1 543 1071
new 0 543 1071
assign 1 543 1072
greater 1 543 1077
assign 1 543 1078
new 0 543 1078
assign 1 543 1079
lesser 1 543 1084
assign 1 0 1085
assign 1 0 1088
assign 1 0 1092
assign 1 0 1095
assign 1 0 1098
setIntUnchecked 2 544 1102
incrementValue 0 545 1103
incrementValue 0 541 1105
sizeSet 1 548 1111
return 1 549 1112
assign 1 553 1119
new 0 553 1119
assign 1 553 1120
lesserEquals 1 553 1125
assign 1 554 1126
new 0 554 1126
return 1 554 1127
assign 1 556 1129
new 0 556 1129
return 1 556 1130
assign 1 639 1148
rfind 1 639 1148
return 1 639 1149
assign 1 645 1160
copy 0 645 1160
assign 1 645 1161
reverseBytes 0 645 1161
assign 1 645 1162
copy 0 645 1162
assign 1 645 1163
reverseBytes 0 645 1163
assign 1 645 1164
find 1 645 1164
assign 1 647 1165
def 1 647 1170
assign 1 648 1171
sizeGet 0 648 1171
addValue 1 648 1172
assign 1 649 1173
subtract 1 649 1173
return 1 649 1174
return 1 651 1176
assign 1 655 1181
new 0 655 1181
assign 1 655 1182
find 2 655 1182
return 1 655 1183
assign 1 661 1227
undef 1 661 1232
assign 1 0 1233
assign 1 661 1236
undef 1 661 1241
assign 1 0 1242
assign 1 0 1245
assign 1 0 1249
assign 1 661 1252
new 0 661 1252
assign 1 661 1253
lesser 1 661 1258
assign 1 0 1259
assign 1 0 1262
assign 1 0 1266
assign 1 661 1269
greaterEquals 1 661 1274
assign 1 0 1275
assign 1 0 1278
assign 1 0 1282
assign 1 661 1285
sizeGet 0 661 1285
assign 1 661 1286
greater 1 661 1291
assign 1 0 1292
assign 1 0 1295
assign 1 0 1299
assign 1 661 1302
new 0 661 1302
assign 1 661 1303
equals 1 661 1308
assign 1 0 1309
assign 1 0 1312
assign 1 0 1316
assign 1 661 1319
sizeGet 0 661 1319
assign 1 661 1320
new 0 661 1320
assign 1 661 1321
equals 1 661 1326
assign 1 0 1327
assign 1 0 1330
return 1 662 1334
assign 1 665 1336
assign 1 666 1337
copy 0 666 1337
assign 1 667 1338
new 0 667 1338
assign 1 668 1339
new 0 668 1339
assign 1 669 1340
new 0 669 1340
getInt 2 669 1341
assign 1 671 1342
sizeGet 0 671 1342
assign 1 673 1343
new 0 673 1343
assign 1 673 1344
greater 1 673 1349
assign 1 674 1350
new 0 674 1350
assign 1 675 1351
new 0 675 1351
assign 1 676 1352
new 0 676 1352
assign 1 678 1354
new 0 678 1354
assign 1 679 1357
lesser 1 679 1362
getInt 2 680 1363
assign 1 681 1364
equals 1 681 1369
assign 1 682 1370
new 0 682 1370
assign 1 682 1371
equals 1 682 1376
return 1 683 1377
setValue 1 685 1379
incrementValue 0 686 1380
setValue 1 687 1381
assign 1 688 1382
sizeGet 0 688 1382
addValue 1 688 1383
assign 1 689 1384
greater 1 689 1389
return 1 690 1390
assign 1 692 1392
new 0 692 1392
assign 1 692 1393
once 0 692 1393
setValue 1 692 1394
assign 1 693 1397
lesser 1 693 1402
getInt 2 694 1403
getInt 2 695 1404
assign 1 696 1405
notEquals 1 696 1410
incrementValue 0 699 1413
incrementValue 0 700 1414
assign 1 702 1420
equals 1 702 1425
return 1 703 1426
incrementValue 0 706 1429
return 1 708 1435
assign 1 712 1446
new 0 712 1446
assign 1 713 1447
new 0 713 1447
assign 1 714 1448
find 2 714 1448
assign 1 715 1449
sizeGet 0 715 1449
assign 1 716 1452
def 1 716 1457
assign 1 717 1458
substring 2 717 1458
addValue 1 717 1459
assign 1 718 1460
add 1 718 1460
assign 1 719 1461
find 2 719 1461
assign 1 721 1467
lesser 1 721 1472
assign 1 722 1473
substring 2 722 1473
addValue 1 722 1474
return 1 724 1476
assign 1 728 1481
new 0 728 1481
assign 1 728 1482
join 2 728 1482
return 1 728 1483
assign 1 732 1489
new 0 732 1489
assign 1 732 1490
lineSplitterGet 0 732 1490
assign 1 732 1491
tokenize 1 732 1491
return 1 732 1492
return 1 736 1495
assign 1 744 1518
undef 1 744 1523
assign 1 0 1524
assign 1 744 1527
otherType 1 744 1527
assign 1 0 1529
assign 1 0 1532
return 1 745 1536
assign 1 747 1538
assign 1 748 1539
sizeGet 0 748 1539
assign 1 749 1540
greater 1 749 1545
assign 1 750 1546
assign 1 752 1549
assign 1 754 1551
new 0 754 1551
assign 1 755 1552
new 0 755 1552
assign 1 756 1553
new 0 756 1553
assign 1 757 1554
new 0 757 1554
assign 1 757 1557
lesser 1 757 1562
getCode 2 758 1563
getCode 2 759 1564
assign 1 760 1565
notEquals 1 760 1570
assign 1 761 1571
greater 1 761 1576
assign 1 762 1577
new 0 762 1577
return 1 762 1578
assign 1 764 1581
new 0 764 1581
return 1 764 1582
incrementValue 0 757 1585
assign 1 768 1591
new 0 768 1591
assign 1 768 1592
equals 1 768 1597
assign 1 769 1598
greater 1 769 1603
assign 1 770 1604
new 0 770 1604
assign 1 771 1607
greater 1 771 1612
assign 1 772 1613
new 0 772 1613
return 1 775 1617
assign 1 779 1626
undef 1 779 1631
return 1 779 1632
assign 1 780 1634
compare 1 780 1634
assign 1 780 1635
new 0 780 1635
assign 1 780 1636
equals 1 780 1641
assign 1 781 1642
new 0 781 1642
return 1 781 1643
assign 1 783 1645
new 0 783 1645
return 1 783 1646
assign 1 787 1655
undef 1 787 1660
return 1 787 1661
assign 1 788 1663
compare 1 788 1663
assign 1 788 1664
new 0 788 1664
assign 1 788 1665
equals 1 788 1670
assign 1 789 1671
new 0 789 1671
return 1 789 1672
assign 1 791 1674
new 0 791 1674
return 1 791 1675
assign 1 840 1691
new 0 840 1691
return 1 840 1692
assign 1 844 1697
equals 1 844 1697
assign 1 844 1698
not 0 844 1703
return 1 844 1703
assign 1 848 1714
toString 0 848 1714
assign 1 849 1715
sizeGet 0 849 1715
assign 1 849 1716
add 1 849 1716
assign 1 849 1717
new 1 849 1717
assign 1 850 1718
new 0 850 1718
assign 1 850 1719
new 0 850 1719
copyValue 4 850 1720
assign 1 851 1721
new 0 851 1721
assign 1 851 1722
sizeGet 0 851 1722
copyValue 4 851 1723
return 1 852 1724
assign 1 855 1728
new 0 855 1728
return 1 855 1729
assign 1 880 1746
new 0 880 1746
assign 1 880 1747
lesser 1 880 1752
assign 1 0 1753
assign 1 880 1756
sizeGet 0 880 1756
assign 1 880 1757
greater 1 880 1762
assign 1 0 1763
assign 1 880 1766
sizeGet 0 880 1766
assign 1 880 1767
greater 1 880 1772
assign 1 0 1773
assign 1 0 1776
assign 1 0 1780
assign 1 0 1783
assign 1 881 1787
new 0 881 1787
assign 1 881 1788
new 1 881 1788
throw 1 881 1789
assign 1 885 1792
undef 1 885 1797
assign 1 886 1798
new 0 886 1798
assign 1 887 1799
new 0 887 1799
setValue 1 889 1801
subtractValue 1 890 1802
assign 1 891 1803
setValue 1 893 1804
addValue 1 894 1805
assign 1 896 1806
greater 1 896 1811
capacitySet 1 897 1812
assign 1 952 1817
greater 1 952 1822
setValue 1 956 1823
return 1 958 1825
assign 1 963 1831
sizeGet 0 963 1831
assign 1 963 1832
substring 2 963 1832
return 1 963 1833
assign 1 967 1840
subtract 1 967 1840
assign 1 967 1841
new 1 967 1841
assign 1 967 1842
new 0 967 1842
assign 1 967 1843
copyValue 4 967 1843
return 1 967 1844
output 0 1052 1860
assign 1 1056 1865
new 1 1056 1865
return 1 1056 1866
assign 1 1060 1870
new 1 1060 1870
return 1 1060 1871
assign 1 1064 1875
new 1 1064 1875
return 1 1064 1876
assign 1 1068 1880
new 1 1068 1880
return 1 1068 1881
assign 1 1072 1885
new 1 1072 1885
return 1 1072 1886
assign 1 1076 1890
new 1 1076 1890
return 1 1076 1891
return 1 1080 1894
assign 1 1084 1901
undef 1 1084 1906
new 0 1085 1907
assign 1 1087 1910
sizeGet 0 1087 1910
assign 1 1087 1911
new 0 1087 1911
assign 1 1087 1912
add 1 1087 1912
new 1 1087 1913
addValue 1 1088 1914
assign 1 1093 1920
new 0 1093 1920
return 1 1093 1921
assign 1 1097 1926
new 0 1097 1926
assign 1 1097 1927
strip 1 1097 1927
return 1 1097 1928
assign 1 1101 1937
new 0 1101 1937
assign 1 1102 1938
new 0 1102 1938
assign 1 1103 1939
new 0 1103 1939
assign 1 1104 1940
new 0 1104 1940
assign 1 1104 1941
subtract 1 1104 1941
assign 1 1105 1944
greater 1 1105 1949
getInt 2 1106 1950
getInt 2 1107 1951
setInt 2 1108 1952
setInt 2 1109 1953
incrementValue 0 1110 1954
decrementValue 0 1111 1955
return 1 0 1964
assign 1 0 1967
return 1 0 1971
return 1 0 1974
assign 1 0 1977
return 1 0 1981
assign 1 0 1984
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 751851582: return bem_chomp_0();
case 1325881255: return bem_readBuffer_0();
case -1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 1670870885: return bem_isInteger_0();
case 825000908: return bem_vstringSet_0();
case 813918656: return bem_vstringGet_0();
case -1163089440: return bem_upperValue_0();
case 856777406: return bem_clear_0();
case 347960120: return bem_readString_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case -223231021: return bem_upper_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 1424677667: return bem_extractString_0();
case -855090856: return bem_multiByteIteratorGet_0();
case -1903477087: return bem_lowerValue_0();
case 70183026: return bem_output_0();
case 195899181: return bem_biterGet_0();
case -1010579589: return bem_open_0();
case 357005938: return bem_lower_0();
case 866536361: return bem_close_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1607888168: return bem_stringIteratorGet_0();
case 1820417453: return bem_create_0();
case 588679298: return bem_siziGet_0();
case -729571811: return bem_serializeToString_0();
case 1343944081: return bem_byteIteratorGet_0();
case -1881757495: return bem_strip_0();
case -139115914: return bem_splitLines_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1751843603: return bem_capacityGet_0();
case 1896696666: return bem_mbiterGet_0();
case -800915430: return bem_reverseBytes_0();
case -1354714650: return bem_copy_0();
case -85457677: return bem_leniGet_0();
case 960545748: return bem_toAlphaNum_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -1279784069: return bem_defined_1(bevd_0);
case -1406325780: return bem_writeTo_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 636254476: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1740761350: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1116723741: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -477101321: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 1320649901: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case -1143153819: return bem_codeNew_1(bevd_0);
case 1274753013: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 340923733: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case -74375424: return bem_leniSet_1(bevd_0);
case -1274448085: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case 1603004369: return bem_write_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1489442332: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case -1412717737: return bem_compare_1(bevd_0);
case -2001811380: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1250088509: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 599761551: return bem_siziSet_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case 1954998871: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1298743126: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1811422864: return bem_swap0_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -889715578: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1154529699: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -761715532: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1250088508: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2110339634: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1393886412: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1956186668: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1395074208: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 126306658: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 340923734: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1274448084: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case -391213135: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_TextString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_TextString.bevs_inst = (BEC_2_4_6_TextString)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_TextString.bevs_inst;
}
}
}
