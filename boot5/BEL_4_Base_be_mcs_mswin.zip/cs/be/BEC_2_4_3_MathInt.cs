namespace be {

using System.IO;
using System;
    /* IO:File: source/base/Int.be */
public sealed class BEC_2_4_3_MathInt : BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }
static BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(71));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(103));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(24));
private static byte[] bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 39));
private static BEC_2_4_3_MathInt bevo_11 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_16 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_17 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bevo_18 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_19 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bevo_20 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(45));
private static byte[] bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 21));
private static byte[] bels_2 = {0x20};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 1));
private static BEC_2_4_3_MathInt bevo_23 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_24 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_25 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_26 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_27 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bevo_28 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bevo_29 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_30 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_31 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_32 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_33 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_34 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bevo_35 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_36 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_3 = {0x2D};
private static BEC_2_4_3_MathInt bevo_37 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
public static new BEC_2_4_3_MathInt bevs_inst;
public BEC_2_4_3_MathInt bem_vintGet_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) {
this.bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) {
this.bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bevo_2;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bevo_3;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
this.bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_4;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bevo_5;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bevo_7;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
this.bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_8;
if (beva_radix.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_4_tmpany_phold = bevo_9;
if (beva_radix.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevt_7_tmpany_phold = bevo_10;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_radix);
bevt_5_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 83 */
bevt_9_tmpany_phold = bevo_11;
if (beva_radix.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevl_max0 = (BEC_2_4_3_MathInt) beva_radix.bem_copy_0();
} /* Line: 86 */
 else  /* Line: 87 */ {
bevl_max0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
} /* Line: 88 */
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_11_tmpany_phold = bevo_12;
bevt_13_tmpany_phold = bevo_13;
bevt_12_tmpany_phold = beva_radix.bem_subtract_1(bevt_13_tmpany_phold);
bevl_maxA = bevt_11_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevo_14;
bevt_16_tmpany_phold = bevo_15;
bevt_15_tmpany_phold = beva_radix.bem_subtract_1(bevt_16_tmpany_phold);
bevl_maxa = bevt_14_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
this.bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
this.bevi_int = bevt_3_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_j = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 102 */ {
bevt_6_tmpany_phold = bevo_16;
if (bevl_j.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 102 */ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_tmpany_phold = bevo_17;
if (bevl_ic.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 106 */ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 106 */
 else  /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 106 */ {
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bevi_int += bevl_ic.bevi_int;
} /* Line: 109 */
 else  /* Line: 106 */ {
bevt_12_tmpany_phold = bevo_18;
if (bevl_ic.bevi_int > bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 110 */ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 110 */
 else  /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 110 */ {
bevt_14_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bevi_int += bevl_ic.bevi_int;
} /* Line: 113 */
 else  /* Line: 106 */ {
bevt_16_tmpany_phold = bevo_19;
if (bevl_ic.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 114 */ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 114 */
 else  /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 114 */ {
bevt_18_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bevi_int += bevl_ic.bevi_int;
} /* Line: 117 */
 else  /* Line: 106 */ {
bevt_20_tmpany_phold = bevo_20;
if (bevl_ic.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_21_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
this.bem_multiplyValue_1(bevt_21_tmpany_phold);
} /* Line: 120 */
 else  /* Line: 121 */ {
bevt_26_tmpany_phold = bevo_21;
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(beva_str);
bevt_27_tmpany_phold = bevo_22;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevl_ic);
bevt_22_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_23_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_22_tmpany_phold);
} /* Line: 122 */
} /* Line: 106 */
} /* Line: 106 */
} /* Line: 106 */
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 125 */
 else  /* Line: 102 */ {
break;
} /* Line: 102 */
} /* Line: 102 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
this.bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_toFloat_0() {
BEC_2_4_5_MathFloat bevl_fi = null;
bevl_fi = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bevo_23;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_6_tmpany_phold = bevo_24;
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) bevt_6_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_4(bevt_1_tmpany_phold, bevt_3_tmpany_phold, bevt_5_tmpany_phold, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = this.bem_toHexString_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_25;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_4_tmpany_phold = bevo_26;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_3(beva_res, bevt_1_tmpany_phold, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_3_tmpany_phold = bevo_27;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_4(bevt_1_tmpany_phold, beva_zeroPad, beva_radix, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_28;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
beva_res.bem_clear_0();
bevl_ts = this.bem_abs_0();
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 198 */ {
bevt_1_tmpany_phold = bevo_29;
if (bevl_ts.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_tmpany_phold = bevo_30;
if (bevl_val.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 201 */ {
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_tmpany_phold.bevi_int;
} /* Line: 202 */
 else  /* Line: 203 */ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 204 */
bevt_6_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_7_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int <= bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_9_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_10_tmpany_phold = bevo_31;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_8_tmpany_phold);
} /* Line: 208 */
bevt_11_tmpany_phold = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_tmpany_phold, bevl_val);
bevt_13_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_14_tmpany_phold = bevo_32;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 215 */
 else  /* Line: 198 */ {
break;
} /* Line: 198 */
} /* Line: 198 */
while (true)
 /* Line: 218 */ {
bevt_19_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_19_tmpany_phold.bevi_int < beva_zeroPad.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_21_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_22_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_21_tmpany_phold.bevi_int <= bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_24_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_25_tmpany_phold = bevo_33;
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_23_tmpany_phold);
} /* Line: 220 */
bevt_26_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_28_tmpany_phold = bevo_34;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
beva_res.bem_setIntUnchecked_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_31_tmpany_phold = bevo_35;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_29_tmpany_phold);
} /* Line: 224 */
 else  /* Line: 218 */ {
break;
} /* Line: 218 */
} /* Line: 218 */
bevt_36_tmpany_phold = bevo_36;
if (this.bevi_int < bevt_36_tmpany_phold.bevi_int) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
beva_res.bem_addValue_1(bevt_37_tmpany_phold);
} /* Line: 229 */
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) beva_res.bem_reverseBytes_0();
return bevt_38_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = this.bevi_int;
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) this.bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_absValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_37;
if (this.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 245 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
this.bem_multiplyValue_1(bevt_2_tmpany_phold);
} /* Line: 246 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 266 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /* Line: 273 */
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 281 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /* Line: 288 */
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 324 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /* Line: 331 */
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 353 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /* Line: 360 */
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 382 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /* Line: 389 */
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 411 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /* Line: 423 */
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 450 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /* Line: 457 */
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 598 */ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 598 */ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 598 */
 else  /* Line: 598 */ {
break;
} /* Line: 598 */
} /* Line: 598 */
return bevl_result;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int == bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int != bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {63, 63, 66, 70, 74, 74, 74, 74, 74, 74, 74, 74, 74, 78, 78, 78, 78, 78, 78, 78, 78, 78, 82, 82, 82, 0, 82, 82, 82, 0, 0, 83, 83, 83, 83, 85, 85, 85, 86, 88, 90, 90, 91, 91, 91, 91, 92, 92, 92, 92, 93, 97, 97, 98, 98, 99, 100, 101, 102, 102, 102, 104, 106, 106, 106, 106, 106, 0, 0, 0, 107, 107, 108, 109, 110, 110, 110, 110, 110, 0, 0, 0, 111, 111, 112, 113, 114, 114, 114, 114, 114, 0, 0, 0, 115, 115, 116, 117, 118, 118, 118, 120, 120, 122, 122, 122, 122, 122, 122, 122, 124, 125, 130, 130, 134, 138, 138, 142, 153, 171, 175, 175, 175, 175, 175, 175, 175, 175, 179, 179, 179, 179, 183, 183, 183, 183, 183, 183, 187, 187, 187, 187, 187, 191, 191, 191, 191, 195, 196, 197, 198, 198, 198, 199, 200, 201, 201, 201, 202, 202, 204, 207, 207, 207, 207, 208, 208, 208, 208, 210, 210, 211, 211, 211, 211, 215, 218, 218, 218, 219, 219, 219, 219, 220, 220, 220, 220, 222, 222, 222, 222, 223, 223, 223, 223, 228, 228, 228, 229, 229, 231, 231, 235, 236, 237, 241, 241, 241, 245, 245, 245, 246, 246, 262, 267, 273, 282, 288, 306, 320, 325, 331, 349, 354, 360, 378, 383, 389, 407, 412, 423, 446, 451, 457, 475, 479, 490, 504, 508, 519, 533, 537, 548, 562, 566, 577, 591, 596, 598, 598, 598, 599, 598, 601, 633, 633, 662, 662, 683, 683, 704, 704, 725, 725, 746, 746};
public static new int[] bevs_smnlec
 = new int[] {70, 71, 74, 78, 90, 91, 92, 93, 94, 95, 96, 97, 98, 110, 111, 112, 113, 114, 115, 116, 117, 118, 142, 143, 148, 149, 152, 153, 158, 159, 162, 166, 167, 168, 169, 171, 172, 177, 178, 181, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 228, 229, 230, 231, 232, 233, 234, 237, 238, 243, 244, 245, 246, 251, 252, 257, 258, 261, 265, 268, 269, 270, 271, 274, 275, 280, 281, 286, 287, 290, 294, 297, 298, 299, 300, 303, 304, 309, 310, 315, 316, 319, 323, 326, 327, 328, 329, 332, 333, 338, 339, 340, 343, 344, 345, 346, 347, 348, 349, 354, 355, 365, 366, 369, 374, 375, 378, 382, 385, 395, 396, 397, 398, 399, 400, 401, 402, 408, 409, 410, 411, 419, 420, 421, 422, 423, 424, 431, 432, 433, 434, 435, 441, 442, 443, 444, 488, 489, 490, 493, 494, 499, 500, 501, 502, 503, 508, 509, 510, 513, 515, 516, 517, 522, 523, 524, 525, 526, 528, 529, 530, 531, 532, 533, 534, 542, 543, 548, 549, 550, 551, 556, 557, 558, 559, 560, 562, 563, 564, 565, 566, 567, 568, 569, 575, 576, 581, 582, 583, 585, 586, 590, 591, 592, 597, 598, 599, 605, 606, 611, 612, 613, 620, 626, 629, 636, 639, 645, 650, 656, 659, 665, 671, 674, 680, 686, 689, 695, 701, 704, 710, 716, 719, 725, 729, 732, 737, 741, 744, 749, 753, 756, 761, 765, 768, 773, 779, 780, 783, 788, 789, 790, 796, 806, 807, 817, 818, 827, 828, 837, 838, 847, 848, 857, 858};
/* BEGIN LINEINFO 
assign 1 63 70
new 0 63 70
return 1 63 71
setStringValueDec 1 66 74
setStringValueHex 1 70 78
assign 1 74 90
new 0 74 90
assign 1 74 91
once 0 74 91
assign 1 74 92
new 0 74 92
assign 1 74 93
once 0 74 93
assign 1 74 94
new 0 74 94
assign 1 74 95
once 0 74 95
assign 1 74 96
new 0 74 96
assign 1 74 97
once 0 74 97
setStringValue 5 74 98
assign 1 78 110
new 0 78 110
assign 1 78 111
once 0 78 111
assign 1 78 112
new 0 78 112
assign 1 78 113
once 0 78 113
assign 1 78 114
new 0 78 114
assign 1 78 115
once 0 78 115
assign 1 78 116
new 0 78 116
assign 1 78 117
once 0 78 117
setStringValue 5 78 118
assign 1 82 142
new 0 82 142
assign 1 82 143
lesser 1 82 148
assign 1 0 149
assign 1 82 152
new 0 82 152
assign 1 82 153
greater 1 82 158
assign 1 0 159
assign 1 0 162
assign 1 83 166
new 0 83 166
assign 1 83 167
add 1 83 167
assign 1 83 168
new 1 83 168
throw 1 83 169
assign 1 85 171
new 0 85 171
assign 1 85 172
lesser 1 85 177
assign 1 86 178
copy 0 86 178
assign 1 88 181
new 0 88 181
assign 1 90 183
new 0 90 183
addValue 1 90 184
assign 1 91 185
new 0 91 185
assign 1 91 186
new 0 91 186
assign 1 91 187
subtract 1 91 187
assign 1 91 188
add 1 91 188
assign 1 92 189
new 0 92 189
assign 1 92 190
new 0 92 190
assign 1 92 191
subtract 1 92 191
assign 1 92 192
add 1 92 192
setStringValue 5 93 193
assign 1 97 228
new 0 97 228
setValue 1 97 229
assign 1 98 230
sizeGet 0 98 230
assign 1 98 231
copy 0 98 231
decrementValue 0 99 232
assign 1 100 233
new 0 100 233
assign 1 101 234
new 0 101 234
assign 1 102 237
new 0 102 237
assign 1 102 238
greaterEquals 1 102 243
getInt 2 104 244
assign 1 106 245
new 0 106 245
assign 1 106 246
greater 1 106 251
assign 1 106 252
lesser 1 106 257
assign 1 0 258
assign 1 0 261
assign 1 0 265
assign 1 107 268
new 0 107 268
subtractValue 1 107 269
multiplyValue 1 108 270
addValue 1 109 271
assign 1 110 274
new 0 110 274
assign 1 110 275
greater 1 110 280
assign 1 110 281
lesser 1 110 286
assign 1 0 287
assign 1 0 290
assign 1 0 294
assign 1 111 297
new 0 111 297
subtractValue 1 111 298
multiplyValue 1 112 299
addValue 1 113 300
assign 1 114 303
new 0 114 303
assign 1 114 304
greater 1 114 309
assign 1 114 310
lesser 1 114 315
assign 1 0 316
assign 1 0 319
assign 1 0 323
assign 1 115 326
new 0 115 326
subtractValue 1 115 327
multiplyValue 1 116 328
addValue 1 117 329
assign 1 118 332
new 0 118 332
assign 1 118 333
equals 1 118 338
assign 1 120 339
new 0 120 339
multiplyValue 1 120 340
assign 1 122 343
new 0 122 343
assign 1 122 344
add 1 122 344
assign 1 122 345
new 0 122 345
assign 1 122 346
add 1 122 346
assign 1 122 347
add 1 122 347
assign 1 122 348
new 1 122 348
throw 1 122 349
decrementValue 0 124 354
multiplyValue 1 125 355
assign 1 130 365
toString 0 130 365
return 1 130 366
new 1 134 369
assign 1 138 374
new 0 138 374
return 1 138 375
return 1 142 378
assign 1 153 382
new 0 153 382
return 1 171 385
assign 1 175 395
new 0 175 395
assign 1 175 396
new 1 175 396
assign 1 175 397
new 0 175 397
assign 1 175 398
once 0 175 398
assign 1 175 399
new 0 175 399
assign 1 175 400
once 0 175 400
assign 1 175 401
toString 4 175 401
return 1 175 402
assign 1 179 408
new 0 179 408
assign 1 179 409
new 1 179 409
assign 1 179 410
toHexString 1 179 410
return 1 179 411
assign 1 183 419
new 0 183 419
assign 1 183 420
once 0 183 420
assign 1 183 421
new 0 183 421
assign 1 183 422
once 0 183 422
assign 1 183 423
toString 3 183 423
return 1 183 424
assign 1 187 431
new 1 187 431
assign 1 187 432
new 0 187 432
assign 1 187 433
once 0 187 433
assign 1 187 434
toString 4 187 434
return 1 187 435
assign 1 191 441
new 0 191 441
assign 1 191 442
once 0 191 442
assign 1 191 443
toString 4 191 443
return 1 191 444
clear 0 195 488
assign 1 196 489
abs 0 196 489
assign 1 197 490
new 0 197 490
assign 1 198 493
new 0 198 493
assign 1 198 494
greater 1 198 499
setValue 1 199 500
modulusValue 1 200 501
assign 1 201 502
new 0 201 502
assign 1 201 503
lesser 1 201 508
assign 1 202 509
new 0 202 509
addValue 1 202 510
addValue 1 204 513
assign 1 207 515
capacityGet 0 207 515
assign 1 207 516
sizeGet 0 207 516
assign 1 207 517
lesserEquals 1 207 522
assign 1 208 523
capacityGet 0 208 523
assign 1 208 524
new 0 208 524
assign 1 208 525
add 1 208 525
capacitySet 1 208 526
assign 1 210 528
sizeGet 0 210 528
setIntUnchecked 2 210 529
assign 1 211 530
sizeGet 0 211 530
assign 1 211 531
new 0 211 531
assign 1 211 532
add 1 211 532
sizeSet 1 211 533
divideValue 1 215 534
assign 1 218 542
sizeGet 0 218 542
assign 1 218 543
lesser 1 218 548
assign 1 219 549
capacityGet 0 219 549
assign 1 219 550
sizeGet 0 219 550
assign 1 219 551
lesserEquals 1 219 556
assign 1 220 557
capacityGet 0 220 557
assign 1 220 558
new 0 220 558
assign 1 220 559
add 1 220 559
capacitySet 1 220 560
assign 1 222 562
sizeGet 0 222 562
assign 1 222 563
new 0 222 563
assign 1 222 564
once 0 222 564
setIntUnchecked 2 222 565
assign 1 223 566
sizeGet 0 223 566
assign 1 223 567
new 0 223 567
assign 1 223 568
add 1 223 568
sizeSet 1 223 569
assign 1 228 575
new 0 228 575
assign 1 228 576
lesser 1 228 581
assign 1 229 582
new 0 229 582
addValue 1 229 583
assign 1 231 585
reverseBytes 0 231 585
return 1 231 586
assign 1 235 590
new 0 235 590
setValue 1 236 591
return 1 237 592
assign 1 241 597
copy 0 241 597
assign 1 241 598
absValue 0 241 598
return 1 241 599
assign 1 245 605
new 0 245 605
assign 1 245 606
lesser 1 245 611
assign 1 246 612
new 0 246 612
multiplyValue 1 246 613
return 1 262 620
assign 1 267 626
new 0 267 626
return 1 273 629
assign 1 282 636
new 0 282 636
return 1 288 639
return 1 306 645
return 1 320 650
assign 1 325 656
new 0 325 656
return 1 331 659
return 1 349 665
assign 1 354 671
new 0 354 671
return 1 360 674
return 1 378 680
assign 1 383 686
new 0 383 686
return 1 389 689
return 1 407 695
assign 1 412 701
new 0 412 701
return 1 423 704
return 1 446 710
assign 1 451 716
new 0 451 716
return 1 457 719
return 1 475 725
assign 1 479 729
new 0 479 729
return 1 490 732
return 1 504 737
assign 1 508 741
new 0 508 741
return 1 519 744
return 1 533 749
assign 1 537 753
new 0 537 753
return 1 548 756
return 1 562 761
assign 1 566 765
new 0 566 765
return 1 577 768
return 1 591 773
assign 1 596 779
new 0 596 779
assign 1 598 780
new 0 598 780
assign 1 598 783
lesser 1 598 788
multiplyValue 1 599 789
incrementValue 0 598 790
return 1 601 796
assign 1 633 806
new 0 633 806
return 1 633 807
assign 1 662 817
new 0 662 817
return 1 662 818
assign 1 683 827
new 0 683 827
return 1 683 828
assign 1 704 837
new 0 704 837
return 1 704 838
assign 1 725 847
new 0 725 847
return 1 725 848
assign 1 746 857
new 0 746 857
return 1 746 858
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1085372256: return bem_increment_0();
case -314718434: return bem_print_0();
case 92614563: return bem_abs_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1205852557: return bem_incrementValue_0();
case 2011061582: return bem_vintGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 2022143834: return bem_vintSet_0();
case -1046151292: return bem_decrement_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 663753935: return bem_decrementValue_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1717721534: return bem_toHexString_0();
case 1820417453: return bem_create_0();
case 1832132624: return bem_absValue_0();
case 1865310226: return bem_toFloat_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -736217829: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case 92659731: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case -1551584407: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case 3419349: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case 81310150: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case -50808448: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case 2139839746: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1567199433: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case -202757140: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1580104161: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 696708346: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case 364269035: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case -1717721533: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case -440702026: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case -477101321: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 1265088726: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2116933162: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case 432448303: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1220624855: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1089696223: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1852231828: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -979186229: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 92957641: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case -436987761: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -387946633: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case 1245164300: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1774940959: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1670339153: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 1774940960: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 1774940961: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callHash) {
case 1670339156: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_3_MathInt();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_3_MathInt.bevs_inst = (BEC_2_4_3_MathInt)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_3_MathInt.bevs_inst;
}
}
}
