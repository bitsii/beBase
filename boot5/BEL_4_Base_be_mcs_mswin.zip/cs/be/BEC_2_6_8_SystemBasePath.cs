namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemBasePath : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
static BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_2_6_8_SystemBasePath bevs_inst;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fromString_1(BEC_2_4_6_TextString beva_spath) {
bevp_path = beva_spath;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_npath = bevt_0_tmpvar_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_firstStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lastStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpvar_phold = null;
BEC_2_6_8_SystemBasePath bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_other.bemd_0(-400189342, BEL_4_Base.bevn_pathGet_0);
bevt_3_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_emptyGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 381 */ {
bevt_4_tmpvar_phold = (BEC_2_6_8_SystemBasePath) this.bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_tmpvar_phold;
} /* Line: 382 */
bevt_5_tmpvar_phold = beva_other.bemd_0(1359432006, BEL_4_Base.bevn_isAbsoluteGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 384 */ {
bevt_6_tmpvar_phold = beva_other.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
return (BEC_2_6_8_SystemBasePath) bevt_6_tmpvar_phold;
} /* Line: 385 */
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpvar_phold = beva_other.bemd_0(-400189342, BEL_4_Base.bevn_pathGet_0);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_tmpvar_phold.bemd_1(-2001811380, BEL_4_Base.bevn_split_1, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 389 */ {
bevt_8_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 389 */ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 391 */
 else  /* Line: 389 */ {
break;
} /* Line: 389 */
} /* Line: 389 */
bevt_9_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_rstr = bevt_9_tmpvar_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_2_6_8_SystemBasePath) this.bem_copy_0();
bevl_rpath = (BEC_2_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_parentGet_0() {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_2_6_8_SystemBasePath) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpvar_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 407 */ {
bevt_1_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 407 */ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 408 */ {
bevt_3_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_tmpvar_phold);
} /* Line: 409 */
 else  /* Line: 410 */ {
bevl_i.bem_nextGet_0();
} /* Line: 411 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 413 */
 else  /* Line: 407 */ {
break;
} /* Line: 407 */
} /* Line: 407 */
bevt_4_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 415 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 416 */
return bevl_rpath;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (bevp_path == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 422 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 422 */ {
bevt_4_tmpvar_phold = bevp_path.bem_toString_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_sizeGet_0();
bevt_5_tmpvar_phold = bevo_0;
if (bevt_3_tmpvar_phold.bevi_int < bevt_5_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 422 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 422 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 422 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 422 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 422 */
bevt_9_tmpvar_phold = bevo_1;
bevt_8_tmpvar_phold = bevp_path.bem_getPoint_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_10_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 424 */
bevt_11_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 430 */ {
bevt_1_tmpvar_phold = bevo_2;
bevt_2_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
} /* Line: 431 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 436 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 437 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
if (beva_howMany.bevi_int > bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 442 */ {
this.bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 447 */ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 447 */ {
if (bevl_next == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 448 */ {
break;
} /* Line: 448 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 447 */
 else  /* Line: 447 */ {
break;
} /* Line: 447 */
} /* Line: 447 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 453 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 465 */ {
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_path = bevt_1_tmpvar_phold.bem_emptyGet_0();
} /* Line: 466 */
 else  /* Line: 467 */ {
bevt_3_tmpvar_phold = bevo_4;
bevt_2_tmpvar_phold = bevl_fp.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpvar_phold, bevt_4_tmpvar_phold);
} /* Line: 468 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 474 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 474 */ {
bevt_1_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_tmpvar_phold);
} /* Line: 475 */
 else  /* Line: 474 */ {
break;
} /* Line: 474 */
} /* Line: 474 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_6_8_SystemBasePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_6_8_SystemBasePath) this.bem_addStep_1(beva_step);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_other = (BEC_2_6_8_SystemBasePath) this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpvar_phold);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_x);
if (bevt_1_tmpvar_phold.bevi_bool) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_x == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 514 */ {
bevt_3_tmpvar_phold = beva_x.bemd_1(-1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 514 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 514 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 514 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 514 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 514 */ {
bevt_5_tmpvar_phold = beva_x.bemd_0(-400189342, BEL_4_Base.bevn_pathGet_0);
bevt_4_tmpvar_phold = bevp_path.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 514 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 514 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 514 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 515 */
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_subPath_2(beva_start, null);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpvar_phold = null;
bevl_st = this.bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 526 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 527 */
 else  /* Line: 528 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 529 */
bevl_res = this.bem_create_0();
bevl_res.bemd_1(410741679, BEL_4_Base.bevn_separatorSet_1, bevp_separator);
bevt_2_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(-389107089, BEL_4_Base.bevn_pathSet_1, bevt_1_tmpvar_phold);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_pathGet_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {342, 342, 346, 347, 351, 355, 359, 359, 363, 364, 364, 365, 369, 369, 373, 373, 373, 377, 377, 377, 381, 381, 381, 381, 382, 382, 384, 385, 385, 387, 388, 388, 389, 389, 390, 391, 393, 393, 394, 395, 397, 401, 402, 403, 403, 404, 405, 406, 407, 407, 408, 408, 409, 409, 411, 413, 415, 416, 418, 422, 422, 0, 422, 422, 422, 422, 422, 0, 0, 422, 422, 423, 423, 423, 424, 424, 426, 426, 430, 431, 431, 431, 436, 436, 436, 437, 442, 442, 442, 443, 444, 446, 447, 447, 447, 448, 448, 449, 450, 451, 447, 453, 458, 459, 460, 464, 465, 465, 466, 466, 468, 468, 468, 468, 473, 474, 474, 475, 475, 477, 481, 481, 485, 486, 487, 488, 492, 493, 494, 494, 495, 499, 499, 503, 503, 507, 507, 507, 514, 514, 0, 514, 0, 0, 0, 514, 514, 0, 0, 515, 515, 517, 517, 521, 521, 525, 526, 526, 527, 529, 531, 532, 533, 533, 533, 534, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 29, 30, 34, 38, 42, 43, 49, 50, 51, 52, 56, 57, 62, 63, 64, 69, 70, 71, 90, 91, 92, 93, 95, 96, 98, 100, 101, 103, 104, 105, 106, 109, 111, 112, 118, 119, 120, 121, 122, 135, 136, 137, 138, 139, 140, 141, 142, 145, 147, 152, 153, 154, 157, 159, 165, 167, 169, 184, 189, 190, 193, 194, 195, 196, 201, 202, 205, 209, 210, 212, 213, 214, 216, 217, 219, 220, 226, 228, 229, 230, 237, 238, 243, 244, 257, 258, 263, 264, 265, 266, 267, 270, 275, 276, 281, 284, 285, 286, 287, 293, 299, 300, 301, 311, 312, 317, 318, 319, 322, 323, 324, 325, 334, 335, 338, 340, 341, 347, 352, 353, 357, 358, 359, 360, 366, 367, 368, 369, 370, 374, 375, 379, 380, 385, 386, 391, 402, 407, 408, 411, 413, 416, 420, 423, 424, 426, 429, 433, 434, 436, 437, 441, 442, 451, 452, 457, 458, 461, 463, 464, 465, 466, 467, 468, 471, 474, 478, 481};
/* BEGIN LINEINFO 
assign 1 342 24
new 0 342 24
new 1 342 25
assign 1 346 29
new 0 346 29
fromString 1 347 30
assign 1 351 34
return 1 355 38
assign 1 359 42
toStringWithSeparator 1 359 42
return 1 359 43
assign 1 363 49
split 1 363 49
assign 1 364 50
new 0 364 50
assign 1 364 51
join 2 364 51
return 1 365 52
assign 1 369 56
split 1 369 56
return 1 369 57
assign 1 373 62
split 1 373 62
assign 1 373 63
firstGet 0 373 63
return 1 373 64
assign 1 377 69
split 1 377 69
assign 1 377 70
lastGet 0 377 70
return 1 377 71
assign 1 381 90
pathGet 0 381 90
assign 1 381 91
new 0 381 91
assign 1 381 92
emptyGet 0 381 92
assign 1 381 93
equals 1 381 93
assign 1 382 95
copy 0 382 95
return 1 382 96
assign 1 384 98
isAbsoluteGet 0 384 98
assign 1 385 100
copy 0 385 100
return 1 385 101
assign 1 387 103
split 1 387 103
assign 1 388 104
pathGet 0 388 104
assign 1 388 105
split 1 388 105
assign 1 389 106
linkedListIteratorGet 0 389 106
assign 1 389 109
hasNextGet 0 389 109
assign 1 390 111
nextGet 0 390 111
addValue 1 391 112
assign 1 393 118
new 0 393 118
assign 1 393 119
join 2 393 119
assign 1 394 120
copy 0 394 120
assign 1 395 121
fromString 1 395 121
return 1 397 122
assign 1 401 135
split 1 401 135
assign 1 402 136
copy 0 402 136
assign 1 403 137
new 0 403 137
pathSet 1 403 138
assign 1 404 139
lengthGet 0 404 139
assign 1 405 140
decrement 0 405 140
assign 1 406 141
new 0 406 141
assign 1 407 142
linkedListIteratorGet 0 407 142
assign 1 407 145
hasNextGet 0 407 145
assign 1 408 147
lesser 1 408 152
assign 1 409 153
nextGet 0 409 153
addStep 1 409 154
nextGet 0 411 157
assign 1 413 159
increment 0 413 159
assign 1 415 165
isAbsoluteGet 0 415 165
makeAbsolute 0 416 167
return 1 418 169
assign 1 422 184
undef 1 422 189
assign 1 0 190
assign 1 422 193
toString 0 422 193
assign 1 422 194
sizeGet 0 422 194
assign 1 422 195
new 0 422 195
assign 1 422 196
lesser 1 422 201
assign 1 0 202
assign 1 0 205
assign 1 422 209
new 0 422 209
return 1 422 210
assign 1 423 212
new 0 423 212
assign 1 423 213
getPoint 1 423 213
assign 1 423 214
equals 1 423 214
assign 1 424 216
new 0 424 216
return 1 424 217
assign 1 426 219
new 0 426 219
return 1 426 220
assign 1 430 226
isAbsoluteGet 0 430 226
assign 1 431 228
new 0 431 228
assign 1 431 229
sizeGet 0 431 229
assign 1 431 230
substring 2 431 230
assign 1 436 237
isAbsoluteGet 0 436 237
assign 1 436 238
not 0 436 243
assign 1 437 244
add 1 437 244
assign 1 442 257
new 0 442 257
assign 1 442 258
greater 1 442 263
makeNonAbsolute 0 443 264
assign 1 444 265
split 1 444 265
assign 1 446 266
firstNodeGet 0 446 266
assign 1 447 267
new 0 447 267
assign 1 447 270
lesser 1 447 275
assign 1 448 276
undef 1 448 281
assign 1 449 284
assign 1 450 285
nextGet 0 450 285
delete 0 451 286
assign 1 447 287
increment 0 447 287
assign 1 453 293
join 2 453 293
assign 1 458 299
split 1 458 299
addValue 1 459 300
assign 1 460 301
join 2 460 301
assign 1 464 311
find 1 464 311
assign 1 465 312
undef 1 465 317
assign 1 466 318
new 0 466 318
assign 1 466 319
emptyGet 0 466 319
assign 1 468 322
new 0 468 322
assign 1 468 323
add 1 468 323
assign 1 468 324
sizeGet 0 468 324
assign 1 468 325
substring 2 468 325
assign 1 473 334
split 1 473 334
assign 1 474 335
linkedListIteratorGet 0 474 335
assign 1 474 338
hasNextGet 0 474 338
assign 1 475 340
nextGet 0 475 340
addValue 1 475 341
assign 1 477 347
join 2 477 347
assign 1 481 352
addStep 1 481 352
return 1 481 353
assign 1 485 357
split 1 485 357
addValue 1 486 358
addValue 1 487 359
assign 1 488 360
join 2 488 360
assign 1 492 366
create 0 492 366
copyTo 1 493 367
assign 1 494 368
copy 0 494 368
pathSet 1 494 369
return 1 495 370
assign 1 499 374
split 1 499 374
return 1 499 375
assign 1 503 379
hashGet 0 503 379
return 1 503 380
assign 1 507 385
equals 1 507 385
assign 1 507 386
not 0 507 391
return 1 507 391
assign 1 514 402
undef 1 514 407
assign 1 0 408
assign 1 514 411
otherType 1 514 411
assign 1 0 413
assign 1 0 416
assign 1 0 420
assign 1 514 423
pathGet 0 514 423
assign 1 514 424
notEquals 1 514 424
assign 1 0 426
assign 1 0 429
assign 1 515 433
new 0 515 433
return 1 515 434
assign 1 517 436
new 0 517 436
return 1 517 437
assign 1 521 441
subPath 2 521 441
return 1 521 442
assign 1 525 451
stepsGet 0 525 451
assign 1 526 452
undef 1 526 457
assign 1 527 458
subList 1 527 458
assign 1 529 461
subList 2 529 461
assign 1 531 463
create 0 531 463
separatorSet 1 532 464
assign 1 533 465
new 0 533 465
assign 1 533 466
join 2 533 466
pathSet 1 533 467
return 1 534 468
return 1 0 471
assign 1 0 474
return 1 0 478
assign 1 0 481
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1081412016: return bem_many_0();
case 1359432006: return bem_isAbsoluteGet_0();
case -1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -471950299: return bem_lastStepGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -935459934: return bem_deleteFirstStep_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -729571811: return bem_serializeToString_0();
case -1719674549: return bem_firstStepGet_0();
case -723109216: return bem_stepsGet_0();
case -1354714650: return bem_copy_0();
case -400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case -1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -630006451: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -488966921: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -389107089: return bem_pathSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1787791811: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 14682424: return bem_addSteps_1(bevd_0);
case -2006569863: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -488966920: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemBasePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemBasePath.bevs_inst = (BEC_2_6_8_SystemBasePath)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemBasePath.bevs_inst;
}
}
}
