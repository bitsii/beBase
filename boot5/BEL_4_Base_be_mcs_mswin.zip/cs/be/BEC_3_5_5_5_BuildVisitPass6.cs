namespace be {
/* IO:File: source/build/Pass6.be */
public sealed class BEC_3_5_5_5_BuildVisitPass6 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass6() { }
static BEC_3_5_5_5_BuildVisitPass6() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] BEC_3_5_5_5_BuildVisitPass6_bels_0 = {0x2C};
private static byte[] BEC_3_5_5_5_BuildVisitPass6_bels_1 = {0x2C};
private static byte[] BEC_3_5_5_5_BuildVisitPass6_bels_2 = {0x73,0x65,0x6C,0x66};
private static byte[] BEC_3_5_5_5_BuildVisitPass6_bels_3 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] BEC_3_5_5_5_BuildVisitPass6_bels_4 = {0x5F};
private static byte[] BEC_3_5_5_5_BuildVisitPass6_bels_5 = {0x74,0x68,0x69,0x73};
private static byte[] BEC_3_5_5_5_BuildVisitPass6_bels_6 = {0x73,0x65,0x6C,0x66};
private static byte[] BEC_3_5_5_5_BuildVisitPass6_bels_7 = {0x73,0x65,0x6C,0x66};
private static byte[] BEC_3_5_5_5_BuildVisitPass6_bels_8 = {0x73,0x65,0x6C,0x66};
public static new BEC_3_5_5_5_BuildVisitPass6 bevs_inst;
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_9_3_ContainerSet bevl_langs = null;
BEC_2_5_4_BuildNode bevl_lang = null;
BEC_2_6_6_SystemObject bevl_doit = null;
BEC_2_6_6_SystemObject bevl_si = null;
BEC_2_6_6_SystemObject bevl_snode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_nxnode = null;
BEC_2_6_6_SystemObject bevl_parens = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_numargs = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vid = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_38_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_5_4_BuildEmit bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_6_BuildIfEmit bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_4_6_TextString bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpany_phold = null;
BEC_2_4_6_TextString bevt_153_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_155_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_5_3_BuildVar bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_164_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_166_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_168_tmpany_phold = null;
BEC_2_4_6_TextString bevt_169_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_175_tmpany_phold = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 22 */ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_12_tmpany_phold = beva_node.bem_containedGet_0();
if (bevt_12_tmpany_phold == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_15_tmpany_phold = beva_node.bem_containedGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_lengthGet_0();
bevt_16_tmpany_phold = bevo_0;
if (bevt_14_tmpany_phold.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevt_20_tmpany_phold = beva_node.bem_containedGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_18_tmpany_phold == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevt_25_tmpany_phold = beva_node.bem_containedGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_firstGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_26_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_26_tmpany_phold);
if (bevt_21_tmpany_phold != null && bevt_21_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_21_tmpany_phold).bevi_bool) /* Line: 24 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevt_30_tmpany_phold = beva_node.bem_secondGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_containedGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_lengthGet_0();
bevt_31_tmpany_phold = bevo_1;
if (bevt_28_tmpany_phold.bevi_int > bevt_31_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_34_tmpany_phold = beva_node.bem_containedGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_0_tmpany_loop = bevt_32_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 27 */ {
bevt_35_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_35_tmpany_phold != null && bevt_35_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpany_phold).bevi_bool) /* Line: 27 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_36_tmpany_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_36_tmpany_phold);
} /* Line: 29 */
 else  /* Line: 27 */ {
break;
} /* Line: 27 */
} /* Line: 27 */
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_37_tmpany_phold);
bevl_doit = be.BECS_Runtime.boolTrue;
if (bevl_doit != null && bevl_doit is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_doit).bevi_bool) /* Line: 33 */ {
bevl_doit = be.BECS_Runtime.boolFalse;
bevt_39_tmpany_phold = beva_node.bem_secondGet_0();
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_containedGet_0();
bevl_i = bevt_38_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 35 */ {
bevt_40_tmpany_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpany_phold != null && bevt_40_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpany_phold).bevi_bool) /* Line: 35 */ {
bevl_si = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_42_tmpany_phold = bevl_si.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_43_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_43_tmpany_phold);
if (bevt_41_tmpany_phold != null && bevt_41_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_41_tmpany_phold).bevi_bool) /* Line: 37 */ {
bevt_44_tmpany_phold = bevl_si.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_44_tmpany_phold);
bevl_doit = be.BECS_Runtime.boolTrue;
} /* Line: 41 */
} /* Line: 37 */
 else  /* Line: 35 */ {
break;
} /* Line: 35 */
} /* Line: 35 */
} /* Line: 35 */
bevt_45_tmpany_phold = bevl_doit.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpany_phold != null && bevt_45_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpany_phold).bevi_bool) /* Line: 45 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 47 */
beva_node.bem_containedSet_1(null);
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = (BEC_2_5_4_BuildEmit) (new BEC_2_5_4_BuildEmit()).bem_new_2((BEC_2_4_6_TextString) bevt_47_tmpany_phold, bevl_langs);
beva_node.bem_heldSet_1(bevt_46_tmpany_phold);
} /* Line: 50 */
 else  /* Line: 51 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 53 */
bevl_snode = beva_node.bem_scopeGet_0();
bevt_49_tmpany_phold = bevl_snode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_50_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_50_tmpany_phold);
if (bevt_48_tmpany_phold != null && bevt_48_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_48_tmpany_phold).bevi_bool) /* Line: 57 */ {
bevl_snode = null;
} /* Line: 58 */
if (bevl_snode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 61 */ {
beva_node.bem_delete_0();
bevt_52_tmpany_phold = bevl_snode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_52_tmpany_phold.bemd_1(-406676794, BEL_4_Base.bevn_addEmit_1, beva_node);
} /* Line: 63 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 66 */
 else  /* Line: 22 */ {
bevt_54_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_54_tmpany_phold.bevi_int == bevt_55_tmpany_phold.bevi_int) {
bevt_53_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_53_tmpany_phold.bevi_bool) /* Line: 67 */ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_58_tmpany_phold = beva_node.bem_containedGet_0();
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_firstGet_0();
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_1_tmpany_loop = bevt_56_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 70 */ {
bevt_59_tmpany_phold = bevt_1_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_59_tmpany_phold != null && bevt_59_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpany_phold).bevi_bool) /* Line: 70 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_1_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_60_tmpany_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_60_tmpany_phold);
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lang);
} /* Line: 73 */
 else  /* Line: 70 */ {
break;
} /* Line: 70 */
} /* Line: 70 */
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevl_langs.bem_delete_1(bevt_61_tmpany_phold);
bevt_63_tmpany_phold = beva_node.bem_heldGet_0();
bevt_62_tmpany_phold = (BEC_2_5_6_BuildIfEmit) (new BEC_2_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_2_4_6_TextString) bevt_63_tmpany_phold);
beva_node.bem_heldSet_1(bevt_62_tmpany_phold);
bevl_ii = bevl_toremove.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 77 */ {
bevt_64_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_64_tmpany_phold != null && bevt_64_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_64_tmpany_phold).bevi_bool) /* Line: 77 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 79 */
 else  /* Line: 77 */ {
break;
} /* Line: 77 */
} /* Line: 77 */
} /* Line: 77 */
 else  /* Line: 22 */ {
bevt_66_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_67_tmpany_phold = bevp_ntypes.bem_IFGet_0();
if (bevt_66_tmpany_phold.bevi_int == bevt_67_tmpany_phold.bevi_int) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 81 */ {
if (bevl_nnode == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevl_lnode = beva_node;
while (true)
 /* Line: 84 */ {
if (bevl_nnode == null) {
bevt_69_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_69_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_69_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_72_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_72_tmpany_phold);
if (bevt_70_tmpany_phold != null && bevt_70_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_70_tmpany_phold).bevi_bool) /* Line: 84 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
 else  /* Line: 84 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 84 */ {
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_73_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_73_tmpany_phold);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_74_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_74_tmpany_phold);
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_75_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_75_tmpany_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_inode);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevt_77_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_78_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = bevt_78_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 97 */ {
bevt_79_tmpany_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_79_tmpany_phold != null && bevt_79_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_79_tmpany_phold).bevi_bool) /* Line: 97 */ {
bevt_80_tmpany_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_80_tmpany_phold);
} /* Line: 98 */
 else  /* Line: 97 */ {
break;
} /* Line: 97 */
} /* Line: 97 */
} /* Line: 97 */
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_nnode = bevl_nxnode;
} /* Line: 109 */
 else  /* Line: 84 */ {
break;
} /* Line: 84 */
} /* Line: 84 */
if (bevl_nnode == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_83_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_84_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_84_tmpany_phold);
if (bevt_82_tmpany_phold != null && bevt_82_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_82_tmpany_phold).bevi_bool) /* Line: 111 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 111 */
 else  /* Line: 111 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 111 */ {
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nnode);
} /* Line: 113 */
} /* Line: 111 */
bevt_85_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpany_phold;
} /* Line: 116 */
 else  /* Line: 22 */ {
bevt_87_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_88_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_87_tmpany_phold.bevi_int == bevt_88_tmpany_phold.bevi_int) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevt_89_tmpany_phold = beva_node.bem_containedGet_0();
bevl_parens = bevt_89_tmpany_phold.bem_firstGet_0();
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_90_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_90_tmpany_phold);
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, BEC_3_5_5_5_BuildVisitPass6_bels_2));
bevl_nd.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_91_tmpany_phold);
bevl_parens.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_nd);
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_2_4_3_MathInt(0));
bevt_92_tmpany_phold = bevl_parens.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_92_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 126 */ {
bevt_93_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_93_tmpany_phold != null && bevt_93_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_93_tmpany_phold).bevi_bool) /* Line: 126 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_ix = bevl_i.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_95_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_96_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_96_tmpany_phold);
if (bevt_94_tmpany_phold != null && bevt_94_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_94_tmpany_phold).bevi_bool) /* Line: 131 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 132 */
 else  /* Line: 131 */ {
bevt_98_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_99_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_99_tmpany_phold);
if (bevt_97_tmpany_phold != null && bevt_97_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_97_tmpany_phold).bevi_bool) /* Line: 133 */ {
bevt_100_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_100_tmpany_phold);
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_101_tmpany_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_101_tmpany_phold);
bevt_102_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_102_tmpany_phold);
bevl_i.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_v);
bevt_103_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_103_tmpany_phold);
bevl_i.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
} /* Line: 140 */
 else  /* Line: 131 */ {
bevt_105_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_106_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_106_tmpany_phold);
if (bevt_104_tmpany_phold != null && bevt_104_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_104_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevt_108_tmpany_phold = bevl_ix.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_109_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_109_tmpany_phold);
if (bevt_107_tmpany_phold != null && bevt_107_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_107_tmpany_phold).bevi_bool) /* Line: 142 */ {
bevt_110_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_110_tmpany_phold);
bevt_111_tmpany_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_112_tmpany_phold = bevl_ix.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_111_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_114_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_113_tmpany_phold.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_114_tmpany_phold);
bevl_i.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevt_115_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_115_tmpany_phold);
} /* Line: 147 */
 else  /* Line: 148 */ {
bevt_117_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, BEC_3_5_5_5_BuildVisitPass6_bels_3));
bevt_116_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_117_tmpany_phold, bevl_i);
throw new be.BECS_ThrowBack(bevt_116_tmpany_phold);
} /* Line: 149 */
} /* Line: 142 */
} /* Line: 131 */
} /* Line: 131 */
} /* Line: 131 */
 else  /* Line: 126 */ {
break;
} /* Line: 126 */
} /* Line: 126 */
bevl_ii = bevl_toremove.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 153 */ {
bevt_118_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_118_tmpany_phold != null && bevt_118_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_118_tmpany_phold).bevi_bool) /* Line: 153 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 155 */
 else  /* Line: 153 */ {
break;
} /* Line: 153 */
} /* Line: 153 */
bevl_s = beva_node.bem_heldGet_0();
bevt_120_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_119_tmpany_phold = bevl_numargs.bemd_1(81310150, BEL_4_Base.bevn_subtract_1, bevt_120_tmpany_phold);
bevl_s.bemd_1(-537631759, BEL_4_Base.bevn_numargsSet_1, bevt_119_tmpany_phold);
bevt_121_tmpany_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_s.bemd_1(-1380410043, BEL_4_Base.bevn_orgNameSet_1, bevt_121_tmpany_phold);
bevt_124_tmpany_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, BEC_3_5_5_5_BuildVisitPass6_bels_4));
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_125_tmpany_phold);
bevt_127_tmpany_phold = bevl_s.bemd_0(-548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_126_tmpany_phold = bevt_127_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_126_tmpany_phold);
bevl_s.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_122_tmpany_phold);
bevl_i = beva_node.bem_secondGet_0();
bevt_129_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_130_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_128_tmpany_phold = bevt_129_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_130_tmpany_phold);
if (bevt_128_tmpany_phold != null && bevt_128_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_128_tmpany_phold).bevi_bool) /* Line: 162 */ {
bevl_i.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_131_tmpany_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_s.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, bevt_131_tmpany_phold);
bevt_134_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_133_tmpany_phold = bevt_134_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevt_133_tmpany_phold == null) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevl_s.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, null);
} /* Line: 168 */
 else  /* Line: 166 */ {
bevt_138_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_137_tmpany_phold = bevt_138_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_136_tmpany_phold = bevt_137_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_139_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, BEC_3_5_5_5_BuildVisitPass6_bels_5));
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_139_tmpany_phold);
if (bevt_135_tmpany_phold != null && bevt_135_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_135_tmpany_phold).bevi_bool) /* Line: 169 */ {
bevt_140_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_141_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_140_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_141_tmpany_phold);
bevt_142_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_143_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_142_tmpany_phold.bemd_1(-524129890, BEL_4_Base.bevn_isSelfSet_1, bevt_143_tmpany_phold);
bevt_144_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_145_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_144_tmpany_phold.bemd_1(606514572, BEL_4_Base.bevn_isThisSet_1, bevt_145_tmpany_phold);
bevt_147_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_146_tmpany_phold = bevt_147_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_148_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, BEC_3_5_5_5_BuildVisitPass6_bels_6));
bevt_146_tmpany_phold.bemd_1(-389107089, BEL_4_Base.bevn_pathSet_1, bevt_148_tmpany_phold);
} /* Line: 174 */
 else  /* Line: 166 */ {
bevt_152_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_151_tmpany_phold = bevt_152_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_150_tmpany_phold = bevt_151_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_153_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, BEC_3_5_5_5_BuildVisitPass6_bels_7));
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_153_tmpany_phold);
if (bevt_149_tmpany_phold != null && bevt_149_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_149_tmpany_phold).bevi_bool) /* Line: 175 */ {
bevt_154_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_155_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_154_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_155_tmpany_phold);
bevt_156_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_157_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_156_tmpany_phold.bemd_1(-524129890, BEL_4_Base.bevn_isSelfSet_1, bevt_157_tmpany_phold);
} /* Line: 177 */
} /* Line: 166 */
} /* Line: 166 */
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 179 */
 else  /* Line: 180 */ {
bevt_158_tmpany_phold = (BEC_2_5_3_BuildVar) (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_s.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, bevt_158_tmpany_phold);
bevt_159_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_160_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_159_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_160_tmpany_phold);
bevt_161_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_162_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_161_tmpany_phold.bemd_1(-524129890, BEL_4_Base.bevn_isSelfSet_1, bevt_162_tmpany_phold);
bevt_163_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_164_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_163_tmpany_phold.bemd_1(606514572, BEL_4_Base.bevn_isThisSet_1, bevt_164_tmpany_phold);
bevt_165_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_166_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_165_tmpany_phold.bemd_1(601092044, BEL_4_Base.bevn_impliedSet_1, bevt_166_tmpany_phold);
bevt_167_tmpany_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_169_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, BEC_3_5_5_5_BuildVisitPass6_bels_8));
bevt_168_tmpany_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_169_tmpany_phold);
bevt_167_tmpany_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_168_tmpany_phold);
} /* Line: 186 */
bevl_clnode = beva_node.bem_classGet_0();
bevt_171_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_170_tmpany_phold = bevt_171_tmpany_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_172_tmpany_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_170_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_172_tmpany_phold, beva_node);
bevt_174_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_173_tmpany_phold = bevt_174_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_173_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
} /* Line: 190 */
} /* Line: 22 */
} /* Line: 22 */
} /* Line: 22 */
bevt_175_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_175_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 21, 22, 22, 22, 22, 23, 24, 24, 24, 24, 24, 24, 24, 24, 0, 0, 0, 24, 24, 24, 24, 24, 0, 0, 0, 24, 24, 24, 24, 24, 24, 0, 0, 0, 24, 24, 24, 24, 24, 24, 0, 0, 0, 26, 27, 27, 27, 27, 0, 27, 27, 29, 29, 31, 31, 32, 34, 35, 35, 35, 35, 36, 37, 37, 37, 38, 38, 41, 45, 46, 47, 49, 50, 50, 50, 52, 53, 56, 57, 57, 57, 58, 61, 61, 62, 63, 63, 66, 67, 67, 67, 67, 68, 69, 70, 70, 70, 70, 0, 70, 70, 72, 72, 73, 75, 75, 76, 76, 76, 77, 77, 78, 79, 81, 81, 81, 81, 82, 82, 83, 84, 84, 84, 84, 84, 0, 0, 0, 85, 86, 86, 87, 88, 89, 90, 90, 91, 92, 93, 93, 94, 95, 96, 96, 96, 97, 97, 97, 98, 98, 105, 106, 107, 108, 109, 111, 111, 111, 111, 111, 0, 0, 0, 112, 113, 116, 116, 117, 117, 117, 117, 118, 118, 119, 120, 121, 121, 122, 122, 123, 124, 125, 126, 126, 126, 127, 128, 131, 131, 131, 132, 133, 133, 133, 134, 134, 135, 136, 136, 137, 137, 138, 139, 139, 140, 141, 141, 141, 142, 142, 142, 143, 143, 144, 144, 144, 145, 145, 145, 146, 147, 147, 149, 149, 149, 153, 153, 154, 155, 157, 158, 158, 158, 159, 159, 160, 160, 160, 160, 160, 160, 160, 161, 162, 162, 162, 163, 165, 165, 166, 166, 166, 166, 168, 169, 169, 169, 169, 169, 171, 171, 171, 172, 172, 172, 173, 173, 173, 174, 174, 174, 174, 175, 175, 175, 175, 175, 176, 176, 176, 177, 177, 177, 179, 181, 181, 182, 182, 182, 183, 183, 183, 184, 184, 184, 185, 185, 185, 186, 186, 186, 186, 188, 189, 189, 189, 189, 190, 190, 190, 192, 192};
public static new int[] bevs_smnlec
 = new int[] {221, 222, 223, 224, 225, 230, 231, 232, 233, 238, 239, 240, 241, 242, 247, 248, 251, 255, 258, 259, 260, 261, 266, 267, 270, 274, 277, 278, 279, 280, 281, 282, 284, 287, 291, 294, 295, 296, 297, 298, 303, 304, 307, 311, 314, 315, 316, 317, 318, 318, 321, 323, 324, 325, 331, 332, 333, 335, 336, 337, 338, 341, 343, 344, 345, 346, 348, 349, 350, 358, 360, 361, 363, 364, 365, 366, 369, 370, 372, 373, 374, 375, 377, 379, 384, 385, 386, 387, 389, 392, 393, 394, 399, 400, 401, 402, 403, 404, 405, 405, 408, 410, 411, 412, 413, 419, 420, 421, 422, 423, 424, 427, 429, 430, 438, 439, 440, 445, 446, 451, 452, 455, 460, 461, 462, 463, 465, 468, 472, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 495, 496, 497, 500, 502, 503, 510, 511, 512, 513, 514, 520, 525, 526, 527, 528, 530, 533, 537, 540, 541, 544, 545, 548, 549, 550, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 571, 573, 574, 575, 576, 577, 579, 582, 583, 584, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 599, 600, 601, 603, 604, 605, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 620, 621, 622, 632, 635, 637, 638, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 662, 663, 664, 665, 666, 667, 672, 673, 676, 677, 678, 679, 680, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 697, 698, 699, 700, 701, 703, 704, 705, 706, 707, 708, 712, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 734, 735, 736, 737, 738, 739, 740, 741, 746, 747};
/* BEGIN LINEINFO 
resolveNp 0 18 221
assign 1 21 222
nextPeerGet 0 21 222
assign 1 22 223
typenameGet 0 22 223
assign 1 22 224
EMITGet 0 22 224
assign 1 22 225
equals 1 22 230
assign 1 23 231
nextAscendGet 0 23 231
assign 1 24 232
containedGet 0 24 232
assign 1 24 233
def 1 24 238
assign 1 24 239
containedGet 0 24 239
assign 1 24 240
lengthGet 0 24 240
assign 1 24 241
new 0 24 241
assign 1 24 242
greater 1 24 247
assign 1 0 248
assign 1 0 251
assign 1 0 255
assign 1 24 258
containedGet 0 24 258
assign 1 24 259
firstGet 0 24 259
assign 1 24 260
containedGet 0 24 260
assign 1 24 261
def 1 24 266
assign 1 0 267
assign 1 0 270
assign 1 0 274
assign 1 24 277
containedGet 0 24 277
assign 1 24 278
firstGet 0 24 278
assign 1 24 279
containedGet 0 24 279
assign 1 24 280
lengthGet 0 24 280
assign 1 24 281
new 0 24 281
assign 1 24 282
greater 1 24 282
assign 1 0 284
assign 1 0 287
assign 1 0 291
assign 1 24 294
secondGet 0 24 294
assign 1 24 295
containedGet 0 24 295
assign 1 24 296
lengthGet 0 24 296
assign 1 24 297
new 0 24 297
assign 1 24 298
greater 1 24 303
assign 1 0 304
assign 1 0 307
assign 1 0 311
assign 1 26 314
new 0 26 314
assign 1 27 315
containedGet 0 27 315
assign 1 27 316
firstGet 0 27 316
assign 1 27 317
containedGet 0 27 317
assign 1 27 318
iteratorGet 0 0 318
assign 1 27 321
hasNextGet 0 27 321
assign 1 27 323
nextGet 0 27 323
assign 1 29 324
heldGet 0 29 324
addValue 1 29 325
assign 1 31 331
new 0 31 331
delete 1 31 332
assign 1 32 333
new 0 32 333
assign 1 34 335
new 0 34 335
assign 1 35 336
secondGet 0 35 336
assign 1 35 337
containedGet 0 35 337
assign 1 35 338
iteratorGet 0 35 338
assign 1 35 341
hasNextGet 0 35 341
assign 1 36 343
nextGet 0 36 343
assign 1 37 344
typenameGet 0 37 344
assign 1 37 345
STRINGLGet 0 37 345
assign 1 37 346
equals 1 37 346
assign 1 38 348
heldGet 0 38 348
heldSet 1 38 349
assign 1 41 350
new 0 41 350
assign 1 45 358
not 0 45 358
delete 0 46 360
return 1 47 361
containedSet 1 49 363
assign 1 50 364
heldGet 0 50 364
assign 1 50 365
new 2 50 365
heldSet 1 50 366
delete 0 52 369
return 1 53 370
assign 1 56 372
scopeGet 0 56 372
assign 1 57 373
typenameGet 0 57 373
assign 1 57 374
METHODGet 0 57 374
assign 1 57 375
equals 1 57 375
assign 1 58 377
assign 1 61 379
def 1 61 384
delete 0 62 385
assign 1 63 386
heldGet 0 63 386
addEmit 1 63 387
return 1 66 389
assign 1 67 392
typenameGet 0 67 392
assign 1 67 393
IFEMITGet 0 67 393
assign 1 67 394
equals 1 67 399
assign 1 68 400
new 0 68 400
assign 1 69 401
new 0 69 401
assign 1 70 402
containedGet 0 70 402
assign 1 70 403
firstGet 0 70 403
assign 1 70 404
containedGet 0 70 404
assign 1 70 405
iteratorGet 0 0 405
assign 1 70 408
hasNextGet 0 70 408
assign 1 70 410
nextGet 0 70 410
assign 1 72 411
heldGet 0 72 411
addValue 1 72 412
addValue 1 73 413
assign 1 75 419
new 0 75 419
delete 1 75 420
assign 1 76 421
heldGet 0 76 421
assign 1 76 422
new 2 76 422
heldSet 1 76 423
assign 1 77 424
iteratorGet 0 77 424
assign 1 77 427
hasNextGet 0 77 427
assign 1 78 429
nextGet 0 78 429
delete 0 79 430
assign 1 81 438
typenameGet 0 81 438
assign 1 81 439
IFGet 0 81 439
assign 1 81 440
equals 1 81 445
assign 1 82 446
def 1 82 451
assign 1 83 452
assign 1 84 455
def 1 84 460
assign 1 84 461
typenameGet 0 84 461
assign 1 84 462
ELIFGet 0 84 462
assign 1 84 463
equals 1 84 463
assign 1 0 465
assign 1 0 468
assign 1 0 472
assign 1 85 475
new 1 85 475
assign 1 86 476
ELSEGet 0 86 476
typenameSet 1 86 477
copyLoc 1 87 478
assign 1 88 479
new 1 88 479
copyLoc 1 89 480
assign 1 90 481
BRACESGet 0 90 481
typenameSet 1 90 482
assign 1 91 483
new 1 91 483
copyLoc 1 92 484
assign 1 93 485
IFGet 0 93 485
typenameSet 1 93 486
addValue 1 94 487
addValue 1 95 488
assign 1 96 489
containedGet 0 96 489
assign 1 96 490
def 1 96 495
assign 1 97 496
containedGet 0 97 496
assign 1 97 497
iteratorGet 0 97 497
assign 1 97 500
hasNextGet 0 97 500
assign 1 98 502
nextGet 0 98 502
addValue 1 98 503
addValue 1 105 510
assign 1 106 511
assign 1 107 512
nextPeerGet 0 107 512
delete 0 108 513
assign 1 109 514
assign 1 111 520
def 1 111 525
assign 1 111 526
typenameGet 0 111 526
assign 1 111 527
ELSEGet 0 111 527
assign 1 111 528
equals 1 111 528
assign 1 0 530
assign 1 0 533
assign 1 0 537
delete 0 112 540
addValue 1 113 541
assign 1 116 544
nextDescendGet 0 116 544
return 1 116 545
assign 1 117 548
typenameGet 0 117 548
assign 1 117 549
METHODGet 0 117 549
assign 1 117 550
equals 1 117 555
assign 1 118 556
containedGet 0 118 556
assign 1 118 557
firstGet 0 118 557
assign 1 119 558
new 1 119 558
copyLoc 1 120 559
assign 1 121 560
IDGet 0 121 560
typenameSet 1 121 561
assign 1 122 562
new 0 122 562
heldSet 1 122 563
prepend 1 123 564
assign 1 124 565
new 0 124 565
assign 1 125 566
new 0 125 566
assign 1 126 567
containedGet 0 126 567
assign 1 126 568
iteratorGet 0 126 568
assign 1 126 571
hasNextGet 0 126 571
assign 1 127 573
nextGet 0 127 573
assign 1 128 574
nextPeerGet 0 128 574
assign 1 131 575
typenameGet 0 131 575
assign 1 131 576
COMMAGet 0 131 576
assign 1 131 577
equals 1 131 577
addValue 1 132 579
assign 1 133 582
typenameGet 0 133 582
assign 1 133 583
IDGet 0 133 583
assign 1 133 584
equals 1 133 584
assign 1 134 586
new 0 134 586
assign 1 134 587
add 1 134 587
assign 1 135 588
new 0 135 588
assign 1 136 589
heldGet 0 136 589
nameSet 1 136 590
assign 1 137 591
new 0 137 591
isArgSet 1 137 592
heldSet 1 138 593
assign 1 139 594
VARGet 0 139 594
typenameSet 1 139 595
addVariable 0 140 596
assign 1 141 599
typenameGet 0 141 599
assign 1 141 600
VARGet 0 141 600
assign 1 141 601
equals 1 141 601
assign 1 142 603
typenameGet 0 142 603
assign 1 142 604
IDGet 0 142 604
assign 1 142 605
equals 1 142 605
assign 1 143 607
new 0 143 607
assign 1 143 608
add 1 143 608
assign 1 144 609
heldGet 0 144 609
assign 1 144 610
heldGet 0 144 610
nameSet 1 144 611
assign 1 145 612
heldGet 0 145 612
assign 1 145 613
new 0 145 613
isArgSet 1 145 614
addVariable 0 146 615
assign 1 147 616
COMMAGet 0 147 616
typenameSet 1 147 617
assign 1 149 620
new 0 149 620
assign 1 149 621
new 2 149 621
throw 1 149 622
assign 1 153 632
iteratorGet 0 153 632
assign 1 153 635
hasNextGet 0 153 635
assign 1 154 637
nextGet 0 154 637
delete 0 155 638
assign 1 157 644
heldGet 0 157 644
assign 1 158 645
new 0 158 645
assign 1 158 646
subtract 1 158 646
numargsSet 1 158 647
assign 1 159 648
nameGet 0 159 648
orgNameSet 1 159 649
assign 1 160 650
nameGet 0 160 650
assign 1 160 651
new 0 160 651
assign 1 160 652
add 1 160 652
assign 1 160 653
numargsGet 0 160 653
assign 1 160 654
toString 0 160 654
assign 1 160 655
add 1 160 655
nameSet 1 160 656
assign 1 161 657
secondGet 0 161 657
assign 1 162 658
typenameGet 0 162 658
assign 1 162 659
VARGet 0 162 659
assign 1 162 660
equals 1 162 660
resolveNp 0 163 662
assign 1 165 663
heldGet 0 165 663
rtypeSet 1 165 664
assign 1 166 665
rtypeGet 0 166 665
assign 1 166 666
namepathGet 0 166 666
assign 1 166 667
undef 1 166 672
rtypeSet 1 168 673
assign 1 169 676
rtypeGet 0 169 676
assign 1 169 677
namepathGet 0 169 677
assign 1 169 678
toString 0 169 678
assign 1 169 679
new 0 169 679
assign 1 169 680
equals 1 169 680
assign 1 171 682
rtypeGet 0 171 682
assign 1 171 683
new 0 171 683
isTypedSet 1 171 684
assign 1 172 685
rtypeGet 0 172 685
assign 1 172 686
new 0 172 686
isSelfSet 1 172 687
assign 1 173 688
rtypeGet 0 173 688
assign 1 173 689
new 0 173 689
isThisSet 1 173 690
assign 1 174 691
rtypeGet 0 174 691
assign 1 174 692
namepathGet 0 174 692
assign 1 174 693
new 0 174 693
pathSet 1 174 694
assign 1 175 697
rtypeGet 0 175 697
assign 1 175 698
namepathGet 0 175 698
assign 1 175 699
toString 0 175 699
assign 1 175 700
new 0 175 700
assign 1 175 701
equals 1 175 701
assign 1 176 703
rtypeGet 0 176 703
assign 1 176 704
new 0 176 704
isTypedSet 1 176 705
assign 1 177 706
rtypeGet 0 177 706
assign 1 177 707
new 0 177 707
isSelfSet 1 177 708
delete 0 179 712
assign 1 181 715
new 0 181 715
rtypeSet 1 181 716
assign 1 182 717
rtypeGet 0 182 717
assign 1 182 718
new 0 182 718
isTypedSet 1 182 719
assign 1 183 720
rtypeGet 0 183 720
assign 1 183 721
new 0 183 721
isSelfSet 1 183 722
assign 1 184 723
rtypeGet 0 184 723
assign 1 184 724
new 0 184 724
isThisSet 1 184 725
assign 1 185 726
rtypeGet 0 185 726
assign 1 185 727
new 0 185 727
impliedSet 1 185 728
assign 1 186 729
rtypeGet 0 186 729
assign 1 186 730
new 0 186 730
assign 1 186 731
new 1 186 731
namepathSet 1 186 732
assign 1 188 734
classGet 0 188 734
assign 1 189 735
heldGet 0 189 735
assign 1 189 736
methodsGet 0 189 736
assign 1 189 737
nameGet 0 189 737
put 2 189 738
assign 1 190 739
heldGet 0 190 739
assign 1 190 740
orderedMethodsGet 0 190 740
addValue 1 190 741
assign 1 192 746
nextDescendGet 0 192 746
return 1 192 747
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass6();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass6.bevs_inst = (BEC_3_5_5_5_BuildVisitPass6)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass6.bevs_inst;
}
}
}
