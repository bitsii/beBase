namespace be {
/* IO:File: source/build/Pass6.be */
public sealed class BEC_3_5_5_5_BuildVisitPass6 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass6() { }
static BEC_3_5_5_5_BuildVisitPass6() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_0 = {0x2C};
private static byte[] bels_1 = {0x2C};
private static byte[] bels_2 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_3 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bels_4 = {0x5F};
private static byte[] bels_5 = {0x73,0x65,0x6C,0x66};
public static new BEC_3_5_5_5_BuildVisitPass6 bevs_inst;
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_9_3_ContainerSet bevl_langs = null;
BEC_2_5_4_BuildNode bevl_lang = null;
BEC_2_6_6_SystemObject bevl_doit = null;
BEC_2_6_6_SystemObject bevl_si = null;
BEC_2_6_6_SystemObject bevl_snode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_nxnode = null;
BEC_2_6_6_SystemObject bevl_parens = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_numargs = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vid = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_29_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_38_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_5_4_BuildEmit bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_5_6_BuildIfEmit bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_85_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_89_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_116_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_132_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_138_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_139_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_144_tmpvar_phold = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
if (bevt_9_tmpvar_phold.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 25 */ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_12_tmpvar_phold = beva_node.bem_containedGet_0();
if (bevt_12_tmpvar_phold == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevt_15_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_lengthGet_0();
bevt_16_tmpvar_phold = bevo_0;
if (bevt_14_tmpvar_phold.bevi_int > bevt_16_tmpvar_phold.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
 else  /* Line: 27 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 27 */ {
bevt_20_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_18_tmpvar_phold == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
 else  /* Line: 27 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 27 */ {
bevt_25_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_firstGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_26_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_26_tmpvar_phold);
if (bevt_21_tmpvar_phold != null && bevt_21_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_21_tmpvar_phold).bevi_bool) /* Line: 27 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
 else  /* Line: 27 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 27 */ {
bevt_30_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_containedGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_lengthGet_0();
bevt_31_tmpvar_phold = bevo_1;
if (bevt_28_tmpvar_phold.bevi_int > bevt_31_tmpvar_phold.bevi_int) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
 else  /* Line: 27 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 27 */ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_34_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_firstGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_0_tmpvar_loop = bevt_32_tmpvar_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 30 */ {
bevt_35_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 30 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_36_tmpvar_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_36_tmpvar_phold);
} /* Line: 32 */
 else  /* Line: 30 */ {
break;
} /* Line: 30 */
} /* Line: 30 */
bevt_37_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevl_langs.bem_delete_1(bevt_37_tmpvar_phold);
bevl_doit = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevl_doit != null && bevl_doit is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_doit).bevi_bool) /* Line: 36 */ {
bevl_doit = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_39_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_containedGet_0();
bevl_i = bevt_38_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_40_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpvar_phold != null && bevt_40_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpvar_phold).bevi_bool) /* Line: 38 */ {
bevl_si = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_42_tmpvar_phold = bevl_si.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_43_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_43_tmpvar_phold);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 40 */ {
bevt_44_tmpvar_phold = bevl_si.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_44_tmpvar_phold);
bevl_doit = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 44 */
} /* Line: 40 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
} /* Line: 38 */
bevt_45_tmpvar_phold = bevl_doit.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 48 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 50 */
beva_node.bem_containedSet_1(null);
bevt_47_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_46_tmpvar_phold = (BEC_2_5_4_BuildEmit) (new BEC_2_5_4_BuildEmit()).bem_new_2((BEC_2_4_6_TextString) bevt_47_tmpvar_phold, bevl_langs);
beva_node.bem_heldSet_1(bevt_46_tmpvar_phold);
} /* Line: 53 */
 else  /* Line: 54 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 56 */
bevl_snode = beva_node.bem_scopeGet_0();
bevt_49_tmpvar_phold = bevl_snode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_50_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_50_tmpvar_phold);
if (bevt_48_tmpvar_phold != null && bevt_48_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_48_tmpvar_phold).bevi_bool) /* Line: 60 */ {
bevl_snode = null;
} /* Line: 61 */
if (bevl_snode == null) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 64 */ {
beva_node.bem_delete_0();
bevt_52_tmpvar_phold = bevl_snode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_52_tmpvar_phold.bemd_1(-406676794, BEL_4_Base.bevn_addEmit_1, beva_node);
} /* Line: 66 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 69 */
 else  /* Line: 25 */ {
bevt_54_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_54_tmpvar_phold.bevi_int == bevt_55_tmpvar_phold.bevi_int) {
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 70 */ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_58_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_firstGet_0();
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_1_tmpvar_loop = bevt_56_tmpvar_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 73 */ {
bevt_59_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 73 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_60_tmpvar_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_60_tmpvar_phold);
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lang);
} /* Line: 76 */
 else  /* Line: 73 */ {
break;
} /* Line: 73 */
} /* Line: 73 */
bevt_61_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_1));
bevl_langs.bem_delete_1(bevt_61_tmpvar_phold);
bevt_63_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_62_tmpvar_phold = (BEC_2_5_6_BuildIfEmit) (new BEC_2_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_2_4_6_TextString) bevt_63_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_62_tmpvar_phold);
bevl_ii = bevl_toremove.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 80 */ {
bevt_64_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_64_tmpvar_phold != null && bevt_64_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_64_tmpvar_phold).bevi_bool) /* Line: 80 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 82 */
 else  /* Line: 80 */ {
break;
} /* Line: 80 */
} /* Line: 80 */
} /* Line: 80 */
 else  /* Line: 25 */ {
bevt_66_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_67_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
if (bevt_66_tmpvar_phold.bevi_int == bevt_67_tmpvar_phold.bevi_int) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 84 */ {
if (bevl_nnode == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 85 */ {
bevl_lnode = beva_node;
while (true)
 /* Line: 87 */ {
if (bevl_nnode == null) {
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevt_71_tmpvar_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_72_tmpvar_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_72_tmpvar_phold);
if (bevt_70_tmpvar_phold != null && bevt_70_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_70_tmpvar_phold).bevi_bool) /* Line: 87 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
 else  /* Line: 87 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 87 */ {
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_73_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_73_tmpvar_phold);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_74_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_74_tmpvar_phold);
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_75_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_75_tmpvar_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_inode);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevt_77_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_77_tmpvar_phold == null) {
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_78_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = bevt_78_tmpvar_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 100 */ {
bevt_79_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 100 */ {
bevt_80_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_80_tmpvar_phold);
} /* Line: 101 */
 else  /* Line: 100 */ {
break;
} /* Line: 100 */
} /* Line: 100 */
} /* Line: 100 */
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_nnode = bevl_nxnode;
} /* Line: 112 */
 else  /* Line: 87 */ {
break;
} /* Line: 87 */
} /* Line: 87 */
if (bevl_nnode == null) {
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 114 */ {
bevt_83_tmpvar_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_84_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_84_tmpvar_phold);
if (bevt_82_tmpvar_phold != null && bevt_82_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_82_tmpvar_phold).bevi_bool) /* Line: 114 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 114 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 114 */
 else  /* Line: 114 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 114 */ {
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nnode);
} /* Line: 116 */
} /* Line: 114 */
bevt_85_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpvar_phold;
} /* Line: 119 */
 else  /* Line: 25 */ {
bevt_87_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_88_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_87_tmpvar_phold.bevi_int == bevt_88_tmpvar_phold.bevi_int) {
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevt_89_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_parens = bevt_89_tmpvar_phold.bem_firstGet_0();
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_90_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_2));
bevl_nd.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_91_tmpvar_phold);
bevl_parens.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_nd);
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_2_4_3_MathInt(0));
bevt_92_tmpvar_phold = bevl_parens.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_92_tmpvar_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 129 */ {
bevt_93_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_93_tmpvar_phold != null && bevt_93_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_93_tmpvar_phold).bevi_bool) /* Line: 129 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_ix = bevl_i.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_95_tmpvar_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_96_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_94_tmpvar_phold = bevt_95_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_96_tmpvar_phold);
if (bevt_94_tmpvar_phold != null && bevt_94_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_94_tmpvar_phold).bevi_bool) /* Line: 134 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 135 */
 else  /* Line: 134 */ {
bevt_98_tmpvar_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_99_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_99_tmpvar_phold);
if (bevt_97_tmpvar_phold != null && bevt_97_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_97_tmpvar_phold).bevi_bool) /* Line: 136 */ {
bevt_100_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_100_tmpvar_phold);
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_101_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_101_tmpvar_phold);
bevt_102_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_102_tmpvar_phold);
bevl_i.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_v);
bevt_103_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_103_tmpvar_phold);
bevl_i.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
} /* Line: 143 */
 else  /* Line: 134 */ {
bevt_105_tmpvar_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_106_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_106_tmpvar_phold);
if (bevt_104_tmpvar_phold != null && bevt_104_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_104_tmpvar_phold).bevi_bool) /* Line: 144 */ {
bevt_108_tmpvar_phold = bevl_ix.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_109_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_107_tmpvar_phold = bevt_108_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_109_tmpvar_phold);
if (bevt_107_tmpvar_phold != null && bevt_107_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_107_tmpvar_phold).bevi_bool) /* Line: 145 */ {
bevt_110_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_110_tmpvar_phold);
bevt_111_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_112_tmpvar_phold = bevl_ix.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_111_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_112_tmpvar_phold);
bevt_113_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_114_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_113_tmpvar_phold.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_114_tmpvar_phold);
bevl_i.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevt_115_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_115_tmpvar_phold);
} /* Line: 150 */
 else  /* Line: 151 */ {
bevt_117_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bels_3));
bevt_116_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_117_tmpvar_phold, bevl_i);
throw new be.BELS_Base.BECS_ThrowBack(bevt_116_tmpvar_phold);
} /* Line: 152 */
} /* Line: 145 */
} /* Line: 134 */
} /* Line: 134 */
} /* Line: 134 */
 else  /* Line: 129 */ {
break;
} /* Line: 129 */
} /* Line: 129 */
bevl_ii = bevl_toremove.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 156 */ {
bevt_118_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_118_tmpvar_phold != null && bevt_118_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_118_tmpvar_phold).bevi_bool) /* Line: 156 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 158 */
 else  /* Line: 156 */ {
break;
} /* Line: 156 */
} /* Line: 156 */
bevl_s = beva_node.bem_heldGet_0();
bevt_120_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_119_tmpvar_phold = bevl_numargs.bemd_1(81310150, BEL_4_Base.bevn_subtract_1, bevt_120_tmpvar_phold);
bevl_s.bemd_1(-537631759, BEL_4_Base.bevn_numargsSet_1, bevt_119_tmpvar_phold);
bevt_121_tmpvar_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_s.bemd_1(-1380410043, BEL_4_Base.bevn_orgNameSet_1, bevt_121_tmpvar_phold);
bevt_124_tmpvar_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_125_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_125_tmpvar_phold);
bevt_127_tmpvar_phold = bevl_s.bemd_0(-548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_126_tmpvar_phold = bevt_127_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_126_tmpvar_phold);
bevl_s.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_122_tmpvar_phold);
bevl_i = beva_node.bem_secondGet_0();
bevt_129_tmpvar_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_130_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_130_tmpvar_phold);
if (bevt_128_tmpvar_phold != null && bevt_128_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_128_tmpvar_phold).bevi_bool) /* Line: 165 */ {
bevl_i.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_131_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_s.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, bevt_131_tmpvar_phold);
bevt_135_tmpvar_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_133_tmpvar_phold = bevt_134_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_136_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_5));
bevt_132_tmpvar_phold = bevt_133_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpvar_phold);
if (bevt_132_tmpvar_phold != null && bevt_132_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_132_tmpvar_phold).bevi_bool) /* Line: 169 */ {
bevt_137_tmpvar_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_138_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_137_tmpvar_phold.bemd_1(-524129890, BEL_4_Base.bevn_isSelfSet_1, bevt_138_tmpvar_phold);
} /* Line: 170 */
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 172 */
bevl_clnode = beva_node.bem_classGet_0();
bevt_140_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_139_tmpvar_phold = bevt_140_tmpvar_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_141_tmpvar_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_139_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_141_tmpvar_phold, beva_node);
bevt_143_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_142_tmpvar_phold = bevt_143_tmpvar_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_142_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
} /* Line: 176 */
} /* Line: 25 */
} /* Line: 25 */
} /* Line: 25 */
bevt_144_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_144_tmpvar_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {21, 24, 25, 25, 25, 25, 26, 27, 27, 27, 27, 27, 27, 27, 27, 0, 0, 0, 27, 27, 27, 27, 27, 0, 0, 0, 27, 27, 27, 27, 27, 27, 0, 0, 0, 27, 27, 27, 27, 27, 27, 0, 0, 0, 29, 30, 30, 30, 30, 0, 30, 30, 32, 32, 34, 34, 35, 37, 38, 38, 38, 38, 39, 40, 40, 40, 41, 41, 44, 48, 49, 50, 52, 53, 53, 53, 55, 56, 59, 60, 60, 60, 61, 64, 64, 65, 66, 66, 69, 70, 70, 70, 70, 71, 72, 73, 73, 73, 73, 0, 73, 73, 75, 75, 76, 78, 78, 79, 79, 79, 80, 80, 81, 82, 84, 84, 84, 84, 85, 85, 86, 87, 87, 87, 87, 87, 0, 0, 0, 88, 89, 89, 90, 91, 92, 93, 93, 94, 95, 96, 96, 97, 98, 99, 99, 99, 100, 100, 100, 101, 101, 108, 109, 110, 111, 112, 114, 114, 114, 114, 114, 0, 0, 0, 115, 116, 119, 119, 120, 120, 120, 120, 121, 121, 122, 123, 124, 124, 125, 125, 126, 127, 128, 129, 129, 129, 130, 131, 134, 134, 134, 135, 136, 136, 136, 137, 137, 138, 139, 139, 140, 140, 141, 142, 142, 143, 144, 144, 144, 145, 145, 145, 146, 146, 147, 147, 147, 148, 148, 148, 149, 150, 150, 152, 152, 152, 156, 156, 157, 158, 160, 161, 161, 161, 162, 162, 163, 163, 163, 163, 163, 163, 163, 164, 165, 165, 165, 166, 168, 168, 169, 169, 169, 169, 169, 170, 170, 170, 172, 174, 175, 175, 175, 175, 176, 176, 176, 178, 178};
public static new int[] bevs_smnlec
 = new int[] {187, 188, 189, 190, 191, 196, 197, 198, 199, 204, 205, 206, 207, 208, 213, 214, 217, 221, 224, 225, 226, 227, 232, 233, 236, 240, 243, 244, 245, 246, 247, 248, 250, 253, 257, 260, 261, 262, 263, 264, 269, 270, 273, 277, 280, 281, 282, 283, 284, 284, 287, 289, 290, 291, 297, 298, 299, 301, 302, 303, 304, 307, 309, 310, 311, 312, 314, 315, 316, 324, 326, 327, 329, 330, 331, 332, 335, 336, 338, 339, 340, 341, 343, 345, 350, 351, 352, 353, 355, 358, 359, 360, 365, 366, 367, 368, 369, 370, 371, 371, 374, 376, 377, 378, 379, 385, 386, 387, 388, 389, 390, 393, 395, 396, 404, 405, 406, 411, 412, 417, 418, 421, 426, 427, 428, 429, 431, 434, 438, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 461, 462, 463, 466, 468, 469, 476, 477, 478, 479, 480, 486, 491, 492, 493, 494, 496, 499, 503, 506, 507, 510, 511, 514, 515, 516, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 537, 539, 540, 541, 542, 543, 545, 548, 549, 550, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 565, 566, 567, 569, 570, 571, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 586, 587, 588, 598, 601, 603, 604, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 628, 629, 630, 631, 632, 633, 634, 635, 637, 638, 639, 641, 643, 644, 645, 646, 647, 648, 649, 650, 655, 656};
/* BEGIN LINEINFO 
resolveNp 0 21 187
assign 1 24 188
nextPeerGet 0 24 188
assign 1 25 189
typenameGet 0 25 189
assign 1 25 190
EMITGet 0 25 190
assign 1 25 191
equals 1 25 196
assign 1 26 197
nextAscendGet 0 26 197
assign 1 27 198
containedGet 0 27 198
assign 1 27 199
def 1 27 204
assign 1 27 205
containedGet 0 27 205
assign 1 27 206
lengthGet 0 27 206
assign 1 27 207
new 0 27 207
assign 1 27 208
greater 1 27 213
assign 1 0 214
assign 1 0 217
assign 1 0 221
assign 1 27 224
containedGet 0 27 224
assign 1 27 225
firstGet 0 27 225
assign 1 27 226
containedGet 0 27 226
assign 1 27 227
def 1 27 232
assign 1 0 233
assign 1 0 236
assign 1 0 240
assign 1 27 243
containedGet 0 27 243
assign 1 27 244
firstGet 0 27 244
assign 1 27 245
containedGet 0 27 245
assign 1 27 246
lengthGet 0 27 246
assign 1 27 247
new 0 27 247
assign 1 27 248
greater 1 27 248
assign 1 0 250
assign 1 0 253
assign 1 0 257
assign 1 27 260
secondGet 0 27 260
assign 1 27 261
containedGet 0 27 261
assign 1 27 262
lengthGet 0 27 262
assign 1 27 263
new 0 27 263
assign 1 27 264
greater 1 27 269
assign 1 0 270
assign 1 0 273
assign 1 0 277
assign 1 29 280
new 0 29 280
assign 1 30 281
containedGet 0 30 281
assign 1 30 282
firstGet 0 30 282
assign 1 30 283
containedGet 0 30 283
assign 1 30 284
iteratorGet 0 0 284
assign 1 30 287
hasNextGet 0 30 287
assign 1 30 289
nextGet 0 30 289
assign 1 32 290
heldGet 0 32 290
addValue 1 32 291
assign 1 34 297
new 0 34 297
delete 1 34 298
assign 1 35 299
new 0 35 299
assign 1 37 301
new 0 37 301
assign 1 38 302
secondGet 0 38 302
assign 1 38 303
containedGet 0 38 303
assign 1 38 304
iteratorGet 0 38 304
assign 1 38 307
hasNextGet 0 38 307
assign 1 39 309
nextGet 0 39 309
assign 1 40 310
typenameGet 0 40 310
assign 1 40 311
STRINGLGet 0 40 311
assign 1 40 312
equals 1 40 312
assign 1 41 314
heldGet 0 41 314
heldSet 1 41 315
assign 1 44 316
new 0 44 316
assign 1 48 324
not 0 48 324
delete 0 49 326
return 1 50 327
containedSet 1 52 329
assign 1 53 330
heldGet 0 53 330
assign 1 53 331
new 2 53 331
heldSet 1 53 332
delete 0 55 335
return 1 56 336
assign 1 59 338
scopeGet 0 59 338
assign 1 60 339
typenameGet 0 60 339
assign 1 60 340
METHODGet 0 60 340
assign 1 60 341
equals 1 60 341
assign 1 61 343
assign 1 64 345
def 1 64 350
delete 0 65 351
assign 1 66 352
heldGet 0 66 352
addEmit 1 66 353
return 1 69 355
assign 1 70 358
typenameGet 0 70 358
assign 1 70 359
IFEMITGet 0 70 359
assign 1 70 360
equals 1 70 365
assign 1 71 366
new 0 71 366
assign 1 72 367
new 0 72 367
assign 1 73 368
containedGet 0 73 368
assign 1 73 369
firstGet 0 73 369
assign 1 73 370
containedGet 0 73 370
assign 1 73 371
iteratorGet 0 0 371
assign 1 73 374
hasNextGet 0 73 374
assign 1 73 376
nextGet 0 73 376
assign 1 75 377
heldGet 0 75 377
addValue 1 75 378
addValue 1 76 379
assign 1 78 385
new 0 78 385
delete 1 78 386
assign 1 79 387
heldGet 0 79 387
assign 1 79 388
new 2 79 388
heldSet 1 79 389
assign 1 80 390
iteratorGet 0 80 390
assign 1 80 393
hasNextGet 0 80 393
assign 1 81 395
nextGet 0 81 395
delete 0 82 396
assign 1 84 404
typenameGet 0 84 404
assign 1 84 405
IFGet 0 84 405
assign 1 84 406
equals 1 84 411
assign 1 85 412
def 1 85 417
assign 1 86 418
assign 1 87 421
def 1 87 426
assign 1 87 427
typenameGet 0 87 427
assign 1 87 428
ELIFGet 0 87 428
assign 1 87 429
equals 1 87 429
assign 1 0 431
assign 1 0 434
assign 1 0 438
assign 1 88 441
new 1 88 441
assign 1 89 442
ELSEGet 0 89 442
typenameSet 1 89 443
copyLoc 1 90 444
assign 1 91 445
new 1 91 445
copyLoc 1 92 446
assign 1 93 447
BRACESGet 0 93 447
typenameSet 1 93 448
assign 1 94 449
new 1 94 449
copyLoc 1 95 450
assign 1 96 451
IFGet 0 96 451
typenameSet 1 96 452
addValue 1 97 453
addValue 1 98 454
assign 1 99 455
containedGet 0 99 455
assign 1 99 456
def 1 99 461
assign 1 100 462
containedGet 0 100 462
assign 1 100 463
iteratorGet 0 100 463
assign 1 100 466
hasNextGet 0 100 466
assign 1 101 468
nextGet 0 101 468
addValue 1 101 469
addValue 1 108 476
assign 1 109 477
assign 1 110 478
nextPeerGet 0 110 478
delete 0 111 479
assign 1 112 480
assign 1 114 486
def 1 114 491
assign 1 114 492
typenameGet 0 114 492
assign 1 114 493
ELSEGet 0 114 493
assign 1 114 494
equals 1 114 494
assign 1 0 496
assign 1 0 499
assign 1 0 503
delete 0 115 506
addValue 1 116 507
assign 1 119 510
nextDescendGet 0 119 510
return 1 119 511
assign 1 120 514
typenameGet 0 120 514
assign 1 120 515
METHODGet 0 120 515
assign 1 120 516
equals 1 120 521
assign 1 121 522
containedGet 0 121 522
assign 1 121 523
firstGet 0 121 523
assign 1 122 524
new 1 122 524
copyLoc 1 123 525
assign 1 124 526
IDGet 0 124 526
typenameSet 1 124 527
assign 1 125 528
new 0 125 528
heldSet 1 125 529
prepend 1 126 530
assign 1 127 531
new 0 127 531
assign 1 128 532
new 0 128 532
assign 1 129 533
containedGet 0 129 533
assign 1 129 534
iteratorGet 0 129 534
assign 1 129 537
hasNextGet 0 129 537
assign 1 130 539
nextGet 0 130 539
assign 1 131 540
nextPeerGet 0 131 540
assign 1 134 541
typenameGet 0 134 541
assign 1 134 542
COMMAGet 0 134 542
assign 1 134 543
equals 1 134 543
addValue 1 135 545
assign 1 136 548
typenameGet 0 136 548
assign 1 136 549
IDGet 0 136 549
assign 1 136 550
equals 1 136 550
assign 1 137 552
new 0 137 552
assign 1 137 553
add 1 137 553
assign 1 138 554
new 0 138 554
assign 1 139 555
heldGet 0 139 555
nameSet 1 139 556
assign 1 140 557
new 0 140 557
isArgSet 1 140 558
heldSet 1 141 559
assign 1 142 560
VARGet 0 142 560
typenameSet 1 142 561
addVariable 0 143 562
assign 1 144 565
typenameGet 0 144 565
assign 1 144 566
VARGet 0 144 566
assign 1 144 567
equals 1 144 567
assign 1 145 569
typenameGet 0 145 569
assign 1 145 570
IDGet 0 145 570
assign 1 145 571
equals 1 145 571
assign 1 146 573
new 0 146 573
assign 1 146 574
add 1 146 574
assign 1 147 575
heldGet 0 147 575
assign 1 147 576
heldGet 0 147 576
nameSet 1 147 577
assign 1 148 578
heldGet 0 148 578
assign 1 148 579
new 0 148 579
isArgSet 1 148 580
addVariable 0 149 581
assign 1 150 582
COMMAGet 0 150 582
typenameSet 1 150 583
assign 1 152 586
new 0 152 586
assign 1 152 587
new 2 152 587
throw 1 152 588
assign 1 156 598
iteratorGet 0 156 598
assign 1 156 601
hasNextGet 0 156 601
assign 1 157 603
nextGet 0 157 603
delete 0 158 604
assign 1 160 610
heldGet 0 160 610
assign 1 161 611
new 0 161 611
assign 1 161 612
subtract 1 161 612
numargsSet 1 161 613
assign 1 162 614
nameGet 0 162 614
orgNameSet 1 162 615
assign 1 163 616
nameGet 0 163 616
assign 1 163 617
new 0 163 617
assign 1 163 618
add 1 163 618
assign 1 163 619
numargsGet 0 163 619
assign 1 163 620
toString 0 163 620
assign 1 163 621
add 1 163 621
nameSet 1 163 622
assign 1 164 623
secondGet 0 164 623
assign 1 165 624
typenameGet 0 165 624
assign 1 165 625
VARGet 0 165 625
assign 1 165 626
equals 1 165 626
resolveNp 0 166 628
assign 1 168 629
heldGet 0 168 629
rtypeSet 1 168 630
assign 1 169 631
rtypeGet 0 169 631
assign 1 169 632
namepathGet 0 169 632
assign 1 169 633
toString 0 169 633
assign 1 169 634
new 0 169 634
assign 1 169 635
equals 1 169 635
assign 1 170 637
rtypeGet 0 170 637
assign 1 170 638
new 0 170 638
isSelfSet 1 170 639
delete 0 172 641
assign 1 174 643
classGet 0 174 643
assign 1 175 644
heldGet 0 175 644
assign 1 175 645
methodsGet 0 175 645
assign 1 175 646
nameGet 0 175 646
put 2 175 647
assign 1 176 648
heldGet 0 176 648
assign 1 176 649
orderedMethodsGet 0 176 649
addValue 1 176 650
assign 1 178 655
nextDescendGet 0 178 655
return 1 178 656
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass6();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass6.bevs_inst = (BEC_3_5_5_5_BuildVisitPass6)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass6.bevs_inst;
}
}
}
