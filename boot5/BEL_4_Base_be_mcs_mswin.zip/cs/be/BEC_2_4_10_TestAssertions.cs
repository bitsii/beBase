namespace be {
/* IO:File: source/base/Test.be */
public class BEC_2_4_10_TestAssertions : BEC_2_6_6_SystemObject {
public BEC_2_4_10_TestAssertions() { }
static BEC_2_4_10_TestAssertions() { }
private static byte[] becc_BEC_2_4_10_TestAssertions_clname = {0x54,0x65,0x73,0x74,0x3A,0x41,0x73,0x73,0x65,0x72,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_2_4_10_TestAssertions_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_0 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_1 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_2 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_3 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_4 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_5 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_6 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x2E};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_7 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_8 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_9 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_10_TestAssertions_bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_4_10_TestAssertions_bels_9, 36));
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_10 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_10_TestAssertions_bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_4_10_TestAssertions_bels_10, 1));
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_11 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x55,0x4E,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_12 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_13 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_14 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x4F,0x54,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_15 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x54,0x52,0x55,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_16 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x46,0x41,0x4C,0x53,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
public static new BEC_2_4_10_TestAssertions bece_BEC_2_4_10_TestAssertions_bevs_inst;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_10_tmpany_phold = null;
bevt_2_tmpany_phold = beva_v1.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_v2);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 27 */ {
bevl_msg = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_0));
if (beva_v1 == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 29 */ {
if (beva_v2 == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 29 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 29 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 29 */
 else  /* Line: 29 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 29 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_1));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevl_msg.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(beva_v1);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_2));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(beva_v2);
} /* Line: 30 */
bevt_10_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 32 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNotHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v1.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_v2);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 36 */ {
bevl_msg = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_3));
if (beva_v1 == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 38 */ {
if (beva_v2 == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 38 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 38 */ {
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_4));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_msg.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(beva_v1);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_5));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(beva_v2);
} /* Line: 39 */
bevt_9_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_9_tmpany_phold);
} /* Line: 41 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_assertEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_10_TestAssertions bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_10_TestAssertions) this.bem_assertEqual_2(beva_v1, beva_v2);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_assertNotEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_10_TestAssertions bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_10_TestAssertions) this.bem_assertNotEqual_2(beva_v1, beva_v2);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_6_TextString bevl_v1v = null;
BEC_2_4_6_TextString bevl_v2v = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
if (beva_v1 == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(56, bece_BEC_2_4_10_TestAssertions_bels_6));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 52 */
bevt_3_tmpany_phold = beva_v1.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, beva_v2);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 54 */ {
if (beva_v1 == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevl_v1v = (BEC_2_4_6_TextString) beva_v1.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 56 */
 else  /* Line: 57 */ {
bevl_v1v = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_7));
} /* Line: 58 */
if (beva_v2 == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevl_v2v = (BEC_2_4_6_TextString) beva_v2.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 61 */
 else  /* Line: 62 */ {
bevl_v2v = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_8));
} /* Line: 63 */
bevt_10_tmpany_phold = bece_BEC_2_4_10_TestAssertions_bevo_0;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_v1v);
bevt_11_tmpany_phold = bece_BEC_2_4_10_TestAssertions_bevo_1;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevl_v2v);
bevt_6_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 65 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNotEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v1.bemd_1(581408689, BEL_4_Base.bevn_equals_1, beva_v2);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 69 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_4_10_TestAssertions_bels_11));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 70 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNull_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_12));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 75 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertIsNull_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_13));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 80 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNotNull_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_4_10_TestAssertions_bels_14));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 85 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertTrue_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 89 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_15));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 90 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertFalse_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_4_7_TestFailure bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (beva_v != null && beva_v is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) beva_v).bevi_bool) /* Line: 94 */ {
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_4_10_TestAssertions_bels_16));
bevt_0_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_1_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_0_tmpany_phold);
} /* Line: 95 */
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {27, 27, 28, 29, 29, 29, 29, 0, 0, 0, 30, 30, 30, 30, 30, 30, 32, 32, 36, 37, 38, 38, 38, 38, 0, 0, 0, 39, 39, 39, 39, 39, 39, 41, 41, 45, 45, 48, 48, 51, 51, 52, 52, 52, 54, 55, 55, 56, 58, 60, 60, 61, 63, 65, 65, 65, 65, 65, 65, 65, 69, 70, 70, 70, 74, 74, 75, 75, 75, 79, 79, 80, 80, 80, 84, 84, 85, 85, 85, 89, 90, 90, 90, 95, 95, 95};
public static new int[] bevs_smnlec
 = new int[] {47, 48, 50, 51, 56, 57, 62, 63, 66, 70, 73, 74, 75, 76, 77, 78, 80, 81, 97, 99, 100, 105, 106, 111, 112, 115, 119, 122, 123, 124, 125, 126, 127, 129, 130, 136, 137, 141, 142, 159, 164, 165, 166, 167, 169, 171, 176, 177, 180, 182, 187, 188, 191, 193, 194, 195, 196, 197, 198, 199, 207, 209, 210, 211, 219, 224, 225, 226, 227, 235, 240, 241, 242, 243, 251, 256, 257, 258, 259, 267, 269, 270, 271, 279, 280, 281};
/* BEGIN LINEINFO 
assign 1 27 47
has 1 27 47
assign 1 27 48
not 0 27 48
assign 1 28 50
new 0 28 50
assign 1 29 51
def 1 29 56
assign 1 29 57
def 1 29 62
assign 1 0 63
assign 1 0 66
assign 1 0 70
assign 1 30 73
new 0 30 73
assign 1 30 74
addValue 1 30 74
assign 1 30 75
addValue 1 30 75
assign 1 30 76
new 0 30 76
assign 1 30 77
addValue 1 30 77
addValue 1 30 78
assign 1 32 80
new 1 32 80
throw 1 32 81
assign 1 36 97
has 1 36 97
assign 1 37 99
new 0 37 99
assign 1 38 100
def 1 38 105
assign 1 38 106
def 1 38 111
assign 1 0 112
assign 1 0 115
assign 1 0 119
assign 1 39 122
new 0 39 122
assign 1 39 123
addValue 1 39 123
assign 1 39 124
addValue 1 39 124
assign 1 39 125
new 0 39 125
assign 1 39 126
addValue 1 39 126
addValue 1 39 127
assign 1 41 129
new 1 41 129
throw 1 41 130
assign 1 45 136
assertEqual 2 45 136
return 1 45 137
assign 1 48 141
assertNotEqual 2 48 141
return 1 48 142
assign 1 51 159
undef 1 51 164
assign 1 52 165
new 0 52 165
assign 1 52 166
new 1 52 166
throw 1 52 167
assign 1 54 169
notEquals 1 54 169
assign 1 55 171
def 1 55 176
assign 1 56 177
toString 0 56 177
assign 1 58 180
new 0 58 180
assign 1 60 182
def 1 60 187
assign 1 61 188
toString 0 61 188
assign 1 63 191
new 0 63 191
assign 1 65 193
new 0 65 193
assign 1 65 194
add 1 65 194
assign 1 65 195
new 0 65 195
assign 1 65 196
add 1 65 196
assign 1 65 197
add 1 65 197
assign 1 65 198
new 1 65 198
throw 1 65 199
assign 1 69 207
equals 1 69 207
assign 1 70 209
new 0 70 209
assign 1 70 210
new 1 70 210
throw 1 70 211
assign 1 74 219
def 1 74 224
assign 1 75 225
new 0 75 225
assign 1 75 226
new 1 75 226
throw 1 75 227
assign 1 79 235
def 1 79 240
assign 1 80 241
new 0 80 241
assign 1 80 242
new 1 80 242
throw 1 80 243
assign 1 84 251
undef 1 84 256
assign 1 85 257
new 0 85 257
assign 1 85 258
new 1 85 258
throw 1 85 259
assign 1 89 267
not 0 89 267
assign 1 90 269
new 0 90 269
assign 1 90 270
new 1 90 270
throw 1 90 271
assign 1 95 279
new 0 95 279
assign 1 95 280
new 1 95 280
throw 1 95 281
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -1502128718: return bem_default_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1397518831: return bem_assertFalse_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1801614214: return bem_assertNotNull_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -754733399: return bem_assertIsNull_1(bevd_0);
case -815800737: return bem_assertNull_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -646535002: return bem_assertTrue_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1160364576: return bem_assertNotHas_2(bevd_0, bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 975863745: return bem_assertEqual_2(bevd_0, bevd_1);
case 511348602: return bem_assertNotEqual_2(bevd_0, bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1328041857: return bem_assertNotEquals_2(bevd_0, bevd_1);
case 383195175: return bem_assertHas_2(bevd_0, bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 187025688: return bem_assertEquals_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_TestAssertions_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_10_TestAssertions_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_10_TestAssertions();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst = (BEC_2_4_10_TestAssertions) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst;
}
}
}
