namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList : BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
static BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_2_9_10_ContainerLinkedList bevs_inst;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_10_4_ContainerLinkedListNode) (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) this.bem_create_0();
bevl_iter = this.bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 140 */ {
return (BEC_2_6_6_SystemObject) bevl_other;
} /* Line: 141 */
while (true)
 /* Line: 145 */ {
if (bevl_f == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 145 */ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 147 */ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 148 */
if (bevl_fnode == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 151 */ {
bevl_fnode = bevl_f;
} /* Line: 152 */
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 155 */
 else  /* Line: 145 */ {
break;
} /* Line: 145 */
} /* Line: 145 */
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, null);
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 164 */ {
beva_node.bemd_1(957596394, BEL_4_Base.bevn_priorSet_1, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 167 */
 else  /* Line: 168 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 170 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, null);
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 176 */ {
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 179 */
 else  /* Line: 180 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 182 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) {
beva_node.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) {
beva_node.bemd_1(-1505376950, BEL_4_Base.bevn_insertBefore_1, beva_toIns);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_0;
if (beva_pos.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_2_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_2_tmpany_phold;
} /* Line: 196 */
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 199 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 199 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 201 */
 else  /* Line: 202 */ {
break;
} /* Line: 203 */
bevl_i.bevi_int++;
} /* Line: 205 */
 else  /* Line: 199 */ {
break;
} /* Line: 199 */
} /* Line: 199 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 207 */ {
return null;
} /* Line: 208 */
bevt_6_tmpany_phold = bevl_iter.bem_nextGet_0();
return bevt_6_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = bevo_1;
beva_pos = beva_pos.bem_add_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 216 */ {
bevt_1_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 216 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 218 */
 else  /* Line: 219 */ {
break;
} /* Line: 220 */
bevl_i.bevi_int++;
} /* Line: 222 */
 else  /* Line: 216 */ {
break;
} /* Line: 216 */
} /* Line: 216 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 225 */
bevt_5_tmpany_phold = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 231 */ {
return null;
} /* Line: 231 */
bevt_1_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_secondGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 236 */ {
bevt_3_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 236 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 236 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 236 */
 else  /* Line: 236 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 236 */ {
bevt_5_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_heldGet_0();
return bevt_4_tmpany_phold;
} /* Line: 237 */
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_thirdGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_4_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
 else  /* Line: 243 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 243 */ {
bevt_7_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_nextGet_0();
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
 else  /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 243 */ {
bevt_10_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_nextGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_heldGet_0();
return bevt_8_tmpany_phold;
} /* Line: 244 */
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 250 */ {
return null;
} /* Line: 250 */
bevt_1_tmpany_phold = bevp_lastNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = beva_pos.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 255 */ {
return bevp_firstNode;
} /* Line: 256 */
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 259 */ {
bevt_2_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 259 */ {
bevt_3_tmpany_phold = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 261 */
 else  /* Line: 262 */ {
break;
} /* Line: 263 */
bevl_i.bevi_int++;
} /* Line: 265 */
 else  /* Line: 259 */ {
break;
} /* Line: 259 */
} /* Line: 259 */
bevt_4_tmpany_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 267 */ {
return null;
} /* Line: 268 */
bevt_5_tmpany_phold = bevl_iter.bem_nextNodeGet_0();
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = this.bem_newNode_1(beva_held);
this.bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addValue_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_held == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 279 */ {
bevt_2_tmpany_phold = beva_held.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 279 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 279 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 279 */
 else  /* Line: 279 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 279 */ {
this.bem_addAll_1(beva_held);
} /* Line: 280 */
 else  /* Line: 281 */ {
this.bem_addValueWhole_1(beva_held);
} /* Line: 282 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 287 */ {
while (true)
 /* Line: 288 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 288 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 289 */
 else  /* Line: 288 */ {
break;
} /* Line: 288 */
} /* Line: 288 */
} /* Line: 288 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addAll_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 295 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 296 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_prepend_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = this.bem_newNode_1(beva_held);
this.bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lengthGet_0() {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 307 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 307 */ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 309 */
 else  /* Line: 307 */ {
break;
} /* Line: 307 */
} /* Line: 307 */
return bevl_cnt;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_lengthGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 319 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 320 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_toNodeList_0() {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_len = this.bem_lengthGet_0();
bevl_toret = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 329 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 329 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 330 */ {
bevt_2_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 331 */
bevl_cnt.bevi_int++;
} /* Line: 333 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
return bevl_toret;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_toList_0() {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_len = this.bem_lengthGet_0();
bevl_toret = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 342 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 342 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 344 */
bevl_cnt.bevi_int++;
} /* Line: 346 */
 else  /* Line: 342 */ {
break;
} /* Line: 342 */
} /* Line: 342 */
return bevl_toret;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_maxGet_0();
bevt_0_tmpany_phold = this.bem_subList_2(beva_start, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) this.bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 369 */ {
return bevl_res;
} /* Line: 370 */
bevl_iter = this.bem_linkedListIteratorGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 373 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 374 */ {
return bevl_res;
} /* Line: 375 */
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 378 */ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 379 */
bevl_i.bevi_int++;
} /* Line: 373 */
 else  /* Line: 373 */ {
break;
} /* Line: 373 */
} /* Line: 373 */
return bevl_res;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_reverse_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_tmpany_phold = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
 /* Line: 422 */ {
if (bevl_current == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 422 */ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_tmpany_phold = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_tmpany_phold);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 427 */
 else  /* Line: 422 */ {
break;
} /* Line: 422 */
} /* Line: 422 */
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() {
return bevp_firstNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() {
return bevp_lastNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {132, 132, 137, 138, 139, 140, 140, 141, 145, 145, 146, 147, 147, 148, 151, 151, 152, 154, 155, 157, 158, 159, 163, 164, 164, 165, 166, 167, 169, 170, 175, 176, 176, 177, 178, 179, 181, 182, 187, 191, 195, 195, 195, 196, 196, 198, 199, 199, 200, 200, 201, 205, 207, 207, 208, 210, 210, 214, 214, 215, 216, 216, 217, 217, 218, 222, 224, 224, 225, 225, 227, 227, 231, 231, 231, 232, 232, 236, 236, 236, 236, 236, 0, 0, 0, 237, 237, 237, 239, 243, 243, 243, 243, 243, 0, 0, 0, 243, 243, 243, 243, 0, 0, 0, 244, 244, 244, 244, 246, 250, 250, 250, 251, 251, 255, 255, 256, 258, 259, 259, 260, 261, 265, 267, 268, 270, 270, 274, 275, 279, 279, 279, 0, 0, 0, 280, 282, 287, 287, 288, 289, 289, 295, 295, 296, 296, 301, 302, 306, 307, 307, 308, 309, 311, 315, 315, 319, 319, 320, 320, 322, 322, 326, 327, 328, 329, 329, 330, 330, 331, 331, 333, 335, 339, 340, 341, 342, 342, 343, 343, 344, 344, 344, 346, 348, 352, 352, 356, 356, 360, 360, 364, 364, 364, 364, 368, 369, 369, 370, 372, 373, 373, 373, 374, 374, 375, 377, 378, 378, 379, 373, 382, 420, 421, 422, 422, 423, 424, 424, 425, 426, 427, 429, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 31, 32, 33, 34, 39, 40, 44, 49, 50, 51, 56, 57, 59, 64, 65, 67, 68, 74, 75, 76, 80, 81, 86, 87, 88, 89, 92, 93, 99, 100, 105, 106, 107, 108, 111, 112, 117, 121, 134, 135, 140, 141, 142, 144, 145, 148, 150, 155, 156, 161, 167, 172, 173, 175, 176, 187, 188, 189, 190, 193, 195, 200, 201, 206, 212, 217, 218, 219, 221, 222, 227, 232, 233, 235, 236, 245, 250, 251, 252, 257, 258, 261, 265, 268, 269, 270, 272, 286, 291, 292, 293, 298, 299, 302, 306, 309, 310, 311, 316, 317, 320, 324, 327, 328, 329, 330, 332, 337, 342, 343, 345, 346, 357, 358, 360, 362, 363, 366, 368, 370, 375, 381, 383, 385, 386, 390, 391, 398, 403, 404, 406, 409, 413, 416, 419, 427, 432, 435, 437, 438, 450, 455, 456, 457, 463, 464, 471, 472, 475, 477, 478, 484, 488, 489, 495, 500, 501, 502, 504, 505, 515, 516, 517, 518, 521, 523, 528, 529, 530, 532, 538, 549, 550, 551, 552, 555, 557, 562, 563, 564, 565, 567, 573, 577, 578, 582, 583, 587, 588, 594, 595, 596, 597, 609, 610, 615, 616, 618, 619, 622, 627, 628, 629, 631, 633, 634, 639, 640, 642, 648, 656, 657, 660, 665, 666, 667, 668, 669, 670, 671, 677, 681, 684, 688, 691};
/* BEGIN LINEINFO 
assign 1 132 18
new 2 132 18
return 1 132 19
assign 1 137 31
create 0 137 31
assign 1 138 32
linkedListIteratorGet 0 138 32
assign 1 139 33
nextNodeGet 0 139 33
assign 1 140 34
undef 1 140 39
return 1 141 40
assign 1 145 44
def 1 145 49
assign 1 146 50
copy 0 146 50
assign 1 147 51
def 1 147 56
nextSet 1 148 57
assign 1 151 59
undef 1 151 64
assign 1 152 65
assign 1 154 67
assign 1 155 68
nextNodeGet 0 155 68
firstNodeSet 1 157 74
lastNodeSet 1 158 75
return 1 159 76
nextSet 1 163 80
assign 1 164 81
def 1 164 86
priorSet 1 165 87
nextSet 1 166 88
assign 1 167 89
assign 1 169 92
assign 1 170 93
nextSet 1 175 99
assign 1 176 100
def 1 176 105
nextSet 1 177 106
priorSet 1 178 107
assign 1 179 108
assign 1 181 111
assign 1 182 112
delete 0 187 117
insertBefore 1 191 121
assign 1 195 134
new 0 195 134
assign 1 195 135
equals 1 195 140
assign 1 196 141
heldGet 0 196 141
return 1 196 142
assign 1 198 144
new 0 198 144
assign 1 199 145
linkedListIteratorGet 0 199 145
assign 1 199 148
hasNextGet 0 199 148
assign 1 200 150
lesser 1 200 155
nextGet 0 201 156
incrementValue 0 205 161
assign 1 207 167
notEquals 1 207 172
return 1 208 173
assign 1 210 175
nextGet 0 210 175
return 1 210 176
assign 1 214 187
new 0 214 187
assign 1 214 188
add 1 214 188
assign 1 215 189
new 0 215 189
assign 1 216 190
linkedListIteratorGet 0 216 190
assign 1 216 193
hasNextGet 0 216 193
assign 1 217 195
lesser 1 217 200
nextGet 0 218 201
incrementValue 0 222 206
assign 1 224 212
notEquals 1 224 217
assign 1 225 218
new 0 225 218
return 1 225 219
assign 1 227 221
currentSet 1 227 221
return 1 227 222
assign 1 231 227
undef 1 231 232
return 1 231 233
assign 1 232 235
heldGet 0 232 235
return 1 232 236
assign 1 236 245
def 1 236 250
assign 1 236 251
nextGet 0 236 251
assign 1 236 252
def 1 236 257
assign 1 0 258
assign 1 0 261
assign 1 0 265
assign 1 237 268
nextGet 0 237 268
assign 1 237 269
heldGet 0 237 269
return 1 237 270
return 1 239 272
assign 1 243 286
def 1 243 291
assign 1 243 292
nextGet 0 243 292
assign 1 243 293
def 1 243 298
assign 1 0 299
assign 1 0 302
assign 1 0 306
assign 1 243 309
nextGet 0 243 309
assign 1 243 310
nextGet 0 243 310
assign 1 243 311
def 1 243 316
assign 1 0 317
assign 1 0 320
assign 1 0 324
assign 1 244 327
nextGet 0 244 327
assign 1 244 328
nextGet 0 244 328
assign 1 244 329
heldGet 0 244 329
return 1 244 330
return 1 246 332
assign 1 250 337
undef 1 250 342
return 1 250 343
assign 1 251 345
heldGet 0 251 345
return 1 251 346
assign 1 255 357
new 0 255 357
assign 1 255 358
equals 1 255 358
return 1 256 360
assign 1 258 362
new 0 258 362
assign 1 259 363
linkedListIteratorGet 0 259 363
assign 1 259 366
hasNextGet 0 259 366
assign 1 260 368
lesser 1 260 368
nextGet 0 261 370
incrementValue 0 265 375
assign 1 267 381
notEquals 1 267 381
return 1 268 383
assign 1 270 385
nextNodeGet 0 270 385
return 1 270 386
assign 1 274 390
newNode 1 274 390
appendNode 1 275 391
assign 1 279 398
def 1 279 403
assign 1 279 404
sameType 1 279 404
assign 1 0 406
assign 1 0 409
assign 1 0 413
addAll 1 280 416
addValueWhole 1 282 419
assign 1 287 427
def 1 287 432
assign 1 288 435
hasNextGet 0 288 435
assign 1 289 437
nextGet 0 289 437
addValueWhole 1 289 438
assign 1 295 450
def 1 295 455
assign 1 296 456
iteratorGet 0 296 456
iterateAdd 1 296 457
assign 1 301 463
newNode 1 301 463
prependNode 1 302 464
assign 1 306 471
new 0 306 471
assign 1 307 472
linkedListIteratorGet 0 307 472
assign 1 307 475
hasNextGet 0 307 475
nextGet 0 308 477
incrementValue 0 309 478
return 1 311 484
assign 1 315 488
lengthGet 0 315 488
return 1 315 489
assign 1 319 495
undef 1 319 500
assign 1 320 501
new 0 320 501
return 1 320 502
assign 1 322 504
new 0 322 504
return 1 322 505
assign 1 326 515
lengthGet 0 326 515
assign 1 327 516
new 1 327 516
assign 1 328 517
new 0 328 517
assign 1 329 518
linkedListIteratorGet 0 329 518
assign 1 329 521
hasNextGet 0 329 521
assign 1 330 523
lesser 1 330 528
assign 1 331 529
nextNodeGet 0 331 529
put 2 331 530
incrementValue 0 333 532
return 1 335 538
assign 1 339 549
lengthGet 0 339 549
assign 1 340 550
new 1 340 550
assign 1 341 551
new 0 341 551
assign 1 342 552
linkedListIteratorGet 0 342 552
assign 1 342 555
hasNextGet 0 342 555
assign 1 343 557
lesser 1 343 562
assign 1 344 563
nextNodeGet 0 344 563
assign 1 344 564
heldGet 0 344 564
put 2 344 565
incrementValue 0 346 567
return 1 348 573
assign 1 352 577
new 1 352 577
return 1 352 578
assign 1 356 582
new 1 356 582
return 1 356 583
assign 1 360 587
iteratorGet 0 360 587
return 1 360 588
assign 1 364 594
new 0 364 594
assign 1 364 595
maxGet 0 364 595
assign 1 364 596
subList 2 364 596
return 1 364 597
assign 1 368 609
create 0 368 609
assign 1 369 610
lesserEquals 1 369 615
return 1 370 616
assign 1 372 618
linkedListIteratorGet 0 372 618
assign 1 373 619
new 0 373 619
assign 1 373 622
lesser 1 373 627
assign 1 374 628
hasNextGet 0 374 628
assign 1 374 629
not 0 374 629
return 1 375 631
assign 1 377 633
nextGet 0 377 633
assign 1 378 634
greaterEquals 1 378 639
addValue 1 379 640
incrementValue 0 373 642
return 1 382 648
assign 1 420 656
assign 1 421 657
assign 1 422 660
def 1 422 665
assign 1 423 666
nextGet 0 423 666
assign 1 424 667
priorGet 0 424 667
nextSet 1 424 668
priorSet 1 425 669
assign 1 426 670
assign 1 427 671
assign 1 429 677
return 1 0 681
assign 1 0 684
return 1 0 688
assign 1 0 691
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 390409747: return bem_reverse_0();
case -1104287156: return bem_toNodeList_0();
case 1696089045: return bem_firstNodeGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1616433729: return bem_lengthGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -183400265: return bem_firstGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -1987444950: return bem_toList_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -978128800: return bem_thirdGet_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1820417453: return bem_create_0();
case 1990707345: return bem_lastGet_0();
case -1351154001: return bem_lastNodeGet_0();
case -786424307: return bem_tagGet_0();
case 242848115: return bem_secondGet_0();
case -1354714650: return bem_copy_0();
case -874473310: return bem_linkedListIteratorGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -228068295: return bem_addValueWhole_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -908228929: return bem_deleteNode_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1707171298: return bem_firstNodeSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1263766286: return bem_addAll_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 655844394: return bem_getNode_1(bevd_0);
case -596113616: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -743891212: return bem_newNode_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1167376622: return bem_appendNode_1(bevd_0);
case -1340071748: return bem_lastNodeSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1007846464: return bem_prepend_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1142954398: return bem_prependNode_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 107034370: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -596113615: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1098622227: return bem_insertBeforeNode_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_10_ContainerLinkedList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_10_ContainerLinkedList.bevs_inst = (BEC_2_9_10_ContainerLinkedList)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_10_ContainerLinkedList.bevs_inst;
}
}
}
