namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_6_IOReader : BEC_2_6_6_SystemObject {
public BEC_2_2_6_IOReader() { }
static BEC_2_2_6_IOReader() { }

    public System.IO.Stream bevi_is;
    
   private static byte[] becc_BEC_2_2_6_IOReader_clname = {0x49,0x4F,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_6_IOReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_2 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_3 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_5 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_8 = (new BEC_2_4_3_MathInt(0));
public static new BEC_2_2_6_IOReader bece_BEC_2_2_6_IOReader_bevs_inst;
public BEC_2_6_6_SystemObject bevp_vfile;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_4_3_MathInt bevp_blockSize;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_blockSize = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(256));
return this;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_extOpen_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_close_0() {

      if (this.bevi_is != null) {
        this.bevi_is.Dispose();
        this.bevi_is = null;
      }
      bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_vfileGet_0() {
return this;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_vfileSet_1(BEC_2_6_6_SystemObject beva_vfile) {
return this;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_byteReaderGet_0() {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_2_10_IOByteReader) (new BEC_2_2_10_IOByteReader()).bem_readerNew_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_byteReader_1(BEC_2_4_3_MathInt beva_blockSize) {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_2_10_IOByteReader) (new BEC_2_2_10_IOByteReader()).bem_readerBlockNew_2(this, beva_blockSize);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_readIntoBuffer_1(BEC_2_4_6_TextString beva_readBuf) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_0;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_readIntoBuffer_2(beva_readBuf, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_readIntoBuffer_2(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = this.bem_readIntoBuffer_3(beva_readBuf, beva_at, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_readIntoBuffer_3(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at, BEC_2_4_3_MathInt beva_readsz) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;

      beva_readsz.bevi_int = this.bevi_is.Read(beva_readBuf.bevi_bytes, beva_at.bevi_int, beva_readBuf.bevi_bytes.Length - beva_at.bevi_int) + beva_at.bevi_int;
      bevt_0_tmpany_phold = beva_readBuf.bem_sizeGet_0();
bevt_0_tmpany_phold.bevi_int = beva_readsz.bevi_int;
return beva_readsz;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_copyData_3(BEC_2_2_6_IOWriter beva_outw, BEC_2_4_6_TextString beva_rwbufE, BEC_2_4_3_MathInt beva_rsz) {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_at = bece_BEC_2_2_6_IOReader_bevo_1;
while (true)
 /* Line: 266 */ {
bevt_1_tmpany_phold = this.bem_readIntoBuffer_3(beva_rwbufE, bevl_at, beva_rsz);
bevt_2_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_2;
if (bevt_1_tmpany_phold.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 266 */ {
beva_outw.bem_write_1(beva_rwbufE);
} /* Line: 267 */
 else  /* Line: 266 */ {
break;
} /* Line: 266 */
} /* Line: 266 */
return this;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_copyData_1(BEC_2_2_6_IOWriter beva_outw) {
BEC_2_4_6_TextString bevl_rwbufE = null;
BEC_2_4_3_MathInt bevl_rsz = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevl_rwbufE = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_rsz = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
this.bem_copyData_3(beva_outw, bevl_rwbufE, bevl_rsz);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBuffer_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevp_blockSize);
bevt_0_tmpany_phold = this.bem_readBuffer_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBuffer_1(BEC_2_4_6_TextString beva_builder) {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_4_3_MathInt bevl_nowAt = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
bevl_at = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nowAt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
this.bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
while (true)
 /* Line: 285 */ {
if (bevl_nowAt.bevi_int > bevl_at.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevl_at.bevi_int = bevl_nowAt.bevi_int;
bevt_3_tmpany_phold = beva_builder.bem_capacityGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_subtract_1(bevl_at);
bevt_4_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_3;
if (bevt_2_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 287 */ {
bevt_7_tmpany_phold = bevl_at.bem_add_1(bevp_blockSize);
bevt_8_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_4;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_5;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_multiply_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_6;
bevl_nsize = bevt_5_tmpany_phold.bem_divide_1(bevt_10_tmpany_phold);
beva_builder.bem_capacitySet_1(bevl_nsize);
} /* Line: 289 */
this.bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
} /* Line: 291 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
return beva_builder;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBufferLine_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = this.bem_readBufferLine_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBufferLine_1(BEC_2_4_6_TextString beva_builder) {
BEC_2_4_6_TextString bevl_crb = null;
BEC_2_4_6_TextString bevl_rbuf = null;
BEC_2_4_3_MathInt bevl_got = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_newlineGet_0();
bevl_crb = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bem_addValue_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_rbuf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_3_tmpany_phold);
bevl_got = this.bem_readIntoBuffer_1(bevl_rbuf);
bevt_5_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_7;
if (bevl_got.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 307 */ {
beva_builder = null;
return beva_builder;
} /* Line: 309 */
beva_builder.bem_addValue_1(bevl_rbuf);
while (true)
 /* Line: 312 */ {
bevt_7_tmpany_phold = bece_BEC_2_2_6_IOReader_bevo_8;
if (bevl_got.bevi_int != bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_8_tmpany_phold = bevl_rbuf.bem_equals_1(bevl_crb);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 313 */ {
return beva_builder;
} /* Line: 314 */
bevl_got = this.bem_readIntoBuffer_1(bevl_rbuf);
beva_builder.bem_addValue_1(bevl_rbuf);
} /* Line: 317 */
 else  /* Line: 312 */ {
break;
} /* Line: 312 */
} /* Line: 312 */
return beva_builder;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_readBuffer_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readString_1(BEC_2_4_6_TextString beva_builder) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_readBuffer_1(beva_builder);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readStringClose_0() {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = this.bem_readString_0();
this.bem_close_0();
return bevl_res;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isClosedGet_0() {
return bevp_isClosed;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_blockSizeGet_0() {
return bevp_blockSize;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_blockSizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_blockSize = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {161, 162, 168, 204, 212, 212, 216, 216, 220, 220, 220, 220, 224, 224, 224, 260, 260, 261, 265, 266, 266, 266, 266, 267, 272, 272, 273, 274, 278, 278, 278, 282, 283, 284, 285, 285, 286, 287, 287, 287, 287, 287, 288, 288, 288, 288, 288, 288, 288, 289, 291, 293, 297, 297, 297, 304, 304, 304, 304, 305, 305, 306, 307, 307, 307, 308, 309, 311, 312, 312, 312, 313, 314, 316, 317, 319, 323, 323, 327, 327, 331, 332, 333, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {28, 29, 33, 42, 53, 54, 58, 59, 65, 66, 67, 68, 73, 74, 75, 81, 82, 83, 90, 93, 94, 95, 100, 101, 113, 114, 115, 116, 122, 123, 124, 141, 142, 143, 146, 151, 152, 153, 154, 155, 156, 161, 162, 163, 164, 165, 166, 167, 168, 169, 171, 177, 182, 183, 184, 199, 200, 201, 202, 203, 204, 205, 206, 207, 212, 213, 214, 216, 219, 220, 225, 226, 228, 230, 231, 237, 241, 242, 246, 247, 251, 252, 253, 256, 259, 263, 266};
/* BEGIN LINEINFO 
assign 1 161 28
new 0 161 28
assign 1 162 29
new 0 162 29
assign 1 168 33
new 0 168 33
assign 1 204 42
new 0 204 42
assign 1 212 53
readerNew 1 212 53
return 1 212 54
assign 1 216 58
readerBlockNew 2 216 58
return 1 216 59
assign 1 220 65
new 0 220 65
assign 1 220 66
once 0 220 66
assign 1 220 67
readIntoBuffer 2 220 67
return 1 220 68
assign 1 224 73
new 0 224 73
assign 1 224 74
readIntoBuffer 3 224 74
return 1 224 75
assign 1 260 81
sizeGet 0 260 81
setValue 1 260 82
return 1 261 83
assign 1 265 90
new 0 265 90
assign 1 266 93
readIntoBuffer 3 266 93
assign 1 266 94
new 0 266 94
assign 1 266 95
greater 1 266 100
write 1 267 101
assign 1 272 113
new 0 272 113
assign 1 272 114
new 1 272 114
assign 1 273 115
new 0 273 115
copyData 3 274 116
assign 1 278 122
new 1 278 122
assign 1 278 123
readBuffer 1 278 123
return 1 278 124
assign 1 282 141
new 0 282 141
assign 1 283 142
new 0 283 142
readIntoBuffer 3 284 143
assign 1 285 146
greater 1 285 151
setValue 1 286 152
assign 1 287 153
capacityGet 0 287 153
assign 1 287 154
subtract 1 287 154
assign 1 287 155
new 0 287 155
assign 1 287 156
lesser 1 287 161
assign 1 288 162
add 1 288 162
assign 1 288 163
new 0 288 163
assign 1 288 164
add 1 288 164
assign 1 288 165
new 0 288 165
assign 1 288 166
multiply 1 288 166
assign 1 288 167
new 0 288 167
assign 1 288 168
divide 1 288 168
capacitySet 1 289 169
readIntoBuffer 3 291 171
return 1 293 177
assign 1 297 182
new 0 297 182
assign 1 297 183
readBufferLine 1 297 183
return 1 297 184
assign 1 304 199
new 0 304 199
assign 1 304 200
new 0 304 200
assign 1 304 201
newlineGet 0 304 201
assign 1 304 202
addValue 1 304 202
assign 1 305 203
new 0 305 203
assign 1 305 204
new 1 305 204
assign 1 306 205
readIntoBuffer 1 306 205
assign 1 307 206
new 0 307 206
assign 1 307 207
equals 1 307 212
assign 1 308 213
return 1 309 214
addValue 1 311 216
assign 1 312 219
new 0 312 219
assign 1 312 220
notEquals 1 312 225
assign 1 313 226
equals 1 313 226
return 1 314 228
assign 1 316 230
readIntoBuffer 1 316 230
addValue 1 317 231
return 1 319 237
assign 1 323 241
readBuffer 0 323 241
return 1 323 242
assign 1 327 246
readBuffer 1 327 246
return 1 327 247
assign 1 331 251
readString 0 331 251
close 0 332 252
return 1 333 253
return 1 0 256
assign 1 0 259
return 1 0 263
assign 1 0 266
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case -1109612452: return bem_byteReaderGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case 1325881255: return bem_readBuffer_0();
case -1358082055: return bem_blockSizeGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 1242327477: return bem_vfileGet_0();
case 287040793: return bem_hashGet_0();
case 698342331: return bem_readBufferLine_0();
case 1774940957: return bem_toString_0();
case -1714939806: return bem_readStringClose_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case -1240964868: return bem_extOpen_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 866536361: return bem_close_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 347960120: return bem_readString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -792269839: return bem_isClosedGet_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1253409730: return bem_vfileSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1359009615: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1346999802: return bem_blockSizeSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1992292136: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -781187586: return bem_isClosedSet_1(bevd_0);
case 1325881256: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 698342332: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1385004253: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 347960121: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1992292137: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 1992292138: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1359009613: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_2_6_IOReader_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_6_IOReader_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_6_IOReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_inst = (BEC_2_2_6_IOReader) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_inst;
}
}
}
