namespace be {
/* IO:File: source/build/CCEmitter.be */
public sealed class BEC_2_5_9_BuildCCEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
static BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_14, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_15, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x3E,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_26, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_29, 31));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_48, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_49, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_50, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_51, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_52, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_54, 20));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_55, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_56, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_65, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_66, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_67, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_68, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_69, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x66,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_70, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_71, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_74, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_75, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_76, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_77, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_78, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_79, 18));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x3E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_80, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_81, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_83, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_84, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_86, 19));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_87, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_95, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x42,0x45,0x44,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_35 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_96, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_36 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_97, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x42,0x45,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_37 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_98, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_38 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_99, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x3C,0x69,0x6F,0x73,0x74,0x72,0x65,0x61,0x6D,0x3E,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x3C,0x6D,0x65,0x6D,0x6F,0x72,0x79,0x3E,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x75,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x73,0x74,0x64,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x5B,0x5D,0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_122, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_40 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_123, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_41 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_127, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_42 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_128, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x3E,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x7D};
public static new BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = this.bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 31 */
 else  /* Line: 32 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevl_extends = this.bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 33 */
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_7_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevl_begin.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
bevl_begin.bem_addValue_1(bevt_10_tmpany_phold);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevp_heow.bem_write_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevp_heow.bem_write_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(58, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevp_heow.bem_write_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(76, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevp_heow.bem_write_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(62, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevp_heow.bem_write_1(bevt_15_tmpany_phold);
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_0;
bevt_19_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_1;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevp_deow.bem_write_1(bevt_16_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
return bevt_21_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
bevt_8_tmpany_phold = this.bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = this.bem_getClassConfig_1(bevp_objectNp);
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_20_tmpany_phold);
bevt_24_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_22_tmpany_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_23_tmpany_phold );
bevt_25_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_relEmitName_1(bevt_25_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_17_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_28_tmpany_phold);
bevt_27_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_0_tmpany_phold);
return bevl_end;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_2;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_3;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_0_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_17_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevp_classHeadBody.bem_addValue_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_24_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_25_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) bevt_22_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevt_21_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevt_19_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevp_classHeadBody.bem_addValue_1(bevt_28_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_12_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v.bem_isTypedGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = bevp_objectCc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_2_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 113 */
 else  /* Line: 114 */ {
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = beva_v.bem_namepathGet_0();
bevt_12_tmpany_phold = this.bem_getClassConfig_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_relEmitName_1(bevt_14_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
bevt_8_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 115 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formDynCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_targ) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_5;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_targ);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_7;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_1(BEC_2_5_11_BuildClassConfig beva_cc) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_8;
bevt_4_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_3_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_9;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_afterCast_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formStatCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_targ) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_10;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_11;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_targ);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevt_8_tmpany_phold = this.bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(beva_len);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_23_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_13;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_14;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_15;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_16;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_17;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_18;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 152 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_19;
bevt_8_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_20;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_21;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_22;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 153 */
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_23;
bevt_20_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_24;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(beva_lisz);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_25;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_belsName);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_26;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
return bevt_12_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_27;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_28;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_29;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 168 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_30;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_31;
bevt_1_tmpany_phold = beva_typeName.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_32;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_33;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
return bevt_18_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_34;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_19_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_36_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_47_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
if (bevp_deow == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_35;
bevt_7_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_36;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevl_libName);
bevp_deon = bevt_3_tmpany_phold.bem_add_1(bevp_headExt);
bevt_12_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_37;
bevt_13_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_38;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_libName);
bevp_heon = bevt_9_tmpany_phold.bem_add_1(bevp_headExt);
bevt_15_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_15_tmpany_phold.bem_addStep_1(bevp_deon);
bevt_16_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_16_tmpany_phold.bem_addStep_1(bevp_heon);
bevt_20_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_fileGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_existsGet_0();
if (bevt_18_tmpany_phold.bevi_bool) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevt_22_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_fileGet_0();
bevt_21_tmpany_phold.bem_makeDirs_0();
} /* Line: 224 */
bevt_24_tmpany_phold = bevp_deop.bem_fileGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_23_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_26_tmpany_phold = bevp_heop.bem_fileGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_25_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevp_heow.bem_write_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevp_heow.bem_write_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevp_heow.bem_write_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevp_heow.bem_write_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevp_deow.bem_write_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevp_heow.bem_write_1(bevt_32_tmpany_phold);
bevt_34_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_has_1(bevt_35_tmpany_phold);
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 241 */ {
bevt_37_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_get_1(bevt_38_tmpany_phold);
bevt_0_tmpany_loop = bevt_36_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 243 */ {
bevt_39_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_39_tmpany_phold != null && bevt_39_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_39_tmpany_phold).bevi_bool) /* Line: 243 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_40_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_40_tmpany_phold.bem_fileGet_0();
bevt_42_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_2_4_6_TextString) bevt_41_tmpany_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_43_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_43_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 249 */
 else  /* Line: 243 */ {
break;
} /* Line: 243 */
} /* Line: 243 */
} /* Line: 243 */
bevt_45_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_has_1(bevt_46_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 252 */ {
bevt_48_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_get_1(bevt_49_tmpany_phold);
bevt_1_tmpany_loop = bevt_47_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 254 */ {
bevt_50_tmpany_phold = bevt_1_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_50_tmpany_phold != null && bevt_50_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_50_tmpany_phold).bevi_bool) /* Line: 254 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_51_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_51_tmpany_phold.bem_fileGet_0();
bevt_53_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_54_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_54_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 260 */
 else  /* Line: 254 */ {
break;
} /* Line: 254 */
} /* Line: 254 */
} /* Line: 254 */
} /* Line: 252 */
return this;
} /*method end*/
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
this.bem_prepHeaderOutput_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_14_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 273 */ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 275 */ {
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 276 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevp_shlibe.bem_write_1(bevt_10_tmpany_phold);
bevp_lineCount.bem_increment_0();
bevt_12_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_has_1(bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevt_15_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_get_1(bevt_16_tmpany_phold);
bevt_0_tmpany_loop = bevt_14_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 283 */ {
bevt_17_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_17_tmpany_phold != null && bevt_17_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 283 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_18_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_18_tmpany_phold.bem_fileGet_0();
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_21_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_21_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevt_22_tmpany_phold = this.bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_22_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 288 */
 else  /* Line: 283 */ {
break;
} /* Line: 283 */
} /* Line: 283 */
} /* Line: 283 */
} /* Line: 282 */
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
beva_libe.bem_write_1(bevt_0_tmpany_phold);
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevp_deow.bem_write_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevp_heow.bem_write_1(bevt_2_tmpany_phold);
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_0_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 327 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 327 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_first.bevi_bool) /* Line: 328 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 329 */
 else  /* Line: 330 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 331 */
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 333 */
 else  /* Line: 327 */ {
break;
} /* Line: 327 */
} /* Line: 327 */
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_39;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_40;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_4_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_41;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_42;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevl_bein;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_5_11_BuildClassConfig bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_getClassConfig_1(bevp_objectNp);
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_0_tmpany_phold.bem_relEmitName_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_2_tmpany_phold );
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_12_tmpany_phold = this.bem_overrideMtdDecGet_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_asnr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_19_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 364 */ {
bevl_asnr = this.bem_formStatCast_2(bevp_classConf, bevl_asnr);
} /* Line: 365 */
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevt_23_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) bevt_22_tmpany_phold.bem_addValue_1(bevl_asnr);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevt_21_tmpany_phold.bem_addValue_1(bevt_25_tmpany_phold);
bevt_20_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_27_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_36_tmpany_phold = this.bem_overrideMtdDecGet_0();
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) bevt_35_tmpany_phold.bem_addValue_1(bevt_37_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) bevt_34_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) bevt_31_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) bevt_30_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) bevt_29_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_28_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_45_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) bevt_44_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) bevt_43_tmpany_phold.bem_addValue_1(bevt_46_tmpany_phold);
bevt_42_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_48_tmpany_phold);
bevt_47_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 20, 22, 23, 26, 30, 30, 31, 31, 31, 33, 33, 35, 35, 35, 35, 35, 35, 37, 37, 39, 39, 41, 43, 45, 47, 49, 49, 50, 50, 51, 51, 52, 52, 53, 53, 55, 55, 55, 55, 55, 55, 57, 57, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 64, 64, 64, 68, 70, 70, 71, 75, 75, 75, 76, 77, 77, 77, 77, 77, 77, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 84, 84, 88, 88, 92, 92, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 99, 101, 101, 101, 101, 101, 101, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 105, 107, 107, 112, 112, 112, 113, 113, 113, 113, 113, 113, 113, 115, 115, 115, 115, 115, 115, 115, 115, 115, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 124, 124, 124, 124, 124, 124, 124, 129, 129, 133, 133, 133, 133, 133, 133, 133, 133, 133, 133, 137, 137, 137, 137, 137, 137, 137, 137, 137, 137, 137, 137, 137, 137, 137, 138, 138, 138, 138, 138, 138, 138, 138, 138, 140, 140, 140, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 144, 148, 148, 148, 148, 148, 148, 148, 148, 148, 148, 148, 148, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 155, 155, 155, 155, 155, 155, 155, 155, 155, 155, 155, 155, 155, 159, 159, 159, 159, 159, 164, 165, 166, 166, 167, 167, 168, 168, 170, 170, 170, 171, 177, 177, 177, 177, 181, 181, 185, 185, 185, 185, 185, 186, 186, 186, 186, 186, 186, 187, 187, 187, 188, 188, 188, 188, 188, 188, 188, 188, 190, 190, 194, 194, 198, 198, 198, 198, 202, 202, 217, 217, 218, 219, 219, 219, 219, 219, 219, 219, 220, 220, 220, 220, 220, 220, 220, 221, 221, 222, 222, 223, 223, 223, 223, 223, 224, 224, 224, 226, 226, 226, 227, 227, 227, 229, 229, 230, 230, 231, 231, 232, 232, 234, 234, 235, 235, 241, 241, 241, 243, 243, 243, 243, 0, 243, 243, 245, 245, 246, 246, 246, 247, 247, 249, 252, 252, 252, 254, 254, 254, 254, 0, 254, 254, 256, 256, 257, 257, 257, 258, 258, 260, 267, 268, 273, 273, 274, 275, 275, 275, 275, 275, 276, 276, 276, 278, 278, 278, 280, 280, 281, 282, 282, 282, 283, 283, 283, 283, 0, 283, 283, 284, 284, 285, 285, 285, 286, 286, 287, 287, 288, 294, 299, 299, 300, 301, 303, 303, 305, 305, 306, 307, 312, 312, 316, 316, 316, 316, 316, 321, 321, 322, 324, 324, 324, 324, 326, 327, 0, 327, 327, 329, 331, 331, 333, 333, 333, 333, 333, 333, 337, 337, 337, 342, 344, 344, 344, 344, 344, 346, 346, 346, 346, 346, 346, 346, 346, 346, 348, 352, 352, 353, 353, 353, 353, 354, 358, 358, 358, 359, 359, 359, 360, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 362, 363, 364, 364, 365, 368, 368, 368, 368, 368, 368, 368, 370, 370, 370, 373, 373, 373, 373, 373, 373, 373, 373, 373, 373, 373, 373, 373, 373, 373, 375, 375, 375, 375, 375, 375, 377, 377, 377, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {206, 207, 208, 209, 210, 211, 239, 244, 245, 246, 247, 250, 251, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 353, 354, 355, 356, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 400, 401, 405, 406, 410, 411, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 497, 498, 503, 504, 505, 506, 507, 508, 509, 510, 513, 514, 515, 516, 517, 518, 519, 520, 521, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 553, 554, 555, 556, 557, 558, 559, 563, 564, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 750, 751, 752, 753, 754, 764, 765, 766, 767, 769, 770, 771, 772, 774, 775, 776, 777, 784, 785, 786, 787, 791, 792, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 842, 843, 849, 850, 851, 852, 856, 857, 922, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 955, 956, 957, 958, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 978, 979, 980, 982, 983, 984, 985, 985, 988, 990, 991, 992, 993, 994, 995, 996, 997, 998, 1005, 1006, 1007, 1009, 1010, 1011, 1012, 1012, 1015, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1036, 1037, 1067, 1072, 1073, 1074, 1075, 1076, 1077, 1082, 1083, 1084, 1085, 1087, 1088, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1097, 1098, 1099, 1100, 1100, 1103, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1115, 1123, 1129, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 1143, 1144, 1151, 1152, 1153, 1154, 1155, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1185, 1188, 1190, 1192, 1195, 1196, 1198, 1199, 1200, 1201, 1202, 1203, 1209, 1210, 1211, 1229, 1230, 1231, 1232, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1243, 1244, 1253, 1254, 1255, 1256, 1257, 1258, 1259, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1339, 1341, 1343, 1344, 1345, 1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375, 1376, 1380, 1383, 1387, 1390, 1394, 1397, 1401, 1404, 1408, 1411, 1415, 1418, 1422, 1425, 1429, 1432, 1436, 1439};
/* BEGIN LINEINFO 
assign 1 18 206
new 0 18 206
assign 1 19 207
new 0 19 207
assign 1 20 208
new 0 20 208
assign 1 22 209
new 0 22 209
assign 1 23 210
new 0 23 210
new 1 26 211
assign 1 30 239
def 1 30 244
assign 1 31 245
libNameGet 0 31 245
assign 1 31 246
relEmitName 1 31 246
assign 1 31 247
extend 1 31 247
assign 1 33 250
new 0 33 250
assign 1 33 251
extend 1 33 251
assign 1 35 253
new 0 35 253
assign 1 35 254
emitNameGet 0 35 254
assign 1 35 255
addValue 1 35 255
assign 1 35 256
addValue 1 35 256
assign 1 35 257
new 0 35 257
assign 1 35 258
addValue 1 35 258
assign 1 37 259
new 0 37 259
addValue 1 37 260
assign 1 39 261
new 0 39 261
addValue 1 39 262
write 1 41 263
write 1 43 264
write 1 45 265
clear 0 47 266
assign 1 49 267
new 0 49 267
write 1 49 268
assign 1 50 269
new 0 50 269
write 1 50 270
assign 1 51 271
new 0 51 271
write 1 51 272
assign 1 52 273
new 0 52 273
write 1 52 274
assign 1 53 275
new 0 53 275
write 1 53 276
assign 1 55 277
new 0 55 277
assign 1 55 278
emitNameGet 0 55 278
assign 1 55 279
add 1 55 279
assign 1 55 280
new 0 55 280
assign 1 55 281
add 1 55 281
write 1 55 282
assign 1 57 283
new 0 57 283
return 1 57 284
assign 1 61 316
overrideMtdDecGet 0 61 316
assign 1 61 317
addValue 1 61 317
assign 1 61 318
new 0 61 318
assign 1 61 319
addValue 1 61 319
assign 1 61 320
getClassConfig 1 61 320
assign 1 61 321
libNameGet 0 61 321
assign 1 61 322
relEmitName 1 61 322
assign 1 61 323
addValue 1 61 323
assign 1 61 324
new 0 61 324
assign 1 61 325
addValue 1 61 325
assign 1 61 326
emitNameGet 0 61 326
assign 1 61 327
addValue 1 61 327
assign 1 61 328
new 0 61 328
assign 1 61 329
addValue 1 61 329
assign 1 61 330
addValue 1 61 330
assign 1 61 331
new 0 61 331
assign 1 61 332
addValue 1 61 332
addValue 1 61 333
assign 1 62 334
new 0 62 334
assign 1 62 335
addValue 1 62 335
assign 1 62 336
heldGet 0 62 336
assign 1 62 337
namepathGet 0 62 337
assign 1 62 338
getClassConfig 1 62 338
assign 1 62 339
libNameGet 0 62 339
assign 1 62 340
relEmitName 1 62 340
assign 1 62 341
addValue 1 62 341
assign 1 62 342
new 0 62 342
assign 1 62 343
addValue 1 62 343
addValue 1 62 344
assign 1 64 345
new 0 64 345
assign 1 64 346
addValue 1 64 346
addValue 1 64 347
assign 1 68 353
new 0 68 353
assign 1 70 354
new 0 70 354
write 1 70 355
return 1 71 356
assign 1 75 376
new 0 75 376
assign 1 75 377
toString 0 75 377
assign 1 75 378
add 1 75 378
incrementValue 0 76 379
assign 1 77 380
new 0 77 380
assign 1 77 381
addValue 1 77 381
assign 1 77 382
addValue 1 77 382
assign 1 77 383
new 0 77 383
assign 1 77 384
addValue 1 77 384
addValue 1 77 385
assign 1 79 386
containedGet 0 79 386
assign 1 79 387
firstGet 0 79 387
assign 1 79 388
containedGet 0 79 388
assign 1 79 389
firstGet 0 79 389
assign 1 79 390
new 0 79 390
assign 1 79 391
add 1 79 391
assign 1 79 392
new 0 79 392
assign 1 79 393
add 1 79 393
assign 1 79 394
finalAssign 3 79 394
addValue 1 79 395
assign 1 84 400
new 0 84 400
return 1 84 401
assign 1 88 405
new 0 88 405
return 1 88 406
assign 1 92 410
new 0 92 410
return 1 92 411
assign 1 97 443
addValue 1 97 443
assign 1 97 444
new 0 97 444
assign 1 97 445
addValue 1 97 445
assign 1 97 446
libNameGet 0 97 446
assign 1 97 447
relEmitName 1 97 447
assign 1 97 448
addValue 1 97 448
assign 1 97 449
new 0 97 449
assign 1 97 450
addValue 1 97 450
assign 1 97 451
emitNameGet 0 97 451
assign 1 97 452
addValue 1 97 452
assign 1 97 453
new 0 97 453
assign 1 97 454
addValue 1 97 454
assign 1 97 455
addValue 1 97 455
assign 1 97 456
new 0 97 456
addValue 1 97 457
addValue 1 99 458
assign 1 101 459
new 0 101 459
assign 1 101 460
addValue 1 101 460
assign 1 101 461
addValue 1 101 461
assign 1 101 462
new 0 101 462
assign 1 101 463
addValue 1 101 463
addValue 1 101 464
assign 1 103 465
new 0 103 465
assign 1 103 466
addValue 1 103 466
assign 1 103 467
libNameGet 0 103 467
assign 1 103 468
relEmitName 1 103 468
assign 1 103 469
addValue 1 103 469
assign 1 103 470
new 0 103 470
assign 1 103 471
addValue 1 103 471
assign 1 103 472
addValue 1 103 472
assign 1 103 473
new 0 103 473
addValue 1 103 474
addValue 1 105 475
assign 1 107 476
new 0 107 476
addValue 1 107 477
assign 1 112 497
isTypedGet 0 112 497
assign 1 112 498
not 0 112 503
assign 1 113 504
new 0 113 504
assign 1 113 505
addValue 1 113 505
assign 1 113 506
libNameGet 0 113 506
assign 1 113 507
relEmitName 1 113 507
assign 1 113 508
addValue 1 113 508
assign 1 113 509
new 0 113 509
addValue 1 113 510
assign 1 115 513
new 0 115 513
assign 1 115 514
addValue 1 115 514
assign 1 115 515
namepathGet 0 115 515
assign 1 115 516
getClassConfig 1 115 516
assign 1 115 517
libNameGet 0 115 517
assign 1 115 518
relEmitName 1 115 518
assign 1 115 519
addValue 1 115 519
assign 1 115 520
new 0 115 520
addValue 1 115 521
assign 1 120 535
new 0 120 535
assign 1 120 536
libNameGet 0 120 536
assign 1 120 537
relEmitName 1 120 537
assign 1 120 538
add 1 120 538
assign 1 120 539
new 0 120 539
assign 1 120 540
add 1 120 540
assign 1 120 541
add 1 120 541
assign 1 120 542
new 0 120 542
assign 1 120 543
add 1 120 543
return 1 120 544
assign 1 124 553
new 0 124 553
assign 1 124 554
libNameGet 0 124 554
assign 1 124 555
relEmitName 1 124 555
assign 1 124 556
add 1 124 556
assign 1 124 557
new 0 124 557
assign 1 124 558
add 1 124 558
return 1 124 559
assign 1 129 563
new 0 129 563
return 1 129 564
assign 1 133 576
new 0 133 576
assign 1 133 577
libNameGet 0 133 577
assign 1 133 578
relEmitName 1 133 578
assign 1 133 579
add 1 133 579
assign 1 133 580
new 0 133 580
assign 1 133 581
add 1 133 581
assign 1 133 582
add 1 133 582
assign 1 133 583
new 0 133 583
assign 1 133 584
add 1 133 584
return 1 133 585
assign 1 137 612
overrideMtdDecGet 0 137 612
assign 1 137 613
addValue 1 137 613
assign 1 137 614
new 0 137 614
assign 1 137 615
addValue 1 137 615
assign 1 137 616
emitNameGet 0 137 616
assign 1 137 617
addValue 1 137 617
assign 1 137 618
new 0 137 618
assign 1 137 619
addValue 1 137 619
assign 1 137 620
addValue 1 137 620
assign 1 137 621
new 0 137 621
assign 1 137 622
addValue 1 137 622
assign 1 137 623
addValue 1 137 623
assign 1 137 624
new 0 137 624
assign 1 137 625
addValue 1 137 625
addValue 1 137 626
assign 1 138 627
new 0 138 627
assign 1 138 628
addValue 1 138 628
assign 1 138 629
addValue 1 138 629
assign 1 138 630
new 0 138 630
assign 1 138 631
addValue 1 138 631
assign 1 138 632
addValue 1 138 632
assign 1 138 633
new 0 138 633
assign 1 138 634
addValue 1 138 634
addValue 1 138 635
assign 1 140 636
new 0 140 636
assign 1 140 637
addValue 1 140 637
addValue 1 140 638
assign 1 144 653
new 0 144 653
assign 1 144 654
libNameGet 0 144 654
assign 1 144 655
relEmitName 1 144 655
assign 1 144 656
add 1 144 656
assign 1 144 657
new 0 144 657
assign 1 144 658
add 1 144 658
assign 1 144 659
heldGet 0 144 659
assign 1 144 660
literalValueGet 0 144 660
assign 1 144 661
add 1 144 661
assign 1 144 662
new 0 144 662
assign 1 144 663
add 1 144 663
return 1 144 664
assign 1 148 678
new 0 148 678
assign 1 148 679
libNameGet 0 148 679
assign 1 148 680
relEmitName 1 148 680
assign 1 148 681
add 1 148 681
assign 1 148 682
new 0 148 682
assign 1 148 683
add 1 148 683
assign 1 148 684
heldGet 0 148 684
assign 1 148 685
literalValueGet 0 148 685
assign 1 148 686
add 1 148 686
assign 1 148 687
new 0 148 687
assign 1 148 688
add 1 148 688
return 1 148 689
assign 1 153 717
new 0 153 717
assign 1 153 718
libNameGet 0 153 718
assign 1 153 719
relEmitName 1 153 719
assign 1 153 720
add 1 153 720
assign 1 153 721
new 0 153 721
assign 1 153 722
add 1 153 722
assign 1 153 723
add 1 153 723
assign 1 153 724
new 0 153 724
assign 1 153 725
add 1 153 725
assign 1 153 726
add 1 153 726
assign 1 153 727
new 0 153 727
assign 1 153 728
add 1 153 728
return 1 153 729
assign 1 155 731
new 0 155 731
assign 1 155 732
libNameGet 0 155 732
assign 1 155 733
relEmitName 1 155 733
assign 1 155 734
add 1 155 734
assign 1 155 735
new 0 155 735
assign 1 155 736
add 1 155 736
assign 1 155 737
add 1 155 737
assign 1 155 738
new 0 155 738
assign 1 155 739
add 1 155 739
assign 1 155 740
add 1 155 740
assign 1 155 741
new 0 155 741
assign 1 155 742
add 1 155 742
return 1 155 743
assign 1 159 750
new 0 159 750
assign 1 159 751
add 1 159 751
assign 1 159 752
new 0 159 752
assign 1 159 753
add 1 159 753
return 1 159 754
getInt 2 164 764
assign 1 165 765
toHexString 1 165 765
assign 1 166 766
new 0 166 766
assign 1 166 767
begins 1 166 767
assign 1 167 769
new 0 167 769
assign 1 167 770
substring 1 167 770
assign 1 168 771
new 0 168 771
addValue 1 168 772
assign 1 170 774
new 0 170 774
assign 1 170 775
once 0 170 775
addValue 1 170 776
addValue 1 171 777
assign 1 177 784
new 0 177 784
assign 1 177 785
add 1 177 785
assign 1 177 786
add 1 177 786
return 1 177 787
assign 1 181 791
new 0 181 791
return 1 181 792
assign 1 185 815
new 0 185 815
assign 1 185 816
add 1 185 816
assign 1 185 817
new 0 185 817
assign 1 185 818
add 1 185 818
assign 1 185 819
add 1 185 819
assign 1 186 820
new 0 186 820
assign 1 186 821
addValue 1 186 821
assign 1 186 822
addValue 1 186 822
assign 1 186 823
new 0 186 823
assign 1 186 824
addValue 1 186 824
addValue 1 186 825
assign 1 187 826
new 0 187 826
assign 1 187 827
addValue 1 187 827
addValue 1 187 828
assign 1 188 829
new 0 188 829
assign 1 188 830
addValue 1 188 830
assign 1 188 831
outputPlatformGet 0 188 831
assign 1 188 832
nameGet 0 188 832
assign 1 188 833
addValue 1 188 833
assign 1 188 834
new 0 188 834
assign 1 188 835
addValue 1 188 835
addValue 1 188 836
assign 1 190 837
new 0 190 837
return 1 190 838
assign 1 194 842
new 0 194 842
return 1 194 843
assign 1 198 849
new 0 198 849
assign 1 198 850
once 0 198 850
assign 1 198 851
add 1 198 851
return 1 198 852
assign 1 202 856
getLibOutput 0 202 856
return 1 202 857
assign 1 217 922
undef 1 217 927
assign 1 218 928
libNameGet 0 218 928
assign 1 219 929
new 0 219 929
assign 1 219 930
sizeGet 0 219 930
assign 1 219 931
add 1 219 931
assign 1 219 932
new 0 219 932
assign 1 219 933
add 1 219 933
assign 1 219 934
add 1 219 934
assign 1 219 935
add 1 219 935
assign 1 220 936
new 0 220 936
assign 1 220 937
sizeGet 0 220 937
assign 1 220 938
add 1 220 938
assign 1 220 939
new 0 220 939
assign 1 220 940
add 1 220 940
assign 1 220 941
add 1 220 941
assign 1 220 942
add 1 220 942
assign 1 221 943
parentGet 0 221 943
assign 1 221 944
addStep 1 221 944
assign 1 222 945
parentGet 0 222 945
assign 1 222 946
addStep 1 222 946
assign 1 223 947
parentGet 0 223 947
assign 1 223 948
fileGet 0 223 948
assign 1 223 949
existsGet 0 223 949
assign 1 223 950
not 0 223 955
assign 1 224 956
parentGet 0 224 956
assign 1 224 957
fileGet 0 224 957
makeDirs 0 224 958
assign 1 226 960
fileGet 0 226 960
assign 1 226 961
writerGet 0 226 961
assign 1 226 962
open 0 226 962
assign 1 227 963
fileGet 0 227 963
assign 1 227 964
writerGet 0 227 964
assign 1 227 965
open 0 227 965
assign 1 229 966
new 0 229 966
write 1 229 967
assign 1 230 968
new 0 230 968
write 1 230 969
assign 1 231 970
new 0 231 970
write 1 231 971
assign 1 232 972
new 0 232 972
write 1 232 973
assign 1 234 974
new 0 234 974
write 1 234 975
assign 1 235 976
new 0 235 976
write 1 235 977
assign 1 241 978
paramsGet 0 241 978
assign 1 241 979
new 0 241 979
assign 1 241 980
has 1 241 980
assign 1 243 982
paramsGet 0 243 982
assign 1 243 983
new 0 243 983
assign 1 243 984
get 1 243 984
assign 1 243 985
iteratorGet 0 0 985
assign 1 243 988
hasNextGet 0 243 988
assign 1 243 990
nextGet 0 243 990
assign 1 245 991
apNew 1 245 991
assign 1 245 992
fileGet 0 245 992
assign 1 246 993
readerGet 0 246 993
assign 1 246 994
open 0 246 994
assign 1 246 995
readString 0 246 995
assign 1 247 996
readerGet 0 247 996
close 0 247 997
write 1 249 998
assign 1 252 1005
paramsGet 0 252 1005
assign 1 252 1006
new 0 252 1006
assign 1 252 1007
has 1 252 1007
assign 1 254 1009
paramsGet 0 254 1009
assign 1 254 1010
new 0 254 1010
assign 1 254 1011
get 1 254 1011
assign 1 254 1012
iteratorGet 0 0 1012
assign 1 254 1015
hasNextGet 0 254 1015
assign 1 254 1017
nextGet 0 254 1017
assign 1 256 1018
apNew 1 256 1018
assign 1 256 1019
fileGet 0 256 1019
assign 1 257 1020
readerGet 0 257 1020
assign 1 257 1021
open 0 257 1021
assign 1 257 1022
readString 0 257 1022
assign 1 258 1023
readerGet 0 258 1023
close 0 258 1024
write 1 260 1025
begin 1 267 1036
prepHeaderOutput 0 268 1037
assign 1 273 1067
undef 1 273 1072
assign 1 274 1073
new 0 274 1073
assign 1 275 1074
parentGet 0 275 1074
assign 1 275 1075
fileGet 0 275 1075
assign 1 275 1076
existsGet 0 275 1076
assign 1 275 1077
not 0 275 1082
assign 1 276 1083
parentGet 0 276 1083
assign 1 276 1084
fileGet 0 276 1084
makeDirs 0 276 1085
assign 1 278 1087
fileGet 0 278 1087
assign 1 278 1088
writerGet 0 278 1088
assign 1 278 1089
open 0 278 1089
assign 1 280 1090
new 0 280 1090
write 1 280 1091
increment 0 281 1092
assign 1 282 1093
paramsGet 0 282 1093
assign 1 282 1094
new 0 282 1094
assign 1 282 1095
has 1 282 1095
assign 1 283 1097
paramsGet 0 283 1097
assign 1 283 1098
new 0 283 1098
assign 1 283 1099
get 1 283 1099
assign 1 283 1100
iteratorGet 0 0 1100
assign 1 283 1103
hasNextGet 0 283 1103
assign 1 283 1105
nextGet 0 283 1105
assign 1 284 1106
apNew 1 284 1106
assign 1 284 1107
fileGet 0 284 1107
assign 1 285 1108
readerGet 0 285 1108
assign 1 285 1109
open 0 285 1109
assign 1 285 1110
readString 0 285 1110
assign 1 286 1111
readerGet 0 286 1111
close 0 286 1112
assign 1 287 1113
countLines 1 287 1113
addValue 1 287 1114
write 1 288 1115
return 1 294 1123
assign 1 299 1129
new 0 299 1129
write 1 299 1130
close 0 300 1131
assign 1 301 1132
assign 1 303 1133
new 0 303 1133
write 1 303 1134
assign 1 305 1135
new 0 305 1135
write 1 305 1136
close 0 306 1137
close 0 307 1138
assign 1 312 1143
new 0 312 1143
return 1 312 1144
assign 1 316 1151
new 0 316 1151
assign 1 316 1152
addValue 1 316 1152
assign 1 316 1153
addValue 1 316 1153
assign 1 316 1154
new 0 316 1154
addValue 1 316 1155
assign 1 321 1177
heldGet 0 321 1177
assign 1 321 1178
synGet 0 321 1178
assign 1 322 1179
ptyListGet 0 322 1179
assign 1 324 1180
emitNameGet 0 324 1180
assign 1 324 1181
addValue 1 324 1181
assign 1 324 1182
new 0 324 1182
addValue 1 324 1183
assign 1 326 1184
new 0 326 1184
assign 1 327 1185
iteratorGet 0 0 1185
assign 1 327 1188
hasNextGet 0 327 1188
assign 1 327 1190
nextGet 0 327 1190
assign 1 329 1192
new 0 329 1192
assign 1 331 1195
new 0 331 1195
addValue 1 331 1196
assign 1 333 1198
addValue 1 333 1198
assign 1 333 1199
new 0 333 1199
assign 1 333 1200
addValue 1 333 1200
assign 1 333 1201
nameGet 0 333 1201
assign 1 333 1202
addValue 1 333 1202
addValue 1 333 1203
assign 1 337 1209
new 0 337 1209
assign 1 337 1210
addValue 1 337 1210
addValue 1 337 1211
assign 1 342 1229
new 0 342 1229
assign 1 344 1230
new 0 344 1230
assign 1 344 1231
emitNameGet 0 344 1231
assign 1 344 1232
add 1 344 1232
assign 1 344 1233
new 0 344 1233
assign 1 344 1234
add 1 344 1234
assign 1 346 1235
new 0 346 1235
assign 1 346 1236
addValue 1 346 1236
assign 1 346 1237
emitNameGet 0 346 1237
assign 1 346 1238
addValue 1 346 1238
assign 1 346 1239
new 0 346 1239
assign 1 346 1240
addValue 1 346 1240
assign 1 346 1241
addValue 1 346 1241
assign 1 346 1242
new 0 346 1242
addValue 1 346 1243
return 1 348 1244
assign 1 352 1253
libNameGet 0 352 1253
assign 1 352 1254
relEmitName 1 352 1254
assign 1 353 1255
new 0 353 1255
assign 1 353 1256
add 1 353 1256
assign 1 353 1257
new 0 353 1257
assign 1 353 1258
add 1 353 1258
return 1 354 1259
assign 1 358 1315
getClassConfig 1 358 1315
assign 1 358 1316
libNameGet 0 358 1316
assign 1 358 1317
relEmitName 1 358 1317
assign 1 359 1318
heldGet 0 359 1318
assign 1 359 1319
namepathGet 0 359 1319
assign 1 359 1320
getClassConfig 1 359 1320
assign 1 360 1321
getInitialInst 1 360 1321
assign 1 362 1322
overrideMtdDecGet 0 362 1322
assign 1 362 1323
addValue 1 362 1323
assign 1 362 1324
new 0 362 1324
assign 1 362 1325
addValue 1 362 1325
assign 1 362 1326
emitNameGet 0 362 1326
assign 1 362 1327
addValue 1 362 1327
assign 1 362 1328
new 0 362 1328
assign 1 362 1329
addValue 1 362 1329
assign 1 362 1330
addValue 1 362 1330
assign 1 362 1331
new 0 362 1331
assign 1 362 1332
addValue 1 362 1332
assign 1 362 1333
addValue 1 362 1333
assign 1 362 1334
new 0 362 1334
assign 1 362 1335
addValue 1 362 1335
addValue 1 362 1336
assign 1 363 1337
new 0 363 1337
assign 1 364 1338
emitNameGet 0 364 1338
assign 1 364 1339
notEquals 1 364 1339
assign 1 365 1341
formStatCast 2 365 1341
assign 1 368 1343
addValue 1 368 1343
assign 1 368 1344
new 0 368 1344
assign 1 368 1345
addValue 1 368 1345
assign 1 368 1346
addValue 1 368 1346
assign 1 368 1347
new 0 368 1347
assign 1 368 1348
addValue 1 368 1348
addValue 1 368 1349
assign 1 370 1350
new 0 370 1350
assign 1 370 1351
addValue 1 370 1351
addValue 1 370 1352
assign 1 373 1353
overrideMtdDecGet 0 373 1353
assign 1 373 1354
addValue 1 373 1354
assign 1 373 1355
new 0 373 1355
assign 1 373 1356
addValue 1 373 1356
assign 1 373 1357
addValue 1 373 1357
assign 1 373 1358
new 0 373 1358
assign 1 373 1359
addValue 1 373 1359
assign 1 373 1360
emitNameGet 0 373 1360
assign 1 373 1361
addValue 1 373 1361
assign 1 373 1362
new 0 373 1362
assign 1 373 1363
addValue 1 373 1363
assign 1 373 1364
addValue 1 373 1364
assign 1 373 1365
new 0 373 1365
assign 1 373 1366
addValue 1 373 1366
addValue 1 373 1367
assign 1 375 1368
new 0 375 1368
assign 1 375 1369
addValue 1 375 1369
assign 1 375 1370
addValue 1 375 1370
assign 1 375 1371
new 0 375 1371
assign 1 375 1372
addValue 1 375 1372
addValue 1 375 1373
assign 1 377 1374
new 0 377 1374
assign 1 377 1375
addValue 1 377 1375
addValue 1 377 1376
return 1 0 1380
assign 1 0 1383
return 1 0 1387
assign 1 0 1390
return 1 0 1394
assign 1 0 1397
return 1 0 1401
assign 1 0 1404
return 1 0 1408
assign 1 0 1411
return 1 0 1415
assign 1 0 1418
return 1 0 1422
assign 1 0 1425
return 1 0 1429
assign 1 0 1432
return 1 0 1436
assign 1 0 1439
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1073009537: return bem_beginNs_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 245121133: return bem_classHeadBodyGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1926693913: return bem_synEmitPathGet_0();
case -1052944126: return bem_csynGet_0();
case -1910715228: return bem_libEmitNameGet_0();
case 1774940957: return bem_toString_0();
case -157262622: return bem_heowGet_0();
case -1413054881: return bem_smnlcsGet_0();
case -797225458: return bem_dynMethodsGet_0();
case -622039562: return bem_intNpGet_0();
case -1923547459: return bem_boolCcGet_0();
case -729571811: return bem_serializeToString_0();
case 498080472: return bem_mnodeGet_0();
case 2001798761: return bem_nlGet_0();
case -1841706211: return bem_returnTypeGet_0();
case -2039613615: return bem_instanceNotEqualGet_0();
case 1240611285: return bem_onceDecsGet_0();
case -206157822: return bem_coanyiantReturnsGet_0();
case -1727672536: return bem_propDecGet_0();
case 916491491: return bem_emitLib_0();
case -722876119: return bem_buildClassInfo_0();
case -402158238: return bem_inFilePathedGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case 1327064356: return bem_methodBodyGet_0();
case -786424307: return bem_tagGet_0();
case 1529527065: return bem_onceCountGet_0();
case -1081275759: return bem_classesInDepthOrderGet_0();
case -1369896794: return bem_objectNpGet_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case -1064889660: return bem_trueValueGet_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 104713553: return bem_new_0();
case -1795655423: return bem_propertyDecsGet_0();
case 89706405: return bem_ccCacheGet_0();
case 962646066: return bem_shlibeGet_0();
case -1317806639: return bem_baseMtdDecGet_0();
case 362974009: return bem_parentConfGet_0();
case -1717783419: return bem_deopGet_0();
case -902412214: return bem_classCallsGet_0();
case -220901978: return bem_emitLangGet_0();
case -1498619679: return bem_getLibOutput_0();
case -946095539: return bem_mainInClassGet_0();
case -357666679: return bem_heopGet_0();
case -1241388883: return bem_lastMethodBodySizeGet_0();
case -101343106: return bem_nativeCSlotsGet_0();
case -1775041721: return bem_deonGet_0();
case 2055025483: return bem_serializeContents_0();
case 5583797: return bem_maxDynArgsGet_0();
case -248786900: return bem_afterCast_0();
case -314718434: return bem_print_0();
case -681402717: return bem_boolTypeGet_0();
case -414924981: return bem_heonGet_0();
case 1820417453: return bem_create_0();
case -388723214: return bem_preClassGet_0();
case -991179882: return bem_qGet_0();
case -1109279973: return bem_spropDecGet_0();
case -1487140092: return bem_classEndGet_0();
case -727049506: return bem_exceptDecGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 361542143: return bem_classEmitsGet_0();
case 1563880876: return bem_prepHeaderOutput_0();
case -1449942744: return bem_instanceEqualGet_0();
case 1859739893: return bem_methodsGet_0();
case 236269941: return bem_ccMethodsGet_0();
case -1786051763: return bem_methodCatchGet_0();
case -1354714650: return bem_copy_0();
case -2085643372: return bem_stringNpGet_0();
case -1500143225: return bem_useDynMethodsGet_0();
case -1831751774: return bem_cnodeGet_0();
case 287040793: return bem_hashGet_0();
case 57260628: return bem_getClassOutput_0();
case -1755995201: return bem_transGet_0();
case -991255330: return bem_mainStartGet_0();
case -493012039: return bem_buildGet_0();
case 604504089: return bem_falseValueGet_0();
case -644675716: return bem_ntypesGet_0();
case -4647121: return bem_doEmit_0();
case 1102720804: return bem_classNameGet_0();
case -944442837: return bem_classConfGet_0();
case 1372235405: return bem_superCallsGet_0();
case -103017121: return bem_runtimeInitGet_0();
case -291757594: return bem_headExtGet_0();
case -254265568: return bem_buildPropList_0();
case -1703922349: return bem_fullLibEmitNameGet_0();
case -1747980150: return bem_smnlecsGet_0();
case 772789066: return bem_libEmitPathGet_0();
case 1177623581: return bem_callNamesGet_0();
case 36542021: return bem_mainEndGet_0();
case -397629001: return bem_maxSpillArgsLenGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case -1152064310: return bem_instOfGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case -294732055: return bem_floatNpGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case 1178070402: return bem_fileExtGet_0();
case 1312373307: return bem_buildCreate_0();
case -1711936384: return bem_baseSmtdDecGet_0();
case 1181505319: return bem_buildInitial_0();
case -229958684: return bem_constGet_0();
case -955058175: return bem_lastMethodBodyLinesGet_0();
case -1607412815: return bem_endNs_0();
case -845792839: return bem_iteratorGet_0();
case -378762597: return bem_boolNpGet_0();
case 1431933907: return bem_lastCallGet_0();
case 1074463609: return bem_saveSyns_0();
case 483359873: return bem_superNameGet_0();
case -1308786538: return bem_echo_0();
case -628036310: return bem_lastMethodsSizeGet_0();
case 1380285640: return bem_objectCcGet_0();
case -1947619572: return bem_msynGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1638160588: return bem_lineCountGet_0();
case -1517379362: return bem_deowGet_0();
case -1967844855: return bem_initialDecGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -571409003: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 256203386: return bem_classHeadBodySet_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -1053807407: return bem_trueValueSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 2142670547: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 2144776371: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 165152860: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1227314505: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -541207893: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case -1915611660: return bem_synEmitPathSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case -1702694534: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -280675341: return bem_headExtSet_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case -610957309: return bem_intNpSet_1(bevd_0);
case -1763959468: return bem_deonSet_1(bevd_0);
case -386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -593061802: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 973728319: return bem_shlibeSet_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case -891329961: return bem_classCallsSet_1(bevd_0);
case -1887784556: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -980097629: return bem_qSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1820669521: return bem_cnodeSet_1(bevd_0);
case -146180369: return bem_heowSet_1(bevd_0);
case -945327254: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case -1073009536: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -90260853: return bem_nativeCSlotsSet_1(bevd_0);
case -1022041723: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case -1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1901078234: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case -1706701166: return bem_deopSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case -596365949: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1912465206: return bem_boolCcSet_1(bevd_0);
case -377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case -943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -933360584: return bem_classConfSet_1(bevd_0);
case 1550716690: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case -1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -70425956: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case -16141842: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case -1980754914: return bem_oldacceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1936537319: return bem_msynSet_1(bevd_0);
case -551679723: return bem_formCast_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case -209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1438860491: return bem_instanceEqualSet_1(bevd_0);
case -1899632975: return bem_libEmitNameSet_1(bevd_0);
case -478502832: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1506297109: return bem_deowSet_1(bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -2110408325: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -193407613: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -391075985: return bem_inFilePathedSet_1(bevd_0);
case -36312873: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1041861873: return bem_csynSet_1(bevd_0);
case -1931824221: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -403842728: return bem_heonSet_1(bevd_0);
case -715967253: return bem_exceptDecSet_1(bevd_0);
case -1830623958: return bem_returnTypeSet_1(bevd_0);
case -1562282714: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case -1774969510: return bem_methodCatchSet_1(bevd_0);
case 2118534024: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case -1358814541: return bem_objectNpSet_1(bevd_0);
case -1820890036: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case -2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case -65026440: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -627952553: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -508002125: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -707569329: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -724180734: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
case -346584426: return bem_heopSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1604046278: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1795316362: return bem_formStatCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1697242261: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1978614329: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1671519971: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 297627956: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -569933480: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -6388749: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1573050023: return bem_formDynCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 1900236781: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -722876116: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 886529145: return bem_finalAssign_3((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callHash) {
case -316092711: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -2023930725: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1591575024: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCCEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
}
}
