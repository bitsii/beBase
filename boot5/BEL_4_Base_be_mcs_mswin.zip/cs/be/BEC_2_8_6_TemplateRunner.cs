namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_8_6_TemplateRunner : BEC_2_6_6_SystemObject {
public BEC_2_8_6_TemplateRunner() { }
static BEC_2_8_6_TemplateRunner() { }
private static byte[] becc_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x75,0x6E,0x6E,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_2_8_6_TemplateRunner bevs_inst;
public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_6_6_SystemObject bevp_output;
public BEC_2_6_6_SystemObject bevp_stepIter;
public BEC_2_9_3_ContainerMap bevp_swap;
public BEC_2_9_3_ContainerMap bevp_handOff;
public BEC_2_8_6_TemplateRunner bevp_baton;
public BEC_2_7_7_ReplaceRunStep bevp_runStep;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep());
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_swapGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_swap == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevp_swap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 182 */
return bevp_swap;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_handOffGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_handOff == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevp_handOff = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 187 */
return bevp_handOff;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_new_2(BEC_2_4_6_TextString beva_template, BEC_2_6_6_SystemObject beva__output) {
this.bem_new_1(beva_template);
bevp_output = beva__output;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_new_1(BEC_2_4_6_TextString beva_template) {
this.bem_new_0();
this.bem_load_1(beva_template);
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_load_1(BEC_2_4_6_TextString beva_template) {
bevp_replace = (BEC_2_8_7_TemplateReplace) (new BEC_2_8_7_TemplateReplace()).bem_new_0();
bevp_replace.bem_load_2(beva_template, this);
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_restart_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_baton == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 209 */
bevp_stepIter = null;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_stepIterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
if (bevp_stepIter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevt_1_tmpany_phold = bevp_replace.bem_stepsGet_0();
bevp_stepIter = bevt_1_tmpany_phold.bem_iteratorGet_0();
} /* Line: 216 */
return bevp_stepIter;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_currentRunnerGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_8_6_TemplateRunner bevt_1_tmpany_phold = null;
if (bevp_baton == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_1_tmpany_phold = bevp_baton.bem_currentRunnerGet_0();
return bevt_1_tmpany_phold;
} /* Line: 223 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentNodeGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_8_6_TemplateRunner bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = this.bem_currentRunnerGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_stepIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1582066476, BEL_4_Base.bevn_currentNodeGet_0);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_6_6_SystemObject bevl_iter = null;
bevl_iter = this.bem_stepIterGet_0();
bevl_iter.bemd_1(1593148729, BEL_4_Base.bevn_currentNodeSet_1, beva_node);
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_runToLabel_1(BEC_2_4_6_TextString beva_label) {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
if (bevp_baton == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_4_tmpany_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 241 */
 else  /* Line: 242 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 245 */
} /* Line: 240 */
bevl_iter = this.bem_stepIterGet_0();
while (true)
 /* Line: 249 */ {
bevt_6_tmpany_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 249 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_handOff == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_8_tmpany_phold = bevl_s.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 251 */ {
bevt_10_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_9_tmpany_phold = bevp_handOff.bem_has_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 251 */ {
bevt_11_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpany_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevt_13_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_13_tmpany_phold;
} /* Line: 256 */
 else  /* Line: 257 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 260 */
} /* Line: 255 */
 else  /* Line: 251 */ {
bevt_14_tmpany_phold = bevl_s.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_16_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, beva_label);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 262 */
 else  /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 262 */ {
bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /* Line: 263 */
 else  /* Line: 264 */ {
bevt_18_tmpany_phold = bevl_s.bemd_1(2068442, BEL_4_Base.bevn_handle_1, this);
bevp_output.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_18_tmpany_phold);
} /* Line: 265 */
} /* Line: 251 */
} /* Line: 251 */
 else  /* Line: 249 */ {
break;
} /* Line: 249 */
} /* Line: 249 */
bevt_19_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_19_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_skipToLabel_1(BEC_2_4_6_TextString beva_label) {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
if (bevp_baton == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_4_tmpany_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 273 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 274 */
 else  /* Line: 275 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 278 */
} /* Line: 273 */
bevl_iter = this.bem_stepIterGet_0();
while (true)
 /* Line: 282 */ {
bevt_6_tmpany_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 282 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_handOff == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_8_tmpany_phold = bevl_s.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_10_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_9_tmpany_phold = bevp_handOff.bem_has_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_11_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpany_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 288 */ {
bevt_13_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_13_tmpany_phold;
} /* Line: 289 */
 else  /* Line: 290 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 293 */
} /* Line: 288 */
 else  /* Line: 284 */ {
bevt_14_tmpany_phold = bevl_s.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 295 */ {
bevt_16_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, beva_label);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 295 */
 else  /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 295 */ {
bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /* Line: 296 */
} /* Line: 284 */
} /* Line: 284 */
 else  /* Line: 282 */ {
break;
} /* Line: 282 */
} /* Line: 282 */
bevt_18_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_18_tmpany_phold;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_run_0() {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
if (bevp_baton == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 303 */ {
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 306 */
bevl_iter = this.bem_stepIterGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpany_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 309 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_handOff == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_5_tmpany_phold = bevl_s.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 311 */
 else  /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 311 */ {
bevt_7_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_6_tmpany_phold = bevp_handOff.bem_has_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 311 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 311 */ {
bevt_8_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_8_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 317 */
 else  /* Line: 318 */ {
bevt_9_tmpany_phold = bevl_s.bemd_1(2068442, BEL_4_Base.bevn_handle_1, this);
bevp_output.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_9_tmpany_phold);
} /* Line: 319 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
return this;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_replaceGet_0() {
return bevp_replace;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_outputGet_0() {
return bevp_output;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_outputSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_output = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_stepIterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_stepIter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_swapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_handOffSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_batonGet_0() {
return bevp_baton;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_batonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_7_7_ReplaceRunStep bem_runStepGet_0() {
return bevp_runStep;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_runStepSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {177, 182, 182, 182, 183, 187, 187, 187, 188, 192, 193, 197, 198, 202, 203, 207, 207, 208, 209, 211, 215, 215, 216, 216, 218, 222, 222, 223, 223, 225, 229, 229, 229, 229, 234, 235, 239, 239, 240, 241, 241, 244, 245, 248, 249, 250, 251, 251, 251, 0, 0, 0, 251, 251, 0, 0, 0, 252, 252, 253, 254, 255, 256, 256, 259, 260, 262, 262, 262, 0, 0, 0, 263, 263, 265, 265, 268, 268, 272, 272, 273, 274, 274, 277, 278, 281, 282, 283, 284, 284, 284, 0, 0, 0, 284, 284, 0, 0, 0, 285, 285, 286, 287, 288, 289, 289, 292, 293, 295, 295, 295, 0, 0, 0, 296, 296, 299, 299, 303, 303, 304, 305, 306, 308, 309, 310, 311, 311, 311, 0, 0, 0, 311, 311, 0, 0, 0, 312, 312, 313, 314, 315, 316, 317, 319, 319, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 22, 27, 28, 30, 34, 39, 40, 42, 45, 46, 50, 51, 55, 56, 61, 66, 67, 68, 70, 76, 81, 82, 83, 85, 90, 95, 96, 97, 99, 105, 106, 107, 108, 112, 113, 139, 144, 145, 147, 148, 151, 152, 155, 158, 160, 161, 166, 167, 169, 172, 176, 179, 180, 182, 185, 189, 192, 193, 194, 195, 196, 198, 199, 202, 203, 207, 209, 210, 212, 215, 219, 222, 223, 226, 227, 235, 236, 260, 265, 266, 268, 269, 272, 273, 276, 279, 281, 282, 287, 288, 290, 293, 297, 300, 301, 303, 306, 310, 313, 314, 315, 316, 317, 319, 320, 323, 324, 328, 330, 331, 333, 336, 340, 343, 344, 352, 353, 368, 373, 374, 375, 376, 378, 381, 383, 384, 389, 390, 392, 395, 399, 402, 403, 405, 408, 412, 415, 416, 417, 418, 419, 420, 421, 424, 425, 435, 438, 442, 445, 449, 453, 457, 461, 464, 468, 471};
/* BEGIN LINEINFO 
assign 1 177 17
new 0 177 17
assign 1 182 22
undef 1 182 27
assign 1 182 28
new 0 182 28
return 1 183 30
assign 1 187 34
undef 1 187 39
assign 1 187 40
new 0 187 40
return 1 188 42
new 1 192 45
assign 1 193 46
new 0 197 50
load 1 198 51
assign 1 202 55
new 0 202 55
load 2 203 56
assign 1 207 61
def 1 207 66
restart 0 208 67
assign 1 209 68
assign 1 211 70
assign 1 215 76
undef 1 215 81
assign 1 216 82
stepsGet 0 216 82
assign 1 216 83
iteratorGet 0 216 83
return 1 218 85
assign 1 222 90
def 1 222 95
assign 1 223 96
currentRunnerGet 0 223 96
return 1 223 97
return 1 225 99
assign 1 229 105
currentRunnerGet 0 229 105
assign 1 229 106
stepIterGet 0 229 106
assign 1 229 107
currentNodeGet 0 229 107
return 1 229 108
assign 1 234 112
stepIterGet 0 234 112
currentNodeSet 1 235 113
assign 1 239 139
def 1 239 144
assign 1 240 145
runToLabel 1 240 145
assign 1 241 147
new 0 241 147
return 1 241 148
restart 0 244 151
assign 1 245 152
assign 1 248 155
stepIterGet 0 248 155
assign 1 249 158
hasNextGet 0 249 158
assign 1 250 160
nextGet 0 250 160
assign 1 251 161
def 1 251 166
assign 1 251 167
sameType 1 251 167
assign 1 0 169
assign 1 0 172
assign 1 0 176
assign 1 251 179
strGet 0 251 179
assign 1 251 180
has 1 251 180
assign 1 0 182
assign 1 0 185
assign 1 0 189
assign 1 252 192
strGet 0 252 192
assign 1 252 193
get 1 252 193
outputSet 1 253 194
swapSet 1 254 195
assign 1 255 196
runToLabel 1 255 196
assign 1 256 198
new 0 256 198
return 1 256 199
restart 0 259 202
assign 1 260 203
assign 1 262 207
sameType 1 262 207
assign 1 262 209
strGet 0 262 209
assign 1 262 210
equals 1 262 210
assign 1 0 212
assign 1 0 215
assign 1 0 219
assign 1 263 222
new 0 263 222
return 1 263 223
assign 1 265 226
handle 1 265 226
write 1 265 227
assign 1 268 235
new 0 268 235
return 1 268 236
assign 1 272 260
def 1 272 265
assign 1 273 266
skipToLabel 1 273 266
assign 1 274 268
new 0 274 268
return 1 274 269
restart 0 277 272
assign 1 278 273
assign 1 281 276
stepIterGet 0 281 276
assign 1 282 279
hasNextGet 0 282 279
assign 1 283 281
nextGet 0 283 281
assign 1 284 282
def 1 284 287
assign 1 284 288
sameType 1 284 288
assign 1 0 290
assign 1 0 293
assign 1 0 297
assign 1 284 300
strGet 0 284 300
assign 1 284 301
has 1 284 301
assign 1 0 303
assign 1 0 306
assign 1 0 310
assign 1 285 313
strGet 0 285 313
assign 1 285 314
get 1 285 314
outputSet 1 286 315
swapSet 1 287 316
assign 1 288 317
skipToLabel 1 288 317
assign 1 289 319
new 0 289 319
return 1 289 320
restart 0 292 323
assign 1 293 324
assign 1 295 328
sameType 1 295 328
assign 1 295 330
strGet 0 295 330
assign 1 295 331
equals 1 295 331
assign 1 0 333
assign 1 0 336
assign 1 0 340
assign 1 296 343
new 0 296 343
return 1 296 344
assign 1 299 352
new 0 299 352
return 1 299 353
assign 1 303 368
def 1 303 373
run 0 304 374
restart 0 305 375
assign 1 306 376
assign 1 308 378
stepIterGet 0 308 378
assign 1 309 381
hasNextGet 0 309 381
assign 1 310 383
nextGet 0 310 383
assign 1 311 384
def 1 311 389
assign 1 311 390
sameType 1 311 390
assign 1 0 392
assign 1 0 395
assign 1 0 399
assign 1 311 402
strGet 0 311 402
assign 1 311 403
has 1 311 403
assign 1 0 405
assign 1 0 408
assign 1 0 412
assign 1 312 415
strGet 0 312 415
assign 1 312 416
get 1 312 416
outputSet 1 313 417
swapSet 1 314 418
run 0 315 419
restart 0 316 420
assign 1 317 421
assign 1 319 424
handle 1 319 424
write 1 319 425
return 1 0 435
assign 1 0 438
return 1 0 442
assign 1 0 445
assign 1 0 449
assign 1 0 453
assign 1 0 457
return 1 0 461
assign 1 0 464
return 1 0 468
assign 1 0 471
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case 1052303331: return bem_stepIterGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1294131276: return bem_swapGet_0();
case 1582066476: return bem_currentNodeGet_0();
case 104713553: return bem_new_0();
case 1941218611: return bem_batonGet_0();
case 287040793: return bem_hashGet_0();
case 108875644: return bem_run_0();
case 1774940957: return bem_toString_0();
case -1858379264: return bem_restart_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 438504243: return bem_replaceGet_0();
case -847016698: return bem_outputGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1032568578: return bem_currentRunnerGet_0();
case 1098633959: return bem_handOffGet_0();
case 1820417453: return bem_create_0();
case 930387920: return bem_runStepGet_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1952300864: return bem_batonSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 941470173: return bem_runStepSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1109716212: return bem_handOffSet_1(bevd_0);
case 449586496: return bem_replaceSet_1(bevd_0);
case -1097519336: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1283049023: return bem_swapSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1593148729: return bem_currentNodeSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -835934445: return bem_outputSet_1(bevd_0);
case 1586884588: return bem_skipToLabel_1((BEC_2_4_6_TextString) bevd_0);
case 1063385584: return bem_stepIterSet_1(bevd_0);
case -2118449056: return bem_runToLabel_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_8_6_TemplateRunner();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_8_6_TemplateRunner.bevs_inst = (BEC_2_8_6_TemplateRunner)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_8_6_TemplateRunner.bevs_inst;
}
}
}
