namespace be {
/* IO:File: source/build/Constants.be */
public sealed class BEC_2_5_9_BuildConstants : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildConstants() { }
static BEC_2_5_9_BuildConstants() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x62,0x72,0x61,0x63,0x65,0x73};
private static byte[] bels_1 = {0x63,0x61,0x6C,0x6C};
private static byte[] bels_2 = {0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_3 = {0x70,0x61,0x72,0x65,0x6E,0x73};
private static byte[] bels_4 = {0x4E,0x4F,0x54};
private static byte[] bels_5 = {0x4F,0x4E,0x43,0x45};
private static byte[] bels_6 = {0x4D,0x41,0x4E,0x59};
private static byte[] bels_7 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bels_8 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bels_9 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59};
private static byte[] bels_10 = {0x44,0x49,0x56,0x49,0x44,0x45};
private static byte[] bels_11 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53};
private static byte[] bels_12 = {0x41,0x44,0x44};
private static byte[] bels_13 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54};
private static byte[] bels_14 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52};
private static byte[] bels_15 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_16 = {0x4C,0x45,0x53,0x53,0x45,0x52};
private static byte[] bels_17 = {0x4C,0x45,0x53,0x53,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_18 = {0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_19 = {0x4E,0x4F,0x54,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_20 = {0x41,0x4E,0x44};
private static byte[] bels_21 = {0x4F,0x52};
private static byte[] bels_22 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x41,0x4E,0x44};
private static byte[] bels_23 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x4F,0x52};
private static byte[] bels_24 = {0x49,0x4E};
private static byte[] bels_25 = {0x41,0x44,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_26 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_27 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_28 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_29 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_30 = {0x44,0x49,0x56,0x49,0x44,0x45,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_31 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_32 = {0x41,0x4E,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_33 = {0x4F,0x52,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_34 = {0x41,0x53,0x53,0x49,0x47,0x4E};
private static byte[] bels_35 = {0x20};
private static BEC_2_6_6_SystemObject bevo_0 = (new BEC_2_4_6_TextString(bels_35, 1));
private static byte[] bels_36 = {0x2F};
private static byte[] bels_37 = {0x7B};
private static byte[] bels_38 = {0x7D};
private static byte[] bels_39 = {0x28};
private static byte[] bels_40 = {0x29};
private static byte[] bels_41 = {0x3B};
private static byte[] bels_42 = {0x3A};
private static byte[] bels_43 = {0x2C};
private static byte[] bels_44 = {0x2B};
private static byte[] bels_45 = {};
private static byte[] bels_46 = {0x2D};
private static byte[] bels_47 = {0x40};
private static byte[] bels_48 = {0x23};
private static byte[] bels_49 = {0x75,0x73,0x65};
private static byte[] bels_50 = {0x61,0x73};
private static byte[] bels_51 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bels_52 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_53 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_54 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_55 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bels_56 = {0x61,0x6E,0x79};
private static byte[] bels_57 = {0x61,0x75,0x74,0x6F};
private static byte[] bels_58 = {0x69,0x66};
private static byte[] bels_59 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_60 = {0x65,0x6C,0x73,0x65,0x49,0x66};
private static byte[] bels_61 = {0x65,0x6C,0x73,0x65};
private static byte[] bels_62 = {0x66,0x69,0x6E,0x61,0x6C,0x6C,0x79};
private static byte[] bels_63 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bels_64 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bels_65 = {0x77,0x68,0x69,0x6C,0x65};
private static byte[] bels_66 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bels_67 = {0x66,0x6F,0x72};
private static byte[] bels_68 = {0x69,0x6E};
private static byte[] bels_69 = {0x65,0x6D,0x69,0x74};
private static byte[] bels_70 = {0x69,0x66,0x45,0x6D,0x69,0x74};
private static byte[] bels_71 = {0x69,0x66,0x4E,0x6F,0x74,0x45,0x6D,0x69,0x74};
private static byte[] bels_72 = {0x62,0x72,0x65,0x61,0x6B};
private static byte[] bels_73 = {0x63,0x6F,0x6E,0x74,0x69,0x6E,0x75,0x65};
private static byte[] bels_74 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_75 = {0x74,0x72,0x75,0x65};
private static byte[] bels_76 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_77 = {0x74,0x72,0x79};
private static byte[] bels_78 = {0x63,0x61,0x74,0x63,0x68};
public static new BEC_2_5_9_BuildConstants bevs_inst;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public BEC_2_4_3_MathInt bevp_maxargs;
public BEC_2_4_3_MathInt bevp_extraSlots;
public BEC_2_4_3_MathInt bevp_mtdxPad;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_9_3_ContainerMap bevp_unwindTo;
public BEC_2_9_3_ContainerMap bevp_unwindOk;
public BEC_2_9_3_ContainerMap bevp_oper;
public BEC_2_9_3_ContainerMap bevp_operNames;
public BEC_2_9_3_ContainerMap bevp_conTypes;
public BEC_2_9_3_ContainerMap bevp_parensReq;
public BEC_2_9_3_ContainerMap bevp_anchorTypes;
public BEC_2_5_9_BuildConstants bem_new_1(BEC_2_6_6_SystemObject beva_build) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_114_tmpany_phold = null;
BEC_2_4_6_TextString bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_4_6_TextString bevt_119_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_133_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_135_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_136_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_142_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_143_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_144_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_146_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_147_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_148_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_149_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_150_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_153_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_154_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_159_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_160_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_161_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_162_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_163_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_166_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_167_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_168_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_171_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_172_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_173_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_174_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_175_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_176_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_177_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_178_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_179_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_180_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_181_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_182_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_183_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_184_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_185_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_186_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_187_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_188_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_189_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_190_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_191_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_192_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_193_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_194_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_195_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_197_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_198_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_199_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_200_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_201_tmpany_phold = null;
bevp_maxargs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevp_extraSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_mtdxPad = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(26));
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) BEC_2_5_9_BuildNodeTypes.bevs_inst;
bevp_unwindTo = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_unwindOk = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_oper = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_operNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_conTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parensReq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_0));
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindTo.bem_put_2(bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_1));
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_2));
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_3));
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_6_tmpany_phold, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevt_9_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_11_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_10_tmpany_phold, bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevt_13_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_15_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_14_tmpany_phold, bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_17_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_16_tmpany_phold, bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_18_tmpany_phold, bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_21_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_20_tmpany_phold, bevt_21_tmpany_phold);
bevt_22_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_23_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_22_tmpany_phold, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_25_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_26_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_29_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_28_tmpany_phold, bevt_29_tmpany_phold);
bevt_30_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_31_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_32_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_33_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_35_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_36_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_37_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_38_tmpany_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_39_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_38_tmpany_phold, bevt_39_tmpany_phold);
bevt_40_tmpany_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_41_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_40_tmpany_phold, bevt_41_tmpany_phold);
bevt_42_tmpany_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_43_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_42_tmpany_phold, bevt_43_tmpany_phold);
bevt_44_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevt_45_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_44_tmpany_phold, bevt_45_tmpany_phold);
bevt_46_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevt_47_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevt_48_tmpany_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_49_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_48_tmpany_phold, bevt_49_tmpany_phold);
bevt_50_tmpany_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_51_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_50_tmpany_phold, bevt_51_tmpany_phold);
bevt_52_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevt_53_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
bevp_oper.bem_put_2(bevt_52_tmpany_phold, bevt_53_tmpany_phold);
bevt_54_tmpany_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_55_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_54_tmpany_phold, bevt_55_tmpany_phold);
bevt_56_tmpany_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_57_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_56_tmpany_phold, bevt_57_tmpany_phold);
bevt_58_tmpany_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_59_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_58_tmpany_phold, bevt_59_tmpany_phold);
bevt_60_tmpany_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_61_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_60_tmpany_phold, bevt_61_tmpany_phold);
bevt_62_tmpany_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_63_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_62_tmpany_phold, bevt_63_tmpany_phold);
bevt_64_tmpany_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_65_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_64_tmpany_phold, bevt_65_tmpany_phold);
bevt_66_tmpany_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_67_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_66_tmpany_phold, bevt_67_tmpany_phold);
bevt_68_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_69_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_oper.bem_put_2(bevt_68_tmpany_phold, bevt_69_tmpany_phold);
bevt_70_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_4));
bevp_operNames.bem_put_2(bevt_70_tmpany_phold, bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_5));
bevp_operNames.bem_put_2(bevt_72_tmpany_phold, bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_6));
bevp_operNames.bem_put_2(bevt_74_tmpany_phold, bevt_75_tmpany_phold);
bevt_76_tmpany_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_7));
bevp_operNames.bem_put_2(bevt_76_tmpany_phold, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_8));
bevp_operNames.bem_put_2(bevt_78_tmpany_phold, bevt_79_tmpany_phold);
bevt_80_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_9));
bevp_operNames.bem_put_2(bevt_80_tmpany_phold, bevt_81_tmpany_phold);
bevt_82_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_10));
bevp_operNames.bem_put_2(bevt_82_tmpany_phold, bevt_83_tmpany_phold);
bevt_84_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_11));
bevp_operNames.bem_put_2(bevt_84_tmpany_phold, bevt_85_tmpany_phold);
bevt_86_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_12));
bevp_operNames.bem_put_2(bevt_86_tmpany_phold, bevt_87_tmpany_phold);
bevt_88_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_13));
bevp_operNames.bem_put_2(bevt_88_tmpany_phold, bevt_89_tmpany_phold);
bevt_90_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_14));
bevp_operNames.bem_put_2(bevt_90_tmpany_phold, bevt_91_tmpany_phold);
bevt_92_tmpany_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_15));
bevp_operNames.bem_put_2(bevt_92_tmpany_phold, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_16));
bevp_operNames.bem_put_2(bevt_94_tmpany_phold, bevt_95_tmpany_phold);
bevt_96_tmpany_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_17));
bevp_operNames.bem_put_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_18));
bevp_operNames.bem_put_2(bevt_98_tmpany_phold, bevt_99_tmpany_phold);
bevt_100_tmpany_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_19));
bevp_operNames.bem_put_2(bevt_100_tmpany_phold, bevt_101_tmpany_phold);
bevt_102_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevt_103_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_20));
bevp_operNames.bem_put_2(bevt_102_tmpany_phold, bevt_103_tmpany_phold);
bevt_104_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_21));
bevp_operNames.bem_put_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevt_106_tmpany_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_22));
bevp_operNames.bem_put_2(bevt_106_tmpany_phold, bevt_107_tmpany_phold);
bevt_108_tmpany_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_109_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_23));
bevp_operNames.bem_put_2(bevt_108_tmpany_phold, bevt_109_tmpany_phold);
bevt_110_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevt_111_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_24));
bevp_operNames.bem_put_2(bevt_110_tmpany_phold, bevt_111_tmpany_phold);
bevt_112_tmpany_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_113_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_25));
bevp_operNames.bem_put_2(bevt_112_tmpany_phold, bevt_113_tmpany_phold);
bevt_114_tmpany_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_115_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_26));
bevp_operNames.bem_put_2(bevt_114_tmpany_phold, bevt_115_tmpany_phold);
bevt_116_tmpany_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_117_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_27));
bevp_operNames.bem_put_2(bevt_116_tmpany_phold, bevt_117_tmpany_phold);
bevt_118_tmpany_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_119_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_28));
bevp_operNames.bem_put_2(bevt_118_tmpany_phold, bevt_119_tmpany_phold);
bevt_120_tmpany_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_121_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_29));
bevp_operNames.bem_put_2(bevt_120_tmpany_phold, bevt_121_tmpany_phold);
bevt_122_tmpany_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_123_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_30));
bevp_operNames.bem_put_2(bevt_122_tmpany_phold, bevt_123_tmpany_phold);
bevt_124_tmpany_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_31));
bevp_operNames.bem_put_2(bevt_124_tmpany_phold, bevt_125_tmpany_phold);
bevt_126_tmpany_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_127_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_32));
bevp_operNames.bem_put_2(bevt_126_tmpany_phold, bevt_127_tmpany_phold);
bevt_128_tmpany_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_129_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_33));
bevp_operNames.bem_put_2(bevt_128_tmpany_phold, bevt_129_tmpany_phold);
bevt_130_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_131_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_34));
bevp_operNames.bem_put_2(bevt_130_tmpany_phold, bevt_131_tmpany_phold);
bevt_132_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_133_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_132_tmpany_phold, bevt_133_tmpany_phold);
bevt_134_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_135_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_134_tmpany_phold, bevt_135_tmpany_phold);
bevt_136_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_137_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_136_tmpany_phold, bevt_137_tmpany_phold);
bevt_138_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_139_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_138_tmpany_phold, bevt_139_tmpany_phold);
bevt_140_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_141_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_140_tmpany_phold, bevt_141_tmpany_phold);
bevt_142_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevt_143_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_142_tmpany_phold, bevt_143_tmpany_phold);
bevt_144_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_145_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_144_tmpany_phold, bevt_145_tmpany_phold);
bevt_146_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_147_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_146_tmpany_phold, bevt_147_tmpany_phold);
bevt_148_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_149_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_148_tmpany_phold, bevt_149_tmpany_phold);
bevt_150_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_151_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_150_tmpany_phold, bevt_151_tmpany_phold);
bevt_152_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_153_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_152_tmpany_phold, bevt_153_tmpany_phold);
bevt_154_tmpany_phold = bevp_ntypes.bem_FINALLYGet_0();
bevt_155_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_154_tmpany_phold, bevt_155_tmpany_phold);
bevt_156_tmpany_phold = bevp_ntypes.bem_TRYGet_0();
bevt_157_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_156_tmpany_phold, bevt_157_tmpany_phold);
bevt_158_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevt_159_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_158_tmpany_phold, bevt_159_tmpany_phold);
bevt_160_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_161_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_160_tmpany_phold, bevt_161_tmpany_phold);
bevt_162_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_163_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_162_tmpany_phold, bevt_163_tmpany_phold);
bevt_164_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_165_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_164_tmpany_phold, bevt_165_tmpany_phold);
bevt_166_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_167_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_166_tmpany_phold, bevt_167_tmpany_phold);
bevt_168_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_169_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_168_tmpany_phold, bevt_169_tmpany_phold);
bevt_170_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
bevt_171_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_170_tmpany_phold, bevt_171_tmpany_phold);
bevt_172_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_173_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_172_tmpany_phold, bevt_173_tmpany_phold);
bevt_174_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_175_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_174_tmpany_phold, bevt_175_tmpany_phold);
bevt_176_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_177_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_176_tmpany_phold, bevt_177_tmpany_phold);
bevt_178_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_179_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_178_tmpany_phold, bevt_179_tmpany_phold);
bevt_180_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_181_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_180_tmpany_phold, bevt_181_tmpany_phold);
bevt_182_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevt_183_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_182_tmpany_phold, bevt_183_tmpany_phold);
bevt_184_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_185_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_184_tmpany_phold, bevt_185_tmpany_phold);
bevt_186_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_187_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_186_tmpany_phold, bevt_187_tmpany_phold);
bevt_188_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_189_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_188_tmpany_phold, bevt_189_tmpany_phold);
bevt_190_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_191_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_190_tmpany_phold, bevt_191_tmpany_phold);
bevt_192_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_193_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_192_tmpany_phold, bevt_193_tmpany_phold);
bevt_194_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_195_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_194_tmpany_phold, bevt_195_tmpany_phold);
bevt_196_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_197_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_196_tmpany_phold, bevt_197_tmpany_phold);
bevt_198_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_199_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_198_tmpany_phold, bevt_199_tmpany_phold);
bevt_200_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_201_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_200_tmpany_phold, bevt_201_tmpany_phold);
this.bem_prepare_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_prepare_0() {
BEC_2_6_6_SystemObject bevl_space = null;
BEC_2_6_6_SystemObject bevl_ntok = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
bevp_matchMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_space = bevo_0;
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_36));
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_twtok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2((BEC_2_4_6_TextString) bevl_ntok, bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_1_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_37));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_2_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_2_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_38));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_3_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_3_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_39));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_4_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_4_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_40));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_5_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_5_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_41));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_6_tmpany_phold = bevp_ntypes.bem_SEMIGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_6_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_42));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_7_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_7_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_43));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_8_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_8_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_44));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_9_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_9_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(0, bels_45));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_10_tmpany_phold = bevp_ntypes.bem_ATYPEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_10_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_46));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_11_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_11_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_47));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_12_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_12_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bels_48));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_13_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(92));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_14_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_15_tmpany_phold = bevp_ntypes.bem_FSLASHGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_16_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_17_tmpany_phold = bevp_ntypes.bem_STRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_17_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(39));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_18_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_19_tmpany_phold = bevp_ntypes.bem_WSTRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_20_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_21_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(93));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_22_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_23_tmpany_phold = bevp_ntypes.bem_RIDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(37));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_24_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_25_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_25_tmpany_phold);
bevt_26_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(61));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_26_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_27_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_27_tmpany_phold);
bevt_28_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(62));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_28_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_29_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(60));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_30_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_31_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(33));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_32_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_33_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_33_tmpany_phold);
bevt_34_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(38));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_34_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_35_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(124));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_36_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_37_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(42));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_38_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_39_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(46));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_40_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_41_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_42_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_43_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_44_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_45_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_45_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_ntok = bevt_46_tmpany_phold.bem_newlineGet_0();
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok);
bevt_47_tmpany_phold = bevp_ntypes.bem_NEWLINEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_47_tmpany_phold);
bevp_rwords = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_49));
bevt_49_tmpany_phold = bevp_ntypes.bem_USEGet_0();
bevp_rwords.bem_put_2(bevt_48_tmpany_phold, bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_50));
bevt_51_tmpany_phold = bevp_ntypes.bem_ASGet_0();
bevp_rwords.bem_put_2(bevt_50_tmpany_phold, bevt_51_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_51));
bevt_53_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevp_rwords.bem_put_2(bevt_52_tmpany_phold, bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_52));
bevt_55_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevp_rwords.bem_put_2(bevt_54_tmpany_phold, bevt_55_tmpany_phold);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_53));
bevt_57_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_56_tmpany_phold, bevt_57_tmpany_phold);
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_54));
bevt_59_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_58_tmpany_phold, bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_55));
bevt_61_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_60_tmpany_phold, bevt_61_tmpany_phold);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_56));
bevt_63_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_62_tmpany_phold, bevt_63_tmpany_phold);
bevt_64_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_57));
bevt_65_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_64_tmpany_phold, bevt_65_tmpany_phold);
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_58));
bevt_67_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_66_tmpany_phold, bevt_67_tmpany_phold);
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_59));
bevt_69_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_68_tmpany_phold, bevt_69_tmpany_phold);
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_60));
bevt_71_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevp_rwords.bem_put_2(bevt_70_tmpany_phold, bevt_71_tmpany_phold);
bevt_72_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_61));
bevt_73_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevp_rwords.bem_put_2(bevt_72_tmpany_phold, bevt_73_tmpany_phold);
bevt_74_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_62));
bevt_75_tmpany_phold = bevp_ntypes.bem_FINALLYGet_0();
bevp_rwords.bem_put_2(bevt_74_tmpany_phold, bevt_75_tmpany_phold);
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_63));
bevt_77_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevp_rwords.bem_put_2(bevt_76_tmpany_phold, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_64));
bevt_79_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevp_rwords.bem_put_2(bevt_78_tmpany_phold, bevt_79_tmpany_phold);
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_65));
bevt_81_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_80_tmpany_phold, bevt_81_tmpany_phold);
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_66));
bevt_83_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_82_tmpany_phold, bevt_83_tmpany_phold);
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_67));
bevt_85_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevp_rwords.bem_put_2(bevt_84_tmpany_phold, bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_68));
bevt_87_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevp_rwords.bem_put_2(bevt_86_tmpany_phold, bevt_87_tmpany_phold);
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_69));
bevt_89_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevp_rwords.bem_put_2(bevt_88_tmpany_phold, bevt_89_tmpany_phold);
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_70));
bevt_91_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_90_tmpany_phold, bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_71));
bevt_93_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_92_tmpany_phold, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_72));
bevt_95_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevp_rwords.bem_put_2(bevt_94_tmpany_phold, bevt_95_tmpany_phold);
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_73));
bevt_97_tmpany_phold = bevp_ntypes.bem_CONTINUEGet_0();
bevp_rwords.bem_put_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_74));
bevt_99_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
bevp_rwords.bem_put_2(bevt_98_tmpany_phold, bevt_99_tmpany_phold);
bevt_100_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_75));
bevt_101_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevp_rwords.bem_put_2(bevt_100_tmpany_phold, bevt_101_tmpany_phold);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_76));
bevt_103_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevp_rwords.bem_put_2(bevt_102_tmpany_phold, bevt_103_tmpany_phold);
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_77));
bevt_105_tmpany_phold = bevp_ntypes.bem_TRYGet_0();
bevp_rwords.bem_put_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevt_106_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_78));
bevt_107_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevp_rwords.bem_put_2(bevt_106_tmpany_phold, bevt_107_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() {
return bevp_matchMap;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() {
return bevp_rwords;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxargsGet_0() {
return bevp_maxargs;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_maxargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_maxargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_extraSlotsGet_0() {
return bevp_extraSlots;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_extraSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extraSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxPadGet_0() {
return bevp_mtdxPad;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_mtdxPadSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdxPad = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindToGet_0() {
return bevp_unwindTo;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindTo = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindOkGet_0() {
return bevp_unwindOk;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindOkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindOk = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operGet_0() {
return bevp_oper;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_oper = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operNamesGet_0() {
return bevp_operNames;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_operNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_conTypesGet_0() {
return bevp_conTypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_conTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_conTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_parensReqGet_0() {
return bevp_parensReq;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_parensReqSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parensReq = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anchorTypesGet_0() {
return bevp_anchorTypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_anchorTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 22, 23, 24, 25, 26, 27, 28, 29, 30, 34, 34, 34, 36, 36, 36, 37, 37, 37, 38, 38, 38, 40, 40, 40, 41, 41, 41, 42, 42, 42, 43, 43, 43, 44, 44, 44, 45, 45, 45, 46, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 49, 50, 50, 50, 51, 51, 51, 52, 52, 52, 53, 53, 53, 54, 54, 54, 55, 55, 55, 56, 56, 56, 57, 57, 57, 58, 58, 58, 59, 59, 59, 60, 60, 60, 61, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64, 64, 65, 65, 65, 66, 66, 66, 67, 67, 67, 68, 68, 68, 69, 69, 69, 70, 70, 70, 72, 72, 72, 73, 73, 73, 74, 74, 74, 75, 75, 75, 76, 76, 76, 77, 77, 77, 78, 78, 78, 79, 79, 79, 80, 80, 80, 81, 81, 81, 82, 82, 82, 83, 83, 83, 84, 84, 84, 85, 85, 85, 86, 86, 86, 87, 87, 87, 88, 88, 88, 89, 89, 89, 90, 90, 90, 91, 91, 91, 92, 92, 92, 93, 93, 93, 94, 94, 94, 95, 95, 95, 96, 96, 96, 97, 97, 97, 98, 98, 98, 99, 99, 99, 100, 100, 100, 101, 101, 101, 102, 102, 102, 104, 104, 104, 105, 105, 105, 106, 106, 106, 107, 107, 107, 108, 108, 108, 109, 109, 109, 110, 110, 110, 111, 111, 111, 112, 112, 112, 113, 113, 113, 114, 114, 114, 115, 115, 115, 116, 116, 116, 117, 117, 117, 118, 118, 118, 119, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 125, 125, 125, 126, 126, 126, 127, 127, 127, 128, 128, 128, 129, 129, 129, 130, 130, 130, 131, 131, 131, 132, 132, 132, 133, 133, 133, 135, 135, 135, 136, 136, 136, 137, 137, 137, 138, 138, 138, 139, 139, 139, 140, 140, 140, 142, 148, 149, 151, 152, 152, 153, 153, 155, 156, 157, 157, 159, 160, 161, 161, 163, 164, 165, 165, 167, 168, 169, 169, 171, 172, 173, 173, 175, 176, 177, 177, 179, 180, 181, 181, 183, 184, 185, 185, 187, 188, 189, 189, 191, 192, 193, 193, 195, 196, 197, 197, 199, 200, 201, 201, 205, 205, 207, 208, 208, 210, 210, 212, 213, 213, 215, 215, 217, 218, 218, 220, 220, 222, 223, 223, 225, 225, 227, 228, 228, 230, 230, 232, 233, 233, 235, 235, 237, 238, 238, 240, 240, 242, 243, 243, 245, 245, 247, 248, 248, 250, 250, 252, 253, 253, 255, 255, 257, 258, 258, 260, 260, 262, 263, 263, 265, 265, 267, 268, 268, 270, 270, 272, 273, 273, 275, 275, 277, 278, 278, 280, 280, 282, 283, 283, 285, 285, 287, 288, 288, 291, 292, 292, 292, 293, 293, 293, 294, 294, 294, 295, 295, 295, 296, 296, 296, 297, 297, 297, 298, 298, 298, 299, 299, 299, 300, 300, 300, 301, 301, 301, 302, 302, 302, 303, 303, 303, 304, 304, 304, 305, 305, 305, 306, 306, 306, 307, 307, 307, 308, 308, 308, 309, 309, 309, 310, 310, 310, 311, 311, 311, 312, 312, 312, 313, 313, 313, 314, 314, 314, 315, 315, 315, 316, 316, 316, 317, 317, 317, 318, 318, 318, 319, 319, 319, 320, 320, 320, 321, 321, 321, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 968, 971, 975, 978, 982, 985, 989, 992, 996, 999, 1003, 1006, 1010, 1013, 1017, 1020, 1024, 1027, 1031, 1034, 1038, 1041, 1045, 1048, 1052, 1055, 1059, 1062};
/* BEGIN LINEINFO 
assign 1 18 306
new 0 18 306
assign 1 19 307
new 0 19 307
assign 1 22 308
new 0 22 308
assign 1 23 309
new 0 23 309
assign 1 24 310
new 0 24 310
assign 1 25 311
new 0 25 311
assign 1 26 312
new 0 26 312
assign 1 27 313
new 0 27 313
assign 1 28 314
new 0 28 314
assign 1 29 315
new 0 29 315
assign 1 30 316
new 0 30 316
assign 1 34 317
new 0 34 317
assign 1 34 318
new 0 34 318
put 2 34 319
assign 1 36 320
new 0 36 320
assign 1 36 321
new 0 36 321
put 2 36 322
assign 1 37 323
new 0 37 323
assign 1 37 324
new 0 37 324
put 2 37 325
assign 1 38 326
new 0 38 326
assign 1 38 327
new 0 38 327
put 2 38 328
assign 1 40 329
NOTGet 0 40 329
assign 1 40 330
new 0 40 330
put 2 40 331
assign 1 41 332
ONCEGet 0 41 332
assign 1 41 333
new 0 41 333
put 2 41 334
assign 1 42 335
MANYGet 0 42 335
assign 1 42 336
new 0 42 336
put 2 42 337
assign 1 43 338
INCREMENTGet 0 43 338
assign 1 43 339
new 0 43 339
put 2 43 340
assign 1 44 341
DECREMENTGet 0 44 341
assign 1 44 342
new 0 44 342
put 2 44 343
assign 1 45 344
INCREMENT_ASSIGNGet 0 45 344
assign 1 45 345
new 0 45 345
put 2 45 346
assign 1 46 347
DECREMENT_ASSIGNGet 0 46 347
assign 1 46 348
new 0 46 348
put 2 46 349
assign 1 47 350
MULTIPLYGet 0 47 350
assign 1 47 351
new 0 47 351
put 2 47 352
assign 1 48 353
DIVIDEGet 0 48 353
assign 1 48 354
new 0 48 354
put 2 48 355
assign 1 49 356
MODULUSGet 0 49 356
assign 1 49 357
new 0 49 357
put 2 49 358
assign 1 50 359
ADDGet 0 50 359
assign 1 50 360
new 0 50 360
put 2 50 361
assign 1 51 362
SUBTRACTGet 0 51 362
assign 1 51 363
new 0 51 363
put 2 51 364
assign 1 52 365
GREATERGet 0 52 365
assign 1 52 366
new 0 52 366
put 2 52 367
assign 1 53 368
GREATER_EQUALSGet 0 53 368
assign 1 53 369
new 0 53 369
put 2 53 370
assign 1 54 371
LESSERGet 0 54 371
assign 1 54 372
new 0 54 372
put 2 54 373
assign 1 55 374
LESSER_EQUALSGet 0 55 374
assign 1 55 375
new 0 55 375
put 2 55 376
assign 1 56 377
EQUALSGet 0 56 377
assign 1 56 378
new 0 56 378
put 2 56 379
assign 1 57 380
NOT_EQUALSGet 0 57 380
assign 1 57 381
new 0 57 381
put 2 57 382
assign 1 58 383
ANDGet 0 58 383
assign 1 58 384
new 0 58 384
put 2 58 385
assign 1 59 386
ORGet 0 59 386
assign 1 59 387
new 0 59 387
put 2 59 388
assign 1 60 389
LOGICAL_ANDGet 0 60 389
assign 1 60 390
new 0 60 390
put 2 60 391
assign 1 61 392
LOGICAL_ORGet 0 61 392
assign 1 61 393
new 0 61 393
put 2 61 394
assign 1 62 395
INGet 0 62 395
assign 1 62 396
new 0 62 396
put 2 62 397
assign 1 63 398
ADD_ASSIGNGet 0 63 398
assign 1 63 399
new 0 63 399
put 2 63 400
assign 1 64 401
SUBTRACT_ASSIGNGet 0 64 401
assign 1 64 402
new 0 64 402
put 2 64 403
assign 1 65 404
MULTIPLY_ASSIGNGet 0 65 404
assign 1 65 405
new 0 65 405
put 2 65 406
assign 1 66 407
DIVIDE_ASSIGNGet 0 66 407
assign 1 66 408
new 0 66 408
put 2 66 409
assign 1 67 410
MODULUS_ASSIGNGet 0 67 410
assign 1 67 411
new 0 67 411
put 2 67 412
assign 1 68 413
AND_ASSIGNGet 0 68 413
assign 1 68 414
new 0 68 414
put 2 68 415
assign 1 69 416
OR_ASSIGNGet 0 69 416
assign 1 69 417
new 0 69 417
put 2 69 418
assign 1 70 419
ASSIGNGet 0 70 419
assign 1 70 420
new 0 70 420
put 2 70 421
assign 1 72 422
NOTGet 0 72 422
assign 1 72 423
new 0 72 423
put 2 72 424
assign 1 73 425
ONCEGet 0 73 425
assign 1 73 426
new 0 73 426
put 2 73 427
assign 1 74 428
MANYGet 0 74 428
assign 1 74 429
new 0 74 429
put 2 74 430
assign 1 75 431
INCREMENTGet 0 75 431
assign 1 75 432
new 0 75 432
put 2 75 433
assign 1 76 434
DECREMENTGet 0 76 434
assign 1 76 435
new 0 76 435
put 2 76 436
assign 1 77 437
MULTIPLYGet 0 77 437
assign 1 77 438
new 0 77 438
put 2 77 439
assign 1 78 440
DIVIDEGet 0 78 440
assign 1 78 441
new 0 78 441
put 2 78 442
assign 1 79 443
MODULUSGet 0 79 443
assign 1 79 444
new 0 79 444
put 2 79 445
assign 1 80 446
ADDGet 0 80 446
assign 1 80 447
new 0 80 447
put 2 80 448
assign 1 81 449
SUBTRACTGet 0 81 449
assign 1 81 450
new 0 81 450
put 2 81 451
assign 1 82 452
GREATERGet 0 82 452
assign 1 82 453
new 0 82 453
put 2 82 454
assign 1 83 455
GREATER_EQUALSGet 0 83 455
assign 1 83 456
new 0 83 456
put 2 83 457
assign 1 84 458
LESSERGet 0 84 458
assign 1 84 459
new 0 84 459
put 2 84 460
assign 1 85 461
LESSER_EQUALSGet 0 85 461
assign 1 85 462
new 0 85 462
put 2 85 463
assign 1 86 464
EQUALSGet 0 86 464
assign 1 86 465
new 0 86 465
put 2 86 466
assign 1 87 467
NOT_EQUALSGet 0 87 467
assign 1 87 468
new 0 87 468
put 2 87 469
assign 1 88 470
ANDGet 0 88 470
assign 1 88 471
new 0 88 471
put 2 88 472
assign 1 89 473
ORGet 0 89 473
assign 1 89 474
new 0 89 474
put 2 89 475
assign 1 90 476
LOGICAL_ANDGet 0 90 476
assign 1 90 477
new 0 90 477
put 2 90 478
assign 1 91 479
LOGICAL_ORGet 0 91 479
assign 1 91 480
new 0 91 480
put 2 91 481
assign 1 92 482
INGet 0 92 482
assign 1 92 483
new 0 92 483
put 2 92 484
assign 1 93 485
ADD_ASSIGNGet 0 93 485
assign 1 93 486
new 0 93 486
put 2 93 487
assign 1 94 488
SUBTRACT_ASSIGNGet 0 94 488
assign 1 94 489
new 0 94 489
put 2 94 490
assign 1 95 491
INCREMENT_ASSIGNGet 0 95 491
assign 1 95 492
new 0 95 492
put 2 95 493
assign 1 96 494
DECREMENT_ASSIGNGet 0 96 494
assign 1 96 495
new 0 96 495
put 2 96 496
assign 1 97 497
MULTIPLY_ASSIGNGet 0 97 497
assign 1 97 498
new 0 97 498
put 2 97 499
assign 1 98 500
DIVIDE_ASSIGNGet 0 98 500
assign 1 98 501
new 0 98 501
put 2 98 502
assign 1 99 503
MODULUS_ASSIGNGet 0 99 503
assign 1 99 504
new 0 99 504
put 2 99 505
assign 1 100 506
AND_ASSIGNGet 0 100 506
assign 1 100 507
new 0 100 507
put 2 100 508
assign 1 101 509
OR_ASSIGNGet 0 101 509
assign 1 101 510
new 0 101 510
put 2 101 511
assign 1 102 512
ASSIGNGet 0 102 512
assign 1 102 513
new 0 102 513
put 2 102 514
assign 1 104 515
IFGet 0 104 515
assign 1 104 516
new 0 104 516
put 2 104 517
assign 1 105 518
ELIFGet 0 105 518
assign 1 105 519
new 0 105 519
put 2 105 520
assign 1 106 521
WHILEGet 0 106 521
assign 1 106 522
new 0 106 522
put 2 106 523
assign 1 107 524
FORGet 0 107 524
assign 1 107 525
new 0 107 525
put 2 107 526
assign 1 108 527
FOREACHGet 0 108 527
assign 1 108 528
new 0 108 528
put 2 108 529
assign 1 109 530
EMITGet 0 109 530
assign 1 109 531
new 0 109 531
put 2 109 532
assign 1 110 533
IFEMITGet 0 110 533
assign 1 110 534
new 0 110 534
put 2 110 535
assign 1 111 536
METHODGet 0 111 536
assign 1 111 537
new 0 111 537
put 2 111 538
assign 1 112 539
CLASSGet 0 112 539
assign 1 112 540
new 0 112 540
put 2 112 541
assign 1 113 542
EXPRGet 0 113 542
assign 1 113 543
new 0 113 543
put 2 113 544
assign 1 114 545
ELSEGet 0 114 545
assign 1 114 546
new 0 114 546
put 2 114 547
assign 1 115 548
FINALLYGet 0 115 548
assign 1 115 549
new 0 115 549
put 2 115 550
assign 1 116 551
TRYGet 0 116 551
assign 1 116 552
new 0 116 552
put 2 116 553
assign 1 117 554
LOOPGet 0 117 554
assign 1 117 555
new 0 117 555
put 2 117 556
assign 1 118 557
PROPERTIESGet 0 118 557
assign 1 118 558
new 0 118 558
put 2 118 559
assign 1 119 560
CATCHGet 0 119 560
assign 1 119 561
new 0 119 561
put 2 119 562
assign 1 120 563
TRANSUNITGet 0 120 563
assign 1 120 564
new 0 120 564
put 2 120 565
assign 1 121 566
BRACESGet 0 121 566
assign 1 121 567
new 0 121 567
put 2 121 568
assign 1 122 569
PARENSGet 0 122 569
assign 1 122 570
new 0 122 570
put 2 122 571
assign 1 123 572
IDXGet 0 123 572
assign 1 123 573
new 0 123 573
put 2 123 574
assign 1 125 575
IFGet 0 125 575
assign 1 125 576
new 0 125 576
put 2 125 577
assign 1 126 578
ELIFGet 0 126 578
assign 1 126 579
new 0 126 579
put 2 126 580
assign 1 127 581
WHILEGet 0 127 581
assign 1 127 582
new 0 127 582
put 2 127 583
assign 1 128 584
FORGet 0 128 584
assign 1 128 585
new 0 128 585
put 2 128 586
assign 1 129 587
FOREACHGet 0 129 587
assign 1 129 588
new 0 129 588
put 2 129 589
assign 1 130 590
EMITGet 0 130 590
assign 1 130 591
new 0 130 591
put 2 130 592
assign 1 131 593
IFEMITGet 0 131 593
assign 1 131 594
new 0 131 594
put 2 131 595
assign 1 132 596
METHODGet 0 132 596
assign 1 132 597
new 0 132 597
put 2 132 598
assign 1 133 599
CATCHGet 0 133 599
assign 1 133 600
new 0 133 600
put 2 133 601
assign 1 135 602
IFGet 0 135 602
assign 1 135 603
new 0 135 603
put 2 135 604
assign 1 136 605
ELIFGet 0 136 605
assign 1 136 606
new 0 136 606
put 2 136 607
assign 1 137 608
WHILEGet 0 137 608
assign 1 137 609
new 0 137 609
put 2 137 610
assign 1 138 611
FORGet 0 138 611
assign 1 138 612
new 0 138 612
put 2 138 613
assign 1 139 614
FOREACHGet 0 139 614
assign 1 139 615
new 0 139 615
put 2 139 616
assign 1 140 617
EXPRGet 0 140 617
assign 1 140 618
new 0 140 618
put 2 140 619
prepare 0 142 620
assign 1 148 734
new 0 148 734
assign 1 149 735
new 0 149 735
assign 1 151 736
new 0 151 736
assign 1 152 737
new 0 152 737
assign 1 152 738
new 2 152 738
assign 1 153 739
DIVIDEGet 0 153 739
put 2 153 740
assign 1 155 741
new 0 155 741
addToken 1 156 742
assign 1 157 743
BRACESGet 0 157 743
put 2 157 744
assign 1 159 745
new 0 159 745
addToken 1 160 746
assign 1 161 747
RBRACESGet 0 161 747
put 2 161 748
assign 1 163 749
new 0 163 749
addToken 1 164 750
assign 1 165 751
PARENSGet 0 165 751
put 2 165 752
assign 1 167 753
new 0 167 753
addToken 1 168 754
assign 1 169 755
RPARENSGet 0 169 755
put 2 169 756
assign 1 171 757
new 0 171 757
addToken 1 172 758
assign 1 173 759
SEMIGet 0 173 759
put 2 173 760
assign 1 175 761
new 0 175 761
addToken 1 176 762
assign 1 177 763
COLONGet 0 177 763
put 2 177 764
assign 1 179 765
new 0 179 765
addToken 1 180 766
assign 1 181 767
COMMAGet 0 181 767
put 2 181 768
assign 1 183 769
new 0 183 769
addToken 1 184 770
assign 1 185 771
ADDGet 0 185 771
put 2 185 772
assign 1 187 773
new 0 187 773
addToken 1 188 774
assign 1 189 775
ATYPEGet 0 189 775
put 2 189 776
assign 1 191 777
new 0 191 777
addToken 1 192 778
assign 1 193 779
SUBTRACTGet 0 193 779
put 2 193 780
assign 1 195 781
new 0 195 781
addToken 1 196 782
assign 1 197 783
ONCEGet 0 197 783
put 2 197 784
assign 1 199 785
new 0 199 785
addToken 1 200 786
assign 1 201 787
MANYGet 0 201 787
put 2 201 788
assign 1 205 789
new 0 205 789
assign 1 205 790
codeNew 1 205 790
addToken 1 207 791
assign 1 208 792
FSLASHGet 0 208 792
put 2 208 793
assign 1 210 794
new 0 210 794
assign 1 210 795
codeNew 1 210 795
addToken 1 212 796
assign 1 213 797
STRQGet 0 213 797
put 2 213 798
assign 1 215 799
new 0 215 799
assign 1 215 800
codeNew 1 215 800
addToken 1 217 801
assign 1 218 802
WSTRQGet 0 218 802
put 2 218 803
assign 1 220 804
new 0 220 804
assign 1 220 805
codeNew 1 220 805
addToken 1 222 806
assign 1 223 807
IDXGet 0 223 807
put 2 223 808
assign 1 225 809
new 0 225 809
assign 1 225 810
codeNew 1 225 810
addToken 1 227 811
assign 1 228 812
RIDXGet 0 228 812
put 2 228 813
assign 1 230 814
new 0 230 814
assign 1 230 815
codeNew 1 230 815
addToken 1 232 816
assign 1 233 817
MODULUSGet 0 233 817
put 2 233 818
assign 1 235 819
new 0 235 819
assign 1 235 820
codeNew 1 235 820
addToken 1 237 821
assign 1 238 822
ASSIGNGet 0 238 822
put 2 238 823
assign 1 240 824
new 0 240 824
assign 1 240 825
codeNew 1 240 825
addToken 1 242 826
assign 1 243 827
GREATERGet 0 243 827
put 2 243 828
assign 1 245 829
new 0 245 829
assign 1 245 830
codeNew 1 245 830
addToken 1 247 831
assign 1 248 832
LESSERGet 0 248 832
put 2 248 833
assign 1 250 834
new 0 250 834
assign 1 250 835
codeNew 1 250 835
addToken 1 252 836
assign 1 253 837
NOTGet 0 253 837
put 2 253 838
assign 1 255 839
new 0 255 839
assign 1 255 840
codeNew 1 255 840
addToken 1 257 841
assign 1 258 842
ANDGet 0 258 842
put 2 258 843
assign 1 260 844
new 0 260 844
assign 1 260 845
codeNew 1 260 845
addToken 1 262 846
assign 1 263 847
ORGet 0 263 847
put 2 263 848
assign 1 265 849
new 0 265 849
assign 1 265 850
codeNew 1 265 850
addToken 1 267 851
assign 1 268 852
MULTIPLYGet 0 268 852
put 2 268 853
assign 1 270 854
new 0 270 854
assign 1 270 855
codeNew 1 270 855
addToken 1 272 856
assign 1 273 857
DOTGet 0 273 857
put 2 273 858
assign 1 275 859
new 0 275 859
assign 1 275 860
codeNew 1 275 860
addToken 1 277 861
assign 1 278 862
SPACEGet 0 278 862
put 2 278 863
assign 1 280 864
new 0 280 864
assign 1 280 865
codeNew 1 280 865
addToken 1 282 866
assign 1 283 867
SPACEGet 0 283 867
put 2 283 868
assign 1 285 869
new 0 285 869
assign 1 285 870
newlineGet 0 285 870
addToken 1 287 871
assign 1 288 872
NEWLINEGet 0 288 872
put 2 288 873
assign 1 291 874
new 0 291 874
assign 1 292 875
new 0 292 875
assign 1 292 876
USEGet 0 292 876
put 2 292 877
assign 1 293 878
new 0 293 878
assign 1 293 879
ASGet 0 293 879
put 2 293 880
assign 1 294 881
new 0 294 881
assign 1 294 882
CLASSGet 0 294 882
put 2 294 883
assign 1 295 884
new 0 295 884
assign 1 295 885
METHODGet 0 295 885
put 2 295 886
assign 1 296 887
new 0 296 887
assign 1 296 888
DEFMODGet 0 296 888
put 2 296 889
assign 1 297 890
new 0 297 890
assign 1 297 891
DEFMODGet 0 297 891
put 2 297 892
assign 1 298 893
new 0 298 893
assign 1 298 894
DEFMODGet 0 298 894
put 2 298 895
assign 1 299 896
new 0 299 896
assign 1 299 897
VARGet 0 299 897
put 2 299 898
assign 1 300 899
new 0 300 899
assign 1 300 900
VARGet 0 300 900
put 2 300 901
assign 1 301 902
new 0 301 902
assign 1 301 903
IFGet 0 301 903
put 2 301 904
assign 1 302 905
new 0 302 905
assign 1 302 906
IFGet 0 302 906
put 2 302 907
assign 1 303 908
new 0 303 908
assign 1 303 909
ELIFGet 0 303 909
put 2 303 910
assign 1 304 911
new 0 304 911
assign 1 304 912
ELSEGet 0 304 912
put 2 304 913
assign 1 305 914
new 0 305 914
assign 1 305 915
FINALLYGet 0 305 915
put 2 305 916
assign 1 306 917
new 0 306 917
assign 1 306 918
LOOPGet 0 306 918
put 2 306 919
assign 1 307 920
new 0 307 920
assign 1 307 921
PROPERTIESGet 0 307 921
put 2 307 922
assign 1 308 923
new 0 308 923
assign 1 308 924
WHILEGet 0 308 924
put 2 308 925
assign 1 309 926
new 0 309 926
assign 1 309 927
WHILEGet 0 309 927
put 2 309 928
assign 1 310 929
new 0 310 929
assign 1 310 930
FORGet 0 310 930
put 2 310 931
assign 1 311 932
new 0 311 932
assign 1 311 933
INGet 0 311 933
put 2 311 934
assign 1 312 935
new 0 312 935
assign 1 312 936
EMITGet 0 312 936
put 2 312 937
assign 1 313 938
new 0 313 938
assign 1 313 939
IFEMITGet 0 313 939
put 2 313 940
assign 1 314 941
new 0 314 941
assign 1 314 942
IFEMITGet 0 314 942
put 2 314 943
assign 1 315 944
new 0 315 944
assign 1 315 945
BREAKGet 0 315 945
put 2 315 946
assign 1 316 947
new 0 316 947
assign 1 316 948
CONTINUEGet 0 316 948
put 2 316 949
assign 1 317 950
new 0 317 950
assign 1 317 951
NULLGet 0 317 951
put 2 317 952
assign 1 318 953
new 0 318 953
assign 1 318 954
TRUEGet 0 318 954
put 2 318 955
assign 1 319 956
new 0 319 956
assign 1 319 957
FALSEGet 0 319 957
put 2 319 958
assign 1 320 959
new 0 320 959
assign 1 320 960
TRYGet 0 320 960
put 2 320 961
assign 1 321 962
new 0 321 962
assign 1 321 963
CATCHGet 0 321 963
put 2 321 964
return 1 0 968
assign 1 0 971
return 1 0 975
assign 1 0 978
return 1 0 982
assign 1 0 985
return 1 0 989
assign 1 0 992
return 1 0 996
assign 1 0 999
return 1 0 1003
assign 1 0 1006
return 1 0 1010
assign 1 0 1013
return 1 0 1017
assign 1 0 1020
return 1 0 1024
assign 1 0 1027
return 1 0 1031
assign 1 0 1034
return 1 0 1038
assign 1 0 1041
return 1 0 1045
assign 1 0 1048
return 1 0 1052
assign 1 0 1055
return 1 0 1059
assign 1 0 1062
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 499424269: return bem_operNamesGet_0();
case -1012494862: return bem_once_0();
case 1820417453: return bem_create_0();
case -729571811: return bem_serializeToString_0();
case -1182494494: return bem_toAny_0();
case -667821230: return bem_parensReqGet_0();
case 1774940957: return bem_toString_0();
case -1081412016: return bem_many_0();
case -634261936: return bem_rwordsGet_0();
case -1011420424: return bem_prepare_0();
case -314718434: return bem_print_0();
case -1308786538: return bem_echo_0();
case 521161323: return bem_unwindToGet_0();
case 264093610: return bem_unwindOkGet_0();
case 1503762842: return bem_twtokGet_0();
case -1354714650: return bem_copy_0();
case -1323554192: return bem_matchMapGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -485024848: return bem_conTypesGet_0();
case -845792839: return bem_iteratorGet_0();
case 1638254553: return bem_operGet_0();
case 1284159779: return bem_anchorTypesGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case -1260156474: return bem_maxargsGet_0();
case -614472113: return bem_mtdxPadGet_0();
case -644675716: return bem_ntypesGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 2055025483: return bem_serializeContents_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -786424307: return bem_tagGet_0();
case -895284094: return bem_extraSlotsGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1514845095: return bem_twtokSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -656738977: return bem_parensReqSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 510506522: return bem_operNamesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1249074221: return bem_maxargsSet_1(bevd_0);
case -623179683: return bem_rwordsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -603389860: return bem_mtdxPadSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1649336806: return bem_operSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1295242032: return bem_anchorTypesSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -884201841: return bem_extraSlotsSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1312471939: return bem_matchMapSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 532243576: return bem_unwindToSet_1(bevd_0);
case -473942595: return bem_conTypesSet_1(bevd_0);
case 275175863: return bem_unwindOkSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildConstants();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildConstants.bevs_inst = (BEC_2_5_9_BuildConstants)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildConstants.bevs_inst;
}
}
}
