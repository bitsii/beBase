namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_4_ContainerLinkedListNode : BEC_2_6_6_SystemObject {
public BEC_3_9_10_4_ContainerLinkedListNode() { }
static BEC_3_9_10_4_ContainerLinkedListNode() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_3_9_10_4_ContainerLinkedListNode bevs_inst;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_prior;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_next;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_2_9_10_ContainerLinkedList bevp_mylist;
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_new_2(BEC_2_6_6_SystemObject beva__held, BEC_2_9_10_ContainerLinkedList beva__mylist) {
bevp_held = beva__held;
bevp_mylist = beva__mylist;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_insertBefore_1(BEC_2_6_6_SystemObject beva_toIns) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_toIns.bemd_1(957596394, BEL_4_Base.bevn_priorSet_1, null);
beva_toIns.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, this);
beva_toIns.bemd_1(-1838097046, BEL_4_Base.bevn_mylistSet_1, bevp_mylist);
bevl_p = bevp_prior;
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) beva_toIns;
if (bevl_p == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevp_mylist.bem_firstNodeSet_1(beva_toIns);
} /* Line: 60 */
 else  /* Line: 61 */ {
bevl_p.bem_nextSet_1(beva_toIns);
beva_toIns.bemd_1(957596394, BEL_4_Base.bevn_priorSet_1, bevl_p);
} /* Line: 63 */
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_delete_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevl_p = bevp_prior;
bevl_n = bevp_next;
bevp_next = null;
bevp_prior = null;
if (bevl_p == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevp_mylist.bem_firstNodeSet_1(bevl_n);
if (bevl_n == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 75 */ {
bevl_n.bem_priorSet_1(null);
} /* Line: 76 */
 else  /* Line: 77 */ {
bevp_mylist.bem_lastNodeSet_1(bevl_n);
} /* Line: 79 */
} /* Line: 75 */
 else  /* Line: 72 */ {
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevl_p.bem_nextSet_1(bevl_n);
bevp_mylist.bem_lastNodeSet_1(bevl_p);
} /* Line: 84 */
 else  /* Line: 85 */ {
bevl_p.bem_nextSet_1(bevl_n);
bevl_n.bem_priorSet_1(bevl_p);
} /* Line: 88 */
} /* Line: 72 */
bevp_mylist = null;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_priorGet_0() {
return bevp_prior;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_priorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_nextGet_0() {
return bevp_next;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_nextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_next = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_heldGet_0() {
return bevp_held;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_mylistGet_0() {
return bevp_mylist;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_mylistSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mylist = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {45, 46, 53, 54, 55, 56, 57, 58, 58, 60, 62, 63, 68, 69, 70, 71, 72, 72, 74, 75, 75, 76, 79, 81, 81, 83, 84, 87, 88, 90, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 21, 22, 23, 24, 25, 26, 31, 32, 35, 36, 46, 47, 48, 49, 50, 55, 56, 57, 62, 63, 66, 70, 75, 76, 77, 80, 81, 84, 88, 91, 95, 98, 102, 105, 109, 112};
/* BEGIN LINEINFO 
assign 1 45 14
assign 1 46 15
priorSet 1 53 21
nextSet 1 54 22
mylistSet 1 55 23
assign 1 56 24
assign 1 57 25
assign 1 58 26
undef 1 58 31
firstNodeSet 1 60 32
nextSet 1 62 35
priorSet 1 63 36
assign 1 68 46
assign 1 69 47
assign 1 70 48
assign 1 71 49
assign 1 72 50
undef 1 72 55
firstNodeSet 1 74 56
assign 1 75 57
def 1 75 62
priorSet 1 76 63
lastNodeSet 1 79 66
assign 1 81 70
undef 1 81 75
nextSet 1 83 76
lastNodeSet 1 84 77
nextSet 1 87 80
priorSet 1 88 81
assign 1 90 84
return 1 0 88
assign 1 0 91
return 1 0 95
assign 1 0 98
return 1 0 102
assign 1 0 105
return 1 0 109
assign 1 0 112
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 931239762: return bem_heldGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 946514141: return bem_priorGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case -1849179299: return bem_mylistGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case 819712668: return bem_delete_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 957596394: return bem_priorSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 942322015: return bem_heldSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1838097046: return bem_mylistSet_1(bevd_0);
case -1505376950: return bem_insertBefore_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 104713555: return bem_new_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_10_4_ContainerLinkedListNode();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_10_4_ContainerLinkedListNode.bevs_inst = (BEC_3_9_10_4_ContainerLinkedListNode)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_10_4_ContainerLinkedListNode.bevs_inst;
}
}
}
