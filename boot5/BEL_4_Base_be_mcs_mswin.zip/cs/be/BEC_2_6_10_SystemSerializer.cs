namespace be {
/* IO:File: source/extended/Serialize.be */
public sealed class BEC_2_6_10_SystemSerializer : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemSerializer() { }
static BEC_2_6_10_SystemSerializer() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x7C};
private static byte[] bels_1 = {0x23};
private static byte[] bels_2 = {0x26};
private static byte[] bels_3 = {0x40};
private static byte[] bels_4 = {0x3B};
private static byte[] bels_5 = {0x3F};
private static byte[] bels_6 = {0x5E};
private static byte[] bels_7 = {0x23};
private static byte[] bels_8 = {0x3B};
private static byte[] bels_9 = {0x7C};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_10 = {};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_10, 0));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_11 = {0x70,0x6F,0x73,0x74,0x44,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65};
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bevo_11 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_12 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static byte[] bels_13 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
private static BEC_2_4_3_MathInt bevo_16 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bevo_17 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
public static new BEC_2_6_10_SystemSerializer bevs_inst;
public BEC_2_4_6_TextString bevp_group;
public BEC_2_4_6_TextString bevp_defineReference;
public BEC_2_4_6_TextString bevp_getReference;
public BEC_2_4_6_TextString bevp_constructString;
public BEC_2_4_6_TextString bevp_nullMark;
public BEC_2_4_6_TextString bevp_getClassTag;
public BEC_2_4_6_TextString bevp_shift;
public BEC_2_4_6_TextString bevp_defineClassTag;
public BEC_2_4_6_TextString bevp_multiNullMark;
public BEC_2_4_6_TextString bevp_endGroup;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_6_3_EncodeHex bevp_encoder;
public BEC_2_5_4_LogicBool bevp_saveIdentity;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_1));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_2));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_5));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_6));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_7));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_8));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_9));
this.bem_new_10(bevt_0_tmpany_phold, bevt_1_tmpany_phold, bevt_2_tmpany_phold, bevt_3_tmpany_phold, bevt_4_tmpany_phold, bevt_5_tmpany_phold, bevt_6_tmpany_phold, bevt_7_tmpany_phold, bevt_8_tmpany_phold, bevt_9_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_new_10(BEC_2_4_6_TextString beva__group, BEC_2_4_6_TextString beva__defineReference, BEC_2_4_6_TextString beva__getReference, BEC_2_4_6_TextString beva__constructString, BEC_2_4_6_TextString beva__nullMark, BEC_2_4_6_TextString beva__getClassTag, BEC_2_4_6_TextString beva__shift, BEC_2_4_6_TextString beva__defineClassTag, BEC_2_4_6_TextString beva__multiNullMark, BEC_2_4_6_TextString beva__endGroup) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
bevp_group = beva__group;
bevp_defineReference = beva__defineReference;
bevp_getReference = beva__getReference;
bevp_constructString = beva__constructString;
bevp_nullMark = beva__nullMark;
bevp_getClassTag = beva__getClassTag;
bevp_shift = beva__shift;
bevp_defineClassTag = beva__defineClassTag;
bevp_multiNullMark = beva__multiNullMark;
bevp_endGroup = beva__endGroup;
bevt_6_tmpany_phold = bevp_group.bem_add_1(bevp_defineReference);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevp_getReference);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevp_constructString);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevp_nullMark);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_defineClassTag);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_getClassTag);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_shift);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_toker = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_tmpany_phold, bevt_7_tmpany_phold);
bevp_encoder = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bevs_inst;
bevp_saveIdentity = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serialize_1(BEC_2_6_6_SystemObject beva_instance) {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
this.bem_serialize_2(beva_instance, bevl_res);
return bevl_res;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serialize_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_instWriter) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_6_10_7_SystemSerializerSession bevt_1_tmpany_phold = null;
if (beva_instance == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 93 */ {
bevt_1_tmpany_phold = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_1(beva_instWriter);
this.bem_serializeI_2(beva_instance, bevt_1_tmpany_phold);
} /* Line: 94 */
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeI_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
this.bem_defineInstance_2(beva_instance, (BEC_3_6_10_7_SystemSerializerSession) beva_session);
bevt_0_tmpany_phold = beva_instance.bemd_0(2055025483, BEL_4_Base.bevn_serializeContents_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 100 */ {
this.bem_serializeC_2(beva_instance, beva_session);
} /* Line: 101 */
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeC_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) {
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_3_MathInt bevl_multiNull = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
bevl_instWriter = beva_session.bemd_0(1940066990, BEL_4_Base.bevn_instWriterGet_0);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = beva_instance.bemd_0(2117559209, BEL_4_Base.bevn_serializationIteratorGet_0);
bevt_0_tmpany_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 109 */ {
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_group);
while (true)
 /* Line: 111 */ {
bevt_1_tmpany_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 111 */ {
bevl_i = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_i == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevl_multiNull = bevl_multiNull.bem_increment_0();
} /* Line: 115 */
 else  /* Line: 116 */ {
bevt_4_tmpany_phold = bevo_0;
if (bevl_multiNull.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 120 */
 else  /* Line: 118 */ {
bevt_6_tmpany_phold = bevo_1;
if (bevl_multiNull.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 121 */ {
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_nullMark);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 124 */
 else  /* Line: 118 */ {
bevt_8_tmpany_phold = bevo_2;
if (bevl_multiNull.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_shift);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_nullMark);
bevt_9_tmpany_phold = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_9_tmpany_phold);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 129 */
} /* Line: 118 */
} /* Line: 118 */
if (bevp_saveIdentity.bevi_bool) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevl_instSerial = null;
} /* Line: 132 */
 else  /* Line: 133 */ {
bevt_11_tmpany_phold = beva_session.bemd_0(-1942660042, BEL_4_Base.bevn_uniqueGet_0);
bevl_instSerial = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
} /* Line: 134 */
if (bevl_instSerial == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 136 */ {
this.bem_serializeI_2(bevl_i, beva_session);
} /* Line: 138 */
 else  /* Line: 139 */ {
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_getReference);
bevt_13_tmpany_phold = bevl_instSerial.bem_toString_0();
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_13_tmpany_phold);
} /* Line: 142 */
} /* Line: 136 */
} /* Line: 113 */
 else  /* Line: 111 */ {
break;
} /* Line: 111 */
} /* Line: 111 */
bevt_15_tmpany_phold = bevo_3;
if (bevl_multiNull.bevi_int == bevt_15_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 147 */ {
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 149 */
 else  /* Line: 147 */ {
bevt_17_tmpany_phold = bevo_4;
if (bevl_multiNull.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 150 */ {
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_nullMark);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 153 */
 else  /* Line: 147 */ {
bevt_19_tmpany_phold = bevo_5;
if (bevl_multiNull.bevi_int > bevt_19_tmpany_phold.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_shift);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_nullMark);
bevt_20_tmpany_phold = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_20_tmpany_phold);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 158 */
} /* Line: 147 */
} /* Line: 147 */
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_shift);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_group);
} /* Line: 161 */
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineInstance_2(BEC_2_6_6_SystemObject beva_instance, BEC_3_6_10_7_SystemSerializerSession beva_session) {
BEC_2_4_3_MathInt bevl_scount = null;
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_6_TextString bevl_instClass = null;
BEC_2_4_3_MathInt bevl_instClassTag = null;
BEC_2_4_6_TextString bevl_instClassTagStr = null;
BEC_2_4_6_TextString bevl_serializedString = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_11_ContainerIdentityMap bevt_13_tmpany_phold = null;
bevl_scount = beva_session.bem_serialCountGet_0();
bevt_2_tmpany_phold = bevo_6;
bevt_1_tmpany_phold = bevl_scount.bem_add_1(bevt_2_tmpany_phold);
beva_session.bem_serialCountSet_1(bevt_1_tmpany_phold);
bevl_instWriter = beva_session.bem_instWriterGet_0();
bevl_instClass = (BEC_2_4_6_TextString) beva_instance.bemd_0(-35631997, BEL_4_Base.bevn_deserializeClassNameGet_0);
bevt_3_tmpany_phold = beva_session.bem_classTagMapGet_0();
bevl_instClassTag = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_get_1(bevl_instClass);
if (bevl_instClassTag == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevl_instClassTag = beva_session.bem_classTagCountGet_0();
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
bevt_6_tmpany_phold = bevo_7;
bevt_5_tmpany_phold = bevl_instClassTag.bem_add_1(bevt_6_tmpany_phold);
beva_session.bem_classTagCountSet_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = beva_session.bem_classTagMapGet_0();
bevt_7_tmpany_phold.bem_put_2(bevl_instClass, bevl_instClassTag);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_shift);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_defineClassTag);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevl_instClass);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_shift);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_defineClassTag);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevl_instClassTagStr);
} /* Line: 182 */
 else  /* Line: 183 */ {
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
} /* Line: 184 */
if (bevp_saveIdentity.bevi_bool) /* Line: 186 */ {
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_defineReference);
bevt_8_tmpany_phold = bevl_scount.bem_toString_0();
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_8_tmpany_phold);
} /* Line: 188 */
bevl_serializedString = (BEC_2_4_6_TextString) beva_instance.bemd_0(-729571811, BEL_4_Base.bevn_serializeToString_0);
if (bevl_serializedString == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevt_11_tmpany_phold = bevo_8;
bevt_10_tmpany_phold = bevl_serializedString.bem_notEquals_1(bevt_11_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
 else  /* Line: 191 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 191 */ {
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_constructString);
bevt_12_tmpany_phold = bevp_encoder.bem_encode_1(bevl_serializedString);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_12_tmpany_phold);
} /* Line: 193 */
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_getClassTag);
bevl_instWriter.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevl_instClassTagStr);
if (bevp_saveIdentity.bevi_bool) /* Line: 197 */ {
bevt_13_tmpany_phold = beva_session.bem_uniqueGet_0();
bevt_13_tmpany_phold.bem_put_2(beva_instance, bevl_scount);
} /* Line: 198 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserialize_1(BEC_2_6_6_SystemObject beva_instReader) {
BEC_2_4_3_MathInt bevl_state = null;
BEC_2_9_4_ContainerList bevl_postDeserialize = null;
BEC_3_6_10_7_SystemSerializerSession bevl_session = null;
BEC_2_9_5_ContainerStack bevl_iterStack = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_9_3_ContainerMap bevl_instances = null;
BEC_2_6_6_SystemObject bevl_rootInst = null;
BEC_2_6_6_SystemObject bevl_groupInstIter = null;
BEC_2_4_6_TextString bevl_defineClassTagName = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_token = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_4_6_TextString bevl_instString = null;
BEC_2_4_3_MathInt bevl_glassTagVal = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_6_6_SystemObject bevl_inst = null;
BEC_2_4_3_MathInt bevl_defineClassTagValue = null;
BEC_2_4_3_MathInt bevl_multiNullCount = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_postDeserialize = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_session = (BEC_3_6_10_7_SystemSerializerSession) (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_0();
bevl_iterStack = (BEC_2_9_5_ContainerStack) (new BEC_2_9_5_ContainerStack()).bem_new_0();
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_1_tmpany_phold = beva_instReader.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevt_2_tmpany_phold);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 207 */ {
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(beva_instReader);
} /* Line: 208 */
 else  /* Line: 209 */ {
bevt_4_tmpany_phold = beva_instReader.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(bevt_4_tmpany_phold);
} /* Line: 210 */
bevl_instances = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_i = bevl_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 216 */ {
bevt_5_tmpany_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 216 */ {
bevl_token = (BEC_2_4_6_TextString) bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_7_tmpany_phold = bevo_9;
if (bevl_state.bevi_int == bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_8_tmpany_phold = bevl_token.bem_equals_1(bevp_defineReference);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 220 */
 else  /* Line: 219 */ {
bevt_9_tmpany_phold = bevl_token.bem_equals_1(bevp_constructString);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
} /* Line: 222 */
 else  /* Line: 219 */ {
bevt_10_tmpany_phold = bevl_token.bem_equals_1(bevp_getClassTag);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
} /* Line: 224 */
 else  /* Line: 219 */ {
bevt_11_tmpany_phold = bevl_token.bem_equals_1(bevp_shift);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1000));
} /* Line: 226 */
 else  /* Line: 219 */ {
bevt_12_tmpany_phold = bevl_token.bem_equals_1(bevp_getReference);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
} /* Line: 228 */
 else  /* Line: 219 */ {
bevt_13_tmpany_phold = bevl_token.bem_equals_1(bevp_nullMark);
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 229 */ {
if (bevl_groupInstIter == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 231 */ {
bevl_groupInstIter.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, null);
} /* Line: 232 */
} /* Line: 231 */
 else  /* Line: 219 */ {
bevt_15_tmpany_phold = bevl_token.bem_equals_1(bevp_group);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 234 */ {
if (bevl_inst == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 236 */ {
if (bevl_groupInstIter == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevl_iterStack.bem_push_1(bevl_groupInstIter);
} /* Line: 238 */
bevl_groupInstIter = bevl_inst.bemd_0(2117559209, BEL_4_Base.bevn_serializationIteratorGet_0);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_11));
bevt_20_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_18_tmpany_phold = bevl_groupInstIter.bemd_2(94427011, BEL_4_Base.bevn_can_2, bevt_19_tmpany_phold, bevt_20_tmpany_phold);
if (bevt_18_tmpany_phold != null && bevt_18_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpany_phold).bevi_bool) /* Line: 241 */ {
bevl_postDeserialize.bem_addValue_1(bevl_groupInstIter);
} /* Line: 242 */
} /* Line: 241 */
} /* Line: 236 */
} /* Line: 219 */
} /* Line: 219 */
} /* Line: 219 */
} /* Line: 219 */
} /* Line: 219 */
} /* Line: 219 */
} /* Line: 219 */
 else  /* Line: 218 */ {
bevt_22_tmpany_phold = bevo_10;
if (bevl_state.bevi_int == bevt_22_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 246 */ {
bevt_23_tmpany_phold = bevl_token.bem_equals_1(bevp_defineClassTag);
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 248 */ {
if (bevl_defineClassTagName == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 249 */ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
} /* Line: 250 */
 else  /* Line: 251 */ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
} /* Line: 252 */
} /* Line: 249 */
 else  /* Line: 248 */ {
bevt_25_tmpany_phold = bevl_token.bem_equals_1(bevp_multiNullMark);
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 254 */ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
} /* Line: 255 */
 else  /* Line: 248 */ {
bevt_26_tmpany_phold = bevl_token.bem_equals_1(bevp_group);
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 256 */ {
bevl_groupInstIter = bevl_iterStack.bem_pop_0();
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 259 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
 else  /* Line: 261 */ {
bevt_28_tmpany_phold = bevo_11;
if (bevl_state.bevi_int == bevt_28_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 262 */ {
if (bevp_saveIdentity.bevi_bool) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(73, bels_12));
bevt_30_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_31_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_30_tmpany_phold);
} /* Line: 264 */
bevl_instSerial = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 267 */
 else  /* Line: 262 */ {
bevt_33_tmpany_phold = bevo_12;
if (bevl_state.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevl_instString = bevp_encoder.bem_decode_1(bevl_token);
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 270 */
 else  /* Line: 262 */ {
bevt_35_tmpany_phold = bevo_13;
if (bevl_state.bevi_int == bevt_35_tmpany_phold.bevi_int) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 271 */ {
bevl_glassTagVal = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_36_tmpany_phold = bevl_session.bem_classTagMapGet_0();
bevl_klass = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bem_get_1(bevl_glassTagVal);
bevt_38_tmpany_phold = this.bem_createInstance_1(bevl_klass);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(-458330056, BEL_4_Base.bevn_deserializeFromStringNew_1, bevl_instString);
bevl_inst = bevt_37_tmpany_phold.bemd_1(-2047949204, BEL_4_Base.bevn_deserializeFromString_1, bevl_instString);
if (bevl_rootInst == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 275 */ {
bevl_rootInst = bevl_inst;
} /* Line: 276 */
if (bevp_saveIdentity.bevi_bool) /* Line: 278 */ {
bevl_instances.bem_put_2(bevl_instSerial, bevl_inst);
} /* Line: 279 */
bevl_instString = null;
if (bevl_groupInstIter == null) {
bevt_40_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 283 */ {
bevl_groupInstIter.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, bevl_inst);
} /* Line: 284 */
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 286 */
 else  /* Line: 262 */ {
bevt_42_tmpany_phold = bevo_14;
if (bevl_state.bevi_int == bevt_42_tmpany_phold.bevi_int) {
bevt_41_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_41_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_41_tmpany_phold.bevi_bool) /* Line: 287 */ {
if (bevp_saveIdentity.bevi_bool) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 288 */ {
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(66, bels_13));
bevt_44_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_45_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_44_tmpany_phold);
} /* Line: 289 */
bevl_instSerial = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_inst = bevl_instances.bem_get_1(bevl_instSerial);
if (bevl_groupInstIter == null) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 293 */ {
bevl_groupInstIter.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, bevl_inst);
} /* Line: 294 */
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 296 */
 else  /* Line: 262 */ {
bevt_48_tmpany_phold = bevo_15;
if (bevl_state.bevi_int == bevt_48_tmpany_phold.bevi_int) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevl_defineClassTagName = bevl_token;
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 299 */
 else  /* Line: 262 */ {
bevt_50_tmpany_phold = bevo_16;
if (bevl_state.bevi_int == bevt_50_tmpany_phold.bevi_int) {
bevt_49_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_49_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevl_defineClassTagValue = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_51_tmpany_phold = bevl_session.bem_classTagMapGet_0();
bevt_51_tmpany_phold.bem_put_2(bevl_defineClassTagValue, bevl_defineClassTagName);
bevl_defineClassTagName = null;
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 305 */
 else  /* Line: 262 */ {
bevt_53_tmpany_phold = bevo_17;
if (bevl_state.bevi_int == bevt_53_tmpany_phold.bevi_int) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 306 */ {
if (bevl_groupInstIter == null) {
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_54_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 308 */ {
bevl_multiNullCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_groupInstIter.bemd_1(-900559503, BEL_4_Base.bevn_skip_1, bevl_multiNullCount);
} /* Line: 310 */
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 312 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 262 */
} /* Line: 218 */
} /* Line: 218 */
 else  /* Line: 216 */ {
break;
} /* Line: 216 */
} /* Line: 216 */
bevl_inst = null;
bevt_0_tmpany_loop = bevl_postDeserialize.bem_iteratorGet_0();
while (true)
 /* Line: 317 */ {
bevt_55_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_55_tmpany_phold != null && bevt_55_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_55_tmpany_phold).bevi_bool) /* Line: 317 */ {
bevl_groupInstIter = bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_groupInstIter.bemd_0(-510157136, BEL_4_Base.bevn_postDeserialize_0);
} /* Line: 318 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
return bevl_rootInst;
} /*method end*/
public BEC_2_4_6_TextString bem_groupGet_0() {
return bevp_group;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_groupSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_group = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineReferenceGet_0() {
return bevp_defineReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getReferenceGet_0() {
return bevp_getReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_constructStringGet_0() {
return bevp_constructString;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_constructStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullMarkGet_0() {
return bevp_nullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_nullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getClassTagGet_0() {
return bevp_getClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shiftGet_0() {
return bevp_shift;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_shiftSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineClassTagGet_0() {
return bevp_defineClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_multiNullMarkGet_0() {
return bevp_multiNullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_multiNullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_endGroupGet_0() {
return bevp_endGroup;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_endGroupSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGet_0() {
return bevp_toker;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_encoderGet_0() {
return bevp_encoder;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_encoderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdentityGet_0() {
return bevp_saveIdentity;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_saveIdentitySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 78, 78, 78, 78, 78, 78, 78, 79, 77, 81, 82, 87, 88, 89, 93, 93, 94, 94, 99, 100, 101, 106, 107, 108, 109, 110, 111, 112, 113, 113, 115, 118, 118, 118, 119, 120, 121, 121, 121, 122, 123, 124, 125, 125, 125, 126, 127, 128, 128, 129, 131, 131, 132, 134, 134, 136, 136, 138, 141, 142, 142, 147, 147, 147, 148, 149, 150, 150, 150, 151, 152, 153, 154, 154, 154, 155, 156, 157, 157, 158, 160, 161, 166, 167, 167, 167, 169, 170, 171, 171, 172, 172, 173, 174, 175, 175, 175, 176, 176, 177, 178, 179, 180, 181, 182, 184, 187, 188, 188, 190, 191, 191, 191, 191, 0, 0, 0, 192, 193, 193, 195, 196, 198, 198, 203, 204, 205, 206, 207, 207, 207, 208, 210, 210, 212, 216, 216, 217, 218, 218, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 231, 231, 232, 234, 236, 236, 237, 237, 238, 240, 241, 241, 241, 242, 246, 246, 246, 248, 249, 249, 250, 252, 254, 255, 256, 258, 259, 262, 262, 262, 263, 263, 264, 264, 264, 266, 267, 268, 268, 268, 269, 270, 271, 271, 271, 272, 273, 273, 274, 274, 274, 275, 275, 276, 279, 281, 283, 283, 284, 286, 287, 287, 287, 288, 288, 289, 289, 289, 291, 292, 293, 293, 294, 296, 297, 297, 297, 298, 299, 300, 300, 300, 302, 303, 303, 304, 305, 306, 306, 306, 308, 308, 309, 310, 312, 316, 317, 0, 317, 317, 318, 320, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 112, 113, 114, 119, 124, 125, 126, 132, 133, 135, 166, 167, 168, 169, 171, 174, 176, 177, 182, 183, 186, 187, 192, 193, 194, 197, 198, 203, 204, 205, 206, 209, 210, 215, 216, 217, 218, 219, 220, 224, 229, 230, 233, 234, 236, 241, 242, 245, 246, 247, 255, 256, 261, 262, 263, 266, 267, 272, 273, 274, 275, 278, 279, 284, 285, 286, 287, 288, 289, 293, 294, 319, 320, 321, 322, 323, 324, 325, 326, 327, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 348, 351, 352, 353, 355, 356, 361, 362, 363, 365, 368, 372, 375, 376, 377, 379, 380, 382, 383, 462, 463, 464, 465, 466, 467, 468, 470, 473, 474, 476, 477, 480, 482, 483, 484, 489, 490, 492, 495, 497, 500, 502, 505, 507, 510, 512, 515, 517, 522, 523, 527, 529, 534, 535, 540, 541, 543, 544, 545, 546, 548, 560, 561, 566, 567, 569, 574, 575, 578, 582, 584, 587, 589, 590, 596, 597, 602, 603, 608, 609, 610, 611, 613, 614, 617, 618, 623, 624, 625, 628, 629, 634, 635, 636, 637, 638, 639, 640, 641, 646, 647, 650, 652, 653, 658, 659, 661, 664, 665, 670, 671, 676, 677, 678, 679, 681, 682, 683, 688, 689, 691, 694, 695, 700, 701, 702, 705, 706, 711, 712, 713, 714, 715, 716, 719, 720, 725, 726, 731, 732, 733, 735, 750, 751, 751, 754, 756, 757, 763, 766, 769, 773, 776, 780, 783, 787, 790, 794, 797, 801, 804, 808, 811, 815, 818, 822, 825, 829, 832, 836, 839, 843, 846, 850, 853};
/* BEGIN LINEINFO 
assign 1 61 65
new 0 61 65
assign 1 61 66
new 0 61 66
assign 1 61 67
new 0 61 67
assign 1 61 68
new 0 61 68
assign 1 61 69
new 0 61 69
assign 1 61 70
new 0 61 70
assign 1 61 71
new 0 61 71
assign 1 61 72
new 0 61 72
assign 1 61 73
new 0 61 73
assign 1 61 74
new 0 61 74
new 10 61 75
assign 1 67 87
assign 1 68 88
assign 1 69 89
assign 1 70 90
assign 1 71 91
assign 1 72 92
assign 1 73 93
assign 1 74 94
assign 1 75 95
assign 1 76 96
assign 1 78 97
add 1 78 97
assign 1 78 98
add 1 78 98
assign 1 78 99
add 1 78 99
assign 1 78 100
add 1 78 100
assign 1 78 101
add 1 78 101
assign 1 78 102
add 1 78 102
assign 1 78 103
add 1 78 103
assign 1 79 104
new 0 79 104
assign 1 77 105
new 2 77 105
assign 1 81 106
new 0 81 106
assign 1 82 107
new 0 82 107
assign 1 87 112
new 0 87 112
serialize 2 88 113
return 1 89 114
assign 1 93 119
def 1 93 124
assign 1 94 125
new 1 94 125
serializeI 2 94 126
defineInstance 2 99 132
assign 1 100 133
serializeContents 0 100 133
serializeC 2 101 135
assign 1 106 166
instWriterGet 0 106 166
assign 1 107 167
new 0 107 167
assign 1 108 168
serializationIteratorGet 0 108 168
assign 1 109 169
hasNextGet 0 109 169
write 1 110 171
assign 1 111 174
hasNextGet 0 111 174
assign 1 112 176
nextGet 0 112 176
assign 1 113 177
undef 1 113 182
assign 1 115 183
increment 0 115 183
assign 1 118 186
new 0 118 186
assign 1 118 187
equals 1 118 192
write 1 119 193
assign 1 120 194
new 0 120 194
assign 1 121 197
new 0 121 197
assign 1 121 198
equals 1 121 203
write 1 122 204
write 1 123 205
assign 1 124 206
new 0 124 206
assign 1 125 209
new 0 125 209
assign 1 125 210
greater 1 125 215
write 1 126 216
write 1 127 217
assign 1 128 218
toString 0 128 218
write 1 128 219
assign 1 129 220
new 0 129 220
assign 1 131 224
not 0 131 229
assign 1 132 230
assign 1 134 233
uniqueGet 0 134 233
assign 1 134 234
get 1 134 234
assign 1 136 236
undef 1 136 241
serializeI 2 138 242
write 1 141 245
assign 1 142 246
toString 0 142 246
write 1 142 247
assign 1 147 255
new 0 147 255
assign 1 147 256
equals 1 147 261
write 1 148 262
assign 1 149 263
new 0 149 263
assign 1 150 266
new 0 150 266
assign 1 150 267
equals 1 150 272
write 1 151 273
write 1 152 274
assign 1 153 275
new 0 153 275
assign 1 154 278
new 0 154 278
assign 1 154 279
greater 1 154 284
write 1 155 285
write 1 156 286
assign 1 157 287
toString 0 157 287
write 1 157 288
assign 1 158 289
new 0 158 289
write 1 160 293
write 1 161 294
assign 1 166 319
serialCountGet 0 166 319
assign 1 167 320
new 0 167 320
assign 1 167 321
add 1 167 321
serialCountSet 1 167 322
assign 1 169 323
instWriterGet 0 169 323
assign 1 170 324
deserializeClassNameGet 0 170 324
assign 1 171 325
classTagMapGet 0 171 325
assign 1 171 326
get 1 171 326
assign 1 172 327
undef 1 172 332
assign 1 173 333
classTagCountGet 0 173 333
assign 1 174 334
toString 0 174 334
assign 1 175 335
new 0 175 335
assign 1 175 336
add 1 175 336
classTagCountSet 1 175 337
assign 1 176 338
classTagMapGet 0 176 338
put 2 176 339
write 1 177 340
write 1 178 341
write 1 179 342
write 1 180 343
write 1 181 344
write 1 182 345
assign 1 184 348
toString 0 184 348
write 1 187 351
assign 1 188 352
toString 0 188 352
write 1 188 353
assign 1 190 355
serializeToString 0 190 355
assign 1 191 356
def 1 191 361
assign 1 191 362
new 0 191 362
assign 1 191 363
notEquals 1 191 363
assign 1 0 365
assign 1 0 368
assign 1 0 372
write 1 192 375
assign 1 193 376
encode 1 193 376
write 1 193 377
write 1 195 379
write 1 196 380
assign 1 198 382
uniqueGet 0 198 382
put 2 198 383
assign 1 203 462
new 0 203 462
assign 1 204 463
new 0 204 463
assign 1 205 464
new 0 205 464
assign 1 206 465
new 0 206 465
assign 1 207 466
new 0 207 466
assign 1 207 467
emptyGet 0 207 467
assign 1 207 468
sameType 1 207 468
assign 1 208 470
tokenize 1 208 470
assign 1 210 473
readString 0 210 473
assign 1 210 474
tokenize 1 210 474
assign 1 212 476
new 0 212 476
assign 1 216 477
linkedListIteratorGet 0 216 477
assign 1 216 480
hasNextGet 0 216 480
assign 1 217 482
nextGet 0 217 482
assign 1 218 483
new 0 218 483
assign 1 218 484
equals 1 218 489
assign 1 219 490
equals 1 219 490
assign 1 220 492
new 0 220 492
assign 1 221 495
equals 1 221 495
assign 1 222 497
new 0 222 497
assign 1 223 500
equals 1 223 500
assign 1 224 502
new 0 224 502
assign 1 225 505
equals 1 225 505
assign 1 226 507
new 0 226 507
assign 1 227 510
equals 1 227 510
assign 1 228 512
new 0 228 512
assign 1 229 515
equals 1 229 515
assign 1 231 517
def 1 231 522
nextSet 1 232 523
assign 1 234 527
equals 1 234 527
assign 1 236 529
def 1 236 534
assign 1 237 535
def 1 237 540
push 1 238 541
assign 1 240 543
serializationIteratorGet 0 240 543
assign 1 241 544
new 0 241 544
assign 1 241 545
new 0 241 545
assign 1 241 546
can 2 241 546
addValue 1 242 548
assign 1 246 560
new 0 246 560
assign 1 246 561
equals 1 246 566
assign 1 248 567
equals 1 248 567
assign 1 249 569
undef 1 249 574
assign 1 250 575
new 0 250 575
assign 1 252 578
new 0 252 578
assign 1 254 582
equals 1 254 582
assign 1 255 584
new 0 255 584
assign 1 256 587
equals 1 256 587
assign 1 258 589
pop 0 258 589
assign 1 259 590
new 0 259 590
assign 1 262 596
new 0 262 596
assign 1 262 597
equals 1 262 602
assign 1 263 603
not 0 263 608
assign 1 264 609
new 0 264 609
assign 1 264 610
new 1 264 610
throw 1 264 611
assign 1 266 613
new 1 266 613
assign 1 267 614
new 0 267 614
assign 1 268 617
new 0 268 617
assign 1 268 618
equals 1 268 623
assign 1 269 624
decode 1 269 624
assign 1 270 625
new 0 270 625
assign 1 271 628
new 0 271 628
assign 1 271 629
equals 1 271 634
assign 1 272 635
new 1 272 635
assign 1 273 636
classTagMapGet 0 273 636
assign 1 273 637
get 1 273 637
assign 1 274 638
createInstance 1 274 638
assign 1 274 639
deserializeFromStringNew 1 274 639
assign 1 274 640
deserializeFromString 1 274 640
assign 1 275 641
undef 1 275 646
assign 1 276 647
put 2 279 650
assign 1 281 652
assign 1 283 653
def 1 283 658
nextSet 1 284 659
assign 1 286 661
new 0 286 661
assign 1 287 664
new 0 287 664
assign 1 287 665
equals 1 287 670
assign 1 288 671
not 0 288 676
assign 1 289 677
new 0 289 677
assign 1 289 678
new 1 289 678
throw 1 289 679
assign 1 291 681
new 1 291 681
assign 1 292 682
get 1 292 682
assign 1 293 683
def 1 293 688
nextSet 1 294 689
assign 1 296 691
new 0 296 691
assign 1 297 694
new 0 297 694
assign 1 297 695
equals 1 297 700
assign 1 298 701
assign 1 299 702
new 0 299 702
assign 1 300 705
new 0 300 705
assign 1 300 706
equals 1 300 711
assign 1 302 712
new 1 302 712
assign 1 303 713
classTagMapGet 0 303 713
put 2 303 714
assign 1 304 715
assign 1 305 716
new 0 305 716
assign 1 306 719
new 0 306 719
assign 1 306 720
equals 1 306 725
assign 1 308 726
def 1 308 731
assign 1 309 732
new 1 309 732
skip 1 310 733
assign 1 312 735
new 0 312 735
assign 1 316 750
assign 1 317 751
iteratorGet 0 0 751
assign 1 317 754
hasNextGet 0 317 754
assign 1 317 756
nextGet 0 317 756
postDeserialize 0 318 757
return 1 320 763
return 1 0 766
assign 1 0 769
return 1 0 773
assign 1 0 776
return 1 0 780
assign 1 0 783
return 1 0 787
assign 1 0 790
return 1 0 794
assign 1 0 797
return 1 0 801
assign 1 0 804
return 1 0 808
assign 1 0 811
return 1 0 815
assign 1 0 818
return 1 0 822
assign 1 0 825
return 1 0 829
assign 1 0 832
return 1 0 836
assign 1 0 839
return 1 0 843
assign 1 0 846
return 1 0 850
assign 1 0 853
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1650286650: return bem_multiNullMarkGet_0();
case -19301941: return bem_encoderGet_0();
case -1081412016: return bem_many_0();
case 1397144963: return bem_endGroupGet_0();
case -1188477033: return bem_defineReferenceGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 504430835: return bem_nullMarkGet_0();
case 1102720804: return bem_classNameGet_0();
case -2013171286: return bem_defineClassTagGet_0();
case -845792839: return bem_iteratorGet_0();
case -786424307: return bem_tagGet_0();
case 1259892296: return bem_groupGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1911308837: return bem_shiftGet_0();
case -1462470753: return bem_constructStringGet_0();
case 193407370: return bem_tokerGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -799346705: return bem_getClassTagGet_0();
case 1820417453: return bem_create_0();
case -729571811: return bem_serializeToString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1354714650: return bem_copy_0();
case -1945828116: return bem_saveIdentityGet_0();
case 2080346610: return bem_getReferenceGet_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1408227216: return bem_endGroupSet_1(bevd_0);
case 1270974549: return bem_groupSet_1(bevd_0);
case 2091428863: return bem_getReferenceSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -8219688: return bem_encoderSet_1(bevd_0);
case -2002089033: return bem_defineClassTagSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -480771215: return bem_deserialize_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1661368903: return bem_multiNullMarkSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1934745863: return bem_saveIdentitySet_1(bevd_0);
case -868745803: return bem_forwardCall_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 204489623: return bem_tokerSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -788264452: return bem_getClassTagSet_1(bevd_0);
case 1922391090: return bem_shiftSet_1(bevd_0);
case 515513088: return bem_nullMarkSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1451388500: return bem_constructStringSet_1(bevd_0);
case -1177394780: return bem_defineReferenceSet_1(bevd_0);
case -1357694318: return bem_serialize_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 466409251: return bem_defineInstance_2(bevd_0, (BEC_3_6_10_7_SystemSerializerSession) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 861129436: return bem_serializeI_2(bevd_0, bevd_1);
case 861123670: return bem_serializeC_2(bevd_0, bevd_1);
case -1357694317: return bem_serialize_2(bevd_0, bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_x(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5, BEC_2_6_6_SystemObject bevd_6, BEC_2_6_6_SystemObject[] bevd_x) {
switch (callHash) {
case -1048847074: return bem_new_10((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4, (BEC_2_4_6_TextString) bevd_5, (BEC_2_4_6_TextString) bevd_6, (BEC_2_4_6_TextString) bevd_x[0], (BEC_2_4_6_TextString) bevd_x[1], (BEC_2_4_6_TextString) bevd_x[2]);
}
return base.bemd_x(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5, bevd_6, bevd_x);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemSerializer();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemSerializer.bevs_inst = (BEC_2_6_10_SystemSerializer)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemSerializer.bevs_inst;
}
}
}
