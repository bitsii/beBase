namespace be {
/* IO:File: source/build/Pass7.be */
public sealed class BEC_3_5_5_5_BuildVisitPass7 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
static BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_0 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_2 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_3 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_5 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_6 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass7_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass7_bels_6, 41));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_7 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_8 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_9 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_10 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_13 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_15 = {0x6E,0x65,0x77};
public static new BEC_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_4_3_MathInt bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_3_MathInt bevt_43_ta_ph = null;
BEC_2_4_3_MathInt bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_5_4_BuildNode bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_4_3_MathInt bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_4_3_MathInt bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
BEC_2_4_3_MathInt bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_6_6_SystemObject bevt_91_ta_ph = null;
BEC_2_5_4_LogicBool bevt_92_ta_ph = null;
BEC_2_5_4_LogicBool bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_5_4_LogicBool bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_4_3_MathInt bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_6_6_SystemObject bevt_99_ta_ph = null;
BEC_2_6_6_SystemObject bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
BEC_2_6_6_SystemObject bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_104_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_105_ta_ph = null;
BEC_2_6_6_SystemObject bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_4_3_MathInt bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_6_6_SystemObject bevt_110_ta_ph = null;
BEC_2_5_4_LogicBool bevt_111_ta_ph = null;
BEC_2_5_4_LogicBool bevt_112_ta_ph = null;
BEC_2_5_4_LogicBool bevt_113_ta_ph = null;
BEC_2_6_6_SystemObject bevt_114_ta_ph = null;
BEC_2_6_6_SystemObject bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_117_ta_ph = null;
BEC_2_4_6_TextString bevt_118_ta_ph = null;
BEC_2_6_6_SystemObject bevt_119_ta_ph = null;
BEC_2_6_6_SystemObject bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_122_ta_ph = null;
BEC_2_4_6_TextString bevt_123_ta_ph = null;
BEC_2_5_4_LogicBool bevt_124_ta_ph = null;
BEC_2_5_4_LogicBool bevt_125_ta_ph = null;
BEC_2_5_4_LogicBool bevt_126_ta_ph = null;
BEC_2_4_3_MathInt bevt_127_ta_ph = null;
BEC_2_4_3_MathInt bevt_128_ta_ph = null;
BEC_2_5_4_LogicBool bevt_129_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_130_ta_ph = null;
BEC_2_4_6_TextString bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_4_3_MathInt bevt_133_ta_ph = null;
BEC_2_4_3_MathInt bevt_134_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_135_ta_ph = null;
BEC_2_4_6_TextString bevt_136_ta_ph = null;
BEC_2_4_3_MathInt bevt_137_ta_ph = null;
BEC_2_5_4_LogicBool bevt_138_ta_ph = null;
BEC_2_4_3_MathInt bevt_139_ta_ph = null;
BEC_2_4_3_MathInt bevt_140_ta_ph = null;
BEC_2_5_4_LogicBool bevt_141_ta_ph = null;
BEC_2_5_4_LogicBool bevt_142_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_143_ta_ph = null;
BEC_2_4_6_TextString bevt_144_ta_ph = null;
BEC_2_6_6_SystemObject bevt_145_ta_ph = null;
BEC_2_6_6_SystemObject bevt_146_ta_ph = null;
BEC_2_4_3_MathInt bevt_147_ta_ph = null;
BEC_2_5_4_LogicBool bevt_148_ta_ph = null;
BEC_2_6_6_SystemObject bevt_149_ta_ph = null;
BEC_2_6_6_SystemObject bevt_150_ta_ph = null;
BEC_2_4_3_MathInt bevt_151_ta_ph = null;
BEC_2_4_3_MathInt bevt_152_ta_ph = null;
BEC_2_6_6_SystemObject bevt_153_ta_ph = null;
BEC_2_5_4_LogicBool bevt_154_ta_ph = null;
BEC_2_4_3_MathInt bevt_155_ta_ph = null;
BEC_2_4_3_MathInt bevt_156_ta_ph = null;
BEC_2_5_4_LogicBool bevt_157_ta_ph = null;
BEC_2_4_3_MathInt bevt_158_ta_ph = null;
BEC_2_4_3_MathInt bevt_159_ta_ph = null;
BEC_2_6_6_SystemObject bevt_160_ta_ph = null;
BEC_2_6_6_SystemObject bevt_161_ta_ph = null;
BEC_2_6_6_SystemObject bevt_162_ta_ph = null;
BEC_2_6_6_SystemObject bevt_163_ta_ph = null;
BEC_2_6_6_SystemObject bevt_164_ta_ph = null;
BEC_2_5_4_LogicBool bevt_165_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_166_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_167_ta_ph = null;
BEC_2_6_6_SystemObject bevt_168_ta_ph = null;
BEC_2_6_6_SystemObject bevt_169_ta_ph = null;
BEC_2_4_3_MathInt bevt_170_ta_ph = null;
BEC_2_5_4_BuildNode bevt_171_ta_ph = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_ta_ph = beva_node.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 38*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_ta_ph.bemd_0(-932925423);
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(-958162796);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_ta_ph.bemd_0(-1990292643);
} /* Line: 40*/
if (bevp_inClassNp == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 42*/ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 44*/
bevt_16_ta_ph = beva_node.bem_typenameGet_0();
bevt_17_ta_ph = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_ta_ph.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 46*/ {
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass7_bels_0));
bevp_build.bem_buildLiteral_2(beva_node, bevt_18_ta_ph);
} /* Line: 47*/
bevt_20_ta_ph = beva_node.bem_typenameGet_0();
bevt_21_ta_ph = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_ta_ph.bevi_int == bevt_21_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_1));
bevp_build.bem_buildLiteral_2(beva_node, bevt_22_ta_ph);
} /* Line: 50*/
bevt_24_ta_ph = beva_node.bem_typenameGet_0();
bevt_25_ta_ph = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_ta_ph.bevi_int == bevt_25_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 52*/ {
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_26_ta_ph);
} /* Line: 53*/
bevt_28_ta_ph = beva_node.bem_typenameGet_0();
bevt_29_ta_ph = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_ta_ph.bevi_int == bevt_29_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 55*/ {
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_30_ta_ph);
bevt_31_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_ta_ph);
} /* Line: 58*/
bevt_33_ta_ph = beva_node.bem_typenameGet_0();
bevt_34_ta_ph = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_ta_ph.bevi_int == bevt_34_ta_ph.bevi_int) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 60*/ {
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass7_bels_3));
beva_node.bem_heldSet_1(bevt_35_ta_ph);
bevt_36_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_4));
bevp_build.bem_buildLiteral_2(beva_node, bevt_36_ta_ph);
} /* Line: 62*/
bevt_38_ta_ph = beva_node.bem_typenameGet_0();
bevt_39_ta_ph = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_ta_ph.bevi_int == bevt_39_ta_ph.bevi_int) {
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 68*/ {
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_5));
beva_node.bem_heldSet_1(bevt_40_ta_ph);
bevt_41_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_4));
bevp_build.bem_buildLiteral_2(beva_node, bevt_41_ta_ph);
} /* Line: 70*/
 else /* Line: 68*/ {
bevt_43_ta_ph = beva_node.bem_typenameGet_0();
bevt_44_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_43_ta_ph.bevi_int == bevt_44_ta_ph.bevi_int) {
bevt_42_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_42_ta_ph.bevi_bool)/* Line: 72*/ {
bevt_47_ta_ph = beva_node.bem_heldGet_0();
bevt_46_ta_ph = bevt_47_ta_ph.bemd_0(1321300955);
bevt_45_ta_ph = bevt_46_ta_ph.bemd_0(560923354);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 72*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 72*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 72*/
 else /* Line: 72*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 72*/ {
bevt_50_ta_ph = beva_node.bem_heldGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bemd_0(-916206427);
if (bevt_49_ta_ph == null) {
bevt_48_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_48_ta_ph.bevi_bool)/* Line: 73*/ {
if (bevl_nnode == null) {
bevt_51_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_51_ta_ph.bevi_bool)/* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 73*/ {
bevt_53_ta_ph = bevl_nnode.bemd_0(1963473742);
bevt_54_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_52_ta_ph = bevt_53_ta_ph.bemd_1(-840953319, bevt_54_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_52_ta_ph).bevi_bool)/* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 73*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 73*/
 else /* Line: 73*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 73*/ {
bevt_57_ta_ph = bece_BEC_3_5_5_5_BuildVisitPass7_bevo_0;
bevt_59_ta_ph = beva_node.bem_heldGet_0();
bevt_58_ta_ph = bevt_59_ta_ph.bemd_0(-916206427);
bevt_56_ta_ph = bevt_57_ta_ph.bem_add_1(bevt_58_ta_ph);
bevt_55_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_55_ta_ph);
} /* Line: 74*/
 else /* Line: 75*/ {
bevt_60_ta_ph = beva_node.bem_heldGet_0();
bevt_61_ta_ph = bevl_nnode.bemd_0(1712678790);
bevt_60_ta_ph.bemd_1(1258888420, bevt_61_ta_ph);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(-413902581);
bevt_62_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_62_ta_ph;
} /* Line: 82*/
} /* Line: 73*/
 else /* Line: 68*/ {
bevt_64_ta_ph = beva_node.bem_typenameGet_0();
bevt_65_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_64_ta_ph.bevi_int == bevt_65_ta_ph.bevi_int) {
bevt_63_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_63_ta_ph.bevi_bool)/* Line: 84*/ {
if (bevl_nnode == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 85*/ {
bevt_68_ta_ph = bevl_nnode.bemd_0(1963473742);
bevt_69_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_67_ta_ph = bevt_68_ta_ph.bemd_1(354557818, bevt_69_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_67_ta_ph).bevi_bool)/* Line: 85*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 85*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 85*/
 else /* Line: 85*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 85*/ {
bevt_71_ta_ph = bevl_nnode.bemd_0(-1599063965);
if (bevt_71_ta_ph == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 86*/ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_ta_ph = bevl_nnode.bemd_0(-1599063965);
bevl_ii = bevt_72_ta_ph.bemd_0(-2014542803);
while (true)
/* Line: 88*/ {
bevt_73_ta_ph = bevl_ii.bemd_0(-1024297580);
if (((BEC_2_5_4_LogicBool) bevt_73_ta_ph).bevi_bool)/* Line: 88*/ {
bevl_i = bevl_ii.bemd_0(-12961780);
bevt_75_ta_ph = bevl_i.bemd_0(1963473742);
bevt_76_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_74_ta_ph = bevt_75_ta_ph.bemd_1(354557818, bevt_76_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_74_ta_ph).bevi_bool)/* Line: 90*/ {
bevl_toremove.bemd_1(-2013138183, bevl_i);
} /* Line: 91*/
} /* Line: 90*/
 else /* Line: 88*/ {
break;
} /* Line: 88*/
} /* Line: 88*/
bevl_ii = bevl_toremove.bemd_0(-2014542803);
while (true)
/* Line: 94*/ {
bevt_77_ta_ph = bevl_ii.bemd_0(-1024297580);
if (((BEC_2_5_4_LogicBool) bevt_77_ta_ph).bevi_bool)/* Line: 94*/ {
bevl_i = bevl_ii.bemd_0(-12961780);
bevl_i.bemd_0(-413902581);
} /* Line: 96*/
 else /* Line: 94*/ {
break;
} /* Line: 94*/
} /* Line: 94*/
} /* Line: 94*/
bevl_pc = bevl_nnode;
bevt_78_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(-472405841, bevt_78_ta_ph);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_ta_ph = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1258888420, bevt_79_ta_ph);
bevl_pc.bemd_1(-120156714, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 107*/ {
bevt_82_ta_ph = bevl_dnode.bemd_0(1963473742);
bevt_83_ta_ph = bevp_ntypes.bem_DOTGet_0();
bevt_81_ta_ph = bevt_82_ta_ph.bemd_1(354557818, bevt_83_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_81_ta_ph).bevi_bool)/* Line: 107*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 107*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 107*/
 else /* Line: 107*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 107*/ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(-265327833);
if (bevl_onode == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 109*/ {
bevt_86_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(38, bece_BEC_3_5_5_5_BuildVisitPass7_bels_7));
bevt_85_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_85_ta_ph);
} /* Line: 110*/
 else /* Line: 109*/ {
bevt_88_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_89_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_ta_ph.bevi_int == bevt_89_ta_ph.bevi_int) {
bevt_87_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_87_ta_ph.bevi_bool)/* Line: 111*/ {
bevt_91_ta_ph = bevl_gc.bemd_0(-916206427);
bevt_90_ta_ph = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_ta_ph );
if (bevt_90_ta_ph.bevi_bool)/* Line: 112*/ {
bevt_92_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1283818210, bevt_92_ta_ph);
bevt_93_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1115876672, bevt_93_ta_ph);
bevt_94_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-765547484, bevt_94_ta_ph);
} /* Line: 115*/
 else /* Line: 116*/ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 117*/
} /* Line: 112*/
 else /* Line: 109*/ {
bevt_96_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_97_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_96_ta_ph.bevi_int == bevt_97_ta_ph.bevi_int) {
bevt_95_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_95_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_95_ta_ph.bevi_bool)/* Line: 119*/ {
bevt_101_ta_ph = beva_node.bem_transUnitGet_0();
bevt_100_ta_ph = bevt_101_ta_ph.bemd_0(1712678790);
bevt_99_ta_ph = bevt_100_ta_ph.bemd_0(1781881204);
bevt_102_ta_ph = bevl_onode.bem_heldGet_0();
bevt_98_ta_ph = bevt_99_ta_ph.bemd_1(-1210716049, bevt_102_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_98_ta_ph).bevi_bool)/* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 119*/ {
bevt_105_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_104_ta_ph = bevt_105_ta_ph.bem_aliasedGet_0();
bevt_106_ta_ph = bevl_onode.bem_heldGet_0();
bevt_103_ta_ph = bevt_104_ta_ph.bem_has_1(bevt_106_ta_ph);
if (bevt_103_ta_ph.bevi_bool)/* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 119*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 119*/
 else /* Line: 119*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 119*/ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_ta_ph = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_ta_ph);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_ta_ph);
bevl_onode.bem_resolveNp_0();
bevt_110_ta_ph = bevl_gc.bemd_0(-916206427);
bevt_109_ta_ph = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_ta_ph );
if (bevt_109_ta_ph.bevi_bool)/* Line: 125*/ {
bevt_111_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1283818210, bevt_111_ta_ph);
bevt_112_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1115876672, bevt_112_ta_ph);
bevt_113_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-765547484, bevt_113_ta_ph);
} /* Line: 128*/
 else /* Line: 129*/ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 130*/
} /* Line: 125*/
 else /* Line: 109*/ {
bevt_115_ta_ph = bevl_gc.bemd_0(-916206427);
bevt_116_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass7_bels_8));
bevt_114_ta_ph = bevt_115_ta_ph.bemd_1(354557818, bevt_116_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_114_ta_ph).bevi_bool)/* Line: 132*/ {
bevt_118_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(70, bece_BEC_3_5_5_5_BuildVisitPass7_bels_9));
bevt_117_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_117_ta_ph);
} /* Line: 133*/
 else /* Line: 109*/ {
bevt_120_ta_ph = bevl_gc.bemd_0(-916206427);
bevt_121_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_10));
bevt_119_ta_ph = bevt_120_ta_ph.bemd_1(354557818, bevt_121_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_119_ta_ph).bevi_bool)/* Line: 134*/ {
bevt_123_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_3_5_5_5_BuildVisitPass7_bels_11));
bevt_122_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_122_ta_ph);
} /* Line: 135*/
} /* Line: 109*/
} /* Line: 109*/
} /* Line: 109*/
} /* Line: 109*/
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(1714123500, bevl_onode);
bevl_dnode.bemd_0(-413902581);
} /* Line: 140*/
 else /* Line: 141*/ {
bevt_124_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1115876672, bevt_124_ta_ph);
bevt_125_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1283818210, bevt_125_ta_ph);
} /* Line: 143*/
} /* Line: 107*/
} /* Line: 85*/
 else /* Line: 68*/ {
bevt_127_ta_ph = beva_node.bem_typenameGet_0();
bevt_128_ta_ph = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_ta_ph.bevi_int == bevt_128_ta_ph.bevi_int) {
bevt_126_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_126_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_126_ta_ph.bevi_bool)/* Line: 147*/ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_129_ta_ph.bevi_bool)/* Line: 151*/ {
bevt_131_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_12));
bevt_130_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_130_ta_ph);
} /* Line: 152*/
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_134_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_ta_ph.bevi_int == bevt_134_ta_ph.bevi_int) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 156*/ {
bevt_136_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(84, bece_BEC_3_5_5_5_BuildVisitPass7_bels_13));
bevt_135_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_135_ta_ph);
} /* Line: 157*/
bevt_137_ta_ph = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_ta_ph);
} /* Line: 159*/
 else /* Line: 68*/ {
bevt_139_ta_ph = beva_node.bem_typenameGet_0();
bevt_140_ta_ph = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_ta_ph.bevi_int == bevt_140_ta_ph.bevi_int) {
bevt_138_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_138_ta_ph.bevi_bool)/* Line: 160*/ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_141_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_141_ta_ph.bevi_bool)/* Line: 165*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 165*/ {
if (bevl_onode == null) {
bevt_142_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_142_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_142_ta_ph.bevi_bool)/* Line: 165*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 165*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 165*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 165*/ {
bevt_144_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_14));
bevt_143_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_143_ta_ph);
} /* Line: 166*/
bevt_146_ta_ph = bevl_nnode.bemd_0(1963473742);
bevt_147_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_145_ta_ph = bevt_146_ta_ph.bemd_1(354557818, bevt_147_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_145_ta_ph).bevi_bool)/* Line: 168*/ {
bevl_pnode = bevl_nnode.bemd_0(716594440);
if (bevl_pnode == null) {
bevt_148_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_148_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 170*/ {
bevt_150_ta_ph = bevl_pnode.bemd_0(1963473742);
bevt_151_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_149_ta_ph = bevt_150_ta_ph.bemd_1(-840953319, bevt_151_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_149_ta_ph).bevi_bool)/* Line: 170*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 170*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 170*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 170*/ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_ta_ph = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_ta_ph);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_ta_ph = bevl_nnode.bemd_0(1712678790);
bevl_ga.bemd_1(1258888420, bevt_153_ta_ph);
bevl_nnode.bemd_0(-413902581);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_156_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_ta_ph.bevi_int == bevt_156_ta_ph.bevi_int) {
bevt_154_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_154_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_154_ta_ph.bevi_bool)/* Line: 179*/ {
bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 180*/
 else /* Line: 179*/ {
bevt_158_ta_ph = bevl_onode.bem_typenameGet_0();
bevt_159_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_158_ta_ph.bevi_int == bevt_159_ta_ph.bevi_int) {
bevt_157_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_157_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_157_ta_ph.bevi_bool)/* Line: 181*/ {
bevt_163_ta_ph = beva_node.bem_transUnitGet_0();
bevt_162_ta_ph = bevt_163_ta_ph.bemd_0(1712678790);
bevt_161_ta_ph = bevt_162_ta_ph.bemd_0(1781881204);
bevt_164_ta_ph = bevl_onode.bem_heldGet_0();
bevt_160_ta_ph = bevt_161_ta_ph.bemd_1(-1210716049, bevt_164_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_160_ta_ph).bevi_bool)/* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 181*/ {
bevt_167_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_166_ta_ph = bevt_167_ta_ph.bem_aliasedGet_0();
bevt_168_ta_ph = bevl_onode.bem_heldGet_0();
bevt_165_ta_ph = bevt_166_ta_ph.bem_has_1(bevt_168_ta_ph);
if (bevt_165_ta_ph.bevi_bool)/* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 181*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 181*/
 else /* Line: 181*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 181*/ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_ta_ph = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_ta_ph);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_ta_ph);
bevl_onode.bem_resolveNp_0();
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 187*/
} /* Line: 179*/
} /* Line: 179*/
} /* Line: 170*/
} /* Line: 168*/
} /* Line: 68*/
} /* Line: 68*/
} /* Line: 68*/
} /* Line: 68*/
bevt_171_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_171_ta_ph;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_ta_ph);
bevt_1_ta_ph = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_ta_ph);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (BEC_2_5_4_BuildCall) (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass7_bels_15));
bevl_gnc.bem_nameSet_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_ta_ph);
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_ta_ph);
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_ta_ph);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGetDirect_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGetDirect_0() {
return bevp_inFile;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {35, 38, 38, 38, 38, 39, 39, 40, 40, 40, 42, 42, 43, 44, 46, 46, 46, 46, 47, 47, 49, 49, 49, 49, 50, 50, 52, 52, 52, 52, 53, 53, 55, 55, 55, 55, 57, 57, 58, 58, 60, 60, 60, 60, 61, 61, 62, 62, 68, 68, 68, 68, 69, 69, 70, 70, 72, 72, 72, 72, 72, 72, 72, 0, 0, 0, 73, 73, 73, 73, 73, 73, 0, 73, 73, 73, 0, 0, 0, 0, 0, 74, 74, 74, 74, 74, 74, 76, 76, 76, 77, 78, 82, 82, 84, 84, 84, 84, 85, 85, 85, 85, 85, 0, 0, 0, 86, 86, 86, 87, 88, 88, 88, 89, 90, 90, 90, 91, 94, 94, 95, 96, 99, 100, 100, 101, 102, 102, 103, 104, 105, 106, 107, 107, 107, 107, 107, 0, 0, 0, 108, 109, 109, 110, 110, 110, 111, 111, 111, 111, 112, 112, 113, 113, 114, 114, 115, 115, 117, 119, 119, 119, 119, 119, 119, 119, 119, 119, 0, 119, 119, 119, 119, 0, 0, 0, 0, 0, 120, 121, 121, 122, 123, 123, 124, 125, 125, 126, 126, 127, 127, 128, 128, 130, 132, 132, 132, 133, 133, 133, 134, 134, 134, 135, 135, 135, 138, 139, 140, 142, 142, 143, 143, 147, 147, 147, 147, 150, 151, 151, 152, 152, 152, 154, 155, 156, 156, 156, 156, 157, 157, 157, 159, 159, 160, 160, 160, 160, 162, 165, 165, 0, 165, 165, 0, 0, 166, 166, 166, 168, 168, 168, 169, 170, 170, 0, 170, 170, 170, 0, 0, 171, 172, 172, 173, 174, 174, 175, 176, 177, 178, 179, 179, 179, 179, 180, 181, 181, 181, 181, 181, 181, 181, 181, 181, 0, 181, 181, 181, 181, 0, 0, 0, 0, 0, 182, 183, 183, 184, 185, 185, 186, 187, 192, 192, 196, 197, 198, 198, 199, 199, 200, 202, 203, 203, 204, 204, 205, 205, 206, 206, 207, 207, 208, 209, 209, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {221, 222, 223, 224, 229, 230, 231, 232, 233, 234, 236, 241, 242, 243, 245, 246, 247, 252, 253, 254, 256, 257, 258, 263, 264, 265, 267, 268, 269, 274, 275, 276, 278, 279, 280, 285, 286, 287, 288, 289, 291, 292, 293, 298, 299, 300, 301, 302, 304, 305, 306, 311, 312, 313, 314, 315, 318, 319, 320, 325, 326, 327, 328, 330, 333, 337, 340, 341, 342, 347, 348, 353, 354, 357, 358, 359, 361, 364, 368, 371, 375, 378, 379, 380, 381, 382, 383, 386, 387, 388, 389, 390, 391, 392, 396, 397, 398, 403, 404, 409, 410, 411, 412, 414, 417, 421, 424, 425, 430, 431, 432, 433, 436, 438, 439, 440, 441, 443, 450, 453, 455, 456, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 478, 479, 480, 481, 483, 486, 490, 493, 494, 499, 500, 501, 502, 505, 506, 507, 512, 513, 514, 516, 517, 518, 519, 520, 521, 524, 528, 529, 530, 535, 536, 537, 538, 539, 540, 542, 545, 546, 547, 548, 550, 553, 557, 560, 564, 567, 568, 569, 570, 571, 572, 573, 574, 575, 577, 578, 579, 580, 581, 582, 585, 589, 590, 591, 593, 594, 595, 598, 599, 600, 602, 603, 604, 610, 611, 612, 615, 616, 617, 618, 623, 624, 625, 630, 631, 632, 637, 638, 639, 640, 642, 643, 644, 645, 646, 651, 652, 653, 654, 656, 657, 660, 661, 662, 667, 668, 669, 674, 675, 678, 683, 684, 687, 691, 692, 693, 695, 696, 697, 699, 700, 705, 706, 709, 710, 711, 713, 716, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 737, 738, 741, 742, 743, 748, 749, 750, 751, 752, 753, 755, 758, 759, 760, 761, 763, 766, 770, 773, 777, 780, 781, 782, 783, 784, 785, 786, 787, 797, 798, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 835, 838, 841, 845, 849, 852, 855, 859};
/* BEGIN LINEINFO 
assign 1 35 221
nextPeerGet 0 35 221
assign 1 38 222
typenameGet 0 38 222
assign 1 38 223
CLASSGet 0 38 223
assign 1 38 224
equals 1 38 229
assign 1 39 230
heldGet 0 39 230
assign 1 39 231
namepathGet 0 39 231
assign 1 40 232
heldGet 0 40 232
assign 1 40 233
fromFileGet 0 40 233
assign 1 40 234
toString 0 40 234
assign 1 42 236
def 1 42 241
inClassNpSet 1 43 242
inFileSet 1 44 243
assign 1 46 245
typenameGet 0 46 245
assign 1 46 246
INTLGet 0 46 246
assign 1 46 247
equals 1 46 252
assign 1 47 253
new 0 47 253
buildLiteral 2 47 254
assign 1 49 256
typenameGet 0 49 256
assign 1 49 257
FLOATLGet 0 49 257
assign 1 49 258
equals 1 49 263
assign 1 50 264
new 0 50 264
buildLiteral 2 50 265
assign 1 52 267
typenameGet 0 52 267
assign 1 52 268
STRINGLGet 0 52 268
assign 1 52 269
equals 1 52 274
assign 1 53 275
new 0 53 275
buildLiteral 2 53 276
assign 1 55 278
typenameGet 0 55 278
assign 1 55 279
WSTRINGLGet 0 55 279
assign 1 55 280
equals 1 55 285
assign 1 57 286
new 0 57 286
buildLiteral 2 57 287
assign 1 58 288
new 0 58 288
wideStringSet 1 58 289
assign 1 60 291
typenameGet 0 60 291
assign 1 60 292
TRUEGet 0 60 292
assign 1 60 293
equals 1 60 298
assign 1 61 299
new 0 61 299
heldSet 1 61 300
assign 1 62 301
new 0 62 301
buildLiteral 2 62 302
assign 1 68 304
typenameGet 0 68 304
assign 1 68 305
FALSEGet 0 68 305
assign 1 68 306
equals 1 68 311
assign 1 69 312
new 0 69 312
heldSet 1 69 313
assign 1 70 314
new 0 70 314
buildLiteral 2 70 315
assign 1 72 318
typenameGet 0 72 318
assign 1 72 319
VARGet 0 72 319
assign 1 72 320
equals 1 72 325
assign 1 72 326
heldGet 0 72 326
assign 1 72 327
isArgGet 0 72 327
assign 1 72 328
not 0 72 328
assign 1 0 330
assign 1 0 333
assign 1 0 337
assign 1 73 340
heldGet 0 73 340
assign 1 73 341
nameGet 0 73 341
assign 1 73 342
undef 1 73 347
assign 1 73 348
undef 1 73 353
assign 1 0 354
assign 1 73 357
typenameGet 0 73 357
assign 1 73 358
IDGet 0 73 358
assign 1 73 359
notEquals 1 73 359
assign 1 0 361
assign 1 0 364
assign 1 0 368
assign 1 0 371
assign 1 0 375
assign 1 74 378
new 0 74 378
assign 1 74 379
heldGet 0 74 379
assign 1 74 380
nameGet 0 74 380
assign 1 74 381
add 1 74 381
assign 1 74 382
new 2 74 382
throw 1 74 383
assign 1 76 386
heldGet 0 76 386
assign 1 76 387
heldGet 0 76 387
nameSet 1 76 388
addVariable 0 77 389
delete 0 78 390
assign 1 82 391
nextDescendGet 0 82 391
return 1 82 392
assign 1 84 396
typenameGet 0 84 396
assign 1 84 397
IDGet 0 84 397
assign 1 84 398
equals 1 84 403
assign 1 85 404
def 1 85 409
assign 1 85 410
typenameGet 0 85 410
assign 1 85 411
PARENSGet 0 85 411
assign 1 85 412
equals 1 85 412
assign 1 0 414
assign 1 0 417
assign 1 0 421
assign 1 86 424
containedGet 0 86 424
assign 1 86 425
def 1 86 430
assign 1 87 431
new 0 87 431
assign 1 88 432
containedGet 0 88 432
assign 1 88 433
iteratorGet 0 88 433
assign 1 88 436
hasNextGet 0 88 436
assign 1 89 438
nextGet 0 89 438
assign 1 90 439
typenameGet 0 90 439
assign 1 90 440
COMMAGet 0 90 440
assign 1 90 441
equals 1 90 441
addValue 1 91 443
assign 1 94 450
iteratorGet 0 94 450
assign 1 94 453
hasNextGet 0 94 453
assign 1 95 455
nextGet 0 95 455
delete 0 96 456
assign 1 99 463
assign 1 100 464
CALLGet 0 100 464
typenameSet 1 100 465
assign 1 101 466
new 0 101 466
assign 1 102 467
heldGet 0 102 467
nameSet 1 102 468
heldSet 1 103 469
delete 0 104 470
assign 1 105 471
assign 1 106 472
priorPeerGet 0 106 472
assign 1 107 473
def 1 107 478
assign 1 107 479
typenameGet 0 107 479
assign 1 107 480
DOTGet 0 107 480
assign 1 107 481
equals 1 107 481
assign 1 0 483
assign 1 0 486
assign 1 0 490
assign 1 108 493
priorPeerGet 0 108 493
assign 1 109 494
undef 1 109 499
assign 1 110 500
new 0 110 500
assign 1 110 501
new 2 110 501
throw 1 110 502
assign 1 111 505
typenameGet 0 111 505
assign 1 111 506
NAMEPATHGet 0 111 506
assign 1 111 507
equals 1 111 512
assign 1 112 513
nameGet 0 112 513
assign 1 112 514
isNewish 1 112 514
assign 1 113 516
new 0 113 516
wasBoundSet 1 113 517
assign 1 114 518
new 0 114 518
boundSet 1 114 519
assign 1 115 520
new 0 115 520
isConstructSet 1 115 521
createImpliedConstruct 2 117 524
assign 1 119 528
typenameGet 0 119 528
assign 1 119 529
IDGet 0 119 529
assign 1 119 530
equals 1 119 535
assign 1 119 536
transUnitGet 0 119 536
assign 1 119 537
heldGet 0 119 537
assign 1 119 538
aliasedGet 0 119 538
assign 1 119 539
heldGet 0 119 539
assign 1 119 540
has 1 119 540
assign 1 0 542
assign 1 119 545
emitDataGet 0 119 545
assign 1 119 546
aliasedGet 0 119 546
assign 1 119 547
heldGet 0 119 547
assign 1 119 548
has 1 119 548
assign 1 0 550
assign 1 0 553
assign 1 0 557
assign 1 0 560
assign 1 0 564
assign 1 120 567
new 0 120 567
assign 1 121 568
heldGet 0 121 568
addStep 1 121 569
heldSet 1 122 570
assign 1 123 571
NAMEPATHGet 0 123 571
typenameSet 1 123 572
resolveNp 0 124 573
assign 1 125 574
nameGet 0 125 574
assign 1 125 575
isNewish 1 125 575
assign 1 126 577
new 0 126 577
wasBoundSet 1 126 578
assign 1 127 579
new 0 127 579
boundSet 1 127 580
assign 1 128 581
new 0 128 581
isConstructSet 1 128 582
createImpliedConstruct 2 130 585
assign 1 132 589
nameGet 0 132 589
assign 1 132 590
new 0 132 590
assign 1 132 591
equals 1 132 591
assign 1 133 593
new 0 133 593
assign 1 133 594
new 2 133 594
throw 1 133 595
assign 1 134 598
nameGet 0 134 598
assign 1 134 599
new 0 134 599
assign 1 134 600
equals 1 134 600
assign 1 135 602
new 0 135 602
assign 1 135 603
new 2 135 603
throw 1 135 604
delete 0 138 610
prepend 1 139 611
delete 0 140 612
assign 1 142 615
new 0 142 615
boundSet 1 142 616
assign 1 143 617
new 0 143 617
wasBoundSet 1 143 618
assign 1 147 623
typenameGet 0 147 623
assign 1 147 624
IDXGet 0 147 624
assign 1 147 625
equals 1 147 630
assign 1 150 631
priorPeerGet 0 150 631
assign 1 151 632
undef 1 151 637
assign 1 152 638
new 0 152 638
assign 1 152 639
new 2 152 639
throw 1 152 640
delete 0 154 642
prepend 1 155 643
assign 1 156 644
typenameGet 0 156 644
assign 1 156 645
NAMEPATHGet 0 156 645
assign 1 156 646
equals 1 156 651
assign 1 157 652
new 0 157 652
assign 1 157 653
new 2 157 653
throw 1 157 654
assign 1 159 656
IDXACCGet 0 159 656
typenameSet 1 159 657
assign 1 160 660
typenameGet 0 160 660
assign 1 160 661
DOTGet 0 160 661
assign 1 160 662
equals 1 160 667
assign 1 162 668
priorPeerGet 0 162 668
assign 1 165 669
undef 1 165 674
assign 1 0 675
assign 1 165 678
undef 1 165 683
assign 1 0 684
assign 1 0 687
assign 1 166 691
new 0 166 691
assign 1 166 692
new 2 166 692
throw 1 166 693
assign 1 168 695
typenameGet 0 168 695
assign 1 168 696
IDGet 0 168 696
assign 1 168 697
equals 1 168 697
assign 1 169 699
nextPeerGet 0 169 699
assign 1 170 700
undef 1 170 705
assign 1 0 706
assign 1 170 709
typenameGet 0 170 709
assign 1 170 710
PARENSGet 0 170 710
assign 1 170 711
notEquals 1 170 711
assign 1 0 713
assign 1 0 716
assign 1 171 720
priorPeerGet 0 171 720
assign 1 172 721
ACCESSORGet 0 172 721
typenameSet 1 172 722
assign 1 173 723
new 0 173 723
assign 1 174 724
heldGet 0 174 724
nameSet 1 174 725
delete 0 175 726
delete 0 176 727
heldSet 1 177 728
addValue 1 178 729
assign 1 179 730
typenameGet 0 179 730
assign 1 179 731
NAMEPATHGet 0 179 731
assign 1 179 732
equals 1 179 737
createImpliedConstruct 2 180 738
assign 1 181 741
typenameGet 0 181 741
assign 1 181 742
IDGet 0 181 742
assign 1 181 743
equals 1 181 748
assign 1 181 749
transUnitGet 0 181 749
assign 1 181 750
heldGet 0 181 750
assign 1 181 751
aliasedGet 0 181 751
assign 1 181 752
heldGet 0 181 752
assign 1 181 753
has 1 181 753
assign 1 0 755
assign 1 181 758
emitDataGet 0 181 758
assign 1 181 759
aliasedGet 0 181 759
assign 1 181 760
heldGet 0 181 760
assign 1 181 761
has 1 181 761
assign 1 0 763
assign 1 0 766
assign 1 0 770
assign 1 0 773
assign 1 0 777
assign 1 182 780
new 0 182 780
assign 1 183 781
heldGet 0 183 781
addStep 1 183 782
heldSet 1 184 783
assign 1 185 784
NAMEPATHGet 0 185 784
typenameSet 1 185 785
resolveNp 0 186 786
createImpliedConstruct 2 187 787
assign 1 192 797
nextDescendGet 0 192 797
return 1 192 798
assign 1 196 811
new 0 196 811
heldSet 1 197 812
assign 1 198 813
NAMEPATHGet 0 198 813
typenameSet 1 198 814
assign 1 199 815
heldGet 0 199 815
heldSet 1 199 816
prepend 1 200 817
assign 1 202 818
new 0 202 818
assign 1 203 819
new 0 203 819
nameSet 1 203 820
assign 1 204 821
new 0 204 821
wasBoundSet 1 204 822
assign 1 205 823
new 0 205 823
boundSet 1 205 824
assign 1 206 825
new 0 206 825
isConstructSet 1 206 826
assign 1 207 827
new 0 207 827
wasImpliedConstructSet 1 207 828
heldSet 1 208 829
assign 1 209 830
CALLGet 0 209 830
typenameSet 1 209 831
return 1 0 835
return 1 0 838
assign 1 0 841
assign 1 0 845
return 1 0 849
return 1 0 852
assign 1 0 855
assign 1 0 859
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1229803830: return bem_deserializeClassNameGet_0();
case 1384423002: return bem_transGet_0();
case -1533701006: return bem_serializeContents_0();
case 938208985: return bem_inFileGet_0();
case 1330976730: return bem_hashGet_0();
case -1760434406: return bem_transGetDirect_0();
case -1191535124: return bem_inClassNpGetDirect_0();
case -1217444056: return bem_constGet_0();
case -1593715630: return bem_ntypesGetDirect_0();
case 437089080: return bem_print_0();
case 2041897687: return bem_inClassNpGet_0();
case -160735352: return bem_once_0();
case 2066642517: return bem_buildGetDirect_0();
case 907276784: return bem_serializeToString_0();
case 862788409: return bem_buildGet_0();
case -1990292643: return bem_toString_0();
case 1208354139: return bem_sourceFileNameGet_0();
case 1882778775: return bem_fieldIteratorGet_0();
case 1674575712: return bem_classNameGet_0();
case -1451048410: return bem_new_0();
case 797867737: return bem_ntypesGet_0();
case -166013833: return bem_tagGet_0();
case 278030248: return bem_constGetDirect_0();
case -1419115955: return bem_create_0();
case 1865983825: return bem_fieldNamesGet_0();
case -206043242: return bem_many_0();
case 872708376: return bem_toAny_0();
case 1200056076: return bem_serializationIteratorGet_0();
case -1539825373: return bem_inFileGetDirect_0();
case 2017345633: return bem_copy_0();
case 48684490: return bem_echo_0();
case -2014542803: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 161134859: return bem_defined_1(bevd_0);
case -691436434: return bem_begin_1(bevd_0);
case -1306142247: return bem_transSet_1(bevd_0);
case 2058785774: return bem_constSet_1(bevd_0);
case 1153143612: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1353297109: return bem_buildSetDirect_1(bevd_0);
case -1845485202: return bem_inFileSet_1(bevd_0);
case 2122176784: return bem_undef_1(bevd_0);
case 448678910: return bem_ntypesSet_1(bevd_0);
case -1948499177: return bem_inClassNpSetDirect_1(bevd_0);
case 170216407: return bem_copyTo_1(bevd_0);
case 1920998617: return bem_sameObject_1(bevd_0);
case 713581423: return bem_constSetDirect_1(bevd_0);
case 625481528: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1484567824: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -279352105: return bem_undefined_1(bevd_0);
case 1596863802: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1517637963: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 494759431: return bem_inClassNpSet_1(bevd_0);
case -1822027791: return bem_otherClass_1(bevd_0);
case 1561328648: return bem_otherType_1(bevd_0);
case 354557818: return bem_equals_1(bevd_0);
case -332644770: return bem_end_1(bevd_0);
case 1406812161: return bem_transSetDirect_1(bevd_0);
case -185383596: return bem_sameType_1(bevd_0);
case 584123032: return bem_def_1(bevd_0);
case 1951809293: return bem_ntypesSetDirect_1(bevd_0);
case -1616094339: return bem_buildSet_1(bevd_0);
case -1960155826: return bem_inFileSetDirect_1(bevd_0);
case 909810346: return bem_sameClass_1(bevd_0);
case -840953319: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 26706284: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
case 1467883232: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 465709808: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 936076332: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -758649425: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 105253121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -29810702: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 175222937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass7_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass7_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst = (BEC_3_5_5_5_BuildVisitPass7) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;
}
}
}
