namespace be {
public class BET_2_4_6_JsonParser : BETS_Object {
public BET_2_4_6_JsonParser() {
string[] bevs_mtnames = new string[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "parse_2", "jsonUcIsPairStart_1", "jsonUcIsPairEnd_1", "jsonUcGetAfterPart_1", "jsonUcUnescape_1", "jsonUcAppendValue_3", "parseTokens_2", "quoteGet_0", "quoteGetDirect_0", "quoteSet_1", "quoteSetDirect_1", "lbraceGet_0", "lbraceGetDirect_0", "lbraceSet_1", "lbraceSetDirect_1", "rbraceGet_0", "rbraceGetDirect_0", "rbraceSet_1", "rbraceSetDirect_1", "lbracketGet_0", "lbracketGetDirect_0", "lbracketSet_1", "lbracketSetDirect_1", "rbracketGet_0", "rbracketGetDirect_0", "rbracketSet_1", "rbracketSetDirect_1", "spaceGet_0", "spaceGetDirect_0", "spaceSet_1", "spaceSetDirect_1", "colonGet_0", "colonGetDirect_0", "colonSet_1", "colonSetDirect_1", "escapeGet_0", "escapeGetDirect_0", "escapeSet_1", "escapeSetDirect_1", "crGet_0", "crGetDirect_0", "crSet_1", "crSetDirect_1", "lfGet_0", "lfGetDirect_0", "lfSet_1", "lfSetDirect_1", "commaGet_0", "commaGetDirect_0", "commaSet_1", "commaSetDirect_1", "tokensGet_0", "tokensGetDirect_0", "tokensSet_1", "tokensSetDirect_1", "tokerGet_0", "tokerGetDirect_0", "tokerSet_1", "tokerSetDirect_1", "hsubGet_0", "hsubGetDirect_0", "hsubSet_1", "hsubSetDirect_1", "vsubGet_0", "vsubGetDirect_0", "vsubSet_1", "vsubSetDirect_1", "hmAddGet_0", "hmAddGetDirect_0", "hmAddSet_1", "hmAddSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new string[] { "quote", "lbrace", "rbrace", "lbracket", "rbracket", "space", "colon", "escape", "cr", "lf", "comma", "tokens", "toker", "hsub", "vsub", "hmAdd" };
}
static BET_2_4_6_JsonParser() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_6_JsonParser();
}
}
}
