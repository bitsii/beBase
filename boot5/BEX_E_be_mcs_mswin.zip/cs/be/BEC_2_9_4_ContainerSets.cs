namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerSets : BEC_2_6_8_SystemVariadic {
public BEC_2_9_4_ContainerSets() { }
static BEC_2_9_4_ContainerSets() { }
private static byte[] becc_BEC_2_9_4_ContainerSets_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x73};
private static byte[] becc_BEC_2_9_4_ContainerSets_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_inst;

public static new BET_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_type;

public virtual BEC_2_9_4_ContainerSets bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_from_1(BEC_2_9_4_ContainerList beva_list) {
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_9_3_ContainerSet bevl_set = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = beva_list.bem_sizeGet_0();
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_ssz = bevt_1_ta_ph.bem_multiply_1(bevt_2_ta_ph);
bevl_ssz.bevi_int++;
bevl_set = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_1(bevl_ssz);
bevt_0_ta_loop = beva_list.bem_iteratorGet_0();
while (true)
/* Line: 710*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bemd_0(1102233);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 710*/ {
bevl_v = bevt_0_ta_loop.bemd_0(199074760);
bevl_set.bem_put_1(bevl_v);
} /* Line: 711*/
 else /* Line: 710*/ {
break;
} /* Line: 710*/
} /* Line: 710*/
return bevl_set;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {707, 707, 707, 708, 709, 710, 0, 710, 710, 711, 713};
public static new int[] bevs_smnlec
 = new int[] {23, 24, 25, 26, 27, 28, 28, 31, 33, 34, 40};
/* BEGIN LINEINFO 
assign 1 707 23
sizeGet 0 707 23
assign 1 707 24
new 0 707 24
assign 1 707 25
multiply 1 707 25
incrementValue 0 708 26
assign 1 709 27
new 1 709 27
assign 1 710 28
iteratorGet 0 0 28
assign 1 710 31
hasNextGet 0 710 31
assign 1 710 33
nextGet 0 710 33
put 1 711 34
return 1 713 40
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1151085267: return bem_deserializeClassNameGet_0();
case 721123821: return bem_tagGet_0();
case 19210432: return bem_iteratorGet_0();
case 1597530459: return bem_print_0();
case 559255035: return bem_fieldNamesGet_0();
case -860520942: return bem_toString_0();
case 216633460: return bem_serializeContents_0();
case 1291824271: return bem_echo_0();
case 595935693: return bem_create_0();
case -390286916: return bem_serializeToString_0();
case -1869924457: return bem_sourceFileNameGet_0();
case 270781002: return bem_new_0();
case -827080774: return bem_copy_0();
case -1156903676: return bem_serializationIteratorGet_0();
case -1123266766: return bem_classNameGet_0();
case -601453628: return bem_fieldIteratorGet_0();
case 1210301124: return bem_default_0();
case 1562356496: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 198160460: return bem_from_1((BEC_2_9_4_ContainerList) bevd_0);
case -323113819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2138090541: return bem_sameClass_1(bevd_0);
case -690535851: return bem_sameObject_1(bevd_0);
case -499138365: return bem_otherClass_1(bevd_0);
case 2140620274: return bem_otherType_1(bevd_0);
case -696336738: return bem_equals_1(bevd_0);
case 1788911287: return bem_sameType_1(bevd_0);
case -637072093: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1582378113: return bem_notEquals_1(bevd_0);
case -478520463: return bem_undef_1(bevd_0);
case -89866327: return bem_copyTo_1(bevd_0);
case -327732297: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1720726298: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1828646701: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -733779503: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -77252171: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -104691827: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 350317076: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerSets_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerSets_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerSets();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst = (BEC_2_9_4_ContainerSets) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_type;
}
}
}
