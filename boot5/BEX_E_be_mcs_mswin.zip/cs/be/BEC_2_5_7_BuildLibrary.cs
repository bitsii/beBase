namespace be {
/* IO:File: source/build/Library.be */
public sealed class BEC_2_5_7_BuildLibrary : BEC_2_6_6_SystemObject {
public BEC_2_5_7_BuildLibrary() { }
static BEC_2_5_7_BuildLibrary() { }
private static byte[] becc_BEC_2_5_7_BuildLibrary_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] becc_BEC_2_5_7_BuildLibrary_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x2E,0x62,0x65};
public static new BEC_2_5_7_BuildLibrary bece_BEC_2_5_7_BuildLibrary_bevs_inst;

public static new BET_2_5_7_BuildLibrary bece_BEC_2_5_7_BuildLibrary_bevs_type;

public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_5_9_BuildClassInfo bevp_libnameInfo;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_5_7_BuildLibrary bem_new_2(BEC_2_4_6_TextString beva_spath, BEC_2_5_5_BuildBuild beva__build) {
BEC_3_2_4_4_IOFilePath bevl_libPath = null;
BEC_2_6_6_SystemObject bevl_libnameNp = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevp_build = beva__build;
if (bevp_libName == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 16*/ {
bevl_libPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevl_libPath.bem_parentGet_0();
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_1_ta_ph = bevl_libPath.bem_stepsGet_0();
bevp_libName = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_lastGet_0();
} /* Line: 20*/
 else /* Line: 21*/ {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
} /* Line: 23*/
if (bevp_libName == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 25*/ {
bevl_libnameNp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_libnameNp.bemd_1(-1409612680, bevp_libName);
if (bevp_exeName == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 28*/ {
bevp_exeName = bevp_libName;
} /* Line: 28*/
bevt_4_ta_ph = bevp_build.bem_emitterGet_0();
bevp_libnameInfo = (BEC_2_5_9_BuildClassInfo) (new BEC_2_5_9_BuildClassInfo()).bem_new_5((BEC_2_5_8_BuildNamePath) bevl_libnameNp , bevt_4_ta_ph, bevp_emitPath, bevp_libName, bevp_exeName);
} /* Line: 29*/
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_new_4(BEC_2_4_6_TextString beva_spath, BEC_2_5_5_BuildBuild beva__build, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) {
bevp_libName = beva__libName;
bevp_exeName = beva__exeName;
bem_new_2(beva_spath, beva__build);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGetDirect_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInfoGet_0() {
return bevp_libnameInfo;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInfoGetDirect_0() {
return bevp_libnameInfo;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libnameInfoSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameInfo = (BEC_2_5_9_BuildClassInfo) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libnameInfoSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameInfo = (BEC_2_5_9_BuildClassInfo) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGetDirect_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() {
return bevp_basePath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGetDirect_0() {
return bevp_basePath;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_basePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {12, 16, 16, 17, 18, 19, 20, 20, 22, 23, 25, 25, 26, 27, 28, 28, 28, 29, 29, 34, 35, 36, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 32, 33, 34, 35, 36, 37, 40, 41, 43, 48, 49, 50, 51, 56, 57, 59, 60, 65, 66, 67, 71, 74, 77, 81, 85, 88, 91, 95, 99, 102, 105, 109, 113, 116, 119, 123, 127, 130, 133, 137, 141, 144, 147, 151};
/* BEGIN LINEINFO 
assign 1 12 26
assign 1 16 27
undef 1 16 32
assign 1 17 33
new 1 17 33
assign 1 18 34
parentGet 0 18 34
assign 1 19 35
copy 0 19 35
assign 1 20 36
stepsGet 0 20 36
assign 1 20 37
lastGet 0 20 37
assign 1 22 40
new 1 22 40
assign 1 23 41
copy 0 23 41
assign 1 25 43
def 1 25 48
assign 1 26 49
new 0 26 49
fromString 1 27 50
assign 1 28 51
undef 1 28 56
assign 1 28 57
assign 1 29 59
emitterGet 0 29 59
assign 1 29 60
new 5 29 60
assign 1 34 65
assign 1 35 66
new 2 36 67
return 1 0 71
return 1 0 74
assign 1 0 77
assign 1 0 81
return 1 0 85
return 1 0 88
assign 1 0 91
assign 1 0 95
return 1 0 99
return 1 0 102
assign 1 0 105
assign 1 0 109
return 1 0 113
return 1 0 116
assign 1 0 119
assign 1 0 123
return 1 0 127
return 1 0 130
assign 1 0 133
assign 1 0 137
return 1 0 141
return 1 0 144
assign 1 0 147
assign 1 0 151
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1893075648: return bem_buildGetDirect_0();
case 4682316: return bem_exeNameGet_0();
case -1642361296: return bem_print_0();
case 1161638424: return bem_new_0();
case 168135582: return bem_create_0();
case 759496930: return bem_tagGet_0();
case 1757350500: return bem_basePathGet_0();
case 814334258: return bem_serializeContents_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case -587897148: return bem_libNameGetDirect_0();
case -894296517: return bem_basePathGetDirect_0();
case -493438343: return bem_exeNameGetDirect_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -1655929819: return bem_emitPathGetDirect_0();
case -71162589: return bem_iteratorGet_0();
case -1256688673: return bem_libnameInfoGet_0();
case 944073339: return bem_fieldIteratorGet_0();
case 735894078: return bem_emitPathGet_0();
case 2132420479: return bem_many_0();
case 1365897346: return bem_serializationIteratorGet_0();
case -1480556491: return bem_toAny_0();
case -202912463: return bem_copy_0();
case 1504098000: return bem_libNameGet_0();
case 350691792: return bem_toString_0();
case -377373844: return bem_libnameInfoGetDirect_0();
case -1044758745: return bem_serializeToString_0();
case -1251441948: return bem_buildGet_0();
case 2064925791: return bem_echo_0();
case -1711670377: return bem_hashGet_0();
case -1359614197: return bem_classNameGet_0();
case -1785724794: return bem_once_0();
case -652053502: return bem_fieldNamesGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -951966168: return bem_def_1(bevd_0);
case 702513292: return bem_exeNameSetDirect_1(bevd_0);
case 819746231: return bem_buildSet_1(bevd_0);
case 1302014173: return bem_libnameInfoSetDirect_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case 441564946: return bem_basePathSet_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case 1115351447: return bem_exeNameSet_1(bevd_0);
case 1035813320: return bem_emitPathSetDirect_1(bevd_0);
case -1989672097: return bem_libNameSet_1(bevd_0);
case -661952603: return bem_libnameInfoSet_1(bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case 469815787: return bem_basePathSetDirect_1(bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case 867713505: return bem_emitPathSet_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case -1055205804: return bem_buildSetDirect_1(bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case -869793943: return bem_libNameSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1259587878: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1803026193: return bem_new_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_5_7_BuildLibrary_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_5_7_BuildLibrary_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_7_BuildLibrary();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_inst = (BEC_2_5_7_BuildLibrary) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_type;
}
}
}
