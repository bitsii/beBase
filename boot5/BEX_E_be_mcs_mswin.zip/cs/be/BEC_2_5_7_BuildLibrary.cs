namespace be {
/* IO:File: source/build/Library.be */
public sealed class BEC_2_5_7_BuildLibrary : BEC_2_6_6_SystemObject {
public BEC_2_5_7_BuildLibrary() { }
static BEC_2_5_7_BuildLibrary() { }
private static byte[] becc_BEC_2_5_7_BuildLibrary_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] becc_BEC_2_5_7_BuildLibrary_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x2E,0x62,0x65};
public static new BEC_2_5_7_BuildLibrary bece_BEC_2_5_7_BuildLibrary_bevs_inst;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_5_9_BuildClassInfo bevp_libnameInfo;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_5_7_BuildLibrary bem_new_2(BEC_2_4_6_TextString beva_spath, BEC_2_5_5_BuildBuild beva__build) {
BEC_3_2_4_4_IOFilePath bevl_libPath = null;
BEC_2_6_6_SystemObject bevl_libnameNp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
bevp_build = beva__build;
if (bevp_libName == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 17 */ {
bevl_libPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevl_libPath.bem_parentGet_0();
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_1_tmpany_phold = bevl_libPath.bem_stepsGet_0();
bevp_libName = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_lastGet_0();
} /* Line: 21 */
 else  /* Line: 22 */ {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
} /* Line: 24 */
if (bevp_libName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 26 */ {
bevl_libnameNp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_libnameNp.bemd_1(619377888, bevp_libName);
if (bevp_exeName == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 29 */ {
bevp_exeName = bevp_libName;
} /* Line: 29 */
bevt_4_tmpany_phold = bevp_build.bem_emitterGet_0();
bevp_libnameInfo = (BEC_2_5_9_BuildClassInfo) (new BEC_2_5_9_BuildClassInfo()).bem_new_5((BEC_2_5_8_BuildNamePath) bevl_libnameNp , bevt_4_tmpany_phold, bevp_emitPath, bevp_libName, bevp_exeName);
} /* Line: 30 */
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_new_4(BEC_2_4_6_TextString beva_spath, BEC_2_5_5_BuildBuild beva__build, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) {
bevp_libName = beva__libName;
bevp_exeName = beva__exeName;
bem_new_2(beva_spath, beva__build);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInfoGet_0() {
return bevp_libnameInfo;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libnameInfoSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameInfo = (BEC_2_5_9_BuildClassInfo) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() {
return bevp_basePath;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {13, 17, 17, 18, 19, 20, 21, 21, 23, 24, 26, 26, 27, 28, 29, 29, 29, 30, 30, 35, 36, 37, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {23, 24, 29, 30, 31, 32, 33, 34, 37, 38, 40, 45, 46, 47, 48, 53, 54, 56, 57, 62, 63, 64, 68, 71, 75, 78, 82, 85, 89, 92, 96, 99, 103, 106};
/* BEGIN LINEINFO 
assign 1 13 23
assign 1 17 24
undef 1 17 29
assign 1 18 30
new 1 18 30
assign 1 19 31
parentGet 0 19 31
assign 1 20 32
copy 0 20 32
assign 1 21 33
stepsGet 0 21 33
assign 1 21 34
lastGet 0 21 34
assign 1 23 37
new 1 23 37
assign 1 24 38
copy 0 24 38
assign 1 26 40
def 1 26 45
assign 1 27 46
new 0 27 46
fromString 1 28 47
assign 1 29 48
undef 1 29 53
assign 1 29 54
assign 1 30 56
emitterGet 0 30 56
assign 1 30 57
new 5 30 57
assign 1 35 62
assign 1 36 63
new 2 37 64
return 1 0 68
assign 1 0 71
return 1 0 75
assign 1 0 78
return 1 0 82
assign 1 0 85
return 1 0 89
assign 1 0 92
return 1 0 96
assign 1 0 99
return 1 0 103
assign 1 0 106
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -526620055: return bem_exeNameGet_0();
case -58429592: return bem_buildGet_0();
case -1193265838: return bem_new_0();
case -1976290782: return bem_print_0();
case 880152096: return bem_classNameGet_0();
case 1211836779: return bem_iteratorGet_0();
case -1896601781: return bem_toAny_0();
case -2091198124: return bem_tagGet_0();
case 444169984: return bem_sourceFileNameGet_0();
case -2052611744: return bem_once_0();
case -1888508563: return bem_serializationIteratorGet_0();
case 752911959: return bem_hashGet_0();
case 1557487820: return bem_basePathGet_0();
case 1474352025: return bem_emitPathGet_0();
case 765668507: return bem_libNameGet_0();
case 1310164435: return bem_serializeContents_0();
case 293380711: return bem_libnameInfoGet_0();
case -326646035: return bem_toString_0();
case -364515046: return bem_fieldIteratorGet_0();
case 2085674875: return bem_echo_0();
case 2098501683: return bem_create_0();
case 1278477757: return bem_serializeToString_0();
case 2141550628: return bem_deserializeClassNameGet_0();
case -1152001976: return bem_copy_0();
case 142206752: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1268433926: return bem_otherClass_1(bevd_0);
case -2100825066: return bem_libnameInfoSet_1(bevd_0);
case -785327205: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2018719997: return bem_basePathSet_1(bevd_0);
case 607370643: return bem_undefined_1(bevd_0);
case 1579053823: return bem_sameType_1(bevd_0);
case 1048239710: return bem_sameClass_1(bevd_0);
case -1981174775: return bem_buildSet_1(bevd_0);
case -1321282362: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1866601742: return bem_otherType_1(bevd_0);
case -1178545054: return bem_exeNameSet_1(bevd_0);
case 1948085050: return bem_undef_1(bevd_0);
case -2102972771: return bem_libNameSet_1(bevd_0);
case 986477958: return bem_defined_1(bevd_0);
case -1262454386: return bem_emitPathSet_1(bevd_0);
case 1990827367: return bem_notEquals_1(bevd_0);
case 275457317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 496808651: return bem_sameObject_1(bevd_0);
case 45057151: return bem_equals_1(bevd_0);
case 136677527: return bem_def_1(bevd_0);
case 930180418: return bem_copyTo_1(bevd_0);
case -1191000829: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1768228505: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 627553561: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
case -1848289028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 253281852: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1400688487: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 686788947: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 893523384: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1481064275: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1536411490: return bem_new_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_5_7_BuildLibrary_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_5_7_BuildLibrary_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_7_BuildLibrary();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_inst = (BEC_2_5_7_BuildLibrary) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_inst;
}
}
}
