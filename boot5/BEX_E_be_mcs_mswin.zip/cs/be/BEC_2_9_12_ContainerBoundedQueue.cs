namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_2_9_12_ContainerBoundedQueue : BEC_2_9_5_ContainerQueue {
public BEC_2_9_12_ContainerBoundedQueue() { }
static BEC_2_9_12_ContainerBoundedQueue() { }
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x42,0x6F,0x75,0x6E,0x64,0x65,0x64,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;

public static new BET_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public override BEC_2_6_6_SystemObject bem_new_0() {
base.bem_new_0();
bevp_max = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(99));
return this;
} /*method end*/
public override BEC_2_9_5_ContainerQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
base.bem_enqueue_1(beva_item);
if (bevp_size.bevi_int > bevp_max.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 191 */ {
bem_dequeue_0();
} /* Line: 192 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_maxGet_0() {
return bevp_max;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGetDirect_0() {
return bevp_max;
} /*method end*/
public virtual BEC_2_9_12_ContainerBoundedQueue bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_maxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {184, 186, 190, 191, 191, 192, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 20, 21, 26, 27, 32, 35, 38, 42};
/* BEGIN LINEINFO 
new 0 184 14
assign 1 186 15
new 0 186 15
enqueue 1 190 20
assign 1 191 21
greater 1 191 26
dequeue 0 192 27
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1057323332: return bem_toAny_0();
case 393968063: return bem_isEmptyGet_0();
case 1206886075: return bem_endGet_0();
case -1438038411: return bem_sourceFileNameGet_0();
case -195266806: return bem_toString_0();
case -166515831: return bem_fieldNamesGet_0();
case -992120130: return bem_fieldIteratorGet_0();
case -299023655: return bem_echo_0();
case 803060031: return bem_create_0();
case -1856486979: return bem_deserializeClassNameGet_0();
case -189856578: return bem_copy_0();
case -811418832: return bem_many_0();
case 2121039924: return bem_new_0();
case -265928475: return bem_classNameGet_0();
case 1236464998: return bem_serializeContents_0();
case -1735879417: return bem_print_0();
case 1841646431: return bem_topGet_0();
case 2111391138: return bem_serializeToString_0();
case -205297998: return bem_endGetDirect_0();
case 1353404980: return bem_sizeGetDirect_0();
case -1888652893: return bem_bottomGet_0();
case 24125772: return bem_iteratorGet_0();
case -1920666734: return bem_topGetDirect_0();
case 1810670501: return bem_maxGetDirect_0();
case 538632487: return bem_serializationIteratorGet_0();
case 1870744321: return bem_once_0();
case 1457322122: return bem_maxGet_0();
case -1232978478: return bem_hashGet_0();
case -1004741527: return bem_sizeGet_0();
case 893274194: return bem_tagGet_0();
case -1683057932: return bem_bottomGetDirect_0();
case -1705947549: return bem_dequeue_0();
case -715597932: return bem_get_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1265063104: return bem_topSetDirect_1(bevd_0);
case 125925927: return bem_topSet_1(bevd_0);
case 1644002544: return bem_sizeSetDirect_1(bevd_0);
case 1669121148: return bem_copyTo_1(bevd_0);
case 472574724: return bem_enqueue_1(bevd_0);
case -490313093: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1628306760: return bem_notEquals_1(bevd_0);
case -564148923: return bem_sameObject_1(bevd_0);
case 1025270681: return bem_sameClass_1(bevd_0);
case -1233382567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 208579137: return bem_put_1(bevd_0);
case -1108496649: return bem_otherClass_1(bevd_0);
case 2034892494: return bem_addValue_1(bevd_0);
case 596900482: return bem_maxSetDirect_1(bevd_0);
case -1822782606: return bem_sizeSet_1(bevd_0);
case 146723804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -905872983: return bem_equals_1(bevd_0);
case 404111983: return bem_maxSet_1(bevd_0);
case 1605446225: return bem_bottomSet_1(bevd_0);
case 525545408: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -132983687: return bem_undefined_1(bevd_0);
case 1681419755: return bem_defined_1(bevd_0);
case -1374125024: return bem_undef_1(bevd_0);
case -1433803932: return bem_def_1(bevd_0);
case 843242446: return bem_endSetDirect_1(bevd_0);
case 1743551507: return bem_bottomSetDirect_1(bevd_0);
case 361063718: return bem_endSet_1(bevd_0);
case -267062499: return bem_sameType_1(bevd_0);
case -1171661229: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1931375919: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 68692131: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383175850: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -110664853: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1765848815: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1365987158: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -381061425: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_9_12_ContainerBoundedQueue_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_12_ContainerBoundedQueue_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_12_ContainerBoundedQueue();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst = (BEC_2_9_12_ContainerBoundedQueue) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;
}
}
}
