namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_2_9_12_ContainerBoundedQueue : BEC_2_9_5_ContainerQueue {
public BEC_2_9_12_ContainerBoundedQueue() { }
static BEC_2_9_12_ContainerBoundedQueue() { }
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x42,0x6F,0x75,0x6E,0x64,0x65,0x64,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;

public static new BET_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public override BEC_2_6_6_SystemObject bem_new_0() {
base.bem_new_0();
bevp_max = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(99));
return this;
} /*method end*/
public override BEC_2_9_5_ContainerQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
base.bem_enqueue_1(beva_item);
if (bevp_size.bevi_int > bevp_max.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 191 */ {
bem_dequeue_0();
} /* Line: 192 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_maxGet_0() {
return bevp_max;
} /*method end*/
public virtual BEC_2_9_12_ContainerBoundedQueue bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {184, 186, 190, 191, 191, 192, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 20, 21, 26, 27, 32, 35};
/* BEGIN LINEINFO 
new 0 184 14
assign 1 186 15
new 0 186 15
enqueue 1 190 20
assign 1 191 21
greater 1 191 26
dequeue 0 192 27
return 1 0 32
assign 1 0 35
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 189742079: return bem_topGet_0();
case 1624944174: return bem_serializationIteratorGet_0();
case 894461621: return bem_get_0();
case 891275742: return bem_maxGet_0();
case 1754519730: return bem_classNameGet_0();
case 1625518333: return bem_isEmptyGet_0();
case 1099128486: return bem_echo_0();
case 342664202: return bem_serializeContents_0();
case 800388063: return bem_endGet_0();
case -1920078604: return bem_sourceFileNameGet_0();
case -1248348608: return bem_many_0();
case 1334927002: return bem_create_0();
case -914943787: return bem_toString_0();
case 1280569362: return bem_fieldIteratorGet_0();
case -1117992648: return bem_hashGet_0();
case -1824160904: return bem_bottomGet_0();
case 93356535: return bem_deserializeClassNameGet_0();
case -1942605555: return bem_toAny_0();
case -152803575: return bem_tagGet_0();
case -541227487: return bem_new_0();
case 38289726: return bem_print_0();
case -1618533783: return bem_serializeToString_0();
case -1749035302: return bem_copy_0();
case -1620303979: return bem_once_0();
case 385489744: return bem_iteratorGet_0();
case -937527115: return bem_dequeue_0();
case 356757239: return bem_sizeGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 545755244: return bem_maxSet_1(bevd_0);
case -147916244: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -647434226: return bem_addValue_1(bevd_0);
case -514748676: return bem_endSet_1(bevd_0);
case -168753549: return bem_put_1(bevd_0);
case 1417404860: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1381620830: return bem_topSet_1(bevd_0);
case 1669123607: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 960625295: return bem_notEquals_1(bevd_0);
case 1356842566: return bem_otherClass_1(bevd_0);
case -1553866014: return bem_sameClass_1(bevd_0);
case -929975460: return bem_equals_1(bevd_0);
case -1164482106: return bem_sizeSet_1(bevd_0);
case -1001167064: return bem_def_1(bevd_0);
case 408844820: return bem_undefined_1(bevd_0);
case -2057956567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -294056039: return bem_bottomSet_1(bevd_0);
case 327551615: return bem_undef_1(bevd_0);
case 589015080: return bem_otherType_1(bevd_0);
case -406377870: return bem_copyTo_1(bevd_0);
case 1004011568: return bem_enqueue_1(bevd_0);
case -1975825183: return bem_sameObject_1(bevd_0);
case -900790842: return bem_defined_1(bevd_0);
case 32553456: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1615755198: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 914119897: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1722418125: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1183458920: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -294037420: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1794036335: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1344222461: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_9_12_ContainerBoundedQueue_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_12_ContainerBoundedQueue_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_12_ContainerBoundedQueue();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst = (BEC_2_9_12_ContainerBoundedQueue) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;
}
}
}
