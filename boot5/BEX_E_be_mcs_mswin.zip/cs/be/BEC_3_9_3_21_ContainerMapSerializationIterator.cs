namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_21_ContainerMapSerializationIterator : BEC_3_9_3_16_ContainerMapKeyValueIterator {
public BEC_3_9_3_21_ContainerMapSerializationIterator() { }
static BEC_3_9_3_21_ContainerMapSerializationIterator() { }
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;
public BEC_2_9_4_ContainerList bevp_contents;
public override BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) {
bevp_contents = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
base.bem_new_1(beva__set);
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
bevp_contents.bem_addValue_1(beva_value);
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 579 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 579 */ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 579 */
 else  /* Line: 579 */ {
break;
} /* Line: 579 */
} /* Line: 579 */
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_postDeserialize_0() {
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_key = null;
BEC_2_6_6_SystemObject bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevl_map = (BEC_2_9_3_ContainerMap) bevp_set;
bevl_iter = bevp_contents.bem_iteratorGet_0();
while (true)
 /* Line: 587 */ {
bevt_0_tmpany_phold = bevl_iter.bemd_0(-2076341414);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 587 */ {
bevl_key = bevl_iter.bemd_0(-1641663327);
bevl_value = bevl_iter.bemd_0(-1641663327);
bevl_map.bem_put_2(bevl_key, bevl_value);
} /* Line: 590 */
 else  /* Line: 587 */ {
break;
} /* Line: 587 */
} /* Line: 587 */
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_contentsGet_0() {
return bevp_contents;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {569, 571, 575, 579, 579, 579, 580, 579, 585, 586, 587, 588, 589, 590, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {11, 12, 16, 22, 25, 30, 31, 32, 46, 47, 50, 52, 53, 54, 63, 66};
/* BEGIN LINEINFO 
assign 1 569 11
new 0 569 11
new 1 571 12
addValue 1 575 16
assign 1 579 22
new 0 579 22
assign 1 579 25
lesser 1 579 30
nextSet 1 580 31
assign 1 579 32
increment 0 579 32
assign 1 585 46
assign 1 586 47
iteratorGet 0 586 47
assign 1 587 50
hasNextGet 0 587 50
assign 1 588 52
nextGet 0 588 52
assign 1 589 53
nextGet 0 589 53
put 2 590 54
return 1 0 63
assign 1 0 66
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 437585929: return bem_currentGet_0();
case 1277077124: return bem_once_0();
case 17959274: return bem_postDeserialize_0();
case -146459624: return bem_tagGet_0();
case -67432972: return bem_fieldIteratorGet_0();
case 16424274: return bem_iteratorGet_0();
case -1641663327: return bem_nextGet_0();
case -1751704975: return bem_many_0();
case 1985246514: return bem_classNameGet_0();
case -1181834336: return bem_serializeToString_0();
case 1818190775: return bem_toString_0();
case -1089603369: return bem_slotsGet_0();
case 1218559501: return bem_onNodeGet_0();
case -1023494158: return bem_contentsGet_0();
case 1704272071: return bem_copy_0();
case 642325680: return bem_deserializeClassNameGet_0();
case 308705107: return bem_serializeContents_0();
case -957295314: return bem_containerGet_0();
case -457378134: return bem_sourceFileNameGet_0();
case -1538220610: return bem_echo_0();
case -2141619492: return bem_moduGet_0();
case -1881085670: return bem_setGet_0();
case 1783316498: return bem_delete_0();
case -563585217: return bem_toAny_0();
case 518706814: return bem_nodeIteratorIteratorGet_0();
case -1613660155: return bem_serializationIteratorGet_0();
case 1190997837: return bem_print_0();
case 371037351: return bem_hashGet_0();
case 1133560869: return bem_new_0();
case -2076341414: return bem_hasNextGet_0();
case 1567284243: return bem_create_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case -1508704559: return bem_copyTo_1(bevd_0);
case 2063128826: return bem_onNodeSet_1(bevd_0);
case -407365077: return bem_slotsSet_1(bevd_0);
case 1024493267: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2112413547: return bem_currentSet_1(bevd_0);
case 2101700701: return bem_undefined_1(bevd_0);
case -1682170766: return bem_otherType_1(bevd_0);
case -503068138: return bem_sameType_1(bevd_0);
case 2077566448: return bem_sameClass_1(bevd_0);
case 1758579140: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 1398941771: return bem_def_1(bevd_0);
case -983798575: return bem_moduSet_1(bevd_0);
case -240186291: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 11116001: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1936197463: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -122042490: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 933268131: return bem_setSet_1(bevd_0);
case 1270721790: return bem_sameObject_1(bevd_0);
case -625783607: return bem_nextSet_1(bevd_0);
case 1933685650: return bem_equals_1(bevd_0);
case 579081683: return bem_defined_1(bevd_0);
case 1069670174: return bem_undef_1(bevd_0);
case -1210345122: return bem_notEquals_1(bevd_0);
case 1170591864: return bem_otherClass_1(bevd_0);
case -704164099: return bem_contentsSet_1(bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1408482482: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1097908484: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1722402091: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1055053136: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2112228411: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -483654719: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1372560242: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(35, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_21_ContainerMapSerializationIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst = (BEC_3_9_3_21_ContainerMapSerializationIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;
}
}
}
