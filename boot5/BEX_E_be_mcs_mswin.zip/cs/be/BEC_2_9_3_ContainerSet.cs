namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet : BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
static BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_5 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_7 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;

public static new BET_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_type;

public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_0;
if (bevp_size.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 232 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 233 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_1;
if (bevp_size.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /* Line: 240 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_3_21_ContainerSetSerializationIterator) (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
 /* Line: 258 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 258 */ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevt_4_tmpany_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpany_phold = bem_innerPut_4(bevt_4_tmpany_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(1168890224);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 261 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 262 */
} /* Line: 261 */
} /* Line: 260 */
 else  /* Line: 258 */ {
break;
} /* Line: 258 */
} /* Line: 258 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_2;
bevl_nslots = bevt_0_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevl_ninner = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 273 */ {
bevt_4_tmpany_phold = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1168890224);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 273 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
} /* Line: 275 */
 else  /* Line: 273 */ {
break;
} /* Line: 273 */
} /* Line: 273 */
return bevl_ninner;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_other == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 281 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 281 */ {
bevt_4_tmpany_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpany_phold = bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int != bevt_5_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 281 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 281 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 281 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 281 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 282 */
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 284 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevl_i = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_9_tmpany_phold = beva_other.bem_has_1(bevl_i);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /* Line: 285 */
} /* Line: 285 */
 else  /* Line: 284 */ {
break;
} /* Line: 284 */
} /* Line: 284 */
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 292 */ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_3;
if (bevl_hval.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 294 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 295 */
} /* Line: 294 */
 else  /* Line: 297 */ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(-1637782115);
} /* Line: 298 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 302 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 304 */ {
if (beva_inode == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 305 */ {
bevt_6_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_tmpany_phold.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpany_phold);
} /* Line: 306 */
 else  /* Line: 307 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 308 */
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 311 */
 else  /* Line: 304 */ {
bevt_10_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_9_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /* Line: 313 */
 else  /* Line: 304 */ {
bevt_13_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 314 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_14_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_14_tmpany_phold;
} /* Line: 318 */
 else  /* Line: 319 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_16_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_16_tmpany_phold;
} /* Line: 322 */
} /* Line: 321 */
} /* Line: 304 */
} /* Line: 304 */
} /* Line: 304 */
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1168890224);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 329 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
 /* Line: 332 */ {
bevt_3_tmpany_phold = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(1168890224);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 332 */ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 333 */
 else  /* Line: 332 */ {
break;
} /* Line: 332 */
} /* Line: 332 */
bevp_slots = bevl_slt;
} /* Line: 335 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 337 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 338 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_4;
if (bevl_hval.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 347 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 351 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 353 */ {
return null;
} /* Line: 354 */
 else  /* Line: 353 */ {
bevt_5_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_4_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 355 */ {
return null;
} /* Line: 356 */
 else  /* Line: 353 */ {
bevt_7_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 357 */ {
bevt_8_tmpany_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpany_phold;
} /* Line: 358 */
 else  /* Line: 359 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 361 */ {
return null;
} /* Line: 362 */
} /* Line: 361 */
} /* Line: 353 */
} /* Line: 353 */
} /* Line: 353 */
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_5;
if (bevl_hval.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 373 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 377 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 379 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /* Line: 380 */
 else  /* Line: 379 */ {
bevt_6_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_5_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 381 */ {
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /* Line: 382 */
 else  /* Line: 379 */ {
bevt_9_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 383 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 384 */
 else  /* Line: 385 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 387 */ {
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /* Line: 388 */
} /* Line: 387 */
} /* Line: 379 */
} /* Line: 379 */
} /* Line: 379 */
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_6;
if (bevl_hval.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 399 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 400 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 404 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 406 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 407 */
 else  /* Line: 406 */ {
bevt_7_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_6_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 408 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 409 */
 else  /* Line: 406 */ {
bevt_10_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 410 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 414 */ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 414 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 416 */ {
bevt_15_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_14_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 416 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 416 */ {
bevt_16_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_16_tmpany_phold;
} /* Line: 417 */
 else  /* Line: 418 */ {
bevt_18_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_7;
bevt_17_tmpany_phold = bevl_sl.bem_subtract_1(bevt_18_tmpany_phold);
bevl_slt.bem_put_2(bevt_17_tmpany_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 420 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 422 */
 else  /* Line: 414 */ {
break;
} /* Line: 414 */
} /* Line: 414 */
bevt_19_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_19_tmpany_phold;
} /* Line: 424 */
 else  /* Line: 425 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 427 */ {
bevt_21_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_21_tmpany_phold;
} /* Line: 428 */
} /* Line: 427 */
} /* Line: 406 */
} /* Line: 406 */
} /* Line: 406 */
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
bevl_other = bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bevp_slots.bem_copy_0();
bevl_other.bemd_1(-78405692, bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 438 */ {
bevt_2_tmpany_phold = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 438 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 440 */ {
bevt_4_tmpany_phold = bevl_other.bemd_0(1109704349);
bevt_6_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpany_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_tmpany_phold.bem_new_3(bevt_7_tmpany_phold, bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_4_tmpany_phold.bemd_2(-845452519, bevl_i, bevt_5_tmpany_phold);
} /* Line: 441 */
 else  /* Line: 442 */ {
bevt_10_tmpany_phold = bevl_other.bemd_0(1109704349);
bevt_10_tmpany_phold.bemd_2(-845452519, bevl_i, null);
} /* Line: 443 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 438 */
 else  /* Line: 438 */ {
break;
} /* Line: 438 */
} /* Line: 438 */
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_clear_0() {
bevp_slots.bem_clear_0();
bevp_slots.bem_sizeSet_1(bevp_modu);
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_keyIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_nodeIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 482 */ {
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 483 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 483 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 485 */
} /* Line: 484 */
 else  /* Line: 483 */ {
break;
} /* Line: 483 */
} /* Line: 483 */
} /* Line: 483 */
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 494 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 494 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 495 */
 else  /* Line: 494 */ {
break;
} /* Line: 494 */
} /* Line: 494 */
if (beva_other == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 497 */ {
bevt_1_tmpany_loop = beva_other.bem_setIteratorGet_0();
while (true)
 /* Line: 498 */ {
bevt_4_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 498 */ {
bevl_x = bevt_1_tmpany_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 499 */
 else  /* Line: 498 */ {
break;
} /* Line: 498 */
} /* Line: 498 */
} /* Line: 498 */
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = (BEC_2_9_3_ContainerSet) bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 512 */ {
bevt_2_tmpany_phold = beva_other.bemd_1(1953776597, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 513 */ {
bevt_0_tmpany_loop = beva_other.bemd_0(812685421);
while (true)
 /* Line: 514 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-383924366);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 514 */ {
bevl_x = bevt_0_tmpany_loop.bemd_0(-25303237);
bem_put_1(bevl_x);
} /* Line: 515 */
 else  /* Line: 514 */ {
break;
} /* Line: 514 */
} /* Line: 514 */
} /* Line: 514 */
 else  /* Line: 513 */ {
bevt_4_tmpany_phold = beva_other.bemd_1(1953776597, bevp_baseNode);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 517 */ {
bevt_5_tmpany_phold = beva_other.bemd_0(-966518794);
bem_put_1(bevt_5_tmpany_phold);
} /* Line: 518 */
 else  /* Line: 519 */ {
bem_put_1(beva_other);
} /* Line: 520 */
} /* Line: 513 */
} /* Line: 513 */
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_slotsGet_0() {
return bevp_slots;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGetDirect_0() {
return bevp_slots;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_slotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_moduGet_0() {
return bevp_modu;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGetDirect_0() {
return bevp_modu;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_moduSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_multiGet_0() {
return bevp_multi;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiGetDirect_0() {
return bevp_multi;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_multiSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() {
return bevp_rel;
} /*method end*/
public BEC_3_9_3_9_ContainerSetRelations bem_relGetDirect_0() {
return bevp_rel;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_relSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() {
return bevp_baseNode;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGetDirect_0() {
return bevp_baseNode;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_baseNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() {
return bevp_innerPutAdded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_innerPutAddedGetDirect_0() {
return bevp_innerPutAdded;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_innerPutAddedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {214, 214, 220, 221, 222, 223, 224, 225, 226, 232, 232, 232, 233, 233, 235, 235, 239, 239, 239, 240, 240, 242, 242, 246, 246, 250, 250, 254, 254, 258, 258, 259, 260, 260, 261, 261, 261, 262, 262, 266, 266, 271, 271, 271, 271, 272, 273, 273, 274, 275, 277, 281, 281, 0, 281, 281, 281, 281, 0, 0, 282, 282, 284, 0, 284, 284, 285, 285, 285, 285, 285, 287, 287, 291, 292, 292, 293, 294, 294, 294, 295, 298, 300, 301, 303, 304, 304, 305, 305, 306, 306, 306, 308, 310, 311, 311, 312, 312, 312, 312, 313, 313, 314, 314, 315, 317, 318, 318, 320, 321, 321, 322, 322, 329, 329, 330, 331, 332, 332, 333, 335, 338, 343, 344, 345, 346, 346, 346, 347, 349, 350, 352, 353, 353, 354, 355, 355, 355, 355, 356, 357, 357, 358, 358, 360, 361, 361, 362, 369, 370, 371, 372, 372, 372, 373, 375, 376, 378, 379, 379, 380, 380, 381, 381, 381, 381, 382, 382, 383, 383, 384, 384, 386, 387, 387, 388, 388, 395, 396, 398, 399, 399, 399, 400, 402, 403, 405, 406, 406, 407, 407, 408, 408, 408, 408, 409, 409, 410, 410, 411, 412, 413, 414, 414, 415, 416, 416, 0, 416, 416, 416, 416, 0, 0, 417, 417, 419, 419, 419, 420, 422, 424, 424, 426, 427, 427, 428, 428, 435, 436, 437, 437, 438, 438, 438, 438, 439, 440, 440, 441, 441, 441, 441, 441, 441, 441, 443, 443, 438, 446, 451, 452, 453, 457, 457, 461, 461, 465, 465, 469, 469, 473, 473, 477, 477, 481, 482, 482, 483, 0, 483, 483, 484, 485, 489, 493, 494, 0, 494, 494, 495, 497, 497, 498, 0, 498, 498, 499, 502, 506, 507, 508, 512, 512, 513, 514, 0, 514, 514, 515, 517, 518, 518, 520, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {29, 30, 34, 35, 36, 37, 38, 39, 40, 48, 49, 54, 55, 56, 58, 59, 66, 67, 72, 73, 74, 76, 77, 81, 82, 86, 87, 92, 93, 105, 108, 110, 111, 116, 117, 118, 119, 121, 122, 130, 131, 141, 142, 143, 144, 145, 148, 149, 151, 152, 158, 174, 179, 180, 183, 184, 185, 190, 191, 194, 198, 199, 201, 201, 204, 206, 207, 208, 213, 214, 215, 222, 223, 248, 249, 254, 255, 256, 257, 262, 263, 267, 269, 270, 273, 274, 279, 280, 285, 286, 287, 288, 291, 293, 294, 295, 298, 299, 300, 305, 306, 307, 310, 311, 313, 314, 315, 316, 319, 320, 325, 326, 327, 340, 341, 343, 344, 347, 348, 350, 356, 359, 380, 381, 382, 383, 384, 389, 390, 392, 393, 396, 397, 402, 403, 406, 407, 408, 413, 414, 417, 418, 420, 421, 424, 425, 430, 431, 458, 459, 460, 461, 462, 467, 468, 470, 471, 474, 475, 480, 481, 482, 485, 486, 487, 492, 493, 494, 497, 498, 500, 501, 504, 505, 510, 511, 512, 548, 549, 550, 551, 552, 557, 558, 560, 561, 564, 565, 570, 571, 572, 575, 576, 577, 582, 583, 584, 587, 588, 590, 591, 592, 595, 600, 601, 602, 607, 608, 611, 612, 613, 618, 619, 622, 626, 627, 630, 631, 632, 633, 635, 641, 642, 645, 646, 651, 652, 653, 675, 676, 677, 678, 679, 682, 683, 688, 689, 690, 695, 696, 697, 698, 699, 700, 701, 702, 705, 706, 708, 714, 717, 718, 719, 724, 725, 729, 730, 734, 735, 739, 740, 744, 745, 749, 750, 759, 760, 765, 766, 766, 769, 771, 772, 774, 782, 792, 793, 793, 796, 798, 799, 805, 810, 811, 811, 814, 816, 817, 824, 828, 829, 830, 840, 845, 846, 848, 848, 851, 853, 854, 862, 864, 865, 868, 875, 878, 881, 885, 889, 892, 895, 899, 903, 906, 909, 913, 917, 920, 923, 927, 931, 934, 937, 941, 945, 948, 951, 955, 959, 962, 965, 969};
/* BEGIN LINEINFO 
assign 1 214 29
new 0 214 29
new 1 214 30
assign 1 220 34
new 1 220 34
assign 1 221 35
assign 1 222 36
new 0 222 36
assign 1 223 37
new 0 223 37
assign 1 224 38
new 0 224 38
assign 1 225 39
new 0 225 39
assign 1 226 40
new 0 226 40
assign 1 232 48
new 0 232 48
assign 1 232 49
equals 1 232 54
assign 1 233 55
new 0 233 55
return 1 233 56
assign 1 235 58
new 0 235 58
return 1 235 59
assign 1 239 66
new 0 239 66
assign 1 239 67
equals 1 239 72
assign 1 240 73
new 0 240 73
return 1 240 74
assign 1 242 76
new 0 242 76
return 1 242 77
assign 1 246 81
toString 0 246 81
return 1 246 82
assign 1 250 86
new 1 250 86
new 1 250 87
assign 1 254 92
new 1 254 92
return 1 254 93
assign 1 258 105
arrayIteratorGet 0 258 105
assign 1 258 108
hasNextGet 0 258 108
assign 1 259 110
nextGet 0 259 110
assign 1 260 111
def 1 260 116
assign 1 261 117
keyGet 0 261 117
assign 1 261 118
innerPut 4 261 118
assign 1 261 119
not 0 261 119
assign 1 262 121
new 0 262 121
return 1 262 122
assign 1 266 130
new 0 266 130
return 1 266 131
assign 1 271 141
sizeGet 0 271 141
assign 1 271 142
multiply 1 271 142
assign 1 271 143
new 0 271 143
assign 1 271 144
add 1 271 144
assign 1 272 145
new 1 272 145
assign 1 273 148
insertAll 2 273 148
assign 1 273 149
not 0 273 149
assign 1 274 151
increment 0 274 151
assign 1 275 152
new 1 275 152
return 1 277 158
assign 1 281 174
undef 1 281 179
assign 1 0 180
assign 1 281 183
sizeGet 0 281 183
assign 1 281 184
sizeGet 0 281 184
assign 1 281 185
notEquals 1 281 190
assign 1 0 191
assign 1 0 194
assign 1 282 198
new 0 282 198
return 1 282 199
assign 1 284 201
setIteratorGet 0 0 201
assign 1 284 204
hasNextGet 0 284 204
assign 1 284 206
nextGet 0 284 206
assign 1 285 207
has 1 285 207
assign 1 285 208
not 0 285 213
assign 1 285 214
new 0 285 214
return 1 285 215
assign 1 287 222
new 0 287 222
return 1 287 223
assign 1 291 248
sizeGet 0 291 248
assign 1 292 249
undef 1 292 254
assign 1 293 255
getHash 1 293 255
assign 1 294 256
new 0 294 256
assign 1 294 257
lesser 1 294 262
assign 1 295 263
abs 0 295 263
assign 1 298 267
hvalGet 0 298 267
assign 1 300 269
modulus 1 300 269
assign 1 301 270
assign 1 303 273
get 1 303 273
assign 1 304 274
undef 1 304 279
assign 1 305 280
undef 1 305 285
assign 1 306 286
create 0 306 286
assign 1 306 287
new 3 306 287
put 2 306 288
put 2 308 291
assign 1 310 293
new 0 310 293
assign 1 311 294
new 0 311 294
return 1 311 295
assign 1 312 298
hvalGet 0 312 298
assign 1 312 299
modulus 1 312 299
assign 1 312 300
notEquals 1 312 305
assign 1 313 306
new 0 313 306
return 1 313 307
assign 1 314 310
keyGet 0 314 310
assign 1 314 311
isEqual 2 314 311
putTo 2 315 313
assign 1 317 314
new 0 317 314
assign 1 318 315
new 0 318 315
return 1 318 316
assign 1 320 319
increment 0 320 319
assign 1 321 320
greaterEquals 1 321 325
assign 1 322 326
new 0 322 326
return 1 322 327
assign 1 329 340
innerPut 4 329 340
assign 1 329 341
not 0 329 341
assign 1 330 343
assign 1 331 344
rehash 1 331 344
assign 1 332 347
innerPut 4 332 347
assign 1 332 348
not 0 332 348
assign 1 333 350
rehash 1 333 350
assign 1 335 356
assign 1 338 359
increment 0 338 359
assign 1 343 380
assign 1 344 381
sizeGet 0 344 381
assign 1 345 382
getHash 1 345 382
assign 1 346 383
new 0 346 383
assign 1 346 384
lesser 1 346 389
assign 1 347 390
abs 0 347 390
assign 1 349 392
modulus 1 349 392
assign 1 350 393
assign 1 352 396
get 1 352 396
assign 1 353 397
undef 1 353 402
return 1 354 403
assign 1 355 406
hvalGet 0 355 406
assign 1 355 407
modulus 1 355 407
assign 1 355 408
notEquals 1 355 413
return 1 356 414
assign 1 357 417
keyGet 0 357 417
assign 1 357 418
isEqual 2 357 418
assign 1 358 420
getFrom 0 358 420
return 1 358 421
assign 1 360 424
increment 0 360 424
assign 1 361 425
greaterEquals 1 361 430
return 1 362 431
assign 1 369 458
assign 1 370 459
sizeGet 0 370 459
assign 1 371 460
getHash 1 371 460
assign 1 372 461
new 0 372 461
assign 1 372 462
lesser 1 372 467
assign 1 373 468
abs 0 373 468
assign 1 375 470
modulus 1 375 470
assign 1 376 471
assign 1 378 474
get 1 378 474
assign 1 379 475
undef 1 379 480
assign 1 380 481
new 0 380 481
return 1 380 482
assign 1 381 485
hvalGet 0 381 485
assign 1 381 486
modulus 1 381 486
assign 1 381 487
notEquals 1 381 492
assign 1 382 493
new 0 382 493
return 1 382 494
assign 1 383 497
keyGet 0 383 497
assign 1 383 498
isEqual 2 383 498
assign 1 384 500
new 0 384 500
return 1 384 501
assign 1 386 504
increment 0 386 504
assign 1 387 505
greaterEquals 1 387 510
assign 1 388 511
new 0 388 511
return 1 388 512
assign 1 395 548
assign 1 396 549
sizeGet 0 396 549
assign 1 398 550
getHash 1 398 550
assign 1 399 551
new 0 399 551
assign 1 399 552
lesser 1 399 557
assign 1 400 558
abs 0 400 558
assign 1 402 560
modulus 1 402 560
assign 1 403 561
assign 1 405 564
get 1 405 564
assign 1 406 565
undef 1 406 570
assign 1 407 571
new 0 407 571
return 1 407 572
assign 1 408 575
hvalGet 0 408 575
assign 1 408 576
modulus 1 408 576
assign 1 408 577
notEquals 1 408 582
assign 1 409 583
new 0 409 583
return 1 409 584
assign 1 410 587
keyGet 0 410 587
assign 1 410 588
isEqual 2 410 588
put 2 411 590
assign 1 412 591
decrement 0 412 591
assign 1 413 592
increment 0 413 592
assign 1 414 595
lesser 1 414 600
assign 1 415 601
get 1 415 601
assign 1 416 602
undef 1 416 607
assign 1 0 608
assign 1 416 611
hvalGet 0 416 611
assign 1 416 612
modulus 1 416 612
assign 1 416 613
notEquals 1 416 618
assign 1 0 619
assign 1 0 622
assign 1 417 626
new 0 417 626
return 1 417 627
assign 1 419 630
new 0 419 630
assign 1 419 631
subtract 1 419 631
put 2 419 632
put 2 420 633
assign 1 422 635
increment 0 422 635
assign 1 424 641
new 0 424 641
return 1 424 642
assign 1 426 645
increment 0 426 645
assign 1 427 646
greaterEquals 1 427 651
assign 1 428 652
new 0 428 652
return 1 428 653
assign 1 435 675
create 0 435 675
copyTo 1 436 676
assign 1 437 677
copy 0 437 677
slotsSet 1 437 678
assign 1 438 679
new 0 438 679
assign 1 438 682
lengthGet 0 438 682
assign 1 438 683
lesser 1 438 688
assign 1 439 689
get 1 439 689
assign 1 440 690
def 1 440 695
assign 1 441 696
slotsGet 0 441 696
assign 1 441 697
create 0 441 697
assign 1 441 698
hvalGet 0 441 698
assign 1 441 699
keyGet 0 441 699
assign 1 441 700
getFrom 0 441 700
assign 1 441 701
new 3 441 701
put 2 441 702
assign 1 443 705
slotsGet 0 443 705
put 2 443 706
assign 1 438 708
increment 0 438 708
return 1 446 714
clear 0 451 717
sizeSet 1 452 718
assign 1 453 719
new 0 453 719
assign 1 457 724
new 1 457 724
return 1 457 725
assign 1 461 729
new 1 461 729
return 1 461 730
assign 1 465 734
new 1 465 734
return 1 465 735
assign 1 469 739
keyIteratorGet 0 469 739
return 1 469 740
assign 1 473 744
new 1 473 744
return 1 473 745
assign 1 477 749
nodeIteratorGet 0 477 749
return 1 477 750
assign 1 481 759
new 0 481 759
assign 1 482 760
def 1 482 765
assign 1 483 766
setIteratorGet 0 0 766
assign 1 483 769
hasNextGet 0 483 769
assign 1 483 771
nextGet 0 483 771
assign 1 484 772
has 1 484 772
put 1 485 774
return 1 489 782
assign 1 493 792
new 0 493 792
assign 1 494 793
setIteratorGet 0 0 793
assign 1 494 796
hasNextGet 0 494 796
assign 1 494 798
nextGet 0 494 798
put 1 495 799
assign 1 497 805
def 1 497 810
assign 1 498 811
setIteratorGet 0 0 811
assign 1 498 814
hasNextGet 0 498 814
assign 1 498 816
nextGet 0 498 816
put 1 499 817
return 1 502 824
assign 1 506 828
copy 0 506 828
addValue 1 507 829
return 1 508 830
assign 1 512 840
def 1 512 845
assign 1 513 846
sameType 1 513 846
assign 1 514 848
iteratorGet 0 0 848
assign 1 514 851
hasNextGet 0 514 851
assign 1 514 853
nextGet 0 514 853
put 1 515 854
assign 1 517 862
sameType 1 517 862
assign 1 518 864
keyGet 0 518 864
put 1 518 865
put 1 520 868
return 1 0 875
return 1 0 878
assign 1 0 881
assign 1 0 885
return 1 0 889
return 1 0 892
assign 1 0 895
assign 1 0 899
return 1 0 903
return 1 0 906
assign 1 0 909
assign 1 0 913
return 1 0 917
return 1 0 920
assign 1 0 923
assign 1 0 927
return 1 0 931
return 1 0 934
assign 1 0 937
assign 1 0 941
return 1 0 945
return 1 0 948
assign 1 0 951
assign 1 0 955
return 1 0 959
return 1 0 962
assign 1 0 965
assign 1 0 969
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1907635971: return bem_tagGet_0();
case -927090833: return bem_new_0();
case -41389076: return bem_multiGet_0();
case -1002607895: return bem_sizeGetDirect_0();
case 1644159961: return bem_relGetDirect_0();
case 1109704349: return bem_slotsGet_0();
case -444269598: return bem_setIteratorGet_0();
case 1550760607: return bem_fieldIteratorGet_0();
case -65082849: return bem_once_0();
case 1926333158: return bem_relGet_0();
case 605655591: return bem_sourceFileNameGet_0();
case -1655660203: return bem_hashGet_0();
case -1577817259: return bem_echo_0();
case 1267812147: return bem_classNameGet_0();
case -1271382771: return bem_clear_0();
case -1572010998: return bem_copy_0();
case -1879356356: return bem_notEmptyGet_0();
case -112905867: return bem_keyIteratorGet_0();
case -1233682651: return bem_multiGetDirect_0();
case -1007878556: return bem_many_0();
case -1353172126: return bem_toString_0();
case 1242173088: return bem_moduGetDirect_0();
case 1840593132: return bem_sizeGet_0();
case 812685421: return bem_iteratorGet_0();
case 399659833: return bem_slotsGetDirect_0();
case 1530555194: return bem_serializeContents_0();
case 702246847: return bem_print_0();
case -1000018882: return bem_create_0();
case -500248069: return bem_serializationIteratorGet_0();
case -364249863: return bem_serializeToString_0();
case 513882387: return bem_baseNodeGetDirect_0();
case -1959825752: return bem_nodesGet_0();
case 2036694681: return bem_keysGet_0();
case -106257945: return bem_fieldNamesGet_0();
case 841108956: return bem_innerPutAddedGetDirect_0();
case 1524391071: return bem_baseNodeGet_0();
case 1472054563: return bem_isEmptyGet_0();
case 1966713191: return bem_deserializeClassNameGet_0();
case -474773744: return bem_nodeIteratorGet_0();
case 1581692921: return bem_toAny_0();
case 2020633149: return bem_moduGet_0();
case 308207615: return bem_innerPutAddedGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1543095159: return bem_multiSetDirect_1(bevd_0);
case -886218051: return bem_equals_1(bevd_0);
case -481756547: return bem_undef_1(bevd_0);
case -926431997: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -227529285: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1330834253: return bem_sizeSet_1(bevd_0);
case -1096288675: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1385994869: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 860351095: return bem_moduSet_1(bevd_0);
case 1258464331: return bem_has_1(bevd_0);
case -509638081: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 150021405: return bem_otherClass_1(bevd_0);
case -78405692: return bem_slotsSet_1(bevd_0);
case -1809912257: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -759946269: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1471457238: return bem_sameObject_1(bevd_0);
case -380623615: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1862075337: return bem_copyTo_1(bevd_0);
case 439602846: return bem_get_1(bevd_0);
case 1529065971: return bem_sizeSetDirect_1(bevd_0);
case 726015407: return bem_otherType_1(bevd_0);
case -1556952447: return bem_defined_1(bevd_0);
case -10869515: return bem_delete_1(bevd_0);
case -1633669948: return bem_innerPutAddedSet_1(bevd_0);
case 1673385175: return bem_notEquals_1(bevd_0);
case 1698158300: return bem_put_1(bevd_0);
case -684720356: return bem_slotsSetDirect_1(bevd_0);
case -1805171749: return bem_relSetDirect_1(bevd_0);
case 999858551: return bem_baseNodeSetDirect_1(bevd_0);
case -1940917614: return bem_addValue_1(bevd_0);
case 1953776597: return bem_sameType_1(bevd_0);
case 1829434833: return bem_moduSetDirect_1(bevd_0);
case -277595620: return bem_relSet_1(bevd_0);
case 140166424: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2141774895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 297381803: return bem_def_1(bevd_0);
case 1244819809: return bem_undefined_1(bevd_0);
case -58459221: return bem_sameClass_1(bevd_0);
case 69557453: return bem_multiSet_1(bevd_0);
case -1404821193: return bem_baseNodeSet_1(bevd_0);
case 1702481018: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1722905349: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -967702518: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -427898914: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 414161005: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 611344245: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -157052200: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1970963739: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 904162443: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 938028004: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_3_ContainerSet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_type;
}
}
}
