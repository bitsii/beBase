namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_6_IOFileWriterStdout : BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_6_IOFileWriterStdout() { }
static BEC_4_2_4_6_6_IOFileWriterStdout() { }
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStdout_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x53,0x74,0x64,0x6F,0x75,0x74};
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStdout_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_4_2_4_6_6_IOFileWriterStdout bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst;

public static new BET_4_2_4_6_6_IOFileWriterStdout bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStdout bem_default_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_isClosedGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_open_0() {
return this;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_close_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {685, 690, 690};
public static new int[] bevs_smnlec
 = new int[] {19, 27, 28};
/* BEGIN LINEINFO 
assign 1 685 19
new 0 685 19
assign 1 690 27
new 0 690 27
return 1 690 28
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1113652033: return bem_serializeToString_0();
case 705904898: return bem_echo_0();
case -1443081417: return bem_extOpen_0();
case 485739285: return bem_many_0();
case 740377946: return bem_fieldIteratorGet_0();
case 1830393821: return bem_serializationIteratorGet_0();
case -853943837: return bem_fieldNamesGet_0();
case -749374888: return bem_toAny_0();
case -769908714: return bem_serializeContents_0();
case 2143199287: return bem_once_0();
case 1977458570: return bem_isClosedGet_0();
case -65786574: return bem_isClosedGetDirect_0();
case -675377167: return bem_sourceFileNameGet_0();
case 2133981775: return bem_pathGet_0();
case 615816465: return bem_vfileGetDirect_0();
case -1043866834: return bem_deserializeClassNameGet_0();
case -143076951: return bem_iteratorGet_0();
case -2005904560: return bem_close_0();
case 1470547704: return bem_default_0();
case 905957116: return bem_create_0();
case -1284705725: return bem_openAppend_0();
case -363455556: return bem_print_0();
case 1634044932: return bem_pathGetDirect_0();
case -1066754440: return bem_openTruncate_0();
case 4057483: return bem_toString_0();
case 1492355280: return bem_vfileGet_0();
case -481509271: return bem_new_0();
case -1939888280: return bem_classNameGet_0();
case 427020448: return bem_tagGet_0();
case -159967270: return bem_open_0();
case 1277127917: return bem_hashGet_0();
case -2047177330: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1345391050: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case -458611020: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case -2021680719: return bem_sameObject_1(bevd_0);
case -1071341413: return bem_otherType_1(bevd_0);
case -785884455: return bem_isClosedSet_1(bevd_0);
case -383438063: return bem_def_1(bevd_0);
case 759969071: return bem_vfileSetDirect_1(bevd_0);
case 1353862901: return bem_sameType_1(bevd_0);
case 1474173561: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 986742986: return bem_pathSetDirect_1(bevd_0);
case -1709376459: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1755877526: return bem_notEquals_1(bevd_0);
case 2128107362: return bem_pathSet_1(bevd_0);
case -1354641129: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case -988024628: return bem_undef_1(bevd_0);
case -2137592378: return bem_undefined_1(bevd_0);
case -271328767: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2122304776: return bem_equals_1(bevd_0);
case -1312044810: return bem_isClosedSetDirect_1(bevd_0);
case -136446475: return bem_otherClass_1(bevd_0);
case -1127802964: return bem_new_1(bevd_0);
case -1520063387: return bem_defined_1(bevd_0);
case -73636763: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -578389793: return bem_sameClass_1(bevd_0);
case 915244770: return bem_vfileSet_1(bevd_0);
case -1924831101: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 503438982: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 837534085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 851139439: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 129124545: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1276325839: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 440463842: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -929921852: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_4_2_4_6_6_IOFileWriterStdout_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_6_IOFileWriterStdout_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_6_IOFileWriterStdout();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst = (BEC_4_2_4_6_6_IOFileWriterStdout) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_type;
}
}
}
