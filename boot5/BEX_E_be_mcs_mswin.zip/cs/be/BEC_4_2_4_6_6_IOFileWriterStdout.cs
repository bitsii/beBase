namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_6_IOFileWriterStdout : BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_6_IOFileWriterStdout() { }
static BEC_4_2_4_6_6_IOFileWriterStdout() { }
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStdout_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x53,0x74,0x64,0x6F,0x75,0x74};
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStdout_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_4_2_4_6_6_IOFileWriterStdout bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst;

public static new BET_4_2_4_6_6_IOFileWriterStdout bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStdout bem_default_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_isClosedGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_open_0() {
return this;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_close_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {685, 690, 690};
public static new int[] bevs_smnlec
 = new int[] {19, 27, 28};
/* BEGIN LINEINFO 
assign 1 685 19
new 0 685 19
assign 1 690 27
new 0 690 27
return 1 690 28
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1882778775: return bem_fieldIteratorGet_0();
case 48684490: return bem_echo_0();
case 1865983825: return bem_fieldNamesGet_0();
case 2017345633: return bem_copy_0();
case -160735352: return bem_once_0();
case -1322808685: return bem_vfileGetDirect_0();
case -378639299: return bem_extOpen_0();
case -1451048410: return bem_new_0();
case 872708376: return bem_toAny_0();
case 1200056076: return bem_serializationIteratorGet_0();
case -923282542: return bem_default_0();
case -1229803830: return bem_deserializeClassNameGet_0();
case -166013833: return bem_tagGet_0();
case -206043242: return bem_many_0();
case -1533701006: return bem_serializeContents_0();
case -966465247: return bem_pathGetDirect_0();
case 1330976730: return bem_hashGet_0();
case 1244458922: return bem_open_0();
case 907276784: return bem_serializeToString_0();
case 1988588081: return bem_openTruncate_0();
case -1990292643: return bem_toString_0();
case -1586484996: return bem_vfileGet_0();
case 1674575712: return bem_classNameGet_0();
case 966177429: return bem_close_0();
case 437089080: return bem_print_0();
case -1419115955: return bem_create_0();
case -940687671: return bem_isClosedGet_0();
case 1208354139: return bem_sourceFileNameGet_0();
case 1316585278: return bem_isClosedGetDirect_0();
case 917747777: return bem_pathGet_0();
case -2014542803: return bem_iteratorGet_0();
case -1106425414: return bem_openAppend_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 909810346: return bem_sameClass_1(bevd_0);
case 1920998617: return bem_sameObject_1(bevd_0);
case 625481528: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1386741229: return bem_vfileSet_1(bevd_0);
case 228067749: return bem_new_1(bevd_0);
case -840953319: return bem_notEquals_1(bevd_0);
case 783450299: return bem_isClosedSet_1(bevd_0);
case -185383596: return bem_sameType_1(bevd_0);
case -408080983: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case -677015629: return bem_pathSet_1(bevd_0);
case -1716631410: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case -1135925672: return bem_pathSetDirect_1(bevd_0);
case 1561328648: return bem_otherType_1(bevd_0);
case 161134859: return bem_defined_1(bevd_0);
case -1883651777: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case -1517637963: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -279352105: return bem_undefined_1(bevd_0);
case 584123032: return bem_def_1(bevd_0);
case 354557818: return bem_equals_1(bevd_0);
case 1596863802: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 170216407: return bem_copyTo_1(bevd_0);
case 1484567824: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1730224823: return bem_vfileSetDirect_1(bevd_0);
case -1822027791: return bem_otherClass_1(bevd_0);
case -630347320: return bem_isClosedSetDirect_1(bevd_0);
case 2122176784: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1467883232: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 465709808: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 936076332: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -758649425: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 105253121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -29810702: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 175222937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_4_2_4_6_6_IOFileWriterStdout_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_6_IOFileWriterStdout_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_6_IOFileWriterStdout();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst = (BEC_4_2_4_6_6_IOFileWriterStdout) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_type;
}
}
}
