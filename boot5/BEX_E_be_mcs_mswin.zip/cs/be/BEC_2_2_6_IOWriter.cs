namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_6_IOWriter : BEC_2_6_6_SystemObject {
public BEC_2_2_6_IOWriter() { }
static BEC_2_2_6_IOWriter() { }

   
    public System.IO.Stream bevi_os;
    
   private static byte[] becc_BEC_2_2_6_IOWriter_clname = {0x49,0x4F,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_2_2_6_IOWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_2_2_6_IOWriter bece_BEC_2_2_6_IOWriter_bevs_inst;

public static new BET_2_2_6_IOWriter bece_BEC_2_2_6_IOWriter_bevs_type;

public BEC_2_6_6_SystemObject bevp_vfile;
public BEC_2_5_4_LogicBool bevp_isClosed;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_2_6_IOWriter bem_vfileGet_0() {
return this;
} /*method end*/
public virtual BEC_2_2_6_IOWriter bem_vfileSet_1(BEC_2_6_6_SystemObject beva_vfile) {
return this;
} /*method end*/
public virtual BEC_2_2_6_IOWriter bem_extOpen_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_2_6_IOWriter bem_close_0() {

      if (this.bevi_os != null) {
        this.bevi_os.Dispose();
        this.bevi_os = null;
      }
      bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_2_6_IOWriter bem_write_1(BEC_2_4_6_TextString beva_stri) {

      this.bevi_os.Write(beva_stri.bevi_bytes, 0, beva_stri.bevp_size.bevi_int);
      return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isClosedGet_0() {
return bevp_isClosed;
} /*method end*/
public virtual BEC_2_2_6_IOWriter bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {469, 480, 517, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 32, 41, 50, 53};
/* BEGIN LINEINFO 
assign 1 469 22
new 0 469 22
assign 1 480 32
new 0 480 32
assign 1 517 41
new 0 517 41
return 1 0 50
assign 1 0 53
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1230030647: return bem_iteratorGet_0();
case -1380773853: return bem_print_0();
case -1546212617: return bem_hashGet_0();
case -1812592029: return bem_copy_0();
case 1765847529: return bem_toAny_0();
case 111705563: return bem_new_0();
case 1814659174: return bem_echo_0();
case -140254392: return bem_classNameGet_0();
case 1138959219: return bem_create_0();
case 1136611843: return bem_many_0();
case -1346342591: return bem_tagGet_0();
case -154821822: return bem_serializationIteratorGet_0();
case 2031852918: return bem_deserializeClassNameGet_0();
case -108571624: return bem_serializeContents_0();
case -110239012: return bem_sourceFileNameGet_0();
case 719240052: return bem_isClosedGet_0();
case -90627019: return bem_toString_0();
case 1843946637: return bem_fieldIteratorGet_0();
case 1159949094: return bem_extOpen_0();
case -375963306: return bem_serializeToString_0();
case 1826454756: return bem_once_0();
case 1266876836: return bem_vfileGet_0();
case 597093154: return bem_close_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2018573962: return bem_defined_1(bevd_0);
case -1745069966: return bem_def_1(bevd_0);
case 1909606580: return bem_isClosedSet_1(bevd_0);
case 1340954430: return bem_undefined_1(bevd_0);
case -796889896: return bem_vfileSet_1(bevd_0);
case -1157481258: return bem_sameObject_1(bevd_0);
case 1955134607: return bem_otherClass_1(bevd_0);
case -1198247472: return bem_undef_1(bevd_0);
case -2050905939: return bem_notEquals_1(bevd_0);
case -604934649: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1352048316: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -231386564: return bem_sameClass_1(bevd_0);
case 1526501544: return bem_copyTo_1(bevd_0);
case 2033783017: return bem_sameType_1(bevd_0);
case -898454377: return bem_equals_1(bevd_0);
case -166605595: return bem_otherType_1(bevd_0);
case 748668477: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 452045758: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 789816767: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1477024989: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1086183440: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -13817058: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1749882081: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -826896459: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 416141599: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 647643475: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_2_6_IOWriter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_6_IOWriter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_6_IOWriter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_6_IOWriter.bece_BEC_2_2_6_IOWriter_bevs_inst = (BEC_2_2_6_IOWriter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_6_IOWriter.bece_BEC_2_2_6_IOWriter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_6_IOWriter.bece_BEC_2_2_6_IOWriter_bevs_type;
}
}
}
