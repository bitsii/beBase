namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_7_ContainerSetSetNode : BEC_2_6_6_SystemObject {
public BEC_3_9_3_7_ContainerSetSetNode() { }
static BEC_3_9_3_7_ContainerSetSetNode() { }
private static byte[] becc_BEC_3_9_3_7_ContainerSetSetNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x53,0x65,0x74,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_3_7_ContainerSetSetNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_7_ContainerSetSetNode bece_BEC_3_9_3_7_ContainerSetSetNode_bevs_inst;

public static new BET_3_9_3_7_ContainerSetSetNode bece_BEC_3_9_3_7_ContainerSetSetNode_bevs_type;

public BEC_2_4_3_MathInt bevp_hval;
public BEC_2_6_6_SystemObject bevp_key;
public virtual BEC_3_9_3_7_ContainerSetSetNode bem_new_3(BEC_2_6_6_SystemObject beva__hval, BEC_2_6_6_SystemObject beva__key, BEC_2_6_6_SystemObject beva__value) {
bevp_hval = (BEC_2_4_3_MathInt) beva__hval;
bevp_key = beva__key;
return this;
} /*method end*/
public virtual BEC_3_9_3_7_ContainerSetSetNode bem_putTo_2(BEC_2_6_6_SystemObject beva__key, BEC_2_6_6_SystemObject beva__value) {
bevp_key = beva__key;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getFrom_0() {
return bevp_key;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hvalGet_0() {
return bevp_hval;
} /*method end*/
public BEC_2_4_3_MathInt bem_hvalGetDirect_0() {
return bevp_hval;
} /*method end*/
public virtual BEC_3_9_3_7_ContainerSetSetNode bem_hvalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hval = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_hvalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hval = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_keyGet_0() {
return bevp_key;
} /*method end*/
public BEC_2_6_6_SystemObject bem_keyGetDirect_0() {
return bevp_key;
} /*method end*/
public virtual BEC_3_9_3_7_ContainerSetSetNode bem_keySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_key = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_keySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_key = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {22, 23, 29, 33, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {15, 16, 20, 24, 27, 30, 33, 37, 41, 44, 47, 51};
/* BEGIN LINEINFO 
assign 1 22 15
assign 1 23 16
assign 1 29 20
return 1 33 24
return 1 0 27
return 1 0 30
assign 1 0 33
assign 1 0 37
return 1 0 41
return 1 0 44
assign 1 0 47
assign 1 0 51
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1990403754: return bem_getFrom_0();
case 2121039924: return bem_new_0();
case -964107848: return bem_hvalGetDirect_0();
case -1856486979: return bem_deserializeClassNameGet_0();
case -811418832: return bem_many_0();
case -992120130: return bem_fieldIteratorGet_0();
case 893274194: return bem_tagGet_0();
case 1057323332: return bem_toAny_0();
case -195266806: return bem_toString_0();
case 538632487: return bem_serializationIteratorGet_0();
case -189856578: return bem_copy_0();
case 1833804100: return bem_keyGetDirect_0();
case -166515831: return bem_fieldNamesGet_0();
case -1259074038: return bem_hvalGet_0();
case 1612027904: return bem_keyGet_0();
case -265928475: return bem_classNameGet_0();
case -1232978478: return bem_hashGet_0();
case 1236464998: return bem_serializeContents_0();
case 803060031: return bem_create_0();
case 2111391138: return bem_serializeToString_0();
case -299023655: return bem_echo_0();
case 1870744321: return bem_once_0();
case -1735879417: return bem_print_0();
case -1438038411: return bem_sourceFileNameGet_0();
case 24125772: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -905872983: return bem_equals_1(bevd_0);
case 146723804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1171661229: return bem_otherType_1(bevd_0);
case 1628306760: return bem_notEquals_1(bevd_0);
case -267062499: return bem_sameType_1(bevd_0);
case -132983687: return bem_undefined_1(bevd_0);
case 1669121148: return bem_copyTo_1(bevd_0);
case 1681419755: return bem_defined_1(bevd_0);
case 1703705428: return bem_keySetDirect_1(bevd_0);
case 245933469: return bem_keySet_1(bevd_0);
case -1233382567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2050700916: return bem_hvalSet_1(bevd_0);
case -490313093: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -564148923: return bem_sameObject_1(bevd_0);
case -1108496649: return bem_otherClass_1(bevd_0);
case 2018821997: return bem_hvalSetDirect_1(bevd_0);
case 525545408: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1374125024: return bem_undef_1(bevd_0);
case 1025270681: return bem_sameClass_1(bevd_0);
case -1433803932: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1931375919: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 68692131: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383175850: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -110664853: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1765848815: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -802698694: return bem_putTo_2(bevd_0, bevd_1);
case 1365987158: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -381061425: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -22002276: return bem_new_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_9_3_7_ContainerSetSetNode_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_7_ContainerSetSetNode_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_7_ContainerSetSetNode();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_7_ContainerSetSetNode.bece_BEC_3_9_3_7_ContainerSetSetNode_bevs_inst = (BEC_3_9_3_7_ContainerSetSetNode) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_7_ContainerSetSetNode.bece_BEC_3_9_3_7_ContainerSetSetNode_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_7_ContainerSetSetNode.bece_BEC_3_9_3_7_ContainerSetSetNode_bevs_type;
}
}
}
