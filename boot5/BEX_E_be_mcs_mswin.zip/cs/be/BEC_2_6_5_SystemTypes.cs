namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_5_SystemTypes : BEC_2_6_6_SystemObject {
public BEC_2_6_5_SystemTypes() { }
static BEC_2_6_5_SystemTypes() { }
private static byte[] becc_BEC_2_6_5_SystemTypes_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_6_5_SystemTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_inst;

public static new BET_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_type;

public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_bool;
public BEC_2_4_5_MathFloat bevp_float;
public BEC_2_6_5_SystemThing bevp_thing;
public BEC_2_4_6_TextString bevp_string;
public BEC_2_4_6_TextString bevp_byteBuffer;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_default_0() {
bevp_int = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_bool = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_float = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();
bevp_thing = (BEC_2_6_5_SystemThing) (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_string = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_byteBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGet_0() {
return bevp_int;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGetDirect_0() {
return bevp_int;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boolGet_0() {
return bevp_bool;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boolGetDirect_0() {
return bevp_bool;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_boolSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_boolSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_floatGet_0() {
return bevp_float;
} /*method end*/
public BEC_2_4_5_MathFloat bem_floatGetDirect_0() {
return bevp_float;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_floatSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_floatSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemThing bem_thingGet_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_5_SystemThing bem_thingGetDirect_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_stringGet_0() {
return bevp_string;
} /*method end*/
public BEC_2_4_6_TextString bem_stringGetDirect_0() {
return bevp_string;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_string = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_string = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_byteBufferGet_0() {
return bevp_byteBuffer;
} /*method end*/
public BEC_2_4_6_TextString bem_byteBufferGetDirect_0() {
return bevp_byteBuffer;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_byteBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_byteBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {294, 295, 296, 297, 298, 299, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 29, 30, 31, 32, 36, 39, 42, 46, 50, 53, 56, 60, 64, 67, 70, 74, 78, 81, 84, 88, 92, 95, 98, 102, 106, 109, 112, 116};
/* BEGIN LINEINFO 
assign 1 294 27
new 0 294 27
assign 1 295 28
new 0 295 28
assign 1 296 29
new 0 296 29
assign 1 297 30
new 0 297 30
assign 1 298 31
new 0 298 31
assign 1 299 32
new 0 299 32
return 1 0 36
return 1 0 39
assign 1 0 42
assign 1 0 46
return 1 0 50
return 1 0 53
assign 1 0 56
assign 1 0 60
return 1 0 64
return 1 0 67
assign 1 0 70
assign 1 0 74
return 1 0 78
return 1 0 81
assign 1 0 84
assign 1 0 88
return 1 0 92
return 1 0 95
assign 1 0 98
assign 1 0 102
return 1 0 106
return 1 0 109
assign 1 0 112
assign 1 0 116
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1196099876: return bem_echo_0();
case 1452249789: return bem_intGet_0();
case -888502976: return bem_print_0();
case -170941956: return bem_serializeToString_0();
case 28921621: return bem_floatGetDirect_0();
case 40131798: return bem_stringGetDirect_0();
case 1989485633: return bem_many_0();
case -1511815073: return bem_byteBufferGet_0();
case -1222154604: return bem_tagGet_0();
case -494057832: return bem_serializationIteratorGet_0();
case -937358711: return bem_default_0();
case 4951343: return bem_boolGetDirect_0();
case -938119864: return bem_boolGet_0();
case -294806467: return bem_create_0();
case 213564239: return bem_copy_0();
case -1916548323: return bem_once_0();
case -242463884: return bem_fieldIteratorGet_0();
case -1230714712: return bem_classNameGet_0();
case -671191297: return bem_serializeContents_0();
case -1342633655: return bem_hashGet_0();
case -1297985879: return bem_fieldNamesGet_0();
case 1418348540: return bem_iteratorGet_0();
case -1925247459: return bem_sourceFileNameGet_0();
case 1832806152: return bem_toString_0();
case 1135080109: return bem_floatGet_0();
case 1674611563: return bem_thingGet_0();
case 593076356: return bem_intGetDirect_0();
case -302817860: return bem_deserializeClassNameGet_0();
case -2015966004: return bem_stringGet_0();
case 1797020795: return bem_toAny_0();
case 789087058: return bem_thingGetDirect_0();
case -1371848308: return bem_byteBufferGetDirect_0();
case -1628841870: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1040130016: return bem_intSet_1(bevd_0);
case 83181817: return bem_undef_1(bevd_0);
case -1451132900: return bem_intSetDirect_1(bevd_0);
case -206578942: return bem_stringSetDirect_1(bevd_0);
case -152296894: return bem_equals_1(bevd_0);
case 744043439: return bem_floatSetDirect_1(bevd_0);
case -810647371: return bem_sameClass_1(bevd_0);
case 1602348302: return bem_sameObject_1(bevd_0);
case -72189386: return bem_boolSetDirect_1(bevd_0);
case 346995129: return bem_def_1(bevd_0);
case -1516543081: return bem_boolSet_1(bevd_0);
case -788622974: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -395616432: return bem_otherClass_1(bevd_0);
case 936942966: return bem_undefined_1(bevd_0);
case 1345095935: return bem_defined_1(bevd_0);
case 945449374: return bem_notEquals_1(bevd_0);
case 1173202089: return bem_stringSet_1(bevd_0);
case -2046043947: return bem_copyTo_1(bevd_0);
case -1967180933: return bem_thingSetDirect_1(bevd_0);
case -559694945: return bem_byteBufferSetDirect_1(bevd_0);
case 1495593147: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 22410956: return bem_floatSet_1(bevd_0);
case -1811224480: return bem_sameType_1(bevd_0);
case -118558475: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -4969921: return bem_thingSet_1(bevd_0);
case 79810732: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1796596677: return bem_otherType_1(bevd_0);
case 368973064: return bem_byteBufferSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -174395426: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1117645207: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1434652185: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2038467728: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 6185266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 34704188: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1515774718: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_6_5_SystemTypes_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_5_SystemTypes_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_5_SystemTypes();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst = (BEC_2_6_5_SystemTypes) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_type;
}
}
}
