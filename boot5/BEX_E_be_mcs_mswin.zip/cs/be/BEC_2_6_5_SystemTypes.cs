namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_5_SystemTypes : BEC_2_6_6_SystemObject {
public BEC_2_6_5_SystemTypes() { }
static BEC_2_6_5_SystemTypes() { }
private static byte[] becc_BEC_2_6_5_SystemTypes_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_6_5_SystemTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_inst;

public static new BET_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_type;

public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_bool;
public BEC_2_4_5_MathFloat bevp_float;
public BEC_2_6_5_SystemThing bevp_thing;
public BEC_2_4_6_TextString bevp_string;
public BEC_2_4_6_TextString bevp_byteBuffer;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_default_0() {
bevp_int = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_bool = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_float = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();
bevp_thing = (BEC_2_6_5_SystemThing) (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_string = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_byteBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGet_0() {
return bevp_int;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGetDirect_0() {
return bevp_int;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boolGet_0() {
return bevp_bool;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boolGetDirect_0() {
return bevp_bool;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_boolSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_boolSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_floatGet_0() {
return bevp_float;
} /*method end*/
public BEC_2_4_5_MathFloat bem_floatGetDirect_0() {
return bevp_float;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_floatSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_floatSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemThing bem_thingGet_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_5_SystemThing bem_thingGetDirect_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_stringGet_0() {
return bevp_string;
} /*method end*/
public BEC_2_4_6_TextString bem_stringGetDirect_0() {
return bevp_string;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_string = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_string = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_byteBufferGet_0() {
return bevp_byteBuffer;
} /*method end*/
public BEC_2_4_6_TextString bem_byteBufferGetDirect_0() {
return bevp_byteBuffer;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_byteBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_byteBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {324, 325, 326, 327, 328, 329, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 29, 30, 31, 32, 36, 39, 42, 46, 50, 53, 56, 60, 64, 67, 70, 74, 78, 81, 84, 88, 92, 95, 98, 102, 106, 109, 112, 116};
/* BEGIN LINEINFO 
assign 1 324 27
new 0 324 27
assign 1 325 28
new 0 325 28
assign 1 326 29
new 0 326 29
assign 1 327 30
new 0 327 30
assign 1 328 31
new 0 328 31
assign 1 329 32
new 0 329 32
return 1 0 36
return 1 0 39
assign 1 0 42
assign 1 0 46
return 1 0 50
return 1 0 53
assign 1 0 56
assign 1 0 60
return 1 0 64
return 1 0 67
assign 1 0 70
assign 1 0 74
return 1 0 78
return 1 0 81
assign 1 0 84
assign 1 0 88
return 1 0 92
return 1 0 95
assign 1 0 98
assign 1 0 102
return 1 0 106
return 1 0 109
assign 1 0 112
assign 1 0 116
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 251429542: return bem_default_0();
case 2121039924: return bem_new_0();
case 961901995: return bem_floatGetDirect_0();
case -1168687000: return bem_byteBufferGet_0();
case -1856486979: return bem_deserializeClassNameGet_0();
case 527313396: return bem_stringGet_0();
case -811418832: return bem_many_0();
case -992120130: return bem_fieldIteratorGet_0();
case 893274194: return bem_tagGet_0();
case 1057323332: return bem_toAny_0();
case -195266806: return bem_toString_0();
case 538632487: return bem_serializationIteratorGet_0();
case -1948140488: return bem_thingGet_0();
case -1294893177: return bem_intGet_0();
case 1403279953: return bem_intGetDirect_0();
case 680251748: return bem_thingGetDirect_0();
case -1767317935: return bem_byteBufferGetDirect_0();
case -189856578: return bem_copy_0();
case -166515831: return bem_fieldNamesGet_0();
case 1165026972: return bem_stringGetDirect_0();
case -265928475: return bem_classNameGet_0();
case -1232978478: return bem_hashGet_0();
case 174802574: return bem_boolGetDirect_0();
case 1236464998: return bem_serializeContents_0();
case 803060031: return bem_create_0();
case 847286277: return bem_floatGet_0();
case 943923683: return bem_boolGet_0();
case 2111391138: return bem_serializeToString_0();
case -299023655: return bem_echo_0();
case 1870744321: return bem_once_0();
case -1735879417: return bem_print_0();
case -1438038411: return bem_sourceFileNameGet_0();
case 24125772: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1433803932: return bem_def_1(bevd_0);
case -267062499: return bem_sameType_1(bevd_0);
case 1628306760: return bem_notEquals_1(bevd_0);
case 495687270: return bem_stringSet_1(bevd_0);
case -905872983: return bem_equals_1(bevd_0);
case 1817819709: return bem_thingSetDirect_1(bevd_0);
case 327517767: return bem_floatSet_1(bevd_0);
case 525545408: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2054809002: return bem_thingSet_1(bevd_0);
case -490313093: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1025270681: return bem_sameClass_1(bevd_0);
case -191703553: return bem_intSet_1(bevd_0);
case -132983687: return bem_undefined_1(bevd_0);
case 1669121148: return bem_copyTo_1(bevd_0);
case -1782060847: return bem_byteBufferSet_1(bevd_0);
case 146723804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -335870931: return bem_boolSet_1(bevd_0);
case 1460591913: return bem_byteBufferSetDirect_1(bevd_0);
case -205682768: return bem_stringSetDirect_1(bevd_0);
case 1625140019: return bem_intSetDirect_1(bevd_0);
case -1374125024: return bem_undef_1(bevd_0);
case -1233382567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1108496649: return bem_otherClass_1(bevd_0);
case 261476508: return bem_boolSetDirect_1(bevd_0);
case -1171661229: return bem_otherType_1(bevd_0);
case 1681419755: return bem_defined_1(bevd_0);
case 2121469214: return bem_floatSetDirect_1(bevd_0);
case -564148923: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1931375919: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 68692131: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383175850: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -110664853: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1765848815: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1365987158: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -381061425: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_6_5_SystemTypes_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_5_SystemTypes_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_5_SystemTypes();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst = (BEC_2_6_5_SystemTypes) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_type;
}
}
}
