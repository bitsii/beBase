namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_15_SystemCurrentPlatform : BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
static BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static new BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 565 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 566 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.platformName));
                bem_setName_1(bevl_platformName);
} /* Line: 589 */
} /* Line: 566 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public override BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
base.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(1162734496, bevp_newline);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {566, 566, 589, 595, 596, 600, 601, 602};
public static new int[] bevs_smnlec
 = new int[] {24, 29, 32, 38, 39, 44, 45, 46};
/* BEGIN LINEINFO 
assign 1 566 24
undef 1 566 29
setName 1 589 32
assign 1 595 38
buildProfile 0 596 39
buildProfile 0 600 44
assign 1 601 45
new 0 601 45
newlineSet 1 602 46
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 605655591: return bem_sourceFileNameGet_0();
case 1267812147: return bem_classNameGet_0();
case 702246847: return bem_print_0();
case -364249863: return bem_serializeToString_0();
case -1353172126: return bem_toString_0();
case 1966713191: return bem_deserializeClassNameGet_0();
case -1655660203: return bem_hashGet_0();
case -500248069: return bem_serializationIteratorGet_0();
case 1581692921: return bem_toAny_0();
case -1572010998: return bem_copy_0();
case -1955645604: return bem_isNixGet_0();
case 1913332038: return bem_separatorGetDirect_0();
case -1313014879: return bem_newlineGet_0();
case -1003635603: return bem_nullFileGetDirect_0();
case 1530555194: return bem_serializeContents_0();
case -1930465770: return bem_newlineGetDirect_0();
case 1566067812: return bem_properNameGetDirect_0();
case 1663705867: return bem_isWinGet_0();
case 812685421: return bem_iteratorGet_0();
case -1297435273: return bem_otherSeparatorGet_0();
case -1138642109: return bem_otherSeparatorGetDirect_0();
case 849044109: return bem_nullFileGet_0();
case 1956316046: return bem_nameGet_0();
case -1606441976: return bem_scriptExtGet_0();
case -1000018882: return bem_create_0();
case -1529886987: return bem_default_0();
case 1521205131: return bem_nameGetDirect_0();
case -65082849: return bem_once_0();
case -836852780: return bem_isNixGetDirect_0();
case -1907635971: return bem_tagGet_0();
case -106257945: return bem_fieldNamesGet_0();
case -1577817259: return bem_echo_0();
case -1737372041: return bem_buildProfile_0();
case -630698614: return bem_scriptExtGetDirect_0();
case 1714625437: return bem_properNameGet_0();
case 1550760607: return bem_fieldIteratorGet_0();
case -927090833: return bem_new_0();
case 656434509: return bem_separatorGet_0();
case 1685485245: return bem_isWinGetDirect_0();
case -1007878556: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1229684250: return bem_otherSeparatorSetDirect_1(bevd_0);
case 1411880885: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case 111100383: return bem_isWinSetDirect_1(bevd_0);
case 1953776597: return bem_sameType_1(bevd_0);
case 1650905702: return bem_separatorSetDirect_1(bevd_0);
case -58459221: return bem_sameClass_1(bevd_0);
case 170746806: return bem_otherSeparatorSet_1(bevd_0);
case 1864185570: return bem_isNixSet_1(bevd_0);
case 1531593391: return bem_scriptExtSetDirect_1(bevd_0);
case -1556952447: return bem_defined_1(bevd_0);
case -1471457238: return bem_sameObject_1(bevd_0);
case -1420991: return bem_isWinSet_1(bevd_0);
case 140166424: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1244819809: return bem_undefined_1(bevd_0);
case -886218051: return bem_equals_1(bevd_0);
case 1389840560: return bem_properNameSet_1(bevd_0);
case 1673385175: return bem_notEquals_1(bevd_0);
case -1048543903: return bem_newlineSetDirect_1(bevd_0);
case 297381803: return bem_def_1(bevd_0);
case -227529285: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1674243123: return bem_nullFileSetDirect_1(bevd_0);
case 150021405: return bem_otherClass_1(bevd_0);
case -481756547: return bem_undef_1(bevd_0);
case -258382158: return bem_nameSetDirect_1(bevd_0);
case -1862075337: return bem_copyTo_1(bevd_0);
case 1540847859: return bem_nullFileSet_1(bevd_0);
case -1060130098: return bem_isNixSetDirect_1(bevd_0);
case 2141774895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 320683756: return bem_scriptExtSet_1(bevd_0);
case -791006622: return bem_separatorSet_1(bevd_0);
case 1162734496: return bem_newlineSet_1(bevd_0);
case 1970413721: return bem_nameSet_1(bevd_0);
case -759946269: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 726015407: return bem_otherType_1(bevd_0);
case -745995587: return bem_properNameSetDirect_1(bevd_0);
case -380623615: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1722905349: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -967702518: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -427898914: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 414161005: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 611344245: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -157052200: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1970963739: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
}
