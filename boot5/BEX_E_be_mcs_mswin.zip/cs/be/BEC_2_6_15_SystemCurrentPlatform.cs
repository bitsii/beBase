namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_15_SystemCurrentPlatform : BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
static BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static new BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 536 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 537 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.platformName));
                bem_setName_1(bevl_platformName);
} /* Line: 555 */
} /* Line: 537 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public override BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
base.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-353398981, bevp_newline);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {537, 537, 555, 561, 562, 566, 567, 568};
public static new int[] bevs_smnlec
 = new int[] {24, 29, 32, 38, 39, 44, 45, 46};
/* BEGIN LINEINFO 
assign 1 537 24
undef 1 537 29
setName 1 555 32
assign 1 561 38
buildProfile 0 562 39
buildProfile 0 566 44
assign 1 567 45
new 0 567 45
newlineSet 1 568 46
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2111733819: return bem_isNixGet_0();
case 1196099876: return bem_echo_0();
case -791391122: return bem_isWinGetDirect_0();
case -888502976: return bem_print_0();
case -1423406500: return bem_isNixGetDirect_0();
case -170941956: return bem_serializeToString_0();
case 1989485633: return bem_many_0();
case -1222154604: return bem_tagGet_0();
case -494057832: return bem_serializationIteratorGet_0();
case 1409293924: return bem_buildProfile_0();
case -937358711: return bem_default_0();
case -1188059775: return bem_isWinGet_0();
case -279588908: return bem_nameGetDirect_0();
case 43475100: return bem_newlineGetDirect_0();
case -1722861324: return bem_separatorGetDirect_0();
case -294806467: return bem_create_0();
case 213564239: return bem_copy_0();
case -1916548323: return bem_once_0();
case -242463884: return bem_fieldIteratorGet_0();
case -1064378719: return bem_otherSeparatorGet_0();
case -1230714712: return bem_classNameGet_0();
case -671191297: return bem_serializeContents_0();
case -1342633655: return bem_hashGet_0();
case -1297985879: return bem_fieldNamesGet_0();
case 1418348540: return bem_iteratorGet_0();
case 19955222: return bem_separatorGet_0();
case -1925247459: return bem_sourceFileNameGet_0();
case 1911091695: return bem_otherSeparatorGetDirect_0();
case 1832806152: return bem_toString_0();
case -1673626578: return bem_nullFileGetDirect_0();
case -302817860: return bem_deserializeClassNameGet_0();
case 1797020795: return bem_toAny_0();
case 1166664450: return bem_nameGet_0();
case -1722474840: return bem_newlineGet_0();
case -1805687238: return bem_nullFileGet_0();
case -1628841870: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -118558475: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1264695616: return bem_isWinSet_1(bevd_0);
case -810647371: return bem_sameClass_1(bevd_0);
case -788622974: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1345095935: return bem_defined_1(bevd_0);
case 1602348302: return bem_sameObject_1(bevd_0);
case -395616432: return bem_otherClass_1(bevd_0);
case 79810732: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1796596677: return bem_otherType_1(bevd_0);
case 964340918: return bem_newlineSetDirect_1(bevd_0);
case -1436334009: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1010869096: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case 93271673: return bem_nameSet_1(bevd_0);
case -500762724: return bem_isNixSet_1(bevd_0);
case -603742475: return bem_separatorSet_1(bevd_0);
case -1311849381: return bem_nullFileSet_1(bevd_0);
case 346995129: return bem_def_1(bevd_0);
case -353398981: return bem_newlineSet_1(bevd_0);
case -256012485: return bem_isNixSetDirect_1(bevd_0);
case -715394232: return bem_nullFileSetDirect_1(bevd_0);
case 936942966: return bem_undefined_1(bevd_0);
case -543390335: return bem_otherSeparatorSet_1(bevd_0);
case 1495593147: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1811224480: return bem_sameType_1(bevd_0);
case 945449374: return bem_notEquals_1(bevd_0);
case -1229364216: return bem_nameSetDirect_1(bevd_0);
case 83181817: return bem_undef_1(bevd_0);
case -1444051280: return bem_isWinSetDirect_1(bevd_0);
case -152296894: return bem_equals_1(bevd_0);
case 565419966: return bem_separatorSetDirect_1(bevd_0);
case -2046043947: return bem_copyTo_1(bevd_0);
case 1075755544: return bem_otherSeparatorSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -174395426: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1117645207: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1434652185: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2038467728: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 6185266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 34704188: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1515774718: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
}
