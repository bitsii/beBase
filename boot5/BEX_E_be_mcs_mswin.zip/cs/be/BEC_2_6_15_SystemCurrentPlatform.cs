namespace be {

using System;
// for threading
using System.Threading;
    /* IO:File: source/base/ExtSystem.be */
public sealed class BEC_2_6_15_SystemCurrentPlatform : BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
static BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static new BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
/* Line: 267*/ {
if (bevp_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 268*/ {

                    bevl_platformName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.platformName));
                /* Line: 283*/ {
} /* Line: 284*/
/* Line: 291*/ {
} /* Line: 292*/
bem_setName_1(bevl_platformName);
} /* Line: 298*/
} /* Line: 268*/
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public override BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
base.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-1236970781, bevp_newline);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {268, 268, 298, 304, 305, 309, 310, 311};
public static new int[] bevs_smnlec
 = new int[] {23, 28, 35, 41, 42, 47, 48, 49};
/* BEGIN LINEINFO 
assign 1 268 23
undef 1 268 28
setName 1 298 35
assign 1 304 41
buildProfile 0 305 42
buildProfile 0 309 47
assign 1 310 48
new 0 310 48
newlineSet 1 311 49
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 707417315: return bem_newlineGet_0();
case -652053502: return bem_fieldNamesGet_0();
case 435669723: return bem_nullFileGet_0();
case 944073339: return bem_fieldIteratorGet_0();
case -1785724794: return bem_once_0();
case 615734246: return bem_otherSeparatorGet_0();
case -1497604239: return bem_properNameGetDirect_0();
case -1480556491: return bem_toAny_0();
case -1760832906: return bem_separatorGet_0();
case 168135582: return bem_create_0();
case 957570195: return bem_otherSeparatorGetDirect_0();
case -462816280: return bem_nameGetDirect_0();
case 2132420479: return bem_many_0();
case -2144448811: return bem_properNameGet_0();
case -1359614197: return bem_classNameGet_0();
case -2079457415: return bem_nameGet_0();
case -1770722520: return bem_scriptExtGet_0();
case -1549494882: return bem_buildProfile_0();
case -1044758745: return bem_serializeToString_0();
case -792711016: return bem_isNixGetDirect_0();
case 1779624788: return bem_default_0();
case 759496930: return bem_tagGet_0();
case 1628225191: return bem_scriptExtGetDirect_0();
case 350691792: return bem_toString_0();
case 814334258: return bem_serializeContents_0();
case -1555833296: return bem_sourceFileNameGet_0();
case 1081516158: return bem_isNixGet_0();
case 219532045: return bem_newlineGetDirect_0();
case -1642361296: return bem_print_0();
case -202912463: return bem_copy_0();
case 2044767051: return bem_separatorGetDirect_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 1365897346: return bem_serializationIteratorGet_0();
case 1053491366: return bem_nullFileGetDirect_0();
case 1573198275: return bem_isWinGet_0();
case 128055141: return bem_isWinGetDirect_0();
case 1161638424: return bem_new_0();
case -71162589: return bem_iteratorGet_0();
case -1711670377: return bem_hashGet_0();
case 2064925791: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1432148458: return bem_nameSet_1(bevd_0);
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -313885040: return bem_separatorSetDirect_1(bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -738776058: return bem_isWinSet_1(bevd_0);
case -2081758286: return bem_properNameSetDirect_1(bevd_0);
case -1829001662: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case 1704964450: return bem_separatorSet_1(bevd_0);
case 1015143156: return bem_nullFileSetDirect_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case -999406865: return bem_nullFileSet_1(bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case 260507228: return bem_nameSetDirect_1(bevd_0);
case -334724974: return bem_newlineSetDirect_1(bevd_0);
case 65986903: return bem_otherSeparatorSetDirect_1(bevd_0);
case -616716775: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case 328367961: return bem_scriptExtSet_1(bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -417870088: return bem_isNixSet_1(bevd_0);
case 981769415: return bem_scriptExtSetDirect_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case -1236970781: return bem_newlineSet_1(bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case 764789626: return bem_isNixSetDirect_1(bevd_0);
case -485946099: return bem_properNameSet_1(bevd_0);
case -709039399: return bem_isWinSetDirect_1(bevd_0);
case -1799386826: return bem_otherSeparatorSet_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
}
