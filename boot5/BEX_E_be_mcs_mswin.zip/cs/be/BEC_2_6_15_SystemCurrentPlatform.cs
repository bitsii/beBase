namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_15_SystemCurrentPlatform : BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
static BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static new BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 566 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 567 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.platformName));
                bem_setName_1(bevl_platformName);
} /* Line: 590 */
} /* Line: 567 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public override BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
base.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(645333239, bevp_newline);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {567, 567, 590, 596, 597, 601, 602, 603};
public static new int[] bevs_smnlec
 = new int[] {24, 29, 32, 38, 39, 44, 45, 46};
/* BEGIN LINEINFO 
assign 1 567 24
undef 1 567 29
setName 1 590 32
assign 1 596 38
buildProfile 0 597 39
buildProfile 0 601 44
assign 1 602 45
new 0 602 45
newlineSet 1 603 46
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1500381597: return bem_isWinGet_0();
case 251429542: return bem_default_0();
case 2121039924: return bem_new_0();
case -1649401148: return bem_isNixGet_0();
case -1856486979: return bem_deserializeClassNameGet_0();
case -811418832: return bem_many_0();
case -2044113939: return bem_isWinGetDirect_0();
case -992120130: return bem_fieldIteratorGet_0();
case 893274194: return bem_tagGet_0();
case 1097912359: return bem_isNixGetDirect_0();
case 1057323332: return bem_toAny_0();
case -195266806: return bem_toString_0();
case 538632487: return bem_serializationIteratorGet_0();
case -1929015479: return bem_nameGet_0();
case -189856578: return bem_copy_0();
case 503318152: return bem_otherSeparatorGet_0();
case -1203173481: return bem_separatorGet_0();
case -166515831: return bem_fieldNamesGet_0();
case 1443401449: return bem_newlineGetDirect_0();
case -265928475: return bem_classNameGet_0();
case -1232978478: return bem_hashGet_0();
case -1482002946: return bem_newlineGet_0();
case 1236464998: return bem_serializeContents_0();
case 157322450: return bem_nullFileGet_0();
case 803060031: return bem_create_0();
case 163902031: return bem_otherSeparatorGetDirect_0();
case 913680749: return bem_nameGetDirect_0();
case 2111391138: return bem_serializeToString_0();
case -299023655: return bem_echo_0();
case 1870744321: return bem_once_0();
case 910547594: return bem_buildProfile_0();
case -1735879417: return bem_print_0();
case -1438038411: return bem_sourceFileNameGet_0();
case 1595333978: return bem_nullFileGetDirect_0();
case 24125772: return bem_iteratorGet_0();
case 2018764748: return bem_separatorGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 645333239: return bem_newlineSet_1(bevd_0);
case 1495337677: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -20250794: return bem_otherSeparatorSetDirect_1(bevd_0);
case -1044203706: return bem_nullFileSetDirect_1(bevd_0);
case -1955762289: return bem_isWinSetDirect_1(bevd_0);
case 1669121148: return bem_copyTo_1(bevd_0);
case 1388532219: return bem_isNixSet_1(bevd_0);
case 712489064: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -490313093: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2001687309: return bem_nullFileSet_1(bevd_0);
case 1628306760: return bem_notEquals_1(bevd_0);
case -564148923: return bem_sameObject_1(bevd_0);
case 1025270681: return bem_sameClass_1(bevd_0);
case -1233382567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1421486817: return bem_isWinSet_1(bevd_0);
case -1108496649: return bem_otherClass_1(bevd_0);
case 146723804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -905872983: return bem_equals_1(bevd_0);
case 525545408: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1420340682: return bem_separatorSet_1(bevd_0);
case -132983687: return bem_undefined_1(bevd_0);
case 390124709: return bem_nameSet_1(bevd_0);
case 1681419755: return bem_defined_1(bevd_0);
case -690395055: return bem_isNixSetDirect_1(bevd_0);
case -1054285965: return bem_separatorSetDirect_1(bevd_0);
case -1374125024: return bem_undef_1(bevd_0);
case -1433803932: return bem_def_1(bevd_0);
case -1509120216: return bem_otherSeparatorSet_1(bevd_0);
case 1768150024: return bem_newlineSetDirect_1(bevd_0);
case -267062499: return bem_sameType_1(bevd_0);
case -1171661229: return bem_otherType_1(bevd_0);
case 1483265124: return bem_nameSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1931375919: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 68692131: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383175850: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -110664853: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1765848815: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1365987158: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -381061425: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
}
