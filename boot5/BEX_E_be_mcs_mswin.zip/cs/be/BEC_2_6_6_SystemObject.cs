namespace be {

using System;
    /* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject : be.BECS_Object {
public BEC_2_6_6_SystemObject() { }
static BEC_2_6_6_SystemObject() { }

   public virtual BEC_2_6_6_SystemObject bems_methodNotDefined(string name, BEC_2_6_6_SystemObject[] args) { 
     name = name.Substring(0, name.LastIndexOf("_"));
     return bem_methodNotDefined_2(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(name)), new BEC_2_9_4_ContainerList(args));
   }
   public virtual BEC_2_6_6_SystemObject bems_forwardCallCp(BEC_2_4_6_TextString name, BEC_2_9_4_ContainerList args) { 
     args = (BEC_2_9_4_ContainerList) args.bem_copy_0();
     return bem_forwardCall_2(name, args);
   }
   private static byte[] becc_BEC_2_6_6_SystemObject_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_BEC_2_6_6_SystemObject_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_0, 8));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_1, 23));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_2 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_2, 8));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_3 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_3, 23));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_4 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_5 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_5, 16));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_6 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_7 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_8 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_8, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_6 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_7 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_8 = (new BEC_2_4_3_MathInt(7));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_9 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_10 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_11 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_11, 1));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_12 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_11 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_inst;

public static BET_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_type;

public virtual BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toAny_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNotDefined_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(beva_name);
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 73 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 78 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_2;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(beva_name);
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_3;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 79 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_phold = bem_createInstance_2(beva_cname, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_11_SystemInitializer bevt_8_tmpany_phold = null;
if (beva_cname == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 89 */
bevl_result = null;

        string key = System.Text.Encoding.UTF8.GetString(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int);
        BETS_Object ti = be.BECS_Runtime.typeRefs[key];
        if (ti != null) {
            bevl_result = ti.bems_createInstance();
        }
        if (bevl_result == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 120 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 121 */ {
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_4;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(beva_cname);
bevt_4_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 122 */
 else  /* Line: 123 */ {
return null;
} /* Line: 124 */
} /* Line: 121 */
bevt_8_tmpany_phold = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_initializeIfShould_1(bevl_result);
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_fieldNamesGet_0() {
BEC_2_9_4_ContainerList bevl_names = null;
bevl_names = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();

     BETS_Object bevs_cano = bemc_getType();
     string[] fnames = bevs_cano.bevs_fieldNames;
     
     for (int i = 0;i < fnames.Length;i++) {
     
       bevl_names.bem_addValue_1(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(fnames[i])));

     }
     return bevl_names;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_6));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 183 */
if (beva_args == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 185 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_6_6_SystemObject_bels_7));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 186 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_5;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
 /* Line: 194 */ {
bevt_10_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_6;
if (bevl_numargs.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_12_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_7;
bevt_11_tmpany_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpany_phold);
bevl_args2 = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
while (true)
 /* Line: 197 */ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_8;
bevt_14_tmpany_phold = bevl_i.bem_subtract_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpany_phold, bevt_16_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 197 */
 else  /* Line: 197 */ {
break;
} /* Line: 197 */
} /* Line: 197 */
} /* Line: 197 */
} /* Line: 195 */

        int ci = be.BECS_Ids.callIds[System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int)];
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 248 */ {
bevl_rval.bemd_0(-1795002401);
} /* Line: 250 */
return bevl_rval;
} /*method end*/
public BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_9));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 261 */
if (beva_numargs == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_6_6_SystemObject_bels_10));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 264 */
bevt_7_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_9;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);

      
      string name = System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int);
      
      BETS_Object bevs_cano = bemc_getType();
      
      if (bevs_cano.bevs_methodNames.ContainsKey(name)) {
        return be.BECS_Runtime.boolTrue;
      }
      
      bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevl_rval.bemd_0(-1795002401);
} /* Line: 302 */
if (bevl_rval == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /* Line: 305 */
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clname();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      bevl_xi = bemc_clnames();
      return bevl_xi;
} /*method end*/
public BEC_2_4_6_TextString bem_sourceFileNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clfile();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      bevl_xi = bemc_clfiles();
      return bevl_xi;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_tagGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_print_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_echo_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold.bem_echo_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_6_6_SystemObject) bem_create_0();
bevt_0_tmpany_phold = (BEC_2_6_6_SystemObject) bem_copyTo_1(bevt_1_tmpany_phold);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
if (beva_copy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 529 */ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 530 */
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_tmpany_phold);
while (true)
 /* Line: 534 */ {
bevt_3_tmpany_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 534 */ {
bevt_4_tmpany_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpany_phold);
} /* Line: 535 */
 else  /* Line: 534 */ {
break;
} /* Line: 534 */
} /* Line: 534 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_serializeToString_0() {
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_fieldIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && this.GetType() == beva_other.GetType()) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && beva_other.GetType().IsAssignableFrom(this.GetType())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sameType_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_getMethod_1(BEC_2_4_6_TextString beva_nameac) {
BEC_2_4_3_MathInt bevl_cd = null;
BEC_2_4_6_TextString bevl_name = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemMethod bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_12));
bevl_cd = beva_nameac.bem_rfind_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_10;
bevl_name = beva_nameac.bem_substring_2(bevt_1_tmpany_phold, bevl_cd);
bevt_4_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_11;
bevt_3_tmpany_phold = bevl_cd.bem_add_1(bevt_4_tmpany_phold);
bevt_2_tmpany_phold = beva_nameac.bem_substring_1(bevt_3_tmpany_phold);
bevl_ac = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_2_tmpany_phold);
bevt_5_tmpany_phold = bem_getMethod_2(bevl_name, bevl_ac);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_getMethod_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_ac) {
BEC_2_6_6_SystemMethod bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_6_SystemMethod) (new BEC_2_6_6_SystemMethod()).bem_new_3(this, beva_name, beva_ac);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_getInvocation_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_6_10_SystemInvocation bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_10_SystemInvocation) (new BEC_2_6_10_SystemInvocation()).bem_new_3(this, beva_name, beva_args);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_once_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_many_0() {
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {31, 31, 42, 42, 53, 53, 64, 64, 68, 72, 73, 73, 73, 73, 73, 73, 73, 73, 78, 79, 79, 79, 79, 79, 79, 79, 79, 84, 84, 84, 88, 88, 89, 89, 89, 91, 120, 120, 122, 122, 122, 122, 124, 127, 127, 127, 132, 173, 182, 182, 183, 183, 183, 185, 185, 186, 186, 186, 188, 189, 189, 189, 189, 195, 195, 195, 196, 196, 196, 197, 197, 197, 198, 198, 198, 198, 197, 248, 250, 252, 260, 260, 261, 261, 261, 263, 263, 264, 264, 264, 266, 266, 266, 266, 301, 302, 304, 304, 305, 305, 307, 307, 343, 367, 399, 399, 431, 431, 442, 468, 479, 505, 509, 509, 509, 513, 513, 517, 517, 521, 521, 525, 525, 525, 529, 529, 530, 532, 532, 533, 533, 534, 535, 535, 541, 541, 547, 553, 553, 557, 557, 561, 561, 565, 565, 588, 635, 635, 639, 639, 639, 671, 671, 675, 675, 675, 679, 679, 680, 680, 681, 681, 681, 681, 682, 682, 686, 686, 690, 690};
public static int[] bevs_smnlec
 = new int[] {53, 54, 58, 59, 63, 64, 68, 69, 72, 83, 85, 86, 87, 88, 89, 90, 91, 92, 105, 107, 108, 109, 110, 111, 112, 113, 114, 121, 122, 123, 136, 141, 142, 143, 144, 146, 153, 158, 160, 161, 162, 163, 166, 169, 170, 171, 175, 185, 211, 216, 217, 218, 219, 221, 226, 227, 228, 229, 231, 232, 233, 234, 235, 237, 238, 243, 244, 245, 246, 247, 250, 255, 256, 257, 258, 259, 260, 290, 292, 294, 313, 318, 319, 320, 321, 323, 328, 329, 330, 331, 333, 334, 335, 336, 347, 349, 351, 356, 357, 358, 360, 361, 369, 377, 385, 386, 394, 395, 399, 402, 406, 409, 414, 415, 420, 424, 425, 429, 430, 435, 436, 442, 443, 444, 454, 459, 460, 462, 463, 464, 465, 468, 470, 471, 481, 482, 488, 495, 496, 500, 501, 505, 506, 510, 511, 517, 525, 526, 531, 532, 537, 545, 546, 551, 552, 557, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 582, 583, 587, 588};
/* BEGIN LINEINFO 
assign 1 31 53
new 0 31 53
return 1 31 54
assign 1 42 58
new 0 42 58
return 1 42 59
assign 1 53 63
new 0 53 63
return 1 53 64
assign 1 64 68
new 0 64 68
return 1 64 69
return 1 68 72
assign 1 72 83
new 0 72 83
assign 1 73 85
new 0 73 85
assign 1 73 86
add 1 73 86
assign 1 73 87
new 0 73 87
assign 1 73 88
add 1 73 88
assign 1 73 89
classNameGet 0 73 89
assign 1 73 90
add 1 73 90
assign 1 73 91
new 1 73 91
throw 1 73 92
assign 1 78 105
new 0 78 105
assign 1 79 107
new 0 79 107
assign 1 79 108
add 1 79 108
assign 1 79 109
new 0 79 109
assign 1 79 110
add 1 79 110
assign 1 79 111
classNameGet 0 79 111
assign 1 79 112
add 1 79 112
assign 1 79 113
new 1 79 113
throw 1 79 114
assign 1 84 121
new 0 84 121
assign 1 84 122
createInstance 2 84 122
return 1 84 123
assign 1 88 136
undef 1 88 141
assign 1 89 142
new 0 89 142
assign 1 89 143
new 1 89 143
throw 1 89 144
assign 1 91 146
assign 1 120 153
undef 1 120 158
assign 1 122 160
new 0 122 160
assign 1 122 161
add 1 122 161
assign 1 122 162
new 1 122 162
throw 1 122 163
return 1 124 166
assign 1 127 169
new 0 127 169
assign 1 127 170
initializeIfShould 1 127 170
return 1 127 171
assign 1 132 175
new 0 132 175
return 1 173 185
assign 1 182 211
undef 1 182 216
assign 1 183 217
new 0 183 217
assign 1 183 218
new 1 183 218
throw 1 183 219
assign 1 185 221
undef 1 185 226
assign 1 186 227
new 0 186 227
assign 1 186 228
new 1 186 228
throw 1 186 229
assign 1 188 231
lengthGet 0 188 231
assign 1 189 232
new 0 189 232
assign 1 189 233
add 1 189 233
assign 1 189 234
toString 0 189 234
assign 1 189 235
add 1 189 235
assign 1 195 237
new 0 195 237
assign 1 195 238
greater 1 195 243
assign 1 196 244
new 0 196 244
assign 1 196 245
subtract 1 196 245
assign 1 196 246
new 1 196 246
assign 1 197 247
new 0 197 247
assign 1 197 250
lesser 1 197 255
assign 1 198 256
new 0 198 256
assign 1 198 257
subtract 1 198 257
assign 1 198 258
get 1 198 258
put 2 198 259
incrementValue 0 197 260
assign 1 248 290
new 0 248 290
toString 0 250 292
return 1 252 294
assign 1 260 313
undef 1 260 318
assign 1 261 319
new 0 261 319
assign 1 261 320
new 1 261 320
throw 1 261 321
assign 1 263 323
undef 1 263 328
assign 1 264 329
new 0 264 329
assign 1 264 330
new 1 264 330
throw 1 264 331
assign 1 266 333
new 0 266 333
assign 1 266 334
add 1 266 334
assign 1 266 335
toString 0 266 335
assign 1 266 336
add 1 266 336
assign 1 301 347
new 0 301 347
toString 0 302 349
assign 1 304 351
def 1 304 356
assign 1 305 357
new 0 305 357
return 1 305 358
assign 1 307 360
new 0 307 360
return 1 307 361
return 1 343 369
return 1 367 377
assign 1 399 385
new 0 399 385
return 1 399 386
assign 1 431 394
new 0 431 394
return 1 431 395
assign 1 442 399
new 0 442 399
return 1 468 402
assign 1 479 406
new 0 479 406
return 1 505 409
assign 1 509 414
equals 1 509 414
assign 1 509 415
not 0 509 420
return 1 509 420
assign 1 513 424
classNameGet 0 513 424
return 1 513 425
assign 1 517 429
toString 0 517 429
print 0 517 430
assign 1 521 435
toString 0 521 435
echo 0 521 436
assign 1 525 442
create 0 525 442
assign 1 525 443
copyTo 1 525 443
return 1 525 444
assign 1 529 454
undef 1 529 459
return 1 530 460
assign 1 532 462
new 0 532 462
assign 1 532 463
new 2 532 463
assign 1 533 464
new 0 533 464
assign 1 533 465
new 2 533 465
assign 1 534 468
hasNextGet 0 534 468
assign 1 535 470
nextGet 0 535 470
nextSet 1 535 471
assign 1 541 481
classNameGet 0 541 481
return 1 541 482
return 1 547 488
assign 1 553 495
new 1 553 495
return 1 553 496
assign 1 557 500
new 1 557 500
return 1 557 501
assign 1 561 505
new 1 561 505
return 1 561 506
assign 1 565 510
new 0 565 510
return 1 565 511
return 1 588 517
assign 1 635 525
new 0 635 525
return 1 635 526
assign 1 639 531
sameClass 1 639 531
assign 1 639 532
not 0 639 537
return 1 639 537
assign 1 671 545
new 0 671 545
return 1 671 546
assign 1 675 551
sameType 1 675 551
assign 1 675 552
not 0 675 557
return 1 675 557
assign 1 679 569
new 0 679 569
assign 1 679 570
rfind 1 679 570
assign 1 680 571
new 0 680 571
assign 1 680 572
substring 2 680 572
assign 1 681 573
new 0 681 573
assign 1 681 574
add 1 681 574
assign 1 681 575
substring 1 681 575
assign 1 681 576
new 1 681 576
assign 1 682 577
getMethod 2 682 577
return 1 682 578
assign 1 686 582
new 3 686 582
return 1 686 583
assign 1 690 587
new 3 690 587
return 1 690 588
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 367195678: return bem_once_0();
case 55812595: return bem_serializeToString_0();
case -604312045: return bem_serializationIteratorGet_0();
case 808044123: return bem_hashGet_0();
case 748315678: return bem_tagGet_0();
case 402201008: return bem_new_0();
case 9957435: return bem_iteratorGet_0();
case -1795002401: return bem_toString_0();
case 966149554: return bem_create_0();
case 1342765490: return bem_toAny_0();
case -1854726950: return bem_echo_0();
case -656937356: return bem_many_0();
case 1678261270: return bem_print_0();
case -1975455714: return bem_copy_0();
case -368347729: return bem_fieldNamesGet_0();
case -434919379: return bem_deserializeClassNameGet_0();
case 682604587: return bem_serializeContents_0();
case -772967023: return bem_classNameGet_0();
case 1860492410: return bem_fieldIteratorGet_0();
case -636994806: return bem_sourceFileNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1614496109: return bem_undef_1(bevd_0);
case 1647993291: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -700310720: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1194473609: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 267174377: return bem_def_1(bevd_0);
case 1448933357: return bem_otherType_1(bevd_0);
case -714900612: return bem_copyTo_1(bevd_0);
case -2144202949: return bem_sameClass_1(bevd_0);
case 350775730: return bem_equals_1(bevd_0);
case 1272631429: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 195308005: return bem_sameObject_1(bevd_0);
case -1007540340: return bem_notEquals_1(bevd_0);
case -991365338: return bem_defined_1(bevd_0);
case 1163078007: return bem_undefined_1(bevd_0);
case 1621186357: return bem_sameType_1(bevd_0);
case 543061021: return bem_otherClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 325307565: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1385197575: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1280867989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1833007700: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1584099228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -187061774: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -961973758: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemObject_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemObject_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemObject();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst = becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_type;
}
}
}
