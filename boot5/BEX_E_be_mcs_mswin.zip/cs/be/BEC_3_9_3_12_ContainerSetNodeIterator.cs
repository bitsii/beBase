namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_12_ContainerSetNodeIterator : BEC_2_6_6_SystemObject {
public BEC_3_9_3_12_ContainerSetNodeIterator() { }
static BEC_3_9_3_12_ContainerSetNodeIterator() { }
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4E,0x6F,0x64,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_2 = (new BEC_2_4_3_MathInt(0));
public static new BEC_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;

public static new BET_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;

public BEC_2_9_3_ContainerSet bevp_set;
public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_current;
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) {
bevp_set = beva__set;
bevp_slots = bevp_set.bem_slotsGet_0();
bevp_modu = bevp_slots.bem_sizeGet_0();
bevp_current = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_containerGet_0() {
return bevp_set;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_i = bevp_current;
while (true)
 /* Line: 658 */ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 658 */ {
bevt_2_tmpany_phold = bevp_slots.bem_get_1(bevl_i);
if (bevt_2_tmpany_phold == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 659 */ {
bevp_current = bevl_i;
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 661 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 658 */
 else  /* Line: 658 */ {
break;
} /* Line: 658 */
} /* Line: 658 */
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_i = bevp_current;
while (true)
 /* Line: 668 */ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 668 */ {
bevl_toRet = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_toRet == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 670 */ {
bevt_2_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_0;
bevp_current = bevl_i.bem_add_1(bevt_2_tmpany_phold);
return bevl_toRet;
} /* Line: 672 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 668 */
 else  /* Line: 668 */ {
break;
} /* Line: 668 */
} /* Line: 668 */
return null;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_delete_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_1;
bevl_i = bevp_current.bem_subtract_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_2;
if (bevl_i.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 680 */ {
bevl_sn = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_sn == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 682 */ {
bevt_5_tmpany_phold = bevl_sn.bem_keyGet_0();
bevt_4_tmpany_phold = bevp_set.bem_delete_1(bevt_5_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 683 */ {
bevp_current = bevl_i;
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 685 */
} /* Line: 683 */
} /* Line: 682 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorIteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_setGet_0() {
return bevp_set;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_setGetDirect_0() {
return bevp_set;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_setSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_set = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_setSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_set = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_slotsGet_0() {
return bevp_slots;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGetDirect_0() {
return bevp_slots;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_slotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_moduGet_0() {
return bevp_modu;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGetDirect_0() {
return bevp_modu;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_moduSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_2_4_3_MathInt bem_currentGetDirect_0() {
return bevp_current;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {645, 646, 647, 648, 654, 658, 658, 658, 659, 659, 659, 660, 661, 661, 658, 664, 664, 668, 668, 668, 669, 670, 670, 671, 671, 672, 668, 675, 679, 679, 680, 680, 680, 681, 682, 682, 683, 683, 684, 685, 685, 689, 689, 694, 698, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 22, 23, 27, 36, 39, 44, 45, 46, 51, 52, 53, 54, 56, 62, 63, 71, 74, 79, 80, 81, 86, 87, 88, 89, 91, 97, 110, 111, 112, 113, 118, 119, 120, 125, 126, 127, 129, 130, 131, 135, 136, 139, 142, 145, 148, 151, 155, 159, 162, 165, 169, 173, 176, 179, 183, 187, 190, 193, 197};
/* BEGIN LINEINFO 
assign 1 645 20
assign 1 646 21
slotsGet 0 646 21
assign 1 647 22
sizeGet 0 647 22
assign 1 648 23
new 0 648 23
return 1 654 27
assign 1 658 36
assign 1 658 39
lesser 1 658 44
assign 1 659 45
get 1 659 45
assign 1 659 46
def 1 659 51
assign 1 660 52
assign 1 661 53
new 0 661 53
return 1 661 54
assign 1 658 56
increment 0 658 56
assign 1 664 62
new 0 664 62
return 1 664 63
assign 1 668 71
assign 1 668 74
lesser 1 668 79
assign 1 669 80
get 1 669 80
assign 1 670 81
def 1 670 86
assign 1 671 87
new 0 671 87
assign 1 671 88
add 1 671 88
return 1 672 89
assign 1 668 91
increment 0 668 91
return 1 675 97
assign 1 679 110
new 0 679 110
assign 1 679 111
subtract 1 679 111
assign 1 680 112
new 0 680 112
assign 1 680 113
greaterEquals 1 680 118
assign 1 681 119
get 1 681 119
assign 1 682 120
def 1 682 125
assign 1 683 126
keyGet 0 683 126
assign 1 683 127
delete 1 683 127
assign 1 684 129
assign 1 685 130
new 0 685 130
return 1 685 131
assign 1 689 135
new 0 689 135
return 1 689 136
return 1 694 139
return 1 698 142
return 1 0 145
return 1 0 148
assign 1 0 151
assign 1 0 155
return 1 0 159
return 1 0 162
assign 1 0 165
assign 1 0 169
return 1 0 173
return 1 0 176
assign 1 0 179
assign 1 0 183
return 1 0 187
return 1 0 190
assign 1 0 193
assign 1 0 197
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -53282896: return bem_currentGetDirect_0();
case 1619233262: return bem_setGet_0();
case 2121039924: return bem_new_0();
case -1856486979: return bem_deserializeClassNameGet_0();
case -811418832: return bem_many_0();
case 1146572082: return bem_containerGet_0();
case -423469580: return bem_nodeIteratorIteratorGet_0();
case -992120130: return bem_fieldIteratorGet_0();
case 893274194: return bem_tagGet_0();
case 1057323332: return bem_toAny_0();
case -195266806: return bem_toString_0();
case -142543557: return bem_hasNextGet_0();
case 538632487: return bem_serializationIteratorGet_0();
case -189856578: return bem_copy_0();
case 1584275584: return bem_currentGet_0();
case -166515831: return bem_fieldNamesGet_0();
case -265928475: return bem_classNameGet_0();
case -515235618: return bem_nextGet_0();
case -1232978478: return bem_hashGet_0();
case 1909168143: return bem_delete_0();
case 1236464998: return bem_serializeContents_0();
case -165699331: return bem_setGetDirect_0();
case 803060031: return bem_create_0();
case -361981443: return bem_slotsGetDirect_0();
case 470714498: return bem_moduGetDirect_0();
case -1105589145: return bem_moduGet_0();
case 2111391138: return bem_serializeToString_0();
case -299023655: return bem_echo_0();
case 1870744321: return bem_once_0();
case 869814362: return bem_slotsGet_0();
case -1735879417: return bem_print_0();
case -1438038411: return bem_sourceFileNameGet_0();
case 24125772: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 603416823: return bem_slotsSetDirect_1(bevd_0);
case -905872983: return bem_equals_1(bevd_0);
case 146723804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1171661229: return bem_otherType_1(bevd_0);
case 1628306760: return bem_notEquals_1(bevd_0);
case -267062499: return bem_sameType_1(bevd_0);
case 629930961: return bem_currentSetDirect_1(bevd_0);
case -132983687: return bem_undefined_1(bevd_0);
case 1534105153: return bem_setSet_1(bevd_0);
case 1669121148: return bem_copyTo_1(bevd_0);
case 1681419755: return bem_defined_1(bevd_0);
case -1233382567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1780562999: return bem_slotsSet_1(bevd_0);
case -490313093: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2044915525: return bem_currentSet_1(bevd_0);
case -272106945: return bem_moduSetDirect_1(bevd_0);
case -564148923: return bem_sameObject_1(bevd_0);
case -1108496649: return bem_otherClass_1(bevd_0);
case 712489064: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1739335990: return bem_moduSet_1(bevd_0);
case 525545408: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1077865529: return bem_setSetDirect_1(bevd_0);
case -1374125024: return bem_undef_1(bevd_0);
case 1025270681: return bem_sameClass_1(bevd_0);
case -1433803932: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1931375919: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 68692131: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383175850: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -110664853: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1765848815: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1365987158: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -381061425: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(26, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_12_ContainerSetNodeIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst = (BEC_3_9_3_12_ContainerSetNodeIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;
}
}
}
