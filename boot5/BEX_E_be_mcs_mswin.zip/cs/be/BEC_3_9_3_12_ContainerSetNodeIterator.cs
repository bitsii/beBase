namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_12_ContainerSetNodeIterator : BEC_2_6_6_SystemObject {
public BEC_3_9_3_12_ContainerSetNodeIterator() { }
static BEC_3_9_3_12_ContainerSetNodeIterator() { }
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4E,0x6F,0x64,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_2 = (new BEC_2_4_3_MathInt(0));
public static new BEC_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;
public BEC_2_9_3_ContainerSet bevp_set;
public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_current;
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) {
bevp_set = beva__set;
bevp_slots = bevp_set.bem_slotsGet_0();
bevp_modu = bevp_slots.bem_sizeGet_0();
bevp_current = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_containerGet_0() {
return bevp_set;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_i = bevp_current;
while (true)
 /* Line: 657 */ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 657 */ {
bevt_2_tmpany_phold = bevp_slots.bem_get_1(bevl_i);
if (bevt_2_tmpany_phold == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 658 */ {
bevp_current = bevl_i;
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 660 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 657 */
 else  /* Line: 657 */ {
break;
} /* Line: 657 */
} /* Line: 657 */
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_i = bevp_current;
while (true)
 /* Line: 667 */ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 667 */ {
bevl_toRet = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_toRet == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 669 */ {
bevt_2_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_0;
bevp_current = bevl_i.bem_add_1(bevt_2_tmpany_phold);
return bevl_toRet;
} /* Line: 671 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 667 */
 else  /* Line: 667 */ {
break;
} /* Line: 667 */
} /* Line: 667 */
return null;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_delete_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_1;
bevl_i = bevp_current.bem_subtract_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_2;
if (bevl_i.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 679 */ {
bevl_sn = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_sn == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 681 */ {
bevt_5_tmpany_phold = bevl_sn.bem_keyGet_0();
bevt_4_tmpany_phold = bevp_set.bem_delete_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 682 */ {
bevp_current = bevl_i;
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 684 */
} /* Line: 682 */
} /* Line: 681 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorIteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_setGet_0() {
return bevp_set;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_setSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_set = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_slotsGet_0() {
return bevp_slots;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_moduGet_0() {
return bevp_modu;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_currentGet_0() {
return bevp_current;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {644, 645, 646, 647, 653, 657, 657, 657, 658, 658, 658, 659, 660, 660, 657, 663, 663, 667, 667, 667, 668, 669, 669, 670, 670, 671, 667, 674, 678, 678, 679, 679, 679, 680, 681, 681, 682, 682, 683, 684, 684, 688, 688, 693, 697, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 18, 19, 20, 24, 33, 36, 41, 42, 43, 48, 49, 50, 51, 53, 59, 60, 68, 71, 76, 77, 78, 83, 84, 85, 86, 88, 94, 107, 108, 109, 110, 115, 116, 117, 122, 123, 124, 126, 127, 128, 132, 133, 136, 139, 142, 145, 149, 152, 156, 159, 163, 166};
/* BEGIN LINEINFO 
assign 1 644 17
assign 1 645 18
slotsGet 0 645 18
assign 1 646 19
sizeGet 0 646 19
assign 1 647 20
new 0 647 20
return 1 653 24
assign 1 657 33
assign 1 657 36
lesser 1 657 41
assign 1 658 42
get 1 658 42
assign 1 658 43
def 1 658 48
assign 1 659 49
assign 1 660 50
new 0 660 50
return 1 660 51
assign 1 657 53
increment 0 657 53
assign 1 663 59
new 0 663 59
return 1 663 60
assign 1 667 68
assign 1 667 71
lesser 1 667 76
assign 1 668 77
get 1 668 77
assign 1 669 78
def 1 669 83
assign 1 670 84
new 0 670 84
assign 1 670 85
add 1 670 85
return 1 671 86
assign 1 667 88
increment 0 667 88
return 1 674 94
assign 1 678 107
new 0 678 107
assign 1 678 108
subtract 1 678 108
assign 1 679 109
new 0 679 109
assign 1 679 110
greaterEquals 1 679 115
assign 1 680 116
get 1 680 116
assign 1 681 117
def 1 681 122
assign 1 682 123
keyGet 0 682 123
assign 1 682 124
delete 1 682 124
assign 1 683 126
assign 1 684 127
new 0 684 127
return 1 684 128
assign 1 688 132
new 0 688 132
return 1 688 133
return 1 693 136
return 1 697 139
return 1 0 142
assign 1 0 145
return 1 0 149
assign 1 0 152
return 1 0 156
assign 1 0 159
return 1 0 163
assign 1 0 166
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1193265838: return bem_new_0();
case -1976290782: return bem_print_0();
case 880152096: return bem_classNameGet_0();
case 1211836779: return bem_iteratorGet_0();
case 1055766673: return bem_setGet_0();
case -1896601781: return bem_toAny_0();
case -2091198124: return bem_tagGet_0();
case 444169984: return bem_sourceFileNameGet_0();
case -1720229911: return bem_moduGet_0();
case -626230809: return bem_currentGet_0();
case -2052611744: return bem_once_0();
case -1888508563: return bem_serializationIteratorGet_0();
case -395826380: return bem_slotsGet_0();
case 752911959: return bem_hashGet_0();
case -939463792: return bem_nextGet_0();
case -1214978246: return bem_containerGet_0();
case 1310164435: return bem_serializeContents_0();
case -326646035: return bem_toString_0();
case -364515046: return bem_fieldIteratorGet_0();
case 2085674875: return bem_echo_0();
case 2098501683: return bem_create_0();
case 452370668: return bem_hasNextGet_0();
case 1278477757: return bem_serializeToString_0();
case 927318721: return bem_delete_0();
case 1446071295: return bem_nodeIteratorIteratorGet_0();
case 2141550628: return bem_deserializeClassNameGet_0();
case -1152001976: return bem_copy_0();
case 142206752: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1319824016: return bem_currentSet_1(bevd_0);
case 1948085050: return bem_undef_1(bevd_0);
case 1990827367: return bem_notEquals_1(bevd_0);
case -1191000829: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1653200761: return bem_setSet_1(bevd_0);
case 1192985456: return bem_moduSet_1(bevd_0);
case -1773439641: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 906221967: return bem_slotsSet_1(bevd_0);
case -785327205: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 136677527: return bem_def_1(bevd_0);
case 1048239710: return bem_sameClass_1(bevd_0);
case 607370643: return bem_undefined_1(bevd_0);
case -1321282362: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1866601742: return bem_otherType_1(bevd_0);
case 986477958: return bem_defined_1(bevd_0);
case 930180418: return bem_copyTo_1(bevd_0);
case 45057151: return bem_equals_1(bevd_0);
case 496808651: return bem_sameObject_1(bevd_0);
case 1579053823: return bem_sameType_1(bevd_0);
case 1268433926: return bem_otherClass_1(bevd_0);
case 275457317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 686788947: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1768228505: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1400688487: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 253281852: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1848289028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 893523384: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1481064275: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(26, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_12_ContainerSetNodeIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst = (BEC_3_9_3_12_ContainerSetNodeIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;
}
}
}
