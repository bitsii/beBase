namespace be {
/* IO:File: source/build/Pass8.be */
public sealed class BEC_3_5_5_5_BuildVisitPass8 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass8() { }
static BEC_3_5_5_5_BuildVisitPass8() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x38};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x38,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_0 = {0x6E,0x6F,0x74,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_3 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_5 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_6 = {0x61,0x64,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_7 = {0x61,0x64,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_8 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_9 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_10 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_11 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_12 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_13 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_15 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_17 = {0x64,0x69,0x76,0x69,0x64,0x65,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_19 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_20 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x61,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_21 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_22 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_23 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_24 = {0x67,0x65,0x74,0x5F,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_25 = {0x67,0x65,0x74,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_26 = {0x61,0x6E,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_27 = {0x61,0x6E,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_28 = {0x6F,0x72,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_29 = {0x6F,0x72,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_30 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
public static new BEC_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;

public BEC_3_5_5_5_BuildVisitPass8 bem_acceptClass_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_8_BuildEmitData bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_0_ta_ph.bem_addParsedClass_1(beva_node);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepOps_0() {
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_3_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevl_ops = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 19*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_1_ta_ph = bevl_i.bemd_1(303691603, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 19*/ {
bevt_3_ta_ph = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_ops.bemd_2(1920178007, bevl_i, bevt_3_ta_ph);
bevl_i = bevl_i.bemd_0(-589465676);
} /* Line: 19*/
 else /* Line: 19*/ {
break;
} /* Line: 19*/
} /* Line: 19*/
return bevl_ops;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_prec = null;
BEC_2_6_6_SystemObject bevl_cont = null;
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_onode = null;
BEC_2_6_6_SystemObject bevl_mo = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_mt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
bevt_3_ta_ph = beva_node.bem_typenameGet_0();
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_3_ta_ph.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 29*/ {
bem_acceptClass_1(beva_node);
bevt_5_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_5_ta_ph;
} /* Line: 31*/
bevt_6_ta_ph = bevp_const.bem_operGet_0();
bevt_7_ta_ph = beva_node.bem_typenameGet_0();
bevl_prec = bevt_6_ta_ph.bem_get_1(bevt_7_ta_ph);
if (bevl_prec == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 34*/ {
bevl_cont = beva_node.bem_containerGet_0();
bevl_ops = bem_prepOps_0();
bevl_onode = beva_node;
beva_node = null;
while (true)
/* Line: 44*/ {
if (bevl_onode == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 44*/ {
if (bevl_prec == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_12_ta_ph = bevl_onode.bemd_0(-1660593916);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(1408797910, bevl_cont);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_13_ta_ph = bevl_ops.bemd_1(-1267929220, bevl_prec);
bevt_13_ta_ph.bemd_1(1628522769, bevl_onode);
bevl_inode = bevl_onode.bemd_0(345274613);
if (bevl_inode == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 47*/ {
bevl_inode = bevl_inode.bemd_0(345274613);
if (bevl_inode == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_17_ta_ph = bevl_inode.bemd_0(822998896);
bevt_18_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bemd_1(1408797910, bevt_18_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_inode = bevl_inode.bemd_0(345274613);
if (bevl_inode == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 52*/ {
bevl_inode = bevl_inode.bemd_0(345274613);
} /* Line: 53*/
} /* Line: 52*/
} /* Line: 50*/
} /* Line: 49*/
bevl_onode = bevl_inode;
if (bevl_onode == null) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 59*/ {
bevt_21_ta_ph = bevp_const.bem_operGet_0();
bevt_22_ta_ph = bevl_onode.bemd_0(822998896);
bevl_prec = bevt_21_ta_ph.bem_get_1(bevt_22_ta_ph);
} /* Line: 60*/
 else /* Line: 61*/ {
bevl_prec = null;
} /* Line: 62*/
} /* Line: 59*/
 else /* Line: 44*/ {
break;
} /* Line: 44*/
} /* Line: 44*/
bevl_prec = (new BEC_2_4_3_MathInt(0));
bevl_it = bevl_ops.bemd_0(-71162589);
while (true)
/* Line: 66*/ {
bevt_23_ta_ph = bevl_it.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 66*/ {
bevl_i = bevl_it.bemd_0(-641452021);
bevt_25_ta_ph = bevl_i.bemd_0(372427837);
bevt_26_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(1144419489, bevt_26_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 68*/ {
bevl_mt = bevl_i.bemd_0(-71162589);
while (true)
/* Line: 69*/ {
bevt_27_ta_ph = bevl_mt.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_27_ta_ph).bevi_bool)/* Line: 69*/ {
bevl_mo = bevl_mt.bemd_0(-641452021);
bevt_28_ta_ph = bevl_mo.bemd_0(1492461624);
bevt_29_ta_ph = bevl_mo.bemd_0(345274613);
bevl_mo = bem_callFromOper_4(bevl_mo, bevl_prec, bevt_28_ta_ph, bevt_29_ta_ph);
beva_node = (BEC_2_5_4_BuildNode) bevl_mo;
} /* Line: 72*/
 else /* Line: 69*/ {
break;
} /* Line: 69*/
} /* Line: 69*/
} /* Line: 69*/
bevl_prec = bevl_prec.bemd_0(-589465676);
} /* Line: 75*/
 else /* Line: 66*/ {
break;
} /* Line: 66*/
} /* Line: 66*/
} /* Line: 66*/
bevt_30_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_30_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callFromOper_4(BEC_2_6_6_SystemObject beva_op, BEC_2_6_6_SystemObject beva_prec, BEC_2_6_6_SystemObject beva_pr, BEC_2_6_6_SystemObject beva_nx) {
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_5_4_LogicBool bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_4_3_MathInt bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-1423537167, bevt_0_ta_ph);
bevt_3_ta_ph = bevp_const.bem_operNamesGet_0();
bevt_4_ta_ph = beva_op.bemd_0(822998896);
bevt_2_ta_ph = bevt_3_ta_ph.bem_get_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(1758824842);
bevl_gc.bemd_1(1432148458, bevt_1_ta_ph);
bevt_6_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_0));
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(1408797910, bevt_7_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 87*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_1));
bevl_gc.bemd_1(1432148458, bevt_8_ta_ph);
} /* Line: 88*/
bevt_10_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_2));
bevt_9_ta_ph = bevt_10_ta_ph.bemd_1(1408797910, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 90*/ {
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_3));
bevl_gc.bemd_1(1432148458, bevt_12_ta_ph);
} /* Line: 91*/
bevt_14_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_4));
bevt_13_ta_ph = bevt_14_ta_ph.bemd_1(1408797910, bevt_15_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 93*/ {
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_5));
bevl_gc.bemd_1(1432148458, bevt_16_ta_ph);
} /* Line: 94*/
bevt_18_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_6));
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(1408797910, bevt_19_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 96*/ {
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_7));
bevl_gc.bemd_1(1432148458, bevt_20_ta_ph);
} /* Line: 97*/
bevt_22_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_8));
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(1408797910, bevt_23_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 99*/ {
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_9));
bevl_gc.bemd_1(1432148458, bevt_24_ta_ph);
} /* Line: 100*/
bevt_26_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_10));
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(1408797910, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_25_ta_ph).bevi_bool)/* Line: 102*/ {
bevt_28_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_11));
bevl_gc.bemd_1(1432148458, bevt_28_ta_ph);
} /* Line: 103*/
bevt_30_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_12));
bevt_29_ta_ph = bevt_30_ta_ph.bemd_1(1408797910, bevt_31_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_29_ta_ph).bevi_bool)/* Line: 105*/ {
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_13));
bevl_gc.bemd_1(1432148458, bevt_32_ta_ph);
} /* Line: 106*/
bevt_34_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_14));
bevt_33_ta_ph = bevt_34_ta_ph.bemd_1(1408797910, bevt_35_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 108*/ {
bevt_36_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_15));
bevl_gc.bemd_1(1432148458, bevt_36_ta_ph);
} /* Line: 109*/
bevt_38_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_16));
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(1408797910, bevt_39_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_37_ta_ph).bevi_bool)/* Line: 111*/ {
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_17));
bevl_gc.bemd_1(1432148458, bevt_40_ta_ph);
} /* Line: 112*/
bevt_42_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_18));
bevt_41_ta_ph = bevt_42_ta_ph.bemd_1(1408797910, bevt_43_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_41_ta_ph).bevi_bool)/* Line: 114*/ {
bevt_44_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_19));
bevl_gc.bemd_1(1432148458, bevt_44_ta_ph);
} /* Line: 115*/
bevt_46_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_47_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_20));
bevt_45_ta_ph = bevt_46_ta_ph.bemd_1(1408797910, bevt_47_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 117*/ {
bevt_48_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_21));
bevl_gc.bemd_1(1432148458, bevt_48_ta_ph);
} /* Line: 118*/
bevt_50_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_51_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_22));
bevt_49_ta_ph = bevt_50_ta_ph.bemd_1(1408797910, bevt_51_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_49_ta_ph).bevi_bool)/* Line: 120*/ {
bevt_52_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_23));
bevl_gc.bemd_1(1432148458, bevt_52_ta_ph);
} /* Line: 121*/
bevt_54_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_55_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_24));
bevt_53_ta_ph = bevt_54_ta_ph.bemd_1(1408797910, bevt_55_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 123*/ {
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_25));
bevl_gc.bemd_1(1432148458, bevt_56_ta_ph);
} /* Line: 125*/
bevt_58_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_59_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_26));
bevt_57_ta_ph = bevt_58_ta_ph.bemd_1(1408797910, bevt_59_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_57_ta_ph).bevi_bool)/* Line: 127*/ {
bevt_60_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_27));
bevl_gc.bemd_1(1432148458, bevt_60_ta_ph);
} /* Line: 128*/
bevt_62_ta_ph = bevl_gc.bemd_0(-2079457415);
bevt_63_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_28));
bevt_61_ta_ph = bevt_62_ta_ph.bemd_1(1408797910, bevt_63_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_61_ta_ph).bevi_bool)/* Line: 130*/ {
bevt_64_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass8_bels_29));
bevl_gc.bemd_1(1432148458, bevt_64_ta_ph);
} /* Line: 131*/
bevt_65_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1167311398, bevt_65_ta_ph);
bevt_67_ta_ph = beva_op.bemd_0(822998896);
bevt_68_ta_ph = bevp_ntypes.bem_GET_METHODGet_0();
bevt_66_ta_ph = bevt_67_ta_ph.bemd_1(1408797910, bevt_68_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_66_ta_ph).bevi_bool)/* Line: 135*/ {
bevt_69_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_30));
bevp_build.bem_buildLiteral_2(beva_nx, bevt_69_ta_ph);
} /* Line: 136*/
bevt_70_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_op.bemd_1(27083027, bevt_70_ta_ph);
beva_op.bemd_1(1854508188, bevl_gc);
beva_pr.bemd_0(1547390618);
beva_op.bemd_1(1628522769, beva_pr);
bevt_72_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_71_ta_ph = beva_prec.bemd_1(1144419489, bevt_72_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_71_ta_ph).bevi_bool)/* Line: 142*/ {
beva_nx.bemd_0(1547390618);
beva_op.bemd_1(1628522769, beva_nx);
} /* Line: 144*/
return beva_op;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {14, 14, 18, 18, 19, 19, 19, 20, 20, 19, 22, 29, 29, 29, 29, 30, 31, 31, 33, 33, 33, 34, 34, 39, 40, 41, 43, 44, 44, 44, 44, 0, 0, 0, 44, 44, 0, 0, 0, 45, 45, 46, 47, 47, 48, 49, 49, 50, 50, 50, 51, 52, 52, 53, 58, 59, 59, 60, 60, 60, 62, 65, 66, 66, 67, 68, 68, 68, 69, 69, 70, 71, 71, 71, 72, 75, 80, 80, 84, 85, 85, 86, 86, 86, 86, 86, 87, 87, 87, 88, 88, 90, 90, 90, 91, 91, 93, 93, 93, 94, 94, 96, 96, 96, 97, 97, 99, 99, 99, 100, 100, 102, 102, 102, 103, 103, 105, 105, 105, 106, 106, 108, 108, 108, 109, 109, 111, 111, 111, 112, 112, 114, 114, 114, 115, 115, 117, 117, 117, 118, 118, 120, 120, 120, 121, 121, 123, 123, 123, 125, 125, 127, 127, 127, 128, 128, 130, 130, 130, 131, 131, 134, 134, 135, 135, 135, 136, 136, 138, 138, 139, 140, 141, 142, 142, 143, 144, 146};
public static new int[] bevs_smnlec
 = new int[] {45, 46, 56, 57, 58, 61, 62, 64, 65, 66, 72, 115, 116, 117, 122, 123, 124, 125, 127, 128, 129, 130, 135, 136, 137, 138, 139, 142, 147, 148, 153, 154, 157, 161, 164, 165, 167, 170, 174, 177, 178, 179, 180, 185, 186, 187, 192, 193, 194, 195, 197, 198, 203, 204, 209, 210, 215, 216, 217, 218, 221, 228, 229, 232, 234, 235, 236, 237, 239, 242, 244, 245, 246, 247, 248, 255, 262, 263, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 352, 353, 355, 356, 357, 359, 360, 362, 363, 364, 366, 367, 369, 370, 371, 373, 374, 376, 377, 378, 380, 381, 383, 384, 385, 387, 388, 390, 391, 392, 394, 395, 397, 398, 399, 401, 402, 404, 405, 406, 408, 409, 411, 412, 413, 415, 416, 418, 419, 420, 422, 423, 425, 426, 427, 429, 430, 432, 433, 434, 436, 437, 439, 440, 441, 443, 444, 446, 447, 448, 450, 451, 453, 454, 455, 456, 457, 459, 460, 462, 463, 464, 465, 466, 467, 468, 470, 471, 473};
/* BEGIN LINEINFO 
assign 1 14 45
emitDataGet 0 14 45
addParsedClass 1 14 46
assign 1 18 56
new 0 18 56
assign 1 18 57
new 1 18 57
assign 1 19 58
new 0 19 58
assign 1 19 61
new 0 19 61
assign 1 19 62
lesser 1 19 62
assign 1 20 64
new 0 20 64
put 2 20 65
assign 1 19 66
increment 0 19 66
return 1 22 72
assign 1 29 115
typenameGet 0 29 115
assign 1 29 116
CLASSGet 0 29 116
assign 1 29 117
equals 1 29 122
acceptClass 1 30 123
assign 1 31 124
nextDescendGet 0 31 124
return 1 31 125
assign 1 33 127
operGet 0 33 127
assign 1 33 128
typenameGet 0 33 128
assign 1 33 129
get 1 33 129
assign 1 34 130
def 1 34 135
assign 1 39 136
containerGet 0 39 136
assign 1 40 137
prepOps 0 40 137
assign 1 41 138
assign 1 43 139
assign 1 44 142
def 1 44 147
assign 1 44 148
def 1 44 153
assign 1 0 154
assign 1 0 157
assign 1 0 161
assign 1 44 164
containerGet 0 44 164
assign 1 44 165
equals 1 44 165
assign 1 0 167
assign 1 0 170
assign 1 0 174
assign 1 45 177
get 1 45 177
addValue 1 45 178
assign 1 46 179
nextPeerGet 0 46 179
assign 1 47 180
def 1 47 185
assign 1 48 186
nextPeerGet 0 48 186
assign 1 49 187
def 1 49 192
assign 1 50 193
typenameGet 0 50 193
assign 1 50 194
COMMAGet 0 50 194
assign 1 50 195
equals 1 50 195
assign 1 51 197
nextPeerGet 0 51 197
assign 1 52 198
def 1 52 203
assign 1 53 204
nextPeerGet 0 53 204
assign 1 58 209
assign 1 59 210
def 1 59 215
assign 1 60 216
operGet 0 60 216
assign 1 60 217
typenameGet 0 60 217
assign 1 60 218
get 1 60 218
assign 1 62 221
assign 1 65 228
new 0 65 228
assign 1 66 229
iteratorGet 0 66 229
assign 1 66 232
hasNextGet 0 66 232
assign 1 67 234
nextGet 0 67 234
assign 1 68 235
lengthGet 0 68 235
assign 1 68 236
new 0 68 236
assign 1 68 237
greater 1 68 237
assign 1 69 239
iteratorGet 0 69 239
assign 1 69 242
hasNextGet 0 69 242
assign 1 70 244
nextGet 0 70 244
assign 1 71 245
priorPeerGet 0 71 245
assign 1 71 246
nextPeerGet 0 71 246
assign 1 71 247
callFromOper 4 71 247
assign 1 72 248
assign 1 75 255
increment 0 75 255
assign 1 80 262
nextDescendGet 0 80 262
return 1 80 263
assign 1 84 340
new 0 84 340
assign 1 85 341
new 0 85 341
wasOperSet 1 85 342
assign 1 86 343
operNamesGet 0 86 343
assign 1 86 344
typenameGet 0 86 344
assign 1 86 345
get 1 86 345
assign 1 86 346
lower 0 86 346
nameSet 1 86 347
assign 1 87 348
nameGet 0 87 348
assign 1 87 349
new 0 87 349
assign 1 87 350
equals 1 87 350
assign 1 88 352
new 0 88 352
nameSet 1 88 353
assign 1 90 355
nameGet 0 90 355
assign 1 90 356
new 0 90 356
assign 1 90 357
equals 1 90 357
assign 1 91 359
new 0 91 359
nameSet 1 91 360
assign 1 93 362
nameGet 0 93 362
assign 1 93 363
new 0 93 363
assign 1 93 364
equals 1 93 364
assign 1 94 366
new 0 94 366
nameSet 1 94 367
assign 1 96 369
nameGet 0 96 369
assign 1 96 370
new 0 96 370
assign 1 96 371
equals 1 96 371
assign 1 97 373
new 0 97 373
nameSet 1 97 374
assign 1 99 376
nameGet 0 99 376
assign 1 99 377
new 0 99 377
assign 1 99 378
equals 1 99 378
assign 1 100 380
new 0 100 380
nameSet 1 100 381
assign 1 102 383
nameGet 0 102 383
assign 1 102 384
new 0 102 384
assign 1 102 385
equals 1 102 385
assign 1 103 387
new 0 103 387
nameSet 1 103 388
assign 1 105 390
nameGet 0 105 390
assign 1 105 391
new 0 105 391
assign 1 105 392
equals 1 105 392
assign 1 106 394
new 0 106 394
nameSet 1 106 395
assign 1 108 397
nameGet 0 108 397
assign 1 108 398
new 0 108 398
assign 1 108 399
equals 1 108 399
assign 1 109 401
new 0 109 401
nameSet 1 109 402
assign 1 111 404
nameGet 0 111 404
assign 1 111 405
new 0 111 405
assign 1 111 406
equals 1 111 406
assign 1 112 408
new 0 112 408
nameSet 1 112 409
assign 1 114 411
nameGet 0 114 411
assign 1 114 412
new 0 114 412
assign 1 114 413
equals 1 114 413
assign 1 115 415
new 0 115 415
nameSet 1 115 416
assign 1 117 418
nameGet 0 117 418
assign 1 117 419
new 0 117 419
assign 1 117 420
equals 1 117 420
assign 1 118 422
new 0 118 422
nameSet 1 118 423
assign 1 120 425
nameGet 0 120 425
assign 1 120 426
new 0 120 426
assign 1 120 427
equals 1 120 427
assign 1 121 429
new 0 121 429
nameSet 1 121 430
assign 1 123 432
nameGet 0 123 432
assign 1 123 433
new 0 123 433
assign 1 123 434
equals 1 123 434
assign 1 125 436
new 0 125 436
nameSet 1 125 437
assign 1 127 439
nameGet 0 127 439
assign 1 127 440
new 0 127 440
assign 1 127 441
equals 1 127 441
assign 1 128 443
new 0 128 443
nameSet 1 128 444
assign 1 130 446
nameGet 0 130 446
assign 1 130 447
new 0 130 447
assign 1 130 448
equals 1 130 448
assign 1 131 450
new 0 131 450
nameSet 1 131 451
assign 1 134 453
new 0 134 453
wasBoundSet 1 134 454
assign 1 135 455
typenameGet 0 135 455
assign 1 135 456
GET_METHODGet 0 135 456
assign 1 135 457
equals 1 135 457
assign 1 136 459
new 0 136 459
buildLiteral 2 136 460
assign 1 138 462
CALLGet 0 138 462
typenameSet 1 138 463
heldSet 1 139 464
delete 0 140 465
addValue 1 141 466
assign 1 142 467
new 0 142 467
assign 1 142 468
greater 1 142 468
delete 0 143 470
addValue 1 144 471
return 1 146 473
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -652053502: return bem_fieldNamesGet_0();
case -1893075648: return bem_buildGetDirect_0();
case 944073339: return bem_fieldIteratorGet_0();
case -1785724794: return bem_once_0();
case -1251441948: return bem_buildGet_0();
case -1480556491: return bem_toAny_0();
case 168135582: return bem_create_0();
case -884149543: return bem_constGet_0();
case 2132420479: return bem_many_0();
case -1359614197: return bem_classNameGet_0();
case -417851647: return bem_transGetDirect_0();
case 1803787653: return bem_transGet_0();
case -1044758745: return bem_serializeToString_0();
case 759496930: return bem_tagGet_0();
case 350691792: return bem_toString_0();
case 814334258: return bem_serializeContents_0();
case 1043004008: return bem_constGetDirect_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -1642361296: return bem_print_0();
case 424617382: return bem_ntypesGetDirect_0();
case -202912463: return bem_copy_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 1365897346: return bem_serializationIteratorGet_0();
case 2096109526: return bem_ntypesGet_0();
case 1161638424: return bem_new_0();
case -71162589: return bem_iteratorGet_0();
case -1711670377: return bem_hashGet_0();
case 2064925791: return bem_echo_0();
case 1669574836: return bem_prepOps_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1142023380: return bem_begin_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case 819746231: return bem_buildSet_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -164810505: return bem_ntypesSet_1(bevd_0);
case -990686106: return bem_constSetDirect_1(bevd_0);
case 1623208395: return bem_end_1(bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case -1458431940: return bem_ntypesSetDirect_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case -1061601401: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case -1762592257: return bem_acceptClass_1(bevd_0);
case -1055205804: return bem_buildSetDirect_1(bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1880603529: return bem_transSetDirect_1(bevd_0);
case -548044674: return bem_transSet_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case -965959383: return bem_constSet_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -635120563: return bem_callFromOper_4(bevd_0, bevd_1, bevd_2, bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass8_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass8_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass8();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst = (BEC_3_5_5_5_BuildVisitPass8) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;
}
}
}
