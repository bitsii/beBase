namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap : BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
static BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static new BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {90, 90, 94, 95, 96, 97, 98, 99};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 90 14
new 0 90 14
new 1 90 15
assign 1 94 19
new 1 94 19
assign 1 95 20
assign 1 96 21
new 0 96 21
assign 1 97 22
new 0 97 22
assign 1 98 23
new 0 98 23
assign 1 99 24
new 0 99 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1907635971: return bem_tagGet_0();
case -927090833: return bem_new_0();
case -41389076: return bem_multiGet_0();
case -1002607895: return bem_sizeGetDirect_0();
case 1644159961: return bem_relGetDirect_0();
case 1109704349: return bem_slotsGet_0();
case -444269598: return bem_setIteratorGet_0();
case 1550760607: return bem_fieldIteratorGet_0();
case -65082849: return bem_once_0();
case 1926333158: return bem_relGet_0();
case 605655591: return bem_sourceFileNameGet_0();
case -1655660203: return bem_hashGet_0();
case -1577817259: return bem_echo_0();
case -50560558: return bem_mapIteratorGet_0();
case -209245103: return bem_valuesGet_0();
case 1267812147: return bem_classNameGet_0();
case -1271382771: return bem_clear_0();
case -1572010998: return bem_copy_0();
case -1879356356: return bem_notEmptyGet_0();
case -112905867: return bem_keyIteratorGet_0();
case -1233682651: return bem_multiGetDirect_0();
case -1007878556: return bem_many_0();
case -1353172126: return bem_toString_0();
case 1242173088: return bem_moduGetDirect_0();
case 1840593132: return bem_sizeGet_0();
case 812685421: return bem_iteratorGet_0();
case 399659833: return bem_slotsGetDirect_0();
case 1530555194: return bem_serializeContents_0();
case -1310746877: return bem_valueIteratorGet_0();
case 702246847: return bem_print_0();
case -1000018882: return bem_create_0();
case -500248069: return bem_serializationIteratorGet_0();
case -364249863: return bem_serializeToString_0();
case 513882387: return bem_baseNodeGetDirect_0();
case -1959825752: return bem_nodesGet_0();
case 2036694681: return bem_keysGet_0();
case -106257945: return bem_fieldNamesGet_0();
case 841108956: return bem_innerPutAddedGetDirect_0();
case 1524391071: return bem_baseNodeGet_0();
case 1472054563: return bem_isEmptyGet_0();
case 1966713191: return bem_deserializeClassNameGet_0();
case -209457000: return bem_keyValueIteratorGet_0();
case -474773744: return bem_nodeIteratorGet_0();
case 1581692921: return bem_toAny_0();
case 2020633149: return bem_moduGet_0();
case 308207615: return bem_innerPutAddedGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1543095159: return bem_multiSetDirect_1(bevd_0);
case -886218051: return bem_equals_1(bevd_0);
case -481756547: return bem_undef_1(bevd_0);
case -926431997: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -227529285: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1330834253: return bem_sizeSet_1(bevd_0);
case -1096288675: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1385994869: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 860351095: return bem_moduSet_1(bevd_0);
case 1258464331: return bem_has_1(bevd_0);
case -509638081: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 150021405: return bem_otherClass_1(bevd_0);
case -78405692: return bem_slotsSet_1(bevd_0);
case -1809912257: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -759946269: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1471457238: return bem_sameObject_1(bevd_0);
case -380623615: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1862075337: return bem_copyTo_1(bevd_0);
case 439602846: return bem_get_1(bevd_0);
case 1529065971: return bem_sizeSetDirect_1(bevd_0);
case 726015407: return bem_otherType_1(bevd_0);
case -1556952447: return bem_defined_1(bevd_0);
case -10869515: return bem_delete_1(bevd_0);
case -1633669948: return bem_innerPutAddedSet_1(bevd_0);
case 1673385175: return bem_notEquals_1(bevd_0);
case 1698158300: return bem_put_1(bevd_0);
case -1784728675: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -684720356: return bem_slotsSetDirect_1(bevd_0);
case -1805171749: return bem_relSetDirect_1(bevd_0);
case 999858551: return bem_baseNodeSetDirect_1(bevd_0);
case -1940917614: return bem_addValue_1(bevd_0);
case 1953776597: return bem_sameType_1(bevd_0);
case 1829434833: return bem_moduSetDirect_1(bevd_0);
case -277595620: return bem_relSet_1(bevd_0);
case 140166424: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2141774895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 297381803: return bem_def_1(bevd_0);
case 1244819809: return bem_undefined_1(bevd_0);
case -58459221: return bem_sameClass_1(bevd_0);
case 69557453: return bem_multiSet_1(bevd_0);
case -1404821193: return bem_baseNodeSet_1(bevd_0);
case 1702481018: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1970963739: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 904162443: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -967702518: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -845452519: return bem_put_2(bevd_0, bevd_1);
case -427898914: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 414161005: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -157052200: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1722905349: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 611344245: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 938028004: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentityMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
}
