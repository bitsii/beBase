namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap : BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
static BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static new BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {91, 91, 95, 96, 97, 98, 99, 100};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 91 14
new 0 91 14
new 1 91 15
assign 1 95 19
new 1 95 19
assign 1 96 20
assign 1 97 21
new 0 97 21
assign 1 98 22
new 0 98 22
assign 1 99 23
new 0 99 23
assign 1 100 24
new 0 100 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -586636129: return bem_moduGetDirect_0();
case -1399183668: return bem_slotsGetDirect_0();
case 102870764: return bem_isEmptyGet_0();
case 1969869774: return bem_echo_0();
case -1747498826: return bem_classNameGet_0();
case 1720292040: return bem_sizeGetDirect_0();
case -1051263431: return bem_create_0();
case -539277844: return bem_fieldIteratorGet_0();
case -265550846: return bem_multiGet_0();
case -860982184: return bem_keyIteratorGet_0();
case 582559958: return bem_sizeGet_0();
case -51466514: return bem_setIteratorGet_0();
case -1470466968: return bem_baseNodeGet_0();
case -1221478671: return bem_nodesGet_0();
case 1375519361: return bem_sourceFileNameGet_0();
case 1916690324: return bem_relGet_0();
case -1850051392: return bem_notEmptyGet_0();
case 1419743617: return bem_valuesGet_0();
case 941172865: return bem_serializeContents_0();
case 322540171: return bem_toAny_0();
case 1205179000: return bem_deserializeClassNameGet_0();
case 1261669209: return bem_moduGet_0();
case 1156921009: return bem_toString_0();
case 1673476940: return bem_keyValueIteratorGet_0();
case -1421045094: return bem_clear_0();
case 1045844509: return bem_innerPutAddedGetDirect_0();
case 464610233: return bem_once_0();
case -1431960617: return bem_many_0();
case 1512772474: return bem_copy_0();
case 9411303: return bem_valueIteratorGet_0();
case 1740593523: return bem_keysGet_0();
case -1965229918: return bem_relGetDirect_0();
case -716168874: return bem_nodeIteratorGet_0();
case 709708052: return bem_slotsGet_0();
case -182215192: return bem_serializationIteratorGet_0();
case 1947173801: return bem_print_0();
case -461205434: return bem_iteratorGet_0();
case -654415539: return bem_tagGet_0();
case -1649731811: return bem_multiGetDirect_0();
case 49134257: return bem_hashGet_0();
case -721231852: return bem_mapIteratorGet_0();
case 1091235517: return bem_innerPutAddedGet_0();
case -1581666253: return bem_new_0();
case 1881939406: return bem_fieldNamesGet_0();
case 874503493: return bem_serializeToString_0();
case 756138498: return bem_baseNodeGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1491890607: return bem_has_1(bevd_0);
case -1405212164: return bem_sameClass_1(bevd_0);
case -1864844031: return bem_relSetDirect_1(bevd_0);
case 1779380050: return bem_undefined_1(bevd_0);
case 2125870571: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1089354598: return bem_undef_1(bevd_0);
case -676560281: return bem_sizeSetDirect_1(bevd_0);
case -1998213816: return bem_multiSet_1(bevd_0);
case 1966156517: return bem_otherClass_1(bevd_0);
case -324004617: return bem_get_1(bevd_0);
case -1947128519: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -767033831: return bem_multiSetDirect_1(bevd_0);
case 1026158152: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -653588721: return bem_otherType_1(bevd_0);
case 1868103554: return bem_innerPutAddedSet_1(bevd_0);
case 117977401: return bem_relSet_1(bevd_0);
case 447923928: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1919318715: return bem_sizeSet_1(bevd_0);
case -1295446558: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -401537677: return bem_slotsSetDirect_1(bevd_0);
case -373658986: return bem_equals_1(bevd_0);
case 778331504: return bem_def_1(bevd_0);
case -498298486: return bem_sameObject_1(bevd_0);
case -1940703752: return bem_copyTo_1(bevd_0);
case 814299234: return bem_baseNodeSet_1(bevd_0);
case 318151132: return bem_put_1(bevd_0);
case 1182616943: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1817351105: return bem_defined_1(bevd_0);
case 976871586: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -151332191: return bem_moduSet_1(bevd_0);
case 125468325: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1499911921: return bem_notEquals_1(bevd_0);
case -1264044693: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1806833239: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -2016123429: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 830627070: return bem_moduSetDirect_1(bevd_0);
case -1586212682: return bem_addValue_1(bevd_0);
case -1514733190: return bem_slotsSet_1(bevd_0);
case 372746140: return bem_sameType_1(bevd_0);
case 243162876: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1615136912: return bem_baseNodeSetDirect_1(bevd_0);
case -753687290: return bem_delete_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 888716978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1714613573: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2102527451: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 193506539: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1129259785: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -292360250: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 614290015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 414389553: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -33740438: return bem_put_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 118747615: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentityMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
}
