namespace be {
public class BET_2_4_7_TestFailure : BETS_Object {
public BET_2_4_7_TestFailure() {
string[] bevs_mtnames = new string[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "new_1", "translateEmittedException_0", "translateEmittedExceptionInner_0", "getSourceFileName_1", "extractKlassLib_1", "extractKlass_1", "extractKlassInner_1", "extractMethod_1", "framesGet_0", "getFrameText_0", "klassNameGet_0", "addFrame_1", "addFrame_4", "methodNameGet_0", "methodNameGetDirect_0", "methodNameSet_1", "methodNameSetDirect_1", "klassNameGetDirect_0", "klassNameSet_1", "klassNameSetDirect_1", "descriptionGet_0", "descriptionGetDirect_0", "descriptionSet_1", "descriptionSetDirect_1", "fileNameGet_0", "fileNameGetDirect_0", "fileNameSet_1", "fileNameSetDirect_1", "lineNumberGet_0", "lineNumberGetDirect_0", "lineNumberSet_1", "lineNumberSetDirect_1", "langGet_0", "langGetDirect_0", "langSet_1", "langSetDirect_1", "emitLangGet_0", "emitLangGetDirect_0", "emitLangSet_1", "emitLangSetDirect_1", "framesGetDirect_0", "framesSet_1", "framesSetDirect_1", "framesTextGet_0", "framesTextGetDirect_0", "framesTextSet_1", "framesTextSetDirect_1", "translatedGet_0", "translatedGetDirect_0", "translatedSet_1", "translatedSetDirect_1", "vvGet_0", "vvGetDirect_0", "vvSet_1", "vvSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new string[] { "methodName", "klassName", "description", "fileName", "lineNumber", "lang", "emitLang", "frames", "framesText", "translated", "vv" };
}
static BET_2_4_7_TestFailure() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_7_TestFailure();
}
}
}
