namespace be {
/* IO:File: source/base/DoNothing.be */
public class BEC_2_6_9_SystemDoNothing : BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemDoNothing() { }
static BEC_2_6_9_SystemDoNothing() { }
private static byte[] becc_BEC_2_6_9_SystemDoNothing_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x44,0x6F,0x4E,0x6F,0x74,0x68,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_6_9_SystemDoNothing_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x44,0x6F,0x4E,0x6F,0x74,0x68,0x69,0x6E,0x67,0x2E,0x62,0x65};
public static new BEC_2_6_9_SystemDoNothing bece_BEC_2_6_9_SystemDoNothing_bevs_inst;

public static new BET_2_6_9_SystemDoNothing bece_BEC_2_6_9_SystemDoNothing_bevs_type;

public virtual BEC_2_6_9_SystemDoNothing bem_main_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 952056940: return bem_toString_0();
case 26617766: return bem_main_0();
case -181500453: return bem_copy_0();
case -664467345: return bem_create_0();
case 1782620959: return bem_echo_0();
case -1714811768: return bem_fieldIteratorGet_0();
case -655092564: return bem_serializationIteratorGet_0();
case -1665576026: return bem_sourceFileNameGet_0();
case -157733273: return bem_many_0();
case -1830560348: return bem_fieldNamesGet_0();
case -1054400757: return bem_deserializeClassNameGet_0();
case 144506434: return bem_new_0();
case 2005192015: return bem_serializeToString_0();
case -1434960598: return bem_serializeContents_0();
case -1427827058: return bem_once_0();
case 1794518227: return bem_iteratorGet_0();
case 2132306504: return bem_classNameGet_0();
case -377355642: return bem_hashGet_0();
case 1667331006: return bem_toAny_0();
case 455481848: return bem_print_0();
case -1313867098: return bem_tagGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1432196319: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -459360005: return bem_otherClass_1(bevd_0);
case 1003716077: return bem_def_1(bevd_0);
case 1135973654: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -98791052: return bem_defined_1(bevd_0);
case 1198427025: return bem_notEquals_1(bevd_0);
case 1911701664: return bem_equals_1(bevd_0);
case 1377625485: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 241299765: return bem_sameType_1(bevd_0);
case 1532532742: return bem_undefined_1(bevd_0);
case -26559400: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2102889872: return bem_sameClass_1(bevd_0);
case 2069326800: return bem_otherType_1(bevd_0);
case 1272963269: return bem_sameObject_1(bevd_0);
case -2123337515: return bem_undef_1(bevd_0);
case -585494508: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1234965347: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -720811311: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 674286989: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1973929830: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -389946827: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2041425680: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1411035525: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemDoNothing_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_9_SystemDoNothing_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_9_SystemDoNothing();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_9_SystemDoNothing.bece_BEC_2_6_9_SystemDoNothing_bevs_inst = (BEC_2_6_9_SystemDoNothing) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_9_SystemDoNothing.bece_BEC_2_6_9_SystemDoNothing_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_9_SystemDoNothing.bece_BEC_2_6_9_SystemDoNothing_bevs_type;
}
}
}
