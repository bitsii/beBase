namespace be {
/* IO:File: source/extended/Log.be */
public class BEC_2_2_3_IOLog : BEC_2_6_6_SystemObject {
public BEC_2_2_3_IOLog() { }
static BEC_2_2_3_IOLog() { }
private static byte[] becc_BEC_2_2_3_IOLog_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_2_3_IOLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_3_IOLog_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_0, 4));
private static byte[] bece_BEC_2_2_3_IOLog_bels_1 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_1, 4));
private static byte[] bece_BEC_2_2_3_IOLog_bels_2 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_2, 4));
public static new BEC_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_inst;

public static new BET_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_type;

public BEC_2_4_3_MathInt bevp_outputLevel;
public BEC_2_4_3_MathInt bevp_level;
public virtual BEC_2_2_3_IOLog bem_new_2(BEC_2_6_6_SystemObject beva__outputLevel, BEC_2_6_6_SystemObject beva__level) {
bevp_outputLevel = (BEC_2_4_3_MathInt) beva__outputLevel;
bevp_level = (BEC_2_4_3_MathInt) beva__level;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_will_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 136 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 137 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_will_1(BEC_2_4_3_MathInt beva__level) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 143 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 144 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_log_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 150 */ {
if (beva_msg == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 151 */ {
beva_msg.bem_print_0();
} /* Line: 152 */
 else  /* Line: 153 */ {
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_0;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 154 */
} /* Line: 151 */
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_log_2(BEC_2_4_3_MathInt beva__level, BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 160 */ {
if (beva_msg == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 161 */ {
beva_msg.bem_print_0();
} /* Line: 162 */
 else  /* Line: 163 */ {
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_1;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 164 */
} /* Line: 161 */
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_output_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (beva_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 170 */ {
beva_msg.bem_print_0();
} /* Line: 171 */
 else  /* Line: 172 */ {
bevt_1_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_2;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 173 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_outputLevelGet_0() {
return bevp_outputLevel;
} /*method end*/
public BEC_2_4_3_MathInt bem_outputLevelGetDirect_0() {
return bevp_outputLevel;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_outputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_outputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_levelGet_0() {
return bevp_level;
} /*method end*/
public BEC_2_4_3_MathInt bem_levelGetDirect_0() {
return bevp_level;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_levelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_levelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {130, 131, 136, 136, 137, 137, 139, 139, 143, 143, 144, 144, 146, 146, 150, 150, 151, 151, 152, 154, 154, 160, 160, 161, 161, 162, 164, 164, 170, 170, 171, 173, 173, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 29, 34, 35, 36, 38, 39, 45, 50, 51, 52, 54, 55, 61, 66, 67, 72, 73, 76, 77, 86, 91, 92, 97, 98, 101, 102, 110, 115, 116, 119, 120, 125, 128, 131, 135, 139, 142, 145, 149};
/* BEGIN LINEINFO 
assign 1 130 21
assign 1 131 22
assign 1 136 29
lesserEquals 1 136 34
assign 1 137 35
new 0 137 35
return 1 137 36
assign 1 139 38
new 0 139 38
return 1 139 39
assign 1 143 45
lesserEquals 1 143 50
assign 1 144 51
new 0 144 51
return 1 144 52
assign 1 146 54
new 0 146 54
return 1 146 55
assign 1 150 61
lesserEquals 1 150 66
assign 1 151 67
def 1 151 72
print 0 152 73
assign 1 154 76
new 0 154 76
print 0 154 77
assign 1 160 86
lesserEquals 1 160 91
assign 1 161 92
def 1 161 97
print 0 162 98
assign 1 164 101
new 0 164 101
print 0 164 102
assign 1 170 110
def 1 170 115
print 0 171 116
assign 1 173 119
new 0 173 119
print 0 173 120
return 1 0 125
return 1 0 128
assign 1 0 131
assign 1 0 135
return 1 0 139
return 1 0 142
assign 1 0 145
assign 1 0 149
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -973144159: return bem_will_0();
case 941172865: return bem_serializeContents_0();
case -182215192: return bem_serializationIteratorGet_0();
case 1881939406: return bem_fieldNamesGet_0();
case -461205434: return bem_iteratorGet_0();
case 464610233: return bem_once_0();
case -1099873808: return bem_outputLevelGet_0();
case -1051263431: return bem_create_0();
case -1876134748: return bem_outputLevelGetDirect_0();
case -539277844: return bem_fieldIteratorGet_0();
case 322540171: return bem_toAny_0();
case 1512772474: return bem_copy_0();
case -706420501: return bem_levelGet_0();
case -1431960617: return bem_many_0();
case -1581666253: return bem_new_0();
case 1156921009: return bem_toString_0();
case 1947173801: return bem_print_0();
case 49134257: return bem_hashGet_0();
case 1205179000: return bem_deserializeClassNameGet_0();
case -1747498826: return bem_classNameGet_0();
case 1969869774: return bem_echo_0();
case 1376231619: return bem_levelGetDirect_0();
case 874503493: return bem_serializeToString_0();
case -654415539: return bem_tagGet_0();
case 1375519361: return bem_sourceFileNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 253155746: return bem_outputLevelSetDirect_1(bevd_0);
case -653588721: return bem_otherType_1(bevd_0);
case 778331504: return bem_def_1(bevd_0);
case -1295446558: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1940703752: return bem_copyTo_1(bevd_0);
case 1779380050: return bem_undefined_1(bevd_0);
case -1405212164: return bem_sameClass_1(bevd_0);
case -1455264169: return bem_will_1((BEC_2_4_3_MathInt) bevd_0);
case 1817351105: return bem_defined_1(bevd_0);
case -314396540: return bem_output_1((BEC_2_4_6_TextString) bevd_0);
case 447923928: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1499911921: return bem_notEquals_1(bevd_0);
case -373658986: return bem_equals_1(bevd_0);
case 120404313: return bem_levelSet_1(bevd_0);
case -1264044693: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1531721630: return bem_log_1((BEC_2_4_6_TextString) bevd_0);
case 372746140: return bem_sameType_1(bevd_0);
case 243162876: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1089354598: return bem_undef_1(bevd_0);
case -498298486: return bem_sameObject_1(bevd_0);
case 1966156517: return bem_otherClass_1(bevd_0);
case -1925355229: return bem_outputLevelSet_1(bevd_0);
case 1723765464: return bem_levelSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 414389553: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1026602887: return bem_new_2(bevd_0, bevd_1);
case 1714613573: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -292360250: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1129259785: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 614290015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 888716978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1972596305: return bem_log_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 193506539: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(6, becc_BEC_2_2_3_IOLog_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_3_IOLog_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_3_IOLog();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst = (BEC_2_2_3_IOLog) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_type;
}
}
}
