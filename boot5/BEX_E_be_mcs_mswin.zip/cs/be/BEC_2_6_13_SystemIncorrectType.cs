namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_13_SystemIncorrectType : BEC_2_6_9_SystemException {
public BEC_2_6_13_SystemIncorrectType() { }
static BEC_2_6_13_SystemIncorrectType() { }
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x54,0x79,0x70,0x65};
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;

public static new BET_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_type;

public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
bevp_description = beva_descr;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {372};
public static new int[] bevs_smnlec
 = new int[] {13};
/* BEGIN LINEINFO 
assign 1 372 13
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1628841870: return bem_new_0();
case -1893116337: return bem_fileNameGet_0();
case -1251154989: return bem_descriptionGetDirect_0();
case -294806467: return bem_create_0();
case -1027681934: return bem_framesTextGetDirect_0();
case -302817860: return bem_deserializeClassNameGet_0();
case -494057832: return bem_serializationIteratorGet_0();
case -1342633655: return bem_hashGet_0();
case -1916548323: return bem_once_0();
case 1196099876: return bem_echo_0();
case -888502976: return bem_print_0();
case 1269571591: return bem_methodNameGetDirect_0();
case -1297985879: return bem_fieldNamesGet_0();
case -147298756: return bem_vvGet_0();
case -1122332955: return bem_lineNumberGetDirect_0();
case -434911523: return bem_emitLangGet_0();
case 374612292: return bem_fileNameGetDirect_0();
case -1543906095: return bem_getFrameText_0();
case -381924126: return bem_translateEmittedExceptionInner_0();
case -1230714712: return bem_classNameGet_0();
case -671191297: return bem_serializeContents_0();
case 787941758: return bem_emitLangGetDirect_0();
case 1339463094: return bem_translatedGetDirect_0();
case 1989485633: return bem_many_0();
case 1797020795: return bem_toAny_0();
case -1609183284: return bem_klassNameGet_0();
case 32265036: return bem_langGet_0();
case -946267519: return bem_framesGetDirect_0();
case -1643131533: return bem_vvGetDirect_0();
case 1740779891: return bem_lineNumberGet_0();
case 1756033276: return bem_framesGet_0();
case 1832806152: return bem_toString_0();
case -242463884: return bem_fieldIteratorGet_0();
case 1418348540: return bem_iteratorGet_0();
case -905424223: return bem_translateEmittedException_0();
case -170941956: return bem_serializeToString_0();
case 1426244864: return bem_framesTextGet_0();
case -1222154604: return bem_tagGet_0();
case 1259940094: return bem_klassNameGetDirect_0();
case 1328429379: return bem_methodNameGet_0();
case 1633476787: return bem_translatedGet_0();
case -942675959: return bem_descriptionGet_0();
case -901412127: return bem_langGetDirect_0();
case -1925247459: return bem_sourceFileNameGet_0();
case 213564239: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -152296894: return bem_equals_1(bevd_0);
case 1602348302: return bem_sameObject_1(bevd_0);
case 1236940655: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -395616432: return bem_otherClass_1(bevd_0);
case 301814767: return bem_framesSetDirect_1(bevd_0);
case 79810732: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1446216471: return bem_descriptionSetDirect_1(bevd_0);
case -118558475: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1514218528: return bem_emitLangSet_1(bevd_0);
case 1267378865: return bem_langSet_1(bevd_0);
case 945449374: return bem_notEquals_1(bevd_0);
case 924695759: return bem_translatedSet_1(bevd_0);
case 1649556969: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 223792752: return bem_klassNameSet_1(bevd_0);
case 936942966: return bem_undefined_1(bevd_0);
case 1892549801: return bem_framesSet_1(bevd_0);
case -2046043947: return bem_copyTo_1(bevd_0);
case 1569424591: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -523979366: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1436334009: return bem_new_1(bevd_0);
case -444625602: return bem_framesTextSet_1(bevd_0);
case 1962218301: return bem_fileNameSetDirect_1(bevd_0);
case 1810770914: return bem_vvSetDirect_1(bevd_0);
case -1737115805: return bem_emitLangSetDirect_1(bevd_0);
case 805733760: return bem_framesTextSetDirect_1(bevd_0);
case 483207545: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 346995129: return bem_def_1(bevd_0);
case -456462670: return bem_fileNameSet_1(bevd_0);
case -909700659: return bem_translatedSetDirect_1(bevd_0);
case -1811224480: return bem_sameType_1(bevd_0);
case -1109705603: return bem_lineNumberSet_1(bevd_0);
case 1791174458: return bem_descriptionSet_1(bevd_0);
case 1337089292: return bem_methodNameSet_1(bevd_0);
case -810647371: return bem_sameClass_1(bevd_0);
case -788622974: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1345095935: return bem_defined_1(bevd_0);
case 1955170897: return bem_vvSet_1(bevd_0);
case -274501031: return bem_lineNumberSetDirect_1(bevd_0);
case 2030985379: return bem_methodNameSetDirect_1(bevd_0);
case 88301375: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 83181817: return bem_undef_1(bevd_0);
case 1867065609: return bem_langSetDirect_1(bevd_0);
case -1796596677: return bem_otherType_1(bevd_0);
case 1495593147: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1962812172: return bem_klassNameSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -174395426: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1117645207: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1434652185: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2038467728: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 6185266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 34704188: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1515774718: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -997529892: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_13_SystemIncorrectType_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_13_SystemIncorrectType_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_13_SystemIncorrectType();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst = (BEC_2_6_13_SystemIncorrectType) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_type;
}
}
}
