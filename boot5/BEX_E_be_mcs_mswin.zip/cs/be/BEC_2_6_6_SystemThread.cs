namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_6_SystemThread : BEC_2_6_10_SystemThinThread {
public BEC_2_6_6_SystemThread() { }
static BEC_2_6_6_SystemThread() { }
private static byte[] becc_BEC_2_6_6_SystemThread_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64};
private static byte[] becc_BEC_2_6_6_SystemThread_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_inst;

public static new BET_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_type;

public BEC_3_6_6_12_SystemThreadObjectLocker bevp_started;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_finished;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_threwException;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_returned;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_exception;
public override BEC_2_6_10_SystemThinThread bem_new_1(BEC_2_6_6_SystemObject beva__toRun) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_1_tmpany_phold);
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
base.bem_new_1(beva__toRun);
return this;
} /*method end*/
public override BEC_2_6_10_SystemThinThread bem_main_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
try  /* Line: 788 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_started.bem_oSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_toRun.bemd_0(-1127142206);
bevp_returned.bem_oSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_threwException.bem_oSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_3_tmpany_phold);
} /* Line: 792 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_threwException.bem_oSet_1(bevt_4_tmpany_phold);
bevp_exception.bem_oSet_1(bevl_e);
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_5_tmpany_phold);
} /* Line: 796 */
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_startedGet_0() {
return bevp_started;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_startedGetDirect_0() {
return bevp_started;
} /*method end*/
public BEC_2_6_6_SystemThread bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_startedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_finishedGet_0() {
return bevp_finished;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_finishedGetDirect_0() {
return bevp_finished;
} /*method end*/
public BEC_2_6_6_SystemThread bem_finishedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_finishedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_threwExceptionGet_0() {
return bevp_threwException;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_threwExceptionGetDirect_0() {
return bevp_threwException;
} /*method end*/
public BEC_2_6_6_SystemThread bem_threwExceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_threwExceptionSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_returnedGet_0() {
return bevp_returned;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_returnedGetDirect_0() {
return bevp_returned;
} /*method end*/
public BEC_2_6_6_SystemThread bem_returnedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_returnedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_exceptionGet_0() {
return bevp_exception;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_exceptionGetDirect_0() {
return bevp_exception;
} /*method end*/
public BEC_2_6_6_SystemThread bem_exceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_exceptionSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {777, 777, 778, 778, 779, 780, 781, 783, 789, 789, 790, 790, 791, 791, 792, 792, 794, 794, 795, 796, 796, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 27, 28, 29, 30, 31, 32, 44, 45, 46, 47, 48, 49, 50, 51, 55, 56, 57, 58, 59, 64, 67, 70, 74, 78, 81, 84, 88, 92, 95, 98, 102, 106, 109, 112, 116, 120, 123, 126, 130};
/* BEGIN LINEINFO 
assign 1 777 25
new 0 777 25
assign 1 777 26
new 1 777 26
assign 1 778 27
new 0 778 27
assign 1 778 28
new 1 778 28
assign 1 779 29
new 0 779 29
assign 1 780 30
new 0 780 30
assign 1 781 31
new 0 781 31
new 1 783 32
assign 1 789 44
new 0 789 44
oSet 1 789 45
assign 1 790 46
main 0 790 46
oSet 1 790 47
assign 1 791 48
new 0 791 48
oSet 1 791 49
assign 1 792 50
new 0 792 50
oSet 1 792 51
assign 1 794 55
new 0 794 55
oSet 1 794 56
oSet 1 795 57
assign 1 796 58
new 0 796 58
oSet 1 796 59
return 1 0 64
return 1 0 67
assign 1 0 70
assign 1 0 74
return 1 0 78
return 1 0 81
assign 1 0 84
assign 1 0 88
return 1 0 92
return 1 0 95
assign 1 0 98
assign 1 0 102
return 1 0 106
return 1 0 109
assign 1 0 112
assign 1 0 116
return 1 0 120
return 1 0 123
assign 1 0 126
assign 1 0 130
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1546544584: return bem_serializationIteratorGet_0();
case -284358906: return bem_startedGetDirect_0();
case -1127142206: return bem_main_0();
case -630280728: return bem_copy_0();
case -300479504: return bem_start_0();
case -576816204: return bem_sourceFileNameGet_0();
case 1438915338: return bem_once_0();
case -1409233752: return bem_toAny_0();
case -345733535: return bem_wait_0();
case -695733973: return bem_hashGet_0();
case -373483362: return bem_classNameGet_0();
case -1847620794: return bem_iteratorGet_0();
case 89630632: return bem_returnedGet_0();
case 1945803401: return bem_print_0();
case -830733381: return bem_echo_0();
case 1606642997: return bem_new_0();
case -1804555482: return bem_returnedGetDirect_0();
case 1824978540: return bem_threwExceptionGet_0();
case -1736147886: return bem_exceptionGet_0();
case -1590584500: return bem_startedGet_0();
case 167399763: return bem_deserializeClassNameGet_0();
case -1304234247: return bem_threwExceptionGetDirect_0();
case 1652382745: return bem_finishedGet_0();
case 2086474367: return bem_create_0();
case 1169011989: return bem_toString_0();
case 1225291287: return bem_toRunGetDirect_0();
case 1425790109: return bem_fieldIteratorGet_0();
case -408522205: return bem_serializeContents_0();
case 2034825137: return bem_tagGet_0();
case -2084016052: return bem_serializeToString_0();
case 1738591028: return bem_fieldNamesGet_0();
case 1066489349: return bem_many_0();
case -1075719997: return bem_exceptionGetDirect_0();
case -1564186274: return bem_toRunGet_0();
case 1152370227: return bem_finishedGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1790575350: return bem_sameClass_1(bevd_0);
case -2045883718: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 232552830: return bem_otherType_1(bevd_0);
case -1227067502: return bem_startedSetDirect_1(bevd_0);
case 837560630: return bem_threwExceptionSet_1(bevd_0);
case -123559847: return bem_returnedSet_1(bevd_0);
case 12334054: return bem_finishedSet_1(bevd_0);
case -190641341: return bem_new_1(bevd_0);
case -726390043: return bem_undef_1(bevd_0);
case 1225117403: return bem_returnedSetDirect_1(bevd_0);
case -85967812: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1642039472: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1663786357: return bem_equals_1(bevd_0);
case -1493515213: return bem_startedSet_1(bevd_0);
case -1371116116: return bem_otherClass_1(bevd_0);
case -463115686: return bem_def_1(bevd_0);
case 990906181: return bem_toRunSetDirect_1(bevd_0);
case 1919206107: return bem_exceptionSetDirect_1(bevd_0);
case 876386412: return bem_sameObject_1(bevd_0);
case 662174377: return bem_exceptionSet_1(bevd_0);
case 575763691: return bem_undefined_1(bevd_0);
case -1854318841: return bem_copyTo_1(bevd_0);
case -2073425080: return bem_sameType_1(bevd_0);
case 542523031: return bem_defined_1(bevd_0);
case 1362077867: return bem_toRunSet_1(bevd_0);
case 85290438: return bem_finishedSetDirect_1(bevd_0);
case -1561485139: return bem_threwExceptionSetDirect_1(bevd_0);
case 1449183263: return bem_notEquals_1(bevd_0);
case 491873122: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1558133875: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -897682046: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 990151340: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600497328: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 116337276: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2028666619: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1471832670: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemThread_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemThread_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemThread();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst = (BEC_2_6_6_SystemThread) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_type;
}
}
}
