namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_7_TextStrings : BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
static BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_5 = {};
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_7_TextStrings_bels_6 = {};
private static BEC_2_4_6_TextString bece_BEC_2_4_7_TextStrings_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_4_7_TextStrings_bels_6, 0));
public static new BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static new BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevp_space = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevp_quote = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_tab = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_tmpany_phold);
bevp_dosNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(13));
bevp_cr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_tmpany_phold);
bevp_lf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_colon = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_4));
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = beva_splits.bemd_0(1794518227);
bevt_1_tmpany_phold = bevl_i.bemd_0(179779414);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1343413621);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1235 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_tmpany_phold;
} /* Line: 1236 */
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_tmpany_phold = bevl_i.bemd_0(2034429922);
bevl_buf.bem_addValue_1(bevt_3_tmpany_phold);
while (true)
 /* Line: 1240 */ {
bevt_4_tmpany_phold = bevl_i.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 1240 */ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_tmpany_phold = bevl_i.bemd_0(2034429922);
bevl_buf.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 1242 */
 else  /* Line: 1240 */ {
break;
} /* Line: 1240 */
} /* Line: 1240 */
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_beg = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
 /* Line: 1252 */ {
bevt_0_tmpany_phold = bevl_mb.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1252 */ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_tmpany_phold = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1254 */ {
if (bevl_foundChar.bevi_bool) /* Line: 1255 */ {
bevl_end.bevi_int++;
} /* Line: 1256 */
 else  /* Line: 1257 */ {
bevl_beg.bevi_int++;
} /* Line: 1258 */
} /* Line: 1255 */
 else  /* Line: 1260 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1262 */
} /* Line: 1254 */
 else  /* Line: 1252 */ {
break;
} /* Line: 1252 */
} /* Line: 1252 */
if (bevl_foundChar.bevi_bool) /* Line: 1265 */ {
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_tmpany_phold);
} /* Line: 1266 */
 else  /* Line: 1267 */ {
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_5));
} /* Line: 1268 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1274 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1274 */ {
if (beva_b == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1274 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1274 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1274 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1274 */ {
return null;
} /* Line: 1274 */
bevt_3_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_tmpany_phold = beva_a.bem_sizeGet_0();
bevt_5_tmpany_phold = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_min_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 1280 */ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1280 */ {
bevl_ai.bemd_1(-1502623478, bevl_av);
bevl_bi.bemd_1(-1502623478, bevl_bv);
bevt_7_tmpany_phold = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 1283 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_0;
bevt_8_tmpany_phold = beva_a.bem_substring_2(bevt_9_tmpany_phold, bevl_i);
return bevt_8_tmpany_phold;
} /* Line: 1284 */
bevl_i.bevi_int++;
} /* Line: 1280 */
 else  /* Line: 1280 */ {
break;
} /* Line: 1280 */
} /* Line: 1280 */
bevt_11_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_1;
bevt_10_tmpany_phold = beva_a.bem_substring_2(bevt_11_tmpany_phold, bevl_i);
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevt_0_tmpany_loop = beva_strs.bemd_0(1794518227);
while (true)
 /* Line: 1291 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 1291 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(2034429922);
bevt_2_tmpany_phold = bem_isEmpty_1(bevl_i);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1292 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 1293 */
} /* Line: 1292 */
 else  /* Line: 1291 */ {
break;
} /* Line: 1291 */
} /* Line: 1291 */
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1300 */ {
bevt_3_tmpany_phold = beva_value.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_2;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1300 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1300 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 1301 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1307 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_3;
bevt_2_tmpany_phold = beva_value.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1307 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1307 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1307 */
 else  /* Line: 1307 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1307 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 1308 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGetDirect_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGetDirect_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGetDirect_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGetDirect_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_6_TextString bem_crGetDirect_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGetDirect_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGetDirect_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGetDirect_0() {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() {
return bevp_ws;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGetDirect_0() {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1209, 1210, 1211, 1211, 1212, 1212, 1213, 1214, 1216, 1216, 1217, 1218, 1219, 1220, 1223, 1224, 1225, 1226, 1230, 1230, 1234, 1235, 1235, 1236, 1236, 1238, 1239, 1239, 1240, 1241, 1242, 1242, 1244, 1248, 1249, 1250, 1251, 1252, 1253, 1254, 1256, 1258, 1261, 1261, 1262, 1266, 1266, 1266, 1268, 1270, 1274, 1274, 0, 1274, 1274, 0, 0, 1274, 1275, 1275, 1275, 1275, 1276, 1277, 1278, 1279, 1280, 1280, 1280, 1281, 1282, 1283, 1284, 1284, 1284, 1280, 1287, 1287, 1287, 1291, 0, 1291, 1291, 1292, 1293, 1293, 1296, 1296, 1300, 1300, 0, 1300, 1300, 1300, 1300, 0, 0, 1301, 1301, 1303, 1303, 1307, 1307, 1307, 1307, 0, 0, 0, 1308, 1308, 1310, 1310, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 67, 68, 79, 80, 81, 83, 84, 86, 87, 88, 91, 93, 94, 95, 101, 115, 116, 117, 118, 121, 123, 124, 127, 130, 134, 135, 136, 144, 145, 146, 149, 151, 172, 177, 178, 181, 186, 187, 190, 194, 196, 197, 198, 199, 200, 201, 202, 203, 204, 207, 212, 213, 214, 215, 217, 218, 219, 221, 227, 228, 229, 238, 238, 241, 243, 244, 246, 247, 254, 255, 265, 270, 271, 274, 275, 276, 281, 282, 285, 289, 290, 292, 293, 302, 307, 308, 309, 311, 314, 318, 321, 322, 324, 325, 328, 331, 334, 338, 342, 345, 348, 352, 356, 359, 362, 366, 370, 373, 376, 380, 384, 387, 390, 394, 398, 401, 404, 408, 412, 415, 418, 422, 426, 429, 432, 436, 440, 443, 446, 450, 454, 457, 460, 464, 468, 471, 474, 478, 482, 485, 488, 492};
/* BEGIN LINEINFO 
assign 1 1209 45
new 0 1209 45
assign 1 1210 46
new 0 1210 46
assign 1 1211 47
new 0 1211 47
assign 1 1211 48
codeNew 1 1211 48
assign 1 1212 49
new 0 1212 49
assign 1 1212 50
codeNew 1 1212 50
assign 1 1213 51
new 0 1213 51
assign 1 1214 52
new 0 1214 52
assign 1 1216 53
new 0 1216 53
assign 1 1216 54
codeNew 1 1216 54
assign 1 1217 55
new 0 1217 55
assign 1 1218 56
new 0 1218 56
assign 1 1219 57
new 1 1219 57
assign 1 1220 58
new 0 1220 58
put 1 1223 59
put 1 1224 60
put 1 1225 61
put 1 1226 62
assign 1 1230 67
joinBuffer 2 1230 67
return 1 1230 68
assign 1 1234 79
iteratorGet 0 1234 79
assign 1 1235 80
hasNextGet 0 1235 80
assign 1 1235 81
not 0 1235 81
assign 1 1236 83
new 0 1236 83
return 1 1236 84
assign 1 1238 86
new 0 1238 86
assign 1 1239 87
nextGet 0 1239 87
addValue 1 1239 88
assign 1 1240 91
hasNextGet 0 1240 91
addValue 1 1241 93
assign 1 1242 94
nextGet 0 1242 94
addValue 1 1242 95
return 1 1244 101
assign 1 1248 115
new 0 1248 115
assign 1 1249 116
new 0 1249 116
assign 1 1250 117
new 0 1250 117
assign 1 1251 118
mbiterGet 0 1251 118
assign 1 1252 121
hasNextGet 0 1252 121
assign 1 1253 123
nextGet 0 1253 123
assign 1 1254 124
has 1 1254 124
incrementValue 0 1256 127
incrementValue 0 1258 130
assign 1 1261 134
new 0 1261 134
setValue 1 1261 135
assign 1 1262 136
new 0 1262 136
assign 1 1266 144
sizeGet 0 1266 144
assign 1 1266 145
subtract 1 1266 145
assign 1 1266 146
substring 2 1266 146
assign 1 1268 149
new 0 1268 149
return 1 1270 151
assign 1 1274 172
undef 1 1274 177
assign 1 0 178
assign 1 1274 181
undef 1 1274 186
assign 1 0 187
assign 1 0 190
return 1 1274 194
assign 1 1275 196
new 0 1275 196
assign 1 1275 197
sizeGet 0 1275 197
assign 1 1275 198
sizeGet 0 1275 198
assign 1 1275 199
min 2 1275 199
assign 1 1276 200
biterGet 0 1276 200
assign 1 1277 201
biterGet 0 1277 201
assign 1 1278 202
new 0 1278 202
assign 1 1279 203
new 0 1279 203
assign 1 1280 204
new 0 1280 204
assign 1 1280 207
lesser 1 1280 212
next 1 1281 213
next 1 1282 214
assign 1 1283 215
notEquals 1 1283 215
assign 1 1284 217
new 0 1284 217
assign 1 1284 218
substring 2 1284 218
return 1 1284 219
incrementValue 0 1280 221
assign 1 1287 227
new 0 1287 227
assign 1 1287 228
substring 2 1287 228
return 1 1287 229
assign 1 1291 238
iteratorGet 0 0 238
assign 1 1291 241
hasNextGet 0 1291 241
assign 1 1291 243
nextGet 0 1291 243
assign 1 1292 244
isEmpty 1 1292 244
assign 1 1293 246
new 0 1293 246
return 1 1293 247
assign 1 1296 254
new 0 1296 254
return 1 1296 255
assign 1 1300 265
undef 1 1300 270
assign 1 0 271
assign 1 1300 274
sizeGet 0 1300 274
assign 1 1300 275
new 0 1300 275
assign 1 1300 276
lesser 1 1300 281
assign 1 0 282
assign 1 0 285
assign 1 1301 289
new 0 1301 289
return 1 1301 290
assign 1 1303 292
new 0 1303 292
return 1 1303 293
assign 1 1307 302
def 1 1307 307
assign 1 1307 308
new 0 1307 308
assign 1 1307 309
notEquals 1 1307 309
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 1308 321
new 0 1308 321
return 1 1308 322
assign 1 1310 324
new 0 1310 324
return 1 1310 325
return 1 0 328
return 1 0 331
assign 1 0 334
assign 1 0 338
return 1 0 342
return 1 0 345
assign 1 0 348
assign 1 0 352
return 1 0 356
return 1 0 359
assign 1 0 362
assign 1 0 366
return 1 0 370
return 1 0 373
assign 1 0 376
assign 1 0 380
return 1 0 384
return 1 0 387
assign 1 0 390
assign 1 0 394
return 1 0 398
return 1 0 401
assign 1 0 404
assign 1 0 408
return 1 0 412
return 1 0 415
assign 1 0 418
assign 1 0 422
return 1 0 426
return 1 0 429
assign 1 0 432
assign 1 0 436
return 1 0 440
return 1 0 443
assign 1 0 446
assign 1 0 450
return 1 0 454
return 1 0 457
assign 1 0 460
assign 1 0 464
return 1 0 468
return 1 0 471
assign 1 0 474
assign 1 0 478
return 1 0 482
return 1 0 485
assign 1 0 488
assign 1 0 492
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1741139904: return bem_lfGetDirect_0();
case 2132306504: return bem_classNameGet_0();
case -1710524745: return bem_wsGet_0();
case -777557778: return bem_tabGetDirect_0();
case 1794518227: return bem_iteratorGet_0();
case -1434960598: return bem_serializeContents_0();
case 618467928: return bem_colonGet_0();
case -974542297: return bem_tabGet_0();
case -1665576026: return bem_sourceFileNameGet_0();
case 378509790: return bem_spaceGetDirect_0();
case 1782620959: return bem_echo_0();
case -1427827058: return bem_once_0();
case -1714811768: return bem_fieldIteratorGet_0();
case 455481848: return bem_print_0();
case -1209500027: return bem_unixNewlineGet_0();
case 253098500: return bem_emptyGetDirect_0();
case 1281105867: return bem_quoteGet_0();
case 2005192015: return bem_serializeToString_0();
case -664467345: return bem_create_0();
case -1050275987: return bem_default_0();
case -655092564: return bem_serializationIteratorGet_0();
case 1398381398: return bem_newlineGetDirect_0();
case -157733273: return bem_many_0();
case -1830560348: return bem_fieldNamesGet_0();
case 1631695584: return bem_crGet_0();
case -1947809963: return bem_dosNewlineGet_0();
case -310443758: return bem_crGetDirect_0();
case -1054400757: return bem_deserializeClassNameGet_0();
case -239590773: return bem_lineSplitterGet_0();
case -1119075387: return bem_lineSplitterGetDirect_0();
case 1667331006: return bem_toAny_0();
case 2019799807: return bem_colonGetDirect_0();
case 144506434: return bem_new_0();
case -907059395: return bem_dosNewlineGetDirect_0();
case -1924797849: return bem_quoteGetDirect_0();
case -1313867098: return bem_tagGet_0();
case -1400395933: return bem_newlineGet_0();
case -1736339295: return bem_emptyGet_0();
case -181500453: return bem_copy_0();
case 930639526: return bem_spaceGet_0();
case -564395883: return bem_unixNewlineGetDirect_0();
case 952056940: return bem_toString_0();
case -411967662: return bem_wsGetDirect_0();
case -1634068403: return bem_lfGet_0();
case -377355642: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1638871317: return bem_lfSet_1(bevd_0);
case 1138675988: return bem_lineSplitterSet_1(bevd_0);
case -585494508: return bem_copyTo_1(bevd_0);
case 210308063: return bem_spaceSetDirect_1(bevd_0);
case -655970733: return bem_wsSet_1(bevd_0);
case -636145854: return bem_anyEmpty_1(bevd_0);
case 904611201: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -2123337515: return bem_undef_1(bevd_0);
case 1391073335: return bem_tabSet_1(bevd_0);
case 1464315297: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1191814733: return bem_quoteSetDirect_1(bevd_0);
case -294825304: return bem_wsSetDirect_1(bevd_0);
case 193188036: return bem_quoteSet_1(bevd_0);
case 1198427025: return bem_notEquals_1(bevd_0);
case 1272963269: return bem_sameObject_1(bevd_0);
case 2069326800: return bem_otherType_1(bevd_0);
case 1003716077: return bem_def_1(bevd_0);
case 1769088803: return bem_unixNewlineSet_1(bevd_0);
case 1135973654: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1911701664: return bem_equals_1(bevd_0);
case 337234744: return bem_dosNewlineSetDirect_1(bevd_0);
case -459360005: return bem_otherClass_1(bevd_0);
case -819986655: return bem_newlineSet_1(bevd_0);
case 1682388013: return bem_newlineSetDirect_1(bevd_0);
case 241299765: return bem_sameType_1(bevd_0);
case 195733967: return bem_dosNewlineSet_1(bevd_0);
case 1532532742: return bem_undefined_1(bevd_0);
case -93369574: return bem_lfSetDirect_1(bevd_0);
case -26559400: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 269176765: return bem_unixNewlineSetDirect_1(bevd_0);
case -1053558612: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 56552993: return bem_colonSet_1(bevd_0);
case -1432196319: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1540890760: return bem_tabSetDirect_1(bevd_0);
case -645521747: return bem_emptySet_1(bevd_0);
case 2114364439: return bem_spaceSet_1(bevd_0);
case -74329310: return bem_lineSplitterSetDirect_1(bevd_0);
case -98791052: return bem_defined_1(bevd_0);
case 777753108: return bem_crSet_1(bevd_0);
case 1706275889: return bem_crSetDirect_1(bevd_0);
case 2102889872: return bem_sameClass_1(bevd_0);
case 1377625485: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1577308555: return bem_colonSetDirect_1(bevd_0);
case -1960215271: return bem_emptySetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1234965347: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -720811311: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 674286989: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 924235689: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1973929830: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -389946827: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 725698023: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 2041425680: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1411035525: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -261981048: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TextStrings();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
}
