namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_7_TextStrings : BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
static BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_5 = {};
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_7_TextStrings_bels_6 = {};
private static BEC_2_4_6_TextString bece_BEC_2_4_7_TextStrings_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_4_7_TextStrings_bels_6, 0));
public static new BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static new BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevp_space = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevp_quote = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_tab = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_tmpany_phold);
bevp_dosNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(13));
bevp_cr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_tmpany_phold);
bevp_lf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_colon = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_4));
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = beva_splits.bemd_0(700847419);
bevt_1_tmpany_phold = bevl_i.bemd_0(-1398488449);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1011951799);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1188 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_tmpany_phold;
} /* Line: 1189 */
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_tmpany_phold = bevl_i.bemd_0(-136681184);
bevl_buf.bem_addValue_1(bevt_3_tmpany_phold);
while (true)
 /* Line: 1193 */ {
bevt_4_tmpany_phold = bevl_i.bemd_0(-1398488449);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 1193 */ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_tmpany_phold = bevl_i.bemd_0(-136681184);
bevl_buf.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 1195 */
 else  /* Line: 1193 */ {
break;
} /* Line: 1193 */
} /* Line: 1193 */
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_beg = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
 /* Line: 1205 */ {
bevt_0_tmpany_phold = bevl_mb.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1205 */ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_tmpany_phold = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1207 */ {
if (bevl_foundChar.bevi_bool) /* Line: 1208 */ {
bevl_end.bevi_int++;
} /* Line: 1209 */
 else  /* Line: 1210 */ {
bevl_beg.bevi_int++;
} /* Line: 1211 */
} /* Line: 1208 */
 else  /* Line: 1213 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1215 */
} /* Line: 1207 */
 else  /* Line: 1205 */ {
break;
} /* Line: 1205 */
} /* Line: 1205 */
if (bevl_foundChar.bevi_bool) /* Line: 1218 */ {
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_tmpany_phold);
} /* Line: 1219 */
 else  /* Line: 1220 */ {
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_5));
} /* Line: 1221 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1227 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1227 */ {
if (beva_b == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1227 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1227 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1227 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1227 */ {
return null;
} /* Line: 1227 */
bevt_3_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_tmpany_phold = beva_a.bem_sizeGet_0();
bevt_5_tmpany_phold = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_min_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 1233 */ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1233 */ {
bevl_ai.bemd_1(-1180966276, bevl_av);
bevl_bi.bemd_1(-1180966276, bevl_bv);
bevt_7_tmpany_phold = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 1236 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_0;
bevt_8_tmpany_phold = beva_a.bem_substring_2(bevt_9_tmpany_phold, bevl_i);
return bevt_8_tmpany_phold;
} /* Line: 1237 */
bevl_i.bevi_int++;
} /* Line: 1233 */
 else  /* Line: 1233 */ {
break;
} /* Line: 1233 */
} /* Line: 1233 */
bevt_11_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_1;
bevt_10_tmpany_phold = beva_a.bem_substring_2(bevt_11_tmpany_phold, bevl_i);
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevt_0_tmpany_loop = beva_strs.bemd_0(700847419);
while (true)
 /* Line: 1244 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1398488449);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 1244 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-136681184);
bevt_2_tmpany_phold = bem_isEmpty_1(bevl_i);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1245 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 1246 */
} /* Line: 1245 */
 else  /* Line: 1244 */ {
break;
} /* Line: 1244 */
} /* Line: 1244 */
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1253 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1253 */ {
bevt_3_tmpany_phold = beva_value.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_2;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1253 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1253 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1253 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1253 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 1254 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1260 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_3;
bevt_2_tmpany_phold = beva_value.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1260 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1260 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1260 */
 else  /* Line: 1260 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1260 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 1261 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGetDirect_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGetDirect_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGetDirect_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGetDirect_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_6_TextString bem_crGetDirect_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGetDirect_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGetDirect_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGetDirect_0() {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() {
return bevp_ws;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGetDirect_0() {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1162, 1163, 1164, 1164, 1165, 1165, 1166, 1167, 1169, 1169, 1170, 1171, 1172, 1173, 1176, 1177, 1178, 1179, 1183, 1183, 1187, 1188, 1188, 1189, 1189, 1191, 1192, 1192, 1193, 1194, 1195, 1195, 1197, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1209, 1211, 1214, 1214, 1215, 1219, 1219, 1219, 1221, 1223, 1227, 1227, 0, 1227, 1227, 0, 0, 1227, 1228, 1228, 1228, 1228, 1229, 1230, 1231, 1232, 1233, 1233, 1233, 1234, 1235, 1236, 1237, 1237, 1237, 1233, 1240, 1240, 1240, 1244, 0, 1244, 1244, 1245, 1246, 1246, 1249, 1249, 1253, 1253, 0, 1253, 1253, 1253, 1253, 0, 0, 1254, 1254, 1256, 1256, 1260, 1260, 1260, 1260, 0, 0, 0, 1261, 1261, 1263, 1263, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 67, 68, 79, 80, 81, 83, 84, 86, 87, 88, 91, 93, 94, 95, 101, 115, 116, 117, 118, 121, 123, 124, 127, 130, 134, 135, 136, 144, 145, 146, 149, 151, 172, 177, 178, 181, 186, 187, 190, 194, 196, 197, 198, 199, 200, 201, 202, 203, 204, 207, 212, 213, 214, 215, 217, 218, 219, 221, 227, 228, 229, 238, 238, 241, 243, 244, 246, 247, 254, 255, 265, 270, 271, 274, 275, 276, 281, 282, 285, 289, 290, 292, 293, 302, 307, 308, 309, 311, 314, 318, 321, 322, 324, 325, 328, 331, 334, 338, 342, 345, 348, 352, 356, 359, 362, 366, 370, 373, 376, 380, 384, 387, 390, 394, 398, 401, 404, 408, 412, 415, 418, 422, 426, 429, 432, 436, 440, 443, 446, 450, 454, 457, 460, 464, 468, 471, 474, 478, 482, 485, 488, 492};
/* BEGIN LINEINFO 
assign 1 1162 45
new 0 1162 45
assign 1 1163 46
new 0 1163 46
assign 1 1164 47
new 0 1164 47
assign 1 1164 48
codeNew 1 1164 48
assign 1 1165 49
new 0 1165 49
assign 1 1165 50
codeNew 1 1165 50
assign 1 1166 51
new 0 1166 51
assign 1 1167 52
new 0 1167 52
assign 1 1169 53
new 0 1169 53
assign 1 1169 54
codeNew 1 1169 54
assign 1 1170 55
new 0 1170 55
assign 1 1171 56
new 0 1171 56
assign 1 1172 57
new 1 1172 57
assign 1 1173 58
new 0 1173 58
put 1 1176 59
put 1 1177 60
put 1 1178 61
put 1 1179 62
assign 1 1183 67
joinBuffer 2 1183 67
return 1 1183 68
assign 1 1187 79
iteratorGet 0 1187 79
assign 1 1188 80
hasNextGet 0 1188 80
assign 1 1188 81
not 0 1188 81
assign 1 1189 83
new 0 1189 83
return 1 1189 84
assign 1 1191 86
new 0 1191 86
assign 1 1192 87
nextGet 0 1192 87
addValue 1 1192 88
assign 1 1193 91
hasNextGet 0 1193 91
addValue 1 1194 93
assign 1 1195 94
nextGet 0 1195 94
addValue 1 1195 95
return 1 1197 101
assign 1 1201 115
new 0 1201 115
assign 1 1202 116
new 0 1202 116
assign 1 1203 117
new 0 1203 117
assign 1 1204 118
mbiterGet 0 1204 118
assign 1 1205 121
hasNextGet 0 1205 121
assign 1 1206 123
nextGet 0 1206 123
assign 1 1207 124
has 1 1207 124
incrementValue 0 1209 127
incrementValue 0 1211 130
assign 1 1214 134
new 0 1214 134
setValue 1 1214 135
assign 1 1215 136
new 0 1215 136
assign 1 1219 144
sizeGet 0 1219 144
assign 1 1219 145
subtract 1 1219 145
assign 1 1219 146
substring 2 1219 146
assign 1 1221 149
new 0 1221 149
return 1 1223 151
assign 1 1227 172
undef 1 1227 177
assign 1 0 178
assign 1 1227 181
undef 1 1227 186
assign 1 0 187
assign 1 0 190
return 1 1227 194
assign 1 1228 196
new 0 1228 196
assign 1 1228 197
sizeGet 0 1228 197
assign 1 1228 198
sizeGet 0 1228 198
assign 1 1228 199
min 2 1228 199
assign 1 1229 200
biterGet 0 1229 200
assign 1 1230 201
biterGet 0 1230 201
assign 1 1231 202
new 0 1231 202
assign 1 1232 203
new 0 1232 203
assign 1 1233 204
new 0 1233 204
assign 1 1233 207
lesser 1 1233 212
next 1 1234 213
next 1 1235 214
assign 1 1236 215
notEquals 1 1236 215
assign 1 1237 217
new 0 1237 217
assign 1 1237 218
substring 2 1237 218
return 1 1237 219
incrementValue 0 1233 221
assign 1 1240 227
new 0 1240 227
assign 1 1240 228
substring 2 1240 228
return 1 1240 229
assign 1 1244 238
iteratorGet 0 0 238
assign 1 1244 241
hasNextGet 0 1244 241
assign 1 1244 243
nextGet 0 1244 243
assign 1 1245 244
isEmpty 1 1245 244
assign 1 1246 246
new 0 1246 246
return 1 1246 247
assign 1 1249 254
new 0 1249 254
return 1 1249 255
assign 1 1253 265
undef 1 1253 270
assign 1 0 271
assign 1 1253 274
sizeGet 0 1253 274
assign 1 1253 275
new 0 1253 275
assign 1 1253 276
lesser 1 1253 281
assign 1 0 282
assign 1 0 285
assign 1 1254 289
new 0 1254 289
return 1 1254 290
assign 1 1256 292
new 0 1256 292
return 1 1256 293
assign 1 1260 302
def 1 1260 307
assign 1 1260 308
new 0 1260 308
assign 1 1260 309
notEquals 1 1260 309
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 1261 321
new 0 1261 321
return 1 1261 322
assign 1 1263 324
new 0 1263 324
return 1 1263 325
return 1 0 328
return 1 0 331
assign 1 0 334
assign 1 0 338
return 1 0 342
return 1 0 345
assign 1 0 348
assign 1 0 352
return 1 0 356
return 1 0 359
assign 1 0 362
assign 1 0 366
return 1 0 370
return 1 0 373
assign 1 0 376
assign 1 0 380
return 1 0 384
return 1 0 387
assign 1 0 390
assign 1 0 394
return 1 0 398
return 1 0 401
assign 1 0 404
assign 1 0 408
return 1 0 412
return 1 0 415
assign 1 0 418
assign 1 0 422
return 1 0 426
return 1 0 429
assign 1 0 432
assign 1 0 436
return 1 0 440
return 1 0 443
assign 1 0 446
assign 1 0 450
return 1 0 454
return 1 0 457
assign 1 0 460
assign 1 0 464
return 1 0 468
return 1 0 471
assign 1 0 474
assign 1 0 478
return 1 0 482
return 1 0 485
assign 1 0 488
assign 1 0 492
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2061644084: return bem_echo_0();
case -1516350551: return bem_unixNewlineGet_0();
case -575216772: return bem_hashGet_0();
case -1698239091: return bem_colonGetDirect_0();
case 1170104228: return bem_wsGet_0();
case 1743657368: return bem_once_0();
case 1578275626: return bem_dosNewlineGetDirect_0();
case -506426606: return bem_tabGetDirect_0();
case 700847419: return bem_iteratorGet_0();
case -2071582224: return bem_fieldNamesGet_0();
case 1649770762: return bem_serializeContents_0();
case -1460138897: return bem_print_0();
case -1381809993: return bem_deserializeClassNameGet_0();
case -1132183501: return bem_wsGetDirect_0();
case 1931581153: return bem_quoteGetDirect_0();
case -432100898: return bem_colonGet_0();
case -1477321659: return bem_create_0();
case -1523909235: return bem_dosNewlineGet_0();
case 278668694: return bem_quoteGet_0();
case -1673174214: return bem_lfGetDirect_0();
case 1546755899: return bem_newlineGetDirect_0();
case 1879848444: return bem_crGetDirect_0();
case -167133301: return bem_fieldIteratorGet_0();
case -1824151510: return bem_sourceFileNameGet_0();
case 228361794: return bem_emptyGetDirect_0();
case 375625109: return bem_copy_0();
case 1249544468: return bem_emptyGet_0();
case 1838557341: return bem_default_0();
case 686988927: return bem_spaceGetDirect_0();
case 1357107465: return bem_many_0();
case 1303816937: return bem_classNameGet_0();
case -1062508492: return bem_toAny_0();
case 885190018: return bem_serializationIteratorGet_0();
case 1554544180: return bem_newlineGet_0();
case 1443037619: return bem_new_0();
case 1111224780: return bem_tabGet_0();
case 641617863: return bem_serializeToString_0();
case 437012555: return bem_lfGet_0();
case 791316988: return bem_crGet_0();
case -954029510: return bem_tagGet_0();
case -446269953: return bem_lineSplitterGet_0();
case 1620631553: return bem_lineSplitterGetDirect_0();
case -1111980982: return bem_toString_0();
case 480345325: return bem_spaceGet_0();
case 855596723: return bem_unixNewlineGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1231442537: return bem_unixNewlineSet_1(bevd_0);
case -2012223833: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1471021973: return bem_quoteSetDirect_1(bevd_0);
case -1967453128: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case -158486422: return bem_undef_1(bevd_0);
case -1358252999: return bem_spaceSet_1(bevd_0);
case 1171201188: return bem_sameType_1(bevd_0);
case 829192566: return bem_otherClass_1(bevd_0);
case 912665444: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -124594925: return bem_equals_1(bevd_0);
case -1429972573: return bem_crSetDirect_1(bevd_0);
case -1107466744: return bem_lineSplitterSetDirect_1(bevd_0);
case -961773673: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1321180057: return bem_quoteSet_1(bevd_0);
case 1694716470: return bem_lineSplitterSet_1(bevd_0);
case -536053857: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -875483916: return bem_tabSetDirect_1(bevd_0);
case 1447134780: return bem_crSet_1(bevd_0);
case 1081114988: return bem_copyTo_1(bevd_0);
case -860634984: return bem_sameObject_1(bevd_0);
case -785361190: return bem_lfSet_1(bevd_0);
case 1416794794: return bem_newlineSet_1(bevd_0);
case -1332788028: return bem_wsSetDirect_1(bevd_0);
case -2126435545: return bem_colonSetDirect_1(bevd_0);
case 997965949: return bem_sameClass_1(bevd_0);
case 1650435450: return bem_undefined_1(bevd_0);
case -936015061: return bem_emptySet_1(bevd_0);
case 1434062431: return bem_defined_1(bevd_0);
case -240276616: return bem_def_1(bevd_0);
case 495212261: return bem_lfSetDirect_1(bevd_0);
case -547496057: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 612697427: return bem_dosNewlineSet_1(bevd_0);
case 1175965768: return bem_anyEmpty_1(bevd_0);
case 577322602: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -536284129: return bem_dosNewlineSetDirect_1(bevd_0);
case 563143589: return bem_unixNewlineSetDirect_1(bevd_0);
case 1754245001: return bem_spaceSetDirect_1(bevd_0);
case -658156965: return bem_wsSet_1(bevd_0);
case 189586042: return bem_newlineSetDirect_1(bevd_0);
case -2012960734: return bem_otherType_1(bevd_0);
case 992878354: return bem_emptySetDirect_1(bevd_0);
case 725362663: return bem_colonSet_1(bevd_0);
case 1843091865: return bem_notEquals_1(bevd_0);
case 581610393: return bem_tabSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -2039992278: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1365145554: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1783314567: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1346654676: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1394763364: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -749136313: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1347676005: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1957573480: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1148373967: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1030966708: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TextStrings();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
}
