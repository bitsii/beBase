namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_7_TextStrings : BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
static BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_5 = {};
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_7_TextStrings_bels_6 = {};
private static BEC_2_4_6_TextString bece_BEC_2_4_7_TextStrings_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_4_7_TextStrings_bels_6, 0));
public static new BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static new BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevp_space = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevp_quote = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_tab = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_tmpany_phold);
bevp_dosNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(13));
bevp_cr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_tmpany_phold);
bevp_lf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_colon = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_4));
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = beva_splits.bemd_0(1418348540);
bevt_1_tmpany_phold = bevl_i.bemd_0(969322174);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-557865609);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1160 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_tmpany_phold;
} /* Line: 1161 */
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_tmpany_phold = bevl_i.bemd_0(-84763849);
bevl_buf.bem_addValue_1(bevt_3_tmpany_phold);
while (true)
 /* Line: 1165 */ {
bevt_4_tmpany_phold = bevl_i.bemd_0(969322174);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 1165 */ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_tmpany_phold = bevl_i.bemd_0(-84763849);
bevl_buf.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 1167 */
 else  /* Line: 1165 */ {
break;
} /* Line: 1165 */
} /* Line: 1165 */
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_beg = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
 /* Line: 1177 */ {
bevt_0_tmpany_phold = bevl_mb.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1177 */ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_tmpany_phold = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1179 */ {
if (bevl_foundChar.bevi_bool) /* Line: 1180 */ {
bevl_end.bevi_int++;
} /* Line: 1181 */
 else  /* Line: 1182 */ {
bevl_beg.bevi_int++;
} /* Line: 1183 */
} /* Line: 1180 */
 else  /* Line: 1185 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1187 */
} /* Line: 1179 */
 else  /* Line: 1177 */ {
break;
} /* Line: 1177 */
} /* Line: 1177 */
if (bevl_foundChar.bevi_bool) /* Line: 1190 */ {
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_tmpany_phold);
} /* Line: 1191 */
 else  /* Line: 1192 */ {
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_5));
} /* Line: 1193 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1199 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1199 */ {
if (beva_b == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1199 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1199 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1199 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1199 */ {
return null;
} /* Line: 1199 */
bevt_3_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_tmpany_phold = beva_a.bem_sizeGet_0();
bevt_5_tmpany_phold = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_min_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 1205 */ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1205 */ {
bevl_ai.bemd_1(2098676641, bevl_av);
bevl_bi.bemd_1(2098676641, bevl_bv);
bevt_7_tmpany_phold = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 1208 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_0;
bevt_8_tmpany_phold = beva_a.bem_substring_2(bevt_9_tmpany_phold, bevl_i);
return bevt_8_tmpany_phold;
} /* Line: 1209 */
bevl_i.bevi_int++;
} /* Line: 1205 */
 else  /* Line: 1205 */ {
break;
} /* Line: 1205 */
} /* Line: 1205 */
bevt_11_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_1;
bevt_10_tmpany_phold = beva_a.bem_substring_2(bevt_11_tmpany_phold, bevl_i);
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevt_0_tmpany_loop = beva_strs.bemd_0(1418348540);
while (true)
 /* Line: 1216 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(969322174);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 1216 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-84763849);
bevt_2_tmpany_phold = bem_isEmpty_1(bevl_i);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1217 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 1218 */
} /* Line: 1217 */
 else  /* Line: 1216 */ {
break;
} /* Line: 1216 */
} /* Line: 1216 */
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1225 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1225 */ {
bevt_3_tmpany_phold = beva_value.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_2;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1225 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1225 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1225 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1225 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 1226 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1232 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_3;
bevt_2_tmpany_phold = beva_value.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1232 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1232 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1232 */
 else  /* Line: 1232 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1232 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 1233 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGetDirect_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGetDirect_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGetDirect_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGetDirect_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_6_TextString bem_crGetDirect_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGetDirect_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGetDirect_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGetDirect_0() {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() {
return bevp_ws;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGetDirect_0() {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1134, 1135, 1136, 1136, 1137, 1137, 1138, 1139, 1141, 1141, 1142, 1143, 1144, 1145, 1148, 1149, 1150, 1151, 1155, 1155, 1159, 1160, 1160, 1161, 1161, 1163, 1164, 1164, 1165, 1166, 1167, 1167, 1169, 1173, 1174, 1175, 1176, 1177, 1178, 1179, 1181, 1183, 1186, 1186, 1187, 1191, 1191, 1191, 1193, 1195, 1199, 1199, 0, 1199, 1199, 0, 0, 1199, 1200, 1200, 1200, 1200, 1201, 1202, 1203, 1204, 1205, 1205, 1205, 1206, 1207, 1208, 1209, 1209, 1209, 1205, 1212, 1212, 1212, 1216, 0, 1216, 1216, 1217, 1218, 1218, 1221, 1221, 1225, 1225, 0, 1225, 1225, 1225, 1225, 0, 0, 1226, 1226, 1228, 1228, 1232, 1232, 1232, 1232, 0, 0, 0, 1233, 1233, 1235, 1235, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 67, 68, 79, 80, 81, 83, 84, 86, 87, 88, 91, 93, 94, 95, 101, 115, 116, 117, 118, 121, 123, 124, 127, 130, 134, 135, 136, 144, 145, 146, 149, 151, 172, 177, 178, 181, 186, 187, 190, 194, 196, 197, 198, 199, 200, 201, 202, 203, 204, 207, 212, 213, 214, 215, 217, 218, 219, 221, 227, 228, 229, 238, 238, 241, 243, 244, 246, 247, 254, 255, 265, 270, 271, 274, 275, 276, 281, 282, 285, 289, 290, 292, 293, 302, 307, 308, 309, 311, 314, 318, 321, 322, 324, 325, 328, 331, 334, 338, 342, 345, 348, 352, 356, 359, 362, 366, 370, 373, 376, 380, 384, 387, 390, 394, 398, 401, 404, 408, 412, 415, 418, 422, 426, 429, 432, 436, 440, 443, 446, 450, 454, 457, 460, 464, 468, 471, 474, 478, 482, 485, 488, 492};
/* BEGIN LINEINFO 
assign 1 1134 45
new 0 1134 45
assign 1 1135 46
new 0 1135 46
assign 1 1136 47
new 0 1136 47
assign 1 1136 48
codeNew 1 1136 48
assign 1 1137 49
new 0 1137 49
assign 1 1137 50
codeNew 1 1137 50
assign 1 1138 51
new 0 1138 51
assign 1 1139 52
new 0 1139 52
assign 1 1141 53
new 0 1141 53
assign 1 1141 54
codeNew 1 1141 54
assign 1 1142 55
new 0 1142 55
assign 1 1143 56
new 0 1143 56
assign 1 1144 57
new 1 1144 57
assign 1 1145 58
new 0 1145 58
put 1 1148 59
put 1 1149 60
put 1 1150 61
put 1 1151 62
assign 1 1155 67
joinBuffer 2 1155 67
return 1 1155 68
assign 1 1159 79
iteratorGet 0 1159 79
assign 1 1160 80
hasNextGet 0 1160 80
assign 1 1160 81
not 0 1160 81
assign 1 1161 83
new 0 1161 83
return 1 1161 84
assign 1 1163 86
new 0 1163 86
assign 1 1164 87
nextGet 0 1164 87
addValue 1 1164 88
assign 1 1165 91
hasNextGet 0 1165 91
addValue 1 1166 93
assign 1 1167 94
nextGet 0 1167 94
addValue 1 1167 95
return 1 1169 101
assign 1 1173 115
new 0 1173 115
assign 1 1174 116
new 0 1174 116
assign 1 1175 117
new 0 1175 117
assign 1 1176 118
mbiterGet 0 1176 118
assign 1 1177 121
hasNextGet 0 1177 121
assign 1 1178 123
nextGet 0 1178 123
assign 1 1179 124
has 1 1179 124
incrementValue 0 1181 127
incrementValue 0 1183 130
assign 1 1186 134
new 0 1186 134
setValue 1 1186 135
assign 1 1187 136
new 0 1187 136
assign 1 1191 144
sizeGet 0 1191 144
assign 1 1191 145
subtract 1 1191 145
assign 1 1191 146
substring 2 1191 146
assign 1 1193 149
new 0 1193 149
return 1 1195 151
assign 1 1199 172
undef 1 1199 177
assign 1 0 178
assign 1 1199 181
undef 1 1199 186
assign 1 0 187
assign 1 0 190
return 1 1199 194
assign 1 1200 196
new 0 1200 196
assign 1 1200 197
sizeGet 0 1200 197
assign 1 1200 198
sizeGet 0 1200 198
assign 1 1200 199
min 2 1200 199
assign 1 1201 200
biterGet 0 1201 200
assign 1 1202 201
biterGet 0 1202 201
assign 1 1203 202
new 0 1203 202
assign 1 1204 203
new 0 1204 203
assign 1 1205 204
new 0 1205 204
assign 1 1205 207
lesser 1 1205 212
next 1 1206 213
next 1 1207 214
assign 1 1208 215
notEquals 1 1208 215
assign 1 1209 217
new 0 1209 217
assign 1 1209 218
substring 2 1209 218
return 1 1209 219
incrementValue 0 1205 221
assign 1 1212 227
new 0 1212 227
assign 1 1212 228
substring 2 1212 228
return 1 1212 229
assign 1 1216 238
iteratorGet 0 0 238
assign 1 1216 241
hasNextGet 0 1216 241
assign 1 1216 243
nextGet 0 1216 243
assign 1 1217 244
isEmpty 1 1217 244
assign 1 1218 246
new 0 1218 246
return 1 1218 247
assign 1 1221 254
new 0 1221 254
return 1 1221 255
assign 1 1225 265
undef 1 1225 270
assign 1 0 271
assign 1 1225 274
sizeGet 0 1225 274
assign 1 1225 275
new 0 1225 275
assign 1 1225 276
lesser 1 1225 281
assign 1 0 282
assign 1 0 285
assign 1 1226 289
new 0 1226 289
return 1 1226 290
assign 1 1228 292
new 0 1228 292
return 1 1228 293
assign 1 1232 302
def 1 1232 307
assign 1 1232 308
new 0 1232 308
assign 1 1232 309
notEquals 1 1232 309
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 1233 321
new 0 1233 321
return 1 1233 322
assign 1 1235 324
new 0 1235 324
return 1 1235 325
return 1 0 328
return 1 0 331
assign 1 0 334
assign 1 0 338
return 1 0 342
return 1 0 345
assign 1 0 348
assign 1 0 352
return 1 0 356
return 1 0 359
assign 1 0 362
assign 1 0 366
return 1 0 370
return 1 0 373
assign 1 0 376
assign 1 0 380
return 1 0 384
return 1 0 387
assign 1 0 390
assign 1 0 394
return 1 0 398
return 1 0 401
assign 1 0 404
assign 1 0 408
return 1 0 412
return 1 0 415
assign 1 0 418
assign 1 0 422
return 1 0 426
return 1 0 429
assign 1 0 432
assign 1 0 436
return 1 0 440
return 1 0 443
assign 1 0 446
assign 1 0 450
return 1 0 454
return 1 0 457
assign 1 0 460
assign 1 0 464
return 1 0 468
return 1 0 471
assign 1 0 474
assign 1 0 478
return 1 0 482
return 1 0 485
assign 1 0 488
assign 1 0 492
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 43475100: return bem_newlineGetDirect_0();
case -1297985879: return bem_fieldNamesGet_0();
case -2114319741: return bem_spaceGet_0();
case -1180513274: return bem_dosNewlineGet_0();
case -888502976: return bem_print_0();
case 1788005678: return bem_crGetDirect_0();
case -1580356870: return bem_emptyGetDirect_0();
case -302817860: return bem_deserializeClassNameGet_0();
case -718256436: return bem_colonGetDirect_0();
case 1196099876: return bem_echo_0();
case -698988474: return bem_unixNewlineGetDirect_0();
case -1222154604: return bem_tagGet_0();
case 1809402761: return bem_unixNewlineGet_0();
case 164278351: return bem_quoteGet_0();
case -494057832: return bem_serializationIteratorGet_0();
case -174025727: return bem_colonGet_0();
case 1797020795: return bem_toAny_0();
case -1426277956: return bem_tabGet_0();
case -1230714712: return bem_classNameGet_0();
case -1722474840: return bem_newlineGet_0();
case -755252415: return bem_lineSplitterGetDirect_0();
case 1989485633: return bem_many_0();
case -1193826881: return bem_dosNewlineGetDirect_0();
case -822740108: return bem_lfGetDirect_0();
case 2111069764: return bem_wsGet_0();
case 506547194: return bem_lineSplitterGet_0();
case -1813418276: return bem_quoteGetDirect_0();
case 673900210: return bem_lfGet_0();
case 908895620: return bem_tabGetDirect_0();
case -1916548323: return bem_once_0();
case -170941956: return bem_serializeToString_0();
case 1832806152: return bem_toString_0();
case -294806467: return bem_create_0();
case -671191297: return bem_serializeContents_0();
case 1701999037: return bem_wsGetDirect_0();
case -1925247459: return bem_sourceFileNameGet_0();
case -937358711: return bem_default_0();
case -1628841870: return bem_new_0();
case -1073128404: return bem_crGet_0();
case 449659944: return bem_spaceGetDirect_0();
case 1418348540: return bem_iteratorGet_0();
case -1342633655: return bem_hashGet_0();
case -242463884: return bem_fieldIteratorGet_0();
case 1947994673: return bem_emptyGet_0();
case 213564239: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 458472770: return bem_emptySet_1(bevd_0);
case -813955395: return bem_dosNewlineSetDirect_1(bevd_0);
case -118558475: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1843292557: return bem_anyEmpty_1(bevd_0);
case 1602348302: return bem_sameObject_1(bevd_0);
case -333291086: return bem_spaceSetDirect_1(bevd_0);
case 1212689313: return bem_lineSplitterSetDirect_1(bevd_0);
case -1370205922: return bem_quoteSetDirect_1(bevd_0);
case -1967471075: return bem_spaceSet_1(bevd_0);
case -1710832747: return bem_unixNewlineSet_1(bevd_0);
case -395616432: return bem_otherClass_1(bevd_0);
case 936942966: return bem_undefined_1(bevd_0);
case 346995129: return bem_def_1(bevd_0);
case -788622974: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1796596677: return bem_otherType_1(bevd_0);
case 110876432: return bem_quoteSet_1(bevd_0);
case 1442125915: return bem_colonSetDirect_1(bevd_0);
case -720923804: return bem_tabSet_1(bevd_0);
case 945449374: return bem_notEquals_1(bevd_0);
case -656675038: return bem_colonSet_1(bevd_0);
case 1998652512: return bem_crSet_1(bevd_0);
case -1103290658: return bem_crSetDirect_1(bevd_0);
case 542311397: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case -1682401829: return bem_tabSetDirect_1(bevd_0);
case 724334893: return bem_emptySetDirect_1(bevd_0);
case -2086196470: return bem_dosNewlineSet_1(bevd_0);
case -1100724407: return bem_lfSetDirect_1(bevd_0);
case 83181817: return bem_undef_1(bevd_0);
case 1495593147: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1475579076: return bem_wsSet_1(bevd_0);
case -353398981: return bem_newlineSet_1(bevd_0);
case -810647371: return bem_sameClass_1(bevd_0);
case -1425474393: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1712273053: return bem_lineSplitterSet_1(bevd_0);
case 640702813: return bem_wsSetDirect_1(bevd_0);
case -1811224480: return bem_sameType_1(bevd_0);
case 1049938912: return bem_lfSet_1(bevd_0);
case -746222178: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -2046043947: return bem_copyTo_1(bevd_0);
case 79810732: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 964340918: return bem_newlineSetDirect_1(bevd_0);
case 1350008829: return bem_unixNewlineSetDirect_1(bevd_0);
case -152296894: return bem_equals_1(bevd_0);
case 1345095935: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -174395426: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1224027174: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1117645207: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1434652185: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1383362808: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 2038467728: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 6185266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 846931715: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 34704188: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1515774718: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TextStrings();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
}
