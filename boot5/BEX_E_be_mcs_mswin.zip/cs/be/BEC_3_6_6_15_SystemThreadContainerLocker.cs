namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
static BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static new BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 829 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 831 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 834 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 840 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(1211387830, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 842 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 845 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 852 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(1600071540, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 854 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 857 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 864 */ {
bevl_r = bevp_container.bemd_0(-277747337);
bevp_lock.bem_unlock_0();
} /* Line: 866 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 869 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 876 */ {
bevl_r = bevp_container.bemd_1(973819151, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 878 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 881 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 888 */ {
bevl_r = bevp_container.bemd_1(973819151, beva_key);
bevp_container.bemd_1(-718237915, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 891 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 894 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 901 */ {
bevl_r = bevp_container.bemd_2(-1527845131, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 903 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 906 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 913 */ {
bevp_container.bemd_1(-683455065, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 915 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 918 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 924 */ {
bevl_r = bevp_container.bemd_1(-1227590421, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 926 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 929 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 936 */ {
bevp_container.bemd_1(-1227590421, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 938 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 941 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 947 */ {
bevl_r = bevp_container.bemd_2(-1690307693, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 949 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 952 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 959 */ {
bevp_container.bemd_2(-1690307693, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 961 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 964 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 970 */ {
bevl_rc = bevp_container.bemd_3(835830642, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 972 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 975 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 982 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(985396784);
bevp_lock.bem_unlock_0();
} /* Line: 984 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 987 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 994 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-1404098221, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 996 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 999 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1006 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(1211387830, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1007 */ {
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 1008 */
 else  /* Line: 1009 */ {
bevp_container.bemd_2(-1690307693, beva_key, beva_value);
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1011 */
bevp_lock.bem_unlock_0();
} /* Line: 1013 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1016 */
return bevl_didPut;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1023 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(1211387830, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1024 */ {
bevl_result = bevp_container.bemd_1(973819151, beva_key);
} /* Line: 1025 */
 else  /* Line: 1026 */ {
bevp_container.bemd_2(-1690307693, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1028 */
bevp_lock.bem_unlock_0();
} /* Line: 1030 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1033 */
return bevl_result;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1040 */ {
bevp_container.bemd_3(1221187057, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1042 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1045 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1051 */ {
bevl_r = bevp_container.bemd_1(-718237915, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1053 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1056 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1063 */ {
bevl_r = bevp_container.bemd_2(-821801818, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1065 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1068 */
return bevl_r;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1075 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(-1340561201);
bevp_lock.bem_unlock_0();
} /* Line: 1077 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1080 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1087 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(-227759616);
bevp_lock.bem_unlock_0();
} /* Line: 1089 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1092 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyContainer_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1099 */ {
bevl_r = bevp_container.bemd_0(-181500453);
bevp_lock.bem_unlock_0();
} /* Line: 1101 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1104 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1111 */ {
bevp_container.bemd_0(-1602712999);
bevp_lock.bem_unlock_0();
} /* Line: 1113 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1116 */
return this;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1122 */ {
bevp_container.bemd_0(639555649);
bevp_lock.bem_unlock_0();
} /* Line: 1124 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1127 */
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGetDirect_0() {
return bevp_container;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {825, 828, 830, 831, 833, 834, 839, 841, 842, 844, 845, 847, 851, 853, 854, 856, 857, 859, 863, 865, 866, 868, 869, 871, 875, 877, 878, 880, 881, 883, 887, 889, 890, 891, 893, 894, 896, 900, 902, 903, 905, 906, 908, 912, 914, 915, 917, 918, 923, 925, 926, 928, 929, 931, 935, 937, 938, 940, 941, 946, 948, 949, 951, 952, 954, 958, 960, 961, 963, 964, 969, 971, 972, 974, 975, 977, 981, 983, 984, 986, 987, 989, 993, 995, 996, 998, 999, 1001, 1005, 1007, 1008, 1010, 1011, 1013, 1015, 1016, 1018, 1022, 1024, 1025, 1027, 1028, 1030, 1032, 1033, 1035, 1039, 1041, 1042, 1044, 1045, 1050, 1052, 1053, 1055, 1056, 1058, 1062, 1064, 1065, 1067, 1068, 1070, 1074, 1076, 1077, 1079, 1080, 1082, 1086, 1088, 1089, 1091, 1092, 1094, 1098, 1100, 1101, 1103, 1104, 1106, 1110, 1112, 1113, 1115, 1116, 1121, 1123, 1124, 1126, 1127, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 24, 25, 29, 30, 37, 39, 40, 44, 45, 47, 52, 54, 55, 59, 60, 62, 67, 69, 70, 74, 75, 77, 82, 84, 85, 89, 90, 92, 97, 99, 100, 101, 105, 106, 108, 113, 115, 116, 120, 121, 123, 127, 129, 130, 134, 135, 142, 144, 145, 149, 150, 152, 156, 158, 159, 163, 164, 171, 173, 174, 178, 179, 181, 185, 187, 188, 192, 193, 200, 202, 203, 207, 208, 210, 215, 217, 218, 222, 223, 225, 230, 232, 233, 237, 238, 240, 246, 248, 250, 253, 254, 256, 260, 261, 263, 269, 271, 273, 276, 277, 279, 283, 284, 286, 290, 292, 293, 297, 298, 305, 307, 308, 312, 313, 315, 320, 322, 323, 327, 328, 330, 335, 337, 338, 342, 343, 345, 350, 352, 353, 357, 358, 360, 365, 367, 368, 372, 373, 375, 379, 381, 382, 386, 387, 393, 395, 396, 400, 401, 406, 409, 412, 416, 420, 423, 426, 430};
/* BEGIN LINEINFO 
assign 1 825 21
new 0 825 21
lock 0 828 22
assign 1 830 24
unlock 0 831 25
unlock 0 833 29
throw 1 834 30
lock 0 839 37
assign 1 841 39
has 1 841 39
unlock 0 842 40
unlock 0 844 44
throw 1 845 45
return 1 847 47
lock 0 851 52
assign 1 853 54
has 2 853 54
unlock 0 854 55
unlock 0 856 59
throw 1 857 60
return 1 859 62
lock 0 863 67
assign 1 865 69
get 0 865 69
unlock 0 866 70
unlock 0 868 74
throw 1 869 75
return 1 871 77
lock 0 875 82
assign 1 877 84
get 1 877 84
unlock 0 878 85
unlock 0 880 89
throw 1 881 90
return 1 883 92
lock 0 887 97
assign 1 889 99
get 1 889 99
delete 1 890 100
unlock 0 891 101
unlock 0 893 105
throw 1 894 106
return 1 896 108
lock 0 900 113
assign 1 902 115
get 2 902 115
unlock 0 903 116
unlock 0 905 120
throw 1 906 121
return 1 908 123
lock 0 912 127
addValue 1 914 129
unlock 0 915 130
unlock 0 917 134
throw 1 918 135
lock 0 923 142
assign 1 925 144
put 1 925 144
unlock 0 926 145
unlock 0 928 149
throw 1 929 150
return 1 931 152
lock 0 935 156
put 1 937 158
unlock 0 938 159
unlock 0 940 163
throw 1 941 164
lock 0 946 171
assign 1 948 173
put 2 948 173
unlock 0 949 174
unlock 0 951 178
throw 1 952 179
return 1 954 181
lock 0 958 185
put 2 960 187
unlock 0 961 188
unlock 0 963 192
throw 1 964 193
lock 0 969 200
assign 1 971 202
testAndPut 3 971 202
unlock 0 972 203
unlock 0 974 207
throw 1 975 208
return 1 977 210
lock 0 981 215
assign 1 983 217
getMap 0 983 217
unlock 0 984 218
unlock 0 986 222
throw 1 987 223
return 1 989 225
lock 0 993 230
assign 1 995 232
getMap 1 995 232
unlock 0 996 233
unlock 0 998 237
throw 1 999 238
return 1 1001 240
lock 0 1005 246
assign 1 1007 248
has 1 1007 248
assign 1 1008 250
new 0 1008 250
put 2 1010 253
assign 1 1011 254
new 0 1011 254
unlock 0 1013 256
unlock 0 1015 260
throw 1 1016 261
return 1 1018 263
lock 0 1022 269
assign 1 1024 271
has 1 1024 271
assign 1 1025 273
get 1 1025 273
put 2 1027 276
assign 1 1028 277
unlock 0 1030 279
unlock 0 1032 283
throw 1 1033 284
return 1 1035 286
lock 0 1039 290
put 3 1041 292
unlock 0 1042 293
unlock 0 1044 297
throw 1 1045 298
lock 0 1050 305
assign 1 1052 307
delete 1 1052 307
unlock 0 1053 308
unlock 0 1055 312
throw 1 1056 313
return 1 1058 315
lock 0 1062 320
assign 1 1064 322
delete 2 1064 322
unlock 0 1065 323
unlock 0 1067 327
throw 1 1068 328
return 1 1070 330
lock 0 1074 335
assign 1 1076 337
sizeGet 0 1076 337
unlock 0 1077 338
unlock 0 1079 342
throw 1 1080 343
return 1 1082 345
lock 0 1086 350
assign 1 1088 352
isEmptyGet 0 1088 352
unlock 0 1089 353
unlock 0 1091 357
throw 1 1092 358
return 1 1094 360
lock 0 1098 365
assign 1 1100 367
copy 0 1100 367
unlock 0 1101 368
unlock 0 1103 372
throw 1 1104 373
return 1 1106 375
lock 0 1110 379
clear 0 1112 381
unlock 0 1113 382
unlock 0 1115 386
throw 1 1116 387
lock 0 1121 393
close 0 1123 395
unlock 0 1124 396
unlock 0 1126 400
throw 1 1127 401
return 1 0 406
return 1 0 409
assign 1 0 412
assign 1 0 416
return 1 0 420
return 1 0 423
assign 1 0 426
assign 1 0 430
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 952056940: return bem_toString_0();
case -181500453: return bem_copy_0();
case 1327388078: return bem_containerGetDirect_0();
case -664467345: return bem_create_0();
case 1782620959: return bem_echo_0();
case -1602712999: return bem_clear_0();
case -277747337: return bem_get_0();
case -1714811768: return bem_fieldIteratorGet_0();
case -655092564: return bem_serializationIteratorGet_0();
case -1665576026: return bem_sourceFileNameGet_0();
case -157733273: return bem_many_0();
case 678691709: return bem_copyContainer_0();
case 480523705: return bem_lockGet_0();
case -1830560348: return bem_fieldNamesGet_0();
case -1054400757: return bem_deserializeClassNameGet_0();
case 144506434: return bem_new_0();
case 2005192015: return bem_serializeToString_0();
case -1434960598: return bem_serializeContents_0();
case -1427827058: return bem_once_0();
case 945403285: return bem_containerGet_0();
case -1340561201: return bem_sizeGet_0();
case 1794518227: return bem_iteratorGet_0();
case 2132306504: return bem_classNameGet_0();
case -227759616: return bem_isEmptyGet_0();
case -377355642: return bem_hashGet_0();
case 1667331006: return bem_toAny_0();
case 985396784: return bem_getMap_0();
case 639555649: return bem_close_0();
case 455481848: return bem_print_0();
case -94235342: return bem_lockGetDirect_0();
case -1313867098: return bem_tagGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -585494508: return bem_copyTo_1(bevd_0);
case -718237915: return bem_delete_1(bevd_0);
case -2123337515: return bem_undef_1(bevd_0);
case 1046739569: return bem_new_1(bevd_0);
case -1404098221: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -1681815902: return bem_lockSetDirect_1(bevd_0);
case 1198427025: return bem_notEquals_1(bevd_0);
case 1272963269: return bem_sameObject_1(bevd_0);
case 2069326800: return bem_otherType_1(bevd_0);
case 1003716077: return bem_def_1(bevd_0);
case -1683530853: return bem_lockSet_1(bevd_0);
case 1135973654: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1911701664: return bem_equals_1(bevd_0);
case -1227590421: return bem_put_1(bevd_0);
case -459360005: return bem_otherClass_1(bevd_0);
case 241299765: return bem_sameType_1(bevd_0);
case -490352436: return bem_containerSet_1(bevd_0);
case 1532532742: return bem_undefined_1(bevd_0);
case -26559400: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1432196319: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2092373550: return bem_getAndClear_1(bevd_0);
case 1501191023: return bem_containerSetDirect_1(bevd_0);
case -98791052: return bem_defined_1(bevd_0);
case 1211387830: return bem_has_1(bevd_0);
case -683455065: return bem_addValue_1(bevd_0);
case 2102889872: return bem_sameClass_1(bevd_0);
case 1377625485: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 973819151: return bem_get_1(bevd_0);
case 721314093: return bem_putReturn_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -338310784: return bem_putReturn_2(bevd_0, bevd_1);
case -1234965347: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1600071540: return bem_has_2(bevd_0, bevd_1);
case -1527845131: return bem_get_2(bevd_0, bevd_1);
case 2041425680: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -389946827: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -821801818: return bem_delete_2(bevd_0, bevd_1);
case -720811311: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1987667091: return bem_putIfAbsent_2(bevd_0, bevd_1);
case 1411035525: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1690307693: return bem_put_2(bevd_0, bevd_1);
case 1973929830: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 674286989: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1388951571: return bem_getOrPut_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1221187057: return bem_put_3(bevd_0, bevd_1, bevd_2);
case 835830642: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
}
