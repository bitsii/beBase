namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
static BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static new BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 882 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 884 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 887 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 893 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(1258464331, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 895 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 898 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 905 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(-463283467, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 907 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 910 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 917 */ {
bevl_r = bevp_container.bemd_0(-1392168040);
bevp_lock.bem_unlock_0();
} /* Line: 919 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 922 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 929 */ {
bevl_r = bevp_container.bemd_1(439602846, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 931 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 934 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 941 */ {
bevl_r = bevp_container.bemd_1(439602846, beva_key);
bevp_container.bemd_1(-10869515, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 944 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 947 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 954 */ {
bevl_r = bevp_container.bemd_2(-2105818970, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 956 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 959 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 966 */ {
bevp_container.bemd_1(-1940917614, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 968 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 971 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 977 */ {
bevl_r = bevp_container.bemd_1(1698158300, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 979 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 982 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 989 */ {
bevp_container.bemd_1(1698158300, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 991 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 994 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1000 */ {
bevl_r = bevp_container.bemd_2(-845452519, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1002 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1005 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1012 */ {
bevp_container.bemd_2(-845452519, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1014 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1017 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1023 */ {
bevl_rc = bevp_container.bemd_3(841458682, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1025 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1028 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getSet_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1035 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(1020313876);
bevp_lock.bem_unlock_0();
} /* Line: 1037 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1040 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1047 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(1646283291);
bevp_lock.bem_unlock_0();
} /* Line: 1049 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1052 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1059 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-1784728675, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 1061 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1064 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1071 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(1258464331, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1072 */ {
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 1073 */
 else  /* Line: 1074 */ {
bevp_container.bemd_2(-845452519, beva_key, beva_value);
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1076 */
bevp_lock.bem_unlock_0();
} /* Line: 1078 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1081 */
return bevl_didPut;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1088 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(1258464331, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1089 */ {
bevl_result = bevp_container.bemd_1(439602846, beva_key);
} /* Line: 1090 */
 else  /* Line: 1091 */ {
bevp_container.bemd_2(-845452519, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1093 */
bevp_lock.bem_unlock_0();
} /* Line: 1095 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1098 */
return bevl_result;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1105 */ {
bevp_container.bemd_3(-1804191863, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1107 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1110 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1116 */ {
bevl_r = bevp_container.bemd_1(-10869515, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1118 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1121 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1128 */ {
bevl_r = bevp_container.bemd_2(782809279, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1130 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1133 */
return bevl_r;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1140 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(1840593132);
bevp_lock.bem_unlock_0();
} /* Line: 1142 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1145 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1152 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(1472054563);
bevp_lock.bem_unlock_0();
} /* Line: 1154 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1157 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyContainer_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1164 */ {
bevl_r = bevp_container.bemd_0(-1572010998);
bevp_lock.bem_unlock_0();
} /* Line: 1166 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1169 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1176 */ {
bevp_container.bemd_0(-1271382771);
bevp_lock.bem_unlock_0();
} /* Line: 1178 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1181 */
return this;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1187 */ {
bevp_container.bemd_0(-1985663275);
bevp_lock.bem_unlock_0();
} /* Line: 1189 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1192 */
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGetDirect_0() {
return bevp_container;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {878, 881, 883, 884, 886, 887, 892, 894, 895, 897, 898, 900, 904, 906, 907, 909, 910, 912, 916, 918, 919, 921, 922, 924, 928, 930, 931, 933, 934, 936, 940, 942, 943, 944, 946, 947, 949, 953, 955, 956, 958, 959, 961, 965, 967, 968, 970, 971, 976, 978, 979, 981, 982, 984, 988, 990, 991, 993, 994, 999, 1001, 1002, 1004, 1005, 1007, 1011, 1013, 1014, 1016, 1017, 1022, 1024, 1025, 1027, 1028, 1030, 1034, 1036, 1037, 1039, 1040, 1042, 1046, 1048, 1049, 1051, 1052, 1054, 1058, 1060, 1061, 1063, 1064, 1066, 1070, 1072, 1073, 1075, 1076, 1078, 1080, 1081, 1083, 1087, 1089, 1090, 1092, 1093, 1095, 1097, 1098, 1100, 1104, 1106, 1107, 1109, 1110, 1115, 1117, 1118, 1120, 1121, 1123, 1127, 1129, 1130, 1132, 1133, 1135, 1139, 1141, 1142, 1144, 1145, 1147, 1151, 1153, 1154, 1156, 1157, 1159, 1163, 1165, 1166, 1168, 1169, 1171, 1175, 1177, 1178, 1180, 1181, 1186, 1188, 1189, 1191, 1192, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 24, 25, 29, 30, 37, 39, 40, 44, 45, 47, 52, 54, 55, 59, 60, 62, 67, 69, 70, 74, 75, 77, 82, 84, 85, 89, 90, 92, 97, 99, 100, 101, 105, 106, 108, 113, 115, 116, 120, 121, 123, 127, 129, 130, 134, 135, 142, 144, 145, 149, 150, 152, 156, 158, 159, 163, 164, 171, 173, 174, 178, 179, 181, 185, 187, 188, 192, 193, 200, 202, 203, 207, 208, 210, 215, 217, 218, 222, 223, 225, 230, 232, 233, 237, 238, 240, 245, 247, 248, 252, 253, 255, 261, 263, 265, 268, 269, 271, 275, 276, 278, 284, 286, 288, 291, 292, 294, 298, 299, 301, 305, 307, 308, 312, 313, 320, 322, 323, 327, 328, 330, 335, 337, 338, 342, 343, 345, 350, 352, 353, 357, 358, 360, 365, 367, 368, 372, 373, 375, 380, 382, 383, 387, 388, 390, 394, 396, 397, 401, 402, 408, 410, 411, 415, 416, 421, 424, 427, 431, 435, 438, 441, 445};
/* BEGIN LINEINFO 
assign 1 878 21
new 0 878 21
lock 0 881 22
assign 1 883 24
unlock 0 884 25
unlock 0 886 29
throw 1 887 30
lock 0 892 37
assign 1 894 39
has 1 894 39
unlock 0 895 40
unlock 0 897 44
throw 1 898 45
return 1 900 47
lock 0 904 52
assign 1 906 54
has 2 906 54
unlock 0 907 55
unlock 0 909 59
throw 1 910 60
return 1 912 62
lock 0 916 67
assign 1 918 69
get 0 918 69
unlock 0 919 70
unlock 0 921 74
throw 1 922 75
return 1 924 77
lock 0 928 82
assign 1 930 84
get 1 930 84
unlock 0 931 85
unlock 0 933 89
throw 1 934 90
return 1 936 92
lock 0 940 97
assign 1 942 99
get 1 942 99
delete 1 943 100
unlock 0 944 101
unlock 0 946 105
throw 1 947 106
return 1 949 108
lock 0 953 113
assign 1 955 115
get 2 955 115
unlock 0 956 116
unlock 0 958 120
throw 1 959 121
return 1 961 123
lock 0 965 127
addValue 1 967 129
unlock 0 968 130
unlock 0 970 134
throw 1 971 135
lock 0 976 142
assign 1 978 144
put 1 978 144
unlock 0 979 145
unlock 0 981 149
throw 1 982 150
return 1 984 152
lock 0 988 156
put 1 990 158
unlock 0 991 159
unlock 0 993 163
throw 1 994 164
lock 0 999 171
assign 1 1001 173
put 2 1001 173
unlock 0 1002 174
unlock 0 1004 178
throw 1 1005 179
return 1 1007 181
lock 0 1011 185
put 2 1013 187
unlock 0 1014 188
unlock 0 1016 192
throw 1 1017 193
lock 0 1022 200
assign 1 1024 202
testAndPut 3 1024 202
unlock 0 1025 203
unlock 0 1027 207
throw 1 1028 208
return 1 1030 210
lock 0 1034 215
assign 1 1036 217
getSet 0 1036 217
unlock 0 1037 218
unlock 0 1039 222
throw 1 1040 223
return 1 1042 225
lock 0 1046 230
assign 1 1048 232
getMap 0 1048 232
unlock 0 1049 233
unlock 0 1051 237
throw 1 1052 238
return 1 1054 240
lock 0 1058 245
assign 1 1060 247
getMap 1 1060 247
unlock 0 1061 248
unlock 0 1063 252
throw 1 1064 253
return 1 1066 255
lock 0 1070 261
assign 1 1072 263
has 1 1072 263
assign 1 1073 265
new 0 1073 265
put 2 1075 268
assign 1 1076 269
new 0 1076 269
unlock 0 1078 271
unlock 0 1080 275
throw 1 1081 276
return 1 1083 278
lock 0 1087 284
assign 1 1089 286
has 1 1089 286
assign 1 1090 288
get 1 1090 288
put 2 1092 291
assign 1 1093 292
unlock 0 1095 294
unlock 0 1097 298
throw 1 1098 299
return 1 1100 301
lock 0 1104 305
put 3 1106 307
unlock 0 1107 308
unlock 0 1109 312
throw 1 1110 313
lock 0 1115 320
assign 1 1117 322
delete 1 1117 322
unlock 0 1118 323
unlock 0 1120 327
throw 1 1121 328
return 1 1123 330
lock 0 1127 335
assign 1 1129 337
delete 2 1129 337
unlock 0 1130 338
unlock 0 1132 342
throw 1 1133 343
return 1 1135 345
lock 0 1139 350
assign 1 1141 352
sizeGet 0 1141 352
unlock 0 1142 353
unlock 0 1144 357
throw 1 1145 358
return 1 1147 360
lock 0 1151 365
assign 1 1153 367
isEmptyGet 0 1153 367
unlock 0 1154 368
unlock 0 1156 372
throw 1 1157 373
return 1 1159 375
lock 0 1163 380
assign 1 1165 382
copy 0 1165 382
unlock 0 1166 383
unlock 0 1168 387
throw 1 1169 388
return 1 1171 390
lock 0 1175 394
clear 0 1177 396
unlock 0 1178 397
unlock 0 1180 401
throw 1 1181 402
lock 0 1186 408
close 0 1188 410
unlock 0 1189 411
unlock 0 1191 415
throw 1 1192 416
return 1 0 421
return 1 0 424
assign 1 0 427
assign 1 0 431
return 1 0 435
return 1 0 438
assign 1 0 441
assign 1 0 445
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1655660203: return bem_hashGet_0();
case 702246847: return bem_print_0();
case -1572010998: return bem_copy_0();
case -1007878556: return bem_many_0();
case 1646283291: return bem_getMap_0();
case 1840593132: return bem_sizeGet_0();
case -1271382771: return bem_clear_0();
case -106257945: return bem_fieldNamesGet_0();
case 256957523: return bem_copyContainer_0();
case -364249863: return bem_serializeToString_0();
case -1577817259: return bem_echo_0();
case -488190164: return bem_lockGet_0();
case 1020313876: return bem_getSet_0();
case 1550760607: return bem_fieldIteratorGet_0();
case 812685421: return bem_iteratorGet_0();
case 620570394: return bem_lockGetDirect_0();
case 605655591: return bem_sourceFileNameGet_0();
case 1966713191: return bem_deserializeClassNameGet_0();
case -927090833: return bem_new_0();
case 1422114133: return bem_containerGet_0();
case 1581692921: return bem_toAny_0();
case -1985663275: return bem_close_0();
case -1353172126: return bem_toString_0();
case -500248069: return bem_serializationIteratorGet_0();
case 1550334178: return bem_containerGetDirect_0();
case -1907635971: return bem_tagGet_0();
case -65082849: return bem_once_0();
case -1392168040: return bem_get_0();
case 1267812147: return bem_classNameGet_0();
case 1472054563: return bem_isEmptyGet_0();
case -1000018882: return bem_create_0();
case 1530555194: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1710098281: return bem_getAndClear_1(bevd_0);
case 73582546: return bem_lockSetDirect_1(bevd_0);
case -10869515: return bem_delete_1(bevd_0);
case 1953776597: return bem_sameType_1(bevd_0);
case 1698158300: return bem_put_1(bevd_0);
case 1062821348: return bem_lockSet_1(bevd_0);
case -58459221: return bem_sameClass_1(bevd_0);
case 805309200: return bem_putReturn_1(bevd_0);
case -1784728675: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -1556952447: return bem_defined_1(bevd_0);
case -1471457238: return bem_sameObject_1(bevd_0);
case -1940917614: return bem_addValue_1(bevd_0);
case 140166424: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1244819809: return bem_undefined_1(bevd_0);
case -886218051: return bem_equals_1(bevd_0);
case 1673385175: return bem_notEquals_1(bevd_0);
case 297381803: return bem_def_1(bevd_0);
case -227529285: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 150021405: return bem_otherClass_1(bevd_0);
case -481756547: return bem_undef_1(bevd_0);
case -1862075337: return bem_copyTo_1(bevd_0);
case 439602846: return bem_get_1(bevd_0);
case 2141774895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1416010056: return bem_containerSetDirect_1(bevd_0);
case 1258464331: return bem_has_1(bevd_0);
case -759946269: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 726015407: return bem_otherType_1(bevd_0);
case -380623615: return bem_new_1(bevd_0);
case 391005151: return bem_containerSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -2105818970: return bem_get_2(bevd_0, bevd_1);
case 1970963739: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1073755683: return bem_putIfAbsent_2(bevd_0, bevd_1);
case 12076877: return bem_putReturn_2(bevd_0, bevd_1);
case -967702518: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -845452519: return bem_put_2(bevd_0, bevd_1);
case 782809279: return bem_delete_2(bevd_0, bevd_1);
case -427898914: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 414161005: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -157052200: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -845056962: return bem_getOrPut_2(bevd_0, bevd_1);
case -463283467: return bem_has_2(bevd_0, bevd_1);
case -1722905349: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 611344245: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1804191863: return bem_put_3(bevd_0, bevd_1, bevd_2);
case 841458682: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
}
