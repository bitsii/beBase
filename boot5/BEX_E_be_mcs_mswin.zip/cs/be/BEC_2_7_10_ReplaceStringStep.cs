namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_7_10_ReplaceStringStep : BEC_2_6_6_SystemObject {
public BEC_2_7_10_ReplaceStringStep() { }
static BEC_2_7_10_ReplaceStringStep() { }
private static byte[] becc_BEC_2_7_10_ReplaceStringStep_clname = {0x52,0x65,0x70,0x6C,0x61,0x63,0x65,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x53,0x74,0x65,0x70};
private static byte[] becc_BEC_2_7_10_ReplaceStringStep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_2_7_10_ReplaceStringStep bece_BEC_2_7_10_ReplaceStringStep_bevs_inst;

public static new BET_2_7_10_ReplaceStringStep bece_BEC_2_7_10_ReplaceStringStep_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public virtual BEC_2_7_10_ReplaceStringStep bem_new_1(BEC_2_4_6_TextString beva__str) {
bevp_str = beva__str;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_handle_1(BEC_2_6_6_SystemObject beva_r) {
return bevp_str;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_strGet_0() {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_strGetDirect_0() {
return bevp_str;
} /*method end*/
public virtual BEC_2_7_10_ReplaceStringStep bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_7_10_ReplaceStringStep bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {40, 46, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 18, 21, 24, 27, 31};
/* BEGIN LINEINFO 
assign 1 40 14
return 1 46 18
return 1 0 21
return 1 0 24
assign 1 0 27
assign 1 0 31
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1201098152: return bem_toAny_0();
case -1931415843: return bem_serializeToString_0();
case 1224800076: return bem_once_0();
case -1350845886: return bem_new_0();
case 2134647390: return bem_toString_0();
case 1759428119: return bem_hashGet_0();
case 1380348244: return bem_strGetDirect_0();
case 1686342789: return bem_print_0();
case -768171916: return bem_tagGet_0();
case -2038383545: return bem_strGet_0();
case 2089449732: return bem_fieldIteratorGet_0();
case -863007361: return bem_copy_0();
case 1314392911: return bem_many_0();
case 1990705765: return bem_serializeContents_0();
case -1294759593: return bem_serializationIteratorGet_0();
case -765261987: return bem_echo_0();
case 1226113552: return bem_create_0();
case -596782621: return bem_iteratorGet_0();
case 1522098204: return bem_sourceFileNameGet_0();
case 816581925: return bem_classNameGet_0();
case 1468891202: return bem_deserializeClassNameGet_0();
case -1399602189: return bem_fieldNamesGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 543904361: return bem_strSetDirect_1(bevd_0);
case 354319884: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1036408998: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1658273096: return bem_otherType_1(bevd_0);
case 1904381430: return bem_notEquals_1(bevd_0);
case -524550398: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1211406823: return bem_sameObject_1(bevd_0);
case -2032446076: return bem_defined_1(bevd_0);
case 392733598: return bem_handle_1(bevd_0);
case -54010859: return bem_equals_1(bevd_0);
case 26178473: return bem_undefined_1(bevd_0);
case -1447916414: return bem_otherClass_1(bevd_0);
case 1814770497: return bem_def_1(bevd_0);
case -2126702146: return bem_sameType_1(bevd_0);
case -1241115003: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2134954924: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2003297856: return bem_undef_1(bevd_0);
case 1461222960: return bem_strSet_1(bevd_0);
case 635699530: return bem_copyTo_1(bevd_0);
case 1286442708: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1439296944: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 353482770: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2000867040: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1285224299: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1661650237: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 309149914: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1467313976: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_7_10_ReplaceStringStep_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_2_7_10_ReplaceStringStep_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_7_10_ReplaceStringStep();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_7_10_ReplaceStringStep.bece_BEC_2_7_10_ReplaceStringStep_bevs_inst = (BEC_2_7_10_ReplaceStringStep) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_7_10_ReplaceStringStep.bece_BEC_2_7_10_ReplaceStringStep_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_7_10_ReplaceStringStep.bece_BEC_2_7_10_ReplaceStringStep_bevs_type;
}
}
}
