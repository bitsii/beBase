namespace be {

using System;
using System.Diagnostics;
/* IO:File: source/extended/Command.be */
public sealed class BEC_2_6_7_SystemCommand : BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemCommand() { }
static BEC_2_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_BEC_2_6_7_SystemCommand_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_2_6_7_SystemCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_0 = {};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_1 = {0x20};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_2 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_7_SystemCommand_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_7_SystemCommand_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemCommand_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemCommand_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_3 = {};
public static new BEC_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_inst;

public static new BET_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_2_9_4_ContainerList bevp_commands;
public BEC_3_2_4_6_IOFileReader bevp_outputReader;
public BEC_2_6_7_SystemCommand bem_new_1(BEC_2_4_6_TextString beva__command) {
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_listNew_1(BEC_2_9_4_ContainerList beva__commands) {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevp_commands = beva__commands;
bevp_command = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_6_7_SystemCommand_bels_0));
bevt_0_tmpany_loop = bevp_commands.bem_iteratorGet_0();
while (true)
 /* Line: 47 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-142543557);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 47 */ {
bevl_c = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-515235618);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_notEmpty_1(bevp_command);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_7_SystemCommand_bels_1));
bevp_command.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 49 */
bevp_command.bem_addValue_1(bevl_c);
} /* Line: 51 */
 else  /* Line: 47 */ {
break;
} /* Line: 47 */
} /* Line: 47 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_1(BEC_2_4_6_TextString beva__command) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bem_new_1(beva__command);
bevt_0_tmpany_phold = bem_run_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_0() {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevl_sp = null;
BEC_2_4_6_TextString bevl_cmdRun = null;
BEC_2_4_6_TextString bevl_cmdArgs = null;
BEC_2_4_3_MathInt bevl_cl = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_cmdi = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
 /* Line: 63 */ {
bevt_0_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_0;
bevl_sp = bevp_command.bem_find_1(bevt_0_tmpany_phold);
if (bevl_sp == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 65 */ {
bevt_2_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_1;
bevl_cmdRun = bevp_command.bem_substring_2(bevt_2_tmpany_phold, bevl_sp);
bevt_4_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_2;
bevt_3_tmpany_phold = bevl_sp.bem_add_1(bevt_4_tmpany_phold);
bevl_cmdArgs = bevp_command.bem_substring_1(bevt_3_tmpany_phold);
} /* Line: 67 */
 else  /* Line: 68 */ {
bevl_cmdRun = bevp_command;
bevl_cmdArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_6_7_SystemCommand_bels_3));
} /* Line: 70 */

          bevi_p = new Process();
          bevi_p.StartInfo.FileName = bevl_cmdRun.bems_toCsString();
          bevi_p.StartInfo.Arguments = bevl_cmdArgs.bems_toCsString();
          bevi_p.StartInfo.CreateNoWindow = true;
          bevi_p.StartInfo.UseShellExecute = false;
          bevi_p.StartInfo.RedirectStandardOutput = true;   
          //bevi_p.StartInfo.WorkingDirectory = strWorkingDirectory;
          bevi_p.Start();
          //bevi_p.StandardOutput.ReadToEnd();
          //bevi_p.WaitForExit();
          } /* Line: 74 */
if (bevp_commands == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 90 */ {
bevl_cl = bevp_commands.bem_sizeGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 97 */ {
if (bevl_i.bevi_int < bevl_cl.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevl_cmdi = (BEC_2_4_6_TextString) bevp_commands.bem_get_1(bevl_i);
bevl_i.bevi_int++;
} /* Line: 97 */
 else  /* Line: 97 */ {
break;
} /* Line: 97 */
} /* Line: 97 */
} /* Line: 106 */
 else  /* Line: 112 */ {
} /* Line: 114 */
return bevl_res;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_open_0() {
bem_run_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 133 */ {
return bevp_outputReader;
} /* Line: 134 */
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) (new BEC_3_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.StandardOutput.BaseStream;
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_closeOutput_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 152 */ {
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 155 */
} /* Line: 153 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 157 */
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_close_0() {
bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_outputContentGet_0() {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_ee = null;
BEC_3_2_4_6_IOFileReader bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemCommand bevt_1_tmpany_phold = null;
try  /* Line: 176 */ {
bevt_1_tmpany_phold = (BEC_2_6_7_SystemCommand) bem_open_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_outputGet_0();
bevl_res = bevt_0_tmpany_phold.bem_readString_0();
bem_close_0();
} /* Line: 178 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
try  /* Line: 180 */ {
bem_close_0();
} /* Line: 181 */
 catch (System.Exception beve_1) {
bevl_ee = (be.BECS_ThrowBack.handleThrow(beve_1));
} /* Line: 182 */
} /* Line: 182 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() {
return bevp_command;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGetDirect_0() {
return bevp_command;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_commandsGet_0() {
return bevp_commands;
} /*method end*/
public BEC_2_9_4_ContainerList bem_commandsGetDirect_0() {
return bevp_commands;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_commands = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_commands = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGet_0() {
return bevp_outputReader;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGetDirect_0() {
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {38, 44, 46, 47, 0, 47, 47, 48, 48, 49, 49, 51, 56, 57, 57, 64, 64, 65, 65, 66, 66, 67, 67, 67, 69, 70, 90, 90, 91, 97, 97, 97, 98, 97, 122, 126, 133, 133, 134, 136, 147, 148, 153, 153, 154, 155, 161, 177, 177, 177, 178, 181, 184, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {28, 38, 39, 40, 40, 43, 45, 46, 47, 49, 50, 52, 62, 63, 64, 82, 83, 84, 89, 90, 91, 92, 93, 94, 97, 98, 112, 117, 118, 119, 122, 127, 128, 129, 138, 141, 146, 151, 152, 154, 157, 158, 164, 169, 170, 171, 180, 192, 193, 194, 195, 200, 206, 209, 212, 215, 219, 223, 226, 229, 233, 237, 240, 243, 247};
/* BEGIN LINEINFO 
assign 1 38 28
assign 1 44 38
assign 1 46 39
new 0 46 39
assign 1 47 40
iteratorGet 0 0 40
assign 1 47 43
hasNextGet 0 47 43
assign 1 47 45
nextGet 0 47 45
assign 1 48 46
new 0 48 46
assign 1 48 47
notEmpty 1 48 47
assign 1 49 49
new 0 49 49
addValue 1 49 50
addValue 1 51 52
new 1 56 62
assign 1 57 63
run 0 57 63
return 1 57 64
assign 1 64 82
new 0 64 82
assign 1 64 83
find 1 64 83
assign 1 65 84
def 1 65 89
assign 1 66 90
new 0 66 90
assign 1 66 91
substring 2 66 91
assign 1 67 92
new 0 67 92
assign 1 67 93
add 1 67 93
assign 1 67 94
substring 1 67 94
assign 1 69 97
assign 1 70 98
new 0 70 98
assign 1 90 112
def 1 90 117
assign 1 91 118
sizeGet 0 91 118
assign 1 97 119
new 0 97 119
assign 1 97 122
lesser 1 97 127
assign 1 98 128
get 1 98 128
incrementValue 0 97 129
return 1 122 138
run 0 126 141
assign 1 133 146
def 1 133 151
return 1 134 152
assign 1 136 154
new 0 136 154
extOpen 0 147 157
return 1 148 158
assign 1 153 164
def 1 153 169
close 0 154 170
assign 1 155 171
closeOutput 0 161 180
assign 1 177 192
open 0 177 192
assign 1 177 193
outputGet 0 177 193
assign 1 177 194
readString 0 177 194
close 0 178 195
close 0 181 200
return 1 184 206
return 1 0 209
return 1 0 212
assign 1 0 215
assign 1 0 219
return 1 0 223
return 1 0 226
assign 1 0 229
assign 1 0 233
return 1 0 237
return 1 0 240
assign 1 0 243
assign 1 0 247
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 2121039924: return bem_new_0();
case 1541452525: return bem_open_0();
case -1856486979: return bem_deserializeClassNameGet_0();
case -811418832: return bem_many_0();
case -1872349920: return bem_outputGet_0();
case -1333447241: return bem_closeOutput_0();
case -1447950980: return bem_outputContentGet_0();
case -1276189650: return bem_outputReaderGetDirect_0();
case -992120130: return bem_fieldIteratorGet_0();
case 893274194: return bem_tagGet_0();
case 1057323332: return bem_toAny_0();
case -195266806: return bem_toString_0();
case 538632487: return bem_serializationIteratorGet_0();
case -1679224519: return bem_commandGet_0();
case 1474888899: return bem_commandsGet_0();
case 972760034: return bem_outputReaderGet_0();
case -189856578: return bem_copy_0();
case -166515831: return bem_fieldNamesGet_0();
case -217110585: return bem_commandsGetDirect_0();
case -265928475: return bem_classNameGet_0();
case -1197889291: return bem_commandGetDirect_0();
case -1232978478: return bem_hashGet_0();
case -473371478: return bem_run_0();
case 1236464998: return bem_serializeContents_0();
case 803060031: return bem_create_0();
case 2111391138: return bem_serializeToString_0();
case -299023655: return bem_echo_0();
case 1870744321: return bem_once_0();
case -1735879417: return bem_print_0();
case -1438038411: return bem_sourceFileNameGet_0();
case 24125772: return bem_iteratorGet_0();
case -1196419988: return bem_close_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -267062499: return bem_sameType_1(bevd_0);
case -490313093: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1233382567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 712489064: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1108496649: return bem_otherClass_1(bevd_0);
case -1854722313: return bem_outputReaderSet_1(bevd_0);
case 1681419755: return bem_defined_1(bevd_0);
case 1119989103: return bem_run_1((BEC_2_4_6_TextString) bevd_0);
case 1446145648: return bem_outputReaderSetDirect_1(bevd_0);
case 955410070: return bem_commandSetDirect_1(bevd_0);
case -564148923: return bem_sameObject_1(bevd_0);
case 525545408: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1374125024: return bem_undef_1(bevd_0);
case -1171661229: return bem_otherType_1(bevd_0);
case -1662879703: return bem_commandsSet_1(bevd_0);
case -1433803932: return bem_def_1(bevd_0);
case 1669121148: return bem_copyTo_1(bevd_0);
case 870188127: return bem_commandSet_1(bevd_0);
case 1257487077: return bem_listNew_1((BEC_2_9_4_ContainerList) bevd_0);
case -132983687: return bem_undefined_1(bevd_0);
case 1628306760: return bem_notEquals_1(bevd_0);
case 260438285: return bem_commandsSetDirect_1(bevd_0);
case -905872983: return bem_equals_1(bevd_0);
case 1025270681: return bem_sameClass_1(bevd_0);
case 146723804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1931375919: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 68692131: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383175850: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -110664853: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1765848815: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1365987158: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -381061425: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemCommand_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemCommand_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_7_SystemCommand();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst = (BEC_2_6_7_SystemCommand) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_type;
}
}
}
