namespace be {
public class BET_2_7_10_ReplaceStringStep : BETS_Object {
public BET_2_7_10_ReplaceStringStep() {
string[] bevs_mtnames = new string[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "new_1", "handle_1", "strGet_0", "strSet_1" };
bems_buildMethodNames(bevs_mtnames);
}
static BET_2_7_10_ReplaceStringStep() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_7_10_ReplaceStringStep();
}
}
}
