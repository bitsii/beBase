namespace be {
/* IO:File: source/build/Constants.be */
public sealed class BEC_2_5_9_BuildConstants : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildConstants() { }
static BEC_2_5_9_BuildConstants() { }
private static byte[] becc_BEC_2_5_9_BuildConstants_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_5_9_BuildConstants_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_0 = {0x62,0x72,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_1 = {0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_2 = {0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_3 = {0x70,0x61,0x72,0x65,0x6E,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_4 = {0x4E,0x4F,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_5 = {0x4F,0x4E,0x43,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_6 = {0x4D,0x41,0x4E,0x59};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_7 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_8 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_9 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_10 = {0x44,0x49,0x56,0x49,0x44,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_11 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_12 = {0x41,0x44,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_13 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_14 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_15 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_16 = {0x4C,0x45,0x53,0x53,0x45,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_17 = {0x4C,0x45,0x53,0x53,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_18 = {0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_19 = {0x4E,0x4F,0x54,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_20 = {0x41,0x4E,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_21 = {0x4F,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_22 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x41,0x4E,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_23 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x4F,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_24 = {0x49,0x4E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_25 = {0x47,0x45,0x54,0x5F,0x4D,0x45,0x54,0x48,0x4F,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_26 = {0x41,0x44,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_27 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_28 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_29 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_30 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_31 = {0x44,0x49,0x56,0x49,0x44,0x45,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_32 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_33 = {0x41,0x4E,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_34 = {0x4F,0x52,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_35 = {0x41,0x53,0x53,0x49,0x47,0x4E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_36 = {0x20};
private static BEC_2_6_6_SystemObject bece_BEC_2_5_9_BuildConstants_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildConstants_bels_36, 1));
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_37 = {0x2F};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_38 = {0x7B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_39 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_40 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_41 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_42 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_43 = {0x3A};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_44 = {0x2C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_45 = {0x2B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_46 = {};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_47 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_48 = {0x40};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_49 = {0x23};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_50 = {0x7E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_51 = {0x75,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_52 = {0x61,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_53 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_54 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_55 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_56 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_57 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_58 = {0x61,0x6E,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_59 = {0x61,0x75,0x74,0x6F};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_60 = {0x69,0x66};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_61 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_62 = {0x65,0x6C,0x73,0x65,0x49,0x66};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_63 = {0x65,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_64 = {0x66,0x69,0x6E,0x61,0x6C,0x6C,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_65 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_66 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_67 = {0x77,0x68,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_68 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_69 = {0x66,0x6F,0x72};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_70 = {0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_71 = {0x65,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_72 = {0x69,0x66,0x45,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_73 = {0x69,0x66,0x4E,0x6F,0x74,0x45,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_74 = {0x62,0x72,0x65,0x61,0x6B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_75 = {0x63,0x6F,0x6E,0x74,0x69,0x6E,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_76 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_77 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_78 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_79 = {0x74,0x72,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_80 = {0x63,0x61,0x74,0x63,0x68};
public static new BEC_2_5_9_BuildConstants bece_BEC_2_5_9_BuildConstants_bevs_inst;

public static new BET_2_5_9_BuildConstants bece_BEC_2_5_9_BuildConstants_bevs_type;

public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public BEC_2_4_3_MathInt bevp_maxargs;
public BEC_2_4_3_MathInt bevp_extraSlots;
public BEC_2_4_3_MathInt bevp_mtdxPad;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_9_3_ContainerMap bevp_unwindTo;
public BEC_2_9_3_ContainerMap bevp_unwindOk;
public BEC_2_9_3_ContainerMap bevp_oper;
public BEC_2_9_3_ContainerMap bevp_operNames;
public BEC_2_9_3_ContainerMap bevp_conTypes;
public BEC_2_9_3_ContainerMap bevp_parensReq;
public BEC_2_9_3_ContainerMap bevp_anchorTypes;
public BEC_2_5_9_BuildConstants bem_new_1(BEC_2_6_6_SystemObject beva_build) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_114_tmpany_phold = null;
BEC_2_4_6_TextString bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_4_6_TextString bevt_119_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpany_phold = null;
BEC_2_4_6_TextString bevt_135_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_136_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_142_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_143_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_144_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_146_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_147_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_148_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_149_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_150_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_153_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_154_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_159_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_160_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_161_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_162_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_163_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_166_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_167_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_168_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_171_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_172_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_173_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_174_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_175_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_176_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_177_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_178_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_179_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_180_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_181_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_182_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_183_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_184_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_185_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_186_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_187_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_188_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_189_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_190_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_191_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_192_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_193_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_194_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_195_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_197_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_198_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_199_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_200_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_201_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_202_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_203_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_204_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_205_tmpany_phold = null;
bevp_maxargs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevp_extraSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_mtdxPad = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(26));
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;
bevp_unwindTo = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_unwindOk = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_oper = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_operNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_conTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parensReq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_0));
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindTo.bem_put_2(bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_1));
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_2));
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_3));
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_6_tmpany_phold, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevt_9_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_11_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_10_tmpany_phold, bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevt_13_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_15_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_14_tmpany_phold, bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_17_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_16_tmpany_phold, bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_18_tmpany_phold, bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_21_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_20_tmpany_phold, bevt_21_tmpany_phold);
bevt_22_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_23_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_22_tmpany_phold, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_25_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_26_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_29_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_28_tmpany_phold, bevt_29_tmpany_phold);
bevt_30_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_31_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_32_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_33_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_35_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_36_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_37_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_38_tmpany_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_39_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_38_tmpany_phold, bevt_39_tmpany_phold);
bevt_40_tmpany_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_41_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_40_tmpany_phold, bevt_41_tmpany_phold);
bevt_42_tmpany_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_43_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_42_tmpany_phold, bevt_43_tmpany_phold);
bevt_44_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevt_45_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_44_tmpany_phold, bevt_45_tmpany_phold);
bevt_46_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevt_47_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevt_48_tmpany_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_49_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_48_tmpany_phold, bevt_49_tmpany_phold);
bevt_50_tmpany_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_51_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_50_tmpany_phold, bevt_51_tmpany_phold);
bevt_52_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevt_53_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
bevp_oper.bem_put_2(bevt_52_tmpany_phold, bevt_53_tmpany_phold);
bevt_54_tmpany_phold = bevp_ntypes.bem_GET_METHODGet_0();
bevt_55_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
bevp_oper.bem_put_2(bevt_54_tmpany_phold, bevt_55_tmpany_phold);
bevt_56_tmpany_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_57_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_56_tmpany_phold, bevt_57_tmpany_phold);
bevt_58_tmpany_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_59_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_58_tmpany_phold, bevt_59_tmpany_phold);
bevt_60_tmpany_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_61_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_60_tmpany_phold, bevt_61_tmpany_phold);
bevt_62_tmpany_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_63_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_62_tmpany_phold, bevt_63_tmpany_phold);
bevt_64_tmpany_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_65_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_64_tmpany_phold, bevt_65_tmpany_phold);
bevt_66_tmpany_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_67_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_66_tmpany_phold, bevt_67_tmpany_phold);
bevt_68_tmpany_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_69_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_68_tmpany_phold, bevt_69_tmpany_phold);
bevt_70_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_71_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_oper.bem_put_2(bevt_70_tmpany_phold, bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_4));
bevp_operNames.bem_put_2(bevt_72_tmpany_phold, bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_5));
bevp_operNames.bem_put_2(bevt_74_tmpany_phold, bevt_75_tmpany_phold);
bevt_76_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_6));
bevp_operNames.bem_put_2(bevt_76_tmpany_phold, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_7));
bevp_operNames.bem_put_2(bevt_78_tmpany_phold, bevt_79_tmpany_phold);
bevt_80_tmpany_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_8));
bevp_operNames.bem_put_2(bevt_80_tmpany_phold, bevt_81_tmpany_phold);
bevt_82_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_9));
bevp_operNames.bem_put_2(bevt_82_tmpany_phold, bevt_83_tmpany_phold);
bevt_84_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_10));
bevp_operNames.bem_put_2(bevt_84_tmpany_phold, bevt_85_tmpany_phold);
bevt_86_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_11));
bevp_operNames.bem_put_2(bevt_86_tmpany_phold, bevt_87_tmpany_phold);
bevt_88_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_12));
bevp_operNames.bem_put_2(bevt_88_tmpany_phold, bevt_89_tmpany_phold);
bevt_90_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_13));
bevp_operNames.bem_put_2(bevt_90_tmpany_phold, bevt_91_tmpany_phold);
bevt_92_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_14));
bevp_operNames.bem_put_2(bevt_92_tmpany_phold, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_15));
bevp_operNames.bem_put_2(bevt_94_tmpany_phold, bevt_95_tmpany_phold);
bevt_96_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_16));
bevp_operNames.bem_put_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildConstants_bels_17));
bevp_operNames.bem_put_2(bevt_98_tmpany_phold, bevt_99_tmpany_phold);
bevt_100_tmpany_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_18));
bevp_operNames.bem_put_2(bevt_100_tmpany_phold, bevt_101_tmpany_phold);
bevt_102_tmpany_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_103_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildConstants_bels_19));
bevp_operNames.bem_put_2(bevt_102_tmpany_phold, bevt_103_tmpany_phold);
bevt_104_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_20));
bevp_operNames.bem_put_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevt_106_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_21));
bevp_operNames.bem_put_2(bevt_106_tmpany_phold, bevt_107_tmpany_phold);
bevt_108_tmpany_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_109_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildConstants_bels_22));
bevp_operNames.bem_put_2(bevt_108_tmpany_phold, bevt_109_tmpany_phold);
bevt_110_tmpany_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_111_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildConstants_bels_23));
bevp_operNames.bem_put_2(bevt_110_tmpany_phold, bevt_111_tmpany_phold);
bevt_112_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevt_113_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_24));
bevp_operNames.bem_put_2(bevt_112_tmpany_phold, bevt_113_tmpany_phold);
bevt_114_tmpany_phold = bevp_ntypes.bem_GET_METHODGet_0();
bevt_115_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildConstants_bels_25));
bevp_operNames.bem_put_2(bevt_114_tmpany_phold, bevt_115_tmpany_phold);
bevt_116_tmpany_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_117_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_26));
bevp_operNames.bem_put_2(bevt_116_tmpany_phold, bevt_117_tmpany_phold);
bevt_118_tmpany_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_119_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_27));
bevp_operNames.bem_put_2(bevt_118_tmpany_phold, bevt_119_tmpany_phold);
bevt_120_tmpany_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_121_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildConstants_bels_28));
bevp_operNames.bem_put_2(bevt_120_tmpany_phold, bevt_121_tmpany_phold);
bevt_122_tmpany_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_123_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildConstants_bels_29));
bevp_operNames.bem_put_2(bevt_122_tmpany_phold, bevt_123_tmpany_phold);
bevt_124_tmpany_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_30));
bevp_operNames.bem_put_2(bevt_124_tmpany_phold, bevt_125_tmpany_phold);
bevt_126_tmpany_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_127_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildConstants_bels_31));
bevp_operNames.bem_put_2(bevt_126_tmpany_phold, bevt_127_tmpany_phold);
bevt_128_tmpany_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_129_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildConstants_bels_32));
bevp_operNames.bem_put_2(bevt_128_tmpany_phold, bevt_129_tmpany_phold);
bevt_130_tmpany_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_131_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_33));
bevp_operNames.bem_put_2(bevt_130_tmpany_phold, bevt_131_tmpany_phold);
bevt_132_tmpany_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_133_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_34));
bevp_operNames.bem_put_2(bevt_132_tmpany_phold, bevt_133_tmpany_phold);
bevt_134_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_135_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_35));
bevp_operNames.bem_put_2(bevt_134_tmpany_phold, bevt_135_tmpany_phold);
bevt_136_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_137_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_136_tmpany_phold, bevt_137_tmpany_phold);
bevt_138_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_139_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_138_tmpany_phold, bevt_139_tmpany_phold);
bevt_140_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_141_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_140_tmpany_phold, bevt_141_tmpany_phold);
bevt_142_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_143_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_142_tmpany_phold, bevt_143_tmpany_phold);
bevt_144_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_145_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_144_tmpany_phold, bevt_145_tmpany_phold);
bevt_146_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevt_147_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_146_tmpany_phold, bevt_147_tmpany_phold);
bevt_148_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_149_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_148_tmpany_phold, bevt_149_tmpany_phold);
bevt_150_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_151_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_150_tmpany_phold, bevt_151_tmpany_phold);
bevt_152_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_153_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_152_tmpany_phold, bevt_153_tmpany_phold);
bevt_154_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_155_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_154_tmpany_phold, bevt_155_tmpany_phold);
bevt_156_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_157_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_156_tmpany_phold, bevt_157_tmpany_phold);
bevt_158_tmpany_phold = bevp_ntypes.bem_FINALLYGet_0();
bevt_159_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_158_tmpany_phold, bevt_159_tmpany_phold);
bevt_160_tmpany_phold = bevp_ntypes.bem_TRYGet_0();
bevt_161_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_160_tmpany_phold, bevt_161_tmpany_phold);
bevt_162_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevt_163_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_162_tmpany_phold, bevt_163_tmpany_phold);
bevt_164_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_165_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_164_tmpany_phold, bevt_165_tmpany_phold);
bevt_166_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_167_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_166_tmpany_phold, bevt_167_tmpany_phold);
bevt_168_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_169_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_168_tmpany_phold, bevt_169_tmpany_phold);
bevt_170_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_171_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_170_tmpany_phold, bevt_171_tmpany_phold);
bevt_172_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_173_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_172_tmpany_phold, bevt_173_tmpany_phold);
bevt_174_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
bevt_175_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_174_tmpany_phold, bevt_175_tmpany_phold);
bevt_176_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_177_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_176_tmpany_phold, bevt_177_tmpany_phold);
bevt_178_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_179_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_178_tmpany_phold, bevt_179_tmpany_phold);
bevt_180_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_181_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_180_tmpany_phold, bevt_181_tmpany_phold);
bevt_182_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_183_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_182_tmpany_phold, bevt_183_tmpany_phold);
bevt_184_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_185_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_184_tmpany_phold, bevt_185_tmpany_phold);
bevt_186_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevt_187_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_186_tmpany_phold, bevt_187_tmpany_phold);
bevt_188_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_189_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_188_tmpany_phold, bevt_189_tmpany_phold);
bevt_190_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_191_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_190_tmpany_phold, bevt_191_tmpany_phold);
bevt_192_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_193_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_192_tmpany_phold, bevt_193_tmpany_phold);
bevt_194_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_195_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_194_tmpany_phold, bevt_195_tmpany_phold);
bevt_196_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_197_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_196_tmpany_phold, bevt_197_tmpany_phold);
bevt_198_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_199_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_198_tmpany_phold, bevt_199_tmpany_phold);
bevt_200_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_201_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_200_tmpany_phold, bevt_201_tmpany_phold);
bevt_202_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_203_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_202_tmpany_phold, bevt_203_tmpany_phold);
bevt_204_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_205_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_204_tmpany_phold, bevt_205_tmpany_phold);
bem_prepare_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_prepare_0() {
BEC_2_6_6_SystemObject bevl_space = null;
BEC_2_6_6_SystemObject bevl_ntok = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
bevp_matchMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_space = bece_BEC_2_5_9_BuildConstants_bevo_0;
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_37));
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_twtok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2((BEC_2_4_6_TextString) bevl_ntok , bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_1_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_38));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_2_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_2_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_39));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_3_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_3_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_40));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_4_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_4_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_41));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_5_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_5_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_42));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_6_tmpany_phold = bevp_ntypes.bem_SEMIGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_6_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_43));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_7_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_7_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_44));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_8_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_8_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_45));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_9_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_9_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildConstants_bels_46));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_10_tmpany_phold = bevp_ntypes.bem_ATYPEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_10_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_47));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_11_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_11_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_48));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_12_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_12_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_49));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_13_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_13_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_50));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_14_tmpany_phold = bevp_ntypes.bem_GET_METHODGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(92));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_15_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_16_tmpany_phold = bevp_ntypes.bem_FSLASHGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_17_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_18_tmpany_phold = bevp_ntypes.bem_STRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(39));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_19_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_20_tmpany_phold = bevp_ntypes.bem_WSTRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_21_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_22_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(93));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_23_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_24_tmpany_phold = bevp_ntypes.bem_RIDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(37));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_25_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_26_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(61));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_27_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_28_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(62));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_29_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_30_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(60));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_31_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_32_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(33));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_33_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_34_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(38));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_35_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_36_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(124));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_37_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_38_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(42));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_39_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_40_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(46));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_41_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_42_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_42_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_43_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_44_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_45_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_46_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_ntok = bevt_47_tmpany_phold.bem_newlineGet_0();
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_48_tmpany_phold = bevp_ntypes.bem_NEWLINEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_48_tmpany_phold);
bevp_rwords = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_51));
bevt_50_tmpany_phold = bevp_ntypes.bem_USEGet_0();
bevp_rwords.bem_put_2(bevt_49_tmpany_phold, bevt_50_tmpany_phold);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_52));
bevt_52_tmpany_phold = bevp_ntypes.bem_ASGet_0();
bevp_rwords.bem_put_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_53));
bevt_54_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevp_rwords.bem_put_2(bevt_53_tmpany_phold, bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_54));
bevt_56_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevp_rwords.bem_put_2(bevt_55_tmpany_phold, bevt_56_tmpany_phold);
bevt_57_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_55));
bevt_58_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_57_tmpany_phold, bevt_58_tmpany_phold);
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_56));
bevt_60_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_59_tmpany_phold, bevt_60_tmpany_phold);
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_57));
bevt_62_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_61_tmpany_phold, bevt_62_tmpany_phold);
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_58));
bevt_64_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_63_tmpany_phold, bevt_64_tmpany_phold);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_59));
bevt_66_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_65_tmpany_phold, bevt_66_tmpany_phold);
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_60));
bevt_68_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_67_tmpany_phold, bevt_68_tmpany_phold);
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_61));
bevt_70_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_69_tmpany_phold, bevt_70_tmpany_phold);
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_62));
bevt_72_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevp_rwords.bem_put_2(bevt_71_tmpany_phold, bevt_72_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_63));
bevt_74_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevp_rwords.bem_put_2(bevt_73_tmpany_phold, bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_64));
bevt_76_tmpany_phold = bevp_ntypes.bem_FINALLYGet_0();
bevp_rwords.bem_put_2(bevt_75_tmpany_phold, bevt_76_tmpany_phold);
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_65));
bevt_78_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevp_rwords.bem_put_2(bevt_77_tmpany_phold, bevt_78_tmpany_phold);
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_66));
bevt_80_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevp_rwords.bem_put_2(bevt_79_tmpany_phold, bevt_80_tmpany_phold);
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_67));
bevt_82_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_68));
bevt_84_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_69));
bevt_86_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevp_rwords.bem_put_2(bevt_85_tmpany_phold, bevt_86_tmpany_phold);
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_70));
bevt_88_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevp_rwords.bem_put_2(bevt_87_tmpany_phold, bevt_88_tmpany_phold);
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_71));
bevt_90_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevp_rwords.bem_put_2(bevt_89_tmpany_phold, bevt_90_tmpany_phold);
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_72));
bevt_92_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_91_tmpany_phold, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_73));
bevt_94_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_93_tmpany_phold, bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_74));
bevt_96_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevp_rwords.bem_put_2(bevt_95_tmpany_phold, bevt_96_tmpany_phold);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_75));
bevt_98_tmpany_phold = bevp_ntypes.bem_CONTINUEGet_0();
bevp_rwords.bem_put_2(bevt_97_tmpany_phold, bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_76));
bevt_100_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
bevp_rwords.bem_put_2(bevt_99_tmpany_phold, bevt_100_tmpany_phold);
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_77));
bevt_102_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevp_rwords.bem_put_2(bevt_101_tmpany_phold, bevt_102_tmpany_phold);
bevt_103_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_78));
bevt_104_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevp_rwords.bem_put_2(bevt_103_tmpany_phold, bevt_104_tmpany_phold);
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_79));
bevt_106_tmpany_phold = bevp_ntypes.bem_TRYGet_0();
bevp_rwords.bem_put_2(bevt_105_tmpany_phold, bevt_106_tmpany_phold);
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_80));
bevt_108_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevp_rwords.bem_put_2(bevt_107_tmpany_phold, bevt_108_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() {
return bevp_matchMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGetDirect_0() {
return bevp_matchMap;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_matchMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() {
return bevp_rwords;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGetDirect_0() {
return bevp_rwords;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_rwordsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxargsGet_0() {
return bevp_maxargs;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxargsGetDirect_0() {
return bevp_maxargs;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_maxargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_maxargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_maxargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_maxargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_extraSlotsGet_0() {
return bevp_extraSlots;
} /*method end*/
public BEC_2_4_3_MathInt bem_extraSlotsGetDirect_0() {
return bevp_extraSlots;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_extraSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extraSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_extraSlotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extraSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxPadGet_0() {
return bevp_mtdxPad;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxPadGetDirect_0() {
return bevp_mtdxPad;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_mtdxPadSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdxPad = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_mtdxPadSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdxPad = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindToGet_0() {
return bevp_unwindTo;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindToGetDirect_0() {
return bevp_unwindTo;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindTo = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindTo = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindOkGet_0() {
return bevp_unwindOk;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindOkGetDirect_0() {
return bevp_unwindOk;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindOkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindOk = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindOkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindOk = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operGet_0() {
return bevp_oper;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operGetDirect_0() {
return bevp_oper;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_oper = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_oper = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operNamesGet_0() {
return bevp_operNames;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operNamesGetDirect_0() {
return bevp_operNames;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_operNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_operNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_conTypesGet_0() {
return bevp_conTypes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_conTypesGetDirect_0() {
return bevp_conTypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_conTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_conTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_conTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_conTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_parensReqGet_0() {
return bevp_parensReq;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_parensReqGetDirect_0() {
return bevp_parensReq;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_parensReqSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parensReq = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_parensReqSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parensReq = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anchorTypesGet_0() {
return bevp_anchorTypes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anchorTypesGetDirect_0() {
return bevp_anchorTypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_anchorTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_anchorTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 22, 23, 24, 25, 26, 27, 28, 29, 30, 34, 34, 34, 36, 36, 36, 37, 37, 37, 38, 38, 38, 40, 40, 40, 41, 41, 41, 42, 42, 42, 43, 43, 43, 44, 44, 44, 45, 45, 45, 46, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 49, 50, 50, 50, 51, 51, 51, 52, 52, 52, 53, 53, 53, 54, 54, 54, 55, 55, 55, 56, 56, 56, 57, 57, 57, 58, 58, 58, 59, 59, 59, 60, 60, 60, 61, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64, 64, 65, 65, 65, 66, 66, 66, 67, 67, 67, 68, 68, 68, 69, 69, 69, 70, 70, 70, 71, 71, 71, 73, 73, 73, 74, 74, 74, 75, 75, 75, 76, 76, 76, 77, 77, 77, 78, 78, 78, 79, 79, 79, 80, 80, 80, 81, 81, 81, 82, 82, 82, 83, 83, 83, 84, 84, 84, 85, 85, 85, 86, 86, 86, 87, 87, 87, 88, 88, 88, 89, 89, 89, 90, 90, 90, 91, 91, 91, 92, 92, 92, 93, 93, 93, 94, 94, 94, 95, 95, 95, 96, 96, 96, 97, 97, 97, 98, 98, 98, 99, 99, 99, 100, 100, 100, 101, 101, 101, 102, 102, 102, 103, 103, 103, 104, 104, 104, 106, 106, 106, 107, 107, 107, 108, 108, 108, 109, 109, 109, 110, 110, 110, 111, 111, 111, 112, 112, 112, 113, 113, 113, 114, 114, 114, 115, 115, 115, 116, 116, 116, 117, 117, 117, 118, 118, 118, 119, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 125, 125, 125, 127, 127, 127, 128, 128, 128, 129, 129, 129, 130, 130, 130, 131, 131, 131, 132, 132, 132, 133, 133, 133, 134, 134, 134, 135, 135, 135, 137, 137, 137, 138, 138, 138, 139, 139, 139, 140, 140, 140, 141, 141, 141, 142, 142, 142, 144, 150, 151, 153, 154, 154, 155, 155, 157, 158, 159, 159, 161, 162, 163, 163, 165, 166, 167, 167, 169, 170, 171, 171, 173, 174, 175, 175, 177, 178, 179, 179, 181, 182, 183, 183, 185, 186, 187, 187, 189, 190, 191, 191, 193, 194, 195, 195, 197, 198, 199, 199, 201, 202, 203, 203, 205, 206, 207, 207, 211, 211, 213, 214, 214, 216, 216, 218, 219, 219, 221, 221, 223, 224, 224, 226, 226, 228, 229, 229, 231, 231, 233, 234, 234, 236, 236, 238, 239, 239, 241, 241, 243, 244, 244, 246, 246, 248, 249, 249, 251, 251, 253, 254, 254, 256, 256, 258, 259, 259, 261, 261, 263, 264, 264, 266, 266, 268, 269, 269, 271, 271, 273, 274, 274, 276, 276, 278, 279, 279, 281, 281, 283, 284, 284, 286, 286, 288, 289, 289, 291, 291, 293, 294, 294, 297, 298, 298, 298, 299, 299, 299, 300, 300, 300, 301, 301, 301, 302, 302, 302, 303, 303, 303, 304, 304, 304, 305, 305, 305, 306, 306, 306, 307, 307, 307, 308, 308, 308, 309, 309, 309, 310, 310, 310, 311, 311, 311, 312, 312, 312, 313, 313, 313, 314, 314, 314, 315, 315, 315, 316, 316, 316, 317, 317, 317, 318, 318, 318, 319, 319, 319, 320, 320, 320, 321, 321, 321, 322, 322, 322, 323, 323, 323, 324, 324, 324, 325, 325, 325, 326, 326, 326, 327, 327, 327, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 978, 979, 980, 981, 982, 983, 984, 988, 991, 994, 998, 1002, 1005, 1008, 1012, 1016, 1019, 1022, 1026, 1030, 1033, 1036, 1040, 1044, 1047, 1050, 1054, 1058, 1061, 1064, 1068, 1072, 1075, 1078, 1082, 1086, 1089, 1092, 1096, 1100, 1103, 1106, 1110, 1114, 1117, 1120, 1124, 1128, 1131, 1134, 1138, 1142, 1145, 1148, 1152, 1156, 1159, 1162, 1166, 1170, 1173, 1176, 1180};
/* BEGIN LINEINFO 
assign 1 18 315
new 0 18 315
assign 1 19 316
new 0 19 316
assign 1 22 317
new 0 22 317
assign 1 23 318
new 0 23 318
assign 1 24 319
new 0 24 319
assign 1 25 320
new 0 25 320
assign 1 26 321
new 0 26 321
assign 1 27 322
new 0 27 322
assign 1 28 323
new 0 28 323
assign 1 29 324
new 0 29 324
assign 1 30 325
new 0 30 325
assign 1 34 326
new 0 34 326
assign 1 34 327
new 0 34 327
put 2 34 328
assign 1 36 329
new 0 36 329
assign 1 36 330
new 0 36 330
put 2 36 331
assign 1 37 332
new 0 37 332
assign 1 37 333
new 0 37 333
put 2 37 334
assign 1 38 335
new 0 38 335
assign 1 38 336
new 0 38 336
put 2 38 337
assign 1 40 338
NOTGet 0 40 338
assign 1 40 339
new 0 40 339
put 2 40 340
assign 1 41 341
ONCEGet 0 41 341
assign 1 41 342
new 0 41 342
put 2 41 343
assign 1 42 344
MANYGet 0 42 344
assign 1 42 345
new 0 42 345
put 2 42 346
assign 1 43 347
INCREMENTGet 0 43 347
assign 1 43 348
new 0 43 348
put 2 43 349
assign 1 44 350
DECREMENTGet 0 44 350
assign 1 44 351
new 0 44 351
put 2 44 352
assign 1 45 353
INCREMENT_ASSIGNGet 0 45 353
assign 1 45 354
new 0 45 354
put 2 45 355
assign 1 46 356
DECREMENT_ASSIGNGet 0 46 356
assign 1 46 357
new 0 46 357
put 2 46 358
assign 1 47 359
MULTIPLYGet 0 47 359
assign 1 47 360
new 0 47 360
put 2 47 361
assign 1 48 362
DIVIDEGet 0 48 362
assign 1 48 363
new 0 48 363
put 2 48 364
assign 1 49 365
MODULUSGet 0 49 365
assign 1 49 366
new 0 49 366
put 2 49 367
assign 1 50 368
ADDGet 0 50 368
assign 1 50 369
new 0 50 369
put 2 50 370
assign 1 51 371
SUBTRACTGet 0 51 371
assign 1 51 372
new 0 51 372
put 2 51 373
assign 1 52 374
GREATERGet 0 52 374
assign 1 52 375
new 0 52 375
put 2 52 376
assign 1 53 377
GREATER_EQUALSGet 0 53 377
assign 1 53 378
new 0 53 378
put 2 53 379
assign 1 54 380
LESSERGet 0 54 380
assign 1 54 381
new 0 54 381
put 2 54 382
assign 1 55 383
LESSER_EQUALSGet 0 55 383
assign 1 55 384
new 0 55 384
put 2 55 385
assign 1 56 386
EQUALSGet 0 56 386
assign 1 56 387
new 0 56 387
put 2 56 388
assign 1 57 389
NOT_EQUALSGet 0 57 389
assign 1 57 390
new 0 57 390
put 2 57 391
assign 1 58 392
ANDGet 0 58 392
assign 1 58 393
new 0 58 393
put 2 58 394
assign 1 59 395
ORGet 0 59 395
assign 1 59 396
new 0 59 396
put 2 59 397
assign 1 60 398
LOGICAL_ANDGet 0 60 398
assign 1 60 399
new 0 60 399
put 2 60 400
assign 1 61 401
LOGICAL_ORGet 0 61 401
assign 1 61 402
new 0 61 402
put 2 61 403
assign 1 62 404
INGet 0 62 404
assign 1 62 405
new 0 62 405
put 2 62 406
assign 1 63 407
GET_METHODGet 0 63 407
assign 1 63 408
new 0 63 408
put 2 63 409
assign 1 64 410
ADD_ASSIGNGet 0 64 410
assign 1 64 411
new 0 64 411
put 2 64 412
assign 1 65 413
SUBTRACT_ASSIGNGet 0 65 413
assign 1 65 414
new 0 65 414
put 2 65 415
assign 1 66 416
MULTIPLY_ASSIGNGet 0 66 416
assign 1 66 417
new 0 66 417
put 2 66 418
assign 1 67 419
DIVIDE_ASSIGNGet 0 67 419
assign 1 67 420
new 0 67 420
put 2 67 421
assign 1 68 422
MODULUS_ASSIGNGet 0 68 422
assign 1 68 423
new 0 68 423
put 2 68 424
assign 1 69 425
AND_ASSIGNGet 0 69 425
assign 1 69 426
new 0 69 426
put 2 69 427
assign 1 70 428
OR_ASSIGNGet 0 70 428
assign 1 70 429
new 0 70 429
put 2 70 430
assign 1 71 431
ASSIGNGet 0 71 431
assign 1 71 432
new 0 71 432
put 2 71 433
assign 1 73 434
NOTGet 0 73 434
assign 1 73 435
new 0 73 435
put 2 73 436
assign 1 74 437
ONCEGet 0 74 437
assign 1 74 438
new 0 74 438
put 2 74 439
assign 1 75 440
MANYGet 0 75 440
assign 1 75 441
new 0 75 441
put 2 75 442
assign 1 76 443
INCREMENTGet 0 76 443
assign 1 76 444
new 0 76 444
put 2 76 445
assign 1 77 446
DECREMENTGet 0 77 446
assign 1 77 447
new 0 77 447
put 2 77 448
assign 1 78 449
MULTIPLYGet 0 78 449
assign 1 78 450
new 0 78 450
put 2 78 451
assign 1 79 452
DIVIDEGet 0 79 452
assign 1 79 453
new 0 79 453
put 2 79 454
assign 1 80 455
MODULUSGet 0 80 455
assign 1 80 456
new 0 80 456
put 2 80 457
assign 1 81 458
ADDGet 0 81 458
assign 1 81 459
new 0 81 459
put 2 81 460
assign 1 82 461
SUBTRACTGet 0 82 461
assign 1 82 462
new 0 82 462
put 2 82 463
assign 1 83 464
GREATERGet 0 83 464
assign 1 83 465
new 0 83 465
put 2 83 466
assign 1 84 467
GREATER_EQUALSGet 0 84 467
assign 1 84 468
new 0 84 468
put 2 84 469
assign 1 85 470
LESSERGet 0 85 470
assign 1 85 471
new 0 85 471
put 2 85 472
assign 1 86 473
LESSER_EQUALSGet 0 86 473
assign 1 86 474
new 0 86 474
put 2 86 475
assign 1 87 476
EQUALSGet 0 87 476
assign 1 87 477
new 0 87 477
put 2 87 478
assign 1 88 479
NOT_EQUALSGet 0 88 479
assign 1 88 480
new 0 88 480
put 2 88 481
assign 1 89 482
ANDGet 0 89 482
assign 1 89 483
new 0 89 483
put 2 89 484
assign 1 90 485
ORGet 0 90 485
assign 1 90 486
new 0 90 486
put 2 90 487
assign 1 91 488
LOGICAL_ANDGet 0 91 488
assign 1 91 489
new 0 91 489
put 2 91 490
assign 1 92 491
LOGICAL_ORGet 0 92 491
assign 1 92 492
new 0 92 492
put 2 92 493
assign 1 93 494
INGet 0 93 494
assign 1 93 495
new 0 93 495
put 2 93 496
assign 1 94 497
GET_METHODGet 0 94 497
assign 1 94 498
new 0 94 498
put 2 94 499
assign 1 95 500
ADD_ASSIGNGet 0 95 500
assign 1 95 501
new 0 95 501
put 2 95 502
assign 1 96 503
SUBTRACT_ASSIGNGet 0 96 503
assign 1 96 504
new 0 96 504
put 2 96 505
assign 1 97 506
INCREMENT_ASSIGNGet 0 97 506
assign 1 97 507
new 0 97 507
put 2 97 508
assign 1 98 509
DECREMENT_ASSIGNGet 0 98 509
assign 1 98 510
new 0 98 510
put 2 98 511
assign 1 99 512
MULTIPLY_ASSIGNGet 0 99 512
assign 1 99 513
new 0 99 513
put 2 99 514
assign 1 100 515
DIVIDE_ASSIGNGet 0 100 515
assign 1 100 516
new 0 100 516
put 2 100 517
assign 1 101 518
MODULUS_ASSIGNGet 0 101 518
assign 1 101 519
new 0 101 519
put 2 101 520
assign 1 102 521
AND_ASSIGNGet 0 102 521
assign 1 102 522
new 0 102 522
put 2 102 523
assign 1 103 524
OR_ASSIGNGet 0 103 524
assign 1 103 525
new 0 103 525
put 2 103 526
assign 1 104 527
ASSIGNGet 0 104 527
assign 1 104 528
new 0 104 528
put 2 104 529
assign 1 106 530
IFGet 0 106 530
assign 1 106 531
new 0 106 531
put 2 106 532
assign 1 107 533
ELIFGet 0 107 533
assign 1 107 534
new 0 107 534
put 2 107 535
assign 1 108 536
WHILEGet 0 108 536
assign 1 108 537
new 0 108 537
put 2 108 538
assign 1 109 539
FORGet 0 109 539
assign 1 109 540
new 0 109 540
put 2 109 541
assign 1 110 542
FOREACHGet 0 110 542
assign 1 110 543
new 0 110 543
put 2 110 544
assign 1 111 545
EMITGet 0 111 545
assign 1 111 546
new 0 111 546
put 2 111 547
assign 1 112 548
IFEMITGet 0 112 548
assign 1 112 549
new 0 112 549
put 2 112 550
assign 1 113 551
METHODGet 0 113 551
assign 1 113 552
new 0 113 552
put 2 113 553
assign 1 114 554
CLASSGet 0 114 554
assign 1 114 555
new 0 114 555
put 2 114 556
assign 1 115 557
EXPRGet 0 115 557
assign 1 115 558
new 0 115 558
put 2 115 559
assign 1 116 560
ELSEGet 0 116 560
assign 1 116 561
new 0 116 561
put 2 116 562
assign 1 117 563
FINALLYGet 0 117 563
assign 1 117 564
new 0 117 564
put 2 117 565
assign 1 118 566
TRYGet 0 118 566
assign 1 118 567
new 0 118 567
put 2 118 568
assign 1 119 569
LOOPGet 0 119 569
assign 1 119 570
new 0 119 570
put 2 119 571
assign 1 120 572
PROPERTIESGet 0 120 572
assign 1 120 573
new 0 120 573
put 2 120 574
assign 1 121 575
CATCHGet 0 121 575
assign 1 121 576
new 0 121 576
put 2 121 577
assign 1 122 578
TRANSUNITGet 0 122 578
assign 1 122 579
new 0 122 579
put 2 122 580
assign 1 123 581
BRACESGet 0 123 581
assign 1 123 582
new 0 123 582
put 2 123 583
assign 1 124 584
PARENSGet 0 124 584
assign 1 124 585
new 0 124 585
put 2 124 586
assign 1 125 587
IDXGet 0 125 587
assign 1 125 588
new 0 125 588
put 2 125 589
assign 1 127 590
IFGet 0 127 590
assign 1 127 591
new 0 127 591
put 2 127 592
assign 1 128 593
ELIFGet 0 128 593
assign 1 128 594
new 0 128 594
put 2 128 595
assign 1 129 596
WHILEGet 0 129 596
assign 1 129 597
new 0 129 597
put 2 129 598
assign 1 130 599
FORGet 0 130 599
assign 1 130 600
new 0 130 600
put 2 130 601
assign 1 131 602
FOREACHGet 0 131 602
assign 1 131 603
new 0 131 603
put 2 131 604
assign 1 132 605
EMITGet 0 132 605
assign 1 132 606
new 0 132 606
put 2 132 607
assign 1 133 608
IFEMITGet 0 133 608
assign 1 133 609
new 0 133 609
put 2 133 610
assign 1 134 611
METHODGet 0 134 611
assign 1 134 612
new 0 134 612
put 2 134 613
assign 1 135 614
CATCHGet 0 135 614
assign 1 135 615
new 0 135 615
put 2 135 616
assign 1 137 617
IFGet 0 137 617
assign 1 137 618
new 0 137 618
put 2 137 619
assign 1 138 620
ELIFGet 0 138 620
assign 1 138 621
new 0 138 621
put 2 138 622
assign 1 139 623
WHILEGet 0 139 623
assign 1 139 624
new 0 139 624
put 2 139 625
assign 1 140 626
FORGet 0 140 626
assign 1 140 627
new 0 140 627
put 2 140 628
assign 1 141 629
FOREACHGet 0 141 629
assign 1 141 630
new 0 141 630
put 2 141 631
assign 1 142 632
EXPRGet 0 142 632
assign 1 142 633
new 0 142 633
put 2 142 634
prepare 0 144 635
assign 1 150 750
new 0 150 750
assign 1 151 751
new 0 151 751
assign 1 153 752
new 0 153 752
assign 1 154 753
new 0 154 753
assign 1 154 754
new 2 154 754
assign 1 155 755
DIVIDEGet 0 155 755
put 2 155 756
assign 1 157 757
new 0 157 757
addToken 1 158 758
assign 1 159 759
BRACESGet 0 159 759
put 2 159 760
assign 1 161 761
new 0 161 761
addToken 1 162 762
assign 1 163 763
RBRACESGet 0 163 763
put 2 163 764
assign 1 165 765
new 0 165 765
addToken 1 166 766
assign 1 167 767
PARENSGet 0 167 767
put 2 167 768
assign 1 169 769
new 0 169 769
addToken 1 170 770
assign 1 171 771
RPARENSGet 0 171 771
put 2 171 772
assign 1 173 773
new 0 173 773
addToken 1 174 774
assign 1 175 775
SEMIGet 0 175 775
put 2 175 776
assign 1 177 777
new 0 177 777
addToken 1 178 778
assign 1 179 779
COLONGet 0 179 779
put 2 179 780
assign 1 181 781
new 0 181 781
addToken 1 182 782
assign 1 183 783
COMMAGet 0 183 783
put 2 183 784
assign 1 185 785
new 0 185 785
addToken 1 186 786
assign 1 187 787
ADDGet 0 187 787
put 2 187 788
assign 1 189 789
new 0 189 789
addToken 1 190 790
assign 1 191 791
ATYPEGet 0 191 791
put 2 191 792
assign 1 193 793
new 0 193 793
addToken 1 194 794
assign 1 195 795
SUBTRACTGet 0 195 795
put 2 195 796
assign 1 197 797
new 0 197 797
addToken 1 198 798
assign 1 199 799
ONCEGet 0 199 799
put 2 199 800
assign 1 201 801
new 0 201 801
addToken 1 202 802
assign 1 203 803
MANYGet 0 203 803
put 2 203 804
assign 1 205 805
new 0 205 805
addToken 1 206 806
assign 1 207 807
GET_METHODGet 0 207 807
put 2 207 808
assign 1 211 809
new 0 211 809
assign 1 211 810
codeNew 1 211 810
addToken 1 213 811
assign 1 214 812
FSLASHGet 0 214 812
put 2 214 813
assign 1 216 814
new 0 216 814
assign 1 216 815
codeNew 1 216 815
addToken 1 218 816
assign 1 219 817
STRQGet 0 219 817
put 2 219 818
assign 1 221 819
new 0 221 819
assign 1 221 820
codeNew 1 221 820
addToken 1 223 821
assign 1 224 822
WSTRQGet 0 224 822
put 2 224 823
assign 1 226 824
new 0 226 824
assign 1 226 825
codeNew 1 226 825
addToken 1 228 826
assign 1 229 827
IDXGet 0 229 827
put 2 229 828
assign 1 231 829
new 0 231 829
assign 1 231 830
codeNew 1 231 830
addToken 1 233 831
assign 1 234 832
RIDXGet 0 234 832
put 2 234 833
assign 1 236 834
new 0 236 834
assign 1 236 835
codeNew 1 236 835
addToken 1 238 836
assign 1 239 837
MODULUSGet 0 239 837
put 2 239 838
assign 1 241 839
new 0 241 839
assign 1 241 840
codeNew 1 241 840
addToken 1 243 841
assign 1 244 842
ASSIGNGet 0 244 842
put 2 244 843
assign 1 246 844
new 0 246 844
assign 1 246 845
codeNew 1 246 845
addToken 1 248 846
assign 1 249 847
GREATERGet 0 249 847
put 2 249 848
assign 1 251 849
new 0 251 849
assign 1 251 850
codeNew 1 251 850
addToken 1 253 851
assign 1 254 852
LESSERGet 0 254 852
put 2 254 853
assign 1 256 854
new 0 256 854
assign 1 256 855
codeNew 1 256 855
addToken 1 258 856
assign 1 259 857
NOTGet 0 259 857
put 2 259 858
assign 1 261 859
new 0 261 859
assign 1 261 860
codeNew 1 261 860
addToken 1 263 861
assign 1 264 862
ANDGet 0 264 862
put 2 264 863
assign 1 266 864
new 0 266 864
assign 1 266 865
codeNew 1 266 865
addToken 1 268 866
assign 1 269 867
ORGet 0 269 867
put 2 269 868
assign 1 271 869
new 0 271 869
assign 1 271 870
codeNew 1 271 870
addToken 1 273 871
assign 1 274 872
MULTIPLYGet 0 274 872
put 2 274 873
assign 1 276 874
new 0 276 874
assign 1 276 875
codeNew 1 276 875
addToken 1 278 876
assign 1 279 877
DOTGet 0 279 877
put 2 279 878
assign 1 281 879
new 0 281 879
assign 1 281 880
codeNew 1 281 880
addToken 1 283 881
assign 1 284 882
SPACEGet 0 284 882
put 2 284 883
assign 1 286 884
new 0 286 884
assign 1 286 885
codeNew 1 286 885
addToken 1 288 886
assign 1 289 887
SPACEGet 0 289 887
put 2 289 888
assign 1 291 889
new 0 291 889
assign 1 291 890
newlineGet 0 291 890
addToken 1 293 891
assign 1 294 892
NEWLINEGet 0 294 892
put 2 294 893
assign 1 297 894
new 0 297 894
assign 1 298 895
new 0 298 895
assign 1 298 896
USEGet 0 298 896
put 2 298 897
assign 1 299 898
new 0 299 898
assign 1 299 899
ASGet 0 299 899
put 2 299 900
assign 1 300 901
new 0 300 901
assign 1 300 902
CLASSGet 0 300 902
put 2 300 903
assign 1 301 904
new 0 301 904
assign 1 301 905
METHODGet 0 301 905
put 2 301 906
assign 1 302 907
new 0 302 907
assign 1 302 908
DEFMODGet 0 302 908
put 2 302 909
assign 1 303 910
new 0 303 910
assign 1 303 911
DEFMODGet 0 303 911
put 2 303 912
assign 1 304 913
new 0 304 913
assign 1 304 914
DEFMODGet 0 304 914
put 2 304 915
assign 1 305 916
new 0 305 916
assign 1 305 917
VARGet 0 305 917
put 2 305 918
assign 1 306 919
new 0 306 919
assign 1 306 920
VARGet 0 306 920
put 2 306 921
assign 1 307 922
new 0 307 922
assign 1 307 923
IFGet 0 307 923
put 2 307 924
assign 1 308 925
new 0 308 925
assign 1 308 926
IFGet 0 308 926
put 2 308 927
assign 1 309 928
new 0 309 928
assign 1 309 929
ELIFGet 0 309 929
put 2 309 930
assign 1 310 931
new 0 310 931
assign 1 310 932
ELSEGet 0 310 932
put 2 310 933
assign 1 311 934
new 0 311 934
assign 1 311 935
FINALLYGet 0 311 935
put 2 311 936
assign 1 312 937
new 0 312 937
assign 1 312 938
LOOPGet 0 312 938
put 2 312 939
assign 1 313 940
new 0 313 940
assign 1 313 941
PROPERTIESGet 0 313 941
put 2 313 942
assign 1 314 943
new 0 314 943
assign 1 314 944
WHILEGet 0 314 944
put 2 314 945
assign 1 315 946
new 0 315 946
assign 1 315 947
WHILEGet 0 315 947
put 2 315 948
assign 1 316 949
new 0 316 949
assign 1 316 950
FORGet 0 316 950
put 2 316 951
assign 1 317 952
new 0 317 952
assign 1 317 953
INGet 0 317 953
put 2 317 954
assign 1 318 955
new 0 318 955
assign 1 318 956
EMITGet 0 318 956
put 2 318 957
assign 1 319 958
new 0 319 958
assign 1 319 959
IFEMITGet 0 319 959
put 2 319 960
assign 1 320 961
new 0 320 961
assign 1 320 962
IFEMITGet 0 320 962
put 2 320 963
assign 1 321 964
new 0 321 964
assign 1 321 965
BREAKGet 0 321 965
put 2 321 966
assign 1 322 967
new 0 322 967
assign 1 322 968
CONTINUEGet 0 322 968
put 2 322 969
assign 1 323 970
new 0 323 970
assign 1 323 971
NULLGet 0 323 971
put 2 323 972
assign 1 324 973
new 0 324 973
assign 1 324 974
TRUEGet 0 324 974
put 2 324 975
assign 1 325 976
new 0 325 976
assign 1 325 977
FALSEGet 0 325 977
put 2 325 978
assign 1 326 979
new 0 326 979
assign 1 326 980
TRYGet 0 326 980
put 2 326 981
assign 1 327 982
new 0 327 982
assign 1 327 983
CATCHGet 0 327 983
put 2 327 984
return 1 0 988
return 1 0 991
assign 1 0 994
assign 1 0 998
return 1 0 1002
return 1 0 1005
assign 1 0 1008
assign 1 0 1012
return 1 0 1016
return 1 0 1019
assign 1 0 1022
assign 1 0 1026
return 1 0 1030
return 1 0 1033
assign 1 0 1036
assign 1 0 1040
return 1 0 1044
return 1 0 1047
assign 1 0 1050
assign 1 0 1054
return 1 0 1058
return 1 0 1061
assign 1 0 1064
assign 1 0 1068
return 1 0 1072
return 1 0 1075
assign 1 0 1078
assign 1 0 1082
return 1 0 1086
return 1 0 1089
assign 1 0 1092
assign 1 0 1096
return 1 0 1100
return 1 0 1103
assign 1 0 1106
assign 1 0 1110
return 1 0 1114
return 1 0 1117
assign 1 0 1120
assign 1 0 1124
return 1 0 1128
return 1 0 1131
assign 1 0 1134
assign 1 0 1138
return 1 0 1142
return 1 0 1145
assign 1 0 1148
assign 1 0 1152
return 1 0 1156
return 1 0 1159
assign 1 0 1162
assign 1 0 1166
return 1 0 1170
return 1 0 1173
assign 1 0 1176
assign 1 0 1180
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1431960617: return bem_many_0();
case -1051263431: return bem_create_0();
case 1375519361: return bem_sourceFileNameGet_0();
case 1156921009: return bem_toString_0();
case 673713547: return bem_operGet_0();
case -521859959: return bem_prepare_0();
case -461205434: return bem_iteratorGet_0();
case -265389944: return bem_mtdxPadGet_0();
case -1581666253: return bem_new_0();
case 1707020898: return bem_unwindOkGet_0();
case -2013854760: return bem_operNamesGetDirect_0();
case -1925832412: return bem_twtokGet_0();
case -539277844: return bem_fieldIteratorGet_0();
case 1947173801: return bem_print_0();
case -388936401: return bem_parensReqGetDirect_0();
case -182215192: return bem_serializationIteratorGet_0();
case 126512909: return bem_operGetDirect_0();
case -1136389693: return bem_ntypesGet_0();
case 1167255869: return bem_anchorTypesGet_0();
case 464610233: return bem_once_0();
case 1969869774: return bem_echo_0();
case 874503493: return bem_serializeToString_0();
case -654415539: return bem_tagGet_0();
case -1522836388: return bem_matchMapGet_0();
case 49134257: return bem_hashGet_0();
case 1817099409: return bem_extraSlotsGetDirect_0();
case -369405366: return bem_matchMapGetDirect_0();
case -1747498826: return bem_classNameGet_0();
case -568871063: return bem_twtokGetDirect_0();
case 895850649: return bem_anchorTypesGetDirect_0();
case 122716458: return bem_extraSlotsGet_0();
case 420062204: return bem_unwindToGet_0();
case -1894009396: return bem_conTypesGet_0();
case 941172865: return bem_serializeContents_0();
case -1908823186: return bem_conTypesGetDirect_0();
case -680518616: return bem_mtdxPadGetDirect_0();
case 1205179000: return bem_deserializeClassNameGet_0();
case -737492775: return bem_rwordsGetDirect_0();
case 1512772474: return bem_copy_0();
case -1047706583: return bem_maxargsGetDirect_0();
case 1429793493: return bem_unwindToGetDirect_0();
case -513827791: return bem_rwordsGet_0();
case 210842964: return bem_unwindOkGetDirect_0();
case 1881939406: return bem_fieldNamesGet_0();
case 2093595293: return bem_operNamesGet_0();
case 85013320: return bem_ntypesGetDirect_0();
case -397552928: return bem_parensReqGet_0();
case -116352994: return bem_maxargsGet_0();
case 322540171: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1499911921: return bem_notEquals_1(bevd_0);
case 899884445: return bem_mtdxPadSetDirect_1(bevd_0);
case -653588721: return bem_otherType_1(bevd_0);
case 1553016471: return bem_maxargsSet_1(bevd_0);
case -879668411: return bem_twtokSetDirect_1(bevd_0);
case -208359851: return bem_unwindToSet_1(bevd_0);
case 677950083: return bem_parensReqSetDirect_1(bevd_0);
case 243162876: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1902213522: return bem_ntypesSet_1(bevd_0);
case -1901926494: return bem_matchMapSetDirect_1(bevd_0);
case -1405212164: return bem_sameClass_1(bevd_0);
case 1817351105: return bem_defined_1(bevd_0);
case -459244160: return bem_maxargsSetDirect_1(bevd_0);
case 104343192: return bem_anchorTypesSetDirect_1(bevd_0);
case 1150738548: return bem_operNamesSetDirect_1(bevd_0);
case 1813126449: return bem_twtokSet_1(bevd_0);
case 2125870571: return bem_new_1(bevd_0);
case -353187974: return bem_unwindToSetDirect_1(bevd_0);
case 1421687176: return bem_rwordsSetDirect_1(bevd_0);
case -1264044693: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2127673178: return bem_parensReqSet_1(bevd_0);
case -1384906098: return bem_conTypesSet_1(bevd_0);
case 1969791439: return bem_extraSlotsSetDirect_1(bevd_0);
case 778331504: return bem_def_1(bevd_0);
case -2019132890: return bem_unwindOkSetDirect_1(bevd_0);
case -1912702671: return bem_operNamesSet_1(bevd_0);
case -1943581702: return bem_conTypesSetDirect_1(bevd_0);
case 372746140: return bem_sameType_1(bevd_0);
case -1295446558: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 52741601: return bem_extraSlotsSet_1(bevd_0);
case 1541877434: return bem_anchorTypesSet_1(bevd_0);
case 447923928: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2138590698: return bem_unwindOkSet_1(bevd_0);
case -1078011444: return bem_operSet_1(bevd_0);
case 1089354598: return bem_undef_1(bevd_0);
case -498298486: return bem_sameObject_1(bevd_0);
case 152845071: return bem_matchMapSet_1(bevd_0);
case 1779380050: return bem_undefined_1(bevd_0);
case 82877906: return bem_operSetDirect_1(bevd_0);
case -373658986: return bem_equals_1(bevd_0);
case -1940703752: return bem_copyTo_1(bevd_0);
case 1966156517: return bem_otherClass_1(bevd_0);
case 1235453304: return bem_mtdxPadSet_1(bevd_0);
case 874551402: return bem_ntypesSetDirect_1(bevd_0);
case -1003897244: return bem_rwordsSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 414389553: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1714613573: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -292360250: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1129259785: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 614290015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 888716978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 193506539: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildConstants_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildConstants_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildConstants();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildConstants.bece_BEC_2_5_9_BuildConstants_bevs_inst = (BEC_2_5_9_BuildConstants) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildConstants.bece_BEC_2_5_9_BuildConstants_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildConstants.bece_BEC_2_5_9_BuildConstants_bevs_type;
}
}
}
