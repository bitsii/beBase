namespace be {
/* IO:File: source/build/JVEmitter.be */
public sealed class BEC_2_5_9_BuildJVEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
static BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_6, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_7, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_8, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_9, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_10, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_12, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_13, 14));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_14, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_20, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_27, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_28, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 9));
public static new BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-1871131500);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(839655824);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 46 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 59 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 59 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
return bevt_3_tmpany_phold;
} /* Line: 60 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 66 */
 else  /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 66 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
return bevt_3_tmpany_phold;
} /* Line: 67 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_25));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-1237003730);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 23, 27, 27, 27, 28, 29, 29, 29, 29, 29, 29, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 37, 37, 37, 37, 37, 42, 43, 44, 44, 45, 45, 46, 46, 48, 48, 48, 49, 55, 55, 55, 55, 55, 55, 59, 59, 59, 0, 0, 0, 60, 60, 62, 62, 66, 66, 66, 0, 0, 0, 67, 67, 69, 69, 73, 73, 77, 77, 77, 77, 77, 78, 78, 78, 78, 78, 78, 79, 79, 79, 80, 80, 80, 80, 80, 80, 80, 80, 81, 85, 85, 85, 89, 89, 89, 89, 89, 89, 89, 93, 93, 97, 97, 101, 101, 101, 101};
public static new int[] bevs_smnlec
 = new int[] {55, 56, 57, 58, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 106, 107, 108, 109, 110, 120, 121, 122, 123, 125, 126, 127, 128, 130, 131, 132, 133, 142, 143, 144, 145, 146, 147, 155, 160, 161, 163, 166, 170, 173, 174, 176, 177, 185, 190, 191, 193, 196, 200, 203, 204, 206, 207, 211, 212, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 261, 262, 263, 272, 273, 274, 275, 276, 277, 278, 282, 283, 287, 288, 294, 295, 296, 297};
/* BEGIN LINEINFO 
assign 1 17 55
new 0 17 55
assign 1 18 56
new 0 18 56
assign 1 19 57
new 0 19 57
new 1 23 58
assign 1 27 79
new 0 27 79
assign 1 27 80
toString 0 27 80
assign 1 27 81
add 1 27 81
incrementValue 0 28 82
assign 1 29 83
new 0 29 83
assign 1 29 84
addValue 1 29 84
assign 1 29 85
addValue 1 29 85
assign 1 29 86
new 0 29 86
assign 1 29 87
addValue 1 29 87
addValue 1 29 88
assign 1 31 89
containedGet 0 31 89
assign 1 31 90
firstGet 0 31 90
assign 1 31 91
containedGet 0 31 91
assign 1 31 92
firstGet 0 31 92
assign 1 31 93
new 0 31 93
assign 1 31 94
add 1 31 94
assign 1 31 95
new 0 31 95
assign 1 31 96
add 1 31 96
assign 1 31 97
finalAssign 4 31 97
addValue 1 31 98
assign 1 37 106
new 0 37 106
assign 1 37 107
add 1 37 107
assign 1 37 108
new 0 37 108
assign 1 37 109
add 1 37 109
return 1 37 110
getInt 2 42 120
assign 1 43 121
toHexString 1 43 121
assign 1 44 122
new 0 44 122
assign 1 44 123
begins 1 44 123
assign 1 45 125
new 0 45 125
assign 1 45 126
substring 1 45 126
assign 1 46 127
new 0 46 127
addValue 1 46 128
assign 1 48 130
new 0 48 130
assign 1 48 131
once 0 48 131
addValue 1 48 132
addValue 1 49 133
assign 1 55 142
new 0 55 142
assign 1 55 143
add 1 55 143
assign 1 55 144
new 0 55 144
assign 1 55 145
add 1 55 145
assign 1 55 146
add 1 55 146
return 1 55 147
assign 1 59 155
def 1 59 160
assign 1 59 161
isFinalGet 0 59 161
assign 1 0 163
assign 1 0 166
assign 1 0 170
assign 1 60 173
new 0 60 173
return 1 60 174
assign 1 62 176
new 0 62 176
return 1 62 177
assign 1 66 185
def 1 66 190
assign 1 66 191
isFinalGet 0 66 191
assign 1 0 193
assign 1 0 196
assign 1 0 200
assign 1 67 203
new 0 67 203
return 1 67 204
assign 1 69 206
new 0 69 206
return 1 69 207
assign 1 73 211
new 0 73 211
return 1 73 212
assign 1 77 234
new 0 77 234
assign 1 77 235
add 1 77 235
assign 1 77 236
new 0 77 236
assign 1 77 237
add 1 77 237
assign 1 77 238
add 1 77 238
assign 1 78 239
new 0 78 239
assign 1 78 240
addValue 1 78 240
assign 1 78 241
addValue 1 78 241
assign 1 78 242
new 0 78 242
assign 1 78 243
addValue 1 78 243
addValue 1 78 244
assign 1 79 245
new 0 79 245
assign 1 79 246
addValue 1 79 246
addValue 1 79 247
assign 1 80 248
new 0 80 248
assign 1 80 249
addValue 1 80 249
assign 1 80 250
outputPlatformGet 0 80 250
assign 1 80 251
nameGet 0 80 251
assign 1 80 252
addValue 1 80 252
assign 1 80 253
new 0 80 253
assign 1 80 254
addValue 1 80 254
addValue 1 80 255
return 1 81 256
assign 1 85 261
libNameGet 0 85 261
assign 1 85 262
beginNs 1 85 262
return 1 85 263
assign 1 89 272
new 0 89 272
assign 1 89 273
libNs 1 89 273
assign 1 89 274
add 1 89 274
assign 1 89 275
new 0 89 275
assign 1 89 276
add 1 89 276
assign 1 89 277
add 1 89 277
return 1 89 278
assign 1 93 282
getNameSpace 1 93 282
return 1 93 283
assign 1 97 287
new 0 97 287
return 1 97 288
assign 1 101 294
new 0 101 294
assign 1 101 295
once 0 101 295
assign 1 101 296
add 1 101 296
return 1 101 297
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 142206752: return bem_many_0();
case 1505612632: return bem_csynGet_0();
case 912437192: return bem_saveSyns_0();
case -67966079: return bem_ccMethodsGet_0();
case -196381941: return bem_nlGet_0();
case -1757462656: return bem_baseMtdDecGet_0();
case -1152001976: return bem_copy_0();
case 231935197: return bem_ccCacheGet_0();
case 2085674875: return bem_echo_0();
case -1465767493: return bem_inFilePathedGet_0();
case -778316098: return bem_randGet_0();
case 1105730801: return bem_constGet_0();
case 2040151902: return bem_boolCcGet_0();
case -1614523272: return bem_classConfGet_0();
case 1437982662: return bem_smnlecsGet_0();
case 349457701: return bem_trueValueGet_0();
case -1930675122: return bem_falseValueGet_0();
case 650294548: return bem_maxSpillArgsLenGet_0();
case -23554930: return bem_useDynMethodsGet_0();
case 1351503048: return bem_lastMethodBodySizeGet_0();
case 950629568: return bem_ntypesGet_0();
case -112541163: return bem_superCallsGet_0();
case -838119829: return bem_synEmitPathGet_0();
case 1904605379: return bem_afterCast_0();
case 1310164435: return bem_serializeContents_0();
case -1976290782: return bem_print_0();
case 2104962208: return bem_lineCountGet_0();
case 1332459590: return bem_boolTypeGet_0();
case -1693697148: return bem_coanyiantReturnsGet_0();
case -92626389: return bem_lastMethodsLinesGet_0();
case -1888508563: return bem_serializationIteratorGet_0();
case 1211836779: return bem_iteratorGet_0();
case 917435133: return bem_endNs_0();
case -168767106: return bem_onceDecsGet_0();
case 5512371: return bem_stringNpGet_0();
case 752911959: return bem_hashGet_0();
case -1517766360: return bem_getLibOutput_0();
case 1419044409: return bem_objectNpGet_0();
case -1990885529: return bem_mainStartGet_0();
case 355714843: return bem_fileExtGet_0();
case -1256094503: return bem_lastMethodBodyLinesGet_0();
case -868180553: return bem_lastMethodsSizeGet_0();
case -326646035: return bem_toString_0();
case 1525522454: return bem_emitLangGet_0();
case 996356293: return bem_instanceEqualGet_0();
case -2028948232: return bem_classEmitsGet_0();
case 1994731310: return bem_classesInDepthOrderGet_0();
case 789352093: return bem_mainOutsideNsGet_0();
case -1179584591: return bem_getClassOutput_0();
case 1464373622: return bem_methodCallsGet_0();
case -275328502: return bem_mainInClassGet_0();
case 1129538563: return bem_beginNs_0();
case -12357288: return bem_returnTypeGet_0();
case 1947970668: return bem_propertyDecsGet_0();
case -555708474: return bem_classCallsGet_0();
case 89421636: return bem_smnlcsGet_0();
case 753454220: return bem_methodBodyGet_0();
case -1186589497: return bem_intNpGet_0();
case 338759142: return bem_instOfGet_0();
case 2141550628: return bem_deserializeClassNameGet_0();
case 880152096: return bem_classNameGet_0();
case -364515046: return bem_fieldIteratorGet_0();
case -1784679170: return bem_libEmitPathGet_0();
case 805495691: return bem_exceptDecGet_0();
case -798238503: return bem_classEndGet_0();
case -949549861: return bem_buildInitial_0();
case 1623561435: return bem_preClassGet_0();
case -914082918: return bem_floatNpGet_0();
case 1708332552: return bem_onceCountGet_0();
case -536696156: return bem_mainEndGet_0();
case 1295210903: return bem_objectCcGet_0();
case 2019847492: return bem_overrideMtdDecGet_0();
case 1171401384: return bem_parentConfGet_0();
case 436151660: return bem_idToNameGet_0();
case -640624992: return bem_dynMethodsGet_0();
case -548011824: return bem_boolNpGet_0();
case 690295505: return bem_fullLibEmitNameGet_0();
case 1918357744: return bem_lastCallGet_0();
case -1222174292: return bem_spropDecGet_0();
case -514928025: return bem_doEmit_0();
case 2049326174: return bem_qGet_0();
case 728740081: return bem_nameToIdGet_0();
case -1908963920: return bem_callNamesGet_0();
case -307083395: return bem_baseSmtdDecGet_0();
case 1029589232: return bem_superNameGet_0();
case -1896601781: return bem_toAny_0();
case -176558462: return bem_methodsGet_0();
case -1148949774: return bem_runtimeInitGet_0();
case -1330536892: return bem_libEmitNameGet_0();
case -1193265838: return bem_new_0();
case -58429592: return bem_buildGet_0();
case -1685838127: return bem_nativeCSlotsGet_0();
case -2052611744: return bem_once_0();
case 993811421: return bem_msynGet_0();
case 938013793: return bem_maxDynArgsGet_0();
case 444169984: return bem_sourceFileNameGet_0();
case -1157180186: return bem_cnodeGet_0();
case 1271001595: return bem_scvpGet_0();
case 513484508: return bem_invpGet_0();
case -1219012766: return bem_mnodeGet_0();
case 588584481: return bem_emitLib_0();
case -1920840121: return bem_propDecGet_0();
case -2091198124: return bem_tagGet_0();
case -1298620421: return bem_methodCatchGet_0();
case 1592187695: return bem_nullValueGet_0();
case -1931237965: return bem_buildClassInfo_0();
case -810155628: return bem_initialDecGet_0();
case -1746464135: return bem_instanceNotEqualGet_0();
case -813327032: return bem_buildCreate_0();
case 1676564734: return bem_transGet_0();
case 1278477757: return bem_serializeToString_0();
case 2098501683: return bem_create_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -631233462: return bem_dynMethodsSet_1(bevd_0);
case -798477866: return bem_superCallsSet_1(bevd_0);
case 275457317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 742405855: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -716934084: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 748590402: return bem_maxSpillArgsLenSet_1(bevd_0);
case -311018698: return bem_preClassSet_1(bevd_0);
case -481362256: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -247434400: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1310449548: return bem_exceptDecSet_1(bevd_0);
case -814460350: return bem_nullValueSet_1(bevd_0);
case 2127150913: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -538280108: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 733937354: return bem_randSet_1(bevd_0);
case 490659810: return bem_libEmitNameSet_1(bevd_0);
case -804607244: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1194214814: return bem_classConfSet_1(bevd_0);
case 1870833628: return bem_constSet_1(bevd_0);
case 762445438: return bem_transSet_1(bevd_0);
case -2000825128: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1670482402: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1287585863: return bem_fileExtSet_1(bevd_0);
case 6890849: return bem_objectCcSet_1(bevd_0);
case 1621921148: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 173002423: return bem_lastMethodsLinesSet_1(bevd_0);
case 1197310997: return bem_trueValueSet_1(bevd_0);
case 1737970266: return bem_nlSet_1(bevd_0);
case 45057151: return bem_equals_1(bevd_0);
case -1866601742: return bem_otherType_1(bevd_0);
case 607370643: return bem_undefined_1(bevd_0);
case -440299713: return bem_returnTypeSet_1(bevd_0);
case -1537121686: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 607192595: return bem_instOfSet_1(bevd_0);
case -49639172: return bem_intNpSet_1(bevd_0);
case -1816358170: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1137699389: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -906508437: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 384533226: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 853716724: return bem_stringNpSet_1(bevd_0);
case 1745540987: return bem_mnodeSet_1(bevd_0);
case 623479031: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1321282362: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -787961965: return bem_msynSet_1(bevd_0);
case -1773439641: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -465185239: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 177636761: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2034076518: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1758874058: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2126497356: return bem_ntypesSet_1(bevd_0);
case 1638290617: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1191000829: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 890438630: return bem_lastMethodsSizeSet_1(bevd_0);
case 1183921425: return bem_ccMethodsSet_1(bevd_0);
case 293173207: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1048239710: return bem_sameClass_1(bevd_0);
case 1268433926: return bem_otherClass_1(bevd_0);
case 1228328984: return bem_methodsSet_1(bevd_0);
case 1151753978: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1790223428: return bem_falseValueSet_1(bevd_0);
case -1772010664: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1973634449: return bem_onceCountSet_1(bevd_0);
case -541640627: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 868878075: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -997977771: return bem_lastMethodBodySizeSet_1(bevd_0);
case 214740953: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1154914696: return bem_ccCacheSet_1(bevd_0);
case -1422064587: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1372580810: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 186383473: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1665073559: return bem_emitLangSet_1(bevd_0);
case -645360788: return bem_nameToIdSet_1(bevd_0);
case -1562549400: return bem_maxDynArgsSet_1(bevd_0);
case 1964070122: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1613144567: return bem_inFilePathedSet_1(bevd_0);
case -783024285: return bem_methodBodySet_1(bevd_0);
case 1780528695: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1428562405: return bem_parentConfSet_1(bevd_0);
case 2037656549: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 572003245: return bem_instanceEqualSet_1(bevd_0);
case -2029990761: return bem_idToNameSet_1(bevd_0);
case 2108303395: return bem_classEmitsSet_1(bevd_0);
case 1579053823: return bem_sameType_1(bevd_0);
case -940573644: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1349190674: return bem_scvpSet_1(bevd_0);
case -299275246: return bem_begin_1(bevd_0);
case -1447803697: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1118834787: return bem_methodCallsSet_1(bevd_0);
case -299447193: return bem_methodCatchSet_1(bevd_0);
case -1981174775: return bem_buildSet_1(bevd_0);
case -710458807: return bem_qSet_1(bevd_0);
case -349377714: return bem_classesInDepthOrderSet_1(bevd_0);
case 927365089: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 986477958: return bem_defined_1(bevd_0);
case -1911587155: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -611743027: return bem_smnlecsSet_1(bevd_0);
case 1944879783: return bem_floatNpSet_1(bevd_0);
case 1821525677: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 365892884: return bem_classCallsSet_1(bevd_0);
case -1925371554: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1166312533: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 930180418: return bem_copyTo_1(bevd_0);
case -122050504: return bem_lineCountSet_1(bevd_0);
case 136677527: return bem_def_1(bevd_0);
case -459509518: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1337230210: return bem_synEmitPathSet_1(bevd_0);
case 56595084: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2077322811: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -476426819: return bem_libEmitPathSet_1(bevd_0);
case 1948085050: return bem_undef_1(bevd_0);
case -660134131: return bem_onceDecsSet_1(bevd_0);
case -785327205: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1914006567: return bem_cnodeSet_1(bevd_0);
case 496808651: return bem_sameObject_1(bevd_0);
case -216746383: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 429962490: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 13452532: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -648867317: return bem_fullLibEmitNameSet_1(bevd_0);
case 416948777: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -2041096990: return bem_objectNpSet_1(bevd_0);
case 625899149: return bem_end_1(bevd_0);
case -1608394331: return bem_nativeCSlotsSet_1(bevd_0);
case -1261226460: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1965578100: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 4276370: return bem_propertyDecsSet_1(bevd_0);
case 1752266843: return bem_csynSet_1(bevd_0);
case 1990827367: return bem_notEquals_1(bevd_0);
case 1902721446: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 395819644: return bem_smnlcsSet_1(bevd_0);
case 193919560: return bem_instanceNotEqualSet_1(bevd_0);
case -1055565724: return bem_boolCcSet_1(bevd_0);
case -857825492: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1340171620: return bem_boolNpSet_1(bevd_0);
case 311367038: return bem_lastCallSet_1(bevd_0);
case 1214828129: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 556784383: return bem_callNamesSet_1(bevd_0);
case 305359074: return bem_invpSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 790665526: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 893523384: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 889614228: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1848289028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1868949278: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 253281852: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567380424: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1169189267: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1481064275: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1768228505: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -420574345: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -799373164: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -597636505: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 686788947: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1291828708: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -186587836: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2004818542: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1400688487: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 822149033: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1464461405: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -950577436: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -838672589: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 629211509: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 1183339681: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 485130037: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 1294482969: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJVEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
}
}
