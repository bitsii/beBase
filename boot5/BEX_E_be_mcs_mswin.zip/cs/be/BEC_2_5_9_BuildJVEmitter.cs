namespace be {
/* IO:File: source/build/JVEmitter.be */
public sealed class BEC_2_5_9_BuildJVEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
static BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_24, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_26, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_27, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_28, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_31, 14));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_32, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_38, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_39 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_39, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_40 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_41 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_42 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_43 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_44 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_45 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_45, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_46 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_46, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_47 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_48 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_48, 9));
public static new BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static new BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 28 */
bevt_10_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_8_tmpany_phold.bemd_0(-940671822);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_tmpany_phold);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_23_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_23_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_24_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1970659078);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(-787859152);
if (bevl_firstmnsyn.bevi_bool) /* Line: 39 */ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 40 */
 else  /* Line: 41 */ {
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
} /* Line: 42 */
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_28_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevt_27_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 44 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_tmpany_phold);
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_32_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_32_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 51 */ {
bevt_33_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1970659078);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 51 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(-787859152);
if (bevl_firstptsyn.bevi_bool) /* Line: 52 */ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 53 */
 else  /* Line: 54 */ {
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
} /* Line: 55 */
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_37_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 57 */
 else  /* Line: 51 */ {
break;
} /* Line: 51 */
} /* Line: 51 */
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevl_bet.bem_addValue_1(bevt_40_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) bevt_42_tmpany_phold.bem_addValue_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_41_tmpany_phold.bem_addValue_1(bevt_45_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevl_bet.bem_addValue_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_20));
bevl_bet.bem_addValue_1(bevt_47_tmpany_phold);
bevl_tout.bemd_1(219609936, bevl_bet);
bevl_tout.bemd_0(353687009);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-737015107);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1823452387);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 89 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 91 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 104 */
 else  /* Line: 104 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 104 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
return bevt_3_tmpany_phold;
} /* Line: 105 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 111 */
 else  /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 111 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
return bevt_3_tmpany_phold;
} /* Line: 112 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_36));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_37));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_40));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_41));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_42));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_43));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1853084056);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_44));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_47));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 23, 27, 27, 27, 27, 27, 28, 28, 28, 30, 30, 30, 30, 31, 32, 32, 33, 33, 33, 33, 33, 33, 34, 34, 34, 34, 34, 34, 36, 36, 37, 38, 38, 0, 38, 38, 40, 42, 42, 44, 44, 44, 44, 46, 46, 47, 47, 49, 49, 50, 51, 51, 0, 51, 51, 53, 55, 55, 57, 57, 57, 57, 59, 59, 61, 61, 63, 63, 64, 64, 64, 64, 64, 64, 65, 65, 66, 66, 67, 68, 72, 72, 72, 73, 74, 74, 74, 74, 74, 74, 76, 76, 76, 76, 76, 76, 76, 76, 76, 76, 82, 82, 82, 82, 82, 87, 88, 89, 89, 90, 90, 91, 91, 93, 93, 93, 94, 100, 100, 100, 100, 100, 100, 104, 104, 104, 0, 0, 0, 105, 105, 107, 107, 111, 111, 111, 0, 0, 0, 112, 112, 114, 114, 118, 118, 122, 122, 122, 122, 122, 123, 123, 123, 123, 123, 123, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 126, 130, 130, 130, 134, 134, 134, 134, 134, 134, 134, 138, 138, 142, 142, 146, 146, 146, 146};
public static new int[] bevs_smnlec
 = new int[] {76, 77, 78, 79, 137, 138, 139, 140, 145, 146, 147, 148, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 173, 176, 178, 180, 183, 184, 186, 187, 188, 189, 195, 196, 197, 198, 199, 200, 201, 202, 203, 203, 206, 208, 210, 213, 214, 216, 217, 218, 219, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 290, 291, 292, 293, 294, 304, 305, 306, 307, 309, 310, 311, 312, 314, 315, 316, 317, 326, 327, 328, 329, 330, 331, 339, 344, 345, 347, 350, 354, 357, 358, 360, 361, 369, 374, 375, 377, 380, 384, 387, 388, 390, 391, 395, 396, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 445, 446, 447, 456, 457, 458, 459, 460, 461, 462, 466, 467, 471, 472, 478, 479, 480, 481};
/* BEGIN LINEINFO 
assign 1 17 76
new 0 17 76
assign 1 18 77
new 0 18 77
assign 1 19 78
new 0 19 78
new 1 23 79
assign 1 27 137
classDirGet 0 27 137
assign 1 27 138
fileGet 0 27 138
assign 1 27 139
existsGet 0 27 139
assign 1 27 140
not 0 27 145
assign 1 28 146
classDirGet 0 28 146
assign 1 28 147
fileGet 0 28 147
makeDirs 0 28 148
assign 1 30 150
typePathGet 0 30 150
assign 1 30 151
fileGet 0 30 151
assign 1 30 152
writerGet 0 30 152
assign 1 30 153
open 0 30 153
assign 1 31 154
new 0 31 154
assign 1 32 155
new 0 32 155
addValue 1 32 156
assign 1 33 157
new 0 33 157
assign 1 33 158
addValue 1 33 158
assign 1 33 159
typeEmitNameGet 0 33 159
assign 1 33 160
addValue 1 33 160
assign 1 33 161
new 0 33 161
addValue 1 33 162
assign 1 34 163
new 0 34 163
assign 1 34 164
addValue 1 34 164
assign 1 34 165
typeEmitNameGet 0 34 165
assign 1 34 166
addValue 1 34 166
assign 1 34 167
new 0 34 167
addValue 1 34 168
assign 1 36 169
new 0 36 169
addValue 1 36 170
assign 1 37 171
new 0 37 171
assign 1 38 172
mtdListGet 0 38 172
assign 1 38 173
iteratorGet 0 0 173
assign 1 38 176
hasNextGet 0 38 176
assign 1 38 178
nextGet 0 38 178
assign 1 40 180
new 0 40 180
assign 1 42 183
new 0 42 183
addValue 1 42 184
assign 1 44 186
addValue 1 44 186
assign 1 44 187
nameGet 0 44 187
assign 1 44 188
addValue 1 44 188
addValue 1 44 189
assign 1 46 195
new 0 46 195
addValue 1 46 196
assign 1 47 197
new 0 47 197
addValue 1 47 198
assign 1 49 199
new 0 49 199
addValue 1 49 200
assign 1 50 201
new 0 50 201
assign 1 51 202
ptyListGet 0 51 202
assign 1 51 203
iteratorGet 0 0 203
assign 1 51 206
hasNextGet 0 51 206
assign 1 51 208
nextGet 0 51 208
assign 1 53 210
new 0 53 210
assign 1 55 213
new 0 55 213
addValue 1 55 214
assign 1 57 216
addValue 1 57 216
assign 1 57 217
nameGet 0 57 217
assign 1 57 218
addValue 1 57 218
addValue 1 57 219
assign 1 59 225
new 0 59 225
addValue 1 59 226
assign 1 61 227
new 0 61 227
addValue 1 61 228
assign 1 63 229
new 0 63 229
addValue 1 63 230
assign 1 64 231
new 0 64 231
assign 1 64 232
addValue 1 64 232
assign 1 64 233
emitNameGet 0 64 233
assign 1 64 234
addValue 1 64 234
assign 1 64 235
new 0 64 235
addValue 1 64 236
assign 1 65 237
new 0 65 237
addValue 1 65 238
assign 1 66 239
new 0 66 239
addValue 1 66 240
write 1 67 241
close 0 68 242
assign 1 72 263
new 0 72 263
assign 1 72 264
toString 0 72 264
assign 1 72 265
add 1 72 265
incrementValue 0 73 266
assign 1 74 267
new 0 74 267
assign 1 74 268
addValue 1 74 268
assign 1 74 269
addValue 1 74 269
assign 1 74 270
new 0 74 270
assign 1 74 271
addValue 1 74 271
addValue 1 74 272
assign 1 76 273
containedGet 0 76 273
assign 1 76 274
firstGet 0 76 274
assign 1 76 275
containedGet 0 76 275
assign 1 76 276
firstGet 0 76 276
assign 1 76 277
new 0 76 277
assign 1 76 278
add 1 76 278
assign 1 76 279
new 0 76 279
assign 1 76 280
add 1 76 280
assign 1 76 281
finalAssign 4 76 281
addValue 1 76 282
assign 1 82 290
new 0 82 290
assign 1 82 291
add 1 82 291
assign 1 82 292
new 0 82 292
assign 1 82 293
add 1 82 293
return 1 82 294
getInt 2 87 304
assign 1 88 305
toHexString 1 88 305
assign 1 89 306
new 0 89 306
assign 1 89 307
begins 1 89 307
assign 1 90 309
new 0 90 309
assign 1 90 310
substring 1 90 310
assign 1 91 311
new 0 91 311
addValue 1 91 312
assign 1 93 314
new 0 93 314
assign 1 93 315
once 0 93 315
addValue 1 93 316
addValue 1 94 317
assign 1 100 326
new 0 100 326
assign 1 100 327
add 1 100 327
assign 1 100 328
new 0 100 328
assign 1 100 329
add 1 100 329
assign 1 100 330
add 1 100 330
return 1 100 331
assign 1 104 339
def 1 104 344
assign 1 104 345
isFinalGet 0 104 345
assign 1 0 347
assign 1 0 350
assign 1 0 354
assign 1 105 357
new 0 105 357
return 1 105 358
assign 1 107 360
new 0 107 360
return 1 107 361
assign 1 111 369
def 1 111 374
assign 1 111 375
isFinalGet 0 111 375
assign 1 0 377
assign 1 0 380
assign 1 0 384
assign 1 112 387
new 0 112 387
return 1 112 388
assign 1 114 390
new 0 114 390
return 1 114 391
assign 1 118 395
new 0 118 395
return 1 118 396
assign 1 122 418
new 0 122 418
assign 1 122 419
add 1 122 419
assign 1 122 420
new 0 122 420
assign 1 122 421
add 1 122 421
assign 1 122 422
add 1 122 422
assign 1 123 423
new 0 123 423
assign 1 123 424
addValue 1 123 424
assign 1 123 425
addValue 1 123 425
assign 1 123 426
new 0 123 426
assign 1 123 427
addValue 1 123 427
addValue 1 123 428
assign 1 124 429
new 0 124 429
assign 1 124 430
addValue 1 124 430
addValue 1 124 431
assign 1 125 432
new 0 125 432
assign 1 125 433
addValue 1 125 433
assign 1 125 434
outputPlatformGet 0 125 434
assign 1 125 435
nameGet 0 125 435
assign 1 125 436
addValue 1 125 436
assign 1 125 437
new 0 125 437
assign 1 125 438
addValue 1 125 438
addValue 1 125 439
return 1 126 440
assign 1 130 445
libNameGet 0 130 445
assign 1 130 446
beginNs 1 130 446
return 1 130 447
assign 1 134 456
new 0 134 456
assign 1 134 457
libNs 1 134 457
assign 1 134 458
add 1 134 458
assign 1 134 459
new 0 134 459
assign 1 134 460
add 1 134 460
assign 1 134 461
add 1 134 461
return 1 134 462
assign 1 138 466
getNameSpace 1 138 466
return 1 138 467
assign 1 142 471
new 0 142 471
return 1 142 472
assign 1 146 478
new 0 146 478
assign 1 146 479
once 0 146 479
assign 1 146 480
add 1 146 480
return 1 146 481
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1139347757: return bem_invpGetDirect_0();
case 1816783655: return bem_nativeCSlotsGetDirect_0();
case 1907951527: return bem_stringNpGetDirect_0();
case 7734082: return bem_afterCast_0();
case 940184788: return bem_methodCatchGetDirect_0();
case -1358063658: return bem_preClassGet_0();
case 530400823: return bem_qGetDirect_0();
case -1777852726: return bem_buildGet_0();
case -470075469: return bem_classCallsGetDirect_0();
case 47035484: return bem_lineCountGet_0();
case -604312045: return bem_serializationIteratorGet_0();
case 470287058: return bem_smnlecsGet_0();
case 1459865059: return bem_classesInDepthOrderGet_0();
case -684830977: return bem_superNameGet_0();
case 977308545: return bem_superCallsGetDirect_0();
case -1059634948: return bem_maxDynArgsGet_0();
case -1882615792: return bem_endNs_0();
case 252140703: return bem_classConfGet_0();
case -1196005680: return bem_intNpGetDirect_0();
case -71481844: return bem_methodsGetDirect_0();
case -1480313798: return bem_buildClassInfo_0();
case -203814511: return bem_buildCreate_0();
case -1317070320: return bem_lastMethodBodyLinesGetDirect_0();
case 983683129: return bem_methodCallsGet_0();
case -1962310412: return bem_trueValueGet_0();
case 966149554: return bem_create_0();
case 1781107121: return bem_fileExtGet_0();
case -1996071003: return bem_libEmitPathGet_0();
case 426226200: return bem_getLibOutput_0();
case -714559931: return bem_transGet_0();
case -1593837427: return bem_scvpGetDirect_0();
case 787830244: return bem_floatNpGetDirect_0();
case 1743756588: return bem_superCallsGet_0();
case -2072362205: return bem_ccMethodsGetDirect_0();
case -813608062: return bem_falseValueGet_0();
case 359069214: return bem_fullLibEmitNameGetDirect_0();
case 452557879: return bem_constGetDirect_0();
case -1939615901: return bem_boolTypeGet_0();
case 10531470: return bem_randGet_0();
case 770993656: return bem_methodCatchGet_0();
case 1579626562: return bem_instanceEqualGetDirect_0();
case 1583257100: return bem_objectCcGetDirect_0();
case 1790636379: return bem_instOfGet_0();
case 369363591: return bem_emitLangGetDirect_0();
case 1388561436: return bem_propertyDecsGetDirect_0();
case -1794064751: return bem_boolNpGet_0();
case 956350229: return bem_mainOutsideNsGet_0();
case 183496967: return bem_inFilePathedGet_0();
case -613412325: return bem_returnTypeGet_0();
case 1294674671: return bem_callNamesGet_0();
case 210715167: return bem_callNamesGetDirect_0();
case -1861483366: return bem_classConfGetDirect_0();
case 2107059512: return bem_stringNpGet_0();
case 1269634327: return bem_useDynMethodsGet_0();
case 431845152: return bem_mnodeGetDirect_0();
case -1876329144: return bem_spropDecGet_0();
case -987432448: return bem_returnTypeGetDirect_0();
case 739887076: return bem_mainInClassGet_0();
case -309390025: return bem_instanceEqualGet_0();
case 1103606563: return bem_transGetDirect_0();
case -650934309: return bem_nlGetDirect_0();
case 665232487: return bem_fullLibEmitNameGet_0();
case 1805283361: return bem_getClassOutput_0();
case -1029707989: return bem_doEmit_0();
case 1678261270: return bem_print_0();
case 1003812032: return bem_boolNpGetDirect_0();
case 367195678: return bem_once_0();
case 55812595: return bem_serializeToString_0();
case -603538398: return bem_instOfGetDirect_0();
case 1711023311: return bem_propertyDecsGet_0();
case 1762277073: return bem_msynGetDirect_0();
case 1576646826: return bem_instanceNotEqualGet_0();
case -631643244: return bem_mnodeGet_0();
case 1012877640: return bem_buildGetDirect_0();
case 1900212623: return bem_dynMethodsGetDirect_0();
case 682604587: return bem_serializeContents_0();
case -509275270: return bem_lastMethodsLinesGet_0();
case -1883652855: return bem_methodBodyGetDirect_0();
case -678255483: return bem_csynGetDirect_0();
case 1089361705: return bem_mainEndGet_0();
case 627288027: return bem_emitLangGet_0();
case -2040011797: return bem_coanyiantReturnsGet_0();
case -378949346: return bem_lastMethodBodySizeGetDirect_0();
case 2020676935: return bem_parentConfGetDirect_0();
case -434919379: return bem_deserializeClassNameGet_0();
case -1207094476: return bem_emitLib_0();
case -438195274: return bem_scvpGet_0();
case 402201008: return bem_new_0();
case 1665167466: return bem_baseSmtdDecGet_0();
case -1090024470: return bem_maxSpillArgsLenGet_0();
case -1854726950: return bem_echo_0();
case 1866032374: return bem_libEmitNameGetDirect_0();
case -1005333789: return bem_classEmitsGet_0();
case 296501791: return bem_methodsGet_0();
case 2096678845: return bem_floatNpGet_0();
case 241110452: return bem_synEmitPathGetDirect_0();
case -772967023: return bem_classNameGet_0();
case -182421476: return bem_smnlcsGet_0();
case 1198492782: return bem_randGetDirect_0();
case -1475082471: return bem_objectNpGetDirect_0();
case -1975455714: return bem_copy_0();
case -718403278: return bem_onceDecsGetDirect_0();
case -126880906: return bem_trueValueGetDirect_0();
case 1342765490: return bem_toAny_0();
case -1204254465: return bem_overrideMtdDecGet_0();
case 283087372: return bem_lastCallGetDirect_0();
case 152664929: return bem_exceptDecGet_0();
case 748315678: return bem_tagGet_0();
case -1186580929: return bem_nlGet_0();
case 1151504418: return bem_onceDecsGet_0();
case -636994806: return bem_sourceFileNameGet_0();
case 70385265: return bem_dynMethodsGet_0();
case 1925483909: return bem_nameToIdGetDirect_0();
case -1188904885: return bem_libEmitPathGetDirect_0();
case 1315653251: return bem_ccCacheGetDirect_0();
case 1747089880: return bem_lastMethodsLinesGetDirect_0();
case -1273919233: return bem_mainStartGet_0();
case -1795002401: return bem_toString_0();
case 1955607776: return bem_saveSyns_0();
case -2059779627: return bem_nameToIdGet_0();
case 1651663118: return bem_ccCacheGet_0();
case 2015889677: return bem_msynGet_0();
case -750596217: return bem_invpGet_0();
case 308358239: return bem_preClassGetDirect_0();
case -207888508: return bem_falseValueGetDirect_0();
case 755172575: return bem_intNpGet_0();
case -368347729: return bem_fieldNamesGet_0();
case 1779469342: return bem_idToNameGetDirect_0();
case 9957435: return bem_iteratorGet_0();
case 1650341081: return bem_ccMethodsGet_0();
case 465862055: return bem_idToNameGet_0();
case -866322424: return bem_fileExtGetDirect_0();
case 1985899788: return bem_propDecGet_0();
case 296430796: return bem_nativeCSlotsGet_0();
case -554391807: return bem_nullValueGetDirect_0();
case -773204033: return bem_parentConfGet_0();
case 808044123: return bem_hashGet_0();
case 1747469683: return bem_methodCallsGetDirect_0();
case -1984027061: return bem_ntypesGet_0();
case -1310648002: return bem_onceCountGetDirect_0();
case -281087469: return bem_classCallsGet_0();
case -1175832858: return bem_cnodeGetDirect_0();
case 1188404410: return bem_baseMtdDecGet_0();
case 1860492410: return bem_fieldIteratorGet_0();
case -1757210331: return bem_synEmitPathGet_0();
case -326657455: return bem_libEmitNameGet_0();
case 1028346622: return bem_onceCountGet_0();
case -530303553: return bem_maxSpillArgsLenGetDirect_0();
case 1592594976: return bem_inFilePathedGetDirect_0();
case -56781435: return bem_lastMethodBodyLinesGet_0();
case 1700683641: return bem_exceptDecGetDirect_0();
case 456016117: return bem_classesInDepthOrderGetDirect_0();
case 1382521702: return bem_csynGet_0();
case -478539782: return bem_runtimeInitGet_0();
case 1963485430: return bem_lastCallGet_0();
case -1919343483: return bem_typeDecGet_0();
case 1746530572: return bem_objectCcGet_0();
case -984341799: return bem_smnlecsGetDirect_0();
case -1695631552: return bem_cnodeGet_0();
case 654196306: return bem_methodBodyGet_0();
case 1319300127: return bem_boolCcGetDirect_0();
case -1577951795: return bem_initialDecGet_0();
case 2134649702: return bem_ntypesGetDirect_0();
case 1357232580: return bem_lastMethodsSizeGet_0();
case 1929964631: return bem_nullValueGet_0();
case -1619172625: return bem_lastMethodsSizeGetDirect_0();
case 1198814331: return bem_boolCcGet_0();
case 1562079606: return bem_classEndGet_0();
case -655904426: return bem_lineCountGetDirect_0();
case -795684785: return bem_maxDynArgsGetDirect_0();
case 1957997946: return bem_instanceNotEqualGetDirect_0();
case -1991954538: return bem_beginNs_0();
case -64388276: return bem_qGet_0();
case 1244303476: return bem_buildInitial_0();
case 1249433515: return bem_objectNpGet_0();
case 571437736: return bem_smnlcsGetDirect_0();
case 691625003: return bem_constGet_0();
case -656937356: return bem_many_0();
case 311227497: return bem_writeBET_0();
case 1689568493: return bem_lastMethodBodySizeGet_0();
case -1811049952: return bem_classEmitsGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 730550942: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -714900612: return bem_copyTo_1(bevd_0);
case -641539384: return bem_classCallsSetDirect_1(bevd_0);
case -1407720437: return bem_emitLangSetDirect_1(bevd_0);
case -792473190: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1643382985: return bem_exceptDecSetDirect_1(bevd_0);
case -137319224: return bem_transSet_1(bevd_0);
case 1335234110: return bem_boolCcSet_1(bevd_0);
case -2048840242: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1282864319: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -2066666180: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1708940053: return bem_emitLangSet_1(bevd_0);
case -1601936280: return bem_stringNpSet_1(bevd_0);
case 213051901: return bem_instanceNotEqualSet_1(bevd_0);
case 555598568: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 659225506: return bem_invpSet_1(bevd_0);
case -1648051247: return bem_falseValueSet_1(bevd_0);
case 170879458: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 333508666: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -449261471: return bem_lastCallSetDirect_1(bevd_0);
case 395294177: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1289655373: return bem_boolNpSetDirect_1(bevd_0);
case 556591619: return bem_csynSetDirect_1(bevd_0);
case -2086953726: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1116656371: return bem_classConfSet_1(bevd_0);
case -1294000406: return bem_nativeCSlotsSet_1(bevd_0);
case -104275102: return bem_scvpSetDirect_1(bevd_0);
case 303463732: return bem_superCallsSet_1(bevd_0);
case 575544269: return bem_onceCountSet_1(bevd_0);
case 637722919: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 543061021: return bem_otherClass_1(bevd_0);
case 205567965: return bem_scvpSet_1(bevd_0);
case -1166300508: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 1272631429: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1206917441: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -1467557431: return bem_floatNpSet_1(bevd_0);
case 1476129303: return bem_end_1(bevd_0);
case -1765303874: return bem_fileExtSet_1(bevd_0);
case 1289478402: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 1081452193: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1783986070: return bem_nameToIdSet_1(bevd_0);
case -22031345: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1170557007: return bem_instOfSet_1(bevd_0);
case 1877825931: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 425143626: return bem_constSet_1(bevd_0);
case -2073348660: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1229871661: return bem_parentConfSet_1(bevd_0);
case 549544471: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1894301486: return bem_maxSpillArgsLenSet_1(bevd_0);
case 889923320: return bem_instOfSetDirect_1(bevd_0);
case -2068310643: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -246972918: return bem_stringNpSetDirect_1(bevd_0);
case -785727625: return bem_classConfSetDirect_1(bevd_0);
case -991365338: return bem_defined_1(bevd_0);
case 2003522842: return bem_libEmitPathSetDirect_1(bevd_0);
case 1328033233: return bem_ntypesSet_1(bevd_0);
case 671390563: return bem_randSet_1(bevd_0);
case -1783770183: return bem_methodsSetDirect_1(bevd_0);
case -303754582: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -953875144: return bem_methodCatchSetDirect_1(bevd_0);
case -1247734993: return bem_objectCcSet_1(bevd_0);
case 1576942125: return bem_cnodeSetDirect_1(bevd_0);
case 1938576577: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 34050125: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 2140251595: return bem_libEmitPathSet_1(bevd_0);
case 429440566: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1317518937: return bem_smnlcsSetDirect_1(bevd_0);
case -1450904973: return bem_csynSet_1(bevd_0);
case 1614496109: return bem_undef_1(bevd_0);
case 1655175184: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -604407015: return bem_objectCcSetDirect_1(bevd_0);
case 431899033: return bem_maxDynArgsSet_1(bevd_0);
case -2002926219: return bem_inFilePathedSet_1(bevd_0);
case 2117928437: return bem_nameToIdSetDirect_1(bevd_0);
case 1396692188: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 186060927: return bem_classCallsSet_1(bevd_0);
case -1718376413: return bem_trueValueSet_1(bevd_0);
case 565314635: return bem_onceDecsSet_1(bevd_0);
case 257729883: return bem_dynMethodsSetDirect_1(bevd_0);
case -376864195: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1111427568: return bem_boolNpSet_1(bevd_0);
case 56169893: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1691175251: return bem_constSetDirect_1(bevd_0);
case -654167750: return bem_smnlcsSet_1(bevd_0);
case -2116968157: return bem_buildSet_1(bevd_0);
case 1375004649: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -533038129: return bem_returnTypeSet_1(bevd_0);
case 171615032: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1708839603: return bem_idToNameSetDirect_1(bevd_0);
case 1663671048: return bem_nlSet_1(bevd_0);
case 1014228034: return bem_transSetDirect_1(bevd_0);
case 1760207091: return bem_ccCacheSetDirect_1(bevd_0);
case -700310720: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 350775730: return bem_equals_1(bevd_0);
case -37117926: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 629606848: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 109495491: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1395161659: return bem_smnlecsSet_1(bevd_0);
case 727740423: return bem_intNpSet_1(bevd_0);
case 288855088: return bem_instanceEqualSet_1(bevd_0);
case 336492961: return bem_methodCatchSet_1(bevd_0);
case -1284878962: return bem_lineCountSet_1(bevd_0);
case -1219230236: return bem_objectNpSet_1(bevd_0);
case -766024789: return bem_cnodeSet_1(bevd_0);
case 1163078007: return bem_undefined_1(bevd_0);
case -889620628: return bem_instanceEqualSetDirect_1(bevd_0);
case 56466839: return bem_intNpSetDirect_1(bevd_0);
case -1117639049: return bem_returnTypeSetDirect_1(bevd_0);
case -260946842: return bem_buildSetDirect_1(bevd_0);
case 1077864444: return bem_objectNpSetDirect_1(bevd_0);
case 1621186357: return bem_sameType_1(bevd_0);
case 254381216: return bem_idToNameSet_1(bevd_0);
case 794240823: return bem_libEmitNameSetDirect_1(bevd_0);
case 1884865998: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -225173798: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -50488662: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -2090382506: return bem_smnlecsSetDirect_1(bevd_0);
case -958618299: return bem_callNamesSetDirect_1(bevd_0);
case 1030958568: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 102861602: return bem_propertyDecsSet_1(bevd_0);
case -74401655: return bem_ntypesSetDirect_1(bevd_0);
case -429644521: return bem_lastMethodsLinesSet_1(bevd_0);
case -1194473609: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 240572474: return bem_msynSet_1(bevd_0);
case -736245641: return bem_propertyDecsSetDirect_1(bevd_0);
case -1897094521: return bem_methodsSet_1(bevd_0);
case 1793908923: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1448933357: return bem_otherType_1(bevd_0);
case -1450670741: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 2085094379: return bem_parentConfSetDirect_1(bevd_0);
case -247385285: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 389186235: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -363787671: return bem_methodCallsSet_1(bevd_0);
case -1264307363: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1963021507: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 937780890: return bem_boolCcSetDirect_1(bevd_0);
case 1415351516: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1530170371: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1222768982: return bem_fileExtSetDirect_1(bevd_0);
case -1396490651: return bem_synEmitPathSetDirect_1(bevd_0);
case 107205237: return bem_methodCallsSetDirect_1(bevd_0);
case 1876334799: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 827995533: return bem_nullValueSet_1(bevd_0);
case 1267157493: return bem_invpSetDirect_1(bevd_0);
case 1516465713: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 705869794: return bem_synEmitPathSet_1(bevd_0);
case 1748496578: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 2044256967: return bem_ccMethodsSetDirect_1(bevd_0);
case -1008921570: return bem_nullValueSetDirect_1(bevd_0);
case -1633447754: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1987815700: return bem_ccCacheSet_1(bevd_0);
case -2032838205: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1771668309: return bem_methodBodySetDirect_1(bevd_0);
case -333217533: return bem_classEmitsSetDirect_1(bevd_0);
case -1787351288: return bem_inFilePathedSetDirect_1(bevd_0);
case -188544810: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1985826627: return bem_onceDecsSetDirect_1(bevd_0);
case 174213832: return bem_fullLibEmitNameSet_1(bevd_0);
case 730817798: return bem_lastCallSet_1(bevd_0);
case -1727189767: return bem_superCallsSetDirect_1(bevd_0);
case 1341799327: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1647993291: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1034236331: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -31244331: return bem_mnodeSet_1(bevd_0);
case -1860951913: return bem_preClassSetDirect_1(bevd_0);
case 1545454187: return bem_trueValueSetDirect_1(bevd_0);
case -382734338: return bem_libEmitNameSet_1(bevd_0);
case 1661110692: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 769294959: return bem_methodBodySet_1(bevd_0);
case -123377969: return bem_nlSetDirect_1(bevd_0);
case 1196516001: return bem_onceCountSetDirect_1(bevd_0);
case -768250697: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1276725721: return bem_lineCountSetDirect_1(bevd_0);
case 195308005: return bem_sameObject_1(bevd_0);
case -312888315: return bem_callNamesSet_1(bevd_0);
case 1347176330: return bem_preClassSet_1(bevd_0);
case 1227756104: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -68032323: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 703949330: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -653770679: return bem_begin_1(bevd_0);
case -1007540340: return bem_notEquals_1(bevd_0);
case -242669315: return bem_falseValueSetDirect_1(bevd_0);
case 1541009903: return bem_qSetDirect_1(bevd_0);
case 635798688: return bem_lastMethodsSizeSet_1(bevd_0);
case 1327717198: return bem_classEmitsSet_1(bevd_0);
case 970659287: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1289603805: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 267174377: return bem_def_1(bevd_0);
case 1827654563: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 2106293004: return bem_ccMethodsSet_1(bevd_0);
case -465241034: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 888286476: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2103166385: return bem_dynMethodsSet_1(bevd_0);
case 2046442280: return bem_qSet_1(bevd_0);
case -990968588: return bem_classesInDepthOrderSet_1(bevd_0);
case -1593794718: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1000177598: return bem_floatNpSetDirect_1(bevd_0);
case 1244770987: return bem_msynSetDirect_1(bevd_0);
case 1408629426: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1257785763: return bem_exceptDecSet_1(bevd_0);
case 244434823: return bem_randSetDirect_1(bevd_0);
case -373249002: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -2144202949: return bem_sameClass_1(bevd_0);
case -398930446: return bem_mnodeSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 994425705: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -247010836: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1744079452: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1167199079: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1385197575: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1722368159: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 325307565: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1257278658: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2103232385: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -187061774: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 422199506: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1757887935: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 321298888: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -961973758: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1026569298: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1584099228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1917325989: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1833007700: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1280867989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -2132030781: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 30045821: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1473463429: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -8313778: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -16654936: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -989299554: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1549908640: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJVEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
}
