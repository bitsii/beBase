namespace be {
/* IO:File: source/build/JVEmitter.be */
public sealed class BEC_2_5_9_BuildJVEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
static BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_6, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_7, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_8, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_9, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_10, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_12, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_13, 14));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_14, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_20, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_27, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_28, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 9));
public static new BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-778477374);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1799820853);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 46 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 59 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 59 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
return bevt_3_tmpany_phold;
} /* Line: 60 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 66 */
 else  /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 66 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
return bevt_3_tmpany_phold;
} /* Line: 67 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_25));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1714019821);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 23, 27, 27, 27, 28, 29, 29, 29, 29, 29, 29, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 37, 37, 37, 37, 37, 42, 43, 44, 44, 45, 45, 46, 46, 48, 48, 48, 49, 55, 55, 55, 55, 55, 55, 59, 59, 59, 0, 0, 0, 60, 60, 62, 62, 66, 66, 66, 0, 0, 0, 67, 67, 69, 69, 73, 73, 77, 77, 77, 77, 77, 78, 78, 78, 78, 78, 78, 79, 79, 79, 80, 80, 80, 80, 80, 80, 80, 80, 81, 85, 85, 85, 89, 89, 89, 89, 89, 89, 89, 93, 93, 97, 97, 101, 101, 101, 101};
public static new int[] bevs_smnlec
 = new int[] {55, 56, 57, 58, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 106, 107, 108, 109, 110, 120, 121, 122, 123, 125, 126, 127, 128, 130, 131, 132, 133, 142, 143, 144, 145, 146, 147, 155, 160, 161, 163, 166, 170, 173, 174, 176, 177, 185, 190, 191, 193, 196, 200, 203, 204, 206, 207, 211, 212, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 261, 262, 263, 272, 273, 274, 275, 276, 277, 278, 282, 283, 287, 288, 294, 295, 296, 297};
/* BEGIN LINEINFO 
assign 1 17 55
new 0 17 55
assign 1 18 56
new 0 18 56
assign 1 19 57
new 0 19 57
new 1 23 58
assign 1 27 79
new 0 27 79
assign 1 27 80
toString 0 27 80
assign 1 27 81
add 1 27 81
incrementValue 0 28 82
assign 1 29 83
new 0 29 83
assign 1 29 84
addValue 1 29 84
assign 1 29 85
addValue 1 29 85
assign 1 29 86
new 0 29 86
assign 1 29 87
addValue 1 29 87
addValue 1 29 88
assign 1 31 89
containedGet 0 31 89
assign 1 31 90
firstGet 0 31 90
assign 1 31 91
containedGet 0 31 91
assign 1 31 92
firstGet 0 31 92
assign 1 31 93
new 0 31 93
assign 1 31 94
add 1 31 94
assign 1 31 95
new 0 31 95
assign 1 31 96
add 1 31 96
assign 1 31 97
finalAssign 4 31 97
addValue 1 31 98
assign 1 37 106
new 0 37 106
assign 1 37 107
add 1 37 107
assign 1 37 108
new 0 37 108
assign 1 37 109
add 1 37 109
return 1 37 110
getInt 2 42 120
assign 1 43 121
toHexString 1 43 121
assign 1 44 122
new 0 44 122
assign 1 44 123
begins 1 44 123
assign 1 45 125
new 0 45 125
assign 1 45 126
substring 1 45 126
assign 1 46 127
new 0 46 127
addValue 1 46 128
assign 1 48 130
new 0 48 130
assign 1 48 131
once 0 48 131
addValue 1 48 132
addValue 1 49 133
assign 1 55 142
new 0 55 142
assign 1 55 143
add 1 55 143
assign 1 55 144
new 0 55 144
assign 1 55 145
add 1 55 145
assign 1 55 146
add 1 55 146
return 1 55 147
assign 1 59 155
def 1 59 160
assign 1 59 161
isFinalGet 0 59 161
assign 1 0 163
assign 1 0 166
assign 1 0 170
assign 1 60 173
new 0 60 173
return 1 60 174
assign 1 62 176
new 0 62 176
return 1 62 177
assign 1 66 185
def 1 66 190
assign 1 66 191
isFinalGet 0 66 191
assign 1 0 193
assign 1 0 196
assign 1 0 200
assign 1 67 203
new 0 67 203
return 1 67 204
assign 1 69 206
new 0 69 206
return 1 69 207
assign 1 73 211
new 0 73 211
return 1 73 212
assign 1 77 234
new 0 77 234
assign 1 77 235
add 1 77 235
assign 1 77 236
new 0 77 236
assign 1 77 237
add 1 77 237
assign 1 77 238
add 1 77 238
assign 1 78 239
new 0 78 239
assign 1 78 240
addValue 1 78 240
assign 1 78 241
addValue 1 78 241
assign 1 78 242
new 0 78 242
assign 1 78 243
addValue 1 78 243
addValue 1 78 244
assign 1 79 245
new 0 79 245
assign 1 79 246
addValue 1 79 246
addValue 1 79 247
assign 1 80 248
new 0 80 248
assign 1 80 249
addValue 1 80 249
assign 1 80 250
outputPlatformGet 0 80 250
assign 1 80 251
nameGet 0 80 251
assign 1 80 252
addValue 1 80 252
assign 1 80 253
new 0 80 253
assign 1 80 254
addValue 1 80 254
addValue 1 80 255
return 1 81 256
assign 1 85 261
libNameGet 0 85 261
assign 1 85 262
beginNs 1 85 262
return 1 85 263
assign 1 89 272
new 0 89 272
assign 1 89 273
libNs 1 89 273
assign 1 89 274
add 1 89 274
assign 1 89 275
new 0 89 275
assign 1 89 276
add 1 89 276
assign 1 89 277
add 1 89 277
return 1 89 278
assign 1 93 282
getNameSpace 1 93 282
return 1 93 283
assign 1 97 287
new 0 97 287
return 1 97 288
assign 1 101 294
new 0 101 294
assign 1 101 295
once 0 101 295
assign 1 101 296
add 1 101 296
return 1 101 297
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1732940654: return bem_objectNpGet_0();
case 729171382: return bem_objectCcGet_0();
case -718636024: return bem_exceptDecGet_0();
case 3447287: return bem_instOfGet_0();
case -1005732618: return bem_inFilePathedGet_0();
case 441873246: return bem_fieldIteratorGet_0();
case -1040532232: return bem_buildClassInfo_0();
case -13409313: return bem_nameToIdGet_0();
case -1584483641: return bem_intNpGet_0();
case -654710043: return bem_beginNs_0();
case -1948913981: return bem_ccCacheGet_0();
case 364146106: return bem_toString_0();
case 591133328: return bem_once_0();
case 1030306077: return bem_hashGet_0();
case 156988171: return bem_toAny_0();
case 1309851258: return bem_overrideMtdDecGet_0();
case -714096738: return bem_randGet_0();
case 1374004550: return bem_baseMtdDecGet_0();
case 1989259136: return bem_lastMethodBodySizeGet_0();
case -491880145: return bem_synEmitPathGet_0();
case -738137773: return bem_lastMethodsSizeGet_0();
case 1826655669: return bem_echo_0();
case -1023413978: return bem_doEmit_0();
case 1656303252: return bem_classEmitsGet_0();
case 1811681346: return bem_initialDecGet_0();
case 747222940: return bem_serializationIteratorGet_0();
case -386748219: return bem_fullLibEmitNameGet_0();
case 322649560: return bem_getLibOutput_0();
case 560909299: return bem_invpGet_0();
case 138118576: return bem_classNameGet_0();
case -607798108: return bem_floatNpGet_0();
case 1219823831: return bem_ccMethodsGet_0();
case -358514790: return bem_methodCallsGet_0();
case 149781373: return bem_nativeCSlotsGet_0();
case 1778404303: return bem_instanceEqualGet_0();
case -751534347: return bem_tagGet_0();
case 957329597: return bem_propDecGet_0();
case -592117169: return bem_idToNameGet_0();
case 605463834: return bem_sourceFileNameGet_0();
case -1940301178: return bem_falseValueGet_0();
case 733407436: return bem_superCallsGet_0();
case 1587538467: return bem_mainOutsideNsGet_0();
case 1804394239: return bem_create_0();
case -1118433102: return bem_transGet_0();
case -1491732566: return bem_spropDecGet_0();
case -1694865880: return bem_serializeToString_0();
case -71125206: return bem_libEmitNameGet_0();
case 1320026295: return bem_classConfGet_0();
case -2026276038: return bem_classCallsGet_0();
case -1919097234: return bem_fileExtGet_0();
case -1654147388: return bem_onceDecsGet_0();
case 1019599928: return bem_cnodeGet_0();
case -1367463547: return bem_methodBodyGet_0();
case 774868823: return bem_many_0();
case -667617737: return bem_qGet_0();
case 1232567589: return bem_new_0();
case 554723171: return bem_buildInitial_0();
case -1979514180: return bem_preClassGet_0();
case 708383678: return bem_baseSmtdDecGet_0();
case 1220927337: return bem_mainStartGet_0();
case 1871290692: return bem_saveSyns_0();
case -560557009: return bem_scvpGet_0();
case 776743088: return bem_classEndGet_0();
case -45601165: return bem_useDynMethodsGet_0();
case 1462847183: return bem_constGet_0();
case -1647334036: return bem_getClassOutput_0();
case -2094575331: return bem_libEmitPathGet_0();
case 625017088: return bem_csynGet_0();
case 86234609: return bem_print_0();
case -105949083: return bem_methodCatchGet_0();
case 2105037663: return bem_afterCast_0();
case -1756358206: return bem_maxSpillArgsLenGet_0();
case 699093085: return bem_ntypesGet_0();
case 1574644940: return bem_mainInClassGet_0();
case 589863407: return bem_methodsGet_0();
case -1435731577: return bem_boolTypeGet_0();
case -1784276139: return bem_superNameGet_0();
case 1651099395: return bem_copy_0();
case -790189446: return bem_emitLangGet_0();
case 1335363828: return bem_serializeContents_0();
case -1855572123: return bem_nullValueGet_0();
case -1400716789: return bem_trueValueGet_0();
case 1223828744: return bem_buildGet_0();
case 1478752341: return bem_parentConfGet_0();
case 2032036219: return bem_nlGet_0();
case -978572496: return bem_onceCountGet_0();
case 1605588634: return bem_msynGet_0();
case 569610238: return bem_lastCallGet_0();
case -184129290: return bem_mnodeGet_0();
case 532776637: return bem_stringNpGet_0();
case 1901535914: return bem_lastMethodBodyLinesGet_0();
case 236628649: return bem_dynMethodsGet_0();
case -721091398: return bem_boolNpGet_0();
case 1687884132: return bem_endNs_0();
case -1361381128: return bem_lineCountGet_0();
case 143053472: return bem_smnlcsGet_0();
case -630594925: return bem_lastMethodsLinesGet_0();
case -70526524: return bem_buildCreate_0();
case -449808324: return bem_maxDynArgsGet_0();
case 169016919: return bem_deserializeClassNameGet_0();
case 975208845: return bem_propertyDecsGet_0();
case -326592833: return bem_smnlecsGet_0();
case -1599021826: return bem_runtimeInitGet_0();
case 634067175: return bem_mainEndGet_0();
case -1365060571: return bem_coanyiantReturnsGet_0();
case -1519782621: return bem_instanceNotEqualGet_0();
case 983910213: return bem_returnTypeGet_0();
case -1520588861: return bem_callNamesGet_0();
case -1890339853: return bem_classesInDepthOrderGet_0();
case 1243926466: return bem_emitLib_0();
case 173912112: return bem_iteratorGet_0();
case 1277136968: return bem_boolCcGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1140940112: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -2090530601: return bem_onceDecsSet_1(bevd_0);
case -636839339: return bem_superCallsSet_1(bevd_0);
case 1304108631: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1503524032: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -66688367: return bem_sameClass_1(bevd_0);
case 1151922045: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1116228934: return bem_classEmitsSet_1(bevd_0);
case 1575781587: return bem_mnodeSet_1(bevd_0);
case 33129065: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -349044863: return bem_boolCcSet_1(bevd_0);
case -548232463: return bem_copyTo_1(bevd_0);
case 1434375948: return bem_callNamesSet_1(bevd_0);
case -1323662573: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 600600170: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 82861367: return bem_libEmitNameSet_1(bevd_0);
case -876554508: return bem_propertyDecsSet_1(bevd_0);
case -98561877: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1984415476: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -1678014319: return bem_synEmitPathSet_1(bevd_0);
case -90307452: return bem_instOfSet_1(bevd_0);
case 287937278: return bem_lineCountSet_1(bevd_0);
case -1397722618: return bem_dynMethodsSet_1(bevd_0);
case -921349672: return bem_libEmitPathSet_1(bevd_0);
case 359338860: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1487087344: return bem_instanceNotEqualSet_1(bevd_0);
case -551720876: return bem_nullValueSet_1(bevd_0);
case 1532877251: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1582571185: return bem_csynSet_1(bevd_0);
case 233607642: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1818203571: return bem_classConfSet_1(bevd_0);
case 294462964: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 765325805: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -293276429: return bem_undefined_1(bevd_0);
case -1990063745: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -616904416: return bem_inFilePathedSet_1(bevd_0);
case 819280437: return bem_end_1(bevd_0);
case -375639969: return bem_objectNpSet_1(bevd_0);
case 1928405394: return bem_parentConfSet_1(bevd_0);
case 1161170695: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -2078921482: return bem_notEquals_1(bevd_0);
case 143426895: return bem_undef_1(bevd_0);
case -35095050: return bem_nativeCSlotsSet_1(bevd_0);
case 488842286: return bem_begin_1(bevd_0);
case -1865425509: return bem_constSet_1(bevd_0);
case -1213173313: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1388122193: return bem_otherClass_1(bevd_0);
case 1411356925: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1404302063: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 149118077: return bem_lastMethodsLinesSet_1(bevd_0);
case 1653035572: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1265091582: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1735538706: return bem_scvpSet_1(bevd_0);
case 315268700: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1396640529: return bem_exceptDecSet_1(bevd_0);
case -105467376: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1731650047: return bem_instanceEqualSet_1(bevd_0);
case -1266399355: return bem_msynSet_1(bevd_0);
case -1142653112: return bem_invpSet_1(bevd_0);
case -1209387497: return bem_otherType_1(bevd_0);
case -1993173300: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -2077086955: return bem_sameType_1(bevd_0);
case 797836803: return bem_lastCallSet_1(bevd_0);
case 1621694516: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -575142196: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -686472259: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 616720515: return bem_ccMethodsSet_1(bevd_0);
case 906190154: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -729372880: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1130470167: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1044810073: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1808476706: return bem_cnodeSet_1(bevd_0);
case -1611890014: return bem_ntypesSet_1(bevd_0);
case 1206237521: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -158050719: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1522210845: return bem_transSet_1(bevd_0);
case 449552909: return bem_falseValueSet_1(bevd_0);
case -829061445: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 225787566: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -334703106: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1790149278: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -192747533: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 280312858: return bem_sameObject_1(bevd_0);
case 1114729861: return bem_methodsSet_1(bevd_0);
case -453047408: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -554684885: return bem_qSet_1(bevd_0);
case -1267580710: return bem_boolNpSet_1(bevd_0);
case -848281772: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 571886433: return bem_classesInDepthOrderSet_1(bevd_0);
case 1360821872: return bem_maxSpillArgsLenSet_1(bevd_0);
case -854031247: return bem_objectCcSet_1(bevd_0);
case 1180593770: return bem_methodBodySet_1(bevd_0);
case -1364148377: return bem_fileExtSet_1(bevd_0);
case -1661765091: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1634052615: return bem_nlSet_1(bevd_0);
case 1218864027: return bem_methodCallsSet_1(bevd_0);
case 1022281941: return bem_defined_1(bevd_0);
case 1214021205: return bem_randSet_1(bevd_0);
case -2067155306: return bem_stringNpSet_1(bevd_0);
case 150363248: return bem_buildSet_1(bevd_0);
case -1365169308: return bem_idToNameSet_1(bevd_0);
case -1460117009: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1379055081: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 33055222: return bem_trueValueSet_1(bevd_0);
case 20774019: return bem_smnlecsSet_1(bevd_0);
case 1598394081: return bem_emitLangSet_1(bevd_0);
case -1340695890: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1238112711: return bem_returnTypeSet_1(bevd_0);
case 1927271440: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -404853921: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 369525135: return bem_onceCountSet_1(bevd_0);
case 1982783090: return bem_fullLibEmitNameSet_1(bevd_0);
case -976841884: return bem_smnlcsSet_1(bevd_0);
case 1049342566: return bem_equals_1(bevd_0);
case -649102027: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -2130860899: return bem_classCallsSet_1(bevd_0);
case -318083249: return bem_intNpSet_1(bevd_0);
case 1993800313: return bem_maxDynArgsSet_1(bevd_0);
case 2020290960: return bem_nameToIdSet_1(bevd_0);
case 183612822: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -463525639: return bem_preClassSet_1(bevd_0);
case 818668120: return bem_def_1(bevd_0);
case -1223710089: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 34363841: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -956577031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -277366317: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1239994276: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -971746764: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1034888511: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -501927830: return bem_methodCatchSet_1(bevd_0);
case 138491017: return bem_lastMethodsSizeSet_1(bevd_0);
case 1033670526: return bem_ccCacheSet_1(bevd_0);
case -1656667816: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1117440760: return bem_floatNpSet_1(bevd_0);
case -1831997136: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1379006171: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1675250987: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -936134816: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 808469705: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -95724576: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 425324768: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 767399417: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1388760709: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 931943317: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -2032210312: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2037027110: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1685281323: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1382980942: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 2096067718: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -479006870: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2008100452: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -81510774: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1991243589: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -265807180: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2023835460: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1042782680: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -407930979: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1952139460: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1571464192: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -23525186: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 101011800: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -1470538222: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJVEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
}
}
