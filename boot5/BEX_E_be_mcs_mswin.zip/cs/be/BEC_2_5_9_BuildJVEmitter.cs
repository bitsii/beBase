namespace be {
/* IO:File: source/build/JVEmitter.be */
public sealed class BEC_2_5_9_BuildJVEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
static BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_17, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_20, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_22, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_23, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_24, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_26, 14));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_23, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_29, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_36, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_39 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_39, 9));
public static new BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static new BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 26 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 27 */
bevt_10_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_8_tmpany_phold.bemd_0(-159967270);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_tmpany_phold);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_23_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_23_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 37 */ {
bevt_24_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-208048626);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 37 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(-1607847165);
if (bevl_firstmnsyn.bevi_bool) /* Line: 38 */ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 39 */
 else  /* Line: 40 */ {
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
} /* Line: 41 */
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_28_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevt_27_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 43 */
 else  /* Line: 37 */ {
break;
} /* Line: 37 */
} /* Line: 37 */
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_tmpany_phold);
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_32_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_32_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 50 */ {
bevt_33_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-208048626);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(-1607847165);
if (bevl_firstptsyn.bevi_bool) /* Line: 51 */ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 52 */
 else  /* Line: 53 */ {
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
} /* Line: 54 */
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_37_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 56 */
 else  /* Line: 50 */ {
break;
} /* Line: 50 */
} /* Line: 50 */
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_40_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) bevt_42_tmpany_phold.bem_addValue_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevt_41_tmpany_phold.bem_addValue_1(bevt_45_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_47_tmpany_phold);
bevl_tout.bemd_1(1345391050, bevl_bet);
bevl_tout.bemd_0(-2005904560);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(279108248);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(651401246);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 90 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 103 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_tmpany_phold;
} /* Line: 104 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 110 */
 else  /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 110 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_tmpany_phold;
} /* Line: 111 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_28));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-1559730859);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 66, 67, 71, 71, 71, 72, 73, 73, 73, 73, 73, 73, 75, 75, 75, 75, 75, 75, 75, 75, 75, 75, 81, 81, 81, 81, 81, 86, 87, 88, 88, 89, 89, 90, 90, 92, 92, 92, 93, 99, 99, 99, 99, 99, 99, 103, 103, 103, 0, 0, 0, 104, 104, 106, 106, 110, 110, 110, 0, 0, 0, 111, 111, 113, 113, 117, 117, 121, 121, 121, 121, 121, 122, 122, 122, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 124, 124, 124, 124, 125, 129, 129, 129, 133, 133, 133, 133, 133, 133, 133, 137, 137, 141, 141, 145, 145, 145, 145};
public static new int[] bevs_smnlec
 = new int[] {67, 68, 69, 70, 128, 129, 130, 131, 136, 137, 138, 139, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 164, 167, 169, 171, 174, 175, 177, 178, 179, 180, 186, 187, 188, 189, 190, 191, 192, 193, 194, 194, 197, 199, 201, 204, 205, 207, 208, 209, 210, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 281, 282, 283, 284, 285, 295, 296, 297, 298, 300, 301, 302, 303, 305, 306, 307, 308, 317, 318, 319, 320, 321, 322, 330, 335, 336, 338, 341, 345, 348, 349, 351, 352, 360, 365, 366, 368, 371, 375, 378, 379, 381, 382, 386, 387, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 436, 437, 438, 447, 448, 449, 450, 451, 452, 453, 457, 458, 462, 463, 469, 470, 471, 472};
/* BEGIN LINEINFO 
assign 1 16 67
new 0 16 67
assign 1 17 68
new 0 17 68
assign 1 18 69
new 0 18 69
new 1 22 70
assign 1 26 128
classDirGet 0 26 128
assign 1 26 129
fileGet 0 26 129
assign 1 26 130
existsGet 0 26 130
assign 1 26 131
not 0 26 136
assign 1 27 137
classDirGet 0 27 137
assign 1 27 138
fileGet 0 27 138
makeDirs 0 27 139
assign 1 29 141
typePathGet 0 29 141
assign 1 29 142
fileGet 0 29 142
assign 1 29 143
writerGet 0 29 143
assign 1 29 144
open 0 29 144
assign 1 30 145
new 0 30 145
assign 1 31 146
new 0 31 146
addValue 1 31 147
assign 1 32 148
new 0 32 148
assign 1 32 149
addValue 1 32 149
assign 1 32 150
typeEmitNameGet 0 32 150
assign 1 32 151
addValue 1 32 151
assign 1 32 152
new 0 32 152
addValue 1 32 153
assign 1 33 154
new 0 33 154
assign 1 33 155
addValue 1 33 155
assign 1 33 156
typeEmitNameGet 0 33 156
assign 1 33 157
addValue 1 33 157
assign 1 33 158
new 0 33 158
addValue 1 33 159
assign 1 35 160
new 0 35 160
addValue 1 35 161
assign 1 36 162
new 0 36 162
assign 1 37 163
mtdListGet 0 37 163
assign 1 37 164
iteratorGet 0 0 164
assign 1 37 167
hasNextGet 0 37 167
assign 1 37 169
nextGet 0 37 169
assign 1 39 171
new 0 39 171
assign 1 41 174
new 0 41 174
addValue 1 41 175
assign 1 43 177
addValue 1 43 177
assign 1 43 178
nameGet 0 43 178
assign 1 43 179
addValue 1 43 179
addValue 1 43 180
assign 1 45 186
new 0 45 186
addValue 1 45 187
assign 1 46 188
new 0 46 188
addValue 1 46 189
assign 1 48 190
new 0 48 190
addValue 1 48 191
assign 1 49 192
new 0 49 192
assign 1 50 193
ptyListGet 0 50 193
assign 1 50 194
iteratorGet 0 0 194
assign 1 50 197
hasNextGet 0 50 197
assign 1 50 199
nextGet 0 50 199
assign 1 52 201
new 0 52 201
assign 1 54 204
new 0 54 204
addValue 1 54 205
assign 1 56 207
addValue 1 56 207
assign 1 56 208
nameGet 0 56 208
assign 1 56 209
addValue 1 56 209
addValue 1 56 210
assign 1 58 216
new 0 58 216
addValue 1 58 217
assign 1 60 218
new 0 60 218
addValue 1 60 219
assign 1 62 220
new 0 62 220
addValue 1 62 221
assign 1 63 222
new 0 63 222
assign 1 63 223
addValue 1 63 223
assign 1 63 224
emitNameGet 0 63 224
assign 1 63 225
addValue 1 63 225
assign 1 63 226
new 0 63 226
addValue 1 63 227
assign 1 64 228
new 0 64 228
addValue 1 64 229
assign 1 65 230
new 0 65 230
addValue 1 65 231
write 1 66 232
close 0 67 233
assign 1 71 254
new 0 71 254
assign 1 71 255
toString 0 71 255
assign 1 71 256
add 1 71 256
incrementValue 0 72 257
assign 1 73 258
new 0 73 258
assign 1 73 259
addValue 1 73 259
assign 1 73 260
addValue 1 73 260
assign 1 73 261
new 0 73 261
assign 1 73 262
addValue 1 73 262
addValue 1 73 263
assign 1 75 264
containedGet 0 75 264
assign 1 75 265
firstGet 0 75 265
assign 1 75 266
containedGet 0 75 266
assign 1 75 267
firstGet 0 75 267
assign 1 75 268
new 0 75 268
assign 1 75 269
add 1 75 269
assign 1 75 270
new 0 75 270
assign 1 75 271
add 1 75 271
assign 1 75 272
finalAssign 4 75 272
addValue 1 75 273
assign 1 81 281
new 0 81 281
assign 1 81 282
add 1 81 282
assign 1 81 283
new 0 81 283
assign 1 81 284
add 1 81 284
return 1 81 285
getInt 2 86 295
assign 1 87 296
toHexString 1 87 296
assign 1 88 297
new 0 88 297
assign 1 88 298
begins 1 88 298
assign 1 89 300
new 0 89 300
assign 1 89 301
substring 1 89 301
assign 1 90 302
new 0 90 302
addValue 1 90 303
assign 1 92 305
new 0 92 305
assign 1 92 306
once 0 92 306
addValue 1 92 307
addValue 1 93 308
assign 1 99 317
new 0 99 317
assign 1 99 318
add 1 99 318
assign 1 99 319
new 0 99 319
assign 1 99 320
add 1 99 320
assign 1 99 321
add 1 99 321
return 1 99 322
assign 1 103 330
def 1 103 335
assign 1 103 336
isFinalGet 0 103 336
assign 1 0 338
assign 1 0 341
assign 1 0 345
assign 1 104 348
new 0 104 348
return 1 104 349
assign 1 106 351
new 0 106 351
return 1 106 352
assign 1 110 360
def 1 110 365
assign 1 110 366
isFinalGet 0 110 366
assign 1 0 368
assign 1 0 371
assign 1 0 375
assign 1 111 378
new 0 111 378
return 1 111 379
assign 1 113 381
new 0 113 381
return 1 113 382
assign 1 117 386
new 0 117 386
return 1 117 387
assign 1 121 409
new 0 121 409
assign 1 121 410
add 1 121 410
assign 1 121 411
new 0 121 411
assign 1 121 412
add 1 121 412
assign 1 121 413
add 1 121 413
assign 1 122 414
new 0 122 414
assign 1 122 415
addValue 1 122 415
assign 1 122 416
addValue 1 122 416
assign 1 122 417
new 0 122 417
assign 1 122 418
addValue 1 122 418
addValue 1 122 419
assign 1 123 420
new 0 123 420
assign 1 123 421
addValue 1 123 421
addValue 1 123 422
assign 1 124 423
new 0 124 423
assign 1 124 424
addValue 1 124 424
assign 1 124 425
outputPlatformGet 0 124 425
assign 1 124 426
nameGet 0 124 426
assign 1 124 427
addValue 1 124 427
assign 1 124 428
new 0 124 428
assign 1 124 429
addValue 1 124 429
addValue 1 124 430
return 1 125 431
assign 1 129 436
libNameGet 0 129 436
assign 1 129 437
beginNs 1 129 437
return 1 129 438
assign 1 133 447
new 0 133 447
assign 1 133 448
libNs 1 133 448
assign 1 133 449
add 1 133 449
assign 1 133 450
new 0 133 450
assign 1 133 451
add 1 133 451
assign 1 133 452
add 1 133 452
return 1 133 453
assign 1 137 457
getNameSpace 1 137 457
return 1 137 458
assign 1 141 462
new 0 141 462
return 1 141 463
assign 1 145 469
new 0 145 469
assign 1 145 470
once 0 145 470
assign 1 145 471
add 1 145 471
return 1 145 472
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1846899040: return bem_idToNameGetDirect_0();
case 76873786: return bem_mainInClassGet_0();
case 1357873552: return bem_nameToIdGetDirect_0();
case 229408466: return bem_cnodeGet_0();
case 1113652033: return bem_serializeToString_0();
case -1684422920: return bem_objectNpGet_0();
case 709474583: return bem_baseMtdDecGet_0();
case -1059573367: return bem_instOfGet_0();
case 1377426624: return bem_classConfGet_0();
case 1510632885: return bem_randGetDirect_0();
case -1221253364: return bem_fullLibEmitNameGetDirect_0();
case 832627853: return bem_superNameGet_0();
case -1339394055: return bem_objectNpGetDirect_0();
case 1296166147: return bem_methodsGetDirect_0();
case 323047172: return bem_dynMethodsGetDirect_0();
case 1762206048: return bem_stringNpGetDirect_0();
case 495632120: return bem_lastCallGet_0();
case -1595863596: return bem_maxSpillArgsLenGetDirect_0();
case 1602064252: return bem_lastMethodsLinesGetDirect_0();
case -1150501322: return bem_covariantReturnsGet_0();
case -682156546: return bem_randGet_0();
case -2098458378: return bem_ccMethodsGet_0();
case -1823346686: return bem_mainOutsideNsGet_0();
case -1465202398: return bem_msynGet_0();
case 1613497467: return bem_ccCacheGet_0();
case -143829511: return bem_invpGet_0();
case -2027944839: return bem_preClassOutput_0();
case 1577813196: return bem_returnTypeGetDirect_0();
case -2025128778: return bem_parentConfGetDirect_0();
case 114510092: return bem_mainStartGet_0();
case -853943837: return bem_fieldNamesGet_0();
case -140578227: return bem_lineCountGet_0();
case 1585789037: return bem_onceCountGet_0();
case -167780227: return bem_classEmitsGetDirect_0();
case 294922170: return bem_newDecGet_0();
case 1767417060: return bem_buildGetDirect_0();
case -181419195: return bem_dynMethodsGet_0();
case -431559463: return bem_methodCallsGetDirect_0();
case 1219515628: return bem_objectCcGet_0();
case -738802071: return bem_lastMethodsSizeGetDirect_0();
case -451267399: return bem_cnodeGetDirect_0();
case 504430637: return bem_afterCast_0();
case 250094135: return bem_csynGet_0();
case -2047177330: return bem_copy_0();
case -785488955: return bem_libEmitPathGetDirect_0();
case -1396428510: return bem_nlGet_0();
case 669859217: return bem_intNpGetDirect_0();
case 1671726086: return bem_exceptDecGet_0();
case -1549393819: return bem_onceDecsGet_0();
case -1043866834: return bem_deserializeClassNameGet_0();
case -530782275: return bem_classesInDepthOrderGetDirect_0();
case -452396680: return bem_csynGetDirect_0();
case -1188496987: return bem_instanceNotEqualGetDirect_0();
case 2064656313: return bem_scvpGetDirect_0();
case 1855270242: return bem_lastMethodBodyLinesGet_0();
case -1921618565: return bem_transGet_0();
case 1108622817: return bem_smnlcsGet_0();
case 640680765: return bem_libEmitPathGet_0();
case 1614637774: return bem_nameToIdPathGetDirect_0();
case -1350407812: return bem_superCallsGet_0();
case 1779150884: return bem_onceCountGetDirect_0();
case -143076951: return bem_iteratorGet_0();
case 61887666: return bem_instOfGetDirect_0();
case 833980530: return bem_emitLangGetDirect_0();
case -884126314: return bem_classEndGet_0();
case -1068407816: return bem_instanceEqualGet_0();
case 836753320: return bem_lastMethodBodySizeGet_0();
case -1627263789: return bem_methodCallsGet_0();
case -1167299086: return bem_ccMethodsGetDirect_0();
case 419060892: return bem_nullValueGet_0();
case 1806921523: return bem_falseValueGet_0();
case -293607392: return bem_qGet_0();
case -2106504331: return bem_transGetDirect_0();
case 4057483: return bem_toString_0();
case 1277127917: return bem_hashGet_0();
case 1264444719: return bem_classesInDepthOrderGet_0();
case -1236376851: return bem_returnTypeGet_0();
case 487457053: return bem_endNs_0();
case 1321977715: return bem_methodBodyGetDirect_0();
case 1502175986: return bem_buildGet_0();
case -1506468267: return bem_smnlecsGetDirect_0();
case 609707247: return bem_invpGetDirect_0();
case 1073601773: return bem_mnodeGet_0();
case -1249348230: return bem_classConfGetDirect_0();
case -267946766: return bem_synEmitPathGet_0();
case 1702014070: return bem_callNamesGet_0();
case 618140052: return bem_falseValueGetDirect_0();
case -532596532: return bem_idToNamePathGet_0();
case 485739285: return bem_many_0();
case -675377167: return bem_sourceFileNameGet_0();
case 1588913869: return bem_boolNpGet_0();
case 168343024: return bem_buildClassInfo_0();
case 705904898: return bem_echo_0();
case -344044576: return bem_classEmitsGet_0();
case -237211598: return bem_parentConfGet_0();
case -2109114591: return bem_doEmit_0();
case 1463878645: return bem_smnlcsGetDirect_0();
case 2054901149: return bem_gcMarksGet_0();
case 195253847: return bem_initialDecGet_0();
case -539760746: return bem_writeBET_0();
case 1116224194: return bem_ccCacheGetDirect_0();
case -2082702609: return bem_boolTypeGet_0();
case 740377946: return bem_fieldIteratorGet_0();
case 1134970208: return bem_emitLangGet_0();
case 2096290464: return bem_nameToIdGet_0();
case -280538724: return bem_fileExtGet_0();
case 641040592: return bem_inFilePathedGetDirect_0();
case -1248576986: return bem_loadIds_0();
case -564332576: return bem_typeDecGet_0();
case -966686879: return bem_propertyDecsGetDirect_0();
case -1943442917: return bem_qGetDirect_0();
case -55139130: return bem_instanceNotEqualGet_0();
case 1830393821: return bem_serializationIteratorGet_0();
case 512890335: return bem_floatNpGetDirect_0();
case 57907214: return bem_exceptDecGetDirect_0();
case -1637495337: return bem_preClassGet_0();
case 884619386: return bem_gcMarksGetDirect_0();
case -191164624: return bem_methodBodyGet_0();
case 1076786794: return bem_inClassGetDirect_0();
case -976075485: return bem_boolNpGetDirect_0();
case -988239783: return bem_stringNpGet_0();
case 1602596418: return bem_saveSyns_0();
case 308667155: return bem_ntypesGetDirect_0();
case 533589704: return bem_saveIds_0();
case 950936775: return bem_fullLibEmitNameGet_0();
case 1587808125: return bem_belslitsGet_0();
case -106036288: return bem_propDecGet_0();
case 1353167170: return bem_beginNs_0();
case 1730856742: return bem_classCallsGet_0();
case 264763873: return bem_boolCcGetDirect_0();
case -1394167660: return bem_runtimeInitGet_0();
case -468748595: return bem_methodsGet_0();
case 559761641: return bem_synEmitPathGetDirect_0();
case 1561073975: return bem_scvpGet_0();
case -481509271: return bem_new_0();
case -1026589981: return bem_inClassGet_0();
case 689890053: return bem_maxDynArgsGetDirect_0();
case -1914960076: return bem_methodCatchGetDirect_0();
case -149211613: return bem_lineCountGetDirect_0();
case 2042727810: return bem_useDynMethodsGet_0();
case -1599300233: return bem_callNamesGetDirect_0();
case -787376397: return bem_instanceEqualGetDirect_0();
case -939737612: return bem_boolCcGet_0();
case -343248702: return bem_baseSmtdDecGet_0();
case -536512790: return bem_intNpGet_0();
case 933744560: return bem_ntypesGet_0();
case 547585077: return bem_lastMethodBodySizeGetDirect_0();
case 132471678: return bem_getClassOutput_0();
case -950819222: return bem_nativeCSlotsGet_0();
case -983915162: return bem_inFilePathedGet_0();
case -749374888: return bem_toAny_0();
case 135583638: return bem_trueValueGet_0();
case -1939888280: return bem_classNameGet_0();
case 905957116: return bem_create_0();
case 503059124: return bem_mainEndGet_0();
case 789001435: return bem_floatNpGet_0();
case 1581311847: return bem_preClassGetDirect_0();
case 585064756: return bem_maxSpillArgsLenGet_0();
case 805334119: return bem_nativeCSlotsGetDirect_0();
case 1867009434: return bem_getLibOutput_0();
case -363455556: return bem_print_0();
case -883871547: return bem_buildCreate_0();
case -1434220410: return bem_nlGetDirect_0();
case -217401926: return bem_classCallsGetDirect_0();
case -340483923: return bem_lastCallGetDirect_0();
case 1103719598: return bem_spropDecGet_0();
case -1865959264: return bem_lastMethodsLinesGet_0();
case -1617259571: return bem_objectCcGetDirect_0();
case 2143199287: return bem_once_0();
case 379413408: return bem_libEmitNameGetDirect_0();
case -2107073538: return bem_superCallsGetDirect_0();
case 1471556020: return bem_smnlecsGet_0();
case -337666335: return bem_nullValueGetDirect_0();
case -14819109: return bem_idToNamePathGetDirect_0();
case -1129361787: return bem_overrideMtdDecGet_0();
case 714666628: return bem_nameToIdPathGet_0();
case 36838171: return bem_lastMethodsSizeGet_0();
case 427020448: return bem_tagGet_0();
case -710055282: return bem_methodCatchGet_0();
case -1719518447: return bem_trueValueGetDirect_0();
case -1678748769: return bem_propertyDecsGet_0();
case -1658710910: return bem_fileExtGetDirect_0();
case -1775514808: return bem_msynGetDirect_0();
case -2072393051: return bem_constGet_0();
case 2136735414: return bem_libEmitNameGet_0();
case -1802854669: return bem_onceDecsGetDirect_0();
case -1553369659: return bem_lastMethodBodyLinesGetDirect_0();
case -880662208: return bem_emitLib_0();
case -1472731832: return bem_idToNameGet_0();
case -769908714: return bem_serializeContents_0();
case 590906277: return bem_constGetDirect_0();
case -2102124626: return bem_buildInitial_0();
case 1918977083: return bem_maxDynArgsGet_0();
case 167124692: return bem_mnodeGetDirect_0();
case -1053007090: return bem_belslitsGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 611844571: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -834169644: return bem_qSetDirect_1(bevd_0);
case -314934182: return bem_inFilePathedSetDirect_1(bevd_0);
case 1126120407: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1538727717: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1648780077: return bem_trueValueSetDirect_1(bevd_0);
case -1701251195: return bem_smnlcsSetDirect_1(bevd_0);
case -882430471: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -273331434: return bem_boolNpSet_1(bevd_0);
case -990578844: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 419968624: return bem_ntypesSet_1(bevd_0);
case 424556729: return bem_stringNpSetDirect_1(bevd_0);
case -1373802836: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1921392851: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 266682788: return bem_constSet_1(bevd_0);
case 229152099: return bem_lastMethodsSizeSet_1(bevd_0);
case 1704875089: return bem_classConfSetDirect_1(bevd_0);
case 2108263232: return bem_dynMethodsSet_1(bevd_0);
case -559253925: return bem_classEmitsSetDirect_1(bevd_0);
case 925661078: return bem_instanceEqualSetDirect_1(bevd_0);
case 1353862901: return bem_sameType_1(bevd_0);
case 2055426717: return bem_synEmitPathSet_1(bevd_0);
case -1184101107: return bem_instOfSetDirect_1(bevd_0);
case 1643740768: return bem_exceptDecSetDirect_1(bevd_0);
case -1585993690: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -73636763: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1442878986: return bem_methodBodySetDirect_1(bevd_0);
case -1688411590: return bem_lastCallSetDirect_1(bevd_0);
case 692274431: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 182595947: return bem_qSet_1(bevd_0);
case 534246995: return bem_trueValueSet_1(bevd_0);
case -1050156575: return bem_superCallsSetDirect_1(bevd_0);
case 145661116: return bem_nameToIdSet_1(bevd_0);
case -1172047710: return bem_falseValueSetDirect_1(bevd_0);
case -1422490847: return bem_msynSet_1(bevd_0);
case -1884286331: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1028423202: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 115743507: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -627055801: return bem_fullLibEmitNameSet_1(bevd_0);
case 978903343: return bem_propertyDecsSet_1(bevd_0);
case 1758574993: return bem_randSetDirect_1(bevd_0);
case -400505111: return bem_invpSet_1(bevd_0);
case -336416419: return bem_instanceEqualSet_1(bevd_0);
case 1952680700: return bem_preClassSetDirect_1(bevd_0);
case 1699074464: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -578389793: return bem_sameClass_1(bevd_0);
case -1905878683: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1677758672: return bem_gcMarksSetDirect_1(bevd_0);
case 287529310: return bem_stringNpSet_1(bevd_0);
case -1446957724: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 676044605: return bem_ccMethodsSetDirect_1(bevd_0);
case -1221343656: return bem_maxDynArgsSet_1(bevd_0);
case 1684210923: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -195307209: return bem_inClassSet_1(bevd_0);
case 1346394813: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -855876275: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1301220421: return bem_returnTypeSetDirect_1(bevd_0);
case 874993261: return bem_csynSet_1(bevd_0);
case -945352951: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1539493192: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1665146238: return bem_intNpSet_1(bevd_0);
case -1150280805: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1346745011: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -92275306: return bem_constSetDirect_1(bevd_0);
case -1373748328: return bem_mnodeSetDirect_1(bevd_0);
case -13362923: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -988024628: return bem_undef_1(bevd_0);
case 2078552096: return bem_csynSetDirect_1(bevd_0);
case 671555038: return bem_mnodeSet_1(bevd_0);
case 559660088: return bem_idToNamePathSet_1(bevd_0);
case 1945295289: return bem_fileExtSet_1(bevd_0);
case -449810452: return bem_nameToIdPathSetDirect_1(bevd_0);
case 2028580870: return bem_libEmitPathSet_1(bevd_0);
case -89496214: return bem_nameToIdPathSet_1(bevd_0);
case -1037326593: return bem_callNamesSet_1(bevd_0);
case -296199100: return bem_lastMethodsLinesSet_1(bevd_0);
case 2122304776: return bem_equals_1(bevd_0);
case 924399842: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -2004796106: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -2082077824: return bem_ntypesSetDirect_1(bevd_0);
case -499367345: return bem_lastMethodBodySizeSet_1(bevd_0);
case 994381856: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -1520063387: return bem_defined_1(bevd_0);
case 1430681934: return bem_ccMethodsSet_1(bevd_0);
case -1687958050: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -2137592378: return bem_undefined_1(bevd_0);
case -406515744: return bem_methodCallsSetDirect_1(bevd_0);
case -1061467923: return bem_boolCcSetDirect_1(bevd_0);
case 342829387: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1533004654: return bem_propertyDecsSetDirect_1(bevd_0);
case -498298769: return bem_nullValueSet_1(bevd_0);
case -734999168: return bem_idToNamePathSetDirect_1(bevd_0);
case 1605038048: return bem_synEmitPathSetDirect_1(bevd_0);
case -2036688615: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1275734751: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 1474173561: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2042462112: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1954284494: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 706604768: return bem_smnlecsSet_1(bevd_0);
case 461757017: return bem_classCallsSetDirect_1(bevd_0);
case -637326106: return bem_lastCallSet_1(bevd_0);
case -2139990976: return bem_transSet_1(bevd_0);
case 1330475388: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -2021680719: return bem_sameObject_1(bevd_0);
case -265913279: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 507475069: return bem_idToNameSet_1(bevd_0);
case -1524544209: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1828091083: return bem_callNamesSetDirect_1(bevd_0);
case -1766496042: return bem_methodsSet_1(bevd_0);
case -1071341413: return bem_otherType_1(bevd_0);
case -2115588905: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -639896631: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 260228915: return bem_inFilePathedSet_1(bevd_0);
case -1867565756: return bem_floatNpSetDirect_1(bevd_0);
case 1720145474: return bem_objectNpSetDirect_1(bevd_0);
case 1271699637: return bem_libEmitNameSet_1(bevd_0);
case 460673119: return bem_methodCallsSet_1(bevd_0);
case -119282334: return bem_methodCatchSetDirect_1(bevd_0);
case 675790532: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1516820737: return bem_instanceNotEqualSet_1(bevd_0);
case -2105430098: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1021250402: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -2065890988: return bem_superCallsSet_1(bevd_0);
case 1442312172: return bem_idToNameSetDirect_1(bevd_0);
case -1837049300: return bem_parentConfSetDirect_1(bevd_0);
case -282573597: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1266985744: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -670124633: return bem_smnlcsSet_1(bevd_0);
case -126440986: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1273935505: return bem_scvpSet_1(bevd_0);
case -19637806: return bem_begin_1(bevd_0);
case -776114173: return bem_classCallsSet_1(bevd_0);
case -1705758111: return bem_boolCcSet_1(bevd_0);
case -1001083399: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1306058284: return bem_methodCatchSet_1(bevd_0);
case 598908332: return bem_classConfSet_1(bevd_0);
case 1399650093: return bem_instOfSet_1(bevd_0);
case -136446475: return bem_otherClass_1(bevd_0);
case 258543302: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1193690456: return bem_preClassSet_1(bevd_0);
case -248436665: return bem_cnodeSet_1(bevd_0);
case -953111407: return bem_falseValueSet_1(bevd_0);
case -205894114: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1924831101: return bem_copyTo_1(bevd_0);
case 1608935784: return bem_nameToIdSetDirect_1(bevd_0);
case 1831009024: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1141007574: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1290285837: return bem_onceDecsSetDirect_1(bevd_0);
case -877405263: return bem_exceptDecSet_1(bevd_0);
case 1779790976: return bem_end_1(bevd_0);
case 993971214: return bem_objectCcSetDirect_1(bevd_0);
case -590042589: return bem_libEmitPathSetDirect_1(bevd_0);
case -74925333: return bem_onceCountSetDirect_1(bevd_0);
case -1646251641: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1002431850: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -525398079: return bem_classesInDepthOrderSet_1(bevd_0);
case 314414239: return bem_libEmitNameSetDirect_1(bevd_0);
case 8957250: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -383438063: return bem_def_1(bevd_0);
case -1136450381: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1472132223: return bem_nlSet_1(bevd_0);
case 149907039: return bem_lineCountSet_1(bevd_0);
case 210863318: return bem_onceCountSet_1(bevd_0);
case 1674895008: return bem_scvpSetDirect_1(bevd_0);
case 646073156: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -1722427951: return bem_gcMarksSet_1(bevd_0);
case -2013239373: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -364462468: return bem_ccCacheSet_1(bevd_0);
case 671676100: return bem_nlSetDirect_1(bevd_0);
case -845758808: return bem_smnlecsSetDirect_1(bevd_0);
case -140611144: return bem_invpSetDirect_1(bevd_0);
case -188012031: return bem_returnTypeSet_1(bevd_0);
case 1593203405: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 783881278: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 353962780: return bem_msynSetDirect_1(bevd_0);
case 142063796: return bem_onceDecsSet_1(bevd_0);
case -1179856082: return bem_boolNpSetDirect_1(bevd_0);
case 788782659: return bem_buildSetDirect_1(bevd_0);
case 1628369504: return bem_cnodeSetDirect_1(bevd_0);
case -294351701: return bem_parentConfSet_1(bevd_0);
case 930487854: return bem_dynMethodsSetDirect_1(bevd_0);
case 844742473: return bem_ccCacheSetDirect_1(bevd_0);
case 1692488970: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -153134876: return bem_objectCcSet_1(bevd_0);
case 1755877526: return bem_notEquals_1(bevd_0);
case -1709376459: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1894732813: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1330034280: return bem_floatNpSet_1(bevd_0);
case 833745362: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 564624444: return bem_classEmitsSet_1(bevd_0);
case 912679304: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1070273820: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -1711010352: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 506604086: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -841115835: return bem_methodBodySet_1(bevd_0);
case -684491784: return bem_buildSet_1(bevd_0);
case 582015585: return bem_belslitsSet_1(bevd_0);
case -382523434: return bem_transSetDirect_1(bevd_0);
case 1923799998: return bem_belslitsSetDirect_1(bevd_0);
case -1127802964: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 871994817: return bem_emitLangSetDirect_1(bevd_0);
case 1332604899: return bem_fileExtSetDirect_1(bevd_0);
case -1832502281: return bem_nativeCSlotsSet_1(bevd_0);
case -1861940914: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1457008076: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -271328767: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 677668132: return bem_lineCountSetDirect_1(bevd_0);
case -1353579892: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1000789595: return bem_methodsSetDirect_1(bevd_0);
case 845587408: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 468606807: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1642450496: return bem_randSet_1(bevd_0);
case -2029384228: return bem_nullValueSetDirect_1(bevd_0);
case -594161593: return bem_emitLangSet_1(bevd_0);
case 1670673015: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -327098282: return bem_inClassSetDirect_1(bevd_0);
case 1793015591: return bem_intNpSetDirect_1(bevd_0);
case -153804876: return bem_objectNpSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -929921852: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1890404728: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1733569708: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1724500158: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 837534085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2031479556: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -960761832: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 440463842: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 851139439: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -329984355: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 503438982: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 129124545: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1276325839: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -730639571: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -652318534: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -697505666: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1143552272: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 792156527: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -735327143: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1591837072: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1654888978: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -945252568: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1854758105: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1495981429: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1783562120: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -259559018: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -1051213446: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -1152611525: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJVEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
}
