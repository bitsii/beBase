namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_8_NetSocketListener : BEC_2_6_6_SystemObject {
public BEC_3_3_6_8_NetSocketListener() { }
static BEC_3_3_6_8_NetSocketListener() { }

  public Socket bevi_listener;
  private static byte[] becc_BEC_3_3_6_8_NetSocketListener_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x4C,0x69,0x73,0x74,0x65,0x6E,0x65,0x72};
private static byte[] becc_BEC_3_3_6_8_NetSocketListener_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_3_6_8_NetSocketListener_bels_0 = {0x30,0x2E,0x30,0x2E,0x30,0x2E,0x30};
public static new BEC_3_3_6_8_NetSocketListener bece_BEC_3_3_6_8_NetSocketListener_bevs_inst;
public BEC_2_4_6_TextString bevp_address;
public BEC_2_4_3_MathInt bevp_port;
public BEC_2_4_3_MathInt bevp_backlog;
public virtual BEC_3_3_6_8_NetSocketListener bem_new_2(BEC_2_4_6_TextString beva__address, BEC_2_4_3_MathInt beva__port) {
bevp_address = beva__address;
bevp_port = beva__port;
bevp_backlog = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(25));
return this;
} /*method end*/
public virtual BEC_3_3_6_8_NetSocketListener bem_new_1(BEC_2_4_3_MathInt beva__port) {
bevp_address = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_3_3_6_8_NetSocketListener_bels_0));
bevp_port = beva__port;
bevp_backlog = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(25));
return this;
} /*method end*/
public virtual BEC_3_3_6_8_NetSocketListener bem_bind_0() {

    IPHostEntry ipHostInfo = Dns.Resolve(bevp_address.bems_toCsString());
    IPAddress ipAddress = ipHostInfo.AddressList[0];
    IPEndPoint localEndPoint = new IPEndPoint(ipAddress, bevp_port.bevi_int);

    bevi_listener = new Socket(AddressFamily.InterNetwork,
        SocketType.Stream, ProtocolType.Tcp );
    bevi_listener.Bind(localEndPoint);
    bevi_listener.Listen(bevp_backlog.bevi_int);
    return this;
} /*method end*/
public virtual BEC_2_3_6_NetSocket bem_accept_0() {
BEC_2_3_6_NetSocket bevl_s = null;
bevl_s = (BEC_2_3_6_NetSocket) (new BEC_2_3_6_NetSocket());

    bevl_s.bevi_socket = bevi_listener.Accept();
    return bevl_s;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_addressGet_0() {
return bevp_address;
} /*method end*/
public virtual BEC_3_3_6_8_NetSocketListener bem_addressSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_address = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_portGet_0() {
return bevp_port;
} /*method end*/
public virtual BEC_3_3_6_8_NetSocketListener bem_portSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_port = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_backlogGet_0() {
return bevp_backlog;
} /*method end*/
public virtual BEC_3_3_6_8_NetSocketListener bem_backlogSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_backlog = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {607, 608, 609, 616, 617, 618, 643, 654, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 26, 30, 31, 32, 49, 52, 55, 58, 62, 65, 69, 72};
/* BEGIN LINEINFO 
assign 1 607 24
assign 1 608 25
assign 1 609 26
new 0 609 26
assign 1 616 30
new 0 616 30
assign 1 617 31
assign 1 618 32
new 0 618 32
assign 1 643 49
new 0 643 49
return 1 654 52
return 1 0 55
assign 1 0 58
return 1 0 62
assign 1 0 65
return 1 0 69
assign 1 0 72
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1193265838: return bem_new_0();
case 752911959: return bem_hashGet_0();
case -151546855: return bem_accept_0();
case 142206752: return bem_many_0();
case 2141550628: return bem_deserializeClassNameGet_0();
case -1896601781: return bem_toAny_0();
case 1233114754: return bem_backlogGet_0();
case -326646035: return bem_toString_0();
case 2085674875: return bem_echo_0();
case 2098501683: return bem_create_0();
case -2052611744: return bem_once_0();
case -364515046: return bem_fieldIteratorGet_0();
case -1888508563: return bem_serializationIteratorGet_0();
case 444169984: return bem_sourceFileNameGet_0();
case 1310164435: return bem_serializeContents_0();
case -1152001976: return bem_copy_0();
case 1278477757: return bem_serializeToString_0();
case 1211836779: return bem_iteratorGet_0();
case -2091198124: return bem_tagGet_0();
case -1976290782: return bem_print_0();
case 880152096: return bem_classNameGet_0();
case -1451014033: return bem_portGet_0();
case 576901079: return bem_bind_0();
case 820080846: return bem_addressGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1268433926: return bem_otherClass_1(bevd_0);
case -785327205: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 607370643: return bem_undefined_1(bevd_0);
case 1579053823: return bem_sameType_1(bevd_0);
case 1048239710: return bem_sameClass_1(bevd_0);
case -1321282362: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1866601742: return bem_otherType_1(bevd_0);
case 1948085050: return bem_undef_1(bevd_0);
case 986477958: return bem_defined_1(bevd_0);
case 1990827367: return bem_notEquals_1(bevd_0);
case -1773439641: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 275457317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 948293491: return bem_addressSet_1(bevd_0);
case 496808651: return bem_sameObject_1(bevd_0);
case 45057151: return bem_equals_1(bevd_0);
case 136677527: return bem_def_1(bevd_0);
case 930180418: return bem_copyTo_1(bevd_0);
case -1191000829: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2143218985: return bem_portSet_1(bevd_0);
case 395719923: return bem_backlogSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1768228505: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 627553561: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1848289028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 253281852: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1400688487: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 686788947: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 893523384: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1481064275: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(19, becc_BEC_3_3_6_8_NetSocketListener_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_8_NetSocketListener_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_3_6_8_NetSocketListener();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_3_6_8_NetSocketListener.bece_BEC_3_3_6_8_NetSocketListener_bevs_inst = (BEC_3_3_6_8_NetSocketListener) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_3_6_8_NetSocketListener.bece_BEC_3_3_6_8_NetSocketListener_bevs_inst;
}
}
}
