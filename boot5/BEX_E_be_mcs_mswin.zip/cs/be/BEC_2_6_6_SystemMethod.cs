namespace be {
/* IO:File: source/base/Functions.be */
public class BEC_2_6_6_SystemMethod : BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemMethod() { }
static BEC_2_6_6_SystemMethod() { }
private static byte[] becc_BEC_2_6_6_SystemMethod_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_6_6_SystemMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_inst;

public static new BET_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_type;

public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_4_3_MathInt bevp_ac;
public virtual BEC_2_6_6_SystemMethod bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_4_3_MathInt beva__ac) {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_ac = beva__ac;
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(-2039992278, bevp_callName, beva_args);
return bevl_result;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_targetGet_0() {
return bevp_target;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGetDirect_0() {
return bevp_target;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_targetSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_callNameGet_0() {
return bevp_callName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callNameGetDirect_0() {
return bevp_callName;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acGet_0() {
return bevp_ac;
} /*method end*/
public BEC_2_6_6_SystemObject bem_acGetDirect_0() {
return bevp_ac;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_acSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_acSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {37, 38, 39, 45, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 17, 18, 23, 24, 27, 30, 33, 37, 41, 44, 47, 51, 55, 58, 61, 65};
/* BEGIN LINEINFO 
assign 1 37 16
assign 1 38 17
assign 1 39 18
assign 1 45 23
invoke 2 45 23
return 1 46 24
return 1 0 27
return 1 0 30
assign 1 0 33
assign 1 0 37
return 1 0 41
return 1 0 44
assign 1 0 47
assign 1 0 51
return 1 0 55
return 1 0 58
assign 1 0 61
assign 1 0 65
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1649770762: return bem_serializeContents_0();
case 1743657368: return bem_once_0();
case -1460138897: return bem_print_0();
case 641617863: return bem_serializeToString_0();
case 700847419: return bem_iteratorGet_0();
case 1737968596: return bem_callNameGetDirect_0();
case -1477321659: return bem_create_0();
case -1381809993: return bem_deserializeClassNameGet_0();
case -575216772: return bem_hashGet_0();
case -1618775534: return bem_acGetDirect_0();
case 375625109: return bem_copy_0();
case -1758932748: return bem_callNameGet_0();
case -1900966395: return bem_targetGetDirect_0();
case 885190018: return bem_serializationIteratorGet_0();
case 1443037619: return bem_new_0();
case -2071582224: return bem_fieldNamesGet_0();
case -2061644084: return bem_echo_0();
case 1357107465: return bem_many_0();
case 1303816937: return bem_classNameGet_0();
case -1824151510: return bem_sourceFileNameGet_0();
case -241638948: return bem_targetGet_0();
case -954029510: return bem_tagGet_0();
case -167133301: return bem_fieldIteratorGet_0();
case -1062508492: return bem_toAny_0();
case 1507105548: return bem_acGet_0();
case -1111980982: return bem_toString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 902422368: return bem_acSetDirect_1(bevd_0);
case 829192566: return bem_otherClass_1(bevd_0);
case 2028527334: return bem_targetSetDirect_1(bevd_0);
case 1843091865: return bem_notEquals_1(bevd_0);
case 997965949: return bem_sameClass_1(bevd_0);
case 5780175: return bem_callNameSet_1(bevd_0);
case 912665444: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1898752197: return bem_targetSet_1(bevd_0);
case -158486422: return bem_undef_1(bevd_0);
case -860634984: return bem_sameObject_1(bevd_0);
case -961773673: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 227943820: return bem_acSet_1(bevd_0);
case -124594925: return bem_equals_1(bevd_0);
case 623016701: return bem_callNameSetDirect_1(bevd_0);
case 1434062431: return bem_defined_1(bevd_0);
case -536053857: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1171201188: return bem_sameType_1(bevd_0);
case -240276616: return bem_def_1(bevd_0);
case -2012223833: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1650435450: return bem_undefined_1(bevd_0);
case 1081114988: return bem_copyTo_1(bevd_0);
case -2012960734: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1783314567: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -749136313: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1365145554: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1346654676: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1957573480: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039992278: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1347676005: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1466324556: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemMethod_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_6_SystemMethod_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemMethod();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst = (BEC_2_6_6_SystemMethod) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_type;
}
}
}
