namespace be {
/* IO:File: source/base/Functions.be */
public class BEC_2_6_6_SystemMethod : BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemMethod() { }
static BEC_2_6_6_SystemMethod() { }
private static byte[] becc_BEC_2_6_6_SystemMethod_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_6_6_SystemMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_inst;

public static new BET_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_type;

public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_4_3_MathInt bevp_ac;
public virtual BEC_2_6_6_SystemMethod bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_4_3_MathInt beva__ac) {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_ac = beva__ac;
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(-897682046, bevp_callName, beva_args);
return bevl_result;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_targetGet_0() {
return bevp_target;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGetDirect_0() {
return bevp_target;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_targetSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_callNameGet_0() {
return bevp_callName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callNameGetDirect_0() {
return bevp_callName;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acGet_0() {
return bevp_ac;
} /*method end*/
public BEC_2_6_6_SystemObject bem_acGetDirect_0() {
return bevp_ac;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_acSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_acSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {37, 38, 39, 48, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 17, 18, 23, 24, 27, 30, 33, 37, 41, 44, 47, 51, 55, 58, 61, 65};
/* BEGIN LINEINFO 
assign 1 37 16
assign 1 38 17
assign 1 39 18
assign 1 48 23
invoke 2 48 23
return 1 49 24
return 1 0 27
return 1 0 30
assign 1 0 33
assign 1 0 37
return 1 0 41
return 1 0 44
assign 1 0 47
assign 1 0 51
return 1 0 55
return 1 0 58
assign 1 0 61
assign 1 0 65
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1293918813: return bem_targetGetDirect_0();
case 1546544584: return bem_serializationIteratorGet_0();
case -576381863: return bem_callNameGet_0();
case -630280728: return bem_copy_0();
case -576816204: return bem_sourceFileNameGet_0();
case 1438915338: return bem_once_0();
case -1409233752: return bem_toAny_0();
case -695733973: return bem_hashGet_0();
case -373483362: return bem_classNameGet_0();
case -1847620794: return bem_iteratorGet_0();
case 1353407340: return bem_acGetDirect_0();
case 1945803401: return bem_print_0();
case 2077439649: return bem_callNameGetDirect_0();
case -830733381: return bem_echo_0();
case 1606642997: return bem_new_0();
case 167399763: return bem_deserializeClassNameGet_0();
case 2086474367: return bem_create_0();
case 1169011989: return bem_toString_0();
case -686990067: return bem_acGet_0();
case 1425790109: return bem_fieldIteratorGet_0();
case -408522205: return bem_serializeContents_0();
case 2034825137: return bem_tagGet_0();
case 1318436666: return bem_targetGet_0();
case -2084016052: return bem_serializeToString_0();
case 1738591028: return bem_fieldNamesGet_0();
case 1066489349: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1642039472: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2045883718: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 876386412: return bem_sameObject_1(bevd_0);
case -2073425080: return bem_sameType_1(bevd_0);
case 517277297: return bem_targetSet_1(bevd_0);
case -1371116116: return bem_otherClass_1(bevd_0);
case -85967812: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 575763691: return bem_undefined_1(bevd_0);
case 232552830: return bem_otherType_1(bevd_0);
case 1790575350: return bem_sameClass_1(bevd_0);
case -1663786357: return bem_equals_1(bevd_0);
case 90745767: return bem_acSet_1(bevd_0);
case 1449183263: return bem_notEquals_1(bevd_0);
case -1854318841: return bem_copyTo_1(bevd_0);
case -337480346: return bem_targetSetDirect_1(bevd_0);
case 542523031: return bem_defined_1(bevd_0);
case -558625820: return bem_callNameSetDirect_1(bevd_0);
case 491873122: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -839893371: return bem_callNameSet_1(bevd_0);
case -1377779865: return bem_acSetDirect_1(bevd_0);
case -463115686: return bem_def_1(bevd_0);
case -726390043: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1558133875: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -897682046: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 990151340: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600497328: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 116337276: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2028666619: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1471832670: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1676750628: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemMethod_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_6_SystemMethod_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemMethod();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst = (BEC_2_6_6_SystemMethod) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_type;
}
}
}
