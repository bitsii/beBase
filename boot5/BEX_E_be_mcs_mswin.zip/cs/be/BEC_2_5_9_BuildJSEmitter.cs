namespace be {
/* IO:File: source/build/JSEmitter.be */
public sealed class BEC_2_5_9_BuildJSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
static BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_7, 8));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_8, 9));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_14, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_15, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_31, 10));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_42, 6));
private static BEC_2_4_3_MathInt bece_BEC_2_5_9_BuildJSEmitter_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x65,0x6D,0x62,0x50,0x6C,0x61,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_47, 7));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_55, 25));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_56, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_58, 17));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_20, 3));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 38));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_60, 21));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_62, 23));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_63, 27));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_23, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_64, 32));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_23, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_67, 6));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_68, 15));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_69, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_70, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_71, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_74, 7));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_75, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_76, 31));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_77, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_80 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_80, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_81 = {0x62,0x65};
public static new BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static new BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_formTarg_1(beva_node);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_invp);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_0;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_1;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_2;
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1599063965);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1117833636);
bevt_14_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_3;
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_4;
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(beva_belsName);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(bevt_3_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-932925423);
bevt_9_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_ta_ph );
bevt_12_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_12_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_14_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(-940042464);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 81*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(-1024297580);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 81*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(-12961780);
if (bevl_first.bevi_bool)/* Line: 82*/ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 83*/
 else /* Line: 84*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevp_ccMethods.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 85*/
bevt_9_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevt_9_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_7_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 87*/
 else /* Line: 81*/ {
break;
} /* Line: 81*/
} /* Line: 81*/
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-932925423);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_4_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_9_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_13_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_11_ta_ph = (BEC_2_4_6_TextString) bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_17_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) bevt_17_ta_ph.bem_addValue_1(bevl_stinst);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_15_ta_ph = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_20_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_21_ta_ph);
bevt_20_ta_ph.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_0_ta_ph = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 131*/ {
bevt_2_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_5;
bevt_3_ta_ph = beva_v.bem_nameGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 132*/
bevt_4_ta_ph = base.bem_nameForVar_1(beva_v);
return bevt_4_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_7_TextStrings bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_7_TextStrings bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_7_TextStrings bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_7_TextStrings bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_5_4_LogicBool bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_81_ta_ph = null;
BEC_2_4_3_MathInt bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_4_6_TextString bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_6_6_SystemObject bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_5_4_LogicBool bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_4_6_TextString bevt_114_ta_ph = null;
BEC_2_5_4_LogicBool bevt_115_ta_ph = null;
BEC_2_5_4_LogicBool bevt_116_ta_ph = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
/* Line: 148*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(-1024297580);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 148*/ {
bevl_clnode = bevl_ci.bemd_0(-12961780);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_9_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevp_q);
bevt_12_ta_ph = bevl_clnode.bemd_0(1712678790);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(-932925423);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-1990292643);
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevp_q);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_17_ta_ph = bevl_clnode.bemd_0(1712678790);
bevt_16_ta_ph = bevt_17_ta_ph.bemd_0(-932925423);
bevt_15_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_ta_ph );
bevt_18_ta_ph = bevp_build.bem_libNameGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_relEmitName_1(bevt_18_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_34));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_22_ta_ph = bevl_clnode.bemd_0(1712678790);
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(-940042464);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(1764425778);
if (((BEC_2_5_4_LogicBool) bevt_20_ta_ph).bevi_bool)/* Line: 154*/ {
bevt_24_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_6;
bevt_28_ta_ph = bevl_clnode.bemd_0(1712678790);
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(-932925423);
bevt_26_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_ta_ph );
bevt_29_ta_ph = bevp_build.bem_libNameGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bem_relEmitName_1(bevt_29_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_30_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_7;
bevl_nc = bevt_23_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_34_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_33_ta_ph = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_34_ta_ph);
bevt_32_ta_ph = (BEC_2_4_6_TextString) bevt_33_ta_ph.bem_addValue_1(bevl_nc);
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_31_ta_ph = (BEC_2_4_6_TextString) bevt_32_ta_ph.bem_addValue_1(bevt_35_ta_ph);
bevt_31_ta_ph.bem_addValue_1(bevp_nl);
bevt_38_ta_ph = bevl_clnode.bemd_0(1712678790);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_0(-940042464);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(1764425778);
if (((BEC_2_5_4_LogicBool) bevt_36_ta_ph).bevi_bool)/* Line: 163*/ {
bevt_42_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_41_ta_ph = (BEC_2_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_42_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) bevt_41_ta_ph.bem_addValue_1(bevl_nc);
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_39_ta_ph = (BEC_2_4_6_TextString) bevt_40_ta_ph.bem_addValue_1(bevt_43_ta_ph);
bevt_39_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 164*/
} /* Line: 163*/
} /* Line: 154*/
 else /* Line: 148*/ {
break;
} /* Line: 148*/
} /* Line: 148*/
bevl_smap = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_ta_ph = bevp_smnlcs.bem_keysGet_0();
bevt_0_ta_loop = bevt_44_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 172*/ {
bevt_45_ta_ph = bevt_0_ta_loop.bemd_0(-1024297580);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 172*/ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-12961780);
bevt_53_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_52_ta_ph = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_53_ta_ph);
bevt_55_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_54_ta_ph = bevt_55_ta_ph.bem_quoteGet_0();
bevt_51_ta_ph = (BEC_2_4_6_TextString) bevt_52_ta_ph.bem_addValue_1(bevt_54_ta_ph);
bevt_50_ta_ph = (BEC_2_4_6_TextString) bevt_51_ta_ph.bem_addValue_1(bevl_smk);
bevt_57_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_56_ta_ph = bevt_57_ta_ph.bem_quoteGet_0();
bevt_49_ta_ph = (BEC_2_4_6_TextString) bevt_50_ta_ph.bem_addValue_1(bevt_56_ta_ph);
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_48_ta_ph = (BEC_2_4_6_TextString) bevt_49_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_59_ta_ph = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_ta_ph = (BEC_2_4_6_TextString) bevt_48_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_60_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_46_ta_ph = (BEC_2_4_6_TextString) bevt_47_ta_ph.bem_addValue_1(bevt_60_ta_ph);
bevt_46_ta_ph.bem_addValue_1(bevp_nl);
bevt_68_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_67_ta_ph = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_68_ta_ph);
bevt_70_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_69_ta_ph = bevt_70_ta_ph.bem_quoteGet_0();
bevt_66_ta_ph = (BEC_2_4_6_TextString) bevt_67_ta_ph.bem_addValue_1(bevt_69_ta_ph);
bevt_65_ta_ph = (BEC_2_4_6_TextString) bevt_66_ta_ph.bem_addValue_1(bevl_smk);
bevt_72_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_71_ta_ph = bevt_72_ta_ph.bem_quoteGet_0();
bevt_64_ta_ph = (BEC_2_4_6_TextString) bevt_65_ta_ph.bem_addValue_1(bevt_71_ta_ph);
bevt_73_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_63_ta_ph = (BEC_2_4_6_TextString) bevt_64_ta_ph.bem_addValue_1(bevt_73_ta_ph);
bevt_74_ta_ph = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_ta_ph = (BEC_2_4_6_TextString) bevt_63_ta_ph.bem_addValue_1(bevt_74_ta_ph);
bevt_75_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_61_ta_ph = (BEC_2_4_6_TextString) bevt_62_ta_ph.bem_addValue_1(bevt_75_ta_ph);
bevt_61_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 175*/
 else /* Line: 172*/ {
break;
} /* Line: 172*/
} /* Line: 172*/
bevt_77_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_78_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_8;
bevt_76_ta_ph = bevt_77_ta_ph.bem_has_1(bevt_78_ta_ph);
if (!(bevt_76_ta_ph.bevi_bool))/* Line: 179*/ {
bevl_libe.bem_write_1(bevl_smap);
} /* Line: 180*/
bevt_81_ta_ph = bevp_build.bem_usedLibrarysGet_0();
bevt_80_ta_ph = bevt_81_ta_ph.bem_sizeGet_0();
bevt_82_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_9;
if (bevt_80_ta_ph.bevi_int == bevt_82_ta_ph.bevi_int) {
bevt_79_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_79_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_79_ta_ph.bevi_bool)/* Line: 184*/ {
bevt_84_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_83_ta_ph = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_84_ta_ph);
bevt_83_ta_ph.bem_addValue_1(bevp_nl);
bevt_86_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_85_ta_ph = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_86_ta_ph);
bevt_85_ta_ph.bem_addValue_1(bevp_nl);
bevt_88_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_87_ta_ph = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_88_ta_ph);
bevt_87_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 187*/
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_89_ta_ph = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_89_ta_ph);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevt_93_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_92_ta_ph = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_93_ta_ph);
bevt_94_ta_ph = bevl_maincc.bem_fullEmitNameGet_0();
bevt_91_ta_ph = (BEC_2_4_6_TextString) bevt_92_ta_ph.bem_addValue_1(bevt_94_ta_ph);
bevt_95_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_90_ta_ph = (BEC_2_4_6_TextString) bevt_91_ta_ph.bem_addValue_1(bevt_95_ta_ph);
bevt_90_ta_ph.bem_addValue_1(bevp_nl);
bevt_96_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_96_ta_ph.bevi_bool)/* Line: 200*/ {
bevt_98_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_99_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_10;
bevt_97_ta_ph = bevt_98_ta_ph.bem_has_1(bevt_99_ta_ph);
if (!(bevt_97_ta_ph.bevi_bool))/* Line: 201*/ {
bevt_101_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_100_ta_ph = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_101_ta_ph);
bevt_100_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 202*/
} /* Line: 201*/
bevt_105_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_104_ta_ph = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_105_ta_ph);
bevt_107_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_106_ta_ph = bevt_107_ta_ph.bemd_0(-916206427);
bevt_103_ta_ph = (BEC_2_4_6_TextString) bevt_104_ta_ph.bem_addValue_1(bevt_106_ta_ph);
bevt_108_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_102_ta_ph = (BEC_2_4_6_TextString) bevt_103_ta_ph.bem_addValue_1(bevt_108_ta_ph);
bevt_102_ta_ph.bem_addValue_1(bevp_nl);
bevt_109_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_109_ta_ph.bevi_bool)/* Line: 206*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 207*/
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_110_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_110_ta_ph.bevi_bool)/* Line: 212*/ {
bevt_112_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_111_ta_ph = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_112_ta_ph);
bevt_111_ta_ph.bem_addValue_1(bevp_nl);
bevt_114_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_113_ta_ph = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_114_ta_ph);
bevt_113_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 214*/
bevt_115_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_115_ta_ph.bevi_bool)/* Line: 216*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 217*/
bem_finishLibOutput_1(bevl_libe);
bevt_116_ta_ph = bevp_build.bem_saveSynsGet_0();
if (bevt_116_ta_ph.bevi_bool)/* Line: 222*/ {
bem_saveSyns_0();
} /* Line: 223*/
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 229*/ {
} /* Line: 229*/
 else /* Line: 231*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 232*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
beva_b.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 233*/
bevt_4_ta_ph = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 235*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_54));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_11;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_exceptDec);
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_12;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_13;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_parent);
bevt_5_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_14;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_5_ta_ph);
bevl_extstr = (BEC_2_4_6_TextString) bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_8_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_7_ta_ph = bevl_extstr.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_15;
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevl_extstr = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_16;
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_17;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-746801720);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_18;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_19;
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_20;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-746801720);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_21;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
if (beva_isOnce.bevi_bool)/* Line: 266*/ {
bevt_8_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_22;
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_23;
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_13_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_24;
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(beva_belsName);
bevt_14_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_25;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_15_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_26;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_15_ta_ph);
return bevt_0_ta_ph;
} /* Line: 267*/
bevt_24_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_27;
bevt_26_ta_ph = bevp_build.bem_libNameGet_0();
bevt_25_ta_ph = beva_newcc.bem_relEmitName_1(bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_27_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_28;
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_29_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_29;
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(beva_belsName);
bevt_30_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_30;
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(beva_lisz);
bevt_31_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_31;
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_31_ta_ph);
return bevt_16_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 273*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 274*/
 else /* Line: 275*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 276*/
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_6_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_66));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_9_ta_ph);
bevt_8_ta_ph.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public override BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1656824459);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 292*/ {
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_notEmpty_1(beva_callArgs);
if (bevt_2_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_32;
beva_callArgs = bevt_4_ta_ph.bem_add_1(beva_callArgs);
} /* Line: 294*/
 else /* Line: 295*/ {
beva_callArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
} /* Line: 296*/
bevt_10_ta_ph = bevp_parentConf.bem_emitNameGet_0();
bevt_11_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_33;
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(-916206427);
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_34;
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_callArgs);
bevt_15_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_35;
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_15_ta_ph);
return bevt_5_ta_ph;
} /* Line: 298*/
bevt_21_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_36;
bevt_20_ta_ph = beva_callTarget.bem_add_1(bevt_21_ta_ph);
bevt_23_ta_ph = beva_node.bem_heldGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(-916206427);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_22_ta_ph);
bevt_24_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_37;
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(beva_callArgs);
bevt_25_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_38;
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_25_ta_ph);
return bevt_16_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevl_end;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_allOnceDecs == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 312*/ {
bevp_allOnceDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 313*/
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_ta_ph;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_3_2_4_6_IOFileWriter bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getLibOutput_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_13_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
if (bevp_shlibe == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 329*/ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_7_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 332*/
bevt_9_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_ta_ph.bemd_0(1244458922);
bevt_11_ta_ph = bevp_build.bem_paramsGet_0();
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_72));
bevt_10_ta_ph = bevt_11_ta_ph.bem_has_1(bevt_12_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_14_ta_ph = bevp_build.bem_paramsGet_0();
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_72));
bevt_13_ta_ph = bevt_14_ta_ph.bem_get_1(bevt_15_ta_ph);
bevt_0_ta_loop = bevt_13_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 337*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bemd_0(-1024297580);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 337*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-12961780);
bevt_17_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(1244458922);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_ta_ph.bemd_0(258173973);
bevt_20_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph.bemd_0(966177429);
bevt_21_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 342*/
 else /* Line: 337*/ {
break;
} /* Line: 337*/
} /* Line: 337*/
} /* Line: 337*/
} /* Line: 336*/
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_73));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_spropDecGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_39;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_anyName);
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_40;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_typeName);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = beva_newcc.bem_relEmitName_1(bevt_2_ta_ph);
bevt_3_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_41;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_42;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_43;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_count);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_78));
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_79));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_7_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_44;
bevt_1_ta_ph = beva_nameSpace.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_emitName);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_81));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = base.bem_getClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = base.bem_getLocalClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGetDirect_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 17, 18, 22, 24, 25, 27, 28, 32, 32, 32, 36, 36, 36, 36, 40, 40, 40, 40, 44, 44, 44, 44, 44, 44, 44, 44, 48, 48, 48, 49, 50, 50, 50, 50, 50, 50, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 63, 63, 63, 63, 63, 63, 63, 67, 67, 67, 67, 67, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 70, 70, 70, 75, 75, 76, 78, 78, 78, 78, 80, 81, 0, 81, 81, 83, 85, 85, 87, 87, 87, 87, 87, 87, 91, 91, 91, 96, 96, 96, 97, 99, 99, 99, 99, 99, 102, 102, 102, 102, 104, 104, 104, 106, 106, 106, 106, 106, 109, 109, 109, 109, 109, 109, 111, 111, 111, 113, 118, 119, 120, 126, 126, 126, 131, 132, 132, 132, 132, 134, 134, 143, 145, 146, 147, 148, 148, 150, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 154, 154, 154, 156, 156, 156, 156, 156, 156, 156, 156, 156, 162, 162, 162, 162, 162, 162, 163, 163, 163, 164, 164, 164, 164, 164, 164, 170, 172, 172, 0, 172, 172, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 179, 179, 179, 180, 184, 184, 184, 184, 184, 185, 185, 185, 186, 186, 186, 187, 187, 187, 190, 191, 194, 195, 195, 196, 198, 199, 199, 199, 199, 199, 199, 199, 200, 201, 201, 201, 202, 202, 202, 205, 205, 205, 205, 205, 205, 205, 205, 206, 207, 209, 210, 211, 212, 213, 213, 213, 214, 214, 214, 216, 217, 220, 222, 223, 229, 232, 232, 232, 233, 233, 235, 235, 240, 240, 244, 244, 244, 244, 244, 244, 248, 248, 252, 252, 252, 252, 252, 252, 252, 253, 253, 253, 253, 253, 254, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 273, 273, 274, 274, 274, 276, 276, 278, 278, 278, 278, 278, 286, 286, 286, 287, 288, 292, 292, 293, 293, 294, 294, 296, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 304, 305, 312, 312, 313, 315, 316, 316, 321, 321, 329, 329, 330, 331, 331, 331, 331, 331, 332, 332, 332, 334, 334, 334, 336, 336, 336, 337, 337, 337, 337, 0, 337, 337, 338, 338, 339, 339, 339, 340, 340, 341, 341, 342, 348, 352, 353, 358, 358, 362, 362, 366, 366, 370, 370, 374, 374, 378, 378, 382, 382, 387, 387, 393, 393, 398, 398, 402, 402, 402, 402, 402, 402, 406, 406, 410, 410, 410, 410, 410, 415, 415, 415, 415, 415, 415, 415, 420, 420, 420, 420, 420, 420, 420, 422, 424, 424, 424, 429, 429, 433, 433, 437, 437, 437, 437, 442, 442, 446, 447, 447, 448, 452, 453, 453, 454, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {142, 143, 144, 145, 146, 147, 148, 149, 155, 156, 157, 163, 164, 165, 166, 172, 173, 174, 175, 185, 186, 187, 188, 189, 190, 191, 192, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 245, 246, 247, 248, 249, 250, 251, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 311, 312, 313, 314, 315, 316, 317, 318, 319, 319, 322, 324, 326, 329, 330, 332, 333, 334, 335, 336, 337, 343, 344, 345, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 408, 409, 410, 416, 417, 418, 427, 429, 430, 431, 432, 434, 435, 570, 571, 572, 573, 574, 577, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 622, 623, 624, 625, 626, 627, 635, 636, 637, 637, 640, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 680, 681, 682, 684, 686, 687, 688, 689, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 721, 722, 723, 725, 726, 727, 730, 731, 732, 733, 734, 735, 736, 737, 738, 740, 742, 743, 744, 745, 747, 748, 749, 750, 751, 752, 754, 756, 758, 759, 761, 771, 775, 776, 781, 782, 783, 785, 786, 792, 793, 801, 802, 803, 804, 805, 806, 810, 811, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 972, 977, 978, 979, 980, 983, 984, 986, 987, 988, 989, 990, 991, 992, 993, 994, 995, 1024, 1025, 1027, 1028, 1030, 1031, 1034, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1063, 1064, 1069, 1074, 1075, 1077, 1078, 1079, 1083, 1084, 1115, 1120, 1121, 1122, 1123, 1124, 1125, 1130, 1131, 1132, 1133, 1135, 1136, 1137, 1138, 1139, 1140, 1142, 1143, 1144, 1145, 1145, 1148, 1150, 1151, 1152, 1153, 1154, 1155, 1156, 1157, 1158, 1159, 1160, 1168, 1171, 1172, 1177, 1178, 1182, 1183, 1187, 1188, 1192, 1193, 1197, 1198, 1202, 1203, 1207, 1208, 1212, 1213, 1217, 1218, 1222, 1223, 1231, 1232, 1233, 1234, 1235, 1236, 1240, 1241, 1248, 1249, 1250, 1251, 1252, 1261, 1262, 1263, 1264, 1265, 1266, 1267, 1278, 1279, 1280, 1281, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1293, 1294, 1298, 1299, 1305, 1306, 1307, 1308, 1312, 1313, 1318, 1319, 1320, 1321, 1326, 1327, 1328, 1329, 1332, 1335, 1338, 1342, 1346, 1349, 1352, 1356};
/* BEGIN LINEINFO 
assign 1 16 142
new 0 16 142
assign 1 17 143
new 0 17 143
assign 1 18 144
new 0 18 144
new 1 22 145
assign 1 24 146
new 0 24 146
assign 1 25 147
new 0 25 147
assign 1 27 148
new 0 27 148
assign 1 28 149
new 0 28 149
assign 1 32 155
formTarg 1 32 155
assign 1 32 156
add 1 32 156
return 1 32 157
assign 1 36 163
formCallTarg 1 36 163
assign 1 36 164
new 0 36 164
assign 1 36 165
add 1 36 165
return 1 36 166
assign 1 40 172
formCallTarg 1 40 172
assign 1 40 173
new 0 40 173
assign 1 40 174
add 1 40 174
return 1 40 175
assign 1 44 185
new 0 44 185
assign 1 44 186
addValue 1 44 186
assign 1 44 187
secondGet 0 44 187
assign 1 44 188
formTarg 1 44 188
assign 1 44 189
addValue 1 44 189
assign 1 44 190
new 0 44 190
assign 1 44 191
addValue 1 44 191
addValue 1 44 192
assign 1 48 213
new 0 48 213
assign 1 48 214
toString 0 48 214
assign 1 48 215
add 1 48 215
incrementValue 0 49 216
assign 1 50 217
new 0 50 217
assign 1 50 218
addValue 1 50 218
assign 1 50 219
addValue 1 50 219
assign 1 50 220
new 0 50 220
assign 1 50 221
addValue 1 50 221
addValue 1 50 222
assign 1 55 223
containedGet 0 55 223
assign 1 55 224
firstGet 0 55 224
assign 1 55 225
containedGet 0 55 225
assign 1 55 226
firstGet 0 55 226
assign 1 55 227
new 0 55 227
assign 1 55 228
add 1 55 228
assign 1 55 229
new 0 55 229
assign 1 55 230
add 1 55 230
assign 1 55 231
finalAssign 4 55 231
addValue 1 55 232
assign 1 63 245
emitNameGet 0 63 245
assign 1 63 246
addValue 1 63 246
assign 1 63 247
new 0 63 247
assign 1 63 248
addValue 1 63 248
assign 1 63 249
addValue 1 63 249
assign 1 63 250
new 0 63 250
addValue 1 63 251
assign 1 67 271
emitNameGet 0 67 271
assign 1 67 272
addValue 1 67 272
assign 1 67 273
new 0 67 273
assign 1 67 274
addValue 1 67 274
addValue 1 67 275
assign 1 68 276
new 0 68 276
assign 1 68 277
addValue 1 68 277
assign 1 68 278
heldGet 0 68 278
assign 1 68 279
namepathGet 0 68 279
assign 1 68 280
getClassConfig 1 68 280
assign 1 68 281
libNameGet 0 68 281
assign 1 68 282
relEmitName 1 68 282
assign 1 68 283
addValue 1 68 283
assign 1 68 284
new 0 68 284
assign 1 68 285
addValue 1 68 285
addValue 1 68 286
assign 1 70 287
new 0 70 287
assign 1 70 288
addValue 1 70 288
addValue 1 70 289
assign 1 75 311
heldGet 0 75 311
assign 1 75 312
synGet 0 75 312
assign 1 76 313
ptyListGet 0 76 313
assign 1 78 314
emitNameGet 0 78 314
assign 1 78 315
addValue 1 78 315
assign 1 78 316
new 0 78 316
addValue 1 78 317
assign 1 80 318
new 0 80 318
assign 1 81 319
iteratorGet 0 0 319
assign 1 81 322
hasNextGet 0 81 322
assign 1 81 324
nextGet 0 81 324
assign 1 83 326
new 0 83 326
assign 1 85 329
new 0 85 329
addValue 1 85 330
assign 1 87 332
addValue 1 87 332
assign 1 87 333
new 0 87 333
assign 1 87 334
addValue 1 87 334
assign 1 87 335
nameGet 0 87 335
assign 1 87 336
addValue 1 87 336
addValue 1 87 337
assign 1 91 343
new 0 91 343
assign 1 91 344
addValue 1 91 344
addValue 1 91 345
assign 1 96 373
heldGet 0 96 373
assign 1 96 374
namepathGet 0 96 374
assign 1 96 375
getClassConfig 1 96 375
assign 1 97 376
getInitialInst 1 97 376
assign 1 99 377
emitNameGet 0 99 377
assign 1 99 378
addValue 1 99 378
assign 1 99 379
new 0 99 379
assign 1 99 380
addValue 1 99 380
addValue 1 99 381
assign 1 102 382
addValue 1 102 382
assign 1 102 383
new 0 102 383
assign 1 102 384
addValue 1 102 384
addValue 1 102 385
assign 1 104 386
new 0 104 386
assign 1 104 387
addValue 1 104 387
addValue 1 104 388
assign 1 106 389
emitNameGet 0 106 389
assign 1 106 390
addValue 1 106 390
assign 1 106 391
new 0 106 391
assign 1 106 392
addValue 1 106 392
addValue 1 106 393
assign 1 109 394
new 0 109 394
assign 1 109 395
addValue 1 109 395
assign 1 109 396
addValue 1 109 396
assign 1 109 397
new 0 109 397
assign 1 109 398
addValue 1 109 398
addValue 1 109 399
assign 1 111 400
new 0 111 400
assign 1 111 401
addValue 1 111 401
addValue 1 111 402
buildPropList 0 113 403
getCode 2 118 408
assign 1 119 409
toString 0 119 409
addValue 1 120 410
assign 1 126 416
new 0 126 416
assign 1 126 417
addValue 1 126 417
addValue 1 126 418
assign 1 131 427
isPropertyGet 0 131 427
assign 1 132 429
new 0 132 429
assign 1 132 430
nameGet 0 132 430
assign 1 132 431
add 1 132 431
return 1 132 432
assign 1 134 434
nameForVar 1 134 434
return 1 134 435
assign 1 143 570
getLibOutput 0 143 570
assign 1 145 571
new 0 145 571
assign 1 146 572
new 0 146 572
assign 1 147 573
new 0 147 573
assign 1 148 574
iteratorGet 0 148 574
assign 1 148 577
hasNextGet 0 148 577
assign 1 150 579
nextGet 0 150 579
assign 1 152 580
new 0 152 580
assign 1 152 581
addValue 1 152 581
assign 1 152 582
addValue 1 152 582
assign 1 152 583
heldGet 0 152 583
assign 1 152 584
namepathGet 0 152 584
assign 1 152 585
toString 0 152 585
assign 1 152 586
addValue 1 152 586
assign 1 152 587
addValue 1 152 587
assign 1 152 588
new 0 152 588
assign 1 152 589
addValue 1 152 589
assign 1 152 590
heldGet 0 152 590
assign 1 152 591
namepathGet 0 152 591
assign 1 152 592
getClassConfig 1 152 592
assign 1 152 593
libNameGet 0 152 593
assign 1 152 594
relEmitName 1 152 594
assign 1 152 595
addValue 1 152 595
assign 1 152 596
new 0 152 596
assign 1 152 597
addValue 1 152 597
addValue 1 152 598
assign 1 154 599
heldGet 0 154 599
assign 1 154 600
synGet 0 154 600
assign 1 154 601
hasDefaultGet 0 154 601
assign 1 156 603
new 0 156 603
assign 1 156 604
heldGet 0 156 604
assign 1 156 605
namepathGet 0 156 605
assign 1 156 606
getClassConfig 1 156 606
assign 1 156 607
libNameGet 0 156 607
assign 1 156 608
relEmitName 1 156 608
assign 1 156 609
add 1 156 609
assign 1 156 610
new 0 156 610
assign 1 156 611
add 1 156 611
assign 1 162 612
new 0 162 612
assign 1 162 613
addValue 1 162 613
assign 1 162 614
addValue 1 162 614
assign 1 162 615
new 0 162 615
assign 1 162 616
addValue 1 162 616
addValue 1 162 617
assign 1 163 618
heldGet 0 163 618
assign 1 163 619
synGet 0 163 619
assign 1 163 620
hasDefaultGet 0 163 620
assign 1 164 622
new 0 164 622
assign 1 164 623
addValue 1 164 623
assign 1 164 624
addValue 1 164 624
assign 1 164 625
new 0 164 625
assign 1 164 626
addValue 1 164 626
addValue 1 164 627
assign 1 170 635
new 0 170 635
assign 1 172 636
keysGet 0 172 636
assign 1 172 637
iteratorGet 0 0 637
assign 1 172 640
hasNextGet 0 172 640
assign 1 172 642
nextGet 0 172 642
assign 1 174 643
new 0 174 643
assign 1 174 644
addValue 1 174 644
assign 1 174 645
new 0 174 645
assign 1 174 646
quoteGet 0 174 646
assign 1 174 647
addValue 1 174 647
assign 1 174 648
addValue 1 174 648
assign 1 174 649
new 0 174 649
assign 1 174 650
quoteGet 0 174 650
assign 1 174 651
addValue 1 174 651
assign 1 174 652
new 0 174 652
assign 1 174 653
addValue 1 174 653
assign 1 174 654
get 1 174 654
assign 1 174 655
addValue 1 174 655
assign 1 174 656
new 0 174 656
assign 1 174 657
addValue 1 174 657
addValue 1 174 658
assign 1 175 659
new 0 175 659
assign 1 175 660
addValue 1 175 660
assign 1 175 661
new 0 175 661
assign 1 175 662
quoteGet 0 175 662
assign 1 175 663
addValue 1 175 663
assign 1 175 664
addValue 1 175 664
assign 1 175 665
new 0 175 665
assign 1 175 666
quoteGet 0 175 666
assign 1 175 667
addValue 1 175 667
assign 1 175 668
new 0 175 668
assign 1 175 669
addValue 1 175 669
assign 1 175 670
get 1 175 670
assign 1 175 671
addValue 1 175 671
assign 1 175 672
new 0 175 672
assign 1 175 673
addValue 1 175 673
addValue 1 175 674
assign 1 179 680
emitChecksGet 0 179 680
assign 1 179 681
new 0 179 681
assign 1 179 682
has 1 179 682
write 1 180 684
assign 1 184 686
usedLibrarysGet 0 184 686
assign 1 184 687
sizeGet 0 184 687
assign 1 184 688
new 0 184 688
assign 1 184 689
equals 1 184 694
assign 1 185 695
new 0 185 695
assign 1 185 696
addValue 1 185 696
addValue 1 185 697
assign 1 186 698
new 0 186 698
assign 1 186 699
addValue 1 186 699
addValue 1 186 700
assign 1 187 701
new 0 187 701
assign 1 187 702
addValue 1 187 702
addValue 1 187 703
write 1 190 705
write 1 191 706
assign 1 194 707
new 0 194 707
assign 1 195 708
mainNameGet 0 195 708
fromString 1 195 709
assign 1 196 710
getClassConfig 1 196 710
assign 1 198 711
new 0 198 711
assign 1 199 712
new 0 199 712
assign 1 199 713
addValue 1 199 713
assign 1 199 714
fullEmitNameGet 0 199 714
assign 1 199 715
addValue 1 199 715
assign 1 199 716
new 0 199 716
assign 1 199 717
addValue 1 199 717
addValue 1 199 718
assign 1 200 719
ownProcessGet 0 200 719
assign 1 201 721
emitChecksGet 0 201 721
assign 1 201 722
new 0 201 722
assign 1 201 723
has 1 201 723
assign 1 202 725
new 0 202 725
assign 1 202 726
addValue 1 202 726
addValue 1 202 727
assign 1 205 730
new 0 205 730
assign 1 205 731
addValue 1 205 731
assign 1 205 732
outputPlatformGet 0 205 732
assign 1 205 733
nameGet 0 205 733
assign 1 205 734
addValue 1 205 734
assign 1 205 735
new 0 205 735
assign 1 205 736
addValue 1 205 736
addValue 1 205 737
assign 1 206 738
doMainGet 0 206 738
write 1 207 740
assign 1 209 742
new 0 209 742
write 1 210 743
write 1 211 744
assign 1 212 745
ownProcessGet 0 212 745
assign 1 213 747
new 0 213 747
assign 1 213 748
addValue 1 213 748
addValue 1 213 749
assign 1 214 750
new 0 214 750
assign 1 214 751
addValue 1 214 751
addValue 1 214 752
assign 1 216 754
doMainGet 0 216 754
write 1 217 756
finishLibOutput 1 220 758
assign 1 222 759
saveSynsGet 0 222 759
saveSyns 0 223 761
assign 1 229 771
isPropertyGet 0 229 771
assign 1 232 775
isArgGet 0 232 775
assign 1 232 776
not 0 232 781
assign 1 233 782
new 0 233 782
addValue 1 233 783
assign 1 235 785
nameForVar 1 235 785
addValue 1 235 786
assign 1 240 792
new 0 240 792
return 1 240 793
assign 1 244 801
new 0 244 801
assign 1 244 802
add 1 244 802
assign 1 244 803
new 0 244 803
assign 1 244 804
add 1 244 804
assign 1 244 805
add 1 244 805
return 1 244 806
assign 1 248 810
new 0 248 810
return 1 248 811
assign 1 252 825
emitNameGet 0 252 825
assign 1 252 826
new 0 252 826
assign 1 252 827
add 1 252 827
assign 1 252 828
add 1 252 828
assign 1 252 829
new 0 252 829
assign 1 252 830
add 1 252 830
assign 1 252 831
addValue 1 252 831
assign 1 253 832
emitNameGet 0 253 832
assign 1 253 833
add 1 253 833
assign 1 253 834
new 0 253 834
assign 1 253 835
add 1 253 835
assign 1 253 836
addValue 1 253 836
return 1 254 837
assign 1 258 851
new 0 258 851
assign 1 258 852
libNameGet 0 258 852
assign 1 258 853
relEmitName 1 258 853
assign 1 258 854
add 1 258 854
assign 1 258 855
new 0 258 855
assign 1 258 856
add 1 258 856
assign 1 258 857
heldGet 0 258 857
assign 1 258 858
literalValueGet 0 258 858
assign 1 258 859
add 1 258 859
assign 1 258 860
new 0 258 860
assign 1 258 861
add 1 258 861
return 1 258 862
assign 1 262 876
new 0 262 876
assign 1 262 877
libNameGet 0 262 877
assign 1 262 878
relEmitName 1 262 878
assign 1 262 879
add 1 262 879
assign 1 262 880
new 0 262 880
assign 1 262 881
add 1 262 881
assign 1 262 882
heldGet 0 262 882
assign 1 262 883
literalValueGet 0 262 883
assign 1 262 884
add 1 262 884
assign 1 262 885
new 0 262 885
assign 1 262 886
add 1 262 886
return 1 262 887
assign 1 267 923
new 0 267 923
assign 1 267 924
libNameGet 0 267 924
assign 1 267 925
relEmitName 1 267 925
assign 1 267 926
add 1 267 926
assign 1 267 927
new 0 267 927
assign 1 267 928
add 1 267 928
assign 1 267 929
emitNameGet 0 267 929
assign 1 267 930
add 1 267 930
assign 1 267 931
new 0 267 931
assign 1 267 932
add 1 267 932
assign 1 267 933
add 1 267 933
assign 1 267 934
new 0 267 934
assign 1 267 935
add 1 267 935
assign 1 267 936
add 1 267 936
assign 1 267 937
new 0 267 937
assign 1 267 938
add 1 267 938
return 1 267 939
assign 1 269 941
new 0 269 941
assign 1 269 942
libNameGet 0 269 942
assign 1 269 943
relEmitName 1 269 943
assign 1 269 944
add 1 269 944
assign 1 269 945
new 0 269 945
assign 1 269 946
add 1 269 946
assign 1 269 947
emitNameGet 0 269 947
assign 1 269 948
add 1 269 948
assign 1 269 949
new 0 269 949
assign 1 269 950
add 1 269 950
assign 1 269 951
add 1 269 951
assign 1 269 952
new 0 269 952
assign 1 269 953
add 1 269 953
assign 1 269 954
add 1 269 954
assign 1 269 955
new 0 269 955
assign 1 269 956
add 1 269 956
return 1 269 957
assign 1 273 972
def 1 273 977
assign 1 274 978
libNameGet 0 274 978
assign 1 274 979
relEmitName 1 274 979
assign 1 274 980
extend 1 274 980
assign 1 276 983
new 0 276 983
assign 1 276 984
extend 1 276 984
assign 1 278 986
new 0 278 986
assign 1 278 987
emitNameGet 0 278 987
assign 1 278 988
addValue 1 278 988
assign 1 278 989
new 0 278 989
assign 1 278 990
addValue 1 278 990
assign 1 286 991
new 0 286 991
assign 1 286 992
addValue 1 286 992
addValue 1 286 993
addValue 1 287 994
return 1 288 995
assign 1 292 1024
heldGet 0 292 1024
assign 1 292 1025
superCallGet 0 292 1025
assign 1 293 1027
new 0 293 1027
assign 1 293 1028
notEmpty 1 293 1028
assign 1 294 1030
new 0 294 1030
assign 1 294 1031
add 1 294 1031
assign 1 296 1034
new 0 296 1034
assign 1 298 1036
emitNameGet 0 298 1036
assign 1 298 1037
new 0 298 1037
assign 1 298 1038
add 1 298 1038
assign 1 298 1039
heldGet 0 298 1039
assign 1 298 1040
nameGet 0 298 1040
assign 1 298 1041
add 1 298 1041
assign 1 298 1042
new 0 298 1042
assign 1 298 1043
add 1 298 1043
assign 1 298 1044
add 1 298 1044
assign 1 298 1045
new 0 298 1045
assign 1 298 1046
add 1 298 1046
return 1 298 1047
assign 1 300 1049
new 0 300 1049
assign 1 300 1050
add 1 300 1050
assign 1 300 1051
heldGet 0 300 1051
assign 1 300 1052
nameGet 0 300 1052
assign 1 300 1053
add 1 300 1053
assign 1 300 1054
new 0 300 1054
assign 1 300 1055
add 1 300 1055
assign 1 300 1056
add 1 300 1056
assign 1 300 1057
new 0 300 1057
assign 1 300 1058
add 1 300 1058
return 1 300 1059
assign 1 304 1063
new 0 304 1063
return 1 305 1064
assign 1 312 1069
undef 1 312 1074
assign 1 313 1075
new 0 313 1075
addValue 1 315 1077
assign 1 316 1078
new 0 316 1078
return 1 316 1079
assign 1 321 1083
getLibOutput 0 321 1083
return 1 321 1084
assign 1 329 1115
undef 1 329 1120
assign 1 330 1121
new 0 330 1121
assign 1 331 1122
parentGet 0 331 1122
assign 1 331 1123
fileGet 0 331 1123
assign 1 331 1124
existsGet 0 331 1124
assign 1 331 1125
not 0 331 1130
assign 1 332 1131
parentGet 0 332 1131
assign 1 332 1132
fileGet 0 332 1132
makeDirs 0 332 1133
assign 1 334 1135
fileGet 0 334 1135
assign 1 334 1136
writerGet 0 334 1136
assign 1 334 1137
open 0 334 1137
assign 1 336 1138
paramsGet 0 336 1138
assign 1 336 1139
new 0 336 1139
assign 1 336 1140
has 1 336 1140
assign 1 337 1142
paramsGet 0 337 1142
assign 1 337 1143
new 0 337 1143
assign 1 337 1144
get 1 337 1144
assign 1 337 1145
iteratorGet 0 0 1145
assign 1 337 1148
hasNextGet 0 337 1148
assign 1 337 1150
nextGet 0 337 1150
assign 1 338 1151
apNew 1 338 1151
assign 1 338 1152
fileGet 0 338 1152
assign 1 339 1153
readerGet 0 339 1153
assign 1 339 1154
open 0 339 1154
assign 1 339 1155
readString 0 339 1155
assign 1 340 1156
readerGet 0 340 1156
close 0 340 1157
assign 1 341 1158
countLines 1 341 1158
addValue 1 341 1159
write 1 342 1160
return 1 348 1168
close 0 352 1171
assign 1 353 1172
assign 1 358 1177
new 0 358 1177
return 1 358 1178
assign 1 362 1182
new 0 362 1182
return 1 362 1183
assign 1 366 1187
new 0 366 1187
return 1 366 1188
assign 1 370 1192
new 0 370 1192
return 1 370 1193
assign 1 374 1197
new 0 374 1197
return 1 374 1198
assign 1 378 1202
new 0 378 1202
return 1 378 1203
assign 1 382 1207
new 0 382 1207
return 1 382 1208
assign 1 387 1212
new 0 387 1212
return 1 387 1213
assign 1 393 1217
new 0 393 1217
return 1 393 1218
assign 1 398 1222
new 0 398 1222
return 1 398 1223
assign 1 402 1231
new 0 402 1231
assign 1 402 1232
add 1 402 1232
assign 1 402 1233
new 0 402 1233
assign 1 402 1234
add 1 402 1234
assign 1 402 1235
add 1 402 1235
return 1 402 1236
assign 1 406 1240
new 0 406 1240
return 1 406 1241
assign 1 410 1248
libNameGet 0 410 1248
assign 1 410 1249
relEmitName 1 410 1249
assign 1 410 1250
new 0 410 1250
assign 1 410 1251
add 1 410 1251
return 1 410 1252
assign 1 415 1261
emitNameGet 0 415 1261
assign 1 415 1262
new 0 415 1262
assign 1 415 1263
add 1 415 1263
assign 1 415 1264
new 0 415 1264
assign 1 415 1265
add 1 415 1265
assign 1 415 1266
add 1 415 1266
return 1 415 1267
assign 1 420 1278
emitNameGet 0 420 1278
assign 1 420 1279
addValue 1 420 1279
assign 1 420 1280
new 0 420 1280
assign 1 420 1281
addValue 1 420 1281
assign 1 420 1282
addValue 1 420 1282
assign 1 420 1283
new 0 420 1283
addValue 1 420 1284
addValue 1 422 1285
assign 1 424 1286
new 0 424 1286
assign 1 424 1287
addValue 1 424 1287
addValue 1 424 1288
assign 1 429 1293
new 0 429 1293
return 1 429 1294
assign 1 433 1298
new 0 433 1298
return 1 433 1299
assign 1 437 1305
new 0 437 1305
assign 1 437 1306
add 1 437 1306
assign 1 437 1307
add 1 437 1307
return 1 437 1308
assign 1 442 1312
new 0 442 1312
return 1 442 1313
assign 1 446 1318
getClassConfig 1 446 1318
assign 1 447 1319
fullEmitNameGet 0 447 1319
emitNameSet 1 447 1320
return 1 448 1321
assign 1 452 1326
getLocalClassConfig 1 452 1326
assign 1 453 1327
fullEmitNameGet 0 453 1327
emitNameSet 1 453 1328
return 1 454 1329
return 1 0 1332
return 1 0 1335
assign 1 0 1338
assign 1 0 1342
return 1 0 1346
return 1 0 1349
assign 1 0 1352
assign 1 0 1356
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1833080324: return bem_nullValueGet_0();
case 89002488: return bem_onceCountGetDirect_0();
case -723212158: return bem_methodsGet_0();
case 853832565: return bem_parentConfGet_0();
case -1847191937: return bem_lastMethodsSizeGet_0();
case -1018579818: return bem_objectNpGetDirect_0();
case 1781028711: return bem_superCallsGet_0();
case 552113488: return bem_csynGet_0();
case -481256408: return bem_spropDecGet_0();
case 1391274656: return bem_inClassGet_0();
case -710452445: return bem_lastMethodsLinesGet_0();
case 1610102147: return bem_mainInClassGet_0();
case -1872688111: return bem_loadIds_0();
case -1413011054: return bem_returnTypeGetDirect_0();
case 2074140539: return bem_belslitsGet_0();
case -179281693: return bem_preClassOutput_0();
case 32905439: return bem_overrideMtdDecGet_0();
case -522919508: return bem_afterCast_0();
case 157506901: return bem_methodCatchGetDirect_0();
case -282980640: return bem_trueValueGetDirect_0();
case -736025505: return bem_scvpGetDirect_0();
case 789696365: return bem_propertyDecsGetDirect_0();
case 851292767: return bem_cnodeGetDirect_0();
case 239197127: return bem_nullValueGetDirect_0();
case 1330976730: return bem_hashGet_0();
case 163439006: return bem_returnTypeGet_0();
case -608329410: return bem_qGet_0();
case -160735352: return bem_once_0();
case 2141530402: return bem_getClassOutput_0();
case -653753889: return bem_classesInDepthOrderGetDirect_0();
case 1094862804: return bem_boolTypeGet_0();
case -262893633: return bem_maxSpillArgsLenGet_0();
case 872708376: return bem_toAny_0();
case -1581897492: return bem_saveIds_0();
case -241267565: return bem_ccCacheGetDirect_0();
case -309720080: return bem_propDecGet_0();
case -2014542803: return bem_iteratorGet_0();
case -1217444056: return bem_constGet_0();
case -280917091: return bem_fullLibEmitNameGet_0();
case 668610815: return bem_idToNameGetDirect_0();
case -1705055257: return bem_inClassGetDirect_0();
case -542134509: return bem_covariantReturnsGet_0();
case 673533612: return bem_typeDecGet_0();
case 1257548112: return bem_instanceNotEqualGetDirect_0();
case -1923047269: return bem_beginNs_0();
case 1128359778: return bem_synEmitPathGet_0();
case 797867737: return bem_ntypesGet_0();
case 325193639: return bem_smnlecsGetDirect_0();
case -1303407072: return bem_preClassGetDirect_0();
case 923717454: return bem_falseValueGet_0();
case -1341998869: return bem_lastCallGet_0();
case -1533701006: return bem_serializeContents_0();
case -1578325062: return bem_ccMethodsGetDirect_0();
case -1959386608: return bem_methodsGetDirect_0();
case -173842906: return bem_ccCacheGet_0();
case 23203927: return bem_instOfGet_0();
case 1023950793: return bem_boolNpGetDirect_0();
case -1268735591: return bem_randGetDirect_0();
case -1492968755: return bem_mnodeGetDirect_0();
case 181571301: return bem_doEmit_0();
case 1996576414: return bem_libEmitPathGetDirect_0();
case -2119911256: return bem_writeBET_0();
case 588916000: return bem_smnlcsGetDirect_0();
case -1451048410: return bem_new_0();
case 1657477077: return bem_mainEndGet_0();
case -588870906: return bem_lastMethodBodyLinesGetDirect_0();
case 1612415239: return bem_classEndGet_0();
case 1033505681: return bem_idToNamePathGet_0();
case -341461031: return bem_superCallsGetDirect_0();
case -425081215: return bem_mnodeGet_0();
case 608916291: return bem_libEmitPathGet_0();
case 286973089: return bem_useDynMethodsGet_0();
case -831119201: return bem_exceptDecGetDirect_0();
case 1208354139: return bem_sourceFileNameGet_0();
case -1138559814: return bem_idToNamePathGetDirect_0();
case -769130124: return bem_nameToIdPathGetDirect_0();
case 606500052: return bem_qGetDirect_0();
case -206043242: return bem_many_0();
case -738417167: return bem_intNpGetDirect_0();
case 437089080: return bem_print_0();
case -244195527: return bem_classEmitsGet_0();
case -1415127054: return bem_allOnceDecsGet_0();
case -612119659: return bem_mainStartGet_0();
case 878380143: return bem_randGet_0();
case 1343497980: return bem_classConfGet_0();
case 907276784: return bem_serializeToString_0();
case -717163782: return bem_callNamesGetDirect_0();
case 644854602: return bem_lastMethodBodySizeGetDirect_0();
case -1082915607: return bem_smnlcsGet_0();
case -1010955676: return bem_smnlecsGet_0();
case 1200056076: return bem_serializationIteratorGet_0();
case 342540667: return bem_objectCcGetDirect_0();
case 1741169350: return bem_maxDynArgsGet_0();
case 1004594222: return bem_objectNpGet_0();
case 1788022534: return bem_mainOutsideNsGet_0();
case 528051774: return bem_fileExtGetDirect_0();
case 834025277: return bem_cnodeGet_0();
case 40101441: return bem_superNameGet_0();
case 1257048979: return bem_methodCatchGet_0();
case -214881374: return bem_lastMethodsSizeGetDirect_0();
case 2017345633: return bem_copy_0();
case -371749847: return bem_callNamesGet_0();
case -2019098513: return bem_nativeCSlotsGetDirect_0();
case 1967715271: return bem_fullLibEmitNameGetDirect_0();
case -1760434406: return bem_transGetDirect_0();
case -1928643950: return bem_dynMethodsGetDirect_0();
case -1104598657: return bem_synEmitPathGetDirect_0();
case 678368333: return bem_nlGetDirect_0();
case -1419115955: return bem_create_0();
case 1358980007: return bem_maxDynArgsGetDirect_0();
case -545635799: return bem_onceDecsGet_0();
case -1490721678: return bem_parentConfGetDirect_0();
case 906919432: return bem_libEmitNameGetDirect_0();
case 835796661: return bem_buildCreate_0();
case -778954260: return bem_newDecGet_0();
case 278030248: return bem_constGetDirect_0();
case -2108129514: return bem_nativeCSlotsGet_0();
case 370840953: return bem_propertyDecsGet_0();
case -877655258: return bem_invpGet_0();
case 373095154: return bem_classCallsGetDirect_0();
case 989191193: return bem_stringNpGetDirect_0();
case 862788409: return bem_buildGet_0();
case -532757565: return bem_trueValueGet_0();
case -2102217588: return bem_invpGetDirect_0();
case -1022435804: return bem_initialDecGet_0();
case 513387389: return bem_onceCountGet_0();
case -1352780820: return bem_falseValueGetDirect_0();
case -2114265547: return bem_methodCallsGet_0();
case -1593715630: return bem_ntypesGetDirect_0();
case -306616201: return bem_methodBodyGetDirect_0();
case -2140984863: return bem_intNpGet_0();
case 796463180: return bem_lastCallGetDirect_0();
case -1732259953: return bem_onceDecsGetDirect_0();
case -675434334: return bem_buildClassInfo_0();
case -1422545140: return bem_getLibOutput_0();
case 795641113: return bem_boolCcGetDirect_0();
case 1689218392: return bem_shlibeGetDirect_0();
case -813054627: return bem_classEmitsGetDirect_0();
case 1384423002: return bem_transGet_0();
case 312842469: return bem_instanceNotEqualGet_0();
case 103700110: return bem_maxSpillArgsLenGetDirect_0();
case 2059991616: return bem_lastMethodBodySizeGet_0();
case -622712732: return bem_emitLangGet_0();
case -1588672742: return bem_classesInDepthOrderGet_0();
case -1882651776: return bem_allOnceDecsGetDirect_0();
case 1882778775: return bem_fieldIteratorGet_0();
case 117270357: return bem_idToNameGet_0();
case 467055783: return bem_boolNpGet_0();
case -741534279: return bem_gcMarksGet_0();
case -780070882: return bem_floatNpGet_0();
case 34717997: return bem_methodBodyGet_0();
case -1229803830: return bem_deserializeClassNameGet_0();
case 32863190: return bem_belslitsGetDirect_0();
case -1990292643: return bem_toString_0();
case -1297748369: return bem_stringNpGet_0();
case 940055786: return bem_runtimeInitGet_0();
case -154172821: return bem_endNs_0();
case -1704770597: return bem_nameToIdGet_0();
case -741980508: return bem_floatNpGetDirect_0();
case -214647999: return bem_gcMarksGetDirect_0();
case -1970314235: return bem_csynGetDirect_0();
case 1061057969: return bem_instOfGetDirect_0();
case -481005419: return bem_baseMtdDecGet_0();
case 755320147: return bem_lastMethodBodyLinesGet_0();
case 1613794738: return bem_preClassGet_0();
case -2069822342: return bem_fileExtGet_0();
case 1976523732: return bem_lineCountGetDirect_0();
case 636737656: return bem_exceptDecGet_0();
case 1674575712: return bem_classNameGet_0();
case -260991597: return bem_buildPropList_0();
case -1397201425: return bem_inFilePathedGet_0();
case 434471495: return bem_dynMethodsGet_0();
case -1534460720: return bem_nlGet_0();
case -50803216: return bem_instanceEqualGet_0();
case 978291767: return bem_buildInitial_0();
case 322928915: return bem_nameToIdPathGet_0();
case -943591803: return bem_classCallsGet_0();
case -911398327: return bem_classConfGetDirect_0();
case 2066642517: return bem_buildGetDirect_0();
case 1865983825: return bem_fieldNamesGet_0();
case 1227631747: return bem_baseSmtdDecGet_0();
case 1450484670: return bem_ccMethodsGet_0();
case 487647791: return bem_saveSyns_0();
case 589115937: return bem_objectCcGet_0();
case -1560434824: return bem_scvpGet_0();
case 578072317: return bem_nameToIdGetDirect_0();
case 667646276: return bem_inFilePathedGetDirect_0();
case -1396098681: return bem_libEmitNameGet_0();
case 48684490: return bem_echo_0();
case 1380917654: return bem_lineCountGet_0();
case -1769146102: return bem_lastMethodsLinesGetDirect_0();
case 232781930: return bem_shlibeGet_0();
case -195236233: return bem_instanceEqualGetDirect_0();
case 1330037424: return bem_emitLib_0();
case -1664773818: return bem_emitLangGetDirect_0();
case -166013833: return bem_tagGet_0();
case 256446682: return bem_boolCcGet_0();
case 430683525: return bem_msynGet_0();
case -1253270041: return bem_msynGetDirect_0();
case -1914610076: return bem_methodCallsGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -748172198: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -564221675: return bem_nullValueSet_1(bevd_0);
case 237098757: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 909810346: return bem_sameClass_1(bevd_0);
case 491643122: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 723911850: return bem_nullValueSetDirect_1(bevd_0);
case 207627386: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1919354007: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1494021750: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1001788822: return bem_propertyDecsSet_1(bevd_0);
case 767314112: return bem_onceCountSet_1(bevd_0);
case 1014945357: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1999988865: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 970258975: return bem_libEmitPathSet_1(bevd_0);
case -279352105: return bem_undefined_1(bevd_0);
case 625481528: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1406812161: return bem_transSetDirect_1(bevd_0);
case 1319461040: return bem_propertyDecsSetDirect_1(bevd_0);
case 1033036587: return bem_instanceNotEqualSet_1(bevd_0);
case 1238298036: return bem_msynSet_1(bevd_0);
case 2136795361: return bem_methodBodySetDirect_1(bevd_0);
case 56467064: return bem_libEmitNameSetDirect_1(bevd_0);
case 161134859: return bem_defined_1(bevd_0);
case -2049985000: return bem_idToNamePathSetDirect_1(bevd_0);
case -443159716: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1020802032: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1505243111: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1269877432: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1561328648: return bem_otherType_1(bevd_0);
case -297744595: return bem_objectNpSetDirect_1(bevd_0);
case 1949920047: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -353909927: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1327996910: return bem_smnlecsSet_1(bevd_0);
case 1359655989: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1389526851: return bem_stringNpSetDirect_1(bevd_0);
case -1198239153: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2122176784: return bem_undef_1(bevd_0);
case -691436434: return bem_begin_1(bevd_0);
case -1619730877: return bem_shlibeSetDirect_1(bevd_0);
case 2108405871: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -456384105: return bem_trueValueSetDirect_1(bevd_0);
case -1530407250: return bem_nlSetDirect_1(bevd_0);
case -1787409601: return bem_classCallsSet_1(bevd_0);
case 1628739562: return bem_libEmitPathSetDirect_1(bevd_0);
case -1517637963: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 941906783: return bem_nameToIdPathSet_1(bevd_0);
case -185383596: return bem_sameType_1(bevd_0);
case 1788454334: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -582178545: return bem_ccMethodsSetDirect_1(bevd_0);
case 640052158: return bem_randSetDirect_1(bevd_0);
case -1921346162: return bem_smnlecsSetDirect_1(bevd_0);
case -943142052: return bem_classEmitsSet_1(bevd_0);
case 42997928: return bem_lastMethodsSizeSet_1(bevd_0);
case -1891874835: return bem_superCallsSet_1(bevd_0);
case -493279006: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 586375800: return bem_boolCcSetDirect_1(bevd_0);
case -1320027359: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 659052743: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1413849242: return bem_intNpSetDirect_1(bevd_0);
case -1681519321: return bem_lastCallSet_1(bevd_0);
case 2022290337: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1398253301: return bem_maxDynArgsSet_1(bevd_0);
case -1454264985: return bem_idToNameSetDirect_1(bevd_0);
case 1576163448: return bem_trueValueSet_1(bevd_0);
case 235398195: return bem_mnodeSetDirect_1(bevd_0);
case 268661112: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 448678910: return bem_ntypesSet_1(bevd_0);
case 657670376: return bem_ccCacheSetDirect_1(bevd_0);
case 1607214220: return bem_nativeCSlotsSet_1(bevd_0);
case 778364331: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1725462479: return bem_methodsSet_1(bevd_0);
case 1950461660: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 2058785774: return bem_constSet_1(bevd_0);
case -45726815: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1554711529: return bem_floatNpSetDirect_1(bevd_0);
case -1310208163: return bem_idToNamePathSet_1(bevd_0);
case 1945717937: return bem_scvpSet_1(bevd_0);
case -1039385772: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1951352986: return bem_cnodeSet_1(bevd_0);
case -1272785300: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -1353297109: return bem_buildSetDirect_1(bevd_0);
case -1465117689: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1308420194: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 228067749: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 904724431: return bem_methodCallsSet_1(bevd_0);
case 453269734: return bem_inFilePathedSetDirect_1(bevd_0);
case 1583845308: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -952975048: return bem_smnlcsSetDirect_1(bevd_0);
case -1616094339: return bem_buildSet_1(bevd_0);
case 1548683697: return bem_boolCcSet_1(bevd_0);
case -12237083: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1126190417: return bem_maxDynArgsSetDirect_1(bevd_0);
case -51313250: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -442583847: return bem_idToNameSet_1(bevd_0);
case -538980551: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -881275486: return bem_libEmitNameSet_1(bevd_0);
case -1024810424: return bem_onceCountSetDirect_1(bevd_0);
case -395076999: return bem_returnTypeSetDirect_1(bevd_0);
case -1863811936: return bem_dynMethodsSetDirect_1(bevd_0);
case 725333944: return bem_methodCatchSetDirect_1(bevd_0);
case 743332682: return bem_classConfSetDirect_1(bevd_0);
case -2059198415: return bem_ccMethodsSet_1(bevd_0);
case -1257644704: return bem_falseValueSetDirect_1(bevd_0);
case 1986208215: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 121710805: return bem_fullLibEmitNameSet_1(bevd_0);
case 387082650: return bem_exceptDecSet_1(bevd_0);
case 716915581: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 560930939: return bem_nameToIdSet_1(bevd_0);
case -805692436: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 972947062: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1648589840: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -36916110: return bem_methodCatchSet_1(bevd_0);
case -1481427497: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1823550413: return bem_superCallsSetDirect_1(bevd_0);
case -2264662: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 190111245: return bem_stringNpSet_1(bevd_0);
case -303965840: return bem_dynMethodsSet_1(bevd_0);
case 1484567824: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -623757830: return bem_parentConfSet_1(bevd_0);
case -821424118: return bem_allOnceDecsSetDirect_1(bevd_0);
case -345530779: return bem_cnodeSetDirect_1(bevd_0);
case 1728149647: return bem_classEmitsSetDirect_1(bevd_0);
case -429821766: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 354557818: return bem_equals_1(bevd_0);
case 1999961458: return bem_synEmitPathSet_1(bevd_0);
case -910373087: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -332644770: return bem_end_1(bevd_0);
case 1153143612: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 2035866723: return bem_randSet_1(bevd_0);
case 1951809293: return bem_ntypesSetDirect_1(bevd_0);
case 374781083: return bem_methodBodySet_1(bevd_0);
case 1287940387: return bem_instanceEqualSet_1(bevd_0);
case -2100432374: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -268521893: return bem_instOfSetDirect_1(bevd_0);
case 601808286: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 908990693: return bem_nameToIdSetDirect_1(bevd_0);
case 584123032: return bem_def_1(bevd_0);
case -840953319: return bem_notEquals_1(bevd_0);
case 481194340: return bem_csynSet_1(bevd_0);
case -184372408: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1114338275: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -306025000: return bem_shlibeSet_1(bevd_0);
case 1920998617: return bem_sameObject_1(bevd_0);
case 1505934601: return bem_gcMarksSet_1(bevd_0);
case -391962880: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1141566853: return bem_methodsSetDirect_1(bevd_0);
case -1418177884: return bem_methodCallsSetDirect_1(bevd_0);
case -1306142247: return bem_transSet_1(bevd_0);
case 701750781: return bem_objectCcSet_1(bevd_0);
case -25591863: return bem_objectNpSet_1(bevd_0);
case -302344233: return bem_classCallsSetDirect_1(bevd_0);
case 1439132366: return bem_preClassSetDirect_1(bevd_0);
case -116267513: return bem_smnlcsSet_1(bevd_0);
case 140816824: return bem_csynSetDirect_1(bevd_0);
case -759212768: return bem_lastMethodsLinesSet_1(bevd_0);
case -734706513: return bem_parentConfSetDirect_1(bevd_0);
case -149561206: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -1738615194: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 661986637: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1957561572: return bem_floatNpSet_1(bevd_0);
case -813682115: return bem_synEmitPathSetDirect_1(bevd_0);
case 285580831: return bem_emitLangSet_1(bevd_0);
case -1139944772: return bem_objectCcSetDirect_1(bevd_0);
case 1300919203: return bem_classConfSet_1(bevd_0);
case -813258193: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -825296333: return bem_gcMarksSetDirect_1(bevd_0);
case -1747716140: return bem_instanceEqualSetDirect_1(bevd_0);
case 378284461: return bem_fileExtSet_1(bevd_0);
case 252490283: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1822027791: return bem_otherClass_1(bevd_0);
case 483173634: return bem_onceDecsSet_1(bevd_0);
case -1346540013: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2084505365: return bem_lastCallSetDirect_1(bevd_0);
case 2056490313: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 795204528: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 589900107: return bem_qSetDirect_1(bevd_0);
case 616680079: return bem_exceptDecSetDirect_1(bevd_0);
case 643730377: return bem_ccCacheSet_1(bevd_0);
case -847381890: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 644308082: return bem_falseValueSet_1(bevd_0);
case 519908725: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1890809107: return bem_inClassSetDirect_1(bevd_0);
case -970017727: return bem_emitLangSetDirect_1(bevd_0);
case -428127051: return bem_scvpSetDirect_1(bevd_0);
case -1644351644: return bem_inFilePathedSet_1(bevd_0);
case -1958201403: return bem_returnTypeSet_1(bevd_0);
case -85334475: return bem_preClassSet_1(bevd_0);
case -770962975: return bem_msynSetDirect_1(bevd_0);
case -2068018884: return bem_mnodeSet_1(bevd_0);
case -778890064: return bem_belslitsSet_1(bevd_0);
case -882365753: return bem_allOnceDecsSet_1(bevd_0);
case -1342042481: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 258408678: return bem_classesInDepthOrderSet_1(bevd_0);
case 353404234: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1448990170: return bem_boolNpSetDirect_1(bevd_0);
case -946790158: return bem_lineCountSet_1(bevd_0);
case -957931049: return bem_boolNpSet_1(bevd_0);
case 2073162558: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1517267444: return bem_callNamesSetDirect_1(bevd_0);
case 1136793635: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1198507900: return bem_onceDecsSetDirect_1(bevd_0);
case -1303655002: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 713581423: return bem_constSetDirect_1(bevd_0);
case 1508179087: return bem_lineCountSetDirect_1(bevd_0);
case -518047533: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 2105110596: return bem_nameToIdPathSetDirect_1(bevd_0);
case 1596863802: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -933369721: return bem_qSet_1(bevd_0);
case 6642322: return bem_intNpSet_1(bevd_0);
case 272081757: return bem_inClassSet_1(bevd_0);
case 1732176829: return bem_nlSet_1(bevd_0);
case 381634908: return bem_callNamesSet_1(bevd_0);
case 2120516283: return bem_fileExtSetDirect_1(bevd_0);
case -1791322503: return bem_invpSet_1(bevd_0);
case 1142250735: return bem_belslitsSetDirect_1(bevd_0);
case 1247692832: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 2134066079: return bem_invpSetDirect_1(bevd_0);
case -25274143: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1963812721: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1198465319: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 170216407: return bem_copyTo_1(bevd_0);
case -4215458: return bem_instOfSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 936076332: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1702878339: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1897967875: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1664783630: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1540430634: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 338839951: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1579081197: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -758649425: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1467883232: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 465709808: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 105253121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2109793977: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -548105507: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -29810702: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 622406268: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 175222937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 750543846: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1903015196: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -509614296: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1663517365: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 806591986: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1320050449: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1477719473: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -724545746: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1476090561: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -1323191926: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -435357440: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1875805073: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
}
