namespace be {
/* IO:File: source/build/JSEmitter.be */
public sealed class BEC_2_5_9_BuildJSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
static BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x65,0x6D,0x62,0x50,0x6C,0x61,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x62,0x65,0x6D,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x3A,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x62,0x65,0x76,0x6F,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_80 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_81 = {0x62,0x65};
public static new BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static new BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_formTarg_1(beva_node);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_invp);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_7));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_8));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_11));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1427477189);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1081918788);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJSEmitter_bels_14));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_15));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(beva_belsName);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(bevt_3_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-507142367);
bevt_9_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_ta_ph );
bevt_12_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_12_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_14_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(576833844);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 81*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 81*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(-641452021);
if (bevl_first.bevi_bool)/* Line: 82*/ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 83*/
 else /* Line: 84*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevp_ccMethods.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 85*/
bevt_9_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevt_9_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_7_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 87*/
 else /* Line: 81*/ {
break;
} /* Line: 81*/
} /* Line: 81*/
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-507142367);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_4_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_9_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_13_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_11_ta_ph = (BEC_2_4_6_TextString) bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_17_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) bevt_17_ta_ph.bem_addValue_1(bevl_stinst);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_15_ta_ph = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_20_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_21_ta_ph);
bevt_20_ta_ph.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_0_ta_ph = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 131*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildJSEmitter_bels_31));
bevt_3_ta_ph = beva_v.bem_nameGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 132*/
bevt_4_ta_ph = base.bem_nameForVar_1(beva_v);
return bevt_4_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_7_TextStrings bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_7_TextStrings bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_7_TextStrings bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_7_TextStrings bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_5_4_LogicBool bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_81_ta_ph = null;
BEC_2_4_3_MathInt bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_4_6_TextString bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_6_6_SystemObject bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_5_4_LogicBool bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_4_6_TextString bevt_114_ta_ph = null;
BEC_2_5_4_LogicBool bevt_115_ta_ph = null;
BEC_2_5_4_LogicBool bevt_116_ta_ph = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
/* Line: 148*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 148*/ {
bevl_clnode = bevl_ci.bemd_0(-641452021);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_9_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevp_q);
bevt_12_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(-507142367);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(350691792);
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevp_q);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_17_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_16_ta_ph = bevt_17_ta_ph.bemd_0(-507142367);
bevt_15_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_ta_ph );
bevt_18_ta_ph = bevp_build.bem_libNameGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_relEmitName_1(bevt_18_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_34));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_22_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(576833844);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(728171232);
if (((BEC_2_5_4_LogicBool) bevt_20_ta_ph).bevi_bool)/* Line: 154*/ {
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_28_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(-507142367);
bevt_26_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_ta_ph );
bevt_29_ta_ph = bevp_build.bem_libNameGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bem_relEmitName_1(bevt_29_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_36));
bevl_nc = bevt_23_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_34_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_33_ta_ph = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_34_ta_ph);
bevt_32_ta_ph = (BEC_2_4_6_TextString) bevt_33_ta_ph.bem_addValue_1(bevl_nc);
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_31_ta_ph = (BEC_2_4_6_TextString) bevt_32_ta_ph.bem_addValue_1(bevt_35_ta_ph);
bevt_31_ta_ph.bem_addValue_1(bevp_nl);
bevt_38_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_0(576833844);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(728171232);
if (((BEC_2_5_4_LogicBool) bevt_36_ta_ph).bevi_bool)/* Line: 163*/ {
bevt_42_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_41_ta_ph = (BEC_2_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_42_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) bevt_41_ta_ph.bem_addValue_1(bevl_nc);
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_39_ta_ph = (BEC_2_4_6_TextString) bevt_40_ta_ph.bem_addValue_1(bevt_43_ta_ph);
bevt_39_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 164*/
} /* Line: 163*/
} /* Line: 154*/
 else /* Line: 148*/ {
break;
} /* Line: 148*/
} /* Line: 148*/
bevl_smap = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_ta_ph = bevp_smnlcs.bem_keysGet_0();
bevt_0_ta_loop = bevt_44_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 172*/ {
bevt_45_ta_ph = bevt_0_ta_loop.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 172*/ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-641452021);
bevt_53_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_52_ta_ph = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_53_ta_ph);
bevt_55_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_54_ta_ph = bevt_55_ta_ph.bem_quoteGet_0();
bevt_51_ta_ph = (BEC_2_4_6_TextString) bevt_52_ta_ph.bem_addValue_1(bevt_54_ta_ph);
bevt_50_ta_ph = (BEC_2_4_6_TextString) bevt_51_ta_ph.bem_addValue_1(bevl_smk);
bevt_57_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_56_ta_ph = bevt_57_ta_ph.bem_quoteGet_0();
bevt_49_ta_ph = (BEC_2_4_6_TextString) bevt_50_ta_ph.bem_addValue_1(bevt_56_ta_ph);
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_48_ta_ph = (BEC_2_4_6_TextString) bevt_49_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_59_ta_ph = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_ta_ph = (BEC_2_4_6_TextString) bevt_48_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_60_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_46_ta_ph = (BEC_2_4_6_TextString) bevt_47_ta_ph.bem_addValue_1(bevt_60_ta_ph);
bevt_46_ta_ph.bem_addValue_1(bevp_nl);
bevt_68_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_67_ta_ph = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_68_ta_ph);
bevt_70_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_69_ta_ph = bevt_70_ta_ph.bem_quoteGet_0();
bevt_66_ta_ph = (BEC_2_4_6_TextString) bevt_67_ta_ph.bem_addValue_1(bevt_69_ta_ph);
bevt_65_ta_ph = (BEC_2_4_6_TextString) bevt_66_ta_ph.bem_addValue_1(bevl_smk);
bevt_72_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_71_ta_ph = bevt_72_ta_ph.bem_quoteGet_0();
bevt_64_ta_ph = (BEC_2_4_6_TextString) bevt_65_ta_ph.bem_addValue_1(bevt_71_ta_ph);
bevt_73_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_63_ta_ph = (BEC_2_4_6_TextString) bevt_64_ta_ph.bem_addValue_1(bevt_73_ta_ph);
bevt_74_ta_ph = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_ta_ph = (BEC_2_4_6_TextString) bevt_63_ta_ph.bem_addValue_1(bevt_74_ta_ph);
bevt_75_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_61_ta_ph = (BEC_2_4_6_TextString) bevt_62_ta_ph.bem_addValue_1(bevt_75_ta_ph);
bevt_61_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 175*/
 else /* Line: 172*/ {
break;
} /* Line: 172*/
} /* Line: 172*/
bevt_77_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_78_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_76_ta_ph = bevt_77_ta_ph.bem_has_1(bevt_78_ta_ph);
if (!(bevt_76_ta_ph.bevi_bool))/* Line: 179*/ {
bevl_libe.bem_write_1(bevl_smap);
} /* Line: 180*/
bevt_81_ta_ph = bevp_build.bem_usedLibrarysGet_0();
bevt_80_ta_ph = bevt_81_ta_ph.bem_sizeGet_0();
bevt_82_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevt_80_ta_ph.bevi_int == bevt_82_ta_ph.bevi_int) {
bevt_79_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_79_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_79_ta_ph.bevi_bool)/* Line: 184*/ {
bevt_84_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_83_ta_ph = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_84_ta_ph);
bevt_83_ta_ph.bem_addValue_1(bevp_nl);
bevt_86_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_85_ta_ph = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_86_ta_ph);
bevt_85_ta_ph.bem_addValue_1(bevp_nl);
bevt_88_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_87_ta_ph = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_88_ta_ph);
bevt_87_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 187*/
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_89_ta_ph = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_89_ta_ph);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevt_93_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_92_ta_ph = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_93_ta_ph);
bevt_94_ta_ph = bevl_maincc.bem_fullEmitNameGet_0();
bevt_91_ta_ph = (BEC_2_4_6_TextString) bevt_92_ta_ph.bem_addValue_1(bevt_94_ta_ph);
bevt_95_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_90_ta_ph = (BEC_2_4_6_TextString) bevt_91_ta_ph.bem_addValue_1(bevt_95_ta_ph);
bevt_90_ta_ph.bem_addValue_1(bevp_nl);
bevt_96_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_96_ta_ph.bevi_bool)/* Line: 200*/ {
bevt_98_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_99_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_97_ta_ph = bevt_98_ta_ph.bem_has_1(bevt_99_ta_ph);
if (!(bevt_97_ta_ph.bevi_bool))/* Line: 201*/ {
bevt_101_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_100_ta_ph = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_101_ta_ph);
bevt_100_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 202*/
} /* Line: 201*/
bevt_105_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_104_ta_ph = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_105_ta_ph);
bevt_107_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_106_ta_ph = bevt_107_ta_ph.bemd_0(-2079457415);
bevt_103_ta_ph = (BEC_2_4_6_TextString) bevt_104_ta_ph.bem_addValue_1(bevt_106_ta_ph);
bevt_108_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_102_ta_ph = (BEC_2_4_6_TextString) bevt_103_ta_ph.bem_addValue_1(bevt_108_ta_ph);
bevt_102_ta_ph.bem_addValue_1(bevp_nl);
bevt_109_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_109_ta_ph.bevi_bool)/* Line: 206*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 207*/
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_110_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_110_ta_ph.bevi_bool)/* Line: 212*/ {
bevt_112_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_111_ta_ph = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_112_ta_ph);
bevt_111_ta_ph.bem_addValue_1(bevp_nl);
bevt_114_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_113_ta_ph = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_114_ta_ph);
bevt_113_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 214*/
bevt_115_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_115_ta_ph.bevi_bool)/* Line: 216*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 217*/
bem_finishLibOutput_1(bevl_libe);
bevt_116_ta_ph = bevp_build.bem_saveSynsGet_0();
if (bevt_116_ta_ph.bevi_bool)/* Line: 222*/ {
bem_saveSyns_0();
} /* Line: 223*/
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 229*/ {
} /* Line: 229*/
 else /* Line: 231*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 232*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
beva_b.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 233*/
bevt_4_ta_ph = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 235*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_54));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_exceptDec);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_56));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJSEmitter_bels_58));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_parent);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_5_ta_ph);
bevl_extstr = (BEC_2_4_6_TextString) bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_8_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_7_ta_ph = bevl_extstr.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildJSEmitter_bels_59));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevl_extstr = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildJSEmitter_bels_60));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-558666375);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJSEmitter_bels_62));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-558666375);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
if (beva_isOnce.bevi_bool)/* Line: 266*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(27, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(beva_belsName);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_15_ta_ph);
return bevt_0_ta_ph;
} /* Line: 267*/
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_26_ta_ph = bevp_build.bem_libNameGet_0();
bevt_25_ta_ph = beva_newcc.bem_relEmitName_1(bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(beva_belsName);
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(beva_lisz);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_31_ta_ph);
return bevt_16_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 273*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 274*/
 else /* Line: 275*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 276*/
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_6_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_66));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_9_ta_ph);
bevt_8_ta_ph.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public override BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(898129746);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 292*/ {
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_notEmpty_1(beva_callArgs);
if (bevt_2_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_67));
beva_callArgs = bevt_4_ta_ph.bem_add_1(beva_callArgs);
} /* Line: 294*/
 else /* Line: 295*/ {
beva_callArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
} /* Line: 296*/
bevt_10_ta_ph = bevp_parentConf.bem_emitNameGet_0();
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_68));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(-2079457415);
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_69));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_callArgs);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_15_ta_ph);
return bevt_5_ta_ph;
} /* Line: 298*/
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_70));
bevt_20_ta_ph = beva_callTarget.bem_add_1(bevt_21_ta_ph);
bevt_23_ta_ph = beva_node.bem_heldGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(-2079457415);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_22_ta_ph);
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_71));
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(beva_callArgs);
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_25_ta_ph);
return bevt_16_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevl_end;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_allOnceDecs == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 312*/ {
bevp_allOnceDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 313*/
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_ta_ph;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_3_2_4_6_IOFileWriter bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getLibOutput_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_13_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
if (bevp_shlibe == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 329*/ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_7_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 332*/
bevt_9_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_ta_ph.bemd_0(-476757857);
bevt_11_ta_ph = bevp_build.bem_paramsGet_0();
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_72));
bevt_10_ta_ph = bevt_11_ta_ph.bem_has_1(bevt_12_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_14_ta_ph = bevp_build.bem_paramsGet_0();
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_72));
bevt_13_ta_ph = bevt_14_ta_ph.bem_get_1(bevt_15_ta_ph);
bevt_0_ta_loop = bevt_13_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 337*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 337*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-641452021);
bevt_17_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-476757857);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_ta_ph.bemd_0(-1751369017);
bevt_20_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph.bemd_0(-645051051);
bevt_21_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 342*/
 else /* Line: 337*/ {
break;
} /* Line: 337*/
} /* Line: 337*/
} /* Line: 337*/
} /* Line: 336*/
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_73));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_spropDecGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_74));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_anyName);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_75));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_typeName);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = beva_newcc.bem_relEmitName_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJSEmitter_bels_76));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_77));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_count);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_78));
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_79));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_7_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_80));
bevt_1_ta_ph = beva_nameSpace.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_emitName);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_81));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = base.bem_getClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = base.bem_getLocalClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGetDirect_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 17, 18, 22, 24, 25, 27, 28, 32, 32, 32, 36, 36, 36, 36, 40, 40, 40, 40, 44, 44, 44, 44, 44, 44, 44, 44, 48, 48, 48, 49, 50, 50, 50, 50, 50, 50, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 63, 63, 63, 63, 63, 63, 63, 67, 67, 67, 67, 67, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 70, 70, 70, 75, 75, 76, 78, 78, 78, 78, 80, 81, 0, 81, 81, 83, 85, 85, 87, 87, 87, 87, 87, 87, 91, 91, 91, 96, 96, 96, 97, 99, 99, 99, 99, 99, 102, 102, 102, 102, 104, 104, 104, 106, 106, 106, 106, 106, 109, 109, 109, 109, 109, 109, 111, 111, 111, 113, 118, 119, 120, 126, 126, 126, 131, 132, 132, 132, 132, 134, 134, 143, 145, 146, 147, 148, 148, 150, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 154, 154, 154, 156, 156, 156, 156, 156, 156, 156, 156, 156, 162, 162, 162, 162, 162, 162, 163, 163, 163, 164, 164, 164, 164, 164, 164, 170, 172, 172, 0, 172, 172, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 179, 179, 179, 180, 184, 184, 184, 184, 184, 185, 185, 185, 186, 186, 186, 187, 187, 187, 190, 191, 194, 195, 195, 196, 198, 199, 199, 199, 199, 199, 199, 199, 200, 201, 201, 201, 202, 202, 202, 205, 205, 205, 205, 205, 205, 205, 205, 206, 207, 209, 210, 211, 212, 213, 213, 213, 214, 214, 214, 216, 217, 220, 222, 223, 229, 232, 232, 232, 233, 233, 235, 235, 240, 240, 244, 244, 244, 244, 244, 244, 248, 248, 252, 252, 252, 252, 252, 252, 252, 253, 253, 253, 253, 253, 254, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 273, 273, 274, 274, 274, 276, 276, 278, 278, 278, 278, 278, 286, 286, 286, 287, 288, 292, 292, 293, 293, 294, 294, 296, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 304, 305, 312, 312, 313, 315, 316, 316, 321, 321, 329, 329, 330, 331, 331, 331, 331, 331, 332, 332, 332, 334, 334, 334, 336, 336, 336, 337, 337, 337, 337, 0, 337, 337, 338, 338, 339, 339, 339, 340, 340, 341, 341, 342, 348, 352, 353, 358, 358, 362, 362, 366, 366, 370, 370, 374, 374, 378, 378, 382, 382, 387, 387, 393, 393, 398, 398, 402, 402, 402, 402, 402, 402, 406, 406, 410, 410, 410, 410, 410, 415, 415, 415, 415, 415, 415, 415, 420, 420, 420, 420, 420, 420, 420, 422, 424, 424, 424, 429, 429, 433, 433, 437, 437, 437, 437, 442, 442, 446, 447, 447, 448, 452, 453, 453, 454, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {97, 98, 99, 100, 101, 102, 103, 104, 110, 111, 112, 118, 119, 120, 121, 127, 128, 129, 130, 140, 141, 142, 143, 144, 145, 146, 147, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 200, 201, 202, 203, 204, 205, 206, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 266, 267, 268, 269, 270, 271, 272, 273, 274, 274, 277, 279, 281, 284, 285, 287, 288, 289, 290, 291, 292, 298, 299, 300, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 363, 364, 365, 371, 372, 373, 382, 384, 385, 386, 387, 389, 390, 525, 526, 527, 528, 529, 532, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 577, 578, 579, 580, 581, 582, 590, 591, 592, 592, 595, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 635, 636, 637, 639, 641, 642, 643, 644, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 676, 677, 678, 680, 681, 682, 685, 686, 687, 688, 689, 690, 691, 692, 693, 695, 697, 698, 699, 700, 702, 703, 704, 705, 706, 707, 709, 711, 713, 714, 716, 726, 730, 731, 736, 737, 738, 740, 741, 747, 748, 756, 757, 758, 759, 760, 761, 765, 766, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 927, 932, 933, 934, 935, 938, 939, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 979, 980, 982, 983, 985, 986, 989, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000, 1001, 1002, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1018, 1019, 1024, 1029, 1030, 1032, 1033, 1034, 1038, 1039, 1070, 1075, 1076, 1077, 1078, 1079, 1080, 1085, 1086, 1087, 1088, 1090, 1091, 1092, 1093, 1094, 1095, 1097, 1098, 1099, 1100, 1100, 1103, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1115, 1123, 1126, 1127, 1132, 1133, 1137, 1138, 1142, 1143, 1147, 1148, 1152, 1153, 1157, 1158, 1162, 1163, 1167, 1168, 1172, 1173, 1177, 1178, 1186, 1187, 1188, 1189, 1190, 1191, 1195, 1196, 1203, 1204, 1205, 1206, 1207, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1243, 1248, 1249, 1253, 1254, 1260, 1261, 1262, 1263, 1267, 1268, 1273, 1274, 1275, 1276, 1281, 1282, 1283, 1284, 1287, 1290, 1293, 1297, 1301, 1304, 1307, 1311};
/* BEGIN LINEINFO 
assign 1 16 97
new 0 16 97
assign 1 17 98
new 0 17 98
assign 1 18 99
new 0 18 99
new 1 22 100
assign 1 24 101
new 0 24 101
assign 1 25 102
new 0 25 102
assign 1 27 103
new 0 27 103
assign 1 28 104
new 0 28 104
assign 1 32 110
formTarg 1 32 110
assign 1 32 111
add 1 32 111
return 1 32 112
assign 1 36 118
formCallTarg 1 36 118
assign 1 36 119
new 0 36 119
assign 1 36 120
add 1 36 120
return 1 36 121
assign 1 40 127
formCallTarg 1 40 127
assign 1 40 128
new 0 40 128
assign 1 40 129
add 1 40 129
return 1 40 130
assign 1 44 140
new 0 44 140
assign 1 44 141
addValue 1 44 141
assign 1 44 142
secondGet 0 44 142
assign 1 44 143
formTarg 1 44 143
assign 1 44 144
addValue 1 44 144
assign 1 44 145
new 0 44 145
assign 1 44 146
addValue 1 44 146
addValue 1 44 147
assign 1 48 168
new 0 48 168
assign 1 48 169
toString 0 48 169
assign 1 48 170
add 1 48 170
incrementValue 0 49 171
assign 1 50 172
new 0 50 172
assign 1 50 173
addValue 1 50 173
assign 1 50 174
addValue 1 50 174
assign 1 50 175
new 0 50 175
assign 1 50 176
addValue 1 50 176
addValue 1 50 177
assign 1 55 178
containedGet 0 55 178
assign 1 55 179
firstGet 0 55 179
assign 1 55 180
containedGet 0 55 180
assign 1 55 181
firstGet 0 55 181
assign 1 55 182
new 0 55 182
assign 1 55 183
add 1 55 183
assign 1 55 184
new 0 55 184
assign 1 55 185
add 1 55 185
assign 1 55 186
finalAssign 4 55 186
addValue 1 55 187
assign 1 63 200
emitNameGet 0 63 200
assign 1 63 201
addValue 1 63 201
assign 1 63 202
new 0 63 202
assign 1 63 203
addValue 1 63 203
assign 1 63 204
addValue 1 63 204
assign 1 63 205
new 0 63 205
addValue 1 63 206
assign 1 67 226
emitNameGet 0 67 226
assign 1 67 227
addValue 1 67 227
assign 1 67 228
new 0 67 228
assign 1 67 229
addValue 1 67 229
addValue 1 67 230
assign 1 68 231
new 0 68 231
assign 1 68 232
addValue 1 68 232
assign 1 68 233
heldGet 0 68 233
assign 1 68 234
namepathGet 0 68 234
assign 1 68 235
getClassConfig 1 68 235
assign 1 68 236
libNameGet 0 68 236
assign 1 68 237
relEmitName 1 68 237
assign 1 68 238
addValue 1 68 238
assign 1 68 239
new 0 68 239
assign 1 68 240
addValue 1 68 240
addValue 1 68 241
assign 1 70 242
new 0 70 242
assign 1 70 243
addValue 1 70 243
addValue 1 70 244
assign 1 75 266
heldGet 0 75 266
assign 1 75 267
synGet 0 75 267
assign 1 76 268
ptyListGet 0 76 268
assign 1 78 269
emitNameGet 0 78 269
assign 1 78 270
addValue 1 78 270
assign 1 78 271
new 0 78 271
addValue 1 78 272
assign 1 80 273
new 0 80 273
assign 1 81 274
iteratorGet 0 0 274
assign 1 81 277
hasNextGet 0 81 277
assign 1 81 279
nextGet 0 81 279
assign 1 83 281
new 0 83 281
assign 1 85 284
new 0 85 284
addValue 1 85 285
assign 1 87 287
addValue 1 87 287
assign 1 87 288
new 0 87 288
assign 1 87 289
addValue 1 87 289
assign 1 87 290
nameGet 0 87 290
assign 1 87 291
addValue 1 87 291
addValue 1 87 292
assign 1 91 298
new 0 91 298
assign 1 91 299
addValue 1 91 299
addValue 1 91 300
assign 1 96 328
heldGet 0 96 328
assign 1 96 329
namepathGet 0 96 329
assign 1 96 330
getClassConfig 1 96 330
assign 1 97 331
getInitialInst 1 97 331
assign 1 99 332
emitNameGet 0 99 332
assign 1 99 333
addValue 1 99 333
assign 1 99 334
new 0 99 334
assign 1 99 335
addValue 1 99 335
addValue 1 99 336
assign 1 102 337
addValue 1 102 337
assign 1 102 338
new 0 102 338
assign 1 102 339
addValue 1 102 339
addValue 1 102 340
assign 1 104 341
new 0 104 341
assign 1 104 342
addValue 1 104 342
addValue 1 104 343
assign 1 106 344
emitNameGet 0 106 344
assign 1 106 345
addValue 1 106 345
assign 1 106 346
new 0 106 346
assign 1 106 347
addValue 1 106 347
addValue 1 106 348
assign 1 109 349
new 0 109 349
assign 1 109 350
addValue 1 109 350
assign 1 109 351
addValue 1 109 351
assign 1 109 352
new 0 109 352
assign 1 109 353
addValue 1 109 353
addValue 1 109 354
assign 1 111 355
new 0 111 355
assign 1 111 356
addValue 1 111 356
addValue 1 111 357
buildPropList 0 113 358
getCode 2 118 363
assign 1 119 364
toString 0 119 364
addValue 1 120 365
assign 1 126 371
new 0 126 371
assign 1 126 372
addValue 1 126 372
addValue 1 126 373
assign 1 131 382
isPropertyGet 0 131 382
assign 1 132 384
new 0 132 384
assign 1 132 385
nameGet 0 132 385
assign 1 132 386
add 1 132 386
return 1 132 387
assign 1 134 389
nameForVar 1 134 389
return 1 134 390
assign 1 143 525
getLibOutput 0 143 525
assign 1 145 526
new 0 145 526
assign 1 146 527
new 0 146 527
assign 1 147 528
new 0 147 528
assign 1 148 529
iteratorGet 0 148 529
assign 1 148 532
hasNextGet 0 148 532
assign 1 150 534
nextGet 0 150 534
assign 1 152 535
new 0 152 535
assign 1 152 536
addValue 1 152 536
assign 1 152 537
addValue 1 152 537
assign 1 152 538
heldGet 0 152 538
assign 1 152 539
namepathGet 0 152 539
assign 1 152 540
toString 0 152 540
assign 1 152 541
addValue 1 152 541
assign 1 152 542
addValue 1 152 542
assign 1 152 543
new 0 152 543
assign 1 152 544
addValue 1 152 544
assign 1 152 545
heldGet 0 152 545
assign 1 152 546
namepathGet 0 152 546
assign 1 152 547
getClassConfig 1 152 547
assign 1 152 548
libNameGet 0 152 548
assign 1 152 549
relEmitName 1 152 549
assign 1 152 550
addValue 1 152 550
assign 1 152 551
new 0 152 551
assign 1 152 552
addValue 1 152 552
addValue 1 152 553
assign 1 154 554
heldGet 0 154 554
assign 1 154 555
synGet 0 154 555
assign 1 154 556
hasDefaultGet 0 154 556
assign 1 156 558
new 0 156 558
assign 1 156 559
heldGet 0 156 559
assign 1 156 560
namepathGet 0 156 560
assign 1 156 561
getClassConfig 1 156 561
assign 1 156 562
libNameGet 0 156 562
assign 1 156 563
relEmitName 1 156 563
assign 1 156 564
add 1 156 564
assign 1 156 565
new 0 156 565
assign 1 156 566
add 1 156 566
assign 1 162 567
new 0 162 567
assign 1 162 568
addValue 1 162 568
assign 1 162 569
addValue 1 162 569
assign 1 162 570
new 0 162 570
assign 1 162 571
addValue 1 162 571
addValue 1 162 572
assign 1 163 573
heldGet 0 163 573
assign 1 163 574
synGet 0 163 574
assign 1 163 575
hasDefaultGet 0 163 575
assign 1 164 577
new 0 164 577
assign 1 164 578
addValue 1 164 578
assign 1 164 579
addValue 1 164 579
assign 1 164 580
new 0 164 580
assign 1 164 581
addValue 1 164 581
addValue 1 164 582
assign 1 170 590
new 0 170 590
assign 1 172 591
keysGet 0 172 591
assign 1 172 592
iteratorGet 0 0 592
assign 1 172 595
hasNextGet 0 172 595
assign 1 172 597
nextGet 0 172 597
assign 1 174 598
new 0 174 598
assign 1 174 599
addValue 1 174 599
assign 1 174 600
new 0 174 600
assign 1 174 601
quoteGet 0 174 601
assign 1 174 602
addValue 1 174 602
assign 1 174 603
addValue 1 174 603
assign 1 174 604
new 0 174 604
assign 1 174 605
quoteGet 0 174 605
assign 1 174 606
addValue 1 174 606
assign 1 174 607
new 0 174 607
assign 1 174 608
addValue 1 174 608
assign 1 174 609
get 1 174 609
assign 1 174 610
addValue 1 174 610
assign 1 174 611
new 0 174 611
assign 1 174 612
addValue 1 174 612
addValue 1 174 613
assign 1 175 614
new 0 175 614
assign 1 175 615
addValue 1 175 615
assign 1 175 616
new 0 175 616
assign 1 175 617
quoteGet 0 175 617
assign 1 175 618
addValue 1 175 618
assign 1 175 619
addValue 1 175 619
assign 1 175 620
new 0 175 620
assign 1 175 621
quoteGet 0 175 621
assign 1 175 622
addValue 1 175 622
assign 1 175 623
new 0 175 623
assign 1 175 624
addValue 1 175 624
assign 1 175 625
get 1 175 625
assign 1 175 626
addValue 1 175 626
assign 1 175 627
new 0 175 627
assign 1 175 628
addValue 1 175 628
addValue 1 175 629
assign 1 179 635
emitChecksGet 0 179 635
assign 1 179 636
new 0 179 636
assign 1 179 637
has 1 179 637
write 1 180 639
assign 1 184 641
usedLibrarysGet 0 184 641
assign 1 184 642
sizeGet 0 184 642
assign 1 184 643
new 0 184 643
assign 1 184 644
equals 1 184 649
assign 1 185 650
new 0 185 650
assign 1 185 651
addValue 1 185 651
addValue 1 185 652
assign 1 186 653
new 0 186 653
assign 1 186 654
addValue 1 186 654
addValue 1 186 655
assign 1 187 656
new 0 187 656
assign 1 187 657
addValue 1 187 657
addValue 1 187 658
write 1 190 660
write 1 191 661
assign 1 194 662
new 0 194 662
assign 1 195 663
mainNameGet 0 195 663
fromString 1 195 664
assign 1 196 665
getClassConfig 1 196 665
assign 1 198 666
new 0 198 666
assign 1 199 667
new 0 199 667
assign 1 199 668
addValue 1 199 668
assign 1 199 669
fullEmitNameGet 0 199 669
assign 1 199 670
addValue 1 199 670
assign 1 199 671
new 0 199 671
assign 1 199 672
addValue 1 199 672
addValue 1 199 673
assign 1 200 674
ownProcessGet 0 200 674
assign 1 201 676
emitChecksGet 0 201 676
assign 1 201 677
new 0 201 677
assign 1 201 678
has 1 201 678
assign 1 202 680
new 0 202 680
assign 1 202 681
addValue 1 202 681
addValue 1 202 682
assign 1 205 685
new 0 205 685
assign 1 205 686
addValue 1 205 686
assign 1 205 687
outputPlatformGet 0 205 687
assign 1 205 688
nameGet 0 205 688
assign 1 205 689
addValue 1 205 689
assign 1 205 690
new 0 205 690
assign 1 205 691
addValue 1 205 691
addValue 1 205 692
assign 1 206 693
doMainGet 0 206 693
write 1 207 695
assign 1 209 697
new 0 209 697
write 1 210 698
write 1 211 699
assign 1 212 700
ownProcessGet 0 212 700
assign 1 213 702
new 0 213 702
assign 1 213 703
addValue 1 213 703
addValue 1 213 704
assign 1 214 705
new 0 214 705
assign 1 214 706
addValue 1 214 706
addValue 1 214 707
assign 1 216 709
doMainGet 0 216 709
write 1 217 711
finishLibOutput 1 220 713
assign 1 222 714
saveSynsGet 0 222 714
saveSyns 0 223 716
assign 1 229 726
isPropertyGet 0 229 726
assign 1 232 730
isArgGet 0 232 730
assign 1 232 731
not 0 232 736
assign 1 233 737
new 0 233 737
addValue 1 233 738
assign 1 235 740
nameForVar 1 235 740
addValue 1 235 741
assign 1 240 747
new 0 240 747
return 1 240 748
assign 1 244 756
new 0 244 756
assign 1 244 757
add 1 244 757
assign 1 244 758
new 0 244 758
assign 1 244 759
add 1 244 759
assign 1 244 760
add 1 244 760
return 1 244 761
assign 1 248 765
new 0 248 765
return 1 248 766
assign 1 252 780
emitNameGet 0 252 780
assign 1 252 781
new 0 252 781
assign 1 252 782
add 1 252 782
assign 1 252 783
add 1 252 783
assign 1 252 784
new 0 252 784
assign 1 252 785
add 1 252 785
assign 1 252 786
addValue 1 252 786
assign 1 253 787
emitNameGet 0 253 787
assign 1 253 788
add 1 253 788
assign 1 253 789
new 0 253 789
assign 1 253 790
add 1 253 790
assign 1 253 791
addValue 1 253 791
return 1 254 792
assign 1 258 806
new 0 258 806
assign 1 258 807
libNameGet 0 258 807
assign 1 258 808
relEmitName 1 258 808
assign 1 258 809
add 1 258 809
assign 1 258 810
new 0 258 810
assign 1 258 811
add 1 258 811
assign 1 258 812
heldGet 0 258 812
assign 1 258 813
literalValueGet 0 258 813
assign 1 258 814
add 1 258 814
assign 1 258 815
new 0 258 815
assign 1 258 816
add 1 258 816
return 1 258 817
assign 1 262 831
new 0 262 831
assign 1 262 832
libNameGet 0 262 832
assign 1 262 833
relEmitName 1 262 833
assign 1 262 834
add 1 262 834
assign 1 262 835
new 0 262 835
assign 1 262 836
add 1 262 836
assign 1 262 837
heldGet 0 262 837
assign 1 262 838
literalValueGet 0 262 838
assign 1 262 839
add 1 262 839
assign 1 262 840
new 0 262 840
assign 1 262 841
add 1 262 841
return 1 262 842
assign 1 267 878
new 0 267 878
assign 1 267 879
libNameGet 0 267 879
assign 1 267 880
relEmitName 1 267 880
assign 1 267 881
add 1 267 881
assign 1 267 882
new 0 267 882
assign 1 267 883
add 1 267 883
assign 1 267 884
emitNameGet 0 267 884
assign 1 267 885
add 1 267 885
assign 1 267 886
new 0 267 886
assign 1 267 887
add 1 267 887
assign 1 267 888
add 1 267 888
assign 1 267 889
new 0 267 889
assign 1 267 890
add 1 267 890
assign 1 267 891
add 1 267 891
assign 1 267 892
new 0 267 892
assign 1 267 893
add 1 267 893
return 1 267 894
assign 1 269 896
new 0 269 896
assign 1 269 897
libNameGet 0 269 897
assign 1 269 898
relEmitName 1 269 898
assign 1 269 899
add 1 269 899
assign 1 269 900
new 0 269 900
assign 1 269 901
add 1 269 901
assign 1 269 902
emitNameGet 0 269 902
assign 1 269 903
add 1 269 903
assign 1 269 904
new 0 269 904
assign 1 269 905
add 1 269 905
assign 1 269 906
add 1 269 906
assign 1 269 907
new 0 269 907
assign 1 269 908
add 1 269 908
assign 1 269 909
add 1 269 909
assign 1 269 910
new 0 269 910
assign 1 269 911
add 1 269 911
return 1 269 912
assign 1 273 927
def 1 273 932
assign 1 274 933
libNameGet 0 274 933
assign 1 274 934
relEmitName 1 274 934
assign 1 274 935
extend 1 274 935
assign 1 276 938
new 0 276 938
assign 1 276 939
extend 1 276 939
assign 1 278 941
new 0 278 941
assign 1 278 942
emitNameGet 0 278 942
assign 1 278 943
addValue 1 278 943
assign 1 278 944
new 0 278 944
assign 1 278 945
addValue 1 278 945
assign 1 286 946
new 0 286 946
assign 1 286 947
addValue 1 286 947
addValue 1 286 948
addValue 1 287 949
return 1 288 950
assign 1 292 979
heldGet 0 292 979
assign 1 292 980
superCallGet 0 292 980
assign 1 293 982
new 0 293 982
assign 1 293 983
notEmpty 1 293 983
assign 1 294 985
new 0 294 985
assign 1 294 986
add 1 294 986
assign 1 296 989
new 0 296 989
assign 1 298 991
emitNameGet 0 298 991
assign 1 298 992
new 0 298 992
assign 1 298 993
add 1 298 993
assign 1 298 994
heldGet 0 298 994
assign 1 298 995
nameGet 0 298 995
assign 1 298 996
add 1 298 996
assign 1 298 997
new 0 298 997
assign 1 298 998
add 1 298 998
assign 1 298 999
add 1 298 999
assign 1 298 1000
new 0 298 1000
assign 1 298 1001
add 1 298 1001
return 1 298 1002
assign 1 300 1004
new 0 300 1004
assign 1 300 1005
add 1 300 1005
assign 1 300 1006
heldGet 0 300 1006
assign 1 300 1007
nameGet 0 300 1007
assign 1 300 1008
add 1 300 1008
assign 1 300 1009
new 0 300 1009
assign 1 300 1010
add 1 300 1010
assign 1 300 1011
add 1 300 1011
assign 1 300 1012
new 0 300 1012
assign 1 300 1013
add 1 300 1013
return 1 300 1014
assign 1 304 1018
new 0 304 1018
return 1 305 1019
assign 1 312 1024
undef 1 312 1029
assign 1 313 1030
new 0 313 1030
addValue 1 315 1032
assign 1 316 1033
new 0 316 1033
return 1 316 1034
assign 1 321 1038
getLibOutput 0 321 1038
return 1 321 1039
assign 1 329 1070
undef 1 329 1075
assign 1 330 1076
new 0 330 1076
assign 1 331 1077
parentGet 0 331 1077
assign 1 331 1078
fileGet 0 331 1078
assign 1 331 1079
existsGet 0 331 1079
assign 1 331 1080
not 0 331 1085
assign 1 332 1086
parentGet 0 332 1086
assign 1 332 1087
fileGet 0 332 1087
makeDirs 0 332 1088
assign 1 334 1090
fileGet 0 334 1090
assign 1 334 1091
writerGet 0 334 1091
assign 1 334 1092
open 0 334 1092
assign 1 336 1093
paramsGet 0 336 1093
assign 1 336 1094
new 0 336 1094
assign 1 336 1095
has 1 336 1095
assign 1 337 1097
paramsGet 0 337 1097
assign 1 337 1098
new 0 337 1098
assign 1 337 1099
get 1 337 1099
assign 1 337 1100
iteratorGet 0 0 1100
assign 1 337 1103
hasNextGet 0 337 1103
assign 1 337 1105
nextGet 0 337 1105
assign 1 338 1106
apNew 1 338 1106
assign 1 338 1107
fileGet 0 338 1107
assign 1 339 1108
readerGet 0 339 1108
assign 1 339 1109
open 0 339 1109
assign 1 339 1110
readString 0 339 1110
assign 1 340 1111
readerGet 0 340 1111
close 0 340 1112
assign 1 341 1113
countLines 1 341 1113
addValue 1 341 1114
write 1 342 1115
return 1 348 1123
close 0 352 1126
assign 1 353 1127
assign 1 358 1132
new 0 358 1132
return 1 358 1133
assign 1 362 1137
new 0 362 1137
return 1 362 1138
assign 1 366 1142
new 0 366 1142
return 1 366 1143
assign 1 370 1147
new 0 370 1147
return 1 370 1148
assign 1 374 1152
new 0 374 1152
return 1 374 1153
assign 1 378 1157
new 0 378 1157
return 1 378 1158
assign 1 382 1162
new 0 382 1162
return 1 382 1163
assign 1 387 1167
new 0 387 1167
return 1 387 1168
assign 1 393 1172
new 0 393 1172
return 1 393 1173
assign 1 398 1177
new 0 398 1177
return 1 398 1178
assign 1 402 1186
new 0 402 1186
assign 1 402 1187
add 1 402 1187
assign 1 402 1188
new 0 402 1188
assign 1 402 1189
add 1 402 1189
assign 1 402 1190
add 1 402 1190
return 1 402 1191
assign 1 406 1195
new 0 406 1195
return 1 406 1196
assign 1 410 1203
libNameGet 0 410 1203
assign 1 410 1204
relEmitName 1 410 1204
assign 1 410 1205
new 0 410 1205
assign 1 410 1206
add 1 410 1206
return 1 410 1207
assign 1 415 1216
emitNameGet 0 415 1216
assign 1 415 1217
new 0 415 1217
assign 1 415 1218
add 1 415 1218
assign 1 415 1219
new 0 415 1219
assign 1 415 1220
add 1 415 1220
assign 1 415 1221
add 1 415 1221
return 1 415 1222
assign 1 420 1233
emitNameGet 0 420 1233
assign 1 420 1234
addValue 1 420 1234
assign 1 420 1235
new 0 420 1235
assign 1 420 1236
addValue 1 420 1236
assign 1 420 1237
addValue 1 420 1237
assign 1 420 1238
new 0 420 1238
addValue 1 420 1239
addValue 1 422 1240
assign 1 424 1241
new 0 424 1241
assign 1 424 1242
addValue 1 424 1242
addValue 1 424 1243
assign 1 429 1248
new 0 429 1248
return 1 429 1249
assign 1 433 1253
new 0 433 1253
return 1 433 1254
assign 1 437 1260
new 0 437 1260
assign 1 437 1261
add 1 437 1261
assign 1 437 1262
add 1 437 1262
return 1 437 1263
assign 1 442 1267
new 0 442 1267
return 1 442 1268
assign 1 446 1273
getClassConfig 1 446 1273
assign 1 447 1274
fullEmitNameGet 0 447 1274
emitNameSet 1 447 1275
return 1 448 1276
assign 1 452 1281
getLocalClassConfig 1 452 1281
assign 1 453 1282
fullEmitNameGet 0 453 1282
emitNameSet 1 453 1283
return 1 454 1284
return 1 0 1287
return 1 0 1290
assign 1 0 1293
assign 1 0 1297
return 1 0 1301
return 1 0 1304
assign 1 0 1307
assign 1 0 1311
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 518059365: return bem_overrideMtdDecGet_0();
case -1044758745: return bem_serializeToString_0();
case -1874656189: return bem_libEmitPathGetDirect_0();
case -221211760: return bem_smnlecsGetDirect_0();
case -205003882: return bem_propertyDecsGetDirect_0();
case 1230417369: return bem_useDynMethodsGet_0();
case 2132420479: return bem_many_0();
case -2127426765: return bem_nullValueGetDirect_0();
case 1480568842: return bem_lastMethodsSizeGet_0();
case 56154670: return bem_returnTypeGetDirect_0();
case -1616980217: return bem_instanceNotEqualGet_0();
case 1863831917: return bem_cnodeGetDirect_0();
case -1480556491: return bem_toAny_0();
case -1281539621: return bem_qGetDirect_0();
case 148116149: return bem_inClassGetDirect_0();
case -724644380: return bem_maxDynArgsGet_0();
case -202912463: return bem_copy_0();
case 1207229505: return bem_classesInDepthOrderGetDirect_0();
case -1084736512: return bem_methodsGet_0();
case -583370841: return bem_callNamesGet_0();
case -791762572: return bem_classEndGet_0();
case -1745556142: return bem_classConfGet_0();
case -573617012: return bem_nullValueGet_0();
case 1455767471: return bem_lastCallGetDirect_0();
case -1083797513: return bem_boolNpGet_0();
case 1083177173: return bem_lastMethodsLinesGet_0();
case -2022569728: return bem_nlGet_0();
case -2121738617: return bem_methodCallsGet_0();
case 1244934604: return bem_instanceEqualGet_0();
case -1502076946: return bem_onceDecsGet_0();
case 1552756669: return bem_baseMtdDecGet_0();
case 1553553394: return bem_nativeCSlotsGet_0();
case 1384902570: return bem_idToNameGetDirect_0();
case 2096109526: return bem_ntypesGet_0();
case 1074159783: return bem_superCallsGet_0();
case -2085034567: return bem_cnodeGet_0();
case 1118253941: return bem_synEmitPathGetDirect_0();
case 1673755344: return bem_instanceNotEqualGetDirect_0();
case -1021789215: return bem_getLibOutput_0();
case -1403780653: return bem_getClassOutput_0();
case -884149543: return bem_constGet_0();
case 759496930: return bem_tagGet_0();
case 780853269: return bem_lastMethodsSizeGetDirect_0();
case -145426125: return bem_classEmitsGet_0();
case -1916572517: return bem_nameToIdGet_0();
case -26933688: return bem_libEmitPathGet_0();
case 1557789203: return bem_preClassGetDirect_0();
case -669121266: return bem_floatNpGetDirect_0();
case -257101022: return bem_shlibeGetDirect_0();
case 184557555: return bem_parentConfGetDirect_0();
case 1118167415: return bem_lastMethodBodySizeGet_0();
case -121822067: return bem_ccCacheGetDirect_0();
case 1914395957: return bem_classConfGetDirect_0();
case -1850305294: return bem_randGet_0();
case 1135685676: return bem_classEmitsGetDirect_0();
case 299428528: return bem_gcMarksGet_0();
case -1348022280: return bem_emitLangGetDirect_0();
case 930517921: return bem_initialDecGet_0();
case 2044684339: return bem_fullLibEmitNameGet_0();
case -2000107535: return bem_nlGetDirect_0();
case 1522126315: return bem_fullLibEmitNameGetDirect_0();
case -535260986: return bem_emitLib_0();
case 86637174: return bem_methodCatchGet_0();
case 417156839: return bem_intNpGet_0();
case -791878922: return bem_scvpGet_0();
case -670597238: return bem_preClassGet_0();
case -71162589: return bem_iteratorGet_0();
case -397234611: return bem_propertyDecsGet_0();
case -1511863590: return bem_dynMethodsGetDirect_0();
case -1680429352: return bem_synEmitPathGet_0();
case 1994066589: return bem_classCallsGetDirect_0();
case 2121785367: return bem_methodBodyGetDirect_0();
case 379851008: return bem_falseValueGet_0();
case 684911675: return bem_instOfGetDirect_0();
case -407184959: return bem_boolCcGetDirect_0();
case -1848489279: return bem_inClassGet_0();
case 2035274083: return bem_invpGet_0();
case 449441290: return bem_msynGetDirect_0();
case -1553363480: return bem_maxSpillArgsLenGet_0();
case -1409631717: return bem_writeBET_0();
case 1754419346: return bem_onceCountGet_0();
case -1874284015: return bem_lineCountGet_0();
case 2122551216: return bem_lastMethodsLinesGetDirect_0();
case 1724560718: return bem_boolNpGetDirect_0();
case 48497608: return bem_parentConfGet_0();
case -1457331945: return bem_loadIds_0();
case -442433432: return bem_preClassOutput_0();
case -2025941103: return bem_ccCacheGet_0();
case -508637315: return bem_nameToIdPathGet_0();
case -652053502: return bem_fieldNamesGet_0();
case 1029696314: return bem_lastMethodBodySizeGetDirect_0();
case -417851647: return bem_transGetDirect_0();
case -1359614197: return bem_classNameGet_0();
case 1161638424: return bem_new_0();
case 618689390: return bem_instanceEqualGetDirect_0();
case 2113444123: return bem_propDecGet_0();
case 92607309: return bem_inFilePathedGetDirect_0();
case 996189900: return bem_saveIds_0();
case -1526346803: return bem_csynGet_0();
case 1844578634: return bem_msynGet_0();
case 2097457448: return bem_inFilePathedGet_0();
case 350691792: return bem_toString_0();
case -1547802168: return bem_mainStartGet_0();
case 465279660: return bem_idToNamePathGet_0();
case 1520021170: return bem_trueValueGet_0();
case -1812832701: return bem_callNamesGetDirect_0();
case 1345437606: return bem_gcMarksGetDirect_0();
case 624323703: return bem_methodBodyGet_0();
case -2138012152: return bem_instOfGet_0();
case 2141485169: return bem_objectCcGetDirect_0();
case -1893075648: return bem_buildGetDirect_0();
case -1251441948: return bem_buildGet_0();
case -413738358: return bem_trueValueGetDirect_0();
case 1611781577: return bem_allOnceDecsGet_0();
case -2103258841: return bem_beginNs_0();
case 65183808: return bem_dynMethodsGet_0();
case 1973708427: return bem_floatNpGet_0();
case 1079800785: return bem_objectCcGet_0();
case 910715234: return bem_runtimeInitGet_0();
case -1167644102: return bem_baseSmtdDecGet_0();
case -1674913155: return bem_nameToIdGetDirect_0();
case -2113130299: return bem_ccMethodsGetDirect_0();
case -789597547: return bem_superCallsGetDirect_0();
case -810350553: return bem_idToNamePathGetDirect_0();
case 903237080: return bem_objectNpGet_0();
case 998798365: return bem_fileExtGet_0();
case 2064925791: return bem_echo_0();
case -1785724794: return bem_once_0();
case -1306837026: return bem_mnodeGetDirect_0();
case 1112318793: return bem_allOnceDecsGetDirect_0();
case 1398445729: return bem_buildPropList_0();
case 1131882165: return bem_stringNpGet_0();
case -1355234942: return bem_shlibeGet_0();
case 856468220: return bem_csynGetDirect_0();
case -900410756: return bem_mainInClassGet_0();
case -1541718074: return bem_libEmitNameGetDirect_0();
case -292507844: return bem_belslitsGet_0();
case 345735475: return bem_qGet_0();
case 2068488599: return bem_idToNameGet_0();
case -2001842300: return bem_endNs_0();
case 1852479453: return bem_intNpGetDirect_0();
case -1446124337: return bem_lastMethodBodyLinesGetDirect_0();
case 1609639145: return bem_mainOutsideNsGet_0();
case -1463900917: return bem_lastMethodBodyLinesGet_0();
case 944073339: return bem_fieldIteratorGet_0();
case -1642361296: return bem_print_0();
case 1803787653: return bem_transGet_0();
case -118795267: return bem_stringNpGetDirect_0();
case 1043004008: return bem_constGetDirect_0();
case 307537027: return bem_onceCountGetDirect_0();
case 2040783457: return bem_falseValueGetDirect_0();
case 158862606: return bem_methodCallsGetDirect_0();
case 814334258: return bem_serializeContents_0();
case 1890718307: return bem_boolCcGet_0();
case -333248212: return bem_belslitsGetDirect_0();
case -1238107083: return bem_saveSyns_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 1438151213: return bem_typeDecGet_0();
case -716082779: return bem_nameToIdPathGetDirect_0();
case -355141393: return bem_libEmitNameGet_0();
case -2051932784: return bem_smnlcsGetDirect_0();
case 238370772: return bem_invpGetDirect_0();
case -186340524: return bem_smnlecsGet_0();
case 310009257: return bem_buildCreate_0();
case 115447708: return bem_mnodeGet_0();
case 1615039904: return bem_onceDecsGetDirect_0();
case 770159800: return bem_doEmit_0();
case -913631679: return bem_classCallsGet_0();
case -243324316: return bem_boolTypeGet_0();
case -271580273: return bem_returnTypeGet_0();
case -985491388: return bem_superNameGet_0();
case 182250316: return bem_maxSpillArgsLenGetDirect_0();
case 908356424: return bem_lastCallGet_0();
case -668074844: return bem_objectNpGetDirect_0();
case -537571503: return bem_spropDecGet_0();
case -2106497134: return bem_smnlcsGet_0();
case -232883676: return bem_methodCatchGetDirect_0();
case -574342168: return bem_maxDynArgsGetDirect_0();
case -227015919: return bem_emitLangGet_0();
case 1944315889: return bem_methodsGetDirect_0();
case 168135582: return bem_create_0();
case -1574324548: return bem_newDecGet_0();
case -1955602809: return bem_nativeCSlotsGetDirect_0();
case -1452897433: return bem_randGetDirect_0();
case -1053161926: return bem_mainEndGet_0();
case 54660062: return bem_exceptDecGet_0();
case 424617382: return bem_ntypesGetDirect_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -987904845: return bem_classesInDepthOrderGet_0();
case -1449087211: return bem_lineCountGetDirect_0();
case -1345515562: return bem_ccMethodsGet_0();
case 644031513: return bem_afterCast_0();
case 2064842730: return bem_exceptDecGetDirect_0();
case 1810406102: return bem_buildInitial_0();
case -1902180333: return bem_buildClassInfo_0();
case -1711670377: return bem_hashGet_0();
case -257889507: return bem_fileExtGetDirect_0();
case -398470049: return bem_scvpGetDirect_0();
case 1731201269: return bem_covariantReturnsGet_0();
case 1365897346: return bem_serializationIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -942509639: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1300545026: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -468553068: return bem_lineCountSetDirect_1(bevd_0);
case 2035388431: return bem_propertyDecsSet_1(bevd_0);
case -1995709366: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -107506469: return bem_allOnceDecsSetDirect_1(bevd_0);
case -965959383: return bem_constSet_1(bevd_0);
case 1599799335: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1762592257: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1798508794: return bem_intNpSetDirect_1(bevd_0);
case 1347604650: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 985495776: return bem_methodsSet_1(bevd_0);
case -1308750752: return bem_invpSetDirect_1(bevd_0);
case -1651775990: return bem_parentConfSetDirect_1(bevd_0);
case -148722121: return bem_emitLangSet_1(bevd_0);
case 1708364945: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -794961138: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -437717091: return bem_nameToIdPathSetDirect_1(bevd_0);
case 685819836: return bem_scvpSet_1(bevd_0);
case -2026582719: return bem_nativeCSlotsSet_1(bevd_0);
case -2145690774: return bem_lineCountSet_1(bevd_0);
case 728294688: return bem_idToNamePathSetDirect_1(bevd_0);
case 401418856: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -535016700: return bem_msynSet_1(bevd_0);
case -759321851: return bem_maxDynArgsSetDirect_1(bevd_0);
case -118363359: return bem_smnlecsSetDirect_1(bevd_0);
case 134463509: return bem_randSetDirect_1(bevd_0);
case 374225239: return bem_mnodeSet_1(bevd_0);
case -143802123: return bem_floatNpSet_1(bevd_0);
case -876419384: return bem_inFilePathedSetDirect_1(bevd_0);
case -1167588101: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 2017376710: return bem_gcMarksSetDirect_1(bevd_0);
case -1820791805: return bem_cnodeSet_1(bevd_0);
case 1809097767: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case 1522061077: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 207383524: return bem_classConfSet_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case 232055575: return bem_dynMethodsSet_1(bevd_0);
case 1754590321: return bem_nullValueSet_1(bevd_0);
case 23284030: return bem_classConfSetDirect_1(bevd_0);
case 2131179758: return bem_csynSet_1(bevd_0);
case 1661450598: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 1376359833: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -1398532: return bem_methodCallsSetDirect_1(bevd_0);
case 896399183: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -1724160625: return bem_trueValueSet_1(bevd_0);
case 841250: return bem_methodCatchSetDirect_1(bevd_0);
case -736694543: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -1628548454: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -652985786: return bem_methodCallsSet_1(bevd_0);
case 1142023380: return bem_begin_1(bevd_0);
case 1620863326: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -428557532: return bem_trueValueSetDirect_1(bevd_0);
case 2123460831: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1922137344: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1324962247: return bem_msynSetDirect_1(bevd_0);
case 78613838: return bem_dynMethodsSetDirect_1(bevd_0);
case 1733059099: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -164810505: return bem_ntypesSet_1(bevd_0);
case -1910686666: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -209483765: return bem_maxDynArgsSet_1(bevd_0);
case 2070218928: return bem_fileExtSetDirect_1(bevd_0);
case -1121794565: return bem_propertyDecsSetDirect_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case -1928070778: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1475128332: return bem_cnodeSetDirect_1(bevd_0);
case -1689925539: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 508328505: return bem_objectCcSet_1(bevd_0);
case -44215448: return bem_nlSet_1(bevd_0);
case -1870684414: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 2118784085: return bem_classesInDepthOrderSet_1(bevd_0);
case -1281674834: return bem_qSet_1(bevd_0);
case 653494180: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -379737235: return bem_ccMethodsSet_1(bevd_0);
case -1570854552: return bem_idToNameSetDirect_1(bevd_0);
case -1086638712: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1123281920: return bem_libEmitPathSetDirect_1(bevd_0);
case -548044674: return bem_transSet_1(bevd_0);
case -1496549123: return bem_ccCacheSet_1(bevd_0);
case -1192460947: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -2089930948: return bem_libEmitNameSet_1(bevd_0);
case 1101150128: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1936852329: return bem_methodBodySet_1(bevd_0);
case -2097529949: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 176972922: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 376581421: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -550104624: return bem_parentConfSet_1(bevd_0);
case 2020000755: return bem_scvpSetDirect_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case -771013672: return bem_fullLibEmitNameSet_1(bevd_0);
case -138861127: return bem_shlibeSet_1(bevd_0);
case -504649414: return bem_instanceEqualSetDirect_1(bevd_0);
case 841670606: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 352753119: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -2019018650: return bem_inClassSetDirect_1(bevd_0);
case 2120995139: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -594882639: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -807287478: return bem_onceDecsSet_1(bevd_0);
case -1149733913: return bem_nameToIdSet_1(bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case -540713899: return bem_intNpSet_1(bevd_0);
case 412812313: return bem_libEmitNameSetDirect_1(bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case -2142191232: return bem_boolNpSet_1(bevd_0);
case 1272558500: return bem_shlibeSetDirect_1(bevd_0);
case -929173031: return bem_boolCcSet_1(bevd_0);
case -1088249597: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2031916912: return bem_objectNpSetDirect_1(bevd_0);
case -230338613: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -1055205804: return bem_buildSetDirect_1(bevd_0);
case -1326936799: return bem_allOnceDecsSet_1(bevd_0);
case -1001914489: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 586283359: return bem_nlSetDirect_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -1829001662: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 385902084: return bem_classCallsSet_1(bevd_0);
case 1287399469: return bem_falseValueSet_1(bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case 159281589: return bem_smnlecsSet_1(bevd_0);
case -1292486007: return bem_classCallsSetDirect_1(bevd_0);
case 1640249839: return bem_belslitsSetDirect_1(bevd_0);
case 1143573289: return bem_lastMethodsLinesSet_1(bevd_0);
case 195515323: return bem_stringNpSet_1(bevd_0);
case 1011749003: return bem_ccCacheSetDirect_1(bevd_0);
case -765034900: return bem_objectCcSetDirect_1(bevd_0);
case 266464762: return bem_lastCallSetDirect_1(bevd_0);
case 1567570112: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1758212580: return bem_methodBodySetDirect_1(bevd_0);
case -1709789150: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1037384817: return bem_emitLangSetDirect_1(bevd_0);
case 866524958: return bem_randSet_1(bevd_0);
case 1170810217: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -977258126: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1458431940: return bem_ntypesSetDirect_1(bevd_0);
case 74538456: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1245799315: return bem_lastCallSet_1(bevd_0);
case -2128299223: return bem_classEmitsSetDirect_1(bevd_0);
case -705936714: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1993593000: return bem_nameToIdSetDirect_1(bevd_0);
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1400374388: return bem_idToNamePathSet_1(bevd_0);
case 853873457: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 550428777: return bem_idToNameSet_1(bevd_0);
case -1779171489: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -134197268: return bem_boolCcSetDirect_1(bevd_0);
case 1592343938: return bem_maxSpillArgsLenSet_1(bevd_0);
case -686948605: return bem_smnlcsSet_1(bevd_0);
case -2124459817: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -602611726: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1175148714: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 1817828411: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 535896014: return bem_onceCountSetDirect_1(bevd_0);
case -1061601401: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1516572934: return bem_instanceEqualSet_1(bevd_0);
case 1305153404: return bem_callNamesSet_1(bevd_0);
case 1268199254: return bem_exceptDecSet_1(bevd_0);
case 45842417: return bem_superCallsSetDirect_1(bevd_0);
case 388528970: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1959613395: return bem_onceCountSet_1(bevd_0);
case -1674907511: return bem_instOfSet_1(bevd_0);
case -964388251: return bem_methodsSetDirect_1(bevd_0);
case -1024086984: return bem_csynSetDirect_1(bevd_0);
case -1139370913: return bem_methodCatchSet_1(bevd_0);
case -1616948450: return bem_callNamesSetDirect_1(bevd_0);
case -1027369216: return bem_preClassSet_1(bevd_0);
case 1698067797: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1795385765: return bem_preClassSetDirect_1(bevd_0);
case -305334572: return bem_ccMethodsSetDirect_1(bevd_0);
case -990686106: return bem_constSetDirect_1(bevd_0);
case -1569310266: return bem_onceDecsSetDirect_1(bevd_0);
case 465808993: return bem_mnodeSetDirect_1(bevd_0);
case 819746231: return bem_buildSet_1(bevd_0);
case -1573771788: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 2064459703: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1843313618: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -189850605: return bem_smnlcsSetDirect_1(bevd_0);
case 1905912786: return bem_gcMarksSet_1(bevd_0);
case -28631103: return bem_nullValueSetDirect_1(bevd_0);
case -1690629120: return bem_superCallsSet_1(bevd_0);
case -409244775: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -916199053: return bem_instOfSetDirect_1(bevd_0);
case -817954322: return bem_qSetDirect_1(bevd_0);
case 414442139: return bem_inFilePathedSet_1(bevd_0);
case -1232637166: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1479763865: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1956411547: return bem_synEmitPathSet_1(bevd_0);
case 1472793028: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1681413752: return bem_nameToIdPathSet_1(bevd_0);
case 959391357: return bem_belslitsSet_1(bevd_0);
case 1880603529: return bem_transSetDirect_1(bevd_0);
case 1623208395: return bem_end_1(bevd_0);
case 587143410: return bem_instanceNotEqualSet_1(bevd_0);
case -941995094: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 821264433: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 68519762: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 606384128: return bem_invpSet_1(bevd_0);
case -1075620657: return bem_classEmitsSet_1(bevd_0);
case -1546923200: return bem_falseValueSetDirect_1(bevd_0);
case 895382208: return bem_lastMethodsSizeSet_1(bevd_0);
case -601916564: return bem_libEmitPathSet_1(bevd_0);
case -320483663: return bem_floatNpSetDirect_1(bevd_0);
case -429261676: return bem_returnTypeSet_1(bevd_0);
case 230669263: return bem_fileExtSet_1(bevd_0);
case 1998631065: return bem_inClassSet_1(bevd_0);
case 456498521: return bem_exceptDecSetDirect_1(bevd_0);
case -34506187: return bem_stringNpSetDirect_1(bevd_0);
case 1578929538: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -565193420: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case 327451583: return bem_synEmitPathSetDirect_1(bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1940884566: return bem_returnTypeSetDirect_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case -1738548092: return bem_boolNpSetDirect_1(bevd_0);
case 181143714: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -1175291236: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1015956070: return bem_objectNpSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -943930853: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1966786166: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -987107618: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1845268376: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 83679378: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 642876482: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -911645690: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1624759692: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 905365146: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1471905794: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1937887980: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 554405505: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -26108433: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 1074511525: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1678372869: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1739269490: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1783207041: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1647654990: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 295712092: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1623806776: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -1344631881: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
}
