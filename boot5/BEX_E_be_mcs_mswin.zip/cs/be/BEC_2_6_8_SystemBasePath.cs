namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemBasePath : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
static BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_4 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static new BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) {
bevp_path = beva_spath;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_tmpany_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_firstStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lastStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_8_SystemBasePath bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_other.bemd_0(1451040144);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1911701664, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 385 */ {
bevt_4_tmpany_phold = (BEC_2_6_8_SystemBasePath) bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_tmpany_phold;
} /* Line: 386 */
bevt_5_tmpany_phold = beva_other.bemd_0(-1281347935);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 388 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(-181500453);
return (BEC_2_6_8_SystemBasePath) bevt_6_tmpany_phold;
} /* Line: 389 */
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpany_phold = beva_other.bemd_0(1451040144);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_tmpany_phold.bemd_1(-752198592, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 393 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 393 */ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 395 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
bevt_9_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_tmpany_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_2_6_8_SystemBasePath) bem_copy_0();
bevl_rpath = (BEC_2_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_parentGet_0() {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_2_6_8_SystemBasePath) bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 411 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 411 */ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 412 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_tmpany_phold);
} /* Line: 413 */
 else  /* Line: 414 */ {
bevl_i.bem_nextGet_0();
} /* Line: 415 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 417 */
 else  /* Line: 411 */ {
break;
} /* Line: 411 */
} /* Line: 411 */
bevt_4_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 420 */
return bevl_rpath;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (bevp_path == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 426 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 426 */ {
bevt_4_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_sizeGet_0();
bevt_5_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 426 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 426 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 426 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 426 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 426 */
bevt_9_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_1;
bevt_8_tmpany_phold = bevp_path.bem_getPoint_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 427 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 428 */
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 434 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_2;
bevt_2_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 435 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 440 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 441 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_3;
if (beva_howMany.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 446 */ {
bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 451 */ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 451 */ {
if (bevl_next == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 452 */ {
break;
} /* Line: 452 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 451 */
 else  /* Line: 451 */ {
break;
} /* Line: 451 */
} /* Line: 451 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 457 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 469 */ {
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_tmpany_phold.bem_emptyGet_0();
} /* Line: 470 */
 else  /* Line: 471 */ {
bevt_3_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_4;
bevt_2_tmpany_phold = bevl_fp.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
} /* Line: 472 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 478 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 478 */ {
bevt_1_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_tmpany_phold);
} /* Line: 479 */
 else  /* Line: 478 */ {
break;
} /* Line: 478 */
} /* Line: 478 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_8_SystemBasePath) bem_addStep_1(beva_step);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 518 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_3_tmpany_phold = beva_x.bemd_1(2069326800, this);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 518 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 518 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 518 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_5_tmpany_phold = beva_x.bemd_0(1451040144);
bevt_4_tmpany_phold = bevp_path.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 518 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 518 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 518 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 519 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_subPath_2(beva_start, null);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 530 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 531 */
 else  /* Line: 532 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 533 */
bevl_res = bem_create_0();
bevl_res.bemd_1(171143353, bevp_separator);
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(-205487005, bevt_1_tmpany_phold);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGetDirect_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {346, 346, 350, 351, 355, 359, 363, 363, 367, 368, 368, 369, 373, 373, 377, 377, 377, 381, 381, 381, 385, 385, 385, 385, 386, 386, 388, 389, 389, 391, 392, 392, 393, 393, 394, 395, 397, 397, 398, 399, 401, 405, 406, 407, 407, 408, 409, 410, 411, 411, 412, 412, 413, 413, 415, 417, 419, 420, 422, 426, 426, 0, 426, 426, 426, 426, 426, 0, 0, 426, 426, 427, 427, 427, 428, 428, 430, 430, 434, 435, 435, 435, 440, 440, 440, 441, 446, 446, 446, 447, 448, 450, 451, 451, 451, 452, 452, 453, 454, 455, 451, 457, 462, 463, 464, 468, 469, 469, 470, 470, 472, 472, 472, 472, 477, 478, 478, 479, 479, 481, 485, 485, 489, 490, 491, 492, 496, 497, 498, 498, 499, 503, 503, 507, 507, 511, 511, 511, 518, 518, 0, 518, 0, 0, 0, 518, 518, 0, 0, 519, 519, 521, 521, 525, 525, 529, 530, 530, 531, 533, 535, 536, 537, 537, 537, 538, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 32, 33, 37, 41, 45, 46, 52, 53, 54, 55, 59, 60, 65, 66, 67, 72, 73, 74, 93, 94, 95, 96, 98, 99, 101, 103, 104, 106, 107, 108, 109, 112, 114, 115, 121, 122, 123, 124, 125, 138, 139, 140, 141, 142, 143, 144, 145, 148, 150, 155, 156, 157, 160, 162, 168, 170, 172, 187, 192, 193, 196, 197, 198, 199, 204, 205, 208, 212, 213, 215, 216, 217, 219, 220, 222, 223, 229, 231, 232, 233, 240, 241, 246, 247, 260, 261, 266, 267, 268, 269, 270, 273, 278, 279, 284, 287, 288, 289, 290, 296, 302, 303, 304, 314, 315, 320, 321, 322, 325, 326, 327, 328, 337, 338, 341, 343, 344, 350, 355, 356, 360, 361, 362, 363, 369, 370, 371, 372, 373, 377, 378, 382, 383, 388, 389, 394, 405, 410, 411, 414, 416, 419, 423, 426, 427, 429, 432, 436, 437, 439, 440, 444, 445, 454, 455, 460, 461, 464, 466, 467, 468, 469, 470, 471, 474, 477, 480, 484, 488, 491, 494, 498};
/* BEGIN LINEINFO 
assign 1 346 27
new 0 346 27
new 1 346 28
assign 1 350 32
new 0 350 32
fromString 1 351 33
assign 1 355 37
return 1 359 41
assign 1 363 45
toStringWithSeparator 1 363 45
return 1 363 46
assign 1 367 52
split 1 367 52
assign 1 368 53
new 0 368 53
assign 1 368 54
join 2 368 54
return 1 369 55
assign 1 373 59
split 1 373 59
return 1 373 60
assign 1 377 65
split 1 377 65
assign 1 377 66
firstGet 0 377 66
return 1 377 67
assign 1 381 72
split 1 381 72
assign 1 381 73
lastGet 0 381 73
return 1 381 74
assign 1 385 93
pathGet 0 385 93
assign 1 385 94
new 0 385 94
assign 1 385 95
emptyGet 0 385 95
assign 1 385 96
equals 1 385 96
assign 1 386 98
copy 0 386 98
return 1 386 99
assign 1 388 101
isAbsoluteGet 0 388 101
assign 1 389 103
copy 0 389 103
return 1 389 104
assign 1 391 106
split 1 391 106
assign 1 392 107
pathGet 0 392 107
assign 1 392 108
split 1 392 108
assign 1 393 109
linkedListIteratorGet 0 393 109
assign 1 393 112
hasNextGet 0 393 112
assign 1 394 114
nextGet 0 394 114
addValue 1 395 115
assign 1 397 121
new 0 397 121
assign 1 397 122
join 2 397 122
assign 1 398 123
copy 0 398 123
assign 1 399 124
fromString 1 399 124
return 1 401 125
assign 1 405 138
split 1 405 138
assign 1 406 139
copy 0 406 139
assign 1 407 140
new 0 407 140
pathSet 1 407 141
assign 1 408 142
lengthGet 0 408 142
assign 1 409 143
decrement 0 409 143
assign 1 410 144
new 0 410 144
assign 1 411 145
linkedListIteratorGet 0 411 145
assign 1 411 148
hasNextGet 0 411 148
assign 1 412 150
lesser 1 412 155
assign 1 413 156
nextGet 0 413 156
addStep 1 413 157
nextGet 0 415 160
assign 1 417 162
increment 0 417 162
assign 1 419 168
isAbsoluteGet 0 419 168
makeAbsolute 0 420 170
return 1 422 172
assign 1 426 187
undef 1 426 192
assign 1 0 193
assign 1 426 196
toString 0 426 196
assign 1 426 197
sizeGet 0 426 197
assign 1 426 198
new 0 426 198
assign 1 426 199
lesser 1 426 204
assign 1 0 205
assign 1 0 208
assign 1 426 212
new 0 426 212
return 1 426 213
assign 1 427 215
new 0 427 215
assign 1 427 216
getPoint 1 427 216
assign 1 427 217
equals 1 427 217
assign 1 428 219
new 0 428 219
return 1 428 220
assign 1 430 222
new 0 430 222
return 1 430 223
assign 1 434 229
isAbsoluteGet 0 434 229
assign 1 435 231
new 0 435 231
assign 1 435 232
sizeGet 0 435 232
assign 1 435 233
substring 2 435 233
assign 1 440 240
isAbsoluteGet 0 440 240
assign 1 440 241
not 0 440 246
assign 1 441 247
add 1 441 247
assign 1 446 260
new 0 446 260
assign 1 446 261
greater 1 446 266
makeNonAbsolute 0 447 267
assign 1 448 268
split 1 448 268
assign 1 450 269
firstNodeGet 0 450 269
assign 1 451 270
new 0 451 270
assign 1 451 273
lesser 1 451 278
assign 1 452 279
undef 1 452 284
assign 1 453 287
assign 1 454 288
nextGet 0 454 288
delete 0 455 289
assign 1 451 290
increment 0 451 290
assign 1 457 296
join 2 457 296
assign 1 462 302
split 1 462 302
addValue 1 463 303
assign 1 464 304
join 2 464 304
assign 1 468 314
find 1 468 314
assign 1 469 315
undef 1 469 320
assign 1 470 321
new 0 470 321
assign 1 470 322
emptyGet 0 470 322
assign 1 472 325
new 0 472 325
assign 1 472 326
add 1 472 326
assign 1 472 327
sizeGet 0 472 327
assign 1 472 328
substring 2 472 328
assign 1 477 337
split 1 477 337
assign 1 478 338
linkedListIteratorGet 0 478 338
assign 1 478 341
hasNextGet 0 478 341
assign 1 479 343
nextGet 0 479 343
addValue 1 479 344
assign 1 481 350
join 2 481 350
assign 1 485 355
addStep 1 485 355
return 1 485 356
assign 1 489 360
split 1 489 360
addValue 1 490 361
addValue 1 491 362
assign 1 492 363
join 2 492 363
assign 1 496 369
create 0 496 369
copyTo 1 497 370
assign 1 498 371
copy 0 498 371
pathSet 1 498 372
return 1 499 373
assign 1 503 377
split 1 503 377
return 1 503 378
assign 1 507 382
hashGet 0 507 382
return 1 507 383
assign 1 511 388
equals 1 511 388
assign 1 511 389
not 0 511 394
return 1 511 394
assign 1 518 405
undef 1 518 410
assign 1 0 411
assign 1 518 414
otherType 1 518 414
assign 1 0 416
assign 1 0 419
assign 1 0 423
assign 1 518 426
pathGet 0 518 426
assign 1 518 427
notEquals 1 518 427
assign 1 0 429
assign 1 0 432
assign 1 519 436
new 0 519 436
return 1 519 437
assign 1 521 439
new 0 521 439
return 1 521 440
assign 1 525 444
subPath 2 525 444
return 1 525 445
assign 1 529 454
stepsGet 0 529 454
assign 1 530 455
undef 1 530 460
assign 1 531 461
subList 1 531 461
assign 1 533 464
subList 2 533 464
assign 1 535 466
create 0 535 466
separatorSet 1 536 467
assign 1 537 468
new 0 537 468
assign 1 537 469
join 2 537 469
pathSet 1 537 470
return 1 538 471
return 1 0 474
return 1 0 477
assign 1 0 480
assign 1 0 484
return 1 0 488
return 1 0 491
assign 1 0 494
assign 1 0 498
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 952056940: return bem_toString_0();
case -1281347935: return bem_isAbsoluteGet_0();
case -1231026821: return bem_makeNonAbsolute_0();
case -181500453: return bem_copy_0();
case -664467345: return bem_create_0();
case 1782620959: return bem_echo_0();
case 1452357926: return bem_parentGet_0();
case -1714811768: return bem_fieldIteratorGet_0();
case -655092564: return bem_serializationIteratorGet_0();
case -1665576026: return bem_sourceFileNameGet_0();
case -157733273: return bem_many_0();
case 1020856154: return bem_stepsGet_0();
case 621622170: return bem_makeAbsolute_0();
case -1830560348: return bem_fieldNamesGet_0();
case 2070597988: return bem_lastStepGet_0();
case -1054400757: return bem_deserializeClassNameGet_0();
case 144506434: return bem_new_0();
case 2005192015: return bem_serializeToString_0();
case 1772872842: return bem_stepListGet_0();
case -1434960598: return bem_serializeContents_0();
case 199885080: return bem_separatorGet_0();
case -1427827058: return bem_once_0();
case 1794518227: return bem_iteratorGet_0();
case 2132306504: return bem_classNameGet_0();
case -377355642: return bem_hashGet_0();
case 1667331006: return bem_toAny_0();
case -2093201661: return bem_deleteFirstStep_0();
case -1406299037: return bem_separatorGetDirect_0();
case 455481848: return bem_print_0();
case 1451040144: return bem_pathGet_0();
case 1037266896: return bem_pathGetDirect_0();
case 1518292847: return bem_firstStepGet_0();
case -1313867098: return bem_tagGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1904819543: return bem_addSteps_1(bevd_0);
case -585494508: return bem_copyTo_1(bevd_0);
case 965114033: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -205487005: return bem_pathSet_1(bevd_0);
case -170944056: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -2123337515: return bem_undef_1(bevd_0);
case 2033542946: return bem_separatorSetDirect_1(bevd_0);
case 1046739569: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1198427025: return bem_notEquals_1(bevd_0);
case 1272963269: return bem_sameObject_1(bevd_0);
case 2069326800: return bem_otherType_1(bevd_0);
case -1859616581: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 1003716077: return bem_def_1(bevd_0);
case 1135973654: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1911701664: return bem_equals_1(bevd_0);
case -184186231: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 996563628: return bem_addStep_1(bevd_0);
case -459360005: return bem_otherClass_1(bevd_0);
case 241299765: return bem_sameType_1(bevd_0);
case 1532532742: return bem_undefined_1(bevd_0);
case -26559400: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -791334202: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1432196319: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -98791052: return bem_defined_1(bevd_0);
case 1147998319: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 2102889872: return bem_sameClass_1(bevd_0);
case 1377625485: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -386644007: return bem_pathSetDirect_1(bevd_0);
case 171143353: return bem_separatorSet_1(bevd_0);
case 2043797984: return bem_add_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1234965347: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -720811311: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 674286989: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1973929830: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1151727219: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -389946827: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2041425680: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1411035525: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 411091261: return bem_addSteps_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemBasePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
}
