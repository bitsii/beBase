namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemBasePath : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
static BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_4 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static new BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) {
bevp_path = beva_spath;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_tmpany_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_firstStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lastStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_8_SystemBasePath bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_other.bemd_0(-428272764);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-373658986, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 370 */ {
bevt_4_tmpany_phold = (BEC_2_6_8_SystemBasePath) bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_tmpany_phold;
} /* Line: 371 */
bevt_5_tmpany_phold = beva_other.bemd_0(846843714);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 373 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(1512772474);
return (BEC_2_6_8_SystemBasePath) bevt_6_tmpany_phold;
} /* Line: 374 */
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpany_phold = beva_other.bemd_0(-428272764);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_tmpany_phold.bemd_1(-476395019, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 378 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 378 */ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 380 */
 else  /* Line: 378 */ {
break;
} /* Line: 378 */
} /* Line: 378 */
bevt_9_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_tmpany_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_2_6_8_SystemBasePath) bem_copy_0();
bevl_rpath = (BEC_2_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_parentGet_0() {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_2_6_8_SystemBasePath) bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 396 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 396 */ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 397 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_tmpany_phold);
} /* Line: 398 */
 else  /* Line: 399 */ {
bevl_i.bem_nextGet_0();
} /* Line: 400 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 402 */
 else  /* Line: 396 */ {
break;
} /* Line: 396 */
} /* Line: 396 */
bevt_4_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 405 */
return bevl_rpath;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (bevp_path == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 411 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 411 */ {
bevt_4_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_sizeGet_0();
bevt_5_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 411 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 411 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 411 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 411 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 411 */
bevt_9_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_1;
bevt_8_tmpany_phold = bevp_path.bem_getPoint_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 412 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 413 */
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_2;
bevt_2_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 420 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 425 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 426 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_3;
if (beva_howMany.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 431 */ {
bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 436 */ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 436 */ {
if (bevl_next == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 437 */ {
break;
} /* Line: 437 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 436 */
 else  /* Line: 436 */ {
break;
} /* Line: 436 */
} /* Line: 436 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 442 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 454 */ {
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_tmpany_phold.bem_emptyGet_0();
} /* Line: 455 */
 else  /* Line: 456 */ {
bevt_3_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_4;
bevt_2_tmpany_phold = bevl_fp.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
} /* Line: 457 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 463 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 463 */ {
bevt_1_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_tmpany_phold);
} /* Line: 464 */
 else  /* Line: 463 */ {
break;
} /* Line: 463 */
} /* Line: 463 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_8_SystemBasePath) bem_addStep_1(beva_step);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 503 */ {
bevt_3_tmpany_phold = beva_x.bemd_1(-653588721, this);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 503 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 503 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 503 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 503 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 503 */ {
bevt_5_tmpany_phold = beva_x.bemd_0(-428272764);
bevt_4_tmpany_phold = bevp_path.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 503 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 503 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 503 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 504 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_subPath_2(beva_start, null);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 515 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 516 */
 else  /* Line: 517 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 518 */
bevl_res = bem_create_0();
bevl_res.bemd_1(1367940486, bevp_separator);
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(-1133064206, bevt_1_tmpany_phold);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGetDirect_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {331, 331, 335, 336, 340, 344, 348, 348, 352, 353, 353, 354, 358, 358, 362, 362, 362, 366, 366, 366, 370, 370, 370, 370, 371, 371, 373, 374, 374, 376, 377, 377, 378, 378, 379, 380, 382, 382, 383, 384, 386, 390, 391, 392, 392, 393, 394, 395, 396, 396, 397, 397, 398, 398, 400, 402, 404, 405, 407, 411, 411, 0, 411, 411, 411, 411, 411, 0, 0, 411, 411, 412, 412, 412, 413, 413, 415, 415, 419, 420, 420, 420, 425, 425, 425, 426, 431, 431, 431, 432, 433, 435, 436, 436, 436, 437, 437, 438, 439, 440, 436, 442, 447, 448, 449, 453, 454, 454, 455, 455, 457, 457, 457, 457, 462, 463, 463, 464, 464, 466, 470, 470, 474, 475, 476, 477, 481, 482, 483, 483, 484, 488, 488, 492, 492, 496, 496, 496, 503, 503, 0, 503, 0, 0, 0, 503, 503, 0, 0, 504, 504, 506, 506, 510, 510, 514, 515, 515, 516, 518, 520, 521, 522, 522, 522, 523, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 32, 33, 37, 41, 45, 46, 52, 53, 54, 55, 59, 60, 65, 66, 67, 72, 73, 74, 93, 94, 95, 96, 98, 99, 101, 103, 104, 106, 107, 108, 109, 112, 114, 115, 121, 122, 123, 124, 125, 138, 139, 140, 141, 142, 143, 144, 145, 148, 150, 155, 156, 157, 160, 162, 168, 170, 172, 187, 192, 193, 196, 197, 198, 199, 204, 205, 208, 212, 213, 215, 216, 217, 219, 220, 222, 223, 229, 231, 232, 233, 240, 241, 246, 247, 260, 261, 266, 267, 268, 269, 270, 273, 278, 279, 284, 287, 288, 289, 290, 296, 302, 303, 304, 314, 315, 320, 321, 322, 325, 326, 327, 328, 337, 338, 341, 343, 344, 350, 355, 356, 360, 361, 362, 363, 369, 370, 371, 372, 373, 377, 378, 382, 383, 388, 389, 394, 405, 410, 411, 414, 416, 419, 423, 426, 427, 429, 432, 436, 437, 439, 440, 444, 445, 454, 455, 460, 461, 464, 466, 467, 468, 469, 470, 471, 474, 477, 480, 484, 488, 491, 494, 498};
/* BEGIN LINEINFO 
assign 1 331 27
new 0 331 27
new 1 331 28
assign 1 335 32
new 0 335 32
fromString 1 336 33
assign 1 340 37
return 1 344 41
assign 1 348 45
toStringWithSeparator 1 348 45
return 1 348 46
assign 1 352 52
split 1 352 52
assign 1 353 53
new 0 353 53
assign 1 353 54
join 2 353 54
return 1 354 55
assign 1 358 59
split 1 358 59
return 1 358 60
assign 1 362 65
split 1 362 65
assign 1 362 66
firstGet 0 362 66
return 1 362 67
assign 1 366 72
split 1 366 72
assign 1 366 73
lastGet 0 366 73
return 1 366 74
assign 1 370 93
pathGet 0 370 93
assign 1 370 94
new 0 370 94
assign 1 370 95
emptyGet 0 370 95
assign 1 370 96
equals 1 370 96
assign 1 371 98
copy 0 371 98
return 1 371 99
assign 1 373 101
isAbsoluteGet 0 373 101
assign 1 374 103
copy 0 374 103
return 1 374 104
assign 1 376 106
split 1 376 106
assign 1 377 107
pathGet 0 377 107
assign 1 377 108
split 1 377 108
assign 1 378 109
linkedListIteratorGet 0 378 109
assign 1 378 112
hasNextGet 0 378 112
assign 1 379 114
nextGet 0 379 114
addValue 1 380 115
assign 1 382 121
new 0 382 121
assign 1 382 122
join 2 382 122
assign 1 383 123
copy 0 383 123
assign 1 384 124
fromString 1 384 124
return 1 386 125
assign 1 390 138
split 1 390 138
assign 1 391 139
copy 0 391 139
assign 1 392 140
new 0 392 140
pathSet 1 392 141
assign 1 393 142
lengthGet 0 393 142
assign 1 394 143
decrement 0 394 143
assign 1 395 144
new 0 395 144
assign 1 396 145
linkedListIteratorGet 0 396 145
assign 1 396 148
hasNextGet 0 396 148
assign 1 397 150
lesser 1 397 155
assign 1 398 156
nextGet 0 398 156
addStep 1 398 157
nextGet 0 400 160
assign 1 402 162
increment 0 402 162
assign 1 404 168
isAbsoluteGet 0 404 168
makeAbsolute 0 405 170
return 1 407 172
assign 1 411 187
undef 1 411 192
assign 1 0 193
assign 1 411 196
toString 0 411 196
assign 1 411 197
sizeGet 0 411 197
assign 1 411 198
new 0 411 198
assign 1 411 199
lesser 1 411 204
assign 1 0 205
assign 1 0 208
assign 1 411 212
new 0 411 212
return 1 411 213
assign 1 412 215
new 0 412 215
assign 1 412 216
getPoint 1 412 216
assign 1 412 217
equals 1 412 217
assign 1 413 219
new 0 413 219
return 1 413 220
assign 1 415 222
new 0 415 222
return 1 415 223
assign 1 419 229
isAbsoluteGet 0 419 229
assign 1 420 231
new 0 420 231
assign 1 420 232
sizeGet 0 420 232
assign 1 420 233
substring 2 420 233
assign 1 425 240
isAbsoluteGet 0 425 240
assign 1 425 241
not 0 425 246
assign 1 426 247
add 1 426 247
assign 1 431 260
new 0 431 260
assign 1 431 261
greater 1 431 266
makeNonAbsolute 0 432 267
assign 1 433 268
split 1 433 268
assign 1 435 269
firstNodeGet 0 435 269
assign 1 436 270
new 0 436 270
assign 1 436 273
lesser 1 436 278
assign 1 437 279
undef 1 437 284
assign 1 438 287
assign 1 439 288
nextGet 0 439 288
delete 0 440 289
assign 1 436 290
increment 0 436 290
assign 1 442 296
join 2 442 296
assign 1 447 302
split 1 447 302
addValue 1 448 303
assign 1 449 304
join 2 449 304
assign 1 453 314
find 1 453 314
assign 1 454 315
undef 1 454 320
assign 1 455 321
new 0 455 321
assign 1 455 322
emptyGet 0 455 322
assign 1 457 325
new 0 457 325
assign 1 457 326
add 1 457 326
assign 1 457 327
sizeGet 0 457 327
assign 1 457 328
substring 2 457 328
assign 1 462 337
split 1 462 337
assign 1 463 338
linkedListIteratorGet 0 463 338
assign 1 463 341
hasNextGet 0 463 341
assign 1 464 343
nextGet 0 464 343
addValue 1 464 344
assign 1 466 350
join 2 466 350
assign 1 470 355
addStep 1 470 355
return 1 470 356
assign 1 474 360
split 1 474 360
addValue 1 475 361
addValue 1 476 362
assign 1 477 363
join 2 477 363
assign 1 481 369
create 0 481 369
copyTo 1 482 370
assign 1 483 371
copy 0 483 371
pathSet 1 483 372
return 1 484 373
assign 1 488 377
split 1 488 377
return 1 488 378
assign 1 492 382
hashGet 0 492 382
return 1 492 383
assign 1 496 388
equals 1 496 388
assign 1 496 389
not 0 496 394
return 1 496 394
assign 1 503 405
undef 1 503 410
assign 1 0 411
assign 1 503 414
otherType 1 503 414
assign 1 0 416
assign 1 0 419
assign 1 0 423
assign 1 503 426
pathGet 0 503 426
assign 1 503 427
notEquals 1 503 427
assign 1 0 429
assign 1 0 432
assign 1 504 436
new 0 504 436
return 1 504 437
assign 1 506 439
new 0 506 439
return 1 506 440
assign 1 510 444
subPath 2 510 444
return 1 510 445
assign 1 514 454
stepsGet 0 514 454
assign 1 515 455
undef 1 515 460
assign 1 516 461
subList 1 516 461
assign 1 518 464
subList 2 518 464
assign 1 520 466
create 0 520 466
separatorSet 1 521 467
assign 1 522 468
new 0 522 468
assign 1 522 469
join 2 522 469
pathSet 1 522 470
return 1 523 471
return 1 0 474
return 1 0 477
assign 1 0 480
assign 1 0 484
return 1 0 488
return 1 0 491
assign 1 0 494
assign 1 0 498
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1431960617: return bem_many_0();
case 1789707820: return bem_stepsGet_0();
case -1051263431: return bem_create_0();
case 1679305813: return bem_separatorGetDirect_0();
case -1154702923: return bem_pathGetDirect_0();
case 1375519361: return bem_sourceFileNameGet_0();
case 1156921009: return bem_toString_0();
case -2062705467: return bem_makeAbsolute_0();
case -461205434: return bem_iteratorGet_0();
case -1581666253: return bem_new_0();
case -539277844: return bem_fieldIteratorGet_0();
case 1947173801: return bem_print_0();
case -182215192: return bem_serializationIteratorGet_0();
case 464610233: return bem_once_0();
case 1969869774: return bem_echo_0();
case 874503493: return bem_serializeToString_0();
case 870240567: return bem_stepListGet_0();
case 1684156126: return bem_separatorGet_0();
case -1952583134: return bem_deleteFirstStep_0();
case -654415539: return bem_tagGet_0();
case 49134257: return bem_hashGet_0();
case -1747498826: return bem_classNameGet_0();
case -795290865: return bem_parentGet_0();
case 36467360: return bem_makeNonAbsolute_0();
case 941172865: return bem_serializeContents_0();
case 1205179000: return bem_deserializeClassNameGet_0();
case 846843714: return bem_isAbsoluteGet_0();
case 1512772474: return bem_copy_0();
case 586078873: return bem_lastStepGet_0();
case -428272764: return bem_pathGet_0();
case 1881939406: return bem_fieldNamesGet_0();
case 235346174: return bem_firstStepGet_0();
case 322540171: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -653588721: return bem_otherType_1(bevd_0);
case -1446211133: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 778331504: return bem_def_1(bevd_0);
case -1295446558: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1940703752: return bem_copyTo_1(bevd_0);
case 1779380050: return bem_undefined_1(bevd_0);
case 1935362065: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 1367940486: return bem_separatorSet_1(bevd_0);
case 1521330956: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -1133064206: return bem_pathSet_1(bevd_0);
case -1405212164: return bem_sameClass_1(bevd_0);
case 811439182: return bem_addStep_1(bevd_0);
case 1817351105: return bem_defined_1(bevd_0);
case 2125870571: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 447923928: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1499911921: return bem_notEquals_1(bevd_0);
case -373658986: return bem_equals_1(bevd_0);
case 1071454001: return bem_pathSetDirect_1(bevd_0);
case 1052016368: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -1264044693: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2016123429: return bem_add_1(bevd_0);
case 372746140: return bem_sameType_1(bevd_0);
case 243162876: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1089354598: return bem_undef_1(bevd_0);
case -498298486: return bem_sameObject_1(bevd_0);
case 1966156517: return bem_otherClass_1(bevd_0);
case -601018483: return bem_separatorSetDirect_1(bevd_0);
case -1970828720: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -2062359963: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -86718477: return bem_addSteps_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 414389553: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1714613573: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -292360250: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1129259785: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 614290015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 888716978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 193506539: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1747196698: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 784102244: return bem_addSteps_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemBasePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
}
