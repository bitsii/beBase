namespace be {
/* IO:File: source/build/Errors.be */
public class BEC_2_5_10_BuildVisitError : BEC_2_6_9_SystemException {
public BEC_2_5_10_BuildVisitError() { }
static BEC_2_5_10_BuildVisitError() { }
private static byte[] becc_BEC_2_5_10_BuildVisitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_10_BuildVisitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_10_BuildVisitError_bels_0 = {};
public static new BEC_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_inst;

public static new BET_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_type;

public BEC_2_6_6_SystemObject bevp_msg;
public BEC_2_6_6_SystemObject bevp_node;
public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_msgi) {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_new_2(BEC_2_6_6_SystemObject beva_msgi, BEC_2_6_6_SystemObject beva_nodei) {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_10_BuildVisitError_bels_0));
if (bevp_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 25 */ {
bevt_1_tmpany_phold = bevl_toRet.bemd_1(-1286410426, bevp_msg);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_newlineGet_0();
bevl_toRet = bevt_1_tmpany_phold.bemd_1(-1286410426, bevt_2_tmpany_phold);
} /* Line: 26 */
if (bevp_node == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 28 */ {
bevl_nc = bevp_node;
while (true)
 /* Line: 30 */ {
if (bevl_nc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevl_toRet.bemd_1(1880329535, bevl_nc);
bevt_7_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_newlineGet_0();
bevl_toRet.bemd_1(1880329535, bevt_6_tmpany_phold);
bevl_nc = bevl_nc.bemd_0(-413117042);
} /* Line: 33 */
 else  /* Line: 30 */ {
break;
} /* Line: 30 */
} /* Line: 30 */
} /* Line: 30 */
bevt_8_tmpany_phold = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(-1286410426, bevt_8_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_msgGet_0() {
return bevp_msg;
} /*method end*/
public BEC_2_6_6_SystemObject bem_msgGetDirect_0() {
return bevp_msg;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_msgSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_msg = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_msgSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_msg = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nodeGet_0() {
return bevp_node;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodeGetDirect_0() {
return bevp_node;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_nodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_node = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_nodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_node = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {11, 16, 17, 24, 25, 25, 26, 26, 26, 26, 28, 28, 29, 30, 30, 31, 32, 32, 32, 33, 36, 36, 37, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 20, 21, 36, 37, 42, 43, 44, 45, 46, 48, 53, 54, 57, 62, 63, 64, 65, 66, 67, 74, 75, 76, 79, 82, 85, 89, 93, 96, 99, 103};
/* BEGIN LINEINFO 
assign 1 11 16
assign 1 16 20
assign 1 17 21
assign 1 24 36
new 0 24 36
assign 1 25 37
def 1 25 42
assign 1 26 43
add 1 26 43
assign 1 26 44
new 0 26 44
assign 1 26 45
newlineGet 0 26 45
assign 1 26 46
add 1 26 46
assign 1 28 48
def 1 28 53
assign 1 29 54
assign 1 30 57
def 1 30 62
addValue 1 31 63
assign 1 32 64
new 0 32 64
assign 1 32 65
newlineGet 0 32 65
addValue 1 32 66
assign 1 33 67
containerGet 0 33 67
assign 1 36 74
getFrameText 0 36 74
assign 1 36 75
add 1 36 75
return 1 37 76
return 1 0 79
return 1 0 82
assign 1 0 85
assign 1 0 89
return 1 0 93
return 1 0 96
assign 1 0 99
assign 1 0 103
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1949710140: return bem_klassNameGetDirect_0();
case -1272818175: return bem_klassNameGet_0();
case 402201008: return bem_new_0();
case -1854726950: return bem_echo_0();
case -918329325: return bem_langGet_0();
case 754185888: return bem_fileNameGet_0();
case -656937356: return bem_many_0();
case 682604587: return bem_serializeContents_0();
case -1975455714: return bem_copy_0();
case 475079748: return bem_translatedGetDirect_0();
case -1795002401: return bem_toString_0();
case -996694279: return bem_fileNameGetDirect_0();
case 616098757: return bem_msgGetDirect_0();
case 369363591: return bem_emitLangGetDirect_0();
case 1884780767: return bem_framesTextGet_0();
case 1498087551: return bem_descriptionGetDirect_0();
case -1028834382: return bem_translatedGet_0();
case 55812595: return bem_serializeToString_0();
case -51459444: return bem_lineNumberGet_0();
case -434919379: return bem_deserializeClassNameGet_0();
case 9957435: return bem_iteratorGet_0();
case 1860492410: return bem_fieldIteratorGet_0();
case -1433464313: return bem_vvGetDirect_0();
case -1781220768: return bem_lineNumberGetDirect_0();
case -368347729: return bem_fieldNamesGet_0();
case 1678261270: return bem_print_0();
case -388446640: return bem_getFrameText_0();
case -604312045: return bem_serializationIteratorGet_0();
case 1954200091: return bem_framesGetDirect_0();
case 1687413327: return bem_descriptionGet_0();
case -1810846836: return bem_methodNameGetDirect_0();
case 1434541716: return bem_nodeGetDirect_0();
case 808044123: return bem_hashGet_0();
case 966149554: return bem_create_0();
case -268004758: return bem_translateEmittedException_0();
case 748315678: return bem_tagGet_0();
case 1342765490: return bem_toAny_0();
case 1927362006: return bem_translateEmittedExceptionInner_0();
case 436073718: return bem_langGetDirect_0();
case -636994806: return bem_sourceFileNameGet_0();
case -772967023: return bem_classNameGet_0();
case -76146719: return bem_nodeGet_0();
case -56343146: return bem_framesTextGetDirect_0();
case 367195678: return bem_once_0();
case 627288027: return bem_emitLangGet_0();
case 1708406851: return bem_msgGet_0();
case -1856497736: return bem_vvGet_0();
case 1684488837: return bem_methodNameGet_0();
case 1493464514: return bem_framesGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 500041386: return bem_methodNameSet_1(bevd_0);
case 1510169426: return bem_msgSetDirect_1(bevd_0);
case 171615032: return bem_new_1(bevd_0);
case -1930481353: return bem_nodeSet_1(bevd_0);
case -1243919368: return bem_framesSet_1(bevd_0);
case 917919988: return bem_lineNumberSetDirect_1(bevd_0);
case 709767374: return bem_fileNameSet_1(bevd_0);
case 1444313604: return bem_translatedSetDirect_1(bevd_0);
case -2040551593: return bem_translatedSet_1(bevd_0);
case 267174377: return bem_def_1(bevd_0);
case -1029495045: return bem_methodNameSetDirect_1(bevd_0);
case 1272631429: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -714900612: return bem_copyTo_1(bevd_0);
case 2027802220: return bem_langSet_1(bevd_0);
case -1007540340: return bem_notEquals_1(bevd_0);
case -1407720437: return bem_emitLangSetDirect_1(bevd_0);
case 1621186357: return bem_sameType_1(bevd_0);
case 1647993291: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1317358248: return bem_framesSetDirect_1(bevd_0);
case -1194473609: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 345055136: return bem_vvSetDirect_1(bevd_0);
case 2006914640: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -173251555: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -248827851: return bem_framesTextSet_1(bevd_0);
case -1057647241: return bem_descriptionSetDirect_1(bevd_0);
case 411297199: return bem_descriptionSet_1(bevd_0);
case 195308005: return bem_sameObject_1(bevd_0);
case 52668276: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 543061021: return bem_otherClass_1(bevd_0);
case -1708940053: return bem_emitLangSet_1(bevd_0);
case -1173074205: return bem_klassNameSetDirect_1(bevd_0);
case 1448933357: return bem_otherType_1(bevd_0);
case 1581635145: return bem_framesTextSetDirect_1(bevd_0);
case -1859768800: return bem_nodeSetDirect_1(bevd_0);
case 28738628: return bem_lineNumberSet_1(bevd_0);
case 1614496109: return bem_undef_1(bevd_0);
case 1685672000: return bem_klassNameSet_1(bevd_0);
case 350775730: return bem_equals_1(bevd_0);
case -2144202949: return bem_sameClass_1(bevd_0);
case 831495119: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1163078007: return bem_undefined_1(bevd_0);
case -854410022: return bem_langSetDirect_1(bevd_0);
case 303580303: return bem_fileNameSetDirect_1(bevd_0);
case -700310720: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -686908994: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -991365338: return bem_defined_1(bevd_0);
case -864826627: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1101377850: return bem_vvSet_1(bevd_0);
case -1332276682: return bem_msgSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 325307565: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2027276174: return bem_new_2(bevd_0, bevd_1);
case -1385197575: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1280867989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1833007700: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1584099228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -187061774: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -961973758: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -2073882612: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_5_10_BuildVisitError_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_5_10_BuildVisitError_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_10_BuildVisitError();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst = (BEC_2_5_10_BuildVisitError) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_type;
}
}
}
