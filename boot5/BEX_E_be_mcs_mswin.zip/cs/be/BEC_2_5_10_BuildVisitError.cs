namespace be {
/* IO:File: source/build/Errors.be */
public class BEC_2_5_10_BuildVisitError : BEC_2_6_9_SystemException {
public BEC_2_5_10_BuildVisitError() { }
static BEC_2_5_10_BuildVisitError() { }
private static byte[] becc_BEC_2_5_10_BuildVisitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_10_BuildVisitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_10_BuildVisitError_bels_0 = {};
public static new BEC_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_inst;

public static new BET_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_type;

public BEC_2_6_6_SystemObject bevp_msg;
public BEC_2_6_6_SystemObject bevp_node;
public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_msgi) {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_new_2(BEC_2_6_6_SystemObject beva_msgi, BEC_2_6_6_SystemObject beva_nodei) {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_10_BuildVisitError_bels_0));
if (bevp_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 25 */ {
bevt_1_tmpany_phold = bevl_toRet.bemd_1(-201699569, bevp_msg);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_newlineGet_0();
bevl_toRet = bevt_1_tmpany_phold.bemd_1(-201699569, bevt_2_tmpany_phold);
} /* Line: 26 */
if (bevp_node == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 28 */ {
bevl_nc = bevp_node;
while (true)
 /* Line: 30 */ {
if (bevl_nc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevl_toRet.bemd_1(-647434226, bevl_nc);
bevt_7_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_newlineGet_0();
bevl_toRet.bemd_1(-647434226, bevt_6_tmpany_phold);
bevl_nc = bevl_nc.bemd_0(-1682802805);
} /* Line: 33 */
 else  /* Line: 30 */ {
break;
} /* Line: 30 */
} /* Line: 30 */
} /* Line: 30 */
bevt_8_tmpany_phold = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(-201699569, bevt_8_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_msgGet_0() {
return bevp_msg;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_msgSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_msg = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nodeGet_0() {
return bevp_node;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_nodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_node = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {11, 16, 17, 24, 25, 25, 26, 26, 26, 26, 28, 28, 29, 30, 30, 31, 32, 32, 32, 33, 36, 36, 37, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 20, 21, 36, 37, 42, 43, 44, 45, 46, 48, 53, 54, 57, 62, 63, 64, 65, 66, 67, 74, 75, 76, 79, 82, 86, 89};
/* BEGIN LINEINFO 
assign 1 11 16
assign 1 16 20
assign 1 17 21
assign 1 24 36
new 0 24 36
assign 1 25 37
def 1 25 42
assign 1 26 43
add 1 26 43
assign 1 26 44
new 0 26 44
assign 1 26 45
newlineGet 0 26 45
assign 1 26 46
add 1 26 46
assign 1 28 48
def 1 28 53
assign 1 29 54
assign 1 30 57
def 1 30 62
addValue 1 31 63
assign 1 32 64
new 0 32 64
assign 1 32 65
newlineGet 0 32 65
addValue 1 32 66
assign 1 33 67
containerGet 0 33 67
assign 1 36 74
getFrameText 0 36 74
assign 1 36 75
add 1 36 75
return 1 37 76
return 1 0 79
assign 1 0 82
return 1 0 86
assign 1 0 89
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1596390344: return bem_emitLangGet_0();
case -1847076103: return bem_translateEmittedExceptionInner_0();
case -1920078604: return bem_sourceFileNameGet_0();
case 1624944174: return bem_serializationIteratorGet_0();
case 889323737: return bem_translateEmittedException_0();
case 1334927002: return bem_create_0();
case 1280569362: return bem_fieldIteratorGet_0();
case -1942605555: return bem_toAny_0();
case 1099128486: return bem_echo_0();
case -914943787: return bem_toString_0();
case 38289726: return bem_print_0();
case -1808414632: return bem_methodNameGet_0();
case -1117139092: return bem_msgGet_0();
case -1367316623: return bem_fileNameGet_0();
case 277625329: return bem_klassNameGet_0();
case 2123119272: return bem_getFrameText_0();
case -1515030964: return bem_framesTextGet_0();
case 1754519730: return bem_classNameGet_0();
case -365467610: return bem_langGet_0();
case 1258765717: return bem_nodeGet_0();
case -541227487: return bem_new_0();
case 342664202: return bem_serializeContents_0();
case -929672993: return bem_descriptionGet_0();
case 385489744: return bem_iteratorGet_0();
case 20258652: return bem_framesGet_0();
case -1620303979: return bem_once_0();
case -2038987715: return bem_translatedGet_0();
case 93356535: return bem_deserializeClassNameGet_0();
case 105646630: return bem_lineNumberGet_0();
case -1618533783: return bem_serializeToString_0();
case -1749035302: return bem_copy_0();
case -1248348608: return bem_many_0();
case -1117992648: return bem_hashGet_0();
case 441576374: return bem_vvGet_0();
case -152803575: return bem_tagGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1766919230: return bem_translatedSet_1(bevd_0);
case 1669123607: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -335525514: return bem_msgSet_1(bevd_0);
case -1553866014: return bem_sameClass_1(bevd_0);
case -579664236: return bem_klassNameSet_1(bevd_0);
case 51761249: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1052704201: return bem_new_1(bevd_0);
case -1001167064: return bem_def_1(bevd_0);
case -340769287: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -900790842: return bem_defined_1(bevd_0);
case -929975460: return bem_equals_1(bevd_0);
case -1975825183: return bem_sameObject_1(bevd_0);
case -575269362: return bem_langSet_1(bevd_0);
case 400272871: return bem_vvSet_1(bevd_0);
case 880660795: return bem_descriptionSet_1(bevd_0);
case 589015080: return bem_otherType_1(bevd_0);
case -147916244: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -991162341: return bem_lineNumberSet_1(bevd_0);
case -655089260: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -2057956567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -610417430: return bem_methodNameSet_1(bevd_0);
case 1356842566: return bem_otherClass_1(bevd_0);
case 408844820: return bem_undefined_1(bevd_0);
case -1667048917: return bem_emitLangSet_1(bevd_0);
case 960625295: return bem_notEquals_1(bevd_0);
case 537379230: return bem_framesTextSet_1(bevd_0);
case -406377870: return bem_copyTo_1(bevd_0);
case -689030370: return bem_fileNameSet_1(bevd_0);
case 1417404860: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2087765200: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 805905187: return bem_framesSet_1(bevd_0);
case -445350097: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 327551615: return bem_undef_1(bevd_0);
case 1458528704: return bem_nodeSet_1(bevd_0);
case 32553456: return bem_sameType_1(bevd_0);
case 240793126: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1615755198: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1430698213: return bem_new_2(bevd_0, bevd_1);
case 914119897: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1722418125: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1183458920: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -294037420: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1794036335: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1344222461: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1453170069: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_5_10_BuildVisitError_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_5_10_BuildVisitError_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_10_BuildVisitError();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst = (BEC_2_5_10_BuildVisitError) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_type;
}
}
}
