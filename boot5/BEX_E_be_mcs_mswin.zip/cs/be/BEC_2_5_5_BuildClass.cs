namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_5_BuildClass : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildClass() { }
static BEC_2_5_5_BuildClass() { }
private static byte[] becc_BEC_2_5_5_BuildClass_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73};
private static byte[] becc_BEC_2_5_5_BuildClass_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_0 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_2 = {0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildClass_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildClass_bels_2, 11));
private static byte[] bece_BEC_2_5_5_BuildClass_bels_3 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildClass_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildClass_bels_3, 10));
public static new BEC_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_inst;

public static new BET_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_extends;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_libName;
public BEC_2_9_3_ContainerMap bevp_methods;
public BEC_2_9_10_ContainerLinkedList bevp_orderedMethods;
public BEC_2_9_10_ContainerLinkedList bevp_used;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_5_4_LogicBool bevp_freeFirstSlot;
public BEC_2_5_4_LogicBool bevp_firstSlotNative;
public BEC_2_4_3_MathInt bevp_nativeSlots;
public BEC_2_5_4_LogicBool bevp_isList;
public BEC_2_4_3_MathInt bevp_onceEvalCount;
public BEC_2_9_3_ContainerSet bevp_referencedProperties;
public BEC_2_5_4_LogicBool bevp_shouldWrite;
public BEC_2_4_3_MathInt bevp_belsCount;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevp_methods = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_used = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_anyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isLocal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isNotNull = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_nativeSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isList = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_onceEvalCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldWrite = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_belsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_0));
bevl_np.bem_fromString_1(bevt_0_tmpany_phold);
bem_addUsed_1(bevl_np);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_1));
bevl_np.bem_fromString_1(bevt_1_tmpany_phold);
bem_addUsed_1(bevl_np);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addUsed_1(BEC_2_6_6_SystemObject beva_touse) {
bevp_used.bem_addValue_1(beva_touse);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_emits == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 138 */ {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 139 */
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_ret = bem_classNameGet_0();
if (bevp_namepath == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 146 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_5_BuildClass_bevo_0;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_namepath.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
if (bevp_extends == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_5_BuildClass_bevo_1;
bevt_5_tmpany_phold = bevl_ret.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_extends.bem_toString_0();
bevl_ret = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 149 */
} /* Line: 148 */
return bevl_ret;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGet_0() {
return bevp_extends;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() {
return bevp_emits;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGet_0() {
return bevp_methods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGet_0() {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGet_0() {
return bevp_used;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGet_0() {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGet_0() {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGet_0() {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGet_0() {
return bevp_isList;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGet_0() {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGet_0() {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGet_0() {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGet_0() {
return bevp_belsCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 124, 125, 125, 126, 128, 129, 129, 130, 134, 138, 138, 139, 141, 145, 146, 146, 147, 147, 147, 147, 148, 148, 149, 149, 149, 149, 152, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 72, 77, 82, 83, 85, 98, 99, 104, 105, 106, 107, 108, 109, 114, 115, 116, 117, 118, 121, 124, 127, 131, 134, 138, 141, 145, 148, 152, 155, 159, 162, 166, 169, 173, 176, 180, 183, 187, 190, 194, 197, 201, 204, 208, 211, 215, 218, 222, 225, 229, 232, 236, 239, 243, 246, 250, 253, 257, 260, 264, 267, 271, 274, 278, 281};
/* BEGIN LINEINFO 
assign 1 104 45
new 0 104 45
assign 1 105 46
new 0 105 46
assign 1 106 47
new 0 106 47
assign 1 107 48
new 0 107 48
assign 1 108 49
new 0 108 49
assign 1 109 50
new 0 109 50
assign 1 110 51
new 0 110 51
assign 1 111 52
new 0 111 52
assign 1 112 53
new 0 112 53
assign 1 113 54
new 0 113 54
assign 1 114 55
new 0 114 55
assign 1 115 56
new 0 115 56
assign 1 116 57
new 0 116 57
assign 1 117 58
new 0 117 58
assign 1 118 59
new 0 118 59
assign 1 119 60
new 0 119 60
assign 1 124 61
new 0 124 61
assign 1 125 62
new 0 125 62
fromString 1 125 63
addUsed 1 126 64
assign 1 128 65
new 0 128 65
assign 1 129 66
new 0 129 66
fromString 1 129 67
addUsed 1 130 68
addValue 1 134 72
assign 1 138 77
undef 1 138 82
assign 1 139 83
new 0 139 83
addValue 1 141 85
assign 1 145 98
classNameGet 0 145 98
assign 1 146 99
def 1 146 104
assign 1 147 105
new 0 147 105
assign 1 147 106
add 1 147 106
assign 1 147 107
toString 0 147 107
assign 1 147 108
add 1 147 108
assign 1 148 109
def 1 148 114
assign 1 149 115
new 0 149 115
assign 1 149 116
add 1 149 116
assign 1 149 117
toString 0 149 117
assign 1 149 118
add 1 149 118
return 1 152 121
return 1 0 124
assign 1 0 127
return 1 0 131
assign 1 0 134
return 1 0 138
assign 1 0 141
return 1 0 145
assign 1 0 148
return 1 0 152
assign 1 0 155
return 1 0 159
assign 1 0 162
return 1 0 166
assign 1 0 169
return 1 0 173
assign 1 0 176
return 1 0 180
assign 1 0 183
return 1 0 187
assign 1 0 190
return 1 0 194
assign 1 0 197
return 1 0 201
assign 1 0 204
return 1 0 208
assign 1 0 211
return 1 0 215
assign 1 0 218
return 1 0 222
assign 1 0 225
return 1 0 229
assign 1 0 232
return 1 0 236
assign 1 0 239
return 1 0 243
assign 1 0 246
return 1 0 250
assign 1 0 253
return 1 0 257
assign 1 0 260
return 1 0 264
assign 1 0 267
return 1 0 271
assign 1 0 274
return 1 0 278
assign 1 0 281
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 778703235: return bem_extendsGet_0();
case 1280569362: return bem_fieldIteratorGet_0();
case 1952448022: return bem_isFinalGet_0();
case -914943787: return bem_toString_0();
case -1500263473: return bem_isNotNullGet_0();
case 2118350648: return bem_onceEvalCountGet_0();
case -1808671166: return bem_fromFileGet_0();
case -1117992648: return bem_hashGet_0();
case 1337171401: return bem_emitsGet_0();
case 2117344602: return bem_synGet_0();
case 1033872092: return bem_methodsGet_0();
case 1561253085: return bem_nativeSlotsGet_0();
case -2095591781: return bem_orderedMethodsGet_0();
case 1334927002: return bem_create_0();
case 1190698147: return bem_referencedPropertiesGet_0();
case 594614948: return bem_nameGet_0();
case -1749035302: return bem_copy_0();
case 1825001642: return bem_belsCountGet_0();
case 1624944174: return bem_serializationIteratorGet_0();
case -1666874315: return bem_usedGet_0();
case 385489744: return bem_iteratorGet_0();
case -541227487: return bem_new_0();
case -1620303979: return bem_once_0();
case -1942605555: return bem_toAny_0();
case -1293517305: return bem_orderedVarsGet_0();
case -1718643332: return bem_firstSlotNativeGet_0();
case 1184954760: return bem_isListGet_0();
case 342664202: return bem_serializeContents_0();
case -1920078604: return bem_sourceFileNameGet_0();
case 25264406: return bem_anyMapGet_0();
case -1618533783: return bem_serializeToString_0();
case 1760273190: return bem_isLocalGet_0();
case 1099128486: return bem_echo_0();
case 1754519730: return bem_classNameGet_0();
case -745462197: return bem_namepathGet_0();
case 38289726: return bem_print_0();
case 986539327: return bem_libNameGet_0();
case -1248348608: return bem_many_0();
case 1126390222: return bem_freeFirstSlotGet_0();
case -680283631: return bem_shouldWriteGet_0();
case 93356535: return bem_deserializeClassNameGet_0();
case -152803575: return bem_tagGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1924378866: return bem_nativeSlotsSet_1(bevd_0);
case 1770631510: return bem_referencedPropertiesSet_1(bevd_0);
case 1669123607: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -91915898: return bem_namepathSet_1(bevd_0);
case 508888195: return bem_nameSet_1(bevd_0);
case -1553866014: return bem_sameClass_1(bevd_0);
case 43977225: return bem_addUsed_1(bevd_0);
case -1586928134: return bem_isListSet_1(bevd_0);
case 1672034497: return bem_firstSlotNativeSet_1(bevd_0);
case -1001167064: return bem_def_1(bevd_0);
case -900790842: return bem_defined_1(bevd_0);
case -929975460: return bem_equals_1(bevd_0);
case -1975825183: return bem_sameObject_1(bevd_0);
case 1754131870: return bem_freeFirstSlotSet_1(bevd_0);
case -1592470427: return bem_orderedVarsSet_1(bevd_0);
case 1178826503: return bem_isFinalSet_1(bevd_0);
case 1717638656: return bem_emitsSet_1(bevd_0);
case 1794878102: return bem_extendsSet_1(bevd_0);
case -230618094: return bem_methodsSet_1(bevd_0);
case 589015080: return bem_otherType_1(bevd_0);
case -147916244: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 366569033: return bem_belsCountSet_1(bevd_0);
case 1567490512: return bem_synSet_1(bevd_0);
case -1564527534: return bem_isNotNullSet_1(bevd_0);
case 389702017: return bem_fromFileSet_1(bevd_0);
case -2057956567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1397469208: return bem_usedSet_1(bevd_0);
case 1726532221: return bem_anyMapSet_1(bevd_0);
case -1808840618: return bem_orderedMethodsSet_1(bevd_0);
case -589427483: return bem_isLocalSet_1(bevd_0);
case 1356842566: return bem_otherClass_1(bevd_0);
case 408844820: return bem_undefined_1(bevd_0);
case 960625295: return bem_notEquals_1(bevd_0);
case -406377870: return bem_copyTo_1(bevd_0);
case 1417404860: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 327551615: return bem_undef_1(bevd_0);
case 405273717: return bem_shouldWriteSet_1(bevd_0);
case 32553456: return bem_sameType_1(bevd_0);
case -1532323281: return bem_libNameSet_1(bevd_0);
case 906252022: return bem_addEmit_1(bevd_0);
case -263866307: return bem_onceEvalCountSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1615755198: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 914119897: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1722418125: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1183458920: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -294037420: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1794036335: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1344222461: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildClass_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_5_BuildClass_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildClass();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst = (BEC_2_5_5_BuildClass) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_type;
}
}
}
