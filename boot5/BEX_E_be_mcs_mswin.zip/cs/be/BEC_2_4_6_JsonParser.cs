namespace be {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_6_JsonParser : BEC_2_6_6_SystemObject {
public BEC_2_4_6_JsonParser() { }
static BEC_2_4_6_JsonParser() { }
private static byte[] becc_BEC_2_4_6_JsonParser_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x72};
private static byte[] becc_BEC_2_4_6_JsonParser_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_0 = {0x7B};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_1 = {0x7D};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_2 = {0x5B};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_3 = {0x5D};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_4 = {0x5C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_5 = {0x2C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_6 = {0x62,0x66,0x6E,0x72,0x74,0x2F};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_8 = {0x44,0x43,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_9 = {0x31,0x30,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_10 = {0x74,0x6F,0x6B,0x20,0x74,0x6F,0x6F,0x20,0x73,0x6D,0x61,0x6C,0x6C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_11 = {0x38,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_12 = {0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_13 = {0x43,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_14 = {0x37,0x43,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_15 = {0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_16 = {0x45,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_17 = {0x46,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_18 = {0x30,0x46,0x43,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_19 = {0x30,0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_20 = {0x31,0x30,0x46,0x46,0x46,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_21 = {0x46,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_22 = {0x31,0x43,0x30,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_23 = {0x30,0x33,0x46,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_24 = {0x30,0x30,0x30,0x46,0x43,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_25 = {0x30,0x30,0x30,0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_26 = {0x66,0x61,0x69,0x6C,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x74,0x6F,0x20,0x62,0x75,0x66,0x66,0x65,0x72,0x20,0x63,0x6F,0x6E,0x76,0x65,0x72,0x74};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_27 = {0x75};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_28 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x69,0x73,0x20,0x69,0x6E,0x76,0x61,0x6C,0x69,0x64};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_29 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x65,0x64,0x20,0x62,0x79,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_30 = {0x74};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_31 = {0x72};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_32 = {0x66};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_33 = {0x6E};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_34 = {0x75,0x65};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_35 = {0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_36 = {0x75,0x6C,0x6C};
public static new BEC_2_4_6_JsonParser bece_BEC_2_4_6_JsonParser_bevs_inst;

public static new BET_2_4_6_JsonParser bece_BEC_2_4_6_JsonParser_bevs_type;

public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_lbrace;
public BEC_2_4_6_TextString bevp_rbrace;
public BEC_2_4_6_TextString bevp_lbracket;
public BEC_2_4_6_TextString bevp_rbracket;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_6_TextString bevp_escape;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_comma;
public BEC_2_4_6_TextString bevp_tokens;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_4_3_MathInt bevp_hsub;
public BEC_2_4_3_MathInt bevp_vsub;
public BEC_2_4_3_MathInt bevp_hmAdd;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_4_7_TextStrings bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_quote = bevt_0_ta_ph.bem_quoteGet_0();
bevp_lbrace = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_0));
bevp_rbrace = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_1));
bevp_lbracket = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_2));
bevp_rbracket = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_3));
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_space = bevt_1_ta_ph.bem_spaceGet_0();
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_colon = bevt_2_ta_ph.bem_colonGet_0();
bevp_escape = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_4));
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_cr = bevt_3_ta_ph.bem_crGet_0();
bevt_4_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_lf = bevt_4_ta_ph.bem_lfGet_0();
bevp_comma = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_5));
bevt_14_ta_ph = bevp_quote.bem_add_1(bevp_lbrace);
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevp_rbrace);
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevp_lbracket);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevp_rbracket);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevp_space);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevp_colon);
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevp_escape);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevp_cr);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevp_lf);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_comma);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_6));
bevp_tokens = bevt_5_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_toker = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevp_tokens, bevt_16_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_7));
bevp_hsub = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_ta_ph);
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_8));
bevp_vsub = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_6_JsonParser_bels_9));
bevp_hmAdd = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_19_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parse_2(BEC_2_4_6_TextString beva_str, BEC_2_6_6_SystemObject beva_handler) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_toker.bem_tokenize_1(beva_str);
bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevt_0_ta_ph , beva_handler);
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_jsonUcIsPairStart_1(BEC_2_4_3_MathInt beva_value) {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55296));
if (bevt_2_ta_ph.bevi_int <= beva_value.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 62*/ {
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(56319));
if (beva_value.bevi_int <= bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 62*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 62*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 62*/
 else /* Line: 62*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 62*/ {
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 63*/
 else /* Line: 64*/ {
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 65*/
return bevl_result;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_jsonUcIsPairEnd_1(BEC_2_4_3_MathInt beva_value) {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(56320));
if (bevt_2_ta_ph.bevi_int <= beva_value.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 73*/ {
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(57343));
if (beva_value.bevi_int <= bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 73*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 73*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 73*/
 else /* Line: 73*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 73*/ {
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 74*/
 else /* Line: 75*/ {
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 76*/
return bevl_result;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_jsonUcGetAfterPart_1(BEC_2_4_6_TextString beva_tok) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_1_ta_ph = beva_tok.bem_sizeGet_0();
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
if (bevt_1_ta_ph.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 83*/ {
return null;
} /* Line: 84*/
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevt_3_ta_ph = beva_tok.bem_substring_1(bevt_4_ta_ph);
return bevt_3_ta_ph;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_jsonUcUnescape_1(BEC_2_4_6_TextString beva_tok) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_9_SystemException bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
bevt_1_ta_ph = beva_tok.bem_sizeGet_0();
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
if (bevt_1_ta_ph.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 90*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_4_6_JsonParser_bels_10));
bevt_3_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_ta_ph);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 91*/
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_6_ta_ph = beva_tok.bem_substring_1(bevt_7_ta_ph);
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_6_ta_ph);
return bevt_5_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_jsonUcAppendValue_3(BEC_2_4_3_MathInt beva_heldValue, BEC_2_4_3_MathInt beva_value, BEC_2_4_6_TextString beva_accum) {
BEC_2_4_3_MathInt bevl_sizeNow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_heldm = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_3_MathInt bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_3_MathInt bevt_44_ta_ph = null;
BEC_2_4_3_MathInt bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_4_3_MathInt bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_4_3_MathInt bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_3_MathInt bevt_69_ta_ph = null;
BEC_2_4_3_MathInt bevt_70_ta_ph = null;
BEC_2_4_3_MathInt bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_3_MathInt bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_4_3_MathInt bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
BEC_2_4_3_MathInt bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
BEC_2_4_3_MathInt bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_3_MathInt bevt_89_ta_ph = null;
BEC_2_4_3_MathInt bevt_90_ta_ph = null;
BEC_2_4_3_MathInt bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_3_MathInt bevt_93_ta_ph = null;
BEC_2_4_3_MathInt bevt_94_ta_ph = null;
BEC_2_4_3_MathInt bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_4_3_MathInt bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_4_3_MathInt bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_5_4_LogicBool bevt_102_ta_ph = null;
BEC_2_4_3_MathInt bevt_103_ta_ph = null;
BEC_2_6_9_SystemException bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_4_3_MathInt bevt_106_ta_ph = null;
BEC_2_4_3_MathInt bevt_107_ta_ph = null;
bevt_2_ta_ph = beva_accum.bem_capacityGet_0();
bevt_3_ta_ph = beva_accum.bem_sizeGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_subtract_1(bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
if (bevt_1_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 98*/ {
bevt_6_ta_ph = beva_accum.bem_sizeGet_0();
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_7_ta_ph);
beva_accum.bem_capacitySet_1(bevt_5_ta_ph);
} /* Line: 99*/
bevl_sizeNow = beva_accum.bem_sizeGet_0();
if (beva_heldValue == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 104*/ {
bevl_heldm = beva_heldValue;
bevl_heldm.bem_subtractValue_1(bevp_hsub);
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevl_heldm.bem_shiftLeftValue_1(bevt_9_ta_ph);
bevl_heldm.bem_subtractValue_1(bevp_vsub);
bevl_heldm.bevi_int += beva_value.bevi_int;
bevl_heldm.bevi_int += bevp_hmAdd.bevi_int;
beva_value = bevl_heldm;
} /* Line: 112*/
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_value.bevi_int < bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 118*/ {
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 119*/
 else /* Line: 118*/ {
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_13_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_14_ta_ph);
if (beva_value.bevi_int < bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 120*/ {
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, beva_value);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 122*/
 else /* Line: 118*/ {
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_12));
bevt_16_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_ta_ph);
if (beva_value.bevi_int < bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 123*/ {
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_13));
bevt_19_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_20_ta_ph);
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_14));
bevt_23_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_24_ta_ph);
bevt_22_ta_ph = beva_value.bem_and_1(bevt_23_ta_ph);
bevt_25_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_21_ta_ph = bevt_22_ta_ph.bem_shiftRight_1(bevt_25_ta_ph);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_21_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_18_ta_ph);
bevt_27_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_26_ta_ph = bevl_sizeNow.bem_add_1(bevt_27_ta_ph);
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_29_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_30_ta_ph);
bevt_33_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_15));
bevt_32_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_33_ta_ph);
bevt_31_ta_ph = beva_value.bem_and_1(bevt_32_ta_ph);
bevt_28_ta_ph = bevt_29_ta_ph.bem_add_1(bevt_31_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_26_ta_ph, bevt_28_ta_ph);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
} /* Line: 126*/
 else /* Line: 118*/ {
bevt_36_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_6_JsonParser_bels_9));
bevt_35_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_36_ta_ph);
if (beva_value.bevi_int < bevt_35_ta_ph.bevi_int) {
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_34_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_34_ta_ph.bevi_bool)/* Line: 127*/ {
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_16));
bevt_38_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_39_ta_ph);
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_17));
bevt_42_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_43_ta_ph);
bevt_41_ta_ph = beva_value.bem_and_1(bevt_42_ta_ph);
bevt_44_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(12));
bevt_40_ta_ph = bevt_41_ta_ph.bem_shiftRight_1(bevt_44_ta_ph);
bevt_37_ta_ph = bevt_38_ta_ph.bem_add_1(bevt_40_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_37_ta_ph);
bevt_46_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_45_ta_ph = bevl_sizeNow.bem_add_1(bevt_46_ta_ph);
bevt_49_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_48_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_49_ta_ph);
bevt_53_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_18));
bevt_52_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_53_ta_ph);
bevt_51_ta_ph = beva_value.bem_and_1(bevt_52_ta_ph);
bevt_54_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_50_ta_ph = bevt_51_ta_ph.bem_shiftRight_1(bevt_54_ta_ph);
bevt_47_ta_ph = bevt_48_ta_ph.bem_add_1(bevt_50_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_45_ta_ph, bevt_47_ta_ph);
bevt_56_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_55_ta_ph = bevl_sizeNow.bem_add_1(bevt_56_ta_ph);
bevt_59_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_58_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_59_ta_ph);
bevt_62_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_19));
bevt_61_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_62_ta_ph);
bevt_60_ta_ph = beva_value.bem_and_1(bevt_61_ta_ph);
bevt_57_ta_ph = bevt_58_ta_ph.bem_add_1(bevt_60_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_55_ta_ph, bevt_57_ta_ph);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
} /* Line: 131*/
 else /* Line: 118*/ {
bevt_65_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_20));
bevt_64_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_65_ta_ph);
if (beva_value.bevi_int <= bevt_64_ta_ph.bevi_int) {
bevt_63_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_63_ta_ph.bevi_bool)/* Line: 132*/ {
bevt_68_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_21));
bevt_67_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_68_ta_ph);
bevt_72_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_22));
bevt_71_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_72_ta_ph);
bevt_70_ta_ph = beva_value.bem_and_1(bevt_71_ta_ph);
bevt_73_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(18));
bevt_69_ta_ph = bevt_70_ta_ph.bem_shiftRight_1(bevt_73_ta_ph);
bevt_66_ta_ph = bevt_67_ta_ph.bem_add_1(bevt_69_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_66_ta_ph);
bevt_75_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_74_ta_ph = bevl_sizeNow.bem_add_1(bevt_75_ta_ph);
bevt_78_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_77_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_78_ta_ph);
bevt_82_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_23));
bevt_81_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_82_ta_ph);
bevt_80_ta_ph = beva_value.bem_and_1(bevt_81_ta_ph);
bevt_83_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(12));
bevt_79_ta_ph = bevt_80_ta_ph.bem_shiftRight_1(bevt_83_ta_ph);
bevt_76_ta_ph = bevt_77_ta_ph.bem_add_1(bevt_79_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_74_ta_ph, bevt_76_ta_ph);
bevt_85_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_84_ta_ph = bevl_sizeNow.bem_add_1(bevt_85_ta_ph);
bevt_88_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_87_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_88_ta_ph);
bevt_92_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_24));
bevt_91_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_92_ta_ph);
bevt_90_ta_ph = beva_value.bem_and_1(bevt_91_ta_ph);
bevt_93_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_89_ta_ph = bevt_90_ta_ph.bem_shiftRight_1(bevt_93_ta_ph);
bevt_86_ta_ph = bevt_87_ta_ph.bem_add_1(bevt_89_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_84_ta_ph, bevt_86_ta_ph);
bevt_95_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevt_94_ta_ph = bevl_sizeNow.bem_add_1(bevt_95_ta_ph);
bevt_98_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_97_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_98_ta_ph);
bevt_101_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_25));
bevt_100_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_101_ta_ph);
bevt_99_ta_ph = beva_value.bem_and_1(bevt_100_ta_ph);
bevt_96_ta_ph = bevt_97_ta_ph.bem_add_1(bevt_99_ta_ph);
beva_accum.bem_setIntUnchecked_2(bevt_94_ta_ph, bevt_96_ta_ph);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
} /* Line: 137*/
 else /* Line: 138*/ {
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 139*/
} /* Line: 118*/
} /* Line: 118*/
} /* Line: 118*/
} /* Line: 118*/
bevt_103_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_size.bevi_int < bevt_103_ta_ph.bevi_int) {
bevt_102_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_102_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_102_ta_ph.bevi_bool)/* Line: 142*/ {
bevt_105_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_4_6_JsonParser_bels_26));
bevt_104_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_105_ta_ph);
throw new be.BECS_ThrowBack(bevt_104_ta_ph);
} /* Line: 143*/
bevt_107_ta_ph = beva_accum.bem_sizeGet_0();
bevt_106_ta_ph = bevt_107_ta_ph.bem_add_1(bevl_size);
beva_accum.bem_sizeSet_1(bevt_106_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parseTokens_2(BEC_2_9_10_ContainerLinkedList beva_toks, BEC_2_6_6_SystemObject beva_handler) {
BEC_2_5_4_LogicBool bevl_inString = null;
BEC_2_5_4_LogicBool bevl_inEscape = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_9_3_ContainerMap bevl_fromEscapes = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_tokIter = null;
BEC_2_4_3_MathInt bevl_heldValue = null;
BEC_2_4_6_TextString bevl_tok = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_6_TextString bevl_remainder = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_4_7_JsonEscapes bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_9_SystemException bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_6_9_SystemException bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_5_4_LogicBool bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_5_4_LogicBool bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
bevl_inString = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_ta_ph = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
bevl_fromEscapes = bevt_9_ta_ph.bem_fromEscapesGet_0();
bevl_tokIter = beva_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 176*/ {
bevt_10_ta_ph = bevl_tokIter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 176*/ {
bevl_tok = (BEC_2_4_6_TextString) bevl_tokIter.bem_nextGet_0();
if (bevl_inString.bevi_bool)/* Line: 179*/ {
if (bevl_inEscape.bevi_bool) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 180*/ {
bevt_12_ta_ph = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_12_ta_ph.bevi_bool)/* Line: 180*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 180*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 180*/
 else /* Line: 180*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 180*/ {
bevl_inString = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_13_ta_ph = bevl_accum.bem_extractString_0();
beva_handler.bemd_1(-89657737, bevt_13_ta_ph);
} /* Line: 182*/
 else /* Line: 183*/ {
if (bevl_inEscape.bevi_bool)/* Line: 184*/ {
bevl_escval = (BEC_2_4_6_TextString) bevl_fromEscapes.bem_get_1(bevl_tok);
if (bevl_escval == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 186*/ {
bevl_accum.bem_addValue_1(bevl_escval);
} /* Line: 187*/
 else /* Line: 186*/ {
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_27));
bevt_15_ta_ph = bevl_tok.bem_begins_1(bevt_16_ta_ph);
if (bevt_15_ta_ph.bevi_bool)/* Line: 188*/ {
bevl_value = bem_jsonUcUnescape_1(bevl_tok);
bevl_remainder = bem_jsonUcGetAfterPart_1(bevl_tok);
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevl_heldValue == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 192*/ {
bevt_19_ta_ph = bem_jsonUcIsPairEnd_1(bevl_value);
if (bevt_19_ta_ph.bevi_bool) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 192*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 192*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 192*/
 else /* Line: 192*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 192*/ {
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(62, bece_BEC_2_4_6_JsonParser_bels_28));
bevt_20_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_21_ta_ph);
throw new be.BECS_ThrowBack(bevt_20_ta_ph);
} /* Line: 193*/
 else /* Line: 192*/ {
if (bevl_heldValue == null) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 194*/ {
bevl_isStart = bem_jsonUcIsPairStart_1(bevl_value);
} /* Line: 195*/
} /* Line: 192*/
if (bevl_isStart.bevi_bool)/* Line: 197*/ {
if (bevl_remainder == null) {
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 197*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 197*/
 else /* Line: 197*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 197*/ {
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(73, bece_BEC_2_4_6_JsonParser_bels_29));
bevt_24_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_ta_ph);
throw new be.BECS_ThrowBack(bevt_24_ta_ph);
} /* Line: 198*/
if (bevl_isStart.bevi_bool)/* Line: 200*/ {
bevl_heldValue = bevl_value;
} /* Line: 201*/
 else /* Line: 202*/ {
bem_jsonUcAppendValue_3(bevl_heldValue, bevl_value, bevl_accum);
bevl_heldValue = null;
if (bevl_remainder == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 205*/ {
bevl_accum.bem_addValue_1(bevl_remainder);
} /* Line: 206*/
} /* Line: 205*/
} /* Line: 200*/
 else /* Line: 209*/ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 210*/
} /* Line: 186*/
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 212*/
 else /* Line: 184*/ {
bevt_27_ta_ph = bevl_tok.bem_equals_1(bevp_escape);
if (bevt_27_ta_ph.bevi_bool)/* Line: 213*/ {
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 214*/
 else /* Line: 215*/ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 216*/
} /* Line: 184*/
} /* Line: 184*/
} /* Line: 180*/
 else /* Line: 219*/ {
bevt_28_ta_ph = bevl_tok.bem_equals_1(bevp_space);
if (bevt_28_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
bevt_29_ta_ph = bevl_tok.bem_equals_1(bevp_cr);
if (bevt_29_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 221*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 221*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
bevt_30_ta_ph = bevl_tok.bem_equals_1(bevp_lf);
if (bevt_30_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 221*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 221*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
bevt_31_ta_ph = bevl_tok.bem_equals_1(bevp_comma);
if (bevt_31_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 221*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 221*/ {
} /* Line: 221*/
 else /* Line: 221*/ {
bevt_32_ta_ph = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_32_ta_ph.bevi_bool)/* Line: 222*/ {
bevl_inString = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 223*/
 else /* Line: 221*/ {
bevt_33_ta_ph = bevl_tok.bem_equals_1(bevp_lbrace);
if (bevt_33_ta_ph.bevi_bool)/* Line: 224*/ {
beva_handler.bemd_0(1774726669);
} /* Line: 225*/
 else /* Line: 221*/ {
bevt_34_ta_ph = bevl_tok.bem_equals_1(bevp_rbrace);
if (bevt_34_ta_ph.bevi_bool)/* Line: 226*/ {
beva_handler.bemd_0(35574049);
} /* Line: 227*/
 else /* Line: 221*/ {
bevt_35_ta_ph = bevl_tok.bem_equals_1(bevp_colon);
if (bevt_35_ta_ph.bevi_bool)/* Line: 228*/ {
beva_handler.bemd_0(-88952667);
} /* Line: 229*/
 else /* Line: 221*/ {
bevt_36_ta_ph = bevl_tok.bem_equals_1(bevp_lbracket);
if (bevt_36_ta_ph.bevi_bool)/* Line: 230*/ {
beva_handler.bemd_0(-2077737637);
} /* Line: 231*/
 else /* Line: 221*/ {
bevt_37_ta_ph = bevl_tok.bem_equals_1(bevp_rbracket);
if (bevt_37_ta_ph.bevi_bool)/* Line: 232*/ {
beva_handler.bemd_0(62664982);
} /* Line: 233*/
 else /* Line: 234*/ {
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_30));
bevt_38_ta_ph = bevl_tok.bem_equals_1(bevt_39_ta_ph);
if (bevt_38_ta_ph.bevi_bool)/* Line: 237*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 237*/ {
bevt_41_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_31));
bevt_40_ta_ph = bevl_tok.bem_equals_1(bevt_41_ta_ph);
if (bevt_40_ta_ph.bevi_bool)/* Line: 237*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 237*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 237*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 237*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 237*/ {
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_32));
bevt_42_ta_ph = bevl_tok.bem_equals_1(bevt_43_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 237*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 237*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 237*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 237*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 237*/ {
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_33));
bevt_44_ta_ph = bevl_tok.bem_equals_1(bevt_45_ta_ph);
if (bevt_44_ta_ph.bevi_bool)/* Line: 237*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 237*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 237*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 237*/ {
} /* Line: 237*/
 else /* Line: 237*/ {
bevt_47_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_34));
bevt_46_ta_ph = bevl_tok.bem_equals_1(bevt_47_ta_ph);
if (bevt_46_ta_ph.bevi_bool)/* Line: 240*/ {
beva_handler.bemd_0(-1815008835);
} /* Line: 241*/
 else /* Line: 237*/ {
bevt_49_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_35));
bevt_48_ta_ph = bevl_tok.bem_equals_1(bevt_49_ta_ph);
if (bevt_48_ta_ph.bevi_bool)/* Line: 242*/ {
beva_handler.bemd_0(-1381475953);
} /* Line: 243*/
 else /* Line: 237*/ {
bevt_51_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_36));
bevt_50_ta_ph = bevl_tok.bem_equals_1(bevt_51_ta_ph);
if (bevt_50_ta_ph.bevi_bool)/* Line: 244*/ {
beva_handler.bemd_0(1474173432);
} /* Line: 245*/
 else /* Line: 246*/ {
bevt_52_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_tok);
beva_handler.bemd_1(1253708956, bevt_52_ta_ph);
} /* Line: 248*/
} /* Line: 237*/
} /* Line: 237*/
} /* Line: 237*/
} /* Line: 237*/
} /* Line: 221*/
} /* Line: 221*/
} /* Line: 221*/
} /* Line: 221*/
} /* Line: 221*/
} /* Line: 221*/
} /* Line: 221*/
} /* Line: 179*/
 else /* Line: 176*/ {
break;
} /* Line: 176*/
} /* Line: 176*/
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGetDirect_0() {
return bevp_quote;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lbraceGet_0() {
return bevp_lbrace;
} /*method end*/
public BEC_2_4_6_TextString bem_lbraceGetDirect_0() {
return bevp_lbrace;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_lbraceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lbrace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lbraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lbrace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_rbraceGet_0() {
return bevp_rbrace;
} /*method end*/
public BEC_2_4_6_TextString bem_rbraceGetDirect_0() {
return bevp_rbrace;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_rbraceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rbrace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_rbraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rbrace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lbracketGet_0() {
return bevp_lbracket;
} /*method end*/
public BEC_2_4_6_TextString bem_lbracketGetDirect_0() {
return bevp_lbracket;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_lbracketSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lbracket = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lbracketSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lbracket = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_rbracketGet_0() {
return bevp_rbracket;
} /*method end*/
public BEC_2_4_6_TextString bem_rbracketGetDirect_0() {
return bevp_rbracket;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_rbracketSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rbracket = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_rbracketSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rbracket = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGetDirect_0() {
return bevp_space;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGetDirect_0() {
return bevp_colon;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_escapeGet_0() {
return bevp_escape;
} /*method end*/
public BEC_2_4_6_TextString bem_escapeGetDirect_0() {
return bevp_escape;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_escapeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_escape = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_escapeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_escape = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_6_TextString bem_crGetDirect_0() {
return bevp_cr;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGetDirect_0() {
return bevp_lf;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_commaGet_0() {
return bevp_comma;
} /*method end*/
public BEC_2_4_6_TextString bem_commaGetDirect_0() {
return bevp_comma;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_commaSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_comma = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_commaSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_comma = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_tokensGet_0() {
return bevp_tokens;
} /*method end*/
public BEC_2_4_6_TextString bem_tokensGetDirect_0() {
return bevp_tokens;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_tokensSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tokens = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_tokensSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tokens = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_tokerGet_0() {
return bevp_toker;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGetDirect_0() {
return bevp_toker;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_tokerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hsubGet_0() {
return bevp_hsub;
} /*method end*/
public BEC_2_4_3_MathInt bem_hsubGetDirect_0() {
return bevp_hsub;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_hsubSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_hsub = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_hsubSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_hsub = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_vsubGet_0() {
return bevp_vsub;
} /*method end*/
public BEC_2_4_3_MathInt bem_vsubGetDirect_0() {
return bevp_vsub;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_vsubSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vsub = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_vsubSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vsub = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hmAddGet_0() {
return bevp_hmAdd;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmAddGetDirect_0() {
return bevp_hmAdd;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_hmAddSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_hmAdd = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_hmAddSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_hmAdd = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {36, 36, 37, 38, 39, 40, 41, 41, 42, 42, 43, 44, 44, 45, 45, 46, 47, 47, 47, 47, 47, 47, 47, 47, 47, 47, 47, 47, 48, 48, 49, 49, 50, 50, 51, 51, 57, 57, 62, 62, 62, 62, 62, 62, 0, 0, 0, 63, 65, 67, 73, 73, 73, 73, 73, 73, 0, 0, 0, 74, 76, 78, 83, 83, 83, 83, 84, 86, 86, 86, 90, 90, 90, 90, 91, 91, 91, 93, 93, 93, 93, 98, 98, 98, 98, 98, 98, 99, 99, 99, 99, 101, 104, 104, 106, 107, 108, 108, 109, 110, 111, 112, 118, 118, 118, 119, 120, 120, 120, 120, 121, 122, 123, 123, 123, 123, 124, 124, 124, 124, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 125, 126, 127, 127, 127, 127, 128, 128, 128, 128, 128, 128, 128, 128, 128, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 130, 130, 130, 130, 130, 130, 130, 130, 130, 131, 132, 132, 132, 132, 133, 133, 133, 133, 133, 133, 133, 133, 133, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 136, 136, 136, 136, 136, 136, 136, 136, 136, 137, 139, 142, 142, 142, 143, 143, 143, 145, 145, 145, 166, 167, 168, 170, 170, 172, 176, 177, 180, 180, 180, 0, 0, 0, 181, 182, 182, 185, 186, 186, 187, 188, 188, 189, 190, 191, 192, 192, 192, 192, 192, 0, 0, 0, 193, 193, 193, 194, 194, 195, 197, 197, 0, 0, 0, 198, 198, 198, 201, 203, 204, 205, 205, 206, 210, 212, 213, 214, 216, 221, 0, 221, 0, 0, 0, 221, 0, 0, 0, 221, 0, 0, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 237, 237, 0, 237, 237, 0, 0, 0, 237, 237, 0, 0, 0, 237, 237, 0, 0, 240, 240, 241, 242, 242, 243, 244, 244, 245, 248, 248, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 126, 127, 137, 138, 143, 144, 145, 150, 151, 154, 158, 161, 164, 166, 175, 176, 181, 182, 183, 188, 189, 192, 196, 199, 202, 204, 212, 213, 214, 219, 220, 222, 223, 224, 235, 236, 237, 242, 243, 244, 245, 247, 248, 249, 250, 364, 365, 366, 367, 368, 373, 374, 375, 376, 377, 379, 380, 385, 386, 387, 388, 389, 390, 391, 392, 393, 395, 396, 401, 402, 405, 406, 407, 412, 413, 414, 417, 418, 419, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 446, 447, 448, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 486, 487, 488, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 537, 543, 544, 549, 550, 551, 552, 554, 555, 556, 624, 625, 626, 627, 628, 629, 632, 634, 636, 641, 642, 644, 647, 651, 654, 655, 656, 660, 661, 666, 667, 670, 671, 673, 674, 675, 676, 681, 682, 683, 688, 689, 692, 696, 699, 700, 701, 704, 709, 710, 714, 719, 720, 723, 727, 730, 731, 732, 735, 738, 739, 740, 745, 746, 751, 754, 757, 759, 762, 768, 770, 773, 775, 778, 782, 785, 787, 790, 794, 797, 799, 802, 808, 810, 813, 815, 818, 820, 823, 825, 828, 830, 833, 835, 838, 839, 841, 844, 845, 847, 850, 854, 857, 858, 860, 863, 867, 870, 871, 873, 876, 882, 883, 885, 888, 889, 891, 894, 895, 897, 900, 901, 922, 925, 928, 932, 936, 939, 942, 946, 950, 953, 956, 960, 964, 967, 970, 974, 978, 981, 984, 988, 992, 995, 998, 1002, 1006, 1009, 1012, 1016, 1020, 1023, 1026, 1030, 1034, 1037, 1040, 1044, 1048, 1051, 1054, 1058, 1062, 1065, 1068, 1072, 1076, 1079, 1082, 1086, 1090, 1093, 1096, 1100, 1104, 1107, 1110, 1114, 1118, 1121, 1124, 1128, 1132, 1135, 1138, 1142};
/* BEGIN LINEINFO 
assign 1 36 86
new 0 36 86
assign 1 36 87
quoteGet 0 36 87
assign 1 37 88
new 0 37 88
assign 1 38 89
new 0 38 89
assign 1 39 90
new 0 39 90
assign 1 40 91
new 0 40 91
assign 1 41 92
new 0 41 92
assign 1 41 93
spaceGet 0 41 93
assign 1 42 94
new 0 42 94
assign 1 42 95
colonGet 0 42 95
assign 1 43 96
new 0 43 96
assign 1 44 97
new 0 44 97
assign 1 44 98
crGet 0 44 98
assign 1 45 99
new 0 45 99
assign 1 45 100
lfGet 0 45 100
assign 1 46 101
new 0 46 101
assign 1 47 102
add 1 47 102
assign 1 47 103
add 1 47 103
assign 1 47 104
add 1 47 104
assign 1 47 105
add 1 47 105
assign 1 47 106
add 1 47 106
assign 1 47 107
add 1 47 107
assign 1 47 108
add 1 47 108
assign 1 47 109
add 1 47 109
assign 1 47 110
add 1 47 110
assign 1 47 111
add 1 47 111
assign 1 47 112
new 0 47 112
assign 1 47 113
add 1 47 113
assign 1 48 114
new 0 48 114
assign 1 48 115
new 2 48 115
assign 1 49 116
new 0 49 116
assign 1 49 117
hexNew 1 49 117
assign 1 50 118
new 0 50 118
assign 1 50 119
hexNew 1 50 119
assign 1 51 120
new 0 51 120
assign 1 51 121
hexNew 1 51 121
assign 1 57 126
tokenize 1 57 126
parseTokens 2 57 127
assign 1 62 137
new 0 62 137
assign 1 62 138
lesserEquals 1 62 143
assign 1 62 144
new 0 62 144
assign 1 62 145
lesserEquals 1 62 150
assign 1 0 151
assign 1 0 154
assign 1 0 158
assign 1 63 161
new 0 63 161
assign 1 65 164
new 0 65 164
return 1 67 166
assign 1 73 175
new 0 73 175
assign 1 73 176
lesserEquals 1 73 181
assign 1 73 182
new 0 73 182
assign 1 73 183
lesserEquals 1 73 188
assign 1 0 189
assign 1 0 192
assign 1 0 196
assign 1 74 199
new 0 74 199
assign 1 76 202
new 0 76 202
return 1 78 204
assign 1 83 212
sizeGet 0 83 212
assign 1 83 213
new 0 83 213
assign 1 83 214
lesser 1 83 219
return 1 84 220
assign 1 86 222
new 0 86 222
assign 1 86 223
substring 1 86 223
return 1 86 224
assign 1 90 235
sizeGet 0 90 235
assign 1 90 236
new 0 90 236
assign 1 90 237
lesser 1 90 242
assign 1 91 243
new 0 91 243
assign 1 91 244
new 1 91 244
throw 1 91 245
assign 1 93 247
new 0 93 247
assign 1 93 248
substring 1 93 248
assign 1 93 249
hexNew 1 93 249
return 1 93 250
assign 1 98 364
capacityGet 0 98 364
assign 1 98 365
sizeGet 0 98 365
assign 1 98 366
subtract 1 98 366
assign 1 98 367
new 0 98 367
assign 1 98 368
lesser 1 98 373
assign 1 99 374
sizeGet 0 99 374
assign 1 99 375
new 0 99 375
assign 1 99 376
add 1 99 376
capacitySet 1 99 377
assign 1 101 379
sizeGet 0 101 379
assign 1 104 380
def 1 104 385
assign 1 106 386
subtractValue 1 107 387
assign 1 108 388
new 0 108 388
shiftLeftValue 1 108 389
subtractValue 1 109 390
addValue 1 110 391
addValue 1 111 392
assign 1 112 393
assign 1 118 395
new 0 118 395
assign 1 118 396
lesser 1 118 401
assign 1 119 402
new 0 119 402
assign 1 120 405
new 0 120 405
assign 1 120 406
hexNew 1 120 406
assign 1 120 407
lesser 1 120 412
setIntUnchecked 2 121 413
assign 1 122 414
new 0 122 414
assign 1 123 417
new 0 123 417
assign 1 123 418
hexNew 1 123 418
assign 1 123 419
lesser 1 123 424
assign 1 124 425
new 0 124 425
assign 1 124 426
hexNew 1 124 426
assign 1 124 427
new 0 124 427
assign 1 124 428
hexNew 1 124 428
assign 1 124 429
and 1 124 429
assign 1 124 430
new 0 124 430
assign 1 124 431
shiftRight 1 124 431
assign 1 124 432
add 1 124 432
setIntUnchecked 2 124 433
assign 1 125 434
new 0 125 434
assign 1 125 435
add 1 125 435
assign 1 125 436
new 0 125 436
assign 1 125 437
hexNew 1 125 437
assign 1 125 438
new 0 125 438
assign 1 125 439
hexNew 1 125 439
assign 1 125 440
and 1 125 440
assign 1 125 441
add 1 125 441
setIntUnchecked 2 125 442
assign 1 126 443
new 0 126 443
assign 1 127 446
new 0 127 446
assign 1 127 447
hexNew 1 127 447
assign 1 127 448
lesser 1 127 453
assign 1 128 454
new 0 128 454
assign 1 128 455
hexNew 1 128 455
assign 1 128 456
new 0 128 456
assign 1 128 457
hexNew 1 128 457
assign 1 128 458
and 1 128 458
assign 1 128 459
new 0 128 459
assign 1 128 460
shiftRight 1 128 460
assign 1 128 461
add 1 128 461
setIntUnchecked 2 128 462
assign 1 129 463
new 0 129 463
assign 1 129 464
add 1 129 464
assign 1 129 465
new 0 129 465
assign 1 129 466
hexNew 1 129 466
assign 1 129 467
new 0 129 467
assign 1 129 468
hexNew 1 129 468
assign 1 129 469
and 1 129 469
assign 1 129 470
new 0 129 470
assign 1 129 471
shiftRight 1 129 471
assign 1 129 472
add 1 129 472
setIntUnchecked 2 129 473
assign 1 130 474
new 0 130 474
assign 1 130 475
add 1 130 475
assign 1 130 476
new 0 130 476
assign 1 130 477
hexNew 1 130 477
assign 1 130 478
new 0 130 478
assign 1 130 479
hexNew 1 130 479
assign 1 130 480
and 1 130 480
assign 1 130 481
add 1 130 481
setIntUnchecked 2 130 482
assign 1 131 483
new 0 131 483
assign 1 132 486
new 0 132 486
assign 1 132 487
hexNew 1 132 487
assign 1 132 488
lesserEquals 1 132 493
assign 1 133 494
new 0 133 494
assign 1 133 495
hexNew 1 133 495
assign 1 133 496
new 0 133 496
assign 1 133 497
hexNew 1 133 497
assign 1 133 498
and 1 133 498
assign 1 133 499
new 0 133 499
assign 1 133 500
shiftRight 1 133 500
assign 1 133 501
add 1 133 501
setIntUnchecked 2 133 502
assign 1 134 503
new 0 134 503
assign 1 134 504
add 1 134 504
assign 1 134 505
new 0 134 505
assign 1 134 506
hexNew 1 134 506
assign 1 134 507
new 0 134 507
assign 1 134 508
hexNew 1 134 508
assign 1 134 509
and 1 134 509
assign 1 134 510
new 0 134 510
assign 1 134 511
shiftRight 1 134 511
assign 1 134 512
add 1 134 512
setIntUnchecked 2 134 513
assign 1 135 514
new 0 135 514
assign 1 135 515
add 1 135 515
assign 1 135 516
new 0 135 516
assign 1 135 517
hexNew 1 135 517
assign 1 135 518
new 0 135 518
assign 1 135 519
hexNew 1 135 519
assign 1 135 520
and 1 135 520
assign 1 135 521
new 0 135 521
assign 1 135 522
shiftRight 1 135 522
assign 1 135 523
add 1 135 523
setIntUnchecked 2 135 524
assign 1 136 525
new 0 136 525
assign 1 136 526
add 1 136 526
assign 1 136 527
new 0 136 527
assign 1 136 528
hexNew 1 136 528
assign 1 136 529
new 0 136 529
assign 1 136 530
hexNew 1 136 530
assign 1 136 531
and 1 136 531
assign 1 136 532
add 1 136 532
setIntUnchecked 2 136 533
assign 1 137 534
new 0 137 534
assign 1 139 537
new 0 139 537
assign 1 142 543
new 0 142 543
assign 1 142 544
lesser 1 142 549
assign 1 143 550
new 0 143 550
assign 1 143 551
new 1 143 551
throw 1 143 552
assign 1 145 554
sizeGet 0 145 554
assign 1 145 555
add 1 145 555
sizeSet 1 145 556
assign 1 166 624
new 0 166 624
assign 1 167 625
new 0 167 625
assign 1 168 626
new 0 168 626
assign 1 170 627
new 0 170 627
assign 1 170 628
fromEscapesGet 0 170 628
assign 1 172 629
linkedListIteratorGet 0 172 629
assign 1 176 632
hasNextGet 0 176 632
assign 1 177 634
nextGet 0 177 634
assign 1 180 636
not 0 180 641
assign 1 180 642
equals 1 180 642
assign 1 0 644
assign 1 0 647
assign 1 0 651
assign 1 181 654
new 0 181 654
assign 1 182 655
extractString 0 182 655
handleString 1 182 656
assign 1 185 660
get 1 185 660
assign 1 186 661
def 1 186 666
addValue 1 187 667
assign 1 188 670
new 0 188 670
assign 1 188 671
begins 1 188 671
assign 1 189 673
jsonUcUnescape 1 189 673
assign 1 190 674
jsonUcGetAfterPart 1 190 674
assign 1 191 675
new 0 191 675
assign 1 192 676
def 1 192 681
assign 1 192 682
jsonUcIsPairEnd 1 192 682
assign 1 192 683
not 0 192 688
assign 1 0 689
assign 1 0 692
assign 1 0 696
assign 1 193 699
new 0 193 699
assign 1 193 700
new 1 193 700
throw 1 193 701
assign 1 194 704
undef 1 194 709
assign 1 195 710
jsonUcIsPairStart 1 195 710
assign 1 197 714
def 1 197 719
assign 1 0 720
assign 1 0 723
assign 1 0 727
assign 1 198 730
new 0 198 730
assign 1 198 731
new 1 198 731
throw 1 198 732
assign 1 201 735
jsonUcAppendValue 3 203 738
assign 1 204 739
assign 1 205 740
def 1 205 745
addValue 1 206 746
addValue 1 210 751
assign 1 212 754
new 0 212 754
assign 1 213 757
equals 1 213 757
assign 1 214 759
new 0 214 759
addValue 1 216 762
assign 1 221 768
equals 1 221 768
assign 1 0 770
assign 1 221 773
equals 1 221 773
assign 1 0 775
assign 1 0 778
assign 1 0 782
assign 1 221 785
equals 1 221 785
assign 1 0 787
assign 1 0 790
assign 1 0 794
assign 1 221 797
equals 1 221 797
assign 1 0 799
assign 1 0 802
assign 1 222 808
equals 1 222 808
assign 1 223 810
new 0 223 810
assign 1 224 813
equals 1 224 813
beginMap 0 225 815
assign 1 226 818
equals 1 226 818
endMap 0 227 820
assign 1 228 823
equals 1 228 823
kvMid 0 229 825
assign 1 230 828
equals 1 230 828
beginList 0 231 830
assign 1 232 833
equals 1 232 833
endList 0 233 835
assign 1 237 838
new 0 237 838
assign 1 237 839
equals 1 237 839
assign 1 0 841
assign 1 237 844
new 0 237 844
assign 1 237 845
equals 1 237 845
assign 1 0 847
assign 1 0 850
assign 1 0 854
assign 1 237 857
new 0 237 857
assign 1 237 858
equals 1 237 858
assign 1 0 860
assign 1 0 863
assign 1 0 867
assign 1 237 870
new 0 237 870
assign 1 237 871
equals 1 237 871
assign 1 0 873
assign 1 0 876
assign 1 240 882
new 0 240 882
assign 1 240 883
equals 1 240 883
handleTrue 0 241 885
assign 1 242 888
new 0 242 888
assign 1 242 889
equals 1 242 889
handleFalse 0 243 891
assign 1 244 894
new 0 244 894
assign 1 244 895
equals 1 244 895
handleNull 0 245 897
assign 1 248 900
new 1 248 900
handleInteger 1 248 901
return 1 0 922
return 1 0 925
assign 1 0 928
assign 1 0 932
return 1 0 936
return 1 0 939
assign 1 0 942
assign 1 0 946
return 1 0 950
return 1 0 953
assign 1 0 956
assign 1 0 960
return 1 0 964
return 1 0 967
assign 1 0 970
assign 1 0 974
return 1 0 978
return 1 0 981
assign 1 0 984
assign 1 0 988
return 1 0 992
return 1 0 995
assign 1 0 998
assign 1 0 1002
return 1 0 1006
return 1 0 1009
assign 1 0 1012
assign 1 0 1016
return 1 0 1020
return 1 0 1023
assign 1 0 1026
assign 1 0 1030
return 1 0 1034
return 1 0 1037
assign 1 0 1040
assign 1 0 1044
return 1 0 1048
return 1 0 1051
assign 1 0 1054
assign 1 0 1058
return 1 0 1062
return 1 0 1065
assign 1 0 1068
assign 1 0 1072
return 1 0 1076
return 1 0 1079
assign 1 0 1082
assign 1 0 1086
return 1 0 1090
return 1 0 1093
assign 1 0 1096
assign 1 0 1100
return 1 0 1104
return 1 0 1107
assign 1 0 1110
assign 1 0 1114
return 1 0 1118
return 1 0 1121
assign 1 0 1124
assign 1 0 1128
return 1 0 1132
return 1 0 1135
assign 1 0 1138
assign 1 0 1142
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1642361296: return bem_print_0();
case 62592414: return bem_hsubGet_0();
case -549708786: return bem_vsubGet_0();
case -1785724794: return bem_once_0();
case -71162589: return bem_iteratorGet_0();
case 962734775: return bem_hmAddGet_0();
case -435325417: return bem_lbraceGet_0();
case -1359614197: return bem_classNameGet_0();
case -1480556491: return bem_toAny_0();
case -588661420: return bem_escapeGetDirect_0();
case 1676516155: return bem_tokerGetDirect_0();
case -922687110: return bem_spaceGetDirect_0();
case 759496930: return bem_tagGet_0();
case -310256822: return bem_tokensGetDirect_0();
case 1365897346: return bem_serializationIteratorGet_0();
case 1968239733: return bem_lfGet_0();
case 2064925791: return bem_echo_0();
case -889558109: return bem_commaGet_0();
case -1451015185: return bem_colonGetDirect_0();
case -1555833296: return bem_sourceFileNameGet_0();
case 359870006: return bem_quoteGet_0();
case -1711670377: return bem_hashGet_0();
case 177115413: return bem_lfGetDirect_0();
case 2064404323: return bem_rbracketGet_0();
case 814334258: return bem_serializeContents_0();
case -1456424031: return bem_rbraceGet_0();
case 1031003208: return bem_crGet_0();
case 1422233702: return bem_rbraceGetDirect_0();
case -652053502: return bem_fieldNamesGet_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 1818830182: return bem_tokensGet_0();
case 1812529119: return bem_lbracketGetDirect_0();
case -1831695196: return bem_spaceGet_0();
case 944073339: return bem_fieldIteratorGet_0();
case 153252752: return bem_quoteGetDirect_0();
case -1044758745: return bem_serializeToString_0();
case -1864533002: return bem_rbracketGetDirect_0();
case 728311894: return bem_lbraceGetDirect_0();
case 2132420479: return bem_many_0();
case 70947723: return bem_hmAddGetDirect_0();
case 1850260854: return bem_crGetDirect_0();
case -1709651283: return bem_vsubGetDirect_0();
case 168135582: return bem_create_0();
case 846879338: return bem_lbracketGet_0();
case 1255895747: return bem_colonGet_0();
case 958578863: return bem_tokerGet_0();
case -752740507: return bem_commaGetDirect_0();
case -1132354331: return bem_escapeGet_0();
case -202912463: return bem_copy_0();
case 350691792: return bem_toString_0();
case 1110776361: return bem_hsubGetDirect_0();
case 1161638424: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1409860153: return bem_jsonUcUnescape_1((BEC_2_4_6_TextString) bevd_0);
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case 330533622: return bem_commaSetDirect_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case 1609984587: return bem_vsubSet_1(bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -91101621: return bem_tokensSet_1(bevd_0);
case 781696203: return bem_hsubSet_1(bevd_0);
case -1442577646: return bem_quoteSet_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case 778770870: return bem_rbracketSet_1(bevd_0);
case -1468096957: return bem_rbracketSetDirect_1(bevd_0);
case -125287085: return bem_colonSet_1(bevd_0);
case -897516582: return bem_jsonUcGetAfterPart_1((BEC_2_4_6_TextString) bevd_0);
case 1817192270: return bem_hsubSetDirect_1(bevd_0);
case 179083653: return bem_hmAddSetDirect_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case 1466936481: return bem_lbraceSet_1(bevd_0);
case 144112319: return bem_spaceSetDirect_1(bevd_0);
case -1375488730: return bem_jsonUcIsPairStart_1((BEC_2_4_3_MathInt) bevd_0);
case -2084148663: return bem_quoteSetDirect_1(bevd_0);
case 930982779: return bem_commaSet_1(bevd_0);
case -718497067: return bem_colonSetDirect_1(bevd_0);
case -739598452: return bem_vsubSetDirect_1(bevd_0);
case 1712594251: return bem_hmAddSet_1(bevd_0);
case 1891086426: return bem_spaceSet_1(bevd_0);
case 280639608: return bem_lbraceSetDirect_1(bevd_0);
case -493651582: return bem_crSetDirect_1(bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case 1533519592: return bem_tokerSetDirect_1(bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1152831772: return bem_jsonUcIsPairEnd_1((BEC_2_4_3_MathInt) bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case 419088441: return bem_lfSetDirect_1(bevd_0);
case 1598820365: return bem_tokerSet_1(bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case 1428774891: return bem_rbraceSet_1(bevd_0);
case -411667107: return bem_lbracketSet_1(bevd_0);
case 1958583822: return bem_lbracketSetDirect_1(bevd_0);
case -1197590402: return bem_escapeSet_1(bevd_0);
case -264392908: return bem_tokensSetDirect_1(bevd_0);
case -1946184216: return bem_crSet_1(bevd_0);
case -1488365553: return bem_rbraceSetDirect_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 289828734: return bem_lfSet_1(bevd_0);
case -2123379191: return bem_escapeSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -468785496: return bem_parse_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2021430540: return bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevd_0, bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1196984768: return bem_jsonUcAppendValue_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_JsonParser_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_6_JsonParser_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_JsonParser();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_inst = (BEC_2_4_6_JsonParser) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_type;
}
}
}
