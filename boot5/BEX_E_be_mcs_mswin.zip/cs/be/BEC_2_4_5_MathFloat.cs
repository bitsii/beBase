namespace be {
/* IO:File: source/base/Float.be */
public sealed class BEC_2_4_5_MathFloat : BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }
static BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_BEC_2_4_5_MathFloat_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_BEC_2_4_5_MathFloat_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_0 = {0x2D};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_1 = {0x2E};
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_3 = (new BEC_2_4_3_MathInt(10));
private static byte[] bece_BEC_2_4_5_MathFloat_bels_2 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_4_5_MathFloat_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_4_5_MathFloat_bels_2, 1));
public static new BEC_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_inst;

public static new BET_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_type;

public BEC_2_4_5_MathFloat bem_vfloatGet_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_vfloatSet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_21_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_22_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_0));
bevt_0_tmpany_phold = beva_si.bemd_1(339616485, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 57 */ {
bevl_neg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(-2030666102, bevt_2_tmpany_phold);
} /* Line: 59 */
 else  /* Line: 60 */ {
bevl_neg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 61 */
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(1878126802, bevt_3_tmpany_phold);
if (bevl_dec == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 64 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_0;
if (bevl_dec.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 65 */ {
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_7_tmpany_phold = beva_si.bemd_2(1954334236, bevt_8_tmpany_phold, bevl_dec);
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_tmpany_phold);
} /* Line: 66 */
 else  /* Line: 67 */ {
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 68 */
bevt_11_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_1;
bevt_10_tmpany_phold = bevl_dec.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = beva_si.bemd_0(-613998555);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_tmpany_phold );
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 70 */ {
bevt_15_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_2;
bevt_14_tmpany_phold = bevl_dec.bem_add_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = beva_si.bemd_1(-2030666102, bevt_14_tmpany_phold);
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_tmpany_phold);
} /* Line: 71 */
 else  /* Line: 72 */ {
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 73 */
} /* Line: 70 */
 else  /* Line: 75 */ {
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 77 */
bevt_16_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_3;
bevt_18_tmpany_phold = bevl_rhs.bem_toString_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_sizeGet_0();
bevl_divby = bevt_16_tmpany_phold.bem_power_1(bevt_17_tmpany_phold);
if (bevl_neg.bevi_bool) /* Line: 80 */ {
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_tmpany_phold);
} /* Line: 82 */
bevt_21_tmpany_phold = bevl_rhs.bem_toFloat_0();
bevt_22_tmpany_phold = bevl_divby.bem_toFloat_0();
bevl_rhsf = bevt_21_tmpany_phold.bem_divide_1(bevt_22_tmpany_phold);
bevl_lhsf = bevl_lhs.bem_toFloat_0();
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return bevl_ii;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toInt_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_lhi = bem_toInt_0();
bevt_0_tmpany_phold = bevl_lhi.bem_toFloat_0();
bevl_rh = bem_subtract_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_tmpany_phold);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_tmpany_phold = bevl_lhi.bem_toString_0();
bevt_5_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_4;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bevl_rhi.bem_toString_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_5_MathFloat bem_increment_0() {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 137 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 144 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrement_0() {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 152 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 159 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 167 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 174 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 182 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 189 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 197 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 204 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 212 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 219 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_5_MathFloat;
      if (this.bevi_float == bevls_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_5_MathFloat;
      if (this.bevi_float != bevls_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {57, 57, 58, 59, 59, 61, 63, 63, 64, 64, 65, 65, 65, 66, 66, 66, 68, 70, 70, 70, 70, 71, 71, 71, 71, 73, 76, 77, 79, 79, 79, 79, 81, 81, 82, 82, 84, 84, 84, 85, 86, 87, 90, 90, 93, 93, 97, 101, 101, 112, 120, 125, 125, 129, 130, 130, 131, 131, 132, 133, 133, 133, 133, 133, 133, 138, 144, 153, 159, 168, 174, 183, 189, 198, 204, 213, 219, 227, 227, 256, 256, 285, 285, 306, 306, 327, 327, 348, 348, 369, 369};
public static new int[] bevs_smnlec
 = new int[] {66, 67, 69, 70, 71, 74, 76, 77, 78, 83, 84, 85, 90, 91, 92, 93, 96, 98, 99, 100, 101, 103, 104, 105, 106, 109, 113, 114, 116, 117, 118, 119, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 135, 136, 140, 141, 144, 149, 150, 154, 155, 159, 160, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 190, 193, 200, 203, 210, 213, 220, 223, 230, 233, 240, 243, 248, 249, 259, 260, 270, 271, 280, 281, 290, 291, 300, 301, 310, 311};
/* BEGIN LINEINFO 
assign 1 57 66
new 0 57 66
assign 1 57 67
begins 1 57 67
assign 1 58 69
new 0 58 69
assign 1 59 70
new 0 59 70
assign 1 59 71
substring 1 59 71
assign 1 61 74
new 0 61 74
assign 1 63 76
new 0 63 76
assign 1 63 77
find 1 63 77
assign 1 64 78
def 1 64 83
assign 1 65 84
new 0 65 84
assign 1 65 85
greater 1 65 90
assign 1 66 91
new 0 66 91
assign 1 66 92
substring 2 66 92
assign 1 66 93
new 1 66 93
assign 1 68 96
new 0 68 96
assign 1 70 98
new 0 70 98
assign 1 70 99
add 1 70 99
assign 1 70 100
sizeGet 0 70 100
assign 1 70 101
lesser 1 70 101
assign 1 71 103
new 0 71 103
assign 1 71 104
add 1 71 104
assign 1 71 105
substring 1 71 105
assign 1 71 106
new 1 71 106
assign 1 73 109
new 0 73 109
assign 1 76 113
new 1 76 113
assign 1 77 114
new 0 77 114
assign 1 79 116
new 0 79 116
assign 1 79 117
toString 0 79 117
assign 1 79 118
sizeGet 0 79 118
assign 1 79 119
power 1 79 119
assign 1 81 121
new 0 81 121
multiplyValue 1 81 122
assign 1 82 123
new 0 82 123
multiplyValue 1 82 124
assign 1 84 126
toFloat 0 84 126
assign 1 84 127
toFloat 0 84 127
assign 1 84 128
divide 1 84 128
assign 1 85 129
toFloat 0 85 129
assign 1 86 130
add 1 86 130
return 1 87 131
assign 1 90 135
new 0 90 135
return 1 90 136
assign 1 93 140
toString 0 93 140
return 1 93 141
new 1 97 144
assign 1 101 149
new 0 101 149
return 1 101 150
assign 1 112 154
new 0 112 154
return 1 120 155
assign 1 125 159
toInt 0 125 159
return 1 125 160
assign 1 129 173
toInt 0 129 173
assign 1 130 174
toFloat 0 130 174
assign 1 130 175
subtract 1 130 175
assign 1 131 176
new 0 131 176
assign 1 131 177
multiply 1 131 177
assign 1 132 178
toInt 0 132 178
assign 1 133 179
toString 0 133 179
assign 1 133 180
new 0 133 180
assign 1 133 181
add 1 133 181
assign 1 133 182
toString 0 133 182
assign 1 133 183
add 1 133 183
return 1 133 184
assign 1 138 190
new 0 138 190
return 1 144 193
assign 1 153 200
new 0 153 200
return 1 159 203
assign 1 168 210
new 0 168 210
return 1 174 213
assign 1 183 220
new 0 183 220
return 1 189 223
assign 1 198 230
new 0 198 230
return 1 204 233
assign 1 213 240
new 0 213 240
return 1 219 243
assign 1 227 248
new 0 227 248
return 1 227 249
assign 1 256 259
new 0 256 259
return 1 256 260
assign 1 285 270
new 0 285 270
return 1 285 271
assign 1 306 280
new 0 306 280
return 1 306 281
assign 1 327 290
new 0 327 290
return 1 327 291
assign 1 348 300
new 0 348 300
return 1 348 301
assign 1 369 310
new 0 369 310
return 1 369 311
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1700654661: return bem_vfloatGet_0();
case -1230030647: return bem_iteratorGet_0();
case -1380773853: return bem_print_0();
case 93173827: return bem_decrement_0();
case -1546212617: return bem_hashGet_0();
case -1605941642: return bem_increment_0();
case -1812592029: return bem_copy_0();
case 1681509073: return bem_vfloatSet_0();
case 1765847529: return bem_toAny_0();
case 111705563: return bem_new_0();
case 1814659174: return bem_echo_0();
case -140254392: return bem_classNameGet_0();
case 1138959219: return bem_create_0();
case 1136611843: return bem_many_0();
case -1346342591: return bem_tagGet_0();
case -154821822: return bem_serializationIteratorGet_0();
case 2031852918: return bem_deserializeClassNameGet_0();
case -108571624: return bem_serializeContents_0();
case -110239012: return bem_sourceFileNameGet_0();
case -90627019: return bem_toString_0();
case 1843946637: return bem_fieldIteratorGet_0();
case -372592920: return bem_toInt_0();
case -375963306: return bem_serializeToString_0();
case 1826454756: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1198247472: return bem_undef_1(bevd_0);
case 2033783017: return bem_sameType_1(bevd_0);
case 110109961: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -2018573962: return bem_defined_1(bevd_0);
case -374200378: return bem_new_1(bevd_0);
case -1745069966: return bem_def_1(bevd_0);
case 1526501544: return bem_copyTo_1(bevd_0);
case 1340954430: return bem_undefined_1(bevd_0);
case 1217812080: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case -231386564: return bem_sameClass_1(bevd_0);
case -1676991132: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case -1352048316: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1769368933: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case 748668477: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1074676880: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
case -2050905939: return bem_notEquals_1(bevd_0);
case -898454377: return bem_equals_1(bevd_0);
case -1554557365: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
case 1877964318: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case 1955134607: return bem_otherClass_1(bevd_0);
case -1079763086: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
case 1430436577: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case -1157481258: return bem_sameObject_1(bevd_0);
case 452045758: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -166605595: return bem_otherType_1(bevd_0);
case -604934649: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1477024989: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1086183440: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -13817058: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1749882081: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -826896459: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 416141599: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 647643475: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_MathFloat_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_4_5_MathFloat_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_5_MathFloat();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst = (BEC_2_4_5_MathFloat) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_type;
}
}
}
