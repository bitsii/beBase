namespace be {
/* IO:File: source/base/Float.be */
public sealed class BEC_2_4_5_MathFloat : BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }
static BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_BEC_2_4_5_MathFloat_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_BEC_2_4_5_MathFloat_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_0 = {0x2D};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_1 = {0x2E};
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_3 = (new BEC_2_4_3_MathInt(10));
private static byte[] bece_BEC_2_4_5_MathFloat_bels_2 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_4_5_MathFloat_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_4_5_MathFloat_bels_2, 1));
public static new BEC_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_inst;

public static new BET_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_type;

public BEC_2_4_5_MathFloat bem_vfloatGet_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_vfloatSet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_21_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_22_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_0));
bevt_0_tmpany_phold = beva_si.bemd_1(1710434457, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 65 */ {
bevl_neg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(1544891482, bevt_2_tmpany_phold);
} /* Line: 67 */
 else  /* Line: 68 */ {
bevl_neg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 69 */
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(238559893, bevt_3_tmpany_phold);
if (bevl_dec == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_0;
if (bevl_dec.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_7_tmpany_phold = beva_si.bemd_2(-1269106748, bevt_8_tmpany_phold, bevl_dec);
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_tmpany_phold);
} /* Line: 74 */
 else  /* Line: 75 */ {
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 76 */
bevt_11_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_1;
bevt_10_tmpany_phold = bevl_dec.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = beva_si.bemd_0(1165362622);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_tmpany_phold );
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 78 */ {
bevt_15_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_2;
bevt_14_tmpany_phold = bevl_dec.bem_add_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = beva_si.bemd_1(1544891482, bevt_14_tmpany_phold);
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_tmpany_phold);
} /* Line: 79 */
 else  /* Line: 80 */ {
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 81 */
} /* Line: 78 */
 else  /* Line: 83 */ {
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 85 */
bevt_16_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_3;
bevt_18_tmpany_phold = bevl_rhs.bem_toString_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_sizeGet_0();
bevl_divby = bevt_16_tmpany_phold.bem_power_1(bevt_17_tmpany_phold);
if (bevl_neg.bevi_bool) /* Line: 88 */ {
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_tmpany_phold);
} /* Line: 90 */
bevt_21_tmpany_phold = bevl_rhs.bem_toFloat_0();
bevt_22_tmpany_phold = bevl_divby.bem_toFloat_0();
bevl_rhsf = bevt_21_tmpany_phold.bem_divide_1(bevt_22_tmpany_phold);
bevl_lhsf = bevl_lhs.bem_toFloat_0();
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return bevl_ii;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toInt_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_lhi = bem_toInt_0();
bevt_0_tmpany_phold = bevl_lhi.bem_toFloat_0();
bevl_rh = bem_subtract_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_tmpany_phold);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_tmpany_phold = bevl_lhi.bem_toString_0();
bevt_5_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_4;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bevl_rhi.bem_toString_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_5_MathFloat bem_increment_0() {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 145 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 157 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrement_0() {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 165 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 177 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 185 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 197 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 205 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 217 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 225 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 237 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 245 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 257 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_5_MathFloat;
      if (this.bevi_float == bevls_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_5_MathFloat;
      if (this.bevi_float != bevls_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {65, 65, 66, 67, 67, 69, 71, 71, 72, 72, 73, 73, 73, 74, 74, 74, 76, 78, 78, 78, 78, 79, 79, 79, 79, 81, 84, 85, 87, 87, 87, 87, 89, 89, 90, 90, 92, 92, 92, 93, 94, 95, 98, 98, 101, 101, 105, 109, 109, 120, 128, 133, 133, 137, 138, 138, 139, 139, 140, 141, 141, 141, 141, 141, 141, 146, 157, 166, 177, 186, 197, 206, 217, 226, 237, 246, 257, 265, 265, 302, 302, 339, 339, 367, 367, 395, 395, 423, 423, 451, 451};
public static new int[] bevs_smnlec
 = new int[] {66, 67, 69, 70, 71, 74, 76, 77, 78, 83, 84, 85, 90, 91, 92, 93, 96, 98, 99, 100, 101, 103, 104, 105, 106, 109, 113, 114, 116, 117, 118, 119, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 135, 136, 140, 141, 144, 149, 150, 154, 155, 159, 160, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 190, 193, 200, 203, 210, 213, 220, 223, 230, 233, 240, 243, 248, 249, 259, 260, 270, 271, 280, 281, 290, 291, 300, 301, 310, 311};
/* BEGIN LINEINFO 
assign 1 65 66
new 0 65 66
assign 1 65 67
begins 1 65 67
assign 1 66 69
new 0 66 69
assign 1 67 70
new 0 67 70
assign 1 67 71
substring 1 67 71
assign 1 69 74
new 0 69 74
assign 1 71 76
new 0 71 76
assign 1 71 77
find 1 71 77
assign 1 72 78
def 1 72 83
assign 1 73 84
new 0 73 84
assign 1 73 85
greater 1 73 90
assign 1 74 91
new 0 74 91
assign 1 74 92
substring 2 74 92
assign 1 74 93
new 1 74 93
assign 1 76 96
new 0 76 96
assign 1 78 98
new 0 78 98
assign 1 78 99
add 1 78 99
assign 1 78 100
sizeGet 0 78 100
assign 1 78 101
lesser 1 78 101
assign 1 79 103
new 0 79 103
assign 1 79 104
add 1 79 104
assign 1 79 105
substring 1 79 105
assign 1 79 106
new 1 79 106
assign 1 81 109
new 0 81 109
assign 1 84 113
new 1 84 113
assign 1 85 114
new 0 85 114
assign 1 87 116
new 0 87 116
assign 1 87 117
toString 0 87 117
assign 1 87 118
sizeGet 0 87 118
assign 1 87 119
power 1 87 119
assign 1 89 121
new 0 89 121
multiplyValue 1 89 122
assign 1 90 123
new 0 90 123
multiplyValue 1 90 124
assign 1 92 126
toFloat 0 92 126
assign 1 92 127
toFloat 0 92 127
assign 1 92 128
divide 1 92 128
assign 1 93 129
toFloat 0 93 129
assign 1 94 130
add 1 94 130
return 1 95 131
assign 1 98 135
new 0 98 135
return 1 98 136
assign 1 101 140
toString 0 101 140
return 1 101 141
new 1 105 144
assign 1 109 149
new 0 109 149
return 1 109 150
assign 1 120 154
new 0 120 154
return 1 128 155
assign 1 133 159
toInt 0 133 159
return 1 133 160
assign 1 137 173
toInt 0 137 173
assign 1 138 174
toFloat 0 138 174
assign 1 138 175
subtract 1 138 175
assign 1 139 176
new 0 139 176
assign 1 139 177
multiply 1 139 177
assign 1 140 178
toInt 0 140 178
assign 1 141 179
toString 0 141 179
assign 1 141 180
new 0 141 180
assign 1 141 181
add 1 141 181
assign 1 141 182
toString 0 141 182
assign 1 141 183
add 1 141 183
return 1 141 184
assign 1 146 190
new 0 146 190
return 1 157 193
assign 1 166 200
new 0 166 200
return 1 177 203
assign 1 186 210
new 0 186 210
return 1 197 213
assign 1 206 220
new 0 206 220
return 1 217 223
assign 1 226 230
new 0 226 230
return 1 237 233
assign 1 246 240
new 0 246 240
return 1 257 243
assign 1 265 248
new 0 265 248
return 1 265 249
assign 1 302 259
new 0 302 259
return 1 302 260
assign 1 339 270
new 0 339 270
return 1 339 271
assign 1 367 280
new 0 367 280
return 1 367 281
assign 1 395 290
new 0 395 290
return 1 395 291
assign 1 423 300
new 0 423 300
return 1 423 301
assign 1 451 310
new 0 451 310
return 1 451 311
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2143950884: return bem_vfloatSet_0();
case -144129925: return bem_serializationIteratorGet_0();
case -1541048309: return bem_create_0();
case -160406851: return bem_new_0();
case 1985057509: return bem_fieldIteratorGet_0();
case 201818212: return bem_tagGet_0();
case -1989311424: return bem_iteratorGet_0();
case -1335607781: return bem_sourceFileNameGet_0();
case 25334918: return bem_toInt_0();
case -654301706: return bem_vfloatGet_0();
case 450989839: return bem_toString_0();
case -259094594: return bem_echo_0();
case -1699769120: return bem_decrement_0();
case 64036809: return bem_serializeToString_0();
case 2077438310: return bem_fieldNamesGet_0();
case 137938641: return bem_copy_0();
case -1307912568: return bem_classNameGet_0();
case -2081710564: return bem_increment_0();
case -1005843071: return bem_serializeContents_0();
case -1192359710: return bem_toAny_0();
case -1128253997: return bem_print_0();
case 681415323: return bem_hashGet_0();
case 1562408751: return bem_once_0();
case 1875317286: return bem_many_0();
case 272950674: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1113733988: return bem_copyTo_1(bevd_0);
case -658977126: return bem_new_1(bevd_0);
case 1151483997: return bem_undef_1(bevd_0);
case 1986510594: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case -1769267387: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 959879294: return bem_notEquals_1(bevd_0);
case 87713512: return bem_otherType_1(bevd_0);
case 1742674668: return bem_equals_1(bevd_0);
case 1558030196: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case 1917243902: return bem_sameObject_1(bevd_0);
case 1496797900: return bem_undefined_1(bevd_0);
case 1237479699: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case 1634136691: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 371940317: return bem_otherClass_1(bevd_0);
case -1943396073: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1139812471: return bem_defined_1(bevd_0);
case 1645054849: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 922269216: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case -867513153: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -1500253371: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
case -742844212: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case -2045198723: return bem_sameType_1(bevd_0);
case 294100036: return bem_def_1(bevd_0);
case 1349958545: return bem_sameClass_1(bevd_0);
case 818409767: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
case 1864118928: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -285325789: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1136827327: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 517362903: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -491501198: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -534690974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -496063349: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1244895026: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_MathFloat_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_4_5_MathFloat_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_5_MathFloat();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst = (BEC_2_4_5_MathFloat) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_type;
}
}
}
