namespace be {
public class BET_2_5_9_BuildConstants : BETS_Object {
public BET_2_5_9_BuildConstants() {
string[] bevs_mtnames = new string[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "new_1", "prepare_0", "twtokGet_0", "twtokGetDirect_0", "twtokSet_1", "twtokSetDirect_1", "matchMapGet_0", "matchMapGetDirect_0", "matchMapSet_1", "matchMapSetDirect_1", "rwordsGet_0", "rwordsGetDirect_0", "rwordsSet_1", "rwordsSetDirect_1", "maxargsGet_0", "maxargsGetDirect_0", "maxargsSet_1", "maxargsSetDirect_1", "extraSlotsGet_0", "extraSlotsGetDirect_0", "extraSlotsSet_1", "extraSlotsSetDirect_1", "mtdxPadGet_0", "mtdxPadGetDirect_0", "mtdxPadSet_1", "mtdxPadSetDirect_1", "ntypesGet_0", "ntypesGetDirect_0", "ntypesSet_1", "ntypesSetDirect_1", "unwindToGet_0", "unwindToGetDirect_0", "unwindToSet_1", "unwindToSetDirect_1", "unwindOkGet_0", "unwindOkGetDirect_0", "unwindOkSet_1", "unwindOkSetDirect_1", "operGet_0", "operGetDirect_0", "operSet_1", "operSetDirect_1", "operNamesGet_0", "operNamesGetDirect_0", "operNamesSet_1", "operNamesSetDirect_1", "conTypesGet_0", "conTypesGetDirect_0", "conTypesSet_1", "conTypesSetDirect_1", "parensReqGet_0", "parensReqGetDirect_0", "parensReqSet_1", "parensReqSetDirect_1", "anchorTypesGet_0", "anchorTypesGetDirect_0", "anchorTypesSet_1", "anchorTypesSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new string[] { "twtok", "matchMap", "rwords", "maxargs", "extraSlots", "mtdxPad", "ntypes", "unwindTo", "unwindOk", "oper", "operNames", "conTypes", "parensReq", "anchorTypes" };
}
static BET_2_5_9_BuildConstants() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_9_BuildConstants();
}
}
}
