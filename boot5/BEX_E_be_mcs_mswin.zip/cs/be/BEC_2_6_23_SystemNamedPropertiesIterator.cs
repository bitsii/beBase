namespace be {
/* IO:File: source/extended/Serialize.be */
public sealed class BEC_2_6_23_SystemNamedPropertiesIterator : BEC_2_6_6_SystemObject {
public BEC_2_6_23_SystemNamedPropertiesIterator() { }
static BEC_2_6_23_SystemNamedPropertiesIterator() { }
private static byte[] becc_BEC_2_6_23_SystemNamedPropertiesIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x69,0x65,0x73,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_23_SystemNamedPropertiesIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_0 = {0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_1 = {0x53,0x65,0x74};
public static new BEC_2_6_23_SystemNamedPropertiesIterator bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst;

public static new BET_2_6_23_SystemNamedPropertiesIterator bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_propNames;
public BEC_3_9_4_8_ContainerListIterator bevp_subIter;
public BEC_2_6_6_SystemObject bevp_inst;
public BEC_2_9_4_ContainerList bevp_setArgs;
public BEC_2_9_4_ContainerList bevp_getArgs;
public BEC_2_6_23_SystemNamedPropertiesIterator bem_new_2(BEC_2_6_6_SystemObject beva__inst, BEC_2_9_4_ContainerList beva__propNames) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevp_propNames = beva__propNames;
bevp_inst = beva__inst;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_setArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_getArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_subIterGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_subIter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 445*/ {
bevp_subIter = bevp_propNames.bem_arrayIteratorGet_0();
} /* Line: 446*/
return bevp_subIter;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_subIterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_hasNextGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_1_ta_ph = bem_subIterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_nextGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_0));
bevl_name = (BEC_2_4_6_TextString) bevt_0_ta_ph.bemd_1(1688096367, bevt_2_ta_ph);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = bevp_inst.bemd_2(1182713671, bevl_name, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 457*/ {
bevt_5_ta_ph = bevp_inst.bemd_2(-1618012778, bevl_name, bevp_getArgs);
return bevt_5_ta_ph;
} /* Line: 458*/
return null;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevt_1_ta_ph = bem_subIterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_nextGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_1));
bevl_name = (BEC_2_4_6_TextString) bevt_0_ta_ph.bemd_1(1688096367, bevt_2_ta_ph);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_3_ta_ph = bevp_inst.bemd_2(1182713671, bevl_name, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 465*/ {
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_setArgs.bem_put_2(bevt_5_ta_ph, beva_value);
bevp_inst.bemd_2(-1618012778, bevl_name, bevp_setArgs);
} /* Line: 467*/
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 472*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 472*/ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 472*/
 else /* Line: 472*/ {
break;
} /* Line: 472*/
} /* Line: 472*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_propNamesGet_0() {
return bevp_propNames;
} /*method end*/
public BEC_2_9_4_ContainerList bem_propNamesGetDirect_0() {
return bevp_propNames;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_propNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_propNames = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_propNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_propNames = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_subIterGetDirect_0() {
return bevp_subIter;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_subIterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_subIter = (BEC_3_9_4_8_ContainerListIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_subIterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_subIter = (BEC_3_9_4_8_ContainerListIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instGet_0() {
return bevp_inst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instGetDirect_0() {
return bevp_inst;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_instSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inst = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_instSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inst = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_setArgsGet_0() {
return bevp_setArgs;
} /*method end*/
public BEC_2_9_4_ContainerList bem_setArgsGetDirect_0() {
return bevp_setArgs;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_setArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_setArgs = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_setArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_setArgs = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_getArgsGet_0() {
return bevp_getArgs;
} /*method end*/
public BEC_2_9_4_ContainerList bem_getArgsGetDirect_0() {
return bevp_getArgs;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_getArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_getArgs = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_getArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_getArgs = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {436, 438, 439, 439, 440, 440, 445, 445, 446, 448, 452, 452, 452, 456, 456, 456, 456, 457, 457, 458, 458, 460, 464, 464, 464, 464, 465, 465, 466, 466, 467, 472, 472, 472, 473, 472, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 24, 25, 26, 27, 32, 37, 38, 40, 45, 46, 47, 57, 58, 59, 60, 61, 62, 64, 65, 67, 77, 78, 79, 80, 81, 82, 84, 85, 86, 93, 96, 101, 102, 103, 112, 115, 118, 122, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175};
/* BEGIN LINEINFO 
assign 1 436 22
assign 1 438 23
assign 1 439 24
new 0 439 24
assign 1 439 25
new 1 439 25
assign 1 440 26
new 0 440 26
assign 1 440 27
new 1 440 27
assign 1 445 32
undef 1 445 37
assign 1 446 38
arrayIteratorGet 0 446 38
return 1 448 40
assign 1 452 45
subIterGet 0 452 45
assign 1 452 46
hasNextGet 0 452 46
return 1 452 47
assign 1 456 57
subIterGet 0 456 57
assign 1 456 58
nextGet 0 456 58
assign 1 456 59
new 0 456 59
assign 1 456 60
add 1 456 60
assign 1 457 61
new 0 457 61
assign 1 457 62
can 2 457 62
assign 1 458 64
invoke 2 458 64
return 1 458 65
return 1 460 67
assign 1 464 77
subIterGet 0 464 77
assign 1 464 78
nextGet 0 464 78
assign 1 464 79
new 0 464 79
assign 1 464 80
add 1 464 80
assign 1 465 81
new 0 465 81
assign 1 465 82
can 2 465 82
assign 1 466 84
new 0 466 84
put 2 466 85
invoke 2 467 86
assign 1 472 93
new 0 472 93
assign 1 472 96
lesser 1 472 101
nextSet 1 473 102
assign 1 472 103
increment 0 472 103
return 1 0 112
return 1 0 115
assign 1 0 118
assign 1 0 122
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1913020036: return bem_propNamesGetDirect_0();
case -652053502: return bem_fieldNamesGet_0();
case 944073339: return bem_fieldIteratorGet_0();
case -1785724794: return bem_once_0();
case -1480556491: return bem_toAny_0();
case 168135582: return bem_create_0();
case -1381942796: return bem_subIterGetDirect_0();
case 694560707: return bem_getArgsGet_0();
case 2132420479: return bem_many_0();
case 1610238730: return bem_hasNextGet_0();
case -1359614197: return bem_classNameGet_0();
case -1044758745: return bem_serializeToString_0();
case 261615513: return bem_setArgsGetDirect_0();
case 759496930: return bem_tagGet_0();
case -641452021: return bem_nextGet_0();
case 350691792: return bem_toString_0();
case 814334258: return bem_serializeContents_0();
case 1354947813: return bem_propNamesGet_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -420606097: return bem_setArgsGet_0();
case -1642361296: return bem_print_0();
case -202912463: return bem_copy_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 556773414: return bem_instGetDirect_0();
case -211163320: return bem_instGet_0();
case 1365897346: return bem_serializationIteratorGet_0();
case 1161638424: return bem_new_0();
case -71162589: return bem_iteratorGet_0();
case -1022940326: return bem_getArgsGetDirect_0();
case -1711670377: return bem_hashGet_0();
case 2064925791: return bem_echo_0();
case -770605131: return bem_subIterGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case -1176709013: return bem_getArgsSet_1(bevd_0);
case 555556563: return bem_propNamesSetDirect_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case 373311807: return bem_setArgsSet_1(bevd_0);
case 74148593: return bem_propNamesSet_1(bevd_0);
case -481584781: return bem_subIterSet_1(bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case 676822489: return bem_setArgsSetDirect_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case 1131827663: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case 661358149: return bem_getArgsSetDirect_1(bevd_0);
case 1146557104: return bem_subIterSetDirect_1(bevd_0);
case 1107661164: return bem_instSet_1(bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case -1535331289: return bem_nextSet_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -477336333: return bem_instSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1259587878: return bem_new_2(bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(30, becc_BEC_2_6_23_SystemNamedPropertiesIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_23_SystemNamedPropertiesIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_23_SystemNamedPropertiesIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst = (BEC_2_6_23_SystemNamedPropertiesIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_type;
}
}
}
