namespace be {
/* IO:File: source/extended/FilePath.be */
public class BEC_3_2_4_4_IOFilePath : BEC_2_6_8_SystemBasePath {
public BEC_3_2_4_4_IOFilePath() { }
static BEC_3_2_4_4_IOFilePath() { }
private static byte[] becc_BEC_3_2_4_4_IOFilePath_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_3_2_4_4_IOFilePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x50,0x61,0x74,0x68,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_2_4_4_IOFilePath_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_2_4_4_IOFilePath_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_2_4_4_IOFilePath_bels_0 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_3_2_4_4_IOFilePath_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_4_IOFilePath_bels_0, 1));
private static BEC_2_4_3_MathInt bece_BEC_3_2_4_4_IOFilePath_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_3_2_4_4_IOFilePath_bevo_4 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_3_2_4_4_IOFilePath_bevo_5 = (new BEC_2_4_3_MathInt(2));
public static new BEC_3_2_4_4_IOFilePath bece_BEC_3_2_4_4_IOFilePath_bevs_inst;

public static new BET_3_2_4_4_IOFilePath bece_BEC_3_2_4_4_IOFilePath_bevs_type;

public BEC_2_2_4_IOFile bevp_file;
public BEC_2_4_6_TextString bevp_driveLetter;
public override BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevp_separator = bevt_0_tmpany_phold.bem_separatorGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_apNew_1(BEC_2_4_6_TextString beva_spath) {
BEC_2_6_8_SystemPlatform bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = beva_spath.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_0;
if (bevt_2_tmpany_phold.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_6_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_1;
bevt_5_tmpany_phold = beva_spath.bem_getPoint_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_2;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevt_8_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_3;
bevt_9_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_4;
bevp_driveLetter = beva_spath.bem_substring_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_3_2_4_4_IOFilePath_bevo_5;
bevt_11_tmpany_phold = beva_spath.bem_sizeGet_0();
beva_spath = beva_spath.bem_substring_2(bevt_10_tmpany_phold, bevt_11_tmpany_phold);
} /* Line: 26 */
bevt_12_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl_p = bevt_12_tmpany_phold.bem_platformGet_0();
bevt_13_tmpany_phold = bevl_p.bem_otherSeparatorGet_0();
bevt_14_tmpany_phold = bevl_p.bem_separatorGet_0();
beva_spath = (BEC_2_4_6_TextString) beva_spath.bem_swap_2(bevt_13_tmpany_phold, bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bem_new_1(beva_spath);
return (BEC_3_2_4_4_IOFilePath) bevt_15_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = base.bem_isAbsoluteGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
bem_apNew_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_fileGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_file == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevp_file = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_0();
bevp_file.bem_pathSet_1(this);
} /* Line: 57 */
return bevp_file;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_3_2_4_4_IOFilePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_3_2_4_4_IOFilePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_other.bem_fileSet_1(null);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_driveLetter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 71 */ {
bevt_1_tmpany_phold = bevp_driveLetter.bem_add_1(bevp_path);
return bevt_1_tmpany_phold;
} /* Line: 72 */
return bevp_path;
} /*method end*/
public override BEC_2_6_8_SystemBasePath bem_parentGet_0() {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = base.bem_parentGet_0();
return (BEC_2_6_8_SystemBasePath) bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevp_driveLetter = null;
base.bem_makeNonAbsolute_0();
} /* Line: 84 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_matchesGlob_1(BEC_2_4_6_TextString beva_glob) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_4_TextGlob bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_4_TextGlob) (new BEC_2_4_4_TextGlob()).bem_new_1(beva_glob);
bevt_2_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_match_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_6_6_SystemObject bevl_res = null;
bevl_res = base.bem_subPath_2(beva_start, beva_end);
bevl_res.bemd_1(730713919, bevp_driveLetter);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_lastStepGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_fileGetDirect_0() {
return bevp_file;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_fileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_file = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_file = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_driveLetterGet_0() {
return bevp_driveLetter;
} /*method end*/
public BEC_2_4_6_TextString bem_driveLetterGetDirect_0() {
return bevp_driveLetter;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_driveLetterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_driveLetter = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_driveLetterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_driveLetter = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 18, 19, 24, 24, 24, 24, 24, 24, 24, 24, 0, 0, 0, 25, 25, 25, 26, 26, 26, 28, 28, 29, 29, 29, 30, 30, 37, 37, 41, 41, 45, 49, 49, 55, 55, 56, 57, 59, 63, 64, 65, 65, 66, 67, 71, 71, 72, 72, 74, 78, 78, 82, 83, 84, 89, 89, 89, 89, 93, 94, 95, 99, 99, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {23, 24, 25, 46, 47, 48, 53, 54, 55, 56, 57, 59, 62, 66, 69, 70, 71, 72, 73, 74, 76, 77, 78, 79, 80, 81, 82, 86, 87, 91, 92, 95, 100, 101, 105, 110, 111, 112, 114, 119, 120, 121, 122, 123, 124, 129, 134, 135, 136, 138, 142, 143, 147, 149, 150, 158, 159, 160, 161, 165, 166, 167, 171, 172, 175, 178, 182, 186, 189, 192, 196};
/* BEGIN LINEINFO 
assign 1 18 23
new 0 18 23
assign 1 18 24
separatorGet 0 18 24
fromString 1 19 25
assign 1 24 46
sizeGet 0 24 46
assign 1 24 47
new 0 24 47
assign 1 24 48
greater 1 24 53
assign 1 24 54
new 0 24 54
assign 1 24 55
getPoint 1 24 55
assign 1 24 56
new 0 24 56
assign 1 24 57
equals 1 24 57
assign 1 0 59
assign 1 0 62
assign 1 0 66
assign 1 25 69
new 0 25 69
assign 1 25 70
new 0 25 70
assign 1 25 71
substring 2 25 71
assign 1 26 72
new 0 26 72
assign 1 26 73
sizeGet 0 26 73
assign 1 26 74
substring 2 26 74
assign 1 28 76
new 0 28 76
assign 1 28 77
platformGet 0 28 77
assign 1 29 78
otherSeparatorGet 0 29 78
assign 1 29 79
separatorGet 0 29 79
assign 1 29 80
swap 2 29 80
assign 1 30 81
new 1 30 81
return 1 30 82
assign 1 37 86
isAbsoluteGet 0 37 86
return 1 37 87
assign 1 41 91
toString 0 41 91
return 1 41 92
apNew 1 45 95
assign 1 49 100
new 0 49 100
return 1 49 101
assign 1 55 105
undef 1 55 110
assign 1 56 111
new 0 56 111
pathSet 1 57 112
return 1 59 114
assign 1 63 119
create 0 63 119
copyTo 1 64 120
assign 1 65 121
copy 0 65 121
pathSet 1 65 122
fileSet 1 66 123
return 1 67 124
assign 1 71 129
def 1 71 134
assign 1 72 135
add 1 72 135
return 1 72 136
return 1 74 138
assign 1 78 142
parentGet 0 78 142
return 1 78 143
assign 1 82 147
isAbsoluteGet 0 82 147
assign 1 83 149
makeNonAbsolute 0 84 150
assign 1 89 158
new 1 89 158
assign 1 89 159
toString 0 89 159
assign 1 89 160
match 1 89 160
return 1 89 161
assign 1 93 165
subPath 2 93 165
driveLetterSet 1 94 166
return 1 95 167
assign 1 99 171
lastStepGet 0 99 171
return 1 99 172
return 1 0 175
assign 1 0 178
assign 1 0 182
return 1 0 186
return 1 0 189
assign 1 0 192
assign 1 0 196
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 427020448: return bem_tagGet_0();
case 2091348126: return bem_deleteFirstStep_0();
case 1157301168: return bem_firstStepGet_0();
case 1543967065: return bem_fileGetDirect_0();
case -65682954: return bem_lastStepGet_0();
case -542469317: return bem_driveLetterGetDirect_0();
case 705904898: return bem_echo_0();
case 152176726: return bem_isAbsoluteGet_0();
case -749374888: return bem_toAny_0();
case 905957116: return bem_create_0();
case 1277127917: return bem_hashGet_0();
case 2143199287: return bem_once_0();
case -363455556: return bem_print_0();
case -675377167: return bem_sourceFileNameGet_0();
case -1043866834: return bem_deserializeClassNameGet_0();
case -481509271: return bem_new_0();
case -143076951: return bem_iteratorGet_0();
case 485739285: return bem_many_0();
case 1236486987: return bem_separatorGetDirect_0();
case -1192287450: return bem_parentGet_0();
case 1634044932: return bem_pathGetDirect_0();
case 1140351358: return bem_makeAbsolute_0();
case 740377946: return bem_fieldIteratorGet_0();
case 1830393821: return bem_serializationIteratorGet_0();
case 1113652033: return bem_serializeToString_0();
case -1585039114: return bem_driveLetterGet_0();
case -2047177330: return bem_copy_0();
case 600898289: return bem_fileGet_0();
case 2133981775: return bem_pathGet_0();
case -1939888280: return bem_classNameGet_0();
case -1031769915: return bem_stepsGet_0();
case -915372871: return bem_makeNonAbsolute_0();
case -769908714: return bem_serializeContents_0();
case -949552796: return bem_stepListGet_0();
case 4057483: return bem_toString_0();
case -594247468: return bem_separatorGet_0();
case -853943837: return bem_fieldNamesGet_0();
case -1559730859: return bem_nameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -656621139: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -1520063387: return bem_defined_1(bevd_0);
case 1755877526: return bem_notEquals_1(bevd_0);
case -383438063: return bem_def_1(bevd_0);
case -2137592378: return bem_undefined_1(bevd_0);
case -640783253: return bem_separatorSetDirect_1(bevd_0);
case 1807878254: return bem_add_1(bevd_0);
case -192930090: return bem_addStep_1(bevd_0);
case 1474173561: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 491937363: return bem_separatorSet_1(bevd_0);
case -192663476: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 712632903: return bem_matchesGlob_1((BEC_2_4_6_TextString) bevd_0);
case 730713919: return bem_driveLetterSet_1(bevd_0);
case 2122304776: return bem_equals_1(bevd_0);
case -253832378: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -1071341413: return bem_otherType_1(bevd_0);
case 2128107362: return bem_pathSet_1(bevd_0);
case -380915955: return bem_fileSetDirect_1(bevd_0);
case 1353862901: return bem_sameType_1(bevd_0);
case -136446475: return bem_otherClass_1(bevd_0);
case -271328767: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 107306958: return bem_driveLetterSetDirect_1(bevd_0);
case -1127802964: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1325161938: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 986742986: return bem_pathSetDirect_1(bevd_0);
case -846136427: return bem_apNew_1((BEC_2_4_6_TextString) bevd_0);
case -1924831101: return bem_copyTo_1(bevd_0);
case 199267201: return bem_fileSet_1(bevd_0);
case -73636763: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2021680719: return bem_sameObject_1(bevd_0);
case -988024628: return bem_undef_1(bevd_0);
case -578389793: return bem_sameClass_1(bevd_0);
case -2009800716: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1177551660: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 828423720: return bem_addSteps_1(bevd_0);
case -1709376459: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1965837486: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 943584436: return bem_addSteps_2(bevd_0, bevd_1);
case 503438982: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 837534085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 851139439: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 129124545: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1276325839: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 440463842: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -929921852: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_3_2_4_4_IOFilePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_3_2_4_4_IOFilePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_4_IOFilePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_inst = (BEC_3_2_4_4_IOFilePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_type;
}
}
}
