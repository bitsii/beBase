namespace be {
/* IO:File: source/build/Pass2.be */
public sealed class BEC_3_5_5_5_BuildVisitPass2 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass2() { }
static BEC_3_5_5_5_BuildVisitPass2() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass2_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x32};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass2_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass2_bels_0 = {0x2E};
public static new BEC_3_5_5_5_BuildVisitPass2 bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass2 bece_BEC_3_5_5_5_BuildVisitPass2_bevs_type;

public BEC_2_4_3_MathInt bevp_idType;
public BEC_2_4_3_MathInt bevp_intType;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
BEC_2_5_9_BuildConstants bevt_1_tmpany_phold = null;
base.bem_begin_1(beva_transi);
bevp_idType = bevp_ntypes.bem_IDGet_0();
bevp_intType = bevp_ntypes.bem_INTLGet_0();
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_matchMap = bevt_0_tmpany_phold.bem_matchMapGet_0();
bevt_1_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_rwords = bevt_1_tmpany_phold.bem_rwordsGet_0();
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_held = null;
BEC_2_6_6_SystemObject bevl_type = null;
BEC_2_5_4_BuildNode bevl_nxp = null;
BEC_2_5_4_BuildNode bevl_nxp2 = null;
BEC_2_5_4_BuildNode bevl_nxp3 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_27_tmpany_phold = null;
bevt_3_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_4_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_3_tmpany_phold.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevt_5_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_5_tmpany_phold;
} /* Line: 31 */
bevl_held = beva_node.bem_heldGet_0();
if (bevl_held == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevl_type = bevp_matchMap.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 36 */ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 38 */
 else  /* Line: 39 */ {
bevt_8_tmpany_phold = bevl_held.bemd_0(1122276280);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 41 */ {
bevl_nxp = beva_node.bem_nextPeerGet_0();
if (bevl_nxp == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_11_tmpany_phold = bevl_nxp.bem_heldGet_0();
if (bevt_11_tmpany_phold == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 43 */
 else  /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 43 */ {
bevt_13_tmpany_phold = bevl_nxp.bem_heldGet_0();
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass2_bels_0));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(-152296894, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 44 */ {
bevl_nxp2 = bevl_nxp.bem_nextPeerGet_0();
if (bevl_nxp2 == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_17_tmpany_phold = bevl_nxp2.bem_heldGet_0();
if (bevt_17_tmpany_phold == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 46 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 46 */
 else  /* Line: 46 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 46 */ {
bevl_nxp3 = bevl_nxp2.bem_nextDescendGet_0();
bevt_19_tmpany_phold = bevl_nxp2.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1122276280);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 48 */ {
bevt_22_tmpany_phold = beva_node.bem_heldGet_0();
bevt_23_tmpany_phold = bevl_nxp.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(1633481692, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = bevl_nxp2.bem_heldGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_1(1633481692, bevt_24_tmpany_phold);
beva_node.bem_heldSet_1(bevt_20_tmpany_phold);
bevt_25_tmpany_phold = bevp_ntypes.bem_FLOATLGet_0();
beva_node.bem_typenameSet_1(bevt_25_tmpany_phold);
bevl_nxp2.bem_delete_0();
bevl_nxp.bem_delete_0();
return bevl_nxp3;
} /* Line: 53 */
} /* Line: 48 */
} /* Line: 46 */
} /* Line: 44 */
beva_node.bem_typenameSet_1(bevp_intType);
} /* Line: 58 */
 else  /* Line: 59 */ {
bevl_type = bevp_rwords.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 61 */ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 62 */
 else  /* Line: 63 */ {
beva_node.bem_typenameSet_1(bevp_idType);
} /* Line: 64 */
} /* Line: 61 */
} /* Line: 41 */
} /* Line: 36 */
bevt_27_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_27_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_idTypeGet_0() {
return bevp_idType;
} /*method end*/
public BEC_2_4_3_MathInt bem_idTypeGetDirect_0() {
return bevp_idType;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_idTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_idType = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_idTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_idType = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intTypeGet_0() {
return bevp_intType;
} /*method end*/
public BEC_2_4_3_MathInt bem_intTypeGetDirect_0() {
return bevp_intType;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_intTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_intType = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_intTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_intType = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() {
return bevp_matchMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGetDirect_0() {
return bevp_matchMap;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_matchMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() {
return bevp_rwords;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGetDirect_0() {
return bevp_rwords;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_rwordsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 19, 20, 21, 21, 22, 22, 30, 30, 30, 30, 31, 31, 33, 34, 34, 35, 36, 36, 38, 41, 42, 43, 43, 43, 43, 43, 0, 0, 0, 44, 44, 44, 45, 46, 46, 46, 46, 46, 0, 0, 0, 47, 48, 48, 49, 49, 49, 49, 49, 49, 50, 50, 51, 52, 53, 58, 60, 61, 61, 62, 64, 69, 69, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 22, 23, 24, 25, 26, 63, 64, 65, 70, 71, 72, 74, 75, 80, 81, 82, 87, 88, 91, 93, 94, 99, 100, 101, 106, 107, 110, 114, 117, 118, 119, 121, 122, 127, 128, 129, 134, 135, 138, 142, 145, 146, 147, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 164, 167, 168, 173, 174, 177, 182, 183, 186, 189, 192, 196, 200, 203, 206, 210, 214, 217, 220, 224, 228, 231, 234, 238};
/* BEGIN LINEINFO 
begin 1 16 20
assign 1 19 21
IDGet 0 19 21
assign 1 20 22
INTLGet 0 20 22
assign 1 21 23
constantsGet 0 21 23
assign 1 21 24
matchMapGet 0 21 24
assign 1 22 25
constantsGet 0 22 25
assign 1 22 26
rwordsGet 0 22 26
assign 1 30 63
typenameGet 0 30 63
assign 1 30 64
TRANSUNITGet 0 30 64
assign 1 30 65
equals 1 30 70
assign 1 31 71
nextDescendGet 0 31 71
return 1 31 72
assign 1 33 74
heldGet 0 33 74
assign 1 34 75
def 1 34 80
assign 1 35 81
get 1 35 81
assign 1 36 82
def 1 36 87
typenameSet 1 38 88
assign 1 41 91
isInteger 0 41 91
assign 1 42 93
nextPeerGet 0 42 93
assign 1 43 94
def 1 43 99
assign 1 43 100
heldGet 0 43 100
assign 1 43 101
def 1 43 106
assign 1 0 107
assign 1 0 110
assign 1 0 114
assign 1 44 117
heldGet 0 44 117
assign 1 44 118
new 0 44 118
assign 1 44 119
equals 1 44 119
assign 1 45 121
nextPeerGet 0 45 121
assign 1 46 122
def 1 46 127
assign 1 46 128
heldGet 0 46 128
assign 1 46 129
def 1 46 134
assign 1 0 135
assign 1 0 138
assign 1 0 142
assign 1 47 145
nextDescendGet 0 47 145
assign 1 48 146
heldGet 0 48 146
assign 1 48 147
isInteger 0 48 147
assign 1 49 149
heldGet 0 49 149
assign 1 49 150
heldGet 0 49 150
assign 1 49 151
add 1 49 151
assign 1 49 152
heldGet 0 49 152
assign 1 49 153
add 1 49 153
heldSet 1 49 154
assign 1 50 155
FLOATLGet 0 50 155
typenameSet 1 50 156
delete 0 51 157
delete 0 52 158
return 1 53 159
typenameSet 1 58 164
assign 1 60 167
get 1 60 167
assign 1 61 168
def 1 61 173
typenameSet 1 62 174
typenameSet 1 64 177
assign 1 69 182
nextDescendGet 0 69 182
return 1 69 183
return 1 0 186
return 1 0 189
assign 1 0 192
assign 1 0 196
return 1 0 200
return 1 0 203
assign 1 0 206
assign 1 0 210
return 1 0 214
return 1 0 217
assign 1 0 220
assign 1 0 224
return 1 0 228
return 1 0 231
assign 1 0 234
assign 1 0 238
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1196099876: return bem_echo_0();
case 87678171: return bem_idTypeGetDirect_0();
case -888502976: return bem_print_0();
case -170941956: return bem_serializeToString_0();
case 1989485633: return bem_many_0();
case 384026730: return bem_ntypesGet_0();
case 1278457769: return bem_buildGet_0();
case -2059181160: return bem_intTypeGetDirect_0();
case -517667337: return bem_rwordsGet_0();
case -1222154604: return bem_tagGet_0();
case -494057832: return bem_serializationIteratorGet_0();
case -982032274: return bem_transGet_0();
case 1352428264: return bem_ntypesGetDirect_0();
case 638575506: return bem_intTypeGet_0();
case -294806467: return bem_create_0();
case 213564239: return bem_copy_0();
case -1916548323: return bem_once_0();
case -242463884: return bem_fieldIteratorGet_0();
case -576159222: return bem_constGetDirect_0();
case 180642345: return bem_transGetDirect_0();
case 159449192: return bem_buildGetDirect_0();
case -1230714712: return bem_classNameGet_0();
case -671191297: return bem_serializeContents_0();
case -1342633655: return bem_hashGet_0();
case -1184557662: return bem_idTypeGet_0();
case -1297985879: return bem_fieldNamesGet_0();
case 1418348540: return bem_iteratorGet_0();
case -1925247459: return bem_sourceFileNameGet_0();
case 1832806152: return bem_toString_0();
case -351265190: return bem_rwordsGetDirect_0();
case -1562351500: return bem_constGet_0();
case -2010402547: return bem_matchMapGetDirect_0();
case -302817860: return bem_deserializeClassNameGet_0();
case 1797020795: return bem_toAny_0();
case -1029982372: return bem_matchMapGet_0();
case -1628841870: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -118558475: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1447630066: return bem_ntypesSetDirect_1(bevd_0);
case -810647371: return bem_sameClass_1(bevd_0);
case -2106634323: return bem_idTypeSetDirect_1(bevd_0);
case -788622974: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1345095935: return bem_defined_1(bevd_0);
case -218654526: return bem_transSet_1(bevd_0);
case -1815955443: return bem_intTypeSet_1(bevd_0);
case 1602348302: return bem_sameObject_1(bevd_0);
case -395616432: return bem_otherClass_1(bevd_0);
case 79810732: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2084177915: return bem_buildSetDirect_1(bevd_0);
case -120099514: return bem_transSetDirect_1(bevd_0);
case -1153526979: return bem_matchMapSet_1(bevd_0);
case 1932567662: return bem_constSet_1(bevd_0);
case 1672498055: return bem_constSetDirect_1(bevd_0);
case 878699000: return bem_ntypesSet_1(bevd_0);
case -1796596677: return bem_otherType_1(bevd_0);
case 920668587: return bem_rwordsSet_1(bevd_0);
case -1258204936: return bem_begin_1(bevd_0);
case 346995129: return bem_def_1(bevd_0);
case 1893921321: return bem_buildSet_1(bevd_0);
case -483876238: return bem_matchMapSetDirect_1(bevd_0);
case 1755961278: return bem_rwordsSetDirect_1(bevd_0);
case 936942966: return bem_undefined_1(bevd_0);
case -259280324: return bem_intTypeSetDirect_1(bevd_0);
case 1495593147: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1759390891: return bem_idTypeSet_1(bevd_0);
case -1811224480: return bem_sameType_1(bevd_0);
case 945449374: return bem_notEquals_1(bevd_0);
case -1190390262: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1398777398: return bem_end_1(bevd_0);
case 83181817: return bem_undef_1(bevd_0);
case -152296894: return bem_equals_1(bevd_0);
case -2046043947: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -174395426: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1117645207: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1434652185: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2038467728: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 6185266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 34704188: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1515774718: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass2_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass2_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass2();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst = (BEC_3_5_5_5_BuildVisitPass2) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_type;
}
}
}
