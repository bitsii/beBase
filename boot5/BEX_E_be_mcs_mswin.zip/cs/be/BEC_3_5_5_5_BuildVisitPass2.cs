namespace be {
/* IO:File: source/build/Pass2.be */
public sealed class BEC_3_5_5_5_BuildVisitPass2 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass2() { }
static BEC_3_5_5_5_BuildVisitPass2() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass2_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x32};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass2_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass2_bels_0 = {0x2E};
public static new BEC_3_5_5_5_BuildVisitPass2 bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass2 bece_BEC_3_5_5_5_BuildVisitPass2_bevs_type;

public BEC_2_4_3_MathInt bevp_idType;
public BEC_2_4_3_MathInt bevp_intType;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
BEC_2_5_9_BuildConstants bevt_0_ta_ph = null;
BEC_2_5_9_BuildConstants bevt_1_ta_ph = null;
base.bem_begin_1(beva_transi);
bevp_idType = bevp_ntypes.bem_IDGet_0();
bevp_intType = bevp_ntypes.bem_INTLGet_0();
bevt_0_ta_ph = bevp_build.bem_constantsGet_0();
bevp_matchMap = bevt_0_ta_ph.bem_matchMapGet_0();
bevt_1_ta_ph = bevp_build.bem_constantsGet_0();
bevp_rwords = bevt_1_ta_ph.bem_rwordsGet_0();
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_held = null;
BEC_2_6_6_SystemObject bevl_type = null;
BEC_2_5_4_BuildNode bevl_nxp = null;
BEC_2_5_4_BuildNode bevl_nxp2 = null;
BEC_2_5_4_BuildNode bevl_nxp3 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_BuildNode bevt_27_ta_ph = null;
bevt_3_ta_ph = beva_node.bem_typenameGet_0();
bevt_4_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_3_ta_ph.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 29*/ {
bevt_5_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_5_ta_ph;
} /* Line: 30*/
bevl_held = beva_node.bem_heldGet_0();
if (bevl_held == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 33*/ {
bevl_type = bevp_matchMap.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 35*/ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 37*/
 else /* Line: 38*/ {
bevt_8_ta_ph = bevl_held.bemd_0(1779694272);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 40*/ {
bevl_nxp = beva_node.bem_nextPeerGet_0();
if (bevl_nxp == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_11_ta_ph = bevl_nxp.bem_heldGet_0();
if (bevt_11_ta_ph == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 42*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 42*/
 else /* Line: 42*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 42*/ {
bevt_13_ta_ph = bevl_nxp.bem_heldGet_0();
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass2_bels_0));
bevt_12_ta_ph = bevt_13_ta_ph.bemd_1(1408797910, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 43*/ {
bevl_nxp2 = bevl_nxp.bem_nextPeerGet_0();
if (bevl_nxp2 == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 45*/ {
bevt_17_ta_ph = bevl_nxp2.bem_heldGet_0();
if (bevt_17_ta_ph == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 45*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 45*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 45*/
 else /* Line: 45*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 45*/ {
bevl_nxp3 = bevl_nxp2.bem_nextDescendGet_0();
bevt_19_ta_ph = bevl_nxp2.bem_heldGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(1779694272);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 47*/ {
bevt_22_ta_ph = beva_node.bem_heldGet_0();
bevt_23_ta_ph = bevl_nxp.bem_heldGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(1688096367, bevt_23_ta_ph);
bevt_24_ta_ph = bevl_nxp2.bem_heldGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_1(1688096367, bevt_24_ta_ph);
beva_node.bem_heldSet_1(bevt_20_ta_ph);
bevt_25_ta_ph = bevp_ntypes.bem_FLOATLGet_0();
beva_node.bem_typenameSet_1(bevt_25_ta_ph);
bevl_nxp2.bem_delete_0();
bevl_nxp.bem_delete_0();
return bevl_nxp3;
} /* Line: 52*/
} /* Line: 47*/
} /* Line: 45*/
} /* Line: 43*/
beva_node.bem_typenameSet_1(bevp_intType);
} /* Line: 57*/
 else /* Line: 58*/ {
bevl_type = bevp_rwords.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 60*/ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 61*/
 else /* Line: 62*/ {
beva_node.bem_typenameSet_1(bevp_idType);
} /* Line: 63*/
} /* Line: 60*/
} /* Line: 40*/
} /* Line: 35*/
bevt_27_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_27_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_idTypeGet_0() {
return bevp_idType;
} /*method end*/
public BEC_2_4_3_MathInt bem_idTypeGetDirect_0() {
return bevp_idType;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_idTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_idType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_idTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_idType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intTypeGet_0() {
return bevp_intType;
} /*method end*/
public BEC_2_4_3_MathInt bem_intTypeGetDirect_0() {
return bevp_intType;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_intTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_intType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_intTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_intType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() {
return bevp_matchMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGetDirect_0() {
return bevp_matchMap;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_matchMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() {
return bevp_rwords;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGetDirect_0() {
return bevp_rwords;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_rwordsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15, 18, 19, 20, 20, 21, 21, 29, 29, 29, 29, 30, 30, 32, 33, 33, 34, 35, 35, 37, 40, 41, 42, 42, 42, 42, 42, 0, 0, 0, 43, 43, 43, 44, 45, 45, 45, 45, 45, 0, 0, 0, 46, 47, 47, 48, 48, 48, 48, 48, 48, 49, 49, 50, 51, 52, 57, 59, 60, 60, 61, 63, 68, 68, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 22, 23, 24, 25, 26, 63, 64, 65, 70, 71, 72, 74, 75, 80, 81, 82, 87, 88, 91, 93, 94, 99, 100, 101, 106, 107, 110, 114, 117, 118, 119, 121, 122, 127, 128, 129, 134, 135, 138, 142, 145, 146, 147, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 164, 167, 168, 173, 174, 177, 182, 183, 186, 189, 192, 196, 200, 203, 206, 210, 214, 217, 220, 224, 228, 231, 234, 238};
/* BEGIN LINEINFO 
begin 1 15 20
assign 1 18 21
IDGet 0 18 21
assign 1 19 22
INTLGet 0 19 22
assign 1 20 23
constantsGet 0 20 23
assign 1 20 24
matchMapGet 0 20 24
assign 1 21 25
constantsGet 0 21 25
assign 1 21 26
rwordsGet 0 21 26
assign 1 29 63
typenameGet 0 29 63
assign 1 29 64
TRANSUNITGet 0 29 64
assign 1 29 65
equals 1 29 70
assign 1 30 71
nextDescendGet 0 30 71
return 1 30 72
assign 1 32 74
heldGet 0 32 74
assign 1 33 75
def 1 33 80
assign 1 34 81
get 1 34 81
assign 1 35 82
def 1 35 87
typenameSet 1 37 88
assign 1 40 91
isInteger 0 40 91
assign 1 41 93
nextPeerGet 0 41 93
assign 1 42 94
def 1 42 99
assign 1 42 100
heldGet 0 42 100
assign 1 42 101
def 1 42 106
assign 1 0 107
assign 1 0 110
assign 1 0 114
assign 1 43 117
heldGet 0 43 117
assign 1 43 118
new 0 43 118
assign 1 43 119
equals 1 43 119
assign 1 44 121
nextPeerGet 0 44 121
assign 1 45 122
def 1 45 127
assign 1 45 128
heldGet 0 45 128
assign 1 45 129
def 1 45 134
assign 1 0 135
assign 1 0 138
assign 1 0 142
assign 1 46 145
nextDescendGet 0 46 145
assign 1 47 146
heldGet 0 47 146
assign 1 47 147
isInteger 0 47 147
assign 1 48 149
heldGet 0 48 149
assign 1 48 150
heldGet 0 48 150
assign 1 48 151
add 1 48 151
assign 1 48 152
heldGet 0 48 152
assign 1 48 153
add 1 48 153
heldSet 1 48 154
assign 1 49 155
FLOATLGet 0 49 155
typenameSet 1 49 156
delete 0 50 157
delete 0 51 158
return 1 52 159
typenameSet 1 57 164
assign 1 59 167
get 1 59 167
assign 1 60 168
def 1 60 173
typenameSet 1 61 174
typenameSet 1 63 177
assign 1 68 182
nextDescendGet 0 68 182
return 1 68 183
return 1 0 186
return 1 0 189
assign 1 0 192
assign 1 0 196
return 1 0 200
return 1 0 203
assign 1 0 206
assign 1 0 210
return 1 0 214
return 1 0 217
assign 1 0 220
assign 1 0 224
return 1 0 228
return 1 0 231
assign 1 0 234
assign 1 0 238
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1893075648: return bem_buildGetDirect_0();
case 1416213514: return bem_intTypeGetDirect_0();
case -2125350734: return bem_idTypeGet_0();
case -1642361296: return bem_print_0();
case 488087252: return bem_idTypeGetDirect_0();
case 2096109526: return bem_ntypesGet_0();
case 1161638424: return bem_new_0();
case -1835746973: return bem_matchMapGet_0();
case 168135582: return bem_create_0();
case 208100575: return bem_intTypeGet_0();
case -766561567: return bem_rwordsGetDirect_0();
case 759496930: return bem_tagGet_0();
case 814334258: return bem_serializeContents_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 1803787653: return bem_transGet_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -71162589: return bem_iteratorGet_0();
case 308363814: return bem_rwordsGet_0();
case -884149543: return bem_constGet_0();
case 1043004008: return bem_constGetDirect_0();
case 944073339: return bem_fieldIteratorGet_0();
case 2132420479: return bem_many_0();
case -417851647: return bem_transGetDirect_0();
case 1365897346: return bem_serializationIteratorGet_0();
case -1480556491: return bem_toAny_0();
case -202912463: return bem_copy_0();
case 350691792: return bem_toString_0();
case -1044758745: return bem_serializeToString_0();
case -1251441948: return bem_buildGet_0();
case 2064925791: return bem_echo_0();
case 424617382: return bem_ntypesGetDirect_0();
case -1711670377: return bem_hashGet_0();
case 22520619: return bem_matchMapGetDirect_0();
case -1359614197: return bem_classNameGet_0();
case -1785724794: return bem_once_0();
case -652053502: return bem_fieldNamesGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1142023380: return bem_begin_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case 819746231: return bem_buildSet_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -164810505: return bem_ntypesSet_1(bevd_0);
case -990686106: return bem_constSetDirect_1(bevd_0);
case 1623208395: return bem_end_1(bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case -1458431940: return bem_ntypesSetDirect_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case -580728130: return bem_matchMapSetDirect_1(bevd_0);
case -678982929: return bem_intTypeSet_1(bevd_0);
case -184438859: return bem_idTypeSetDirect_1(bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case -1061601401: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case 1415081112: return bem_intTypeSetDirect_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 943568586: return bem_idTypeSet_1(bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case 2135280430: return bem_matchMapSet_1(bevd_0);
case -1055205804: return bem_buildSetDirect_1(bevd_0);
case -1138300739: return bem_rwordsSetDirect_1(bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1880603529: return bem_transSetDirect_1(bevd_0);
case -424141057: return bem_rwordsSet_1(bevd_0);
case -548044674: return bem_transSet_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case -965959383: return bem_constSet_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass2_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass2_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass2();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst = (BEC_3_5_5_5_BuildVisitPass2) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_type;
}
}
}
