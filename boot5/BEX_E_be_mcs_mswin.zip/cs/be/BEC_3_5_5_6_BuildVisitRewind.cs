namespace be {
/* IO:File: source/build/Pass12.be */
public sealed class BEC_3_5_5_6_BuildVisitRewind : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitRewind() { }
static BEC_3_5_5_6_BuildVisitRewind() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitRewind_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitRewind_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_1, 11));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_2 = {0x5F,0x30};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_2, 2));
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_2, 2));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_3 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_4 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_4, 27));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_5 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_6 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_6, 13));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_7 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_7, 13));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_8 = {0x28,0x41,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_8, 17));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_9 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_9, 10));
public static new BEC_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;

public static new BET_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;

public BEC_2_6_6_SystemObject bevp_tvmap;
public BEC_2_6_6_SystemObject bevp_rmap;
public BEC_2_6_6_SystemObject bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_6_6_SystemObject bevp_nl;
public BEC_2_6_6_SystemObject bevp_emitter;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_8_BuildNamePath bevl_fgnp = null;
BEC_2_4_6_TextString bevl_fgcn = null;
BEC_2_4_6_TextString bevl_fgin = null;
BEC_2_5_8_BuildClassSyn bevl_fgsy = null;
BEC_2_5_6_BuildMtdSyn bevl_fgms = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_BuildNode bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_5_4_BuildNode bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_34_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_3_MathInt bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_5_4_LogicBool bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_5_4_LogicBool bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_6_6_SystemObject bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_5_4_LogicBool bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_5_4_BuildNode bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_5_4_BuildNode bevt_79_ta_ph = null;
BEC_2_5_4_BuildNode bevt_80_ta_ph = null;
BEC_2_5_4_LogicBool bevt_81_ta_ph = null;
BEC_2_4_3_MathInt bevt_82_ta_ph = null;
BEC_2_5_4_BuildNode bevt_83_ta_ph = null;
BEC_2_5_4_BuildNode bevt_84_ta_ph = null;
BEC_2_4_3_MathInt bevt_85_ta_ph = null;
BEC_2_5_4_BuildNode bevt_86_ta_ph = null;
bevt_9_ta_ph = beva_node.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 348*/ {
bevt_12_ta_ph = beva_node.bem_heldGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(-1104955329);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 348*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 348*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 348*/
 else /* Line: 348*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 348*/ {
bevt_15_ta_ph = beva_node.bem_containerGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_typenameGet_0();
bevt_16_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_14_ta_ph.bevi_int == bevt_16_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_20_ta_ph = beva_node.bem_containerGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_heldGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-623202179);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(354557818, bevt_21_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 350*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 350*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 350*/
 else /* Line: 350*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 350*/ {
bevt_22_ta_ph = beva_node.bem_isSecondGet_0();
if (bevt_22_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 350*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 350*/
 else /* Line: 350*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 350*/ {
bevt_26_ta_ph = beva_node.bem_containedGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bem_firstGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(1963473742);
bevt_27_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_1(354557818, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 352*/ {
bevt_31_ta_ph = beva_node.bem_containedGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_firstGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bemd_0(1712678790);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(1463424675);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 352*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 352*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 352*/
 else /* Line: 352*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 352*/ {
bevt_34_ta_ph = beva_node.bem_containedGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(1712678790);
bevl_fgnp = (BEC_2_5_8_BuildNamePath) bevt_32_ta_ph.bemd_0(-932925423);
bevt_35_ta_ph = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_2_4_6_TextString) bevt_35_ta_ph.bem_lastGet_0();
bevt_39_ta_ph = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_0;
bevt_40_ta_ph = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_1;
bevt_38_ta_ph = bevl_fgcn.bem_substring_2(bevt_39_ta_ph, bevt_40_ta_ph);
bevt_37_ta_ph = (BEC_2_4_6_TextString) bevt_38_ta_ph.bem_lowerValue_0();
bevt_42_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_41_ta_ph = bevl_fgcn.bem_substring_1(bevt_42_ta_ph);
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevt_41_ta_ph);
bevt_43_ta_ph = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_2;
bevl_fgin = bevt_36_ta_ph.bem_add_1(bevt_43_ta_ph);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_ta_ph = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_ta_ph = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_3;
bevt_45_ta_ph = bevl_fgin.bem_add_1(bevt_46_ta_ph);
bevl_fgms = (BEC_2_5_6_BuildMtdSyn) bevt_44_ta_ph.bem_get_1(bevt_45_ta_ph);
if (bevl_fgms == null) {
bevt_47_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_47_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_47_ta_ph.bevi_bool)/* Line: 359*/ {
bevt_48_ta_ph = beva_node.bem_heldGet_0();
bevt_48_ta_ph.bemd_1(911907691, bevl_fgin);
bevt_49_ta_ph = beva_node.bem_heldGet_0();
bevt_51_ta_ph = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_4;
bevt_50_ta_ph = bevl_fgin.bem_add_1(bevt_51_ta_ph);
bevt_49_ta_ph.bemd_1(1258888420, bevt_50_ta_ph);
} /* Line: 362*/
} /* Line: 359*/
} /* Line: 352*/
} /* Line: 350*/
bevt_53_ta_ph = beva_node.bem_typenameGet_0();
bevt_54_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_53_ta_ph.bevi_int == bevt_54_ta_ph.bevi_int) {
bevt_52_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_52_ta_ph.bevi_bool)/* Line: 367*/ {
bevp_inClass = beva_node;
bevt_55_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_ta_ph.bemd_0(-932925423);
bevt_56_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_ta_ph.bemd_0(-940042464);
} /* Line: 370*/
bevt_58_ta_ph = beva_node.bem_typenameGet_0();
bevt_59_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_58_ta_ph.bevi_int == bevt_59_ta_ph.bevi_int) {
bevt_57_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_57_ta_ph.bevi_bool)/* Line: 372*/ {
bevp_tvmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 374*/
 else /* Line: 372*/ {
bevt_61_ta_ph = beva_node.bem_typenameGet_0();
bevt_62_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_61_ta_ph.bevi_int == bevt_62_ta_ph.bevi_int) {
bevt_60_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_60_ta_ph.bevi_bool)/* Line: 375*/ {
bevt_64_ta_ph = beva_node.bem_heldGet_0();
bevt_63_ta_ph = bevt_64_ta_ph.bemd_0(-318274408);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 375*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 375*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 375*/
 else /* Line: 375*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 375*/ {
bevt_66_ta_ph = beva_node.bem_heldGet_0();
bevt_65_ta_ph = bevt_66_ta_ph.bemd_0(-916206427);
bevt_67_ta_ph = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(-1832936144, bevt_65_ta_ph, bevt_67_ta_ph);
bevt_69_ta_ph = beva_node.bem_heldGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bemd_0(-916206427);
bevl_ll = bevp_rmap.bemd_1(-179596882, bevt_68_ta_ph);
if (bevl_ll == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 378*/ {
bevl_ll = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_ta_ph = beva_node.bem_heldGet_0();
bevt_71_ta_ph = bevt_72_ta_ph.bemd_0(-916206427);
bevp_rmap.bemd_2(-1832936144, bevt_71_ta_ph, bevl_ll);
} /* Line: 380*/
bevl_ll.bemd_1(-2013138183, beva_node);
} /* Line: 382*/
 else /* Line: 372*/ {
bevt_74_ta_ph = beva_node.bem_typenameGet_0();
bevt_75_ta_ph = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_74_ta_ph.bevi_int == bevt_75_ta_ph.bevi_int) {
bevt_73_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_73_ta_ph.bevi_bool)/* Line: 383*/ {
bevt_77_ta_ph = beva_node.bem_containerGet_0();
if (bevt_77_ta_ph == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 383*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 383*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 383*/
 else /* Line: 383*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 383*/ {
bevt_80_ta_ph = beva_node.bem_containerGet_0();
bevt_79_ta_ph = bevt_80_ta_ph.bem_containerGet_0();
if (bevt_79_ta_ph == null) {
bevt_78_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_78_ta_ph.bevi_bool)/* Line: 383*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 383*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 383*/
 else /* Line: 383*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 383*/ {
bevt_84_ta_ph = beva_node.bem_containerGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bem_containerGet_0();
bevt_82_ta_ph = bevt_83_ta_ph.bem_typenameGet_0();
bevt_85_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_82_ta_ph.bevi_int == bevt_85_ta_ph.bevi_int) {
bevt_81_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_81_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_81_ta_ph.bevi_bool)/* Line: 383*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 383*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 383*/
 else /* Line: 383*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 383*/ {
bem_processTmps_0();
} /* Line: 385*/
} /* Line: 372*/
} /* Line: 372*/
bevt_86_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_86_ta_ph;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_processTmps_0() {
BEC_2_6_6_SystemObject bevl_foundone = null;
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_tcall = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_targNp = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_nv = null;
BEC_2_6_6_SystemObject bevl_nvname = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_k = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_5_4_LogicBool bevt_41_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_5_4_LogicBool bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_6_6_SystemObject bevt_84_ta_ph = null;
BEC_2_6_6_SystemObject bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_6_6_SystemObject bevt_87_ta_ph = null;
BEC_2_6_6_SystemObject bevt_88_ta_ph = null;
BEC_2_6_6_SystemObject bevt_89_ta_ph = null;
BEC_2_6_6_SystemObject bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_6_6_SystemObject bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_6_6_SystemObject bevt_99_ta_ph = null;
BEC_2_6_6_SystemObject bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
bevl_foundone = be.BECS_Runtime.boolTrue;
while (true)
/* Line: 399*/ {
if (((BEC_2_5_4_LogicBool) bevl_foundone).bevi_bool)/* Line: 399*/ {
bevl_foundone = be.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(2061887638);
while (true)
/* Line: 401*/ {
bevt_9_ta_ph = bevl_i.bemd_0(-1024297580);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 401*/ {
bevl_nv = bevl_i.bemd_0(-12961780);
bevt_11_ta_ph = bevl_nv.bemd_0(1463424675);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(560923354);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 404*/ {
bevl_nvname = bevl_nv.bemd_0(-916206427);
bevl_ll = bevp_rmap.bemd_1(-179596882, bevl_nvname);
bevt_0_ta_loop = bevl_ll.bemd_0(-2014542803);
while (true)
/* Line: 409*/ {
bevt_12_ta_ph = bevt_0_ta_loop.bemd_0(-1024297580);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 409*/ {
bevl_k = bevt_0_ta_loop.bemd_0(-12961780);
bevt_13_ta_ph = bevl_k.bemd_0(1281770511);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 410*/ {
bevt_16_ta_ph = bevl_k.bemd_0(284720992);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(1963473742);
bevt_17_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bemd_1(354557818, bevt_17_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 410*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 410*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 410*/
 else /* Line: 410*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 410*/ {
bevt_21_ta_ph = bevl_k.bemd_0(284720992);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(1712678790);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-623202179);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(354557818, bevt_22_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 410*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 410*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 410*/
 else /* Line: 410*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 410*/ {
bevt_26_ta_ph = bevl_k.bemd_0(284720992);
bevt_25_ta_ph = bevt_26_ta_ph.bemd_0(443497498);
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(1963473742);
bevt_27_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_1(354557818, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 410*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 410*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 410*/
 else /* Line: 410*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 410*/ {
bevt_28_ta_ph = bevl_k.bemd_0(284720992);
bevl_tcall = bevt_28_ta_ph.bemd_0(443497498);
bevl_targNp = null;
bevt_31_ta_ph = bevl_tcall.bemd_0(1712678790);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(873778313);
if (bevt_30_ta_ph == null) {
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 414*/ {
bevt_32_ta_ph = bevl_tcall.bemd_0(1712678790);
bevl_targNp = bevt_32_ta_ph.bemd_0(873778313);
} /* Line: 415*/
 else /* Line: 416*/ {
bevt_33_ta_ph = bevl_tcall.bemd_0(-1599063965);
bevl_targ = bevt_33_ta_ph.bemd_0(1117833636);
bevt_35_ta_ph = bevl_targ.bemd_0(1712678790);
bevt_34_ta_ph = bevt_35_ta_ph.bemd_0(-778417959);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 421*/ {
bevl_tany = bevl_targ.bemd_0(1712678790);
} /* Line: 422*/
 else /* Line: 423*/ {
bevt_37_ta_ph = bevp_inClassSyn.bemd_0(-1319528275);
bevt_39_ta_ph = bevl_targ.bemd_0(1712678790);
bevt_38_ta_ph = bevt_39_ta_ph.bemd_0(-916206427);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_1(-179596882, bevt_38_ta_ph);
bevl_tany = bevt_36_ta_ph.bemd_0(-131723669);
} /* Line: 424*/
bevt_40_ta_ph = bevl_tany.bemd_0(1463424675);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 427*/ {
bevl_targNp = bevl_tany.bemd_0(-932925423);
} /* Line: 428*/
} /* Line: 427*/
if (bevl_targNp == null) {
bevt_41_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_41_ta_ph.bevi_bool)/* Line: 431*/ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_42_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_44_ta_ph = bevl_tcall.bemd_0(1712678790);
bevt_43_ta_ph = bevt_44_ta_ph.bemd_0(-916206427);
bevl_mtdc = bevt_42_ta_ph.bem_get_1(bevt_43_ta_ph);
if (bevl_mtdc == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 435*/ {
bevl_oany = bevl_mtdc.bemd_0(-146333296);
if (bevl_oany == null) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 438*/ {
bevt_47_ta_ph = bevl_oany.bemd_0(1463424675);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 438*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 438*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 438*/
 else /* Line: 438*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 438*/ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_48_ta_ph = bevl_oany.bemd_0(377176253);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 441*/ {
bevl_nv.bemd_1(1082109373, bevl_targNp);
} /* Line: 442*/
 else /* Line: 443*/ {
bevt_49_ta_ph = bevl_oany.bemd_0(-932925423);
bevl_nv.bemd_1(1082109373, bevt_49_ta_ph);
} /* Line: 444*/
bevt_50_ta_ph = bevl_oany.bemd_0(1463424675);
bevl_nv.bemd_1(662840365, bevt_50_ta_ph);
bevt_51_ta_ph = bevp_inClass.bemd_0(1712678790);
bevt_52_ta_ph = bevl_nv.bemd_0(-932925423);
bevt_51_ta_ph.bemd_1(-1877524032, bevt_52_ta_ph);
bevt_55_ta_ph = bevl_nv.bemd_0(-932925423);
bevt_54_ta_ph = bevt_55_ta_ph.bemd_0(-1990292643);
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitRewind_bels_3));
bevt_53_ta_ph = bevt_54_ta_ph.bemd_1(354557818, bevt_56_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 448*/ {
bevt_58_ta_ph = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_5;
bevt_59_ta_ph = bevl_oany.bemd_0(377176253);
bevt_57_ta_ph = bevt_58_ta_ph.bem_add_1(bevt_59_ta_ph);
bevt_57_ta_ph.bem_print_0();
} /* Line: 448*/
} /* Line: 448*/
} /* Line: 438*/
 else /* Line: 435*/ {
bevt_62_ta_ph = bevl_tcall.bemd_0(1712678790);
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(-623202179);
bevt_63_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_5));
bevt_60_ta_ph = bevt_61_ta_ph.bemd_1(-840953319, bevt_63_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_60_ta_ph).bevi_bool)/* Line: 450*/ {
bevt_64_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_65_ta_ph = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_6;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_64_ta_ph.bem_get_1(bevt_65_ta_ph);
if (bevl_fcms == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 452*/ {
bevt_69_ta_ph = bevl_fcms.bem_originGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bem_toString_0();
bevt_70_ta_ph = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_7;
bevt_67_ta_ph = bevt_68_ta_ph.bem_notEquals_1(bevt_70_ta_ph);
if (bevt_67_ta_ph.bevi_bool)/* Line: 452*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 452*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 452*/
 else /* Line: 452*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 452*/ {
bevt_71_ta_ph = bevl_tcall.bemd_0(1712678790);
bevt_72_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_71_ta_ph.bemd_1(-867739393, bevt_72_ta_ph);
} /* Line: 453*/
 else /* Line: 454*/ {
bevt_77_ta_ph = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_8;
bevt_79_ta_ph = bevl_tcall.bemd_0(1712678790);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_0(-916206427);
bevt_76_ta_ph = bevt_77_ta_ph.bem_add_1(bevt_78_ta_ph);
bevt_80_ta_ph = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_9;
bevt_75_ta_ph = bevt_76_ta_ph.bem_add_1(bevt_80_ta_ph);
bevt_81_ta_ph = bevl_targNp.bemd_0(-1990292643);
bevt_74_ta_ph = bevt_75_ta_ph.bem_add_1(bevt_81_ta_ph);
bevt_73_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_ta_ph, bevl_tcall);
throw new be.BECS_ThrowBack(bevt_73_ta_ph);
} /* Line: 455*/
} /* Line: 452*/
} /* Line: 435*/
} /* Line: 435*/
} /* Line: 431*/
 else /* Line: 410*/ {
bevt_82_ta_ph = bevl_k.bemd_0(1281770511);
if (((BEC_2_5_4_LogicBool) bevt_82_ta_ph).bevi_bool)/* Line: 461*/ {
bevt_85_ta_ph = bevl_k.bemd_0(284720992);
bevt_84_ta_ph = bevt_85_ta_ph.bemd_0(1963473742);
bevt_86_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bemd_1(354557818, bevt_86_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_83_ta_ph).bevi_bool)/* Line: 461*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 461*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 461*/
 else /* Line: 461*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 461*/ {
bevt_90_ta_ph = bevl_k.bemd_0(284720992);
bevt_89_ta_ph = bevt_90_ta_ph.bemd_0(1712678790);
bevt_88_ta_ph = bevt_89_ta_ph.bemd_0(-623202179);
bevt_91_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_87_ta_ph = bevt_88_ta_ph.bemd_1(354557818, bevt_91_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_87_ta_ph).bevi_bool)/* Line: 461*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 461*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 461*/
 else /* Line: 461*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 461*/ {
bevt_95_ta_ph = bevl_k.bemd_0(284720992);
bevt_94_ta_ph = bevt_95_ta_ph.bemd_0(443497498);
bevt_93_ta_ph = bevt_94_ta_ph.bemd_0(1963473742);
bevt_96_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_92_ta_ph = bevt_93_ta_ph.bemd_1(354557818, bevt_96_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_92_ta_ph).bevi_bool)/* Line: 461*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 461*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 461*/
 else /* Line: 461*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 461*/ {
bevt_98_ta_ph = bevl_k.bemd_0(284720992);
bevt_97_ta_ph = bevt_98_ta_ph.bemd_0(443497498);
bevl_targ = bevt_97_ta_ph.bemd_0(1712678790);
bevt_99_ta_ph = bevl_targ.bemd_0(1463424675);
if (((BEC_2_5_4_LogicBool) bevt_99_ta_ph).bevi_bool)/* Line: 464*/ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_100_ta_ph = bevl_targ.bemd_0(1463424675);
bevl_nv.bemd_1(662840365, bevt_100_ta_ph);
bevt_101_ta_ph = bevl_targ.bemd_0(-932925423);
bevl_nv.bemd_1(1082109373, bevt_101_ta_ph);
} /* Line: 469*/
} /* Line: 464*/
} /* Line: 410*/
} /* Line: 410*/
 else /* Line: 409*/ {
break;
} /* Line: 409*/
} /* Line: 409*/
} /* Line: 409*/
} /* Line: 404*/
 else /* Line: 401*/ {
break;
} /* Line: 401*/
} /* Line: 401*/
} /* Line: 401*/
 else /* Line: 399*/ {
break;
} /* Line: 399*/
} /* Line: 399*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGet_0() {
return bevp_tvmap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGetDirect_0() {
return bevp_tvmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tvmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tvmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGet_0() {
return bevp_rmap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGetDirect_0() {
return bevp_rmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGetDirect_0() {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClass = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClass = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGetDirect_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassNp = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassNp = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGetDirect_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassSyn = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassSyn = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGetDirect_0() {
return bevp_nl;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nl = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nl = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGetDirect_0() {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {348, 348, 348, 348, 348, 348, 0, 0, 0, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 0, 0, 0, 350, 0, 0, 0, 352, 352, 352, 352, 352, 352, 352, 352, 352, 0, 0, 0, 353, 353, 353, 353, 354, 354, 355, 355, 355, 355, 355, 355, 355, 355, 355, 357, 358, 358, 358, 358, 359, 359, 361, 361, 362, 362, 362, 362, 367, 367, 367, 367, 368, 369, 369, 370, 370, 372, 372, 372, 372, 373, 374, 375, 375, 375, 375, 375, 375, 0, 0, 0, 376, 376, 376, 376, 377, 377, 377, 378, 378, 379, 380, 380, 380, 382, 383, 383, 383, 383, 383, 383, 383, 0, 0, 0, 383, 383, 383, 383, 0, 0, 0, 383, 383, 383, 383, 383, 383, 0, 0, 0, 385, 387, 387, 391, 400, 401, 401, 402, 404, 404, 407, 408, 409, 0, 409, 409, 410, 410, 410, 410, 410, 0, 0, 0, 410, 410, 410, 410, 410, 0, 0, 0, 410, 410, 410, 410, 410, 0, 0, 0, 412, 412, 413, 414, 414, 414, 414, 415, 415, 417, 417, 421, 421, 422, 424, 424, 424, 424, 424, 427, 428, 431, 431, 433, 434, 434, 434, 434, 435, 435, 437, 438, 438, 438, 0, 0, 0, 439, 441, 442, 444, 444, 446, 446, 447, 447, 447, 448, 448, 448, 448, 448, 448, 448, 448, 450, 450, 450, 450, 451, 451, 451, 452, 452, 452, 452, 452, 452, 0, 0, 0, 453, 453, 453, 455, 455, 455, 455, 455, 455, 455, 455, 455, 455, 461, 461, 461, 461, 461, 0, 0, 0, 461, 461, 461, 461, 461, 0, 0, 0, 461, 461, 461, 461, 461, 0, 0, 0, 462, 462, 462, 464, 466, 468, 468, 469, 469, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {136, 137, 138, 143, 144, 145, 147, 150, 154, 157, 158, 159, 160, 165, 166, 167, 168, 169, 170, 172, 175, 179, 182, 184, 187, 191, 194, 195, 196, 197, 198, 200, 201, 202, 203, 205, 208, 212, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 240, 241, 242, 243, 244, 245, 246, 251, 252, 253, 258, 259, 260, 261, 262, 263, 265, 266, 267, 272, 273, 274, 277, 278, 279, 284, 285, 286, 288, 291, 295, 298, 299, 300, 301, 302, 303, 304, 305, 310, 311, 312, 313, 314, 316, 319, 320, 321, 326, 327, 328, 333, 334, 337, 341, 344, 345, 346, 351, 352, 355, 359, 362, 363, 364, 365, 366, 371, 372, 375, 379, 382, 386, 387, 506, 510, 511, 514, 516, 517, 518, 520, 521, 522, 522, 525, 527, 528, 530, 531, 532, 533, 535, 538, 542, 545, 546, 547, 548, 549, 551, 554, 558, 561, 562, 563, 564, 565, 567, 570, 574, 577, 578, 579, 580, 581, 582, 587, 588, 589, 592, 593, 594, 595, 597, 600, 601, 602, 603, 604, 606, 608, 611, 616, 617, 618, 619, 620, 621, 622, 627, 628, 629, 634, 635, 637, 640, 644, 647, 648, 650, 653, 654, 656, 657, 658, 659, 660, 661, 662, 663, 664, 666, 667, 668, 669, 674, 675, 676, 677, 679, 680, 681, 682, 687, 688, 689, 690, 691, 693, 696, 700, 703, 704, 705, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 724, 726, 727, 728, 729, 731, 734, 738, 741, 742, 743, 744, 745, 747, 750, 754, 757, 758, 759, 760, 761, 763, 766, 770, 773, 774, 775, 776, 778, 779, 780, 781, 782, 805, 808, 811, 815, 819, 822, 825, 829, 833, 836, 839, 843, 847, 850, 853, 857, 861, 864, 867, 871, 875, 878, 881, 885, 889, 892, 895, 899};
/* BEGIN LINEINFO 
assign 1 348 136
typenameGet 0 348 136
assign 1 348 137
CALLGet 0 348 137
assign 1 348 138
equals 1 348 143
assign 1 348 144
heldGet 0 348 144
assign 1 348 145
wasForeachGennedGet 0 348 145
assign 1 0 147
assign 1 0 150
assign 1 0 154
assign 1 350 157
containerGet 0 350 157
assign 1 350 158
typenameGet 0 350 158
assign 1 350 159
CALLGet 0 350 159
assign 1 350 160
equals 1 350 165
assign 1 350 166
containerGet 0 350 166
assign 1 350 167
heldGet 0 350 167
assign 1 350 168
orgNameGet 0 350 168
assign 1 350 169
new 0 350 169
assign 1 350 170
equals 1 350 170
assign 1 0 172
assign 1 0 175
assign 1 0 179
assign 1 350 182
isSecondGet 0 350 182
assign 1 0 184
assign 1 0 187
assign 1 0 191
assign 1 352 194
containedGet 0 352 194
assign 1 352 195
firstGet 0 352 195
assign 1 352 196
typenameGet 0 352 196
assign 1 352 197
VARGet 0 352 197
assign 1 352 198
equals 1 352 198
assign 1 352 200
containedGet 0 352 200
assign 1 352 201
firstGet 0 352 201
assign 1 352 202
heldGet 0 352 202
assign 1 352 203
isTypedGet 0 352 203
assign 1 0 205
assign 1 0 208
assign 1 0 212
assign 1 353 215
containedGet 0 353 215
assign 1 353 216
firstGet 0 353 216
assign 1 353 217
heldGet 0 353 217
assign 1 353 218
namepathGet 0 353 218
assign 1 354 219
stepsGet 0 354 219
assign 1 354 220
lastGet 0 354 220
assign 1 355 221
new 0 355 221
assign 1 355 222
new 0 355 222
assign 1 355 223
substring 2 355 223
assign 1 355 224
lowerValue 0 355 224
assign 1 355 225
new 0 355 225
assign 1 355 226
substring 1 355 226
assign 1 355 227
add 1 355 227
assign 1 355 228
new 0 355 228
assign 1 355 229
add 1 355 229
assign 1 357 230
getSynNp 1 357 230
assign 1 358 231
mtdMapGet 0 358 231
assign 1 358 232
new 0 358 232
assign 1 358 233
add 1 358 233
assign 1 358 234
get 1 358 234
assign 1 359 235
def 1 359 240
assign 1 361 241
heldGet 0 361 241
orgNameSet 1 361 242
assign 1 362 243
heldGet 0 362 243
assign 1 362 244
new 0 362 244
assign 1 362 245
add 1 362 245
nameSet 1 362 246
assign 1 367 251
typenameGet 0 367 251
assign 1 367 252
CLASSGet 0 367 252
assign 1 367 253
equals 1 367 258
assign 1 368 259
assign 1 369 260
heldGet 0 369 260
assign 1 369 261
namepathGet 0 369 261
assign 1 370 262
heldGet 0 370 262
assign 1 370 263
synGet 0 370 263
assign 1 372 265
typenameGet 0 372 265
assign 1 372 266
METHODGet 0 372 266
assign 1 372 267
equals 1 372 272
assign 1 373 273
new 0 373 273
assign 1 374 274
new 0 374 274
assign 1 375 277
typenameGet 0 375 277
assign 1 375 278
VARGet 0 375 278
assign 1 375 279
equals 1 375 284
assign 1 375 285
heldGet 0 375 285
assign 1 375 286
autoTypeGet 0 375 286
assign 1 0 288
assign 1 0 291
assign 1 0 295
assign 1 376 298
heldGet 0 376 298
assign 1 376 299
nameGet 0 376 299
assign 1 376 300
heldGet 0 376 300
put 2 376 301
assign 1 377 302
heldGet 0 377 302
assign 1 377 303
nameGet 0 377 303
assign 1 377 304
get 1 377 304
assign 1 378 305
undef 1 378 310
assign 1 379 311
new 0 379 311
assign 1 380 312
heldGet 0 380 312
assign 1 380 313
nameGet 0 380 313
put 2 380 314
addValue 1 382 316
assign 1 383 319
typenameGet 0 383 319
assign 1 383 320
RBRACESGet 0 383 320
assign 1 383 321
equals 1 383 326
assign 1 383 327
containerGet 0 383 327
assign 1 383 328
def 1 383 333
assign 1 0 334
assign 1 0 337
assign 1 0 341
assign 1 383 344
containerGet 0 383 344
assign 1 383 345
containerGet 0 383 345
assign 1 383 346
def 1 383 351
assign 1 0 352
assign 1 0 355
assign 1 0 359
assign 1 383 362
containerGet 0 383 362
assign 1 383 363
containerGet 0 383 363
assign 1 383 364
typenameGet 0 383 364
assign 1 383 365
METHODGet 0 383 365
assign 1 383 366
equals 1 383 371
assign 1 0 372
assign 1 0 375
assign 1 0 379
processTmps 0 385 382
assign 1 387 386
nextDescendGet 0 387 386
return 1 387 387
assign 1 391 506
new 0 391 506
assign 1 400 510
new 0 400 510
assign 1 401 511
valueIteratorGet 0 401 511
assign 1 401 514
hasNextGet 0 401 514
assign 1 402 516
nextGet 0 402 516
assign 1 404 517
isTypedGet 0 404 517
assign 1 404 518
not 0 404 518
assign 1 407 520
nameGet 0 407 520
assign 1 408 521
get 1 408 521
assign 1 409 522
iteratorGet 0 0 522
assign 1 409 525
hasNextGet 0 409 525
assign 1 409 527
nextGet 0 409 527
assign 1 410 528
isFirstGet 0 410 528
assign 1 410 530
containerGet 0 410 530
assign 1 410 531
typenameGet 0 410 531
assign 1 410 532
CALLGet 0 410 532
assign 1 410 533
equals 1 410 533
assign 1 0 535
assign 1 0 538
assign 1 0 542
assign 1 410 545
containerGet 0 410 545
assign 1 410 546
heldGet 0 410 546
assign 1 410 547
orgNameGet 0 410 547
assign 1 410 548
new 0 410 548
assign 1 410 549
equals 1 410 549
assign 1 0 551
assign 1 0 554
assign 1 0 558
assign 1 410 561
containerGet 0 410 561
assign 1 410 562
secondGet 0 410 562
assign 1 410 563
typenameGet 0 410 563
assign 1 410 564
CALLGet 0 410 564
assign 1 410 565
equals 1 410 565
assign 1 0 567
assign 1 0 570
assign 1 0 574
assign 1 412 577
containerGet 0 412 577
assign 1 412 578
secondGet 0 412 578
assign 1 413 579
assign 1 414 580
heldGet 0 414 580
assign 1 414 581
newNpGet 0 414 581
assign 1 414 582
def 1 414 587
assign 1 415 588
heldGet 0 415 588
assign 1 415 589
newNpGet 0 415 589
assign 1 417 592
containedGet 0 417 592
assign 1 417 593
firstGet 0 417 593
assign 1 421 594
heldGet 0 421 594
assign 1 421 595
isDeclaredGet 0 421 595
assign 1 422 597
heldGet 0 422 597
assign 1 424 600
ptyMapGet 0 424 600
assign 1 424 601
heldGet 0 424 601
assign 1 424 602
nameGet 0 424 602
assign 1 424 603
get 1 424 603
assign 1 424 604
memSynGet 0 424 604
assign 1 427 606
isTypedGet 0 427 606
assign 1 428 608
namepathGet 0 428 608
assign 1 431 611
def 1 431 616
assign 1 433 617
getSynNp 1 433 617
assign 1 434 618
mtdMapGet 0 434 618
assign 1 434 619
heldGet 0 434 619
assign 1 434 620
nameGet 0 434 620
assign 1 434 621
get 1 434 621
assign 1 435 622
def 1 435 627
assign 1 437 628
rsynGet 0 437 628
assign 1 438 629
def 1 438 634
assign 1 438 635
isTypedGet 0 438 635
assign 1 0 637
assign 1 0 640
assign 1 0 644
assign 1 439 647
new 0 439 647
assign 1 441 648
isSelfGet 0 441 648
namepathSet 1 442 650
assign 1 444 653
namepathGet 0 444 653
namepathSet 1 444 654
assign 1 446 656
isTypedGet 0 446 656
isTypedSet 1 446 657
assign 1 447 658
heldGet 0 447 658
assign 1 447 659
namepathGet 0 447 659
addUsed 1 447 660
assign 1 448 661
namepathGet 0 448 661
assign 1 448 662
toString 0 448 662
assign 1 448 663
new 0 448 663
assign 1 448 664
equals 1 448 664
assign 1 448 666
new 0 448 666
assign 1 448 667
isSelfGet 0 448 667
assign 1 448 668
add 1 448 668
print 0 448 669
assign 1 450 674
heldGet 0 450 674
assign 1 450 675
orgNameGet 0 450 675
assign 1 450 676
new 0 450 676
assign 1 450 677
notEquals 1 450 677
assign 1 451 679
mtdMapGet 0 451 679
assign 1 451 680
new 0 451 680
assign 1 451 681
get 1 451 681
assign 1 452 682
def 1 452 687
assign 1 452 688
originGet 0 452 688
assign 1 452 689
toString 0 452 689
assign 1 452 690
new 0 452 690
assign 1 452 691
notEquals 1 452 691
assign 1 0 693
assign 1 0 696
assign 1 0 700
assign 1 453 703
heldGet 0 453 703
assign 1 453 704
new 0 453 704
isForwardSet 1 453 705
assign 1 455 708
new 0 455 708
assign 1 455 709
heldGet 0 455 709
assign 1 455 710
nameGet 0 455 710
assign 1 455 711
add 1 455 711
assign 1 455 712
new 0 455 712
assign 1 455 713
add 1 455 713
assign 1 455 714
toString 0 455 714
assign 1 455 715
add 1 455 715
assign 1 455 716
new 2 455 716
throw 1 455 717
assign 1 461 724
isFirstGet 0 461 724
assign 1 461 726
containerGet 0 461 726
assign 1 461 727
typenameGet 0 461 727
assign 1 461 728
CALLGet 0 461 728
assign 1 461 729
equals 1 461 729
assign 1 0 731
assign 1 0 734
assign 1 0 738
assign 1 461 741
containerGet 0 461 741
assign 1 461 742
heldGet 0 461 742
assign 1 461 743
orgNameGet 0 461 743
assign 1 461 744
new 0 461 744
assign 1 461 745
equals 1 461 745
assign 1 0 747
assign 1 0 750
assign 1 0 754
assign 1 461 757
containerGet 0 461 757
assign 1 461 758
secondGet 0 461 758
assign 1 461 759
typenameGet 0 461 759
assign 1 461 760
VARGet 0 461 760
assign 1 461 761
equals 1 461 761
assign 1 0 763
assign 1 0 766
assign 1 0 770
assign 1 462 773
containerGet 0 462 773
assign 1 462 774
secondGet 0 462 774
assign 1 462 775
heldGet 0 462 775
assign 1 464 776
isTypedGet 0 464 776
assign 1 466 778
new 0 466 778
assign 1 468 779
isTypedGet 0 468 779
isTypedSet 1 468 780
assign 1 469 781
namepathGet 0 469 781
namepathSet 1 469 782
return 1 0 805
return 1 0 808
assign 1 0 811
assign 1 0 815
return 1 0 819
return 1 0 822
assign 1 0 825
assign 1 0 829
return 1 0 833
return 1 0 836
assign 1 0 839
assign 1 0 843
return 1 0 847
return 1 0 850
assign 1 0 853
assign 1 0 857
return 1 0 861
return 1 0 864
assign 1 0 867
assign 1 0 871
return 1 0 875
return 1 0 878
assign 1 0 881
assign 1 0 885
return 1 0 889
return 1 0 892
assign 1 0 895
assign 1 0 899
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1229803830: return bem_deserializeClassNameGet_0();
case 1384423002: return bem_transGet_0();
case -1533701006: return bem_serializeContents_0();
case -1884859936: return bem_inClassSynGetDirect_0();
case -2077773687: return bem_emitterGet_0();
case 1792540121: return bem_tvmapGet_0();
case 1330976730: return bem_hashGet_0();
case -1760434406: return bem_transGetDirect_0();
case -1191535124: return bem_inClassNpGetDirect_0();
case -1217444056: return bem_constGet_0();
case -1593715630: return bem_ntypesGetDirect_0();
case 437089080: return bem_print_0();
case 678368333: return bem_nlGetDirect_0();
case 2041897687: return bem_inClassNpGet_0();
case -160735352: return bem_once_0();
case -764449153: return bem_emitterGetDirect_0();
case 868552696: return bem_rmapGetDirect_0();
case 2066642517: return bem_buildGetDirect_0();
case 907276784: return bem_serializeToString_0();
case 862788409: return bem_buildGet_0();
case -1705055257: return bem_inClassGetDirect_0();
case -1990292643: return bem_toString_0();
case 1208354139: return bem_sourceFileNameGet_0();
case 1882778775: return bem_fieldIteratorGet_0();
case 1674575712: return bem_classNameGet_0();
case -1451048410: return bem_new_0();
case 1335856818: return bem_rmapGet_0();
case 797867737: return bem_ntypesGet_0();
case 1738968438: return bem_inClassSynGet_0();
case -166013833: return bem_tagGet_0();
case 278030248: return bem_constGetDirect_0();
case -1419115955: return bem_create_0();
case 1865983825: return bem_fieldNamesGet_0();
case -206043242: return bem_many_0();
case 872708376: return bem_toAny_0();
case 1200056076: return bem_serializationIteratorGet_0();
case -587206076: return bem_tvmapGetDirect_0();
case -1534460720: return bem_nlGet_0();
case 2017345633: return bem_copy_0();
case 1391274656: return bem_inClassGet_0();
case 48684490: return bem_echo_0();
case 329251961: return bem_processTmps_0();
case -2014542803: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1366190884: return bem_tvmapSet_1(bevd_0);
case 625481528: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -691436434: return bem_begin_1(bevd_0);
case -1306142247: return bem_transSet_1(bevd_0);
case 494759431: return bem_inClassNpSet_1(bevd_0);
case 1561328648: return bem_otherType_1(bevd_0);
case -583950953: return bem_emitterSet_1(bevd_0);
case 1920998617: return bem_sameObject_1(bevd_0);
case 1596863802: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1484567824: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -332644770: return bem_end_1(bevd_0);
case -1517637963: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1948499177: return bem_inClassNpSetDirect_1(bevd_0);
case 272081757: return bem_inClassSet_1(bevd_0);
case 170216407: return bem_copyTo_1(bevd_0);
case 90914731: return bem_rmapSetDirect_1(bevd_0);
case -185383596: return bem_sameType_1(bevd_0);
case -1530407250: return bem_nlSetDirect_1(bevd_0);
case -1890809107: return bem_inClassSetDirect_1(bevd_0);
case 448678910: return bem_ntypesSet_1(bevd_0);
case 584123032: return bem_def_1(bevd_0);
case 354557818: return bem_equals_1(bevd_0);
case -1616094339: return bem_buildSet_1(bevd_0);
case -1255859492: return bem_emitterSetDirect_1(bevd_0);
case 2122176784: return bem_undef_1(bevd_0);
case -840953319: return bem_notEquals_1(bevd_0);
case -1858490504: return bem_rmapSet_1(bevd_0);
case -340249021: return bem_inClassSynSetDirect_1(bevd_0);
case 161134859: return bem_defined_1(bevd_0);
case -1822027791: return bem_otherClass_1(bevd_0);
case -829553391: return bem_inClassSynSet_1(bevd_0);
case 2058785774: return bem_constSet_1(bevd_0);
case 1406812161: return bem_transSetDirect_1(bevd_0);
case 1951809293: return bem_ntypesSetDirect_1(bevd_0);
case -1353297109: return bem_buildSetDirect_1(bevd_0);
case 1153143612: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -279352105: return bem_undefined_1(bevd_0);
case 713581423: return bem_constSetDirect_1(bevd_0);
case 1732176829: return bem_nlSet_1(bevd_0);
case 909810346: return bem_sameClass_1(bevd_0);
case 1212269660: return bem_tvmapSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1467883232: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 465709808: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 936076332: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -758649425: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 105253121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -29810702: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 175222937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitRewind_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitRewind_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitRewind();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst = (BEC_3_5_5_6_BuildVisitRewind) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;
}
}
}
