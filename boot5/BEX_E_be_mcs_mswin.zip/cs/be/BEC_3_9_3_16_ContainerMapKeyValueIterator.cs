namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_16_ContainerMapKeyValueIterator : BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_16_ContainerMapKeyValueIterator() { }
static BEC_3_9_3_16_ContainerMapKeyValueIterator() { }
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x4B,0x65,0x79,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;

public static new BET_3_9_3_16_ContainerMapKeyValueIterator bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;

public BEC_2_6_6_SystemObject bevp_onNode;
public override BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) {
base.bem_new_1(beva__set);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_onNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 606 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 607 */
bevt_2_tmpany_phold = base.bem_hasNextGet_0();
return bevt_2_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_onNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 613 */ {
bevl_toRet = bevp_onNode.bemd_0(1225486227);
bevp_onNode = null;
return bevl_toRet;
} /* Line: 616 */
bevp_onNode = base.bem_nextGet_0();
if (bevp_onNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 619 */ {
bevt_2_tmpany_phold = bevp_onNode.bemd_0(118205241);
return bevt_2_tmpany_phold;
} /* Line: 620 */
return bevp_onNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_onNodeGet_0() {
return bevp_onNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onNodeGetDirect_0() {
return bevp_onNode;
} /*method end*/
public virtual BEC_3_9_3_16_ContainerMapKeyValueIterator bem_onNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onNode = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_onNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onNode = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {602, 606, 606, 607, 607, 609, 609, 613, 613, 614, 615, 616, 618, 619, 619, 620, 620, 622, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 21, 26, 27, 28, 30, 31, 38, 43, 44, 45, 46, 48, 49, 54, 55, 56, 58, 61, 64, 67, 71};
/* BEGIN LINEINFO 
new 1 602 14
assign 1 606 21
def 1 606 26
assign 1 607 27
new 0 607 27
return 1 607 28
assign 1 609 30
hasNextGet 0 609 30
return 1 609 31
assign 1 613 38
def 1 613 43
assign 1 614 44
valueGet 0 614 44
assign 1 615 45
return 1 616 46
assign 1 618 48
nextGet 0 618 48
assign 1 619 49
def 1 619 54
assign 1 620 55
keyGet 0 620 55
return 1 620 56
return 1 622 58
return 1 0 61
return 1 0 64
assign 1 0 67
assign 1 0 71
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1401179497: return bem_slotsGet_0();
case -1201098152: return bem_toAny_0();
case 161140493: return bem_nextGet_0();
case -1796349364: return bem_onNodeGet_0();
case -1681211547: return bem_delete_0();
case -1931415843: return bem_serializeToString_0();
case 1224800076: return bem_once_0();
case 668853581: return bem_moduGetDirect_0();
case 1509106008: return bem_onNodeGetDirect_0();
case -1350845886: return bem_new_0();
case 2134647390: return bem_toString_0();
case 1759428119: return bem_hashGet_0();
case 1686342789: return bem_print_0();
case -768171916: return bem_tagGet_0();
case 2089449732: return bem_fieldIteratorGet_0();
case -863007361: return bem_copy_0();
case 1314392911: return bem_many_0();
case -1631360312: return bem_hasNextGet_0();
case -2086761670: return bem_currentGet_0();
case 1990705765: return bem_serializeContents_0();
case -1294759593: return bem_serializationIteratorGet_0();
case -765261987: return bem_echo_0();
case 1226113552: return bem_create_0();
case -596782621: return bem_iteratorGet_0();
case 2103133023: return bem_currentGetDirect_0();
case 1522098204: return bem_sourceFileNameGet_0();
case -1346552946: return bem_containerGet_0();
case 816581925: return bem_classNameGet_0();
case 1468891202: return bem_deserializeClassNameGet_0();
case -1399602189: return bem_fieldNamesGet_0();
case 1878330533: return bem_slotsGetDirect_0();
case -435550090: return bem_setGetDirect_0();
case 763204594: return bem_setGet_0();
case -1146714610: return bem_nodeIteratorIteratorGet_0();
case 1661623728: return bem_moduGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 26178473: return bem_undefined_1(bevd_0);
case 1904381430: return bem_notEquals_1(bevd_0);
case 510789026: return bem_moduSetDirect_1(bevd_0);
case 1814770497: return bem_def_1(bevd_0);
case 1605172949: return bem_moduSet_1(bevd_0);
case -1241115003: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -54010859: return bem_equals_1(bevd_0);
case -1804962281: return bem_onNodeSetDirect_1(bevd_0);
case -2134954924: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1658273096: return bem_otherType_1(bevd_0);
case -1447916414: return bem_otherClass_1(bevd_0);
case 1544198073: return bem_slotsSet_1(bevd_0);
case -2032446076: return bem_defined_1(bevd_0);
case -1443175505: return bem_currentSet_1(bevd_0);
case 635699530: return bem_copyTo_1(bevd_0);
case -420786779: return bem_slotsSetDirect_1(bevd_0);
case -2083071624: return bem_currentSetDirect_1(bevd_0);
case 1211406823: return bem_sameObject_1(bevd_0);
case -657185622: return bem_setSetDirect_1(bevd_0);
case -1233659066: return bem_onNodeSet_1(bevd_0);
case 354319884: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1036408998: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1286442708: return bem_sameClass_1(bevd_0);
case -2126702146: return bem_sameType_1(bevd_0);
case -524550398: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2003297856: return bem_undef_1(bevd_0);
case 2077350753: return bem_setSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1439296944: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 353482770: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2000867040: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1285224299: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1661650237: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 309149914: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1467313976: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_16_ContainerMapKeyValueIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_16_ContainerMapKeyValueIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst = (BEC_3_9_3_16_ContainerMapKeyValueIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_16_ContainerMapKeyValueIterator.bece_BEC_3_9_3_16_ContainerMapKeyValueIterator_bevs_type;
}
}
}
