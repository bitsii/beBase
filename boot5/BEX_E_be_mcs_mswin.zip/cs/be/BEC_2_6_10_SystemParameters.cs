namespace be {
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
static BEC_2_6_10_SystemParameters() { }
private static byte[] becc_BEC_2_6_10_SystemParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_10_SystemParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_0 = {0x0D,0x0A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_3 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_8 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_1 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_1, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_10 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_2 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_12 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_3 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_3, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_14 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_4 = {0x23,0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_4, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_17 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_5 = {0x23};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_5, 1));
public static new BEC_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_inst;

public static new BET_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_0));
bevp_fileTok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) {
bem_new_0();
bem_addArgs_1(beva__args);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
if (bevp_preProcessor == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevl_ii = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 124 */ {
bevt_7_tmpany_phold = beva__args.bemd_0(-337319865);
bevt_6_tmpany_phold = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_tmpany_phold );
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_9_tmpany_phold = beva__args.bemd_1(-324004617, bevl_ii);
bevt_8_tmpany_phold = bevp_preProcessor.bemd_1(-766127977, bevt_9_tmpany_phold);
beva__args.bemd_2(-33740438, bevl_ii, bevt_8_tmpany_phold);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 124 */
 else  /* Line: 124 */ {
break;
} /* Line: 124 */
} /* Line: 124 */
} /* Line: 124 */
if (bevp_args == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 128 */ {
bevp_args = (BEC_2_9_4_ContainerList) beva__args;
bevp_params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
} /* Line: 131 */
 else  /* Line: 132 */ {
bevp_args = (BEC_2_9_4_ContainerList) bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args );
} /* Line: 133 */
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_loop = beva__args.bemd_0(-461205434);
while (true)
 /* Line: 137 */ {
bevt_11_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 137 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-999307174);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_13_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_14_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_0;
if (bevt_13_tmpany_phold.bevi_int > bevt_14_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 141 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_1;
bevt_16_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_2;
bevl_fa = bevl_i.bem_substring_2(bevt_15_tmpany_phold, bevt_16_tmpany_phold);
bevt_18_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_19_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_3;
if (bevt_18_tmpany_phold.bevi_int > bevt_19_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 143 */ {
bevt_20_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_4;
bevt_21_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_5;
bevl_fb = bevl_i.bem_substring_2(bevt_20_tmpany_phold, bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_24_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_6;
if (bevt_23_tmpany_phold.bevi_int > bevt_24_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 145 */ {
bevt_25_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_7;
bevt_26_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_8;
bevl_fc = bevl_i.bem_substring_2(bevt_25_tmpany_phold, bevt_26_tmpany_phold);
} /* Line: 146 */
} /* Line: 145 */
} /* Line: 143 */
if (bevl_pname == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 150 */ {
if (bevl_pnameComment.bevi_bool) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 151 */ {
bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 152 */
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 155 */
 else  /* Line: 150 */ {
if (bevl_fb == null) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_9;
bevt_30_tmpany_phold = bevl_fb.bem_equals_1(bevt_31_tmpany_phold);
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 156 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 156 */
 else  /* Line: 156 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 156 */ {
bevt_32_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_10;
bevt_33_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
} /* Line: 157 */
 else  /* Line: 150 */ {
if (bevl_fa == null) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevt_36_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_11;
bevt_35_tmpany_phold = bevl_fa.bem_equals_1(bevt_36_tmpany_phold);
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 158 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 158 */
 else  /* Line: 158 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 158 */ {
bevt_37_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_12;
bevt_38_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_37_tmpany_phold, bevt_38_tmpany_phold);
bevt_39_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_13;
bevl_pos = bevl_par.bem_find_1(bevt_39_tmpany_phold);
if (bevl_pos == null) {
bevt_40_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevt_41_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_14;
bevl_key = bevl_par.bem_substring_2(bevt_41_tmpany_phold, bevl_pos);
bevt_43_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_15;
bevt_42_tmpany_phold = bevl_pos.bem_add_1(bevt_43_tmpany_phold);
bevl_value = bevl_par.bem_substring_1(bevt_42_tmpany_phold);
bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 164 */
} /* Line: 161 */
 else  /* Line: 150 */ {
if (bevl_fc == null) {
bevt_44_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_46_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_16;
bevt_45_tmpany_phold = bevl_fc.bem_equals_1(bevt_46_tmpany_phold);
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 166 */
 else  /* Line: 166 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 166 */ {
bevt_47_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_17;
bevt_48_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 168 */
 else  /* Line: 150 */ {
if (bevl_fa == null) {
bevt_49_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_49_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_51_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_18;
bevt_50_tmpany_phold = bevl_fa.bem_equals_1(bevt_51_tmpany_phold);
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 169 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 169 */
 else  /* Line: 169 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 170 */
} /* Line: 150 */
} /* Line: 150 */
} /* Line: 150 */
} /* Line: 150 */
} /* Line: 150 */
 else  /* Line: 137 */ {
break;
} /* Line: 137 */
} /* Line: 137 */
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 177 */ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 178 */ {
bevt_3_tmpany_phold = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 178 */ {
bevt_5_tmpany_phold = bevp_args.bem_get_1(bevl_i);
bevt_4_tmpany_phold = bevp_preProcessor.bemd_1(-766127977, bevt_5_tmpany_phold);
bevp_args.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 178 */
 else  /* Line: 178 */ {
break;
} /* Line: 178 */
} /* Line: 178 */
} /* Line: 178 */
if (bevp_ordered == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 183 */ {
bevt_8_tmpany_phold = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_10_tmpany_phold = bevp_ordered.bem_get_1(bevl_i);
bevt_9_tmpany_phold = bevp_preProcessor.bemd_1(-766127977, bevt_10_tmpany_phold);
bevp_ordered.bem_put_2(bevl_i, bevt_9_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 183 */
 else  /* Line: 183 */ {
break;
} /* Line: 183 */
} /* Line: 183 */
} /* Line: 183 */
if (bevp_params == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevl__params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
 /* Line: 189 */ {
bevt_12_tmpany_phold = bevl_it.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 189 */ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(-999307174);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpany_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 193 */ {
bevt_13_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 193 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevt_14_tmpany_phold = bevp_preProcessor.bemd_1(-766127977, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_tmpany_phold);
} /* Line: 194 */
 else  /* Line: 193 */ {
break;
} /* Line: 193 */
} /* Line: 193 */
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(-766127977, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 197 */
 else  /* Line: 189 */ {
break;
} /* Line: 189 */
} /* Line: 189 */
bevp_params = bevl__params;
} /* Line: 199 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_res = bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 205 */ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 207 */
return beva_isit;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_isTrue_2(beva_name, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_has_1(beva_name);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevl_pl = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 229 */
return bevl_pl;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getFirst_2(beva_name, null);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 240 */ {
return beva_default;
} /* Line: 241 */
bevt_1_tmpany_phold = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 249 */ {
bevl_vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 251 */
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = beva_file.bem_readerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(684860601);
bevl_fcontents = bevt_0_tmpany_phold.bemd_0(-1748667265);
bevt_2_tmpany_phold = beva_file.bem_readerGet_0();
bevt_2_tmpany_phold.bemd_0(26136785);
bevt_3_tmpany_phold = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_tmpany_phold.bemd_0(561995972);
bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_orderedGet_0() {
return bevp_ordered;
} /*method end*/
public BEC_2_9_4_ContainerList bem_orderedGetDirect_0() {
return bevp_ordered;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_orderedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_fileTokGet_0() {
return bevp_fileTok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_fileTokGetDirect_0() {
return bevp_fileTok;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fileTokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_preProcessorGet_0() {
return bevp_preProcessor;
} /*method end*/
public BEC_2_6_6_SystemObject bem_preProcessorGetDirect_0() {
return bevp_preProcessor;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_preProcessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_preProcessor = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {111, 111, 118, 119, 123, 123, 124, 124, 124, 125, 125, 125, 124, 128, 128, 129, 130, 131, 133, 135, 136, 137, 0, 137, 137, 138, 139, 140, 141, 141, 141, 141, 142, 142, 142, 143, 143, 143, 143, 144, 144, 144, 145, 145, 145, 145, 146, 146, 146, 150, 150, 151, 151, 152, 154, 155, 156, 156, 156, 156, 0, 0, 0, 157, 157, 157, 158, 158, 158, 158, 0, 0, 0, 159, 159, 159, 160, 160, 161, 161, 162, 162, 163, 163, 163, 164, 166, 166, 166, 166, 0, 0, 0, 167, 167, 167, 168, 169, 169, 169, 169, 0, 0, 0, 169, 169, 170, 176, 177, 177, 178, 178, 178, 178, 179, 179, 179, 178, 182, 182, 183, 183, 183, 183, 184, 184, 184, 183, 187, 187, 188, 189, 189, 190, 191, 192, 193, 0, 193, 193, 194, 194, 196, 197, 199, 204, 205, 205, 207, 210, 214, 214, 214, 218, 218, 222, 222, 226, 227, 227, 228, 229, 231, 235, 235, 239, 240, 240, 241, 243, 243, 248, 249, 249, 250, 251, 253, 257, 257, 257, 258, 258, 259, 259, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {44, 45, 49, 50, 118, 123, 124, 127, 128, 130, 131, 132, 133, 140, 145, 146, 147, 148, 151, 153, 154, 155, 155, 158, 160, 161, 162, 163, 164, 165, 166, 171, 172, 173, 174, 175, 176, 177, 182, 183, 184, 185, 186, 187, 188, 193, 194, 195, 196, 200, 205, 206, 211, 212, 214, 215, 218, 223, 224, 225, 227, 230, 234, 237, 238, 239, 242, 247, 248, 249, 251, 254, 258, 261, 262, 263, 264, 265, 266, 271, 272, 273, 274, 275, 276, 277, 281, 286, 287, 288, 290, 293, 297, 300, 301, 302, 303, 306, 311, 312, 313, 315, 318, 322, 324, 329, 330, 366, 367, 372, 373, 376, 377, 382, 383, 384, 385, 386, 393, 398, 399, 402, 403, 408, 409, 410, 411, 412, 419, 424, 425, 426, 429, 431, 432, 433, 434, 434, 437, 439, 440, 441, 447, 448, 454, 461, 462, 467, 468, 470, 475, 476, 477, 481, 482, 486, 487, 492, 493, 498, 499, 500, 502, 506, 507, 513, 514, 519, 520, 522, 523, 528, 529, 534, 535, 536, 538, 548, 549, 550, 551, 552, 553, 554, 555, 559, 562, 565, 569, 573, 576, 579, 583, 587, 590, 593, 597, 601, 604, 607, 611, 615, 618, 621};
/* BEGIN LINEINFO 
assign 1 111 44
new 0 111 44
assign 1 111 45
new 1 111 45
new 0 118 49
addArgs 1 119 50
assign 1 123 118
def 1 123 123
assign 1 124 124
new 0 124 124
assign 1 124 127
lengthGet 0 124 127
assign 1 124 128
lesser 1 124 128
assign 1 125 130
get 1 125 130
assign 1 125 131
process 1 125 131
put 2 125 132
assign 1 124 133
increment 0 124 133
assign 1 128 140
undef 1 128 145
assign 1 129 146
assign 1 130 147
new 0 130 147
assign 1 131 148
new 0 131 148
assign 1 133 151
add 1 133 151
assign 1 135 153
assign 1 136 154
new 0 136 154
assign 1 137 155
iteratorGet 0 0 155
assign 1 137 158
hasNextGet 0 137 158
assign 1 137 160
nextGet 0 137 160
assign 1 138 161
assign 1 139 162
assign 1 140 163
assign 1 141 164
sizeGet 0 141 164
assign 1 141 165
new 0 141 165
assign 1 141 166
greater 1 141 171
assign 1 142 172
new 0 142 172
assign 1 142 173
new 0 142 173
assign 1 142 174
substring 2 142 174
assign 1 143 175
sizeGet 0 143 175
assign 1 143 176
new 0 143 176
assign 1 143 177
greater 1 143 182
assign 1 144 183
new 0 144 183
assign 1 144 184
new 0 144 184
assign 1 144 185
substring 2 144 185
assign 1 145 186
sizeGet 0 145 186
assign 1 145 187
new 0 145 187
assign 1 145 188
greater 1 145 193
assign 1 146 194
new 0 146 194
assign 1 146 195
new 0 146 195
assign 1 146 196
substring 2 146 196
assign 1 150 200
def 1 150 205
assign 1 151 206
not 0 151 211
addParameter 2 152 212
assign 1 154 214
assign 1 155 215
new 0 155 215
assign 1 156 218
def 1 156 223
assign 1 156 224
new 0 156 224
assign 1 156 225
equals 1 156 225
assign 1 0 227
assign 1 0 230
assign 1 0 234
assign 1 157 237
new 0 157 237
assign 1 157 238
sizeGet 0 157 238
assign 1 157 239
substring 2 157 239
assign 1 158 242
def 1 158 247
assign 1 158 248
new 0 158 248
assign 1 158 249
equals 1 158 249
assign 1 0 251
assign 1 0 254
assign 1 0 258
assign 1 159 261
new 0 159 261
assign 1 159 262
sizeGet 0 159 262
assign 1 159 263
substring 2 159 263
assign 1 160 264
new 0 160 264
assign 1 160 265
find 1 160 265
assign 1 161 266
def 1 161 271
assign 1 162 272
new 0 162 272
assign 1 162 273
substring 2 162 273
assign 1 163 274
new 0 163 274
assign 1 163 275
add 1 163 275
assign 1 163 276
substring 1 163 276
addParameter 2 164 277
assign 1 166 281
def 1 166 286
assign 1 166 287
new 0 166 287
assign 1 166 288
equals 1 166 288
assign 1 0 290
assign 1 0 293
assign 1 0 297
assign 1 167 300
new 0 167 300
assign 1 167 301
sizeGet 0 167 301
assign 1 167 302
substring 2 167 302
assign 1 168 303
new 0 168 303
assign 1 169 306
def 1 169 311
assign 1 169 312
new 0 169 312
assign 1 169 313
equals 1 169 313
assign 1 0 315
assign 1 0 318
assign 1 0 322
assign 1 169 324
not 0 169 329
addValue 1 170 330
assign 1 176 366
assign 1 177 367
def 1 177 372
assign 1 178 373
new 0 178 373
assign 1 178 376
lengthGet 0 178 376
assign 1 178 377
lesser 1 178 382
assign 1 179 383
get 1 179 383
assign 1 179 384
process 1 179 384
put 2 179 385
assign 1 178 386
increment 0 178 386
assign 1 182 393
def 1 182 398
assign 1 183 399
new 0 183 399
assign 1 183 402
lengthGet 0 183 402
assign 1 183 403
lesser 1 183 408
assign 1 184 409
get 1 184 409
assign 1 184 410
process 1 184 410
put 2 184 411
assign 1 183 412
increment 0 183 412
assign 1 187 419
def 1 187 424
assign 1 188 425
new 0 188 425
assign 1 189 426
keyIteratorGet 0 189 426
assign 1 189 429
hasNextGet 0 189 429
assign 1 190 431
nextGet 0 190 431
assign 1 191 432
get 1 191 432
assign 1 192 433
new 0 192 433
assign 1 193 434
linkedListIteratorGet 0 0 434
assign 1 193 437
hasNextGet 0 193 437
assign 1 193 439
nextGet 0 193 439
assign 1 194 440
process 1 194 440
addValue 1 194 441
assign 1 196 447
process 1 196 447
put 2 197 448
assign 1 199 454
assign 1 204 461
getFirst 1 204 461
assign 1 205 462
def 1 205 467
assign 1 207 468
new 1 207 468
return 1 210 470
assign 1 214 475
new 0 214 475
assign 1 214 476
isTrue 2 214 476
return 1 214 477
assign 1 218 481
has 1 218 481
return 1 218 482
assign 1 222 486
get 1 222 486
return 1 222 487
assign 1 226 492
get 1 226 492
assign 1 227 493
undef 1 227 498
assign 1 228 499
new 0 228 499
addValue 1 229 500
return 1 231 502
assign 1 235 506
getFirst 2 235 506
return 1 235 507
assign 1 239 513
get 1 239 513
assign 1 240 514
undef 1 240 519
return 1 241 520
assign 1 243 522
firstGet 0 243 522
return 1 243 523
assign 1 248 528
get 1 248 528
assign 1 249 529
undef 1 249 534
assign 1 250 535
new 0 250 535
put 2 251 536
addValue 1 253 538
assign 1 257 548
readerGet 0 257 548
assign 1 257 549
open 0 257 549
assign 1 257 550
readString 0 257 550
assign 1 258 551
readerGet 0 258 551
close 0 258 552
assign 1 259 553
tokenize 1 259 553
assign 1 259 554
toList 0 259 554
addArgs 1 260 555
return 1 0 559
return 1 0 562
assign 1 0 565
assign 1 0 569
return 1 0 573
return 1 0 576
assign 1 0 579
assign 1 0 583
return 1 0 587
return 1 0 590
assign 1 0 593
assign 1 0 597
return 1 0 601
return 1 0 604
assign 1 0 607
assign 1 0 611
return 1 0 615
return 1 0 618
assign 1 0 621
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1358016112: return bem_argsGet_0();
case -1431960617: return bem_many_0();
case -1051263431: return bem_create_0();
case -872332340: return bem_paramsGetDirect_0();
case 1375519361: return bem_sourceFileNameGet_0();
case 1156921009: return bem_toString_0();
case -461205434: return bem_iteratorGet_0();
case -1581666253: return bem_new_0();
case -539277844: return bem_fieldIteratorGet_0();
case 1947173801: return bem_print_0();
case -182215192: return bem_serializationIteratorGet_0();
case 464610233: return bem_once_0();
case 1969869774: return bem_echo_0();
case 874503493: return bem_serializeToString_0();
case 1116633813: return bem_argsGetDirect_0();
case -1152406013: return bem_orderedGetDirect_0();
case 580319188: return bem_fileTokGetDirect_0();
case -654415539: return bem_tagGet_0();
case 2077890793: return bem_orderedGet_0();
case 49134257: return bem_hashGet_0();
case -1747498826: return bem_classNameGet_0();
case -126683907: return bem_fileTokGet_0();
case 1344196413: return bem_preProcessorGet_0();
case 941172865: return bem_serializeContents_0();
case 1205179000: return bem_deserializeClassNameGet_0();
case 1512772474: return bem_copy_0();
case -1881857451: return bem_paramsGet_0();
case 1881939406: return bem_fieldNamesGet_0();
case 1152775717: return bem_preProcessorGetDirect_0();
case 322540171: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 243162876: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 447923928: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 38981322: return bem_orderedSet_1(bevd_0);
case -2144078956: return bem_paramsSet_1(bevd_0);
case -1940703752: return bem_copyTo_1(bevd_0);
case 372746140: return bem_sameType_1(bevd_0);
case -2016169338: return bem_fileTokSet_1(bevd_0);
case 663136702: return bem_orderedSetDirect_1(bevd_0);
case 1779380050: return bem_undefined_1(bevd_0);
case -2144028250: return bem_argsSet_1(bevd_0);
case -373658986: return bem_equals_1(bevd_0);
case -1264044693: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -653588721: return bem_otherType_1(bevd_0);
case -498298486: return bem_sameObject_1(bevd_0);
case 1966156517: return bem_otherClass_1(bevd_0);
case 1897144316: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case -116786245: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
case 415073118: return bem_paramsSetDirect_1(bevd_0);
case 778331504: return bem_def_1(bevd_0);
case 1817351105: return bem_defined_1(bevd_0);
case -1405212164: return bem_sameClass_1(bevd_0);
case 2125870571: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case -1863819212: return bem_preProcessorSet_1(bevd_0);
case -1295446558: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1089354598: return bem_undef_1(bevd_0);
case 1491890607: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 2118688674: return bem_addArgs_1(bevd_0);
case -1974697659: return bem_fileTokSetDirect_1(bevd_0);
case -1499911921: return bem_notEquals_1(bevd_0);
case 75623957: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
case -324004617: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 614039171: return bem_preProcessorSetDirect_1(bevd_0);
case 204668710: return bem_argsSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 193506539: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1129259785: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1170601676: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 888716978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1842235085: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 414389553: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -292360250: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1714613573: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1507774776: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 614290015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 615004681: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemParameters_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_10_SystemParameters_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemParameters();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst = (BEC_2_6_10_SystemParameters) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_type;
}
}
}
