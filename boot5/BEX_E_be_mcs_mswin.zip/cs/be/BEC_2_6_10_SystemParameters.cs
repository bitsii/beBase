namespace be {
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
static BEC_2_6_10_SystemParameters() { }
private static byte[] becc_BEC_2_6_10_SystemParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_10_SystemParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_0 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_1 = {0x61,0x72,0x67,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_2 = {0x70,0x61,0x72,0x61,0x6D,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_3 = {0x6F,0x72,0x64,0x65,0x72,0x65,0x64};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_4 = {0x2D,0x2D};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_5 = {0x2D};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_6 = {0x3D};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_7 = {0x23,0x2D,0x2D};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_8 = {0x23};
public static new BEC_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_inst;

public static new BET_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_initialArgs;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevp_initialArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_args = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_0));
bevp_fileTok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toJson_0() {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_9_4_ContainerMaps bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_10_JsonMarshaller bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject[] bevd_x = new BEC_2_6_6_SystemObject[7];
bevt_0_ta_ph = (BEC_2_9_4_ContainerMaps) BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_6_10_SystemParameters_bels_1));
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_6_10_SystemParameters_bels_2));
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_10_SystemParameters_bels_3));
bevd_x[0] = bevt_1_ta_ph;
bevd_x[1] = bevp_args;
bevd_x[2] = bevt_2_ta_ph;
bevd_x[3] = bevp_params;
bevd_x[4] = bevt_3_ta_ph;
bevd_x[5] = bevp_ordered;
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_ta_ph.bems_forwardCallCp(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes("from")), new BEC_2_9_4_ContainerList(bevd_x, 6));
bevt_5_ta_ph = (BEC_2_4_10_JsonMarshaller) (new BEC_2_4_10_JsonMarshaller()).bem_new_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_marshall_1(bevl_jsm);
return bevt_4_ta_ph;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fromJson_1(BEC_2_4_6_TextString beva_jsms) {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_4_12_JsonUnmarshaller bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_12_JsonUnmarshaller) (new BEC_2_4_12_JsonUnmarshaller()).bem_new_0();
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_ta_ph.bem_unmarshall_1(beva_jsms);
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_6_10_SystemParameters_bels_1));
bevp_args = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_1_ta_ph);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_6_10_SystemParameters_bels_2));
bevp_params = (BEC_2_9_3_ContainerMap) bevl_jsm.bem_get_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_10_SystemParameters_bels_3));
bevp_ordered = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_3_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fromJsonFile_1(BEC_2_2_4_IOFile beva_jsf) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevt_2_ta_ph = beva_jsf.bem_readerGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-476757857);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1271275320);
bem_fromJson_1((BEC_2_4_6_TextString) bevt_0_ta_ph );
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_toJsonFile_1(BEC_2_2_4_IOFile beva_jsf) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = beva_jsf.bem_writerGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-476757857);
bevt_2_ta_ph = bem_toJson_0();
bevt_0_ta_ph.bemd_1(784935608, bevt_2_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addValue_1(BEC_2_6_10_SystemParameters beva_p) {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_9_10_ContainerLinkedList bevl_cp = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_9_4_ContainerList bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
bevt_1_ta_ph = beva_p.bem_argsGet_0();
bevp_args.bem_addValue_1(bevt_1_ta_ph);
bevt_2_ta_ph = beva_p.bem_orderedGet_0();
bevp_ordered.bem_addValue_1(bevt_2_ta_ph);
bevt_3_ta_ph = beva_p.bem_paramsGet_0();
bevt_0_ta_loop = bevt_3_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 140*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 140*/ {
bevl_kv = bevt_0_ta_loop.bemd_0(-641452021);
bevt_5_ta_ph = bevl_kv.bemd_0(-120746800);
bevl_cp = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevt_5_ta_ph);
if (bevl_cp == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 142*/ {
bevt_7_ta_ph = bevl_kv.bemd_0(-890301597);
bevl_cp.bem_addValue_1(bevt_7_ta_ph);
} /* Line: 143*/
 else /* Line: 144*/ {
bevt_8_ta_ph = bevl_kv.bemd_0(-120746800);
bevt_9_ta_ph = bevl_kv.bemd_0(-890301597);
bevp_params.bem_put_2(bevt_8_ta_ph, bevt_9_ta_ph);
} /* Line: 145*/
} /* Line: 142*/
 else /* Line: 140*/ {
break;
} /* Line: 140*/
} /* Line: 140*/
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) {
bem_new_0();
bevp_initialArgs = beva__args;
bem_addArgs_1(beva__args);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_3_MathInt bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
if (bevp_preProcessor == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 157*/ {
bevl_ii = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 158*/ {
bevt_7_ta_ph = beva__args.bemd_0(372427837);
bevt_6_ta_ph = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_ta_ph );
if (bevt_6_ta_ph.bevi_bool)/* Line: 158*/ {
bevt_9_ta_ph = beva__args.bemd_1(-1267929220, bevl_ii);
bevt_8_ta_ph = bevp_preProcessor.bemd_1(193476437, bevt_9_ta_ph);
beva__args.bemd_2(1920178007, bevl_ii, bevt_8_ta_ph);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 158*/
 else /* Line: 158*/ {
break;
} /* Line: 158*/
} /* Line: 158*/
} /* Line: 158*/
bevp_args = (BEC_2_9_4_ContainerList) bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args );
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_ta_loop = beva__args.bemd_0(-71162589);
while (true)
/* Line: 165*/ {
bevt_10_ta_ph = bevt_0_ta_loop.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 165*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-641452021);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_12_ta_ph = bevl_i.bem_sizeGet_0();
bevt_13_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevt_12_ta_ph.bevi_int > bevt_13_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 169*/ {
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_15_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_fa = bevl_i.bem_substring_2(bevt_14_ta_ph, bevt_15_ta_ph);
bevt_17_ta_ph = bevl_i.bem_sizeGet_0();
bevt_18_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_17_ta_ph.bevi_int > bevt_18_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 171*/ {
bevt_19_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_20_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_fb = bevl_i.bem_substring_2(bevt_19_ta_ph, bevt_20_ta_ph);
bevt_22_ta_ph = bevl_i.bem_sizeGet_0();
bevt_23_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
if (bevt_22_ta_ph.bevi_int > bevt_23_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 173*/ {
bevt_24_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_25_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevl_fc = bevl_i.bem_substring_2(bevt_24_ta_ph, bevt_25_ta_ph);
} /* Line: 174*/
} /* Line: 173*/
} /* Line: 171*/
if (bevl_pname == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 178*/ {
if (bevl_pnameComment.bevi_bool) {
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 179*/ {
bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 180*/
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 183*/
 else /* Line: 178*/ {
if (bevl_fb == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 184*/ {
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_4));
bevt_29_ta_ph = bevl_fb.bem_equals_1(bevt_30_ta_ph);
if (bevt_29_ta_ph.bevi_bool)/* Line: 184*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 184*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 184*/
 else /* Line: 184*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 184*/ {
bevt_31_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_32_ta_ph = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_31_ta_ph, bevt_32_ta_ph);
} /* Line: 185*/
 else /* Line: 178*/ {
if (bevl_fa == null) {
bevt_33_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_33_ta_ph.bevi_bool)/* Line: 186*/ {
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemParameters_bels_5));
bevt_34_ta_ph = bevl_fa.bem_equals_1(bevt_35_ta_ph);
if (bevt_34_ta_ph.bevi_bool)/* Line: 186*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 186*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 186*/
 else /* Line: 186*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 186*/ {
bevt_36_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_37_ta_ph = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_36_ta_ph, bevt_37_ta_ph);
bevt_38_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemParameters_bels_6));
bevl_pos = bevl_par.bem_find_1(bevt_38_ta_ph);
if (bevl_pos == null) {
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 189*/ {
bevt_40_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_key = bevl_par.bem_substring_2(bevt_40_ta_ph, bevl_pos);
bevt_42_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_41_ta_ph = bevl_pos.bem_add_1(bevt_42_ta_ph);
bevl_value = bevl_par.bem_substring_1(bevt_41_ta_ph);
bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 192*/
} /* Line: 189*/
 else /* Line: 178*/ {
if (bevl_fc == null) {
bevt_43_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_43_ta_ph.bevi_bool)/* Line: 194*/ {
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_6_10_SystemParameters_bels_7));
bevt_44_ta_ph = bevl_fc.bem_equals_1(bevt_45_ta_ph);
if (bevt_44_ta_ph.bevi_bool)/* Line: 194*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 194*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 194*/
 else /* Line: 194*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 194*/ {
bevt_46_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevt_47_ta_ph = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_46_ta_ph, bevt_47_ta_ph);
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 196*/
 else /* Line: 178*/ {
if (bevl_fa == null) {
bevt_48_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_48_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_48_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_50_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemParameters_bels_8));
bevt_49_ta_ph = bevl_fa.bem_equals_1(bevt_50_ta_ph);
if (bevt_49_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 197*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 197*/
 else /* Line: 197*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool) {
bevt_51_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_51_ta_ph.bevi_bool)/* Line: 197*/ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 198*/
} /* Line: 178*/
} /* Line: 178*/
} /* Line: 178*/
} /* Line: 178*/
} /* Line: 178*/
 else /* Line: 165*/ {
break;
} /* Line: 165*/
} /* Line: 165*/
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 205*/ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 206*/ {
bevt_3_ta_ph = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 206*/ {
bevt_5_ta_ph = bevp_args.bem_get_1(bevl_i);
bevt_4_ta_ph = bevp_preProcessor.bemd_1(193476437, bevt_5_ta_ph);
bevp_args.bem_put_2(bevl_i, bevt_4_ta_ph);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 206*/
 else /* Line: 206*/ {
break;
} /* Line: 206*/
} /* Line: 206*/
} /* Line: 206*/
if (bevp_ordered == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 210*/ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 211*/ {
bevt_8_ta_ph = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 211*/ {
bevt_10_ta_ph = bevp_ordered.bem_get_1(bevl_i);
bevt_9_ta_ph = bevp_preProcessor.bemd_1(193476437, bevt_10_ta_ph);
bevp_ordered.bem_put_2(bevl_i, bevt_9_ta_ph);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 211*/
 else /* Line: 211*/ {
break;
} /* Line: 211*/
} /* Line: 211*/
} /* Line: 211*/
if (bevp_params == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 215*/ {
bevl__params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
/* Line: 217*/ {
bevt_12_ta_ph = bevl_it.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 217*/ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(-641452021);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_ta_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
/* Line: 221*/ {
bevt_13_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 221*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevt_14_ta_ph = bevp_preProcessor.bemd_1(193476437, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_ta_ph);
} /* Line: 222*/
 else /* Line: 221*/ {
break;
} /* Line: 221*/
} /* Line: 221*/
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(193476437, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 225*/
 else /* Line: 217*/ {
break;
} /* Line: 217*/
} /* Line: 217*/
bevp_params = bevl__params;
} /* Line: 227*/
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_res = bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 233*/ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 235*/
return beva_isit;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_ta_ph = bem_isTrue_2(beva_name, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_params.bem_has_1(beva_name);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 255*/ {
bevl_pl = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 257*/
return bevl_pl;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getFirst_2(beva_name, null);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 268*/ {
return beva_default;
} /* Line: 269*/
bevt_1_ta_ph = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_ta_ph;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) {
bem_addParam_2(beva_name, beva_value);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addParam_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 281*/ {
bevl_vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 283*/
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = beva_file.bem_readerGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-476757857);
bevl_fcontents = bevt_0_ta_ph.bemd_0(-1751369017);
bevt_2_ta_ph = beva_file.bem_readerGet_0();
bevt_2_ta_ph.bemd_0(-645051051);
bevt_3_ta_ph = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_ta_ph.bemd_0(-1441490037);
bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_params.bem_iteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_initialArgsGet_0() {
return bevp_initialArgs;
} /*method end*/
public BEC_2_9_4_ContainerList bem_initialArgsGetDirect_0() {
return bevp_initialArgs;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_initialArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_initialArgs = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_initialArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_initialArgs = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_orderedGet_0() {
return bevp_ordered;
} /*method end*/
public BEC_2_9_4_ContainerList bem_orderedGetDirect_0() {
return bevp_ordered;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_orderedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_fileTokGet_0() {
return bevp_fileTok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_fileTokGetDirect_0() {
return bevp_fileTok;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fileTokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_preProcessorGet_0() {
return bevp_preProcessor;
} /*method end*/
public BEC_2_6_6_SystemObject bem_preProcessorGetDirect_0() {
return bevp_preProcessor;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_preProcessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_preProcessor = bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {107, 108, 109, 110, 111, 111, 118, 118, 118, 118, 118, 119, 119, 119, 123, 123, 124, 124, 125, 125, 126, 126, 130, 130, 130, 130, 134, 134, 134, 134, 138, 138, 139, 139, 140, 140, 0, 140, 140, 141, 141, 142, 142, 143, 143, 145, 145, 145, 151, 152, 153, 157, 157, 158, 158, 158, 159, 159, 159, 158, 162, 163, 164, 165, 0, 165, 165, 166, 167, 168, 169, 169, 169, 169, 170, 170, 170, 171, 171, 171, 171, 172, 172, 172, 173, 173, 173, 173, 174, 174, 174, 178, 178, 179, 179, 180, 182, 183, 184, 184, 184, 184, 0, 0, 0, 185, 185, 185, 186, 186, 186, 186, 0, 0, 0, 187, 187, 187, 188, 188, 189, 189, 190, 190, 191, 191, 191, 192, 194, 194, 194, 194, 0, 0, 0, 195, 195, 195, 196, 197, 197, 197, 197, 0, 0, 0, 197, 197, 198, 204, 205, 205, 206, 206, 206, 206, 207, 207, 207, 206, 210, 210, 211, 211, 211, 211, 212, 212, 212, 211, 215, 215, 216, 217, 217, 218, 219, 220, 221, 0, 221, 221, 222, 222, 224, 225, 227, 232, 233, 233, 235, 238, 242, 242, 242, 246, 246, 250, 250, 254, 255, 255, 256, 257, 259, 263, 263, 267, 268, 268, 269, 271, 271, 275, 280, 281, 281, 282, 283, 285, 290, 290, 290, 291, 291, 292, 292, 293, 297, 297, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {29, 30, 31, 32, 33, 34, 46, 47, 48, 49, 50, 57, 58, 59, 67, 68, 69, 70, 71, 72, 73, 74, 81, 82, 83, 84, 91, 92, 93, 94, 110, 111, 112, 113, 114, 115, 115, 118, 120, 121, 122, 123, 128, 129, 130, 133, 134, 135, 145, 146, 147, 214, 219, 220, 223, 224, 226, 227, 228, 229, 236, 237, 238, 239, 239, 242, 244, 245, 246, 247, 248, 249, 250, 255, 256, 257, 258, 259, 260, 261, 266, 267, 268, 269, 270, 271, 272, 277, 278, 279, 280, 284, 289, 290, 295, 296, 298, 299, 302, 307, 308, 309, 311, 314, 318, 321, 322, 323, 326, 331, 332, 333, 335, 338, 342, 345, 346, 347, 348, 349, 350, 355, 356, 357, 358, 359, 360, 361, 365, 370, 371, 372, 374, 377, 381, 384, 385, 386, 387, 390, 395, 396, 397, 399, 402, 406, 408, 413, 414, 450, 451, 456, 457, 460, 461, 466, 467, 468, 469, 470, 477, 482, 483, 486, 487, 492, 493, 494, 495, 496, 503, 508, 509, 510, 513, 515, 516, 517, 518, 518, 521, 523, 524, 525, 531, 532, 538, 545, 546, 551, 552, 554, 559, 560, 561, 565, 566, 570, 571, 576, 577, 582, 583, 584, 586, 590, 591, 597, 598, 603, 604, 606, 607, 610, 616, 617, 622, 623, 624, 626, 636, 637, 638, 639, 640, 641, 642, 643, 648, 649, 652, 655, 658, 662, 666, 669, 672, 676, 680, 683, 686, 690, 694, 697, 700, 704, 708, 711, 714, 718, 722, 725, 728};
/* BEGIN LINEINFO 
assign 1 107 29
new 0 107 29
assign 1 108 30
new 0 108 30
assign 1 109 31
new 0 109 31
assign 1 110 32
new 0 110 32
assign 1 111 33
new 0 111 33
assign 1 111 34
new 1 111 34
assign 1 118 46
new 0 118 46
assign 1 118 47
new 0 118 47
assign 1 118 48
new 0 118 48
assign 1 118 49
new 0 118 49
assign 1 118 50
from 6 118 50
assign 1 119 57
new 0 119 57
assign 1 119 58
marshall 1 119 58
return 1 119 59
assign 1 123 67
new 0 123 67
assign 1 123 68
unmarshall 1 123 68
assign 1 124 69
new 0 124 69
assign 1 124 70
get 1 124 70
assign 1 125 71
new 0 125 71
assign 1 125 72
get 1 125 72
assign 1 126 73
new 0 126 73
assign 1 126 74
get 1 126 74
assign 1 130 81
readerGet 0 130 81
assign 1 130 82
open 0 130 82
assign 1 130 83
readStringClose 0 130 83
fromJson 1 130 84
assign 1 134 91
writerGet 0 134 91
assign 1 134 92
open 0 134 92
assign 1 134 93
toJson 0 134 93
writeStringClose 1 134 94
assign 1 138 110
argsGet 0 138 110
addValue 1 138 111
assign 1 139 112
orderedGet 0 139 112
addValue 1 139 113
assign 1 140 114
paramsGet 0 140 114
assign 1 140 115
iteratorGet 0 0 115
assign 1 140 118
hasNextGet 0 140 118
assign 1 140 120
nextGet 0 140 120
assign 1 141 121
keyGet 0 141 121
assign 1 141 122
get 1 141 122
assign 1 142 123
def 1 142 128
assign 1 143 129
valueGet 0 143 129
addValue 1 143 130
assign 1 145 133
keyGet 0 145 133
assign 1 145 134
valueGet 0 145 134
put 2 145 135
new 0 151 145
assign 1 152 146
addArgs 1 153 147
assign 1 157 214
def 1 157 219
assign 1 158 220
new 0 158 220
assign 1 158 223
lengthGet 0 158 223
assign 1 158 224
lesser 1 158 224
assign 1 159 226
get 1 159 226
assign 1 159 227
process 1 159 227
put 2 159 228
assign 1 158 229
increment 0 158 229
assign 1 162 236
add 1 162 236
assign 1 163 237
assign 1 164 238
new 0 164 238
assign 1 165 239
iteratorGet 0 0 239
assign 1 165 242
hasNextGet 0 165 242
assign 1 165 244
nextGet 0 165 244
assign 1 166 245
assign 1 167 246
assign 1 168 247
assign 1 169 248
sizeGet 0 169 248
assign 1 169 249
new 0 169 249
assign 1 169 250
greater 1 169 255
assign 1 170 256
new 0 170 256
assign 1 170 257
new 0 170 257
assign 1 170 258
substring 2 170 258
assign 1 171 259
sizeGet 0 171 259
assign 1 171 260
new 0 171 260
assign 1 171 261
greater 1 171 266
assign 1 172 267
new 0 172 267
assign 1 172 268
new 0 172 268
assign 1 172 269
substring 2 172 269
assign 1 173 270
sizeGet 0 173 270
assign 1 173 271
new 0 173 271
assign 1 173 272
greater 1 173 277
assign 1 174 278
new 0 174 278
assign 1 174 279
new 0 174 279
assign 1 174 280
substring 2 174 280
assign 1 178 284
def 1 178 289
assign 1 179 290
not 0 179 295
addParameter 2 180 296
assign 1 182 298
assign 1 183 299
new 0 183 299
assign 1 184 302
def 1 184 307
assign 1 184 308
new 0 184 308
assign 1 184 309
equals 1 184 309
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 185 321
new 0 185 321
assign 1 185 322
sizeGet 0 185 322
assign 1 185 323
substring 2 185 323
assign 1 186 326
def 1 186 331
assign 1 186 332
new 0 186 332
assign 1 186 333
equals 1 186 333
assign 1 0 335
assign 1 0 338
assign 1 0 342
assign 1 187 345
new 0 187 345
assign 1 187 346
sizeGet 0 187 346
assign 1 187 347
substring 2 187 347
assign 1 188 348
new 0 188 348
assign 1 188 349
find 1 188 349
assign 1 189 350
def 1 189 355
assign 1 190 356
new 0 190 356
assign 1 190 357
substring 2 190 357
assign 1 191 358
new 0 191 358
assign 1 191 359
add 1 191 359
assign 1 191 360
substring 1 191 360
addParameter 2 192 361
assign 1 194 365
def 1 194 370
assign 1 194 371
new 0 194 371
assign 1 194 372
equals 1 194 372
assign 1 0 374
assign 1 0 377
assign 1 0 381
assign 1 195 384
new 0 195 384
assign 1 195 385
sizeGet 0 195 385
assign 1 195 386
substring 2 195 386
assign 1 196 387
new 0 196 387
assign 1 197 390
def 1 197 395
assign 1 197 396
new 0 197 396
assign 1 197 397
equals 1 197 397
assign 1 0 399
assign 1 0 402
assign 1 0 406
assign 1 197 408
not 0 197 413
addValue 1 198 414
assign 1 204 450
assign 1 205 451
def 1 205 456
assign 1 206 457
new 0 206 457
assign 1 206 460
lengthGet 0 206 460
assign 1 206 461
lesser 1 206 466
assign 1 207 467
get 1 207 467
assign 1 207 468
process 1 207 468
put 2 207 469
assign 1 206 470
increment 0 206 470
assign 1 210 477
def 1 210 482
assign 1 211 483
new 0 211 483
assign 1 211 486
lengthGet 0 211 486
assign 1 211 487
lesser 1 211 492
assign 1 212 493
get 1 212 493
assign 1 212 494
process 1 212 494
put 2 212 495
assign 1 211 496
increment 0 211 496
assign 1 215 503
def 1 215 508
assign 1 216 509
new 0 216 509
assign 1 217 510
keyIteratorGet 0 217 510
assign 1 217 513
hasNextGet 0 217 513
assign 1 218 515
nextGet 0 218 515
assign 1 219 516
get 1 219 516
assign 1 220 517
new 0 220 517
assign 1 221 518
linkedListIteratorGet 0 0 518
assign 1 221 521
hasNextGet 0 221 521
assign 1 221 523
nextGet 0 221 523
assign 1 222 524
process 1 222 524
addValue 1 222 525
assign 1 224 531
process 1 224 531
put 2 225 532
assign 1 227 538
assign 1 232 545
getFirst 1 232 545
assign 1 233 546
def 1 233 551
assign 1 235 552
new 1 235 552
return 1 238 554
assign 1 242 559
new 0 242 559
assign 1 242 560
isTrue 2 242 560
return 1 242 561
assign 1 246 565
has 1 246 565
return 1 246 566
assign 1 250 570
get 1 250 570
return 1 250 571
assign 1 254 576
get 1 254 576
assign 1 255 577
undef 1 255 582
assign 1 256 583
new 0 256 583
addValue 1 257 584
return 1 259 586
assign 1 263 590
getFirst 2 263 590
return 1 263 591
assign 1 267 597
get 1 267 597
assign 1 268 598
undef 1 268 603
return 1 269 604
assign 1 271 606
firstGet 0 271 606
return 1 271 607
addParam 2 275 610
assign 1 280 616
get 1 280 616
assign 1 281 617
undef 1 281 622
assign 1 282 623
new 0 282 623
put 2 283 624
addValue 1 285 626
assign 1 290 636
readerGet 0 290 636
assign 1 290 637
open 0 290 637
assign 1 290 638
readString 0 290 638
assign 1 291 639
readerGet 0 291 639
close 0 291 640
assign 1 292 641
tokenize 1 292 641
assign 1 292 642
toList 0 292 642
addArgs 1 293 643
assign 1 297 648
iteratorGet 0 297 648
return 1 297 649
return 1 0 652
return 1 0 655
assign 1 0 658
assign 1 0 662
return 1 0 666
return 1 0 669
assign 1 0 672
assign 1 0 676
return 1 0 680
return 1 0 683
assign 1 0 686
assign 1 0 690
return 1 0 694
return 1 0 697
assign 1 0 700
assign 1 0 704
return 1 0 708
return 1 0 711
assign 1 0 714
assign 1 0 718
return 1 0 722
return 1 0 725
assign 1 0 728
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 931409870: return bem_fileTokGet_0();
case -1642361296: return bem_print_0();
case 1161638424: return bem_new_0();
case 173395416: return bem_argsGetDirect_0();
case 168135582: return bem_create_0();
case 759496930: return bem_tagGet_0();
case 1292559786: return bem_paramsGet_0();
case -1720405868: return bem_preProcessorGet_0();
case 814334258: return bem_serializeContents_0();
case -1836040566: return bem_initialArgsGet_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 709758977: return bem_toJson_0();
case 867768075: return bem_argsGet_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -71162589: return bem_iteratorGet_0();
case -657619679: return bem_paramsGetDirect_0();
case 944073339: return bem_fieldIteratorGet_0();
case 2132420479: return bem_many_0();
case 1365897346: return bem_serializationIteratorGet_0();
case -1480556491: return bem_toAny_0();
case -202912463: return bem_copy_0();
case 350691792: return bem_toString_0();
case -1032141079: return bem_orderedGet_0();
case -1044758745: return bem_serializeToString_0();
case 2064925791: return bem_echo_0();
case -1711670377: return bem_hashGet_0();
case -307215531: return bem_initialArgsGetDirect_0();
case -1359614197: return bem_classNameGet_0();
case -407617335: return bem_orderedGetDirect_0();
case -1785724794: return bem_once_0();
case 1867217275: return bem_fileTokGetDirect_0();
case -652053502: return bem_fieldNamesGet_0();
case 58053887: return bem_preProcessorGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -844245022: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1209889694: return bem_paramsSetDirect_1(bevd_0);
case 1827485140: return bem_argsSetDirect_1(bevd_0);
case -1214541120: return bem_argsSet_1(bevd_0);
case -709481923: return bem_fileTokSet_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case 983050663: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1628522769: return bem_addValue_1((BEC_2_6_10_SystemParameters) bevd_0);
case -1424067020: return bem_preProcessorSetDirect_1(bevd_0);
case 215182947: return bem_fromJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case 623593862: return bem_fromJson_1((BEC_2_4_6_TextString) bevd_0);
case 411940460: return bem_initialArgsSetDirect_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case -1726097078: return bem_initialArgsSet_1(bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case -176866672: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -853802596: return bem_orderedSet_1(bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case -419891485: return bem_toJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1995613039: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case -215117342: return bem_preProcessorSet_1(bevd_0);
case -1015869565: return bem_orderedSetDirect_1(bevd_0);
case -979605925: return bem_paramsSet_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -1304536467: return bem_fileTokSetDirect_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case -1267929220: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -687582790: return bem_addArgs_1(bevd_0);
case -1829001662: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1173444547: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -114207976: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1807478794: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1024289165: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1151140058: return bem_addParam_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemParameters_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_10_SystemParameters_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemParameters();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst = (BEC_2_6_10_SystemParameters) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_type;
}
}
}
