namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_17_ContainerSetIdentityRelations : BEC_3_9_3_9_ContainerSetRelations {
public BEC_3_9_3_17_ContainerSetIdentityRelations() { }
static BEC_3_9_3_17_ContainerSetIdentityRelations() { }
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x52,0x65,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;

public static new BET_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_type;

public override BEC_2_6_6_SystemObject bem_getHash_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_k.bemd_0(721123821);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_isEqual_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_l) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_k.bemd_1(-690535851, beva_l);
return bevt_0_ta_ph;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {78, 78, 82, 82};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20};
/* BEGIN LINEINFO 
assign 1 78 14
tagGet 0 78 14
return 1 78 15
assign 1 82 19
sameObject 1 82 19
return 1 82 20
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1151085267: return bem_deserializeClassNameGet_0();
case 721123821: return bem_tagGet_0();
case 19210432: return bem_iteratorGet_0();
case 1597530459: return bem_print_0();
case 559255035: return bem_fieldNamesGet_0();
case -860520942: return bem_toString_0();
case 216633460: return bem_serializeContents_0();
case 1291824271: return bem_echo_0();
case 595935693: return bem_create_0();
case -390286916: return bem_serializeToString_0();
case -1869924457: return bem_sourceFileNameGet_0();
case 270781002: return bem_new_0();
case -827080774: return bem_copy_0();
case -1156903676: return bem_serializationIteratorGet_0();
case -1123266766: return bem_classNameGet_0();
case -601453628: return bem_fieldIteratorGet_0();
case 1210301124: return bem_default_0();
case 1562356496: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1303058317: return bem_getHash_1(bevd_0);
case -323113819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2138090541: return bem_sameClass_1(bevd_0);
case -690535851: return bem_sameObject_1(bevd_0);
case -499138365: return bem_otherClass_1(bevd_0);
case 2140620274: return bem_otherType_1(bevd_0);
case -696336738: return bem_equals_1(bevd_0);
case 1788911287: return bem_sameType_1(bevd_0);
case -637072093: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1582378113: return bem_notEquals_1(bevd_0);
case -478520463: return bem_undef_1(bevd_0);
case -89866327: return bem_copyTo_1(bevd_0);
case -327732297: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1720726298: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1828646701: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1348467221: return bem_isEqual_2(bevd_0, bevd_1);
case -733779503: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -77252171: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -104691827: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 350317076: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(31, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_17_ContainerSetIdentityRelations();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst = (BEC_3_9_3_17_ContainerSetIdentityRelations) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_type;
}
}
}
