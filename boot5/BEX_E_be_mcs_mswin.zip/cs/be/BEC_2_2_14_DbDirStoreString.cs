namespace be {
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_14_DbDirStoreString : BEC_2_2_8_DbDirStore {
public BEC_2_2_14_DbDirStoreString() { }
static BEC_2_2_14_DbDirStoreString() { }
private static byte[] becc_BEC_2_2_14_DbDirStoreString_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_2_14_DbDirStoreString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_14_DbDirStoreString_bels_0 = {};
public static new BEC_2_2_14_DbDirStoreString bece_BEC_2_2_14_DbDirStoreString_bevs_inst;

public static new BET_2_2_14_DbDirStoreString bece_BEC_2_2_14_DbDirStoreString_bevs_type;

public override BEC_2_2_8_DbDirStore bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
if (beva_id == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 329*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_2_14_DbDirStoreString_bels_0));
bevt_2_ta_ph = beva_id.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 329*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 329*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 329*/
 else /* Line: 329*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 329*/ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_5_ta_ph = bevl_p.bem_fileGet_0();
bevt_6_ta_ph = beva_object.bemd_0(-860520942);
bevt_5_ta_ph.bem_contentsSet_1((BEC_2_4_6_TextString) bevt_6_ta_ph );
} /* Line: 332*/
} /* Line: 331*/
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
if (beva_id == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 338*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_2_14_DbDirStoreString_bels_0));
bevt_3_ta_ph = beva_id.bem_notEquals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 338*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 338*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 338*/
 else /* Line: 338*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 338*/ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 340*/ {
bevt_7_ta_ph = bevl_p.bem_fileGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_existsGet_0();
if (bevt_6_ta_ph.bevi_bool)/* Line: 340*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 340*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 340*/
 else /* Line: 340*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 340*/ {
bevt_9_ta_ph = bevl_p.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_contentsGet_0();
return bevt_8_ta_ph;
} /* Line: 341*/
} /* Line: 340*/
return null;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {329, 329, 329, 329, 0, 0, 0, 330, 331, 331, 332, 332, 332, 338, 338, 338, 338, 0, 0, 0, 339, 340, 340, 340, 340, 0, 0, 0, 341, 341, 341, 344};
public static new int[] bevs_smnlec
 = new int[] {22, 27, 28, 29, 31, 34, 38, 41, 42, 47, 48, 49, 50, 67, 72, 73, 74, 76, 79, 83, 86, 87, 92, 93, 94, 96, 99, 103, 106, 107, 108, 111};
/* BEGIN LINEINFO 
assign 1 329 22
def 1 329 27
assign 1 329 28
new 0 329 28
assign 1 329 29
notEquals 1 329 29
assign 1 0 31
assign 1 0 34
assign 1 0 38
assign 1 330 41
getPath 1 330 41
assign 1 331 42
def 1 331 47
assign 1 332 48
fileGet 0 332 48
assign 1 332 49
toString 0 332 49
contentsSet 1 332 50
assign 1 338 67
def 1 338 72
assign 1 338 73
new 0 338 73
assign 1 338 74
notEquals 1 338 74
assign 1 0 76
assign 1 0 79
assign 1 0 83
assign 1 339 86
getPath 1 339 86
assign 1 340 87
def 1 340 92
assign 1 340 93
fileGet 0 340 93
assign 1 340 94
existsGet 0 340 94
assign 1 0 96
assign 1 0 99
assign 1 0 103
assign 1 341 106
fileGet 0 341 106
assign 1 341 107
contentsGet 0 341 107
return 1 341 108
return 1 344 111
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 595935693: return bem_create_0();
case 19210432: return bem_iteratorGet_0();
case -860520942: return bem_toString_0();
case -1156903676: return bem_serializationIteratorGet_0();
case -1520684387: return bem_serGetDirect_0();
case 721123821: return bem_tagGet_0();
case 1306377428: return bem_keyEncoderGetDirect_0();
case -1869924457: return bem_sourceFileNameGet_0();
case 1151085267: return bem_deserializeClassNameGet_0();
case -123629051: return bem_storageDirGetDirect_0();
case 270781002: return bem_new_0();
case 216633460: return bem_serializeContents_0();
case 1597530459: return bem_print_0();
case 559255035: return bem_fieldNamesGet_0();
case -827080774: return bem_copy_0();
case 583669801: return bem_storageDirGet_0();
case -1123266766: return bem_classNameGet_0();
case 1291824271: return bem_echo_0();
case -601453628: return bem_fieldIteratorGet_0();
case -320178062: return bem_keyEncoderGet_0();
case 1562356496: return bem_hashGet_0();
case 57360156: return bem_serGet_0();
case -390286916: return bem_serializeToString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1048052916: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case -374449594: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -696336738: return bem_equals_1(bevd_0);
case 960633757: return bem_keyEncoderSetDirect_1(bevd_0);
case -1582378113: return bem_notEquals_1(bevd_0);
case 1720726298: return bem_def_1(bevd_0);
case 927923503: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -2138090541: return bem_sameClass_1(bevd_0);
case -89866327: return bem_copyTo_1(bevd_0);
case -1132929934: return bem_keyEncoderSet_1(bevd_0);
case -323113819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 207306702: return bem_storageDirSetDirect_1(bevd_0);
case -730019666: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case 1297421681: return bem_serSetDirect_1(bevd_0);
case 1788911287: return bem_sameType_1(bevd_0);
case -478520463: return bem_undef_1(bevd_0);
case 30619544: return bem_storageDirSet_1(bevd_0);
case -1841219535: return bem_serSet_1(bevd_0);
case -499138365: return bem_otherClass_1(bevd_0);
case 610886167: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -327732297: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -690535851: return bem_sameObject_1(bevd_0);
case -147574232: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case -822151472: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -637072093: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2140620274: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -77252171: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 350317076: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1828646701: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -858055421: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -104691827: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -733779503: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1327820471: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_2_14_DbDirStoreString_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_2_2_14_DbDirStoreString_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_14_DbDirStoreString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_inst = (BEC_2_2_14_DbDirStoreString) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_type;
}
}
}
