namespace be {
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_14_DbDirStoreString : BEC_2_2_8_DbDirStore {
public BEC_2_2_14_DbDirStoreString() { }
static BEC_2_2_14_DbDirStoreString() { }
private static byte[] becc_BEC_2_2_14_DbDirStoreString_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_2_14_DbDirStoreString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_14_DbDirStoreString_bels_0 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_14_DbDirStoreString_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_14_DbDirStoreString_bels_0, 0));
private static byte[] bece_BEC_2_2_14_DbDirStoreString_bels_1 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_14_DbDirStoreString_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_14_DbDirStoreString_bels_1, 0));
public static new BEC_2_2_14_DbDirStoreString bece_BEC_2_2_14_DbDirStoreString_bevs_inst;
public override BEC_2_2_8_DbDirStore bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 330 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_14_DbDirStoreString_bevo_0;
bevt_2_tmpany_phold = beva_id.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 330 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 330 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 330 */
 else  /* Line: 330 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 330 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 332 */ {
bevt_5_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = beva_object.bemd_0(1818190775);
bevt_5_tmpany_phold.bem_contentsSet_1((BEC_2_4_6_TextString) bevt_6_tmpany_phold );
} /* Line: 333 */
} /* Line: 332 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
if (beva_id == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 339 */ {
bevt_4_tmpany_phold = bece_BEC_2_2_14_DbDirStoreString_bevo_1;
bevt_3_tmpany_phold = beva_id.bem_notEquals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 339 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 339 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 339 */
 else  /* Line: 339 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 339 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 341 */ {
bevt_7_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_existsGet_0();
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 341 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 341 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 341 */
 else  /* Line: 341 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 341 */ {
bevt_9_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_contentsGet_0();
return bevt_8_tmpany_phold;
} /* Line: 342 */
} /* Line: 341 */
return null;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {330, 330, 330, 330, 0, 0, 0, 331, 332, 332, 333, 333, 333, 339, 339, 339, 339, 0, 0, 0, 340, 341, 341, 341, 341, 0, 0, 0, 342, 342, 342, 345};
public static new int[] bevs_smnlec
 = new int[] {22, 27, 28, 29, 31, 34, 38, 41, 42, 47, 48, 49, 50, 67, 72, 73, 74, 76, 79, 83, 86, 87, 92, 93, 94, 96, 99, 103, 106, 107, 108, 111};
/* BEGIN LINEINFO 
assign 1 330 22
def 1 330 27
assign 1 330 28
new 0 330 28
assign 1 330 29
notEquals 1 330 29
assign 1 0 31
assign 1 0 34
assign 1 0 38
assign 1 331 41
getPath 1 331 41
assign 1 332 42
def 1 332 47
assign 1 333 48
fileGet 0 333 48
assign 1 333 49
toString 0 333 49
contentsSet 1 333 50
assign 1 339 67
def 1 339 72
assign 1 339 73
new 0 339 73
assign 1 339 74
notEquals 1 339 74
assign 1 0 76
assign 1 0 79
assign 1 0 83
assign 1 340 86
getPath 1 340 86
assign 1 341 87
def 1 341 92
assign 1 341 93
fileGet 0 341 93
assign 1 341 94
existsGet 0 341 94
assign 1 0 96
assign 1 0 99
assign 1 0 103
assign 1 342 106
fileGet 0 342 106
assign 1 342 107
contentsGet 0 342 107
return 1 342 108
return 1 345 111
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case -1538220610: return bem_echo_0();
case 308705107: return bem_serializeContents_0();
case -67432972: return bem_fieldIteratorGet_0();
case -1751704975: return bem_many_0();
case -146459624: return bem_tagGet_0();
case -1181834336: return bem_serializeToString_0();
case 1704272071: return bem_copy_0();
case 1818190775: return bem_toString_0();
case -1613660155: return bem_serializationIteratorGet_0();
case 1133560869: return bem_new_0();
case 1277077124: return bem_once_0();
case 1567284243: return bem_create_0();
case 642325680: return bem_deserializeClassNameGet_0();
case 624537853: return bem_keyEncoderGet_0();
case 1196296936: return bem_serGet_0();
case 1190997837: return bem_print_0();
case 1985246514: return bem_classNameGet_0();
case -457378134: return bem_sourceFileNameGet_0();
case 371037351: return bem_hashGet_0();
case -563585217: return bem_toAny_0();
case 16424274: return bem_iteratorGet_0();
case -1541432838: return bem_storageDirGet_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case -503068138: return bem_sameType_1(bevd_0);
case 1398941771: return bem_def_1(bevd_0);
case -1682170766: return bem_otherType_1(bevd_0);
case -2130760528: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 800372560: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case 2077566448: return bem_sameClass_1(bevd_0);
case 1170591864: return bem_otherClass_1(bevd_0);
case -2016447869: return bem_storageDirSet_1(bevd_0);
case 1270721790: return bem_sameObject_1(bevd_0);
case 1916412992: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case 382645669: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case 152446702: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -1508704559: return bem_copyTo_1(bevd_0);
case -240186291: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1936197463: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2101700701: return bem_undefined_1(bevd_0);
case 1069670174: return bem_undef_1(bevd_0);
case 11116001: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1210345122: return bem_notEquals_1(bevd_0);
case 1933685650: return bem_equals_1(bevd_0);
case 1024493267: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 579081683: return bem_defined_1(bevd_0);
case -550700921: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -122042490: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -76789915: return bem_serSet_1(bevd_0);
case 544554524: return bem_keyEncoderSet_1(bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1408482482: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1097908484: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1722402091: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1055053136: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -153418843: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 2112228411: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -87381279: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -483654719: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1372560242: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_2_14_DbDirStoreString_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_2_2_14_DbDirStoreString_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_14_DbDirStoreString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_inst = (BEC_2_2_14_DbDirStoreString) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_inst;
}
}
}
