namespace be {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_6_DigestSHA256 : BEC_2_6_6_SystemObject {
public BEC_2_6_6_DigestSHA256() { }
static BEC_2_6_6_DigestSHA256() { }

    public SHA256Managed bevi_md; 
   private static byte[] becc_BEC_2_6_6_DigestSHA256_clname = {0x44,0x69,0x67,0x65,0x73,0x74,0x3A,0x53,0x48,0x41,0x32,0x35,0x36};
private static byte[] becc_BEC_2_6_6_DigestSHA256_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
public static new BEC_2_6_6_DigestSHA256 bece_BEC_2_6_6_DigestSHA256_bevs_inst;
public override BEC_2_6_6_SystemObject bem_new_0() {

        bevi_md = new SHA256Managed();
        return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_digest_1(BEC_2_4_6_TextString beva_with) {
BEC_2_4_6_TextString bevl_res = null;
bem_new_0();

        bevl_res = new BEC_2_4_6_TextString(
          bevi_md.ComputeHash(beva_with.bevi_bytes, 0, beva_with.bevp_size.bevi_int)
        );
        return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_digestToHex_1(BEC_2_4_6_TextString beva_input) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_3_EncodeHex bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevt_2_tmpany_phold = bem_digest_1(beva_input);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_encode_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {95, 110, 114, 114, 114, 114};
public static new int[] bevs_smnlec
 = new int[] {20, 25, 31, 32, 33, 34};
/* BEGIN LINEINFO 
new 0 95 20
return 1 110 25
assign 1 114 31
new 0 114 31
assign 1 114 32
digest 1 114 32
assign 1 114 33
encode 1 114 33
return 1 114 34
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 1704272071: return bem_copy_0();
case 16424274: return bem_iteratorGet_0();
case 1277077124: return bem_once_0();
case -146459624: return bem_tagGet_0();
case 1818190775: return bem_toString_0();
case 371037351: return bem_hashGet_0();
case 1190997837: return bem_print_0();
case -1613660155: return bem_serializationIteratorGet_0();
case -1181834336: return bem_serializeToString_0();
case 308705107: return bem_serializeContents_0();
case 1133560869: return bem_new_0();
case -457378134: return bem_sourceFileNameGet_0();
case 1985246514: return bem_classNameGet_0();
case -1751704975: return bem_many_0();
case -67432972: return bem_fieldIteratorGet_0();
case 1567284243: return bem_create_0();
case -1538220610: return bem_echo_0();
case 642325680: return bem_deserializeClassNameGet_0();
case -563585217: return bem_toAny_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case -1508704559: return bem_copyTo_1(bevd_0);
case 1024493267: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1747886579: return bem_digestToHex_1((BEC_2_4_6_TextString) bevd_0);
case 2101700701: return bem_undefined_1(bevd_0);
case -1682170766: return bem_otherType_1(bevd_0);
case -503068138: return bem_sameType_1(bevd_0);
case 2077566448: return bem_sameClass_1(bevd_0);
case 1398941771: return bem_def_1(bevd_0);
case -240186291: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 100525275: return bem_digest_1((BEC_2_4_6_TextString) bevd_0);
case -1936197463: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -122042490: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1270721790: return bem_sameObject_1(bevd_0);
case 1933685650: return bem_equals_1(bevd_0);
case 579081683: return bem_defined_1(bevd_0);
case 1069670174: return bem_undef_1(bevd_0);
case -1210345122: return bem_notEquals_1(bevd_0);
case 1170591864: return bem_otherClass_1(bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1408482482: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1097908484: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1722402091: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1055053136: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2112228411: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -483654719: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1372560242: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_DigestSHA256_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_DigestSHA256_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_DigestSHA256();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_DigestSHA256.bece_BEC_2_6_6_DigestSHA256_bevs_inst = (BEC_2_6_6_DigestSHA256) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_DigestSHA256.bece_BEC_2_6_6_DigestSHA256_bevs_inst;
}
}
}
