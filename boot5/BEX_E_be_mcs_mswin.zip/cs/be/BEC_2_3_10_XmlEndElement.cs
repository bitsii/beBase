namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_10_XmlEndElement : BEC_2_3_3_XmlTag {
public BEC_2_3_10_XmlEndElement() { }
static BEC_2_3_10_XmlEndElement() { }
private static byte[] becc_BEC_2_3_10_XmlEndElement_clname = {0x58,0x6D,0x6C,0x3A,0x45,0x6E,0x64,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_3_10_XmlEndElement_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_10_XmlEndElement_bels_0 = {0x3C,0x2F};
private static byte[] bece_BEC_2_3_10_XmlEndElement_bels_1 = {0x3E};
public static new BEC_2_3_10_XmlEndElement bece_BEC_2_3_10_XmlEndElement_bevs_inst;

public static new BET_2_3_10_XmlEndElement bece_BEC_2_3_10_XmlEndElement_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_10_XmlEndElement_bels_0));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_name);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_10_XmlEndElement_bels_1));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_3_10_XmlEndElement bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_10_XmlEndElement bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {77, 77, 77, 77, 77, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {23, 24, 25, 26, 27, 30, 33, 36, 40};
/* BEGIN LINEINFO 
assign 1 77 23
new 0 77 23
assign 1 77 24
add 1 77 24
assign 1 77 25
new 0 77 25
assign 1 77 26
add 1 77 26
return 1 77 27
return 1 0 30
return 1 0 33
assign 1 0 36
assign 1 0 40
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1151085267: return bem_deserializeClassNameGet_0();
case 721123821: return bem_tagGet_0();
case 19210432: return bem_iteratorGet_0();
case 1597530459: return bem_print_0();
case 559255035: return bem_fieldNamesGet_0();
case -860520942: return bem_toString_0();
case 216633460: return bem_serializeContents_0();
case 1291824271: return bem_echo_0();
case 595935693: return bem_create_0();
case -390286916: return bem_serializeToString_0();
case -1869924457: return bem_sourceFileNameGet_0();
case 270781002: return bem_new_0();
case -827080774: return bem_copy_0();
case -1156903676: return bem_serializationIteratorGet_0();
case 2136811591: return bem_nameGet_0();
case 1696088548: return bem_nameGetDirect_0();
case -1123266766: return bem_classNameGet_0();
case -601453628: return bem_fieldIteratorGet_0();
case 1562356496: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -637072093: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -499138365: return bem_otherClass_1(bevd_0);
case -323113819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1788911287: return bem_sameType_1(bevd_0);
case -2138090541: return bem_sameClass_1(bevd_0);
case -89866327: return bem_copyTo_1(bevd_0);
case -696336738: return bem_equals_1(bevd_0);
case 1443582703: return bem_nameSet_1(bevd_0);
case 1720726298: return bem_def_1(bevd_0);
case -690535851: return bem_sameObject_1(bevd_0);
case -478520463: return bem_undef_1(bevd_0);
case -327732297: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -726664186: return bem_nameSetDirect_1(bevd_0);
case -1582378113: return bem_notEquals_1(bevd_0);
case 2140620274: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1828646701: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -733779503: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -77252171: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -104691827: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 350317076: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_3_10_XmlEndElement_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_10_XmlEndElement_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_10_XmlEndElement();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_10_XmlEndElement.bece_BEC_2_3_10_XmlEndElement_bevs_inst = (BEC_2_3_10_XmlEndElement) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_10_XmlEndElement.bece_BEC_2_3_10_XmlEndElement_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_3_10_XmlEndElement.bece_BEC_2_3_10_XmlEndElement_bevs_type;
}
}
}
