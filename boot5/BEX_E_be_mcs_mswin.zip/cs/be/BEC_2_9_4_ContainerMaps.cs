namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerMaps : BEC_2_6_8_SystemVariadic {
public BEC_2_9_4_ContainerMaps() { }
static BEC_2_9_4_ContainerMaps() { }
private static byte[] becc_BEC_2_9_4_ContainerMaps_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x73};
private static byte[] becc_BEC_2_9_4_ContainerMaps_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_inst;
public virtual BEC_2_9_4_ContainerMaps bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_from_1(BEC_2_9_4_ContainerList beva_list) {
BEC_2_4_3_MathInt bevl_ls = null;
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevl_ls = beva_list.bem_sizeGet_0();
bevl_map = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_1(bevl_ls);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 723 */ {
if (bevl_i.bevi_int < bevl_ls.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 723 */ {
bevt_1_tmpany_phold = beva_list.bem_get_1(bevl_i);
bevl_i.bevi_int++;
bevt_3_tmpany_phold = bevl_i;
bevt_2_tmpany_phold = beva_list.bem_get_1(bevt_3_tmpany_phold);
bevl_map.bem_put_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 723 */
 else  /* Line: 723 */ {
break;
} /* Line: 723 */
} /* Line: 723 */
return bevl_map;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_fieldsIntoMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_9_3_ContainerMap beva_res) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_i = beva_inst.bemd_0(-364515046);
while (true)
 /* Line: 730 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(452370668);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 730 */ {
bevt_1_tmpany_phold = bevl_i.bemd_0(2122941334);
bevt_2_tmpany_phold = bevl_i.bemd_0(-626230809);
beva_res.bem_put_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 731 */
 else  /* Line: 730 */ {
break;
} /* Line: 730 */
} /* Line: 730 */
return beva_res;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_mapIntoFields_2(BEC_2_9_3_ContainerMap beva_from, BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_i = beva_inst.bemd_0(-364515046);
while (true)
 /* Line: 737 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(452370668);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 737 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(2122941334);
bevt_1_tmpany_phold = beva_from.bem_get_1(bevt_2_tmpany_phold);
bevl_i.bemd_1(-1319824016, bevt_1_tmpany_phold);
} /* Line: 738 */
 else  /* Line: 737 */ {
break;
} /* Line: 737 */
} /* Line: 737 */
return beva_inst;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {721, 722, 723, 723, 723, 724, 724, 724, 724, 723, 726, 730, 730, 731, 731, 731, 733, 737, 737, 738, 738, 738, 740};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 22, 25, 30, 31, 32, 34, 35, 36, 42, 49, 52, 54, 55, 56, 62, 69, 72, 74, 75, 76, 82};
/* BEGIN LINEINFO 
assign 1 721 20
sizeGet 0 721 20
assign 1 722 21
new 1 722 21
assign 1 723 22
new 0 723 22
assign 1 723 25
lesser 1 723 30
assign 1 724 31
get 1 724 31
assign 1 724 32
incrementValue 0 724 32
assign 1 724 34
get 1 724 34
put 2 724 35
incrementValue 0 723 36
return 1 726 42
assign 1 730 49
fieldIteratorGet 0 730 49
assign 1 730 52
hasNextGet 0 730 52
assign 1 731 54
nextNameGet 0 731 54
assign 1 731 55
currentGet 0 731 55
put 2 731 56
return 1 733 62
assign 1 737 69
fieldIteratorGet 0 737 69
assign 1 737 72
hasNextGet 0 737 72
assign 1 738 74
nextNameGet 0 738 74
assign 1 738 75
get 1 738 75
currentSet 1 738 76
return 1 740 82
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1193265838: return bem_new_0();
case 752911959: return bem_hashGet_0();
case 142206752: return bem_many_0();
case 2141550628: return bem_deserializeClassNameGet_0();
case -1896601781: return bem_toAny_0();
case 2142995396: return bem_default_0();
case -326646035: return bem_toString_0();
case 2085674875: return bem_echo_0();
case 2098501683: return bem_create_0();
case -2052611744: return bem_once_0();
case -364515046: return bem_fieldIteratorGet_0();
case -1888508563: return bem_serializationIteratorGet_0();
case 444169984: return bem_sourceFileNameGet_0();
case 1310164435: return bem_serializeContents_0();
case -1152001976: return bem_copy_0();
case 1278477757: return bem_serializeToString_0();
case 1211836779: return bem_iteratorGet_0();
case -2091198124: return bem_tagGet_0();
case -1976290782: return bem_print_0();
case 880152096: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1268433926: return bem_otherClass_1(bevd_0);
case -785327205: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 607370643: return bem_undefined_1(bevd_0);
case 1579053823: return bem_sameType_1(bevd_0);
case 1048239710: return bem_sameClass_1(bevd_0);
case -1321282362: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1866601742: return bem_otherType_1(bevd_0);
case 1948085050: return bem_undef_1(bevd_0);
case 986477958: return bem_defined_1(bevd_0);
case 1990827367: return bem_notEquals_1(bevd_0);
case 275457317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 496808651: return bem_sameObject_1(bevd_0);
case 45057151: return bem_equals_1(bevd_0);
case 136677527: return bem_def_1(bevd_0);
case 930180418: return bem_copyTo_1(bevd_0);
case -1191000829: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 249957819: return bem_from_1((BEC_2_9_4_ContainerList) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1481064275: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 893523384: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1400688487: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 686788947: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1688733530: return bem_fieldsIntoMap_2(bevd_0, (BEC_2_9_3_ContainerMap) bevd_1);
case -1768228505: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 253281852: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1592504658: return bem_mapIntoFields_2((BEC_2_9_3_ContainerMap) bevd_0, bevd_1);
case -1848289028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerMaps_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerMaps_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerMaps();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst = (BEC_2_9_4_ContainerMaps) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
}
}
}
