namespace be {
/* IO:File: source/build/CSEmitter.be */
public sealed class BEC_2_5_9_BuildCSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
static BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_24, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_27, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_28, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_38, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_39, 18));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_40, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_41, 38));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_42, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_45 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_46 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_47 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_48 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_48, 10));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_49 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_49, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_50 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_50, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_51 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_51, 3));
public static new BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static new BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 28 */
bevt_10_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_8_tmpany_phold.bemd_0(1754703175);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_12_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_17_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_tmpany_phold);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_23_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_23_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_24_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1511439398);
if (bevl_firstmnsyn.bevi_bool) /* Line: 39 */ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 40 */
 else  /* Line: 41 */ {
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
} /* Line: 42 */
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_28_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevt_27_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 44 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_tmpany_phold);
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_32_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_32_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 51 */ {
bevt_33_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 51 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(1511439398);
if (bevl_firstptsyn.bevi_bool) /* Line: 52 */ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 53 */
 else  /* Line: 54 */ {
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
} /* Line: 55 */
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_37_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 57 */
 else  /* Line: 51 */ {
break;
} /* Line: 51 */
} /* Line: 51 */
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) bevt_41_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_40_tmpany_phold.bem_addValue_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevl_bet.bem_addValue_1(bevt_45_tmpany_phold);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevt_47_tmpany_phold.bem_addValue_1(bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevt_46_tmpany_phold.bem_addValue_1(bevt_50_tmpany_phold);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_21));
bevl_bet.bem_addValue_1(bevt_51_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevl_bet.bem_addValue_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevl_bet.bem_addValue_1(bevt_53_tmpany_phold);
bevl_tout.bemd_1(-1443067519, bevl_bet);
bevl_tout.bemd_0(1092690343);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(882717118);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(601087743);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, bevt_16_tmpany_phold);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
if (beva_msyn == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_3_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
return bevt_4_tmpany_phold;
} /* Line: 88 */
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 94 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 94 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_33));
return bevt_3_tmpany_phold;
} /* Line: 95 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_34));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_43));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_44));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_45));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_46));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(476222825);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_47));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 23, 27, 27, 27, 27, 27, 28, 28, 28, 30, 30, 30, 30, 31, 32, 32, 33, 33, 33, 33, 33, 33, 34, 34, 34, 34, 34, 34, 36, 36, 37, 38, 38, 0, 38, 38, 40, 42, 42, 44, 44, 44, 44, 46, 46, 47, 47, 49, 49, 50, 51, 51, 0, 51, 51, 53, 55, 55, 57, 57, 57, 57, 59, 59, 61, 61, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 65, 65, 65, 65, 66, 66, 67, 67, 68, 68, 69, 70, 74, 74, 74, 75, 76, 76, 76, 76, 76, 76, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 83, 83, 87, 0, 87, 87, 87, 0, 0, 0, 0, 0, 88, 88, 90, 90, 94, 94, 94, 0, 0, 0, 95, 95, 97, 97, 101, 101, 105, 105, 105, 105, 105, 110, 111, 112, 112, 112, 113, 119, 119, 119, 119, 119, 119, 123, 123, 123, 123, 123, 124, 124, 124, 124, 124, 124, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 127, 131, 131, 131, 135, 135, 135, 135, 135, 135, 135, 139, 139, 143, 143, 143, 147, 147, 147, 147, 151, 151};
public static new int[] bevs_smnlec
 = new int[] {79, 80, 81, 82, 146, 147, 148, 149, 154, 155, 156, 157, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 182, 185, 187, 189, 192, 193, 195, 196, 197, 198, 204, 205, 206, 207, 208, 209, 210, 211, 212, 212, 215, 217, 219, 222, 223, 225, 226, 227, 228, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 306, 307, 316, 318, 321, 326, 327, 329, 332, 336, 339, 342, 346, 347, 349, 350, 358, 363, 364, 366, 369, 373, 376, 377, 379, 380, 384, 385, 392, 393, 394, 395, 396, 402, 403, 404, 405, 406, 407, 416, 417, 418, 419, 420, 421, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 470, 471, 472, 481, 482, 483, 484, 485, 486, 487, 491, 492, 497, 498, 499, 505, 506, 507, 508, 512, 513};
/* BEGIN LINEINFO 
assign 1 17 79
new 0 17 79
assign 1 18 80
new 0 18 80
assign 1 19 81
new 0 19 81
new 1 23 82
assign 1 27 146
classDirGet 0 27 146
assign 1 27 147
fileGet 0 27 147
assign 1 27 148
existsGet 0 27 148
assign 1 27 149
not 0 27 154
assign 1 28 155
classDirGet 0 28 155
assign 1 28 156
fileGet 0 28 156
makeDirs 0 28 157
assign 1 30 159
typePathGet 0 30 159
assign 1 30 160
fileGet 0 30 160
assign 1 30 161
writerGet 0 30 161
assign 1 30 162
open 0 30 162
assign 1 31 163
new 0 31 163
assign 1 32 164
new 0 32 164
addValue 1 32 165
assign 1 33 166
new 0 33 166
assign 1 33 167
addValue 1 33 167
assign 1 33 168
typeEmitNameGet 0 33 168
assign 1 33 169
addValue 1 33 169
assign 1 33 170
new 0 33 170
addValue 1 33 171
assign 1 34 172
new 0 34 172
assign 1 34 173
addValue 1 34 173
assign 1 34 174
typeEmitNameGet 0 34 174
assign 1 34 175
addValue 1 34 175
assign 1 34 176
new 0 34 176
addValue 1 34 177
assign 1 36 178
new 0 36 178
addValue 1 36 179
assign 1 37 180
new 0 37 180
assign 1 38 181
mtdListGet 0 38 181
assign 1 38 182
iteratorGet 0 0 182
assign 1 38 185
hasNextGet 0 38 185
assign 1 38 187
nextGet 0 38 187
assign 1 40 189
new 0 40 189
assign 1 42 192
new 0 42 192
addValue 1 42 193
assign 1 44 195
addValue 1 44 195
assign 1 44 196
nameGet 0 44 196
assign 1 44 197
addValue 1 44 197
addValue 1 44 198
assign 1 46 204
new 0 46 204
addValue 1 46 205
assign 1 47 206
new 0 47 206
addValue 1 47 207
assign 1 49 208
new 0 49 208
addValue 1 49 209
assign 1 50 210
new 0 50 210
assign 1 51 211
ptyListGet 0 51 211
assign 1 51 212
iteratorGet 0 0 212
assign 1 51 215
hasNextGet 0 51 215
assign 1 51 217
nextGet 0 51 217
assign 1 53 219
new 0 53 219
assign 1 55 222
new 0 55 222
addValue 1 55 223
assign 1 57 225
addValue 1 57 225
assign 1 57 226
nameGet 0 57 226
assign 1 57 227
addValue 1 57 227
addValue 1 57 228
assign 1 59 234
new 0 59 234
addValue 1 59 235
assign 1 61 236
new 0 61 236
addValue 1 61 237
assign 1 63 238
new 0 63 238
assign 1 63 239
addValue 1 63 239
assign 1 63 240
typeEmitNameGet 0 63 240
assign 1 63 241
addValue 1 63 241
assign 1 63 242
new 0 63 242
addValue 1 63 243
assign 1 64 244
new 0 64 244
addValue 1 64 245
assign 1 65 246
new 0 65 246
assign 1 65 247
addValue 1 65 247
assign 1 65 248
emitNameGet 0 65 248
assign 1 65 249
addValue 1 65 249
assign 1 65 250
new 0 65 250
addValue 1 65 251
assign 1 66 252
new 0 66 252
addValue 1 66 253
assign 1 67 254
new 0 67 254
addValue 1 67 255
assign 1 68 256
new 0 68 256
addValue 1 68 257
write 1 69 258
close 0 70 259
assign 1 74 281
new 0 74 281
assign 1 74 282
toString 0 74 282
assign 1 74 283
add 1 74 283
incrementValue 0 75 284
assign 1 76 285
new 0 76 285
assign 1 76 286
addValue 1 76 286
assign 1 76 287
addValue 1 76 287
assign 1 76 288
new 0 76 288
assign 1 76 289
addValue 1 76 289
addValue 1 76 290
assign 1 78 291
containedGet 0 78 291
assign 1 78 292
firstGet 0 78 292
assign 1 78 293
containedGet 0 78 293
assign 1 78 294
firstGet 0 78 294
assign 1 78 295
new 0 78 295
assign 1 78 296
add 1 78 296
assign 1 78 297
new 0 78 297
assign 1 78 298
add 1 78 298
assign 1 78 299
new 0 78 299
assign 1 78 300
finalAssign 4 78 300
addValue 1 78 301
assign 1 83 306
new 0 83 306
return 1 83 307
assign 1 87 316
isFinalGet 0 87 316
assign 1 0 318
assign 1 87 321
def 1 87 326
assign 1 87 327
isFinalGet 0 87 327
assign 1 0 329
assign 1 0 332
assign 1 0 336
assign 1 0 339
assign 1 0 342
assign 1 88 346
new 0 88 346
return 1 88 347
assign 1 90 349
new 0 90 349
return 1 90 350
assign 1 94 358
def 1 94 363
assign 1 94 364
isFinalGet 0 94 364
assign 1 0 366
assign 1 0 369
assign 1 0 373
assign 1 95 376
new 0 95 376
return 1 95 377
assign 1 97 379
new 0 97 379
return 1 97 380
assign 1 101 384
new 0 101 384
return 1 101 385
assign 1 105 392
new 0 105 392
assign 1 105 393
add 1 105 393
assign 1 105 394
new 0 105 394
assign 1 105 395
add 1 105 395
return 1 105 396
getCode 2 110 402
assign 1 111 403
toHexString 1 111 403
assign 1 112 404
new 0 112 404
assign 1 112 405
once 0 112 405
addValue 1 112 406
addValue 1 113 407
assign 1 119 416
new 0 119 416
assign 1 119 417
add 1 119 417
assign 1 119 418
new 0 119 418
assign 1 119 419
add 1 119 419
assign 1 119 420
add 1 119 420
return 1 119 421
assign 1 123 443
new 0 123 443
assign 1 123 444
add 1 123 444
assign 1 123 445
new 0 123 445
assign 1 123 446
add 1 123 446
assign 1 123 447
add 1 123 447
assign 1 124 448
new 0 124 448
assign 1 124 449
addValue 1 124 449
assign 1 124 450
addValue 1 124 450
assign 1 124 451
new 0 124 451
assign 1 124 452
addValue 1 124 452
addValue 1 124 453
assign 1 125 454
new 0 125 454
assign 1 125 455
addValue 1 125 455
addValue 1 125 456
assign 1 126 457
new 0 126 457
assign 1 126 458
addValue 1 126 458
assign 1 126 459
outputPlatformGet 0 126 459
assign 1 126 460
nameGet 0 126 460
assign 1 126 461
addValue 1 126 461
assign 1 126 462
new 0 126 462
assign 1 126 463
addValue 1 126 463
addValue 1 126 464
return 1 127 465
assign 1 131 470
libNameGet 0 131 470
assign 1 131 471
beginNs 1 131 471
return 1 131 472
assign 1 135 481
new 0 135 481
assign 1 135 482
libNs 1 135 482
assign 1 135 483
add 1 135 483
assign 1 135 484
new 0 135 484
assign 1 135 485
add 1 135 485
assign 1 135 486
add 1 135 486
return 1 135 487
assign 1 139 491
getNameSpace 1 139 491
return 1 139 492
assign 1 143 497
new 0 143 497
assign 1 143 498
add 1 143 498
return 1 143 499
assign 1 147 505
new 0 147 505
assign 1 147 506
once 0 147 506
assign 1 147 507
add 1 147 507
return 1 147 508
assign 1 151 512
new 0 151 512
return 1 151 513
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1036346068: return bem_mainEndGet_0();
case 426100702: return bem_scvpGetDirect_0();
case -1371744023: return bem_objectNpGet_0();
case -446642707: return bem_methodCallsGet_0();
case 331936486: return bem_floatNpGetDirect_0();
case -963133890: return bem_classEmitsGetDirect_0();
case 1527199995: return bem_invpGetDirect_0();
case -61574052: return bem_runtimeInitGet_0();
case 169081302: return bem_intNpGetDirect_0();
case 2145732529: return bem_fullLibEmitNameGetDirect_0();
case 463617615: return bem_cnodeGet_0();
case 22071818: return bem_instanceNotEqualGetDirect_0();
case 1444899573: return bem_cnodeGetDirect_0();
case -2112620300: return bem_doEmit_0();
case 453113237: return bem_superCallsGetDirect_0();
case -680161822: return bem_classConfGet_0();
case 1509132379: return bem_preClassGetDirect_0();
case -1487245201: return bem_synEmitPathGetDirect_0();
case -690666266: return bem_csynGetDirect_0();
case -1272290715: return bem_maxDynArgsGet_0();
case 1121485372: return bem_returnTypeGetDirect_0();
case 238827447: return bem_smnlcsGetDirect_0();
case -1350077857: return bem_callNamesGet_0();
case 1019548152: return bem_methodBodyGetDirect_0();
case -925323991: return bem_idToNameGetDirect_0();
case 1627697722: return bem_getLibOutput_0();
case -1959451215: return bem_nullValueGetDirect_0();
case 556880031: return bem_smnlcsGet_0();
case 257663210: return bem_mainOutsideNsGet_0();
case -356165793: return bem_saveIds_0();
case 640421622: return bem_methodCatchGetDirect_0();
case 1626332064: return bem_floatNpGet_0();
case -1180094692: return bem_instanceEqualGetDirect_0();
case -288179766: return bem_ccMethodsGet_0();
case 2007932962: return bem_exceptDecGetDirect_0();
case 1768380355: return bem_objectCcGetDirect_0();
case 148813974: return bem_beginNs_0();
case -1724156551: return bem_inClassGetDirect_0();
case -647519736: return bem_print_0();
case -1151305003: return bem_lastMethodBodyLinesGetDirect_0();
case 1330296081: return bem_libEmitPathGetDirect_0();
case 536353860: return bem_qGetDirect_0();
case -978703941: return bem_mainStartGet_0();
case -1008655903: return bem_nameToIdGet_0();
case -73250478: return bem_lineCountGetDirect_0();
case -1870939020: return bem_nlGet_0();
case 847806652: return bem_nativeCSlotsGetDirect_0();
case -272520222: return bem_classesInDepthOrderGetDirect_0();
case 1591904658: return bem_emitLangGet_0();
case -977511772: return bem_fileExtGet_0();
case -1470269081: return bem_ccCacheGetDirect_0();
case -747859575: return bem_echo_0();
case -1364681056: return bem_lastMethodsLinesGet_0();
case 1961684391: return bem_idToNameGet_0();
case -1966047965: return bem_qGet_0();
case 320569903: return bem_instanceNotEqualGet_0();
case -1966566809: return bem_saveSyns_0();
case -987920044: return bem_randGet_0();
case 247818182: return bem_copy_0();
case 1823676436: return bem_initialDecGet_0();
case 1561881831: return bem_tagGet_0();
case -555801573: return bem_overrideMtdDecGet_0();
case 1283134492: return bem_lastMethodsSizeGet_0();
case 1164652906: return bem_inClassGet_0();
case -439190343: return bem_mainInClassGet_0();
case -335942583: return bem_fieldIteratorGet_0();
case 654677949: return bem_idToNamePathGetDirect_0();
case -1922984937: return bem_nlGetDirect_0();
case 2046345772: return bem_ntypesGet_0();
case -1841413068: return bem_mnodeGet_0();
case 432171186: return bem_endNs_0();
case 600221046: return bem_lastCallGet_0();
case 1194459879: return bem_trueValueGetDirect_0();
case 1893430435: return bem_buildGetDirect_0();
case -259040255: return bem_fileExtGetDirect_0();
case 1377475470: return bem_superNameGet_0();
case -90924177: return bem_inFilePathedGetDirect_0();
case -1202368558: return bem_boolNpGet_0();
case -1162035206: return bem_constGet_0();
case -1063821226: return bem_parentConfGetDirect_0();
case -540935343: return bem_methodCatchGet_0();
case 688493679: return bem_classesInDepthOrderGet_0();
case 1093722757: return bem_lastMethodBodySizeGet_0();
case 413617868: return bem_stringNpGet_0();
case -2010659964: return bem_methodsGetDirect_0();
case -737229351: return bem_onceCountGet_0();
case -804726543: return bem_synEmitPathGet_0();
case 1984235840: return bem_buildClassInfo_0();
case 193699006: return bem_spropDecGet_0();
case 827545780: return bem_idToNamePathGet_0();
case -1248831869: return bem_parentConfGet_0();
case -1457724445: return bem_randGetDirect_0();
case -709677651: return bem_fieldNamesGet_0();
case 1578795495: return bem_ntypesGetDirect_0();
case 728138052: return bem_smnlecsGet_0();
case -1404106487: return bem_classEndGet_0();
case 800058728: return bem_stringNpGetDirect_0();
case -606951928: return bem_emitLib_0();
case 1599241336: return bem_iteratorGet_0();
case -1999703144: return bem_sourceFileNameGet_0();
case -1037783611: return bem_classCallsGetDirect_0();
case 1424593348: return bem_falseValueGet_0();
case -42616222: return bem_lastMethodBodySizeGetDirect_0();
case 998134723: return bem_lastMethodBodyLinesGet_0();
case 361346859: return bem_objectCcGet_0();
case -1610310365: return bem_boolCcGetDirect_0();
case 1936817185: return bem_fullLibEmitNameGet_0();
case 789562315: return bem_lastCallGetDirect_0();
case -764401283: return bem_maxDynArgsGetDirect_0();
case 826888340: return bem_onceDecsGetDirect_0();
case 1003453997: return bem_useDynMethodsGet_0();
case -801924444: return bem_emitLangGetDirect_0();
case 607574975: return bem_writeBET_0();
case -1098498237: return bem_coanyiantReturnsGet_0();
case 1354432723: return bem_dynMethodsGet_0();
case -279406019: return bem_onceCountGetDirect_0();
case 1034659716: return bem_once_0();
case 307892966: return bem_intNpGet_0();
case -1097509485: return bem_nativeCSlotsGet_0();
case 1974821397: return bem_baseMtdDecGet_0();
case 1288148288: return bem_lineCountGet_0();
case 1938954117: return bem_libEmitNameGetDirect_0();
case 394441908: return bem_lastMethodsSizeGetDirect_0();
case 1919225868: return bem_propertyDecsGet_0();
case -1583815318: return bem_returnTypeGet_0();
case 776574254: return bem_nameToIdPathGet_0();
case 784673728: return bem_instOfGet_0();
case 1992583192: return bem_classNameGet_0();
case 1359075500: return bem_invpGet_0();
case 1035232271: return bem_toAny_0();
case 1626731890: return bem_classConfGetDirect_0();
case -2044460281: return bem_new_0();
case -1044896182: return bem_boolCcGet_0();
case 73612433: return bem_propDecGet_0();
case -31877142: return bem_many_0();
case -687604782: return bem_lastMethodsLinesGetDirect_0();
case 1901290793: return bem_classCallsGet_0();
case 203262360: return bem_exceptDecGet_0();
case -507714840: return bem_buildCreate_0();
case 987048722: return bem_serializeContents_0();
case 1379499369: return bem_msynGet_0();
case -1025530682: return bem_scvpGet_0();
case 1872190443: return bem_inFilePathedGet_0();
case -2133393: return bem_falseValueGetDirect_0();
case 2011982054: return bem_buildGet_0();
case -2144962585: return bem_smnlecsGetDirect_0();
case 1951321180: return bem_loadIds_0();
case -723040039: return bem_constGetDirect_0();
case 1127904827: return bem_msynGetDirect_0();
case -1503949943: return bem_hashGet_0();
case -1309821246: return bem_methodCallsGetDirect_0();
case 993512899: return bem_nullValueGet_0();
case 788290025: return bem_dynMethodsGetDirect_0();
case -1430518555: return bem_baseSmtdDecGet_0();
case 1469189753: return bem_buildInitial_0();
case -1635273087: return bem_maxSpillArgsLenGet_0();
case 785426212: return bem_callNamesGetDirect_0();
case 875466653: return bem_transGetDirect_0();
case -1082525179: return bem_objectNpGetDirect_0();
case -427081409: return bem_create_0();
case -2030702755: return bem_boolNpGetDirect_0();
case 245481994: return bem_onceDecsGet_0();
case -1670869215: return bem_boolTypeGet_0();
case 1724668573: return bem_trueValueGet_0();
case -141904644: return bem_toString_0();
case 1374872636: return bem_deserializeClassNameGet_0();
case 1250354294: return bem_classEmitsGet_0();
case 1969860558: return bem_maxSpillArgsLenGetDirect_0();
case 1654821692: return bem_typeDecGet_0();
case 1400899465: return bem_libEmitNameGet_0();
case -1721880481: return bem_methodsGet_0();
case 421047878: return bem_serializationIteratorGet_0();
case -1558407090: return bem_transGet_0();
case 1460328730: return bem_nameToIdPathGetDirect_0();
case -2090695059: return bem_mnodeGetDirect_0();
case -1626486187: return bem_methodBodyGet_0();
case -293296696: return bem_nameToIdGetDirect_0();
case 1908882734: return bem_instanceEqualGet_0();
case 2045518746: return bem_csynGet_0();
case -303917795: return bem_preClassGet_0();
case -1601826647: return bem_afterCast_0();
case -1022455796: return bem_superCallsGet_0();
case -693351667: return bem_instOfGetDirect_0();
case 1764872711: return bem_preClassOutput_0();
case -1474345157: return bem_serializeToString_0();
case 882842425: return bem_propertyDecsGetDirect_0();
case 1209675675: return bem_ccMethodsGetDirect_0();
case 1220691033: return bem_getClassOutput_0();
case 711277457: return bem_ccCacheGet_0();
case 630984502: return bem_libEmitPathGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1719382314: return bem_classEmitsSetDirect_1(bevd_0);
case 370112538: return bem_cnodeSet_1(bevd_0);
case -2071296654: return bem_instanceEqualSetDirect_1(bevd_0);
case -1275834143: return bem_classCallsSetDirect_1(bevd_0);
case 534077240: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1871952548: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -147461431: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1051165080: return bem_sameObject_1(bevd_0);
case -923256274: return bem_invpSet_1(bevd_0);
case 1438490864: return bem_inFilePathedSetDirect_1(bevd_0);
case 906326077: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -1229467988: return bem_objectCcSet_1(bevd_0);
case -1683300970: return bem_emitLangSet_1(bevd_0);
case -1667731536: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1432611381: return bem_buildSet_1(bevd_0);
case -260362098: return bem_inClassSetDirect_1(bevd_0);
case 2088770629: return bem_intNpSetDirect_1(bevd_0);
case -552651313: return bem_msynSet_1(bevd_0);
case 1158413284: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1029383581: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1431506517: return bem_buildSetDirect_1(bevd_0);
case 1832994631: return bem_trueValueSet_1(bevd_0);
case 1354329194: return bem_synEmitPathSet_1(bevd_0);
case -1732439949: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -416509322: return bem_classConfSetDirect_1(bevd_0);
case 64383944: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1939863837: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -1554068327: return bem_libEmitPathSetDirect_1(bevd_0);
case -875577467: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -651986106: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1244605888: return bem_maxDynArgsSet_1(bevd_0);
case 1695020204: return bem_fullLibEmitNameSet_1(bevd_0);
case -1037648926: return bem_copyTo_1(bevd_0);
case 1216015783: return bem_nullValueSet_1(bevd_0);
case -236737022: return bem_methodCatchSet_1(bevd_0);
case -1507831697: return bem_emitLangSetDirect_1(bevd_0);
case 1221489176: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -2057649456: return bem_end_1(bevd_0);
case 867216347: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1372255702: return bem_boolNpSetDirect_1(bevd_0);
case -2098005038: return bem_callNamesSet_1(bevd_0);
case -88760803: return bem_smnlecsSet_1(bevd_0);
case -744000624: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 101616771: return bem_synEmitPathSetDirect_1(bevd_0);
case -606552192: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1041115620: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1673564896: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 467730220: return bem_otherType_1(bevd_0);
case 2141740909: return bem_otherClass_1(bevd_0);
case -168621282: return bem_boolCcSet_1(bevd_0);
case 1080281551: return bem_libEmitNameSet_1(bevd_0);
case 1274524885: return bem_classEmitsSet_1(bevd_0);
case -562005691: return bem_classConfSet_1(bevd_0);
case -1693232637: return bem_floatNpSet_1(bevd_0);
case -1205550430: return bem_idToNamePathSetDirect_1(bevd_0);
case -1633378880: return bem_methodsSetDirect_1(bevd_0);
case 544063329: return bem_equals_1(bevd_0);
case -122530154: return bem_stringNpSet_1(bevd_0);
case -813880195: return bem_parentConfSet_1(bevd_0);
case 349687306: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1886145624: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1571894165: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 458261040: return bem_ntypesSetDirect_1(bevd_0);
case 492564392: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1023897724: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1256289996: return bem_transSet_1(bevd_0);
case -734314045: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1232381763: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1105226089: return bem_onceDecsSet_1(bevd_0);
case -2136985639: return bem_sameType_1(bevd_0);
case -1103337674: return bem_undefined_1(bevd_0);
case -544997268: return bem_superCallsSet_1(bevd_0);
case 1402363485: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1814109207: return bem_classCallsSet_1(bevd_0);
case -1863694198: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 340892962: return bem_parentConfSetDirect_1(bevd_0);
case 4220314: return bem_nameToIdSetDirect_1(bevd_0);
case 488622977: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1980526755: return bem_qSet_1(bevd_0);
case -592852200: return bem_onceDecsSetDirect_1(bevd_0);
case 1197362150: return bem_csynSet_1(bevd_0);
case 1626722435: return bem_constSet_1(bevd_0);
case -1484499384: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 1987213796: return bem_idToNamePathSet_1(bevd_0);
case 1564869927: return bem_lastMethodsSizeSet_1(bevd_0);
case -1824242132: return bem_qSetDirect_1(bevd_0);
case -1128483666: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1167923007: return bem_stringNpSetDirect_1(bevd_0);
case 1340066555: return bem_invpSetDirect_1(bevd_0);
case 1173812139: return bem_nlSetDirect_1(bevd_0);
case -2136117538: return bem_scvpSet_1(bevd_0);
case -1503012700: return bem_objectCcSetDirect_1(bevd_0);
case 1056498349: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -162735702: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2098940824: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -408161423: return bem_idToNameSetDirect_1(bevd_0);
case 323436812: return bem_preClassSetDirect_1(bevd_0);
case -1073158349: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 44267416: return bem_objectNpSetDirect_1(bevd_0);
case 943792868: return bem_boolCcSetDirect_1(bevd_0);
case 1931429610: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -860510560: return bem_methodBodySetDirect_1(bevd_0);
case -1423089931: return bem_methodCatchSetDirect_1(bevd_0);
case 1098475346: return bem_instOfSetDirect_1(bevd_0);
case 1252901978: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -608070054: return bem_msynSetDirect_1(bevd_0);
case -535478661: return bem_floatNpSetDirect_1(bevd_0);
case 836210587: return bem_propertyDecsSet_1(bevd_0);
case -287668856: return bem_lastCallSet_1(bevd_0);
case 158380114: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1157791894: return bem_inFilePathedSet_1(bevd_0);
case 1025653735: return bem_methodCallsSet_1(bevd_0);
case -184720464: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1375430234: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 719283783: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -716349618: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1676103012: return bem_inClassSet_1(bevd_0);
case -1921324054: return bem_smnlecsSetDirect_1(bevd_0);
case 295070701: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1010808697: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -1448619701: return bem_falseValueSetDirect_1(bevd_0);
case -2113071366: return bem_ntypesSet_1(bevd_0);
case -1537586475: return bem_returnTypeSet_1(bevd_0);
case -1832928179: return bem_mnodeSetDirect_1(bevd_0);
case 199947838: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -962606879: return bem_ccCacheSet_1(bevd_0);
case 1194054136: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1601906278: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1053793088: return bem_dynMethodsSetDirect_1(bevd_0);
case 1106088401: return bem_fileExtSetDirect_1(bevd_0);
case 410491424: return bem_exceptDecSet_1(bevd_0);
case 146949046: return bem_falseValueSet_1(bevd_0);
case -433684926: return bem_randSet_1(bevd_0);
case 1935249863: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -1625072646: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -1682281673: return bem_onceCountSet_1(bevd_0);
case -1124454534: return bem_preClassSet_1(bevd_0);
case -641855555: return bem_mnodeSet_1(bevd_0);
case -1132230483: return bem_methodBodySet_1(bevd_0);
case 581338216: return bem_boolNpSet_1(bevd_0);
case 999671815: return bem_callNamesSetDirect_1(bevd_0);
case 1607544468: return bem_idToNameSet_1(bevd_0);
case 100597300: return bem_exceptDecSetDirect_1(bevd_0);
case -861425493: return bem_libEmitNameSetDirect_1(bevd_0);
case -2101056641: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 369203727: return bem_intNpSet_1(bevd_0);
case 2115430055: return bem_nameToIdPathSet_1(bevd_0);
case -795019035: return bem_ccMethodsSetDirect_1(bevd_0);
case 1036415269: return bem_transSetDirect_1(bevd_0);
case -137211227: return bem_nameToIdSet_1(bevd_0);
case 1212850538: return bem_csynSetDirect_1(bevd_0);
case -471870748: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1357030791: return bem_scvpSetDirect_1(bevd_0);
case 1985057232: return bem_constSetDirect_1(bevd_0);
case 1637482603: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1011008800: return bem_randSetDirect_1(bevd_0);
case 375113695: return bem_nativeCSlotsSet_1(bevd_0);
case 1482027850: return bem_sameClass_1(bevd_0);
case -1620969772: return bem_onceCountSetDirect_1(bevd_0);
case 1900199953: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1363249364: return bem_nullValueSetDirect_1(bevd_0);
case -226381159: return bem_propertyDecsSetDirect_1(bevd_0);
case -767876115: return bem_undef_1(bevd_0);
case 501465133: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 703409242: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1857210868: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -414562689: return bem_instOfSet_1(bevd_0);
case 445215522: return bem_instanceEqualSet_1(bevd_0);
case 843083505: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1259048964: return bem_notEquals_1(bevd_0);
case 1094762935: return bem_smnlcsSet_1(bevd_0);
case -317049327: return bem_def_1(bevd_0);
case 2008108555: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -934949307: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -127180895: return bem_methodsSet_1(bevd_0);
case 1175323797: return bem_libEmitPathSet_1(bevd_0);
case -464114184: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -84882557: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -17711770: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 149603694: return bem_begin_1(bevd_0);
case -1372464538: return bem_returnTypeSetDirect_1(bevd_0);
case 1684998701: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1285036044: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 839437920: return bem_instanceNotEqualSet_1(bevd_0);
case -614864771: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -2105073613: return bem_smnlcsSetDirect_1(bevd_0);
case 268075261: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 573455496: return bem_maxDynArgsSetDirect_1(bevd_0);
case -170042189: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -68783926: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1601836380: return bem_fileExtSet_1(bevd_0);
case 1118935191: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1462005442: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1041597961: return bem_ccCacheSetDirect_1(bevd_0);
case -225685828: return bem_dynMethodsSet_1(bevd_0);
case 926343649: return bem_methodCallsSetDirect_1(bevd_0);
case 1844168065: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1137579565: return bem_lineCountSet_1(bevd_0);
case -1369143562: return bem_cnodeSetDirect_1(bevd_0);
case 1435842653: return bem_ccMethodsSet_1(bevd_0);
case 48926023: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1829649181: return bem_lastMethodsLinesSet_1(bevd_0);
case 698593363: return bem_lastCallSetDirect_1(bevd_0);
case 723109244: return bem_lineCountSetDirect_1(bevd_0);
case -536186181: return bem_trueValueSetDirect_1(bevd_0);
case -84438301: return bem_objectNpSet_1(bevd_0);
case 860340266: return bem_classesInDepthOrderSet_1(bevd_0);
case -109170042: return bem_nameToIdPathSetDirect_1(bevd_0);
case 339103065: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 524539135: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1032782900: return bem_nlSet_1(bevd_0);
case 2114805413: return bem_superCallsSetDirect_1(bevd_0);
case -1617324535: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1343398622: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -657633999: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 419857368: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1850726754: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1155749415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1817204980: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -501479017: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 136033499: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -78432632: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2119495855: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 260222269: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1952485203: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -158176316: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 930768377: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2068762169: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1135810204: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2067866135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1477075576: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1050698004: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -312870745: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1645271178: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1427816813: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 192185692: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -709811609: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -1623003495: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 1473379549: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 238300245: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
}
