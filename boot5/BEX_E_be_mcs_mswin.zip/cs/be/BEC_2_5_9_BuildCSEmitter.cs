namespace be {
/* IO:File: source/build/CSEmitter.be */
public sealed class BEC_2_5_9_BuildCSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
static BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_19, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_22, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_23, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_30, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_31, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_32, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_33, 18));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_31, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_34, 9));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_35, 48));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_37, 38));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_43, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_44, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_45 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_45, 3));
public static new BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static new BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(1244458922);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_18_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = (BEC_2_4_6_TextString) bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(-1024297580);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(-12961780);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = (BEC_2_4_6_TextString) bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(-1024297580);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(-12961780);
if (bevl_firstptsyn.bevi_bool)/* Line: 51*/ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 52*/
 else /* Line: 53*/ {
bevt_34_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 54*/
bevt_36_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_37_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_35_ta_ph = (BEC_2_4_6_TextString) bevt_36_ta_ph.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 56*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_38_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_42_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevt_41_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_43_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_40_ta_ph = (BEC_2_4_6_TextString) bevt_41_ta_ph.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevt_40_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevl_bet.bem_addValue_1(bevt_45_ta_ph);
bevt_48_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_47_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_48_ta_ph);
bevt_49_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_46_ta_ph = (BEC_2_4_6_TextString) bevt_47_ta_ph.bem_addValue_1(bevt_49_ta_ph);
bevt_50_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevt_46_ta_ph.bem_addValue_1(bevt_50_ta_ph);
bevt_51_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_51_ta_ph);
bevt_52_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_52_ta_ph);
bevt_53_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevl_tout.bemd_1(-1883651777, bevl_bet);
bevl_tout.bemd_0(966177429);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevt_0_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_21));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1599063965);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1117833636);
bevt_14_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_24));
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, bevt_16_ta_ph);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_1_ta_ph = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
if (beva_msyn == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_3_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 86*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 86*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 86*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
return bevt_4_ta_ph;
} /* Line: 87*/
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
return bevt_5_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 93*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 93*/
 else /* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 93*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_27));
return bevt_3_ta_ph;
} /* Line: 94*/
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_28));
return bevt_4_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_typeName);
bevt_3_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 122*/ {
bevt_5_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_exceptDec);
bevt_6_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevl_ms = bevt_3_ta_ph.bem_add_1(bevp_nl);
} /* Line: 123*/
 else /* Line: 124*/ {
bevt_9_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevp_exceptDec);
bevt_10_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_10_ta_ph);
bevl_ms = bevt_7_ta_ph.bem_add_1(bevp_nl);
} /* Line: 125*/
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_38));
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevt_13_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_39));
bevt_11_ta_ph = (BEC_2_4_6_TextString) bevt_12_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_40));
bevt_16_ta_ph = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_17_ta_ph);
bevt_16_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_41));
bevt_20_ta_ph = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(-916206427);
bevt_19_ta_ph = (BEC_2_4_6_TextString) bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_42));
bevt_18_ta_ph = (BEC_2_4_6_TextString) bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_18_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_14;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_15;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_5_9_BuildCSEmitter_bevo_16;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_once_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 62, 62, 62, 62, 63, 63, 64, 64, 64, 64, 64, 64, 65, 65, 66, 66, 67, 67, 68, 69, 73, 73, 73, 74, 75, 75, 75, 75, 75, 75, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 82, 82, 86, 0, 86, 86, 86, 0, 0, 0, 0, 0, 87, 87, 89, 89, 93, 93, 93, 0, 0, 0, 94, 94, 96, 96, 100, 100, 104, 104, 104, 104, 104, 109, 110, 111, 111, 111, 112, 118, 118, 118, 118, 118, 118, 122, 122, 122, 123, 123, 123, 123, 123, 125, 125, 125, 125, 125, 127, 127, 127, 127, 127, 127, 128, 128, 128, 129, 129, 129, 129, 129, 129, 129, 129, 130, 134, 134, 134, 138, 138, 138, 138, 138, 138, 138, 142, 142, 146, 146, 146, 150, 150, 150, 150, 154, 154};
public static new int[] bevs_smnlec
 = new int[] {76, 77, 78, 79, 143, 144, 145, 146, 151, 152, 153, 154, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 179, 182, 184, 186, 189, 190, 192, 193, 194, 195, 201, 202, 203, 204, 205, 206, 207, 208, 209, 209, 212, 214, 216, 219, 220, 222, 223, 224, 225, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 303, 304, 313, 315, 318, 323, 324, 326, 329, 333, 336, 339, 343, 344, 346, 347, 355, 360, 361, 363, 366, 370, 373, 374, 376, 377, 381, 382, 389, 390, 391, 392, 393, 399, 400, 401, 402, 403, 404, 413, 414, 415, 416, 417, 418, 447, 448, 449, 451, 452, 453, 454, 455, 458, 459, 460, 461, 462, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 486, 487, 488, 497, 498, 499, 500, 501, 502, 503, 507, 508, 513, 514, 515, 521, 522, 523, 524, 528, 529};
/* BEGIN LINEINFO 
assign 1 16 76
new 0 16 76
assign 1 17 77
new 0 17 77
assign 1 18 78
new 0 18 78
new 1 22 79
assign 1 26 143
classDirGet 0 26 143
assign 1 26 144
fileGet 0 26 144
assign 1 26 145
existsGet 0 26 145
assign 1 26 146
not 0 26 151
assign 1 27 152
classDirGet 0 27 152
assign 1 27 153
fileGet 0 27 153
makeDirs 0 27 154
assign 1 29 156
typePathGet 0 29 156
assign 1 29 157
fileGet 0 29 157
assign 1 29 158
writerGet 0 29 158
assign 1 29 159
open 0 29 159
assign 1 30 160
new 0 30 160
assign 1 31 161
new 0 31 161
addValue 1 31 162
assign 1 32 163
new 0 32 163
assign 1 32 164
addValue 1 32 164
assign 1 32 165
typeEmitNameGet 0 32 165
assign 1 32 166
addValue 1 32 166
assign 1 32 167
new 0 32 167
addValue 1 32 168
assign 1 33 169
new 0 33 169
assign 1 33 170
addValue 1 33 170
assign 1 33 171
typeEmitNameGet 0 33 171
assign 1 33 172
addValue 1 33 172
assign 1 33 173
new 0 33 173
addValue 1 33 174
assign 1 35 175
new 0 35 175
addValue 1 35 176
assign 1 36 177
new 0 36 177
assign 1 37 178
mtdListGet 0 37 178
assign 1 37 179
iteratorGet 0 0 179
assign 1 37 182
hasNextGet 0 37 182
assign 1 37 184
nextGet 0 37 184
assign 1 39 186
new 0 39 186
assign 1 41 189
new 0 41 189
addValue 1 41 190
assign 1 43 192
addValue 1 43 192
assign 1 43 193
nameGet 0 43 193
assign 1 43 194
addValue 1 43 194
addValue 1 43 195
assign 1 45 201
new 0 45 201
addValue 1 45 202
assign 1 46 203
new 0 46 203
addValue 1 46 204
assign 1 48 205
new 0 48 205
addValue 1 48 206
assign 1 49 207
new 0 49 207
assign 1 50 208
ptyListGet 0 50 208
assign 1 50 209
iteratorGet 0 0 209
assign 1 50 212
hasNextGet 0 50 212
assign 1 50 214
nextGet 0 50 214
assign 1 52 216
new 0 52 216
assign 1 54 219
new 0 54 219
addValue 1 54 220
assign 1 56 222
addValue 1 56 222
assign 1 56 223
nameGet 0 56 223
assign 1 56 224
addValue 1 56 224
addValue 1 56 225
assign 1 58 231
new 0 58 231
addValue 1 58 232
assign 1 60 233
new 0 60 233
addValue 1 60 234
assign 1 62 235
new 0 62 235
assign 1 62 236
addValue 1 62 236
assign 1 62 237
typeEmitNameGet 0 62 237
assign 1 62 238
addValue 1 62 238
assign 1 62 239
new 0 62 239
addValue 1 62 240
assign 1 63 241
new 0 63 241
addValue 1 63 242
assign 1 64 243
new 0 64 243
assign 1 64 244
addValue 1 64 244
assign 1 64 245
emitNameGet 0 64 245
assign 1 64 246
addValue 1 64 246
assign 1 64 247
new 0 64 247
addValue 1 64 248
assign 1 65 249
new 0 65 249
addValue 1 65 250
assign 1 66 251
new 0 66 251
addValue 1 66 252
assign 1 67 253
new 0 67 253
addValue 1 67 254
write 1 68 255
close 0 69 256
assign 1 73 278
new 0 73 278
assign 1 73 279
toString 0 73 279
assign 1 73 280
add 1 73 280
incrementValue 0 74 281
assign 1 75 282
new 0 75 282
assign 1 75 283
addValue 1 75 283
assign 1 75 284
addValue 1 75 284
assign 1 75 285
new 0 75 285
assign 1 75 286
addValue 1 75 286
addValue 1 75 287
assign 1 77 288
containedGet 0 77 288
assign 1 77 289
firstGet 0 77 289
assign 1 77 290
containedGet 0 77 290
assign 1 77 291
firstGet 0 77 291
assign 1 77 292
new 0 77 292
assign 1 77 293
add 1 77 293
assign 1 77 294
new 0 77 294
assign 1 77 295
add 1 77 295
assign 1 77 296
new 0 77 296
assign 1 77 297
finalAssign 4 77 297
addValue 1 77 298
assign 1 82 303
new 0 82 303
return 1 82 304
assign 1 86 313
isFinalGet 0 86 313
assign 1 0 315
assign 1 86 318
def 1 86 323
assign 1 86 324
isFinalGet 0 86 324
assign 1 0 326
assign 1 0 329
assign 1 0 333
assign 1 0 336
assign 1 0 339
assign 1 87 343
new 0 87 343
return 1 87 344
assign 1 89 346
new 0 89 346
return 1 89 347
assign 1 93 355
def 1 93 360
assign 1 93 361
isFinalGet 0 93 361
assign 1 0 363
assign 1 0 366
assign 1 0 370
assign 1 94 373
new 0 94 373
return 1 94 374
assign 1 96 376
new 0 96 376
return 1 96 377
assign 1 100 381
new 0 100 381
return 1 100 382
assign 1 104 389
new 0 104 389
assign 1 104 390
add 1 104 390
assign 1 104 391
new 0 104 391
assign 1 104 392
add 1 104 392
return 1 104 393
getCode 2 109 399
assign 1 110 400
toHexString 1 110 400
assign 1 111 401
new 0 111 401
assign 1 111 402
once 0 111 402
addValue 1 111 403
addValue 1 112 404
assign 1 118 413
new 0 118 413
assign 1 118 414
add 1 118 414
assign 1 118 415
new 0 118 415
assign 1 118 416
add 1 118 416
assign 1 118 417
add 1 118 417
return 1 118 418
assign 1 122 447
emitChecksGet 0 122 447
assign 1 122 448
new 0 122 448
assign 1 122 449
has 1 122 449
assign 1 123 451
new 0 123 451
assign 1 123 452
add 1 123 452
assign 1 123 453
new 0 123 453
assign 1 123 454
add 1 123 454
assign 1 123 455
add 1 123 455
assign 1 125 458
new 0 125 458
assign 1 125 459
add 1 125 459
assign 1 125 460
new 0 125 460
assign 1 125 461
add 1 125 461
assign 1 125 462
add 1 125 462
assign 1 127 464
new 0 127 464
assign 1 127 465
addValue 1 127 465
assign 1 127 466
addValue 1 127 466
assign 1 127 467
new 0 127 467
assign 1 127 468
addValue 1 127 468
addValue 1 127 469
assign 1 128 470
new 0 128 470
assign 1 128 471
addValue 1 128 471
addValue 1 128 472
assign 1 129 473
new 0 129 473
assign 1 129 474
addValue 1 129 474
assign 1 129 475
outputPlatformGet 0 129 475
assign 1 129 476
nameGet 0 129 476
assign 1 129 477
addValue 1 129 477
assign 1 129 478
new 0 129 478
assign 1 129 479
addValue 1 129 479
addValue 1 129 480
return 1 130 481
assign 1 134 486
libNameGet 0 134 486
assign 1 134 487
beginNs 1 134 487
return 1 134 488
assign 1 138 497
new 0 138 497
assign 1 138 498
libNs 1 138 498
assign 1 138 499
add 1 138 499
assign 1 138 500
new 0 138 500
assign 1 138 501
add 1 138 501
assign 1 138 502
add 1 138 502
return 1 138 503
assign 1 142 507
getNameSpace 1 142 507
return 1 142 508
assign 1 146 513
new 0 146 513
assign 1 146 514
add 1 146 514
return 1 146 515
assign 1 150 521
new 0 150 521
assign 1 150 522
once 0 150 522
assign 1 150 523
add 1 150 523
return 1 150 524
assign 1 154 528
new 0 154 528
return 1 154 529
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1833080324: return bem_nullValueGet_0();
case 89002488: return bem_onceCountGetDirect_0();
case -723212158: return bem_methodsGet_0();
case 853832565: return bem_parentConfGet_0();
case -1847191937: return bem_lastMethodsSizeGet_0();
case -1018579818: return bem_objectNpGetDirect_0();
case 1781028711: return bem_superCallsGet_0();
case 552113488: return bem_csynGet_0();
case -481256408: return bem_spropDecGet_0();
case 1391274656: return bem_inClassGet_0();
case -710452445: return bem_lastMethodsLinesGet_0();
case 1610102147: return bem_mainInClassGet_0();
case -1872688111: return bem_loadIds_0();
case -1413011054: return bem_returnTypeGetDirect_0();
case 2074140539: return bem_belslitsGet_0();
case -179281693: return bem_preClassOutput_0();
case 32905439: return bem_overrideMtdDecGet_0();
case -522919508: return bem_afterCast_0();
case 157506901: return bem_methodCatchGetDirect_0();
case -282980640: return bem_trueValueGetDirect_0();
case -736025505: return bem_scvpGetDirect_0();
case 789696365: return bem_propertyDecsGetDirect_0();
case 851292767: return bem_cnodeGetDirect_0();
case 239197127: return bem_nullValueGetDirect_0();
case 1330976730: return bem_hashGet_0();
case 163439006: return bem_returnTypeGet_0();
case -608329410: return bem_qGet_0();
case -160735352: return bem_once_0();
case 2141530402: return bem_getClassOutput_0();
case -653753889: return bem_classesInDepthOrderGetDirect_0();
case 1094862804: return bem_boolTypeGet_0();
case -262893633: return bem_maxSpillArgsLenGet_0();
case 872708376: return bem_toAny_0();
case -1581897492: return bem_saveIds_0();
case -241267565: return bem_ccCacheGetDirect_0();
case -309720080: return bem_propDecGet_0();
case -2014542803: return bem_iteratorGet_0();
case -1217444056: return bem_constGet_0();
case -280917091: return bem_fullLibEmitNameGet_0();
case 668610815: return bem_idToNameGetDirect_0();
case -1705055257: return bem_inClassGetDirect_0();
case -542134509: return bem_covariantReturnsGet_0();
case 673533612: return bem_typeDecGet_0();
case 1257548112: return bem_instanceNotEqualGetDirect_0();
case -1923047269: return bem_beginNs_0();
case 1128359778: return bem_synEmitPathGet_0();
case 797867737: return bem_ntypesGet_0();
case 325193639: return bem_smnlecsGetDirect_0();
case -1303407072: return bem_preClassGetDirect_0();
case 923717454: return bem_falseValueGet_0();
case -1341998869: return bem_lastCallGet_0();
case -1533701006: return bem_serializeContents_0();
case -1578325062: return bem_ccMethodsGetDirect_0();
case -1959386608: return bem_methodsGetDirect_0();
case -173842906: return bem_ccCacheGet_0();
case 23203927: return bem_instOfGet_0();
case 1023950793: return bem_boolNpGetDirect_0();
case -1268735591: return bem_randGetDirect_0();
case -1492968755: return bem_mnodeGetDirect_0();
case 181571301: return bem_doEmit_0();
case 1996576414: return bem_libEmitPathGetDirect_0();
case -2119911256: return bem_writeBET_0();
case 588916000: return bem_smnlcsGetDirect_0();
case -1451048410: return bem_new_0();
case 1657477077: return bem_mainEndGet_0();
case -588870906: return bem_lastMethodBodyLinesGetDirect_0();
case 1612415239: return bem_classEndGet_0();
case 1033505681: return bem_idToNamePathGet_0();
case -341461031: return bem_superCallsGetDirect_0();
case -425081215: return bem_mnodeGet_0();
case 608916291: return bem_libEmitPathGet_0();
case 286973089: return bem_useDynMethodsGet_0();
case -831119201: return bem_exceptDecGetDirect_0();
case 1208354139: return bem_sourceFileNameGet_0();
case -1138559814: return bem_idToNamePathGetDirect_0();
case -769130124: return bem_nameToIdPathGetDirect_0();
case 606500052: return bem_qGetDirect_0();
case -206043242: return bem_many_0();
case -738417167: return bem_intNpGetDirect_0();
case 437089080: return bem_print_0();
case -244195527: return bem_classEmitsGet_0();
case -612119659: return bem_mainStartGet_0();
case 878380143: return bem_randGet_0();
case 1343497980: return bem_classConfGet_0();
case 907276784: return bem_serializeToString_0();
case -717163782: return bem_callNamesGetDirect_0();
case 644854602: return bem_lastMethodBodySizeGetDirect_0();
case -1082915607: return bem_smnlcsGet_0();
case -1010955676: return bem_smnlecsGet_0();
case 1200056076: return bem_serializationIteratorGet_0();
case 342540667: return bem_objectCcGetDirect_0();
case 1741169350: return bem_maxDynArgsGet_0();
case 1004594222: return bem_objectNpGet_0();
case 1788022534: return bem_mainOutsideNsGet_0();
case 528051774: return bem_fileExtGetDirect_0();
case 834025277: return bem_cnodeGet_0();
case 40101441: return bem_superNameGet_0();
case 1257048979: return bem_methodCatchGet_0();
case -214881374: return bem_lastMethodsSizeGetDirect_0();
case 2017345633: return bem_copy_0();
case -371749847: return bem_callNamesGet_0();
case -2019098513: return bem_nativeCSlotsGetDirect_0();
case 1967715271: return bem_fullLibEmitNameGetDirect_0();
case -1760434406: return bem_transGetDirect_0();
case -1928643950: return bem_dynMethodsGetDirect_0();
case -1104598657: return bem_synEmitPathGetDirect_0();
case 678368333: return bem_nlGetDirect_0();
case -1419115955: return bem_create_0();
case 1358980007: return bem_maxDynArgsGetDirect_0();
case -545635799: return bem_onceDecsGet_0();
case -1490721678: return bem_parentConfGetDirect_0();
case 906919432: return bem_libEmitNameGetDirect_0();
case 835796661: return bem_buildCreate_0();
case -778954260: return bem_newDecGet_0();
case 278030248: return bem_constGetDirect_0();
case -2108129514: return bem_nativeCSlotsGet_0();
case 370840953: return bem_propertyDecsGet_0();
case -877655258: return bem_invpGet_0();
case 373095154: return bem_classCallsGetDirect_0();
case 989191193: return bem_stringNpGetDirect_0();
case 862788409: return bem_buildGet_0();
case -532757565: return bem_trueValueGet_0();
case -2102217588: return bem_invpGetDirect_0();
case -1022435804: return bem_initialDecGet_0();
case 513387389: return bem_onceCountGet_0();
case -1352780820: return bem_falseValueGetDirect_0();
case -2114265547: return bem_methodCallsGet_0();
case -1593715630: return bem_ntypesGetDirect_0();
case -306616201: return bem_methodBodyGetDirect_0();
case -2140984863: return bem_intNpGet_0();
case 796463180: return bem_lastCallGetDirect_0();
case -1732259953: return bem_onceDecsGetDirect_0();
case -675434334: return bem_buildClassInfo_0();
case -1422545140: return bem_getLibOutput_0();
case 795641113: return bem_boolCcGetDirect_0();
case -813054627: return bem_classEmitsGetDirect_0();
case 1384423002: return bem_transGet_0();
case 312842469: return bem_instanceNotEqualGet_0();
case 103700110: return bem_maxSpillArgsLenGetDirect_0();
case 2059991616: return bem_lastMethodBodySizeGet_0();
case -622712732: return bem_emitLangGet_0();
case -1588672742: return bem_classesInDepthOrderGet_0();
case 1882778775: return bem_fieldIteratorGet_0();
case 117270357: return bem_idToNameGet_0();
case 467055783: return bem_boolNpGet_0();
case -741534279: return bem_gcMarksGet_0();
case -780070882: return bem_floatNpGet_0();
case 34717997: return bem_methodBodyGet_0();
case -1229803830: return bem_deserializeClassNameGet_0();
case 32863190: return bem_belslitsGetDirect_0();
case -1990292643: return bem_toString_0();
case -1297748369: return bem_stringNpGet_0();
case 940055786: return bem_runtimeInitGet_0();
case -154172821: return bem_endNs_0();
case -1704770597: return bem_nameToIdGet_0();
case -741980508: return bem_floatNpGetDirect_0();
case -214647999: return bem_gcMarksGetDirect_0();
case -1970314235: return bem_csynGetDirect_0();
case 1061057969: return bem_instOfGetDirect_0();
case -481005419: return bem_baseMtdDecGet_0();
case 755320147: return bem_lastMethodBodyLinesGet_0();
case 1613794738: return bem_preClassGet_0();
case -2069822342: return bem_fileExtGet_0();
case 1976523732: return bem_lineCountGetDirect_0();
case 636737656: return bem_exceptDecGet_0();
case 1674575712: return bem_classNameGet_0();
case -1397201425: return bem_inFilePathedGet_0();
case 434471495: return bem_dynMethodsGet_0();
case -1534460720: return bem_nlGet_0();
case -50803216: return bem_instanceEqualGet_0();
case 978291767: return bem_buildInitial_0();
case 322928915: return bem_nameToIdPathGet_0();
case -943591803: return bem_classCallsGet_0();
case -911398327: return bem_classConfGetDirect_0();
case 2066642517: return bem_buildGetDirect_0();
case 1865983825: return bem_fieldNamesGet_0();
case 1227631747: return bem_baseSmtdDecGet_0();
case 1450484670: return bem_ccMethodsGet_0();
case 487647791: return bem_saveSyns_0();
case 589115937: return bem_objectCcGet_0();
case -1560434824: return bem_scvpGet_0();
case 578072317: return bem_nameToIdGetDirect_0();
case 667646276: return bem_inFilePathedGetDirect_0();
case -1396098681: return bem_libEmitNameGet_0();
case 48684490: return bem_echo_0();
case 1380917654: return bem_lineCountGet_0();
case -1769146102: return bem_lastMethodsLinesGetDirect_0();
case -195236233: return bem_instanceEqualGetDirect_0();
case 1330037424: return bem_emitLib_0();
case -1664773818: return bem_emitLangGetDirect_0();
case -166013833: return bem_tagGet_0();
case 256446682: return bem_boolCcGet_0();
case 430683525: return bem_msynGet_0();
case -1253270041: return bem_msynGetDirect_0();
case -1914610076: return bem_methodCallsGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -748172198: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -564221675: return bem_nullValueSet_1(bevd_0);
case 237098757: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 909810346: return bem_sameClass_1(bevd_0);
case 491643122: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 723911850: return bem_nullValueSetDirect_1(bevd_0);
case 207627386: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1919354007: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1494021750: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1001788822: return bem_propertyDecsSet_1(bevd_0);
case 767314112: return bem_onceCountSet_1(bevd_0);
case 1014945357: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1999988865: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 970258975: return bem_libEmitPathSet_1(bevd_0);
case -279352105: return bem_undefined_1(bevd_0);
case 625481528: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1406812161: return bem_transSetDirect_1(bevd_0);
case 1319461040: return bem_propertyDecsSetDirect_1(bevd_0);
case 1033036587: return bem_instanceNotEqualSet_1(bevd_0);
case 1238298036: return bem_msynSet_1(bevd_0);
case 2136795361: return bem_methodBodySetDirect_1(bevd_0);
case 56467064: return bem_libEmitNameSetDirect_1(bevd_0);
case 161134859: return bem_defined_1(bevd_0);
case -2049985000: return bem_idToNamePathSetDirect_1(bevd_0);
case -443159716: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1020802032: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1505243111: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1269877432: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1561328648: return bem_otherType_1(bevd_0);
case -297744595: return bem_objectNpSetDirect_1(bevd_0);
case 1949920047: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -353909927: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1327996910: return bem_smnlecsSet_1(bevd_0);
case 1359655989: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1389526851: return bem_stringNpSetDirect_1(bevd_0);
case -1198239153: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2122176784: return bem_undef_1(bevd_0);
case -691436434: return bem_begin_1(bevd_0);
case 2108405871: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -456384105: return bem_trueValueSetDirect_1(bevd_0);
case -1530407250: return bem_nlSetDirect_1(bevd_0);
case -1787409601: return bem_classCallsSet_1(bevd_0);
case 1628739562: return bem_libEmitPathSetDirect_1(bevd_0);
case -1517637963: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 941906783: return bem_nameToIdPathSet_1(bevd_0);
case -185383596: return bem_sameType_1(bevd_0);
case 1788454334: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -582178545: return bem_ccMethodsSetDirect_1(bevd_0);
case 640052158: return bem_randSetDirect_1(bevd_0);
case -1921346162: return bem_smnlecsSetDirect_1(bevd_0);
case -943142052: return bem_classEmitsSet_1(bevd_0);
case 42997928: return bem_lastMethodsSizeSet_1(bevd_0);
case -1891874835: return bem_superCallsSet_1(bevd_0);
case -493279006: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 586375800: return bem_boolCcSetDirect_1(bevd_0);
case -1320027359: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 659052743: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1413849242: return bem_intNpSetDirect_1(bevd_0);
case -1681519321: return bem_lastCallSet_1(bevd_0);
case 2022290337: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1398253301: return bem_maxDynArgsSet_1(bevd_0);
case -1454264985: return bem_idToNameSetDirect_1(bevd_0);
case 1576163448: return bem_trueValueSet_1(bevd_0);
case 235398195: return bem_mnodeSetDirect_1(bevd_0);
case 268661112: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 448678910: return bem_ntypesSet_1(bevd_0);
case 657670376: return bem_ccCacheSetDirect_1(bevd_0);
case 1607214220: return bem_nativeCSlotsSet_1(bevd_0);
case 778364331: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1725462479: return bem_methodsSet_1(bevd_0);
case 1950461660: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 2058785774: return bem_constSet_1(bevd_0);
case -45726815: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1554711529: return bem_floatNpSetDirect_1(bevd_0);
case -1310208163: return bem_idToNamePathSet_1(bevd_0);
case 1945717937: return bem_scvpSet_1(bevd_0);
case -1039385772: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1951352986: return bem_cnodeSet_1(bevd_0);
case -1272785300: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -1353297109: return bem_buildSetDirect_1(bevd_0);
case -1465117689: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1308420194: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 228067749: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 904724431: return bem_methodCallsSet_1(bevd_0);
case 453269734: return bem_inFilePathedSetDirect_1(bevd_0);
case 1583845308: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -952975048: return bem_smnlcsSetDirect_1(bevd_0);
case -1616094339: return bem_buildSet_1(bevd_0);
case 1548683697: return bem_boolCcSet_1(bevd_0);
case -12237083: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1126190417: return bem_maxDynArgsSetDirect_1(bevd_0);
case -51313250: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -442583847: return bem_idToNameSet_1(bevd_0);
case -538980551: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -881275486: return bem_libEmitNameSet_1(bevd_0);
case -1024810424: return bem_onceCountSetDirect_1(bevd_0);
case -395076999: return bem_returnTypeSetDirect_1(bevd_0);
case -1863811936: return bem_dynMethodsSetDirect_1(bevd_0);
case 725333944: return bem_methodCatchSetDirect_1(bevd_0);
case 743332682: return bem_classConfSetDirect_1(bevd_0);
case -2059198415: return bem_ccMethodsSet_1(bevd_0);
case -1257644704: return bem_falseValueSetDirect_1(bevd_0);
case 1986208215: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 121710805: return bem_fullLibEmitNameSet_1(bevd_0);
case 387082650: return bem_exceptDecSet_1(bevd_0);
case 716915581: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 560930939: return bem_nameToIdSet_1(bevd_0);
case -805692436: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 972947062: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1648589840: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -36916110: return bem_methodCatchSet_1(bevd_0);
case -1481427497: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1823550413: return bem_superCallsSetDirect_1(bevd_0);
case -2264662: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 190111245: return bem_stringNpSet_1(bevd_0);
case -303965840: return bem_dynMethodsSet_1(bevd_0);
case 1484567824: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -623757830: return bem_parentConfSet_1(bevd_0);
case -345530779: return bem_cnodeSetDirect_1(bevd_0);
case 1728149647: return bem_classEmitsSetDirect_1(bevd_0);
case -429821766: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 354557818: return bem_equals_1(bevd_0);
case 1999961458: return bem_synEmitPathSet_1(bevd_0);
case -910373087: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -332644770: return bem_end_1(bevd_0);
case 1153143612: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 2035866723: return bem_randSet_1(bevd_0);
case 1951809293: return bem_ntypesSetDirect_1(bevd_0);
case 374781083: return bem_methodBodySet_1(bevd_0);
case 1287940387: return bem_instanceEqualSet_1(bevd_0);
case -2100432374: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -268521893: return bem_instOfSetDirect_1(bevd_0);
case 601808286: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 908990693: return bem_nameToIdSetDirect_1(bevd_0);
case 584123032: return bem_def_1(bevd_0);
case -840953319: return bem_notEquals_1(bevd_0);
case 481194340: return bem_csynSet_1(bevd_0);
case -184372408: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1114338275: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1920998617: return bem_sameObject_1(bevd_0);
case 1505934601: return bem_gcMarksSet_1(bevd_0);
case -391962880: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1141566853: return bem_methodsSetDirect_1(bevd_0);
case -1418177884: return bem_methodCallsSetDirect_1(bevd_0);
case -1306142247: return bem_transSet_1(bevd_0);
case 701750781: return bem_objectCcSet_1(bevd_0);
case -25591863: return bem_objectNpSet_1(bevd_0);
case -302344233: return bem_classCallsSetDirect_1(bevd_0);
case 1439132366: return bem_preClassSetDirect_1(bevd_0);
case -116267513: return bem_smnlcsSet_1(bevd_0);
case 140816824: return bem_csynSetDirect_1(bevd_0);
case -759212768: return bem_lastMethodsLinesSet_1(bevd_0);
case -734706513: return bem_parentConfSetDirect_1(bevd_0);
case -149561206: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -1738615194: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 661986637: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1957561572: return bem_floatNpSet_1(bevd_0);
case -813682115: return bem_synEmitPathSetDirect_1(bevd_0);
case 285580831: return bem_emitLangSet_1(bevd_0);
case -1139944772: return bem_objectCcSetDirect_1(bevd_0);
case 1300919203: return bem_classConfSet_1(bevd_0);
case -813258193: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -825296333: return bem_gcMarksSetDirect_1(bevd_0);
case -1747716140: return bem_instanceEqualSetDirect_1(bevd_0);
case 378284461: return bem_fileExtSet_1(bevd_0);
case 252490283: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1822027791: return bem_otherClass_1(bevd_0);
case 483173634: return bem_onceDecsSet_1(bevd_0);
case -1346540013: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2084505365: return bem_lastCallSetDirect_1(bevd_0);
case 2056490313: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 795204528: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 589900107: return bem_qSetDirect_1(bevd_0);
case 616680079: return bem_exceptDecSetDirect_1(bevd_0);
case 643730377: return bem_ccCacheSet_1(bevd_0);
case -847381890: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 644308082: return bem_falseValueSet_1(bevd_0);
case 519908725: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1890809107: return bem_inClassSetDirect_1(bevd_0);
case -970017727: return bem_emitLangSetDirect_1(bevd_0);
case -428127051: return bem_scvpSetDirect_1(bevd_0);
case -1644351644: return bem_inFilePathedSet_1(bevd_0);
case -1958201403: return bem_returnTypeSet_1(bevd_0);
case -85334475: return bem_preClassSet_1(bevd_0);
case -770962975: return bem_msynSetDirect_1(bevd_0);
case -2068018884: return bem_mnodeSet_1(bevd_0);
case -778890064: return bem_belslitsSet_1(bevd_0);
case -1342042481: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 258408678: return bem_classesInDepthOrderSet_1(bevd_0);
case 353404234: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1448990170: return bem_boolNpSetDirect_1(bevd_0);
case -946790158: return bem_lineCountSet_1(bevd_0);
case -957931049: return bem_boolNpSet_1(bevd_0);
case 2073162558: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1517267444: return bem_callNamesSetDirect_1(bevd_0);
case 1136793635: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1198507900: return bem_onceDecsSetDirect_1(bevd_0);
case -1303655002: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 713581423: return bem_constSetDirect_1(bevd_0);
case 1508179087: return bem_lineCountSetDirect_1(bevd_0);
case -518047533: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 2105110596: return bem_nameToIdPathSetDirect_1(bevd_0);
case 1596863802: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -933369721: return bem_qSet_1(bevd_0);
case 6642322: return bem_intNpSet_1(bevd_0);
case 272081757: return bem_inClassSet_1(bevd_0);
case 1732176829: return bem_nlSet_1(bevd_0);
case 381634908: return bem_callNamesSet_1(bevd_0);
case 2120516283: return bem_fileExtSetDirect_1(bevd_0);
case -1791322503: return bem_invpSet_1(bevd_0);
case 1142250735: return bem_belslitsSetDirect_1(bevd_0);
case 1247692832: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 2134066079: return bem_invpSetDirect_1(bevd_0);
case -25274143: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1963812721: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1198465319: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 170216407: return bem_copyTo_1(bevd_0);
case -4215458: return bem_instOfSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 936076332: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1702878339: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1897967875: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1664783630: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1540430634: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 338839951: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1579081197: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -758649425: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1467883232: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 465709808: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 105253121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2109793977: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -548105507: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -29810702: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 622406268: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 175222937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 750543846: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1903015196: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -509614296: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1663517365: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 806591986: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1320050449: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1477719473: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -724545746: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1476090561: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -1323191926: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -435357440: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1875805073: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
}
