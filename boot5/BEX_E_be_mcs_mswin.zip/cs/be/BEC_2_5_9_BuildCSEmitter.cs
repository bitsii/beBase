namespace be {
/* IO:File: source/build/CSEmitter.be */
public sealed class BEC_2_5_9_BuildCSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
static BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_21, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_24, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_33, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_34, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_35, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 18));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_38, 38));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_39, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_45 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_45, 10));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_46 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_46, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_47 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_47, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_48 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_48, 3));
public static new BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static new BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_8_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
bevt_4_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_fileGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_existsGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_6_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_5_tmpany_phold.bem_makeDirs_0();
} /* Line: 28 */
bevt_9_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_fileGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_7_tmpany_phold.bemd_0(2007080127);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_11_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_16_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_21_tmpany_phold);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_22_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_22_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_23_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-26359499);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(-2060874566);
if (bevl_firstmnsyn.bevi_bool) /* Line: 39 */ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 40 */
 else  /* Line: 41 */ {
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_24_tmpany_phold);
} /* Line: 42 */
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_27_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) bevt_26_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 44 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevt_31_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevl_bet.bem_addValue_1(bevt_36_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) bevt_38_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_37_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevl_bet.bem_addValue_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevl_bet.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevl_bet.bem_addValue_1(bevt_44_tmpany_phold);
bevl_tout.bemd_1(1354761082, bevl_bet);
bevl_tout.bemd_0(-770443915);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(2048906136);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(786691626);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, bevt_16_tmpany_phold);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_27));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
if (beva_msyn == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_3_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
 else  /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_28));
return bevt_4_tmpany_phold;
} /* Line: 75 */
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
return bevt_3_tmpany_phold;
} /* Line: 82 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_40));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_41));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_42));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_43));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(594614948);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_44));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 23, 27, 27, 27, 27, 27, 28, 28, 28, 30, 30, 30, 30, 31, 32, 32, 33, 33, 33, 33, 33, 33, 34, 34, 34, 34, 34, 34, 36, 36, 37, 38, 38, 0, 38, 38, 40, 42, 42, 44, 44, 44, 44, 46, 46, 47, 47, 48, 48, 50, 50, 50, 50, 50, 50, 51, 51, 52, 52, 52, 52, 52, 52, 53, 53, 54, 54, 55, 55, 56, 57, 61, 61, 61, 62, 63, 63, 63, 63, 63, 63, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 70, 70, 74, 0, 74, 74, 74, 0, 0, 0, 0, 0, 75, 75, 77, 77, 81, 81, 81, 0, 0, 0, 82, 82, 84, 84, 88, 88, 92, 92, 92, 92, 92, 97, 98, 99, 99, 99, 100, 106, 106, 106, 106, 106, 106, 110, 110, 110, 110, 110, 111, 111, 111, 111, 111, 111, 112, 112, 112, 113, 113, 113, 113, 113, 113, 113, 113, 114, 118, 118, 118, 122, 122, 122, 122, 122, 122, 122, 126, 126, 130, 130, 130, 134, 134, 134, 134, 138, 138};
public static new int[] bevs_smnlec
 = new int[] {76, 77, 78, 79, 132, 133, 134, 135, 140, 141, 142, 143, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 168, 171, 173, 175, 178, 179, 181, 182, 183, 184, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 264, 265, 274, 276, 279, 284, 285, 287, 290, 294, 297, 300, 304, 305, 307, 308, 316, 321, 322, 324, 327, 331, 334, 335, 337, 338, 342, 343, 350, 351, 352, 353, 354, 360, 361, 362, 363, 364, 365, 374, 375, 376, 377, 378, 379, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 428, 429, 430, 439, 440, 441, 442, 443, 444, 445, 449, 450, 455, 456, 457, 463, 464, 465, 466, 470, 471};
/* BEGIN LINEINFO 
assign 1 17 76
new 0 17 76
assign 1 18 77
new 0 18 77
assign 1 19 78
new 0 19 78
new 1 23 79
assign 1 27 132
classDirGet 0 27 132
assign 1 27 133
fileGet 0 27 133
assign 1 27 134
existsGet 0 27 134
assign 1 27 135
not 0 27 140
assign 1 28 141
classDirGet 0 28 141
assign 1 28 142
fileGet 0 28 142
makeDirs 0 28 143
assign 1 30 145
typePathGet 0 30 145
assign 1 30 146
fileGet 0 30 146
assign 1 30 147
writerGet 0 30 147
assign 1 30 148
open 0 30 148
assign 1 31 149
new 0 31 149
assign 1 32 150
new 0 32 150
addValue 1 32 151
assign 1 33 152
new 0 33 152
assign 1 33 153
addValue 1 33 153
assign 1 33 154
typeEmitNameGet 0 33 154
assign 1 33 155
addValue 1 33 155
assign 1 33 156
new 0 33 156
addValue 1 33 157
assign 1 34 158
new 0 34 158
assign 1 34 159
addValue 1 34 159
assign 1 34 160
typeEmitNameGet 0 34 160
assign 1 34 161
addValue 1 34 161
assign 1 34 162
new 0 34 162
addValue 1 34 163
assign 1 36 164
new 0 36 164
addValue 1 36 165
assign 1 37 166
new 0 37 166
assign 1 38 167
mtdListGet 0 38 167
assign 1 38 168
iteratorGet 0 0 168
assign 1 38 171
hasNextGet 0 38 171
assign 1 38 173
nextGet 0 38 173
assign 1 40 175
new 0 40 175
assign 1 42 178
new 0 42 178
addValue 1 42 179
assign 1 44 181
addValue 1 44 181
assign 1 44 182
nameGet 0 44 182
assign 1 44 183
addValue 1 44 183
addValue 1 44 184
assign 1 46 190
new 0 46 190
addValue 1 46 191
assign 1 47 192
new 0 47 192
addValue 1 47 193
assign 1 48 194
new 0 48 194
addValue 1 48 195
assign 1 50 196
new 0 50 196
assign 1 50 197
addValue 1 50 197
assign 1 50 198
typeEmitNameGet 0 50 198
assign 1 50 199
addValue 1 50 199
assign 1 50 200
new 0 50 200
addValue 1 50 201
assign 1 51 202
new 0 51 202
addValue 1 51 203
assign 1 52 204
new 0 52 204
assign 1 52 205
addValue 1 52 205
assign 1 52 206
emitNameGet 0 52 206
assign 1 52 207
addValue 1 52 207
assign 1 52 208
new 0 52 208
addValue 1 52 209
assign 1 53 210
new 0 53 210
addValue 1 53 211
assign 1 54 212
new 0 54 212
addValue 1 54 213
assign 1 55 214
new 0 55 214
addValue 1 55 215
write 1 56 216
close 0 57 217
assign 1 61 239
new 0 61 239
assign 1 61 240
toString 0 61 240
assign 1 61 241
add 1 61 241
incrementValue 0 62 242
assign 1 63 243
new 0 63 243
assign 1 63 244
addValue 1 63 244
assign 1 63 245
addValue 1 63 245
assign 1 63 246
new 0 63 246
assign 1 63 247
addValue 1 63 247
addValue 1 63 248
assign 1 65 249
containedGet 0 65 249
assign 1 65 250
firstGet 0 65 250
assign 1 65 251
containedGet 0 65 251
assign 1 65 252
firstGet 0 65 252
assign 1 65 253
new 0 65 253
assign 1 65 254
add 1 65 254
assign 1 65 255
new 0 65 255
assign 1 65 256
add 1 65 256
assign 1 65 257
new 0 65 257
assign 1 65 258
finalAssign 4 65 258
addValue 1 65 259
assign 1 70 264
new 0 70 264
return 1 70 265
assign 1 74 274
isFinalGet 0 74 274
assign 1 0 276
assign 1 74 279
def 1 74 284
assign 1 74 285
isFinalGet 0 74 285
assign 1 0 287
assign 1 0 290
assign 1 0 294
assign 1 0 297
assign 1 0 300
assign 1 75 304
new 0 75 304
return 1 75 305
assign 1 77 307
new 0 77 307
return 1 77 308
assign 1 81 316
def 1 81 321
assign 1 81 322
isFinalGet 0 81 322
assign 1 0 324
assign 1 0 327
assign 1 0 331
assign 1 82 334
new 0 82 334
return 1 82 335
assign 1 84 337
new 0 84 337
return 1 84 338
assign 1 88 342
new 0 88 342
return 1 88 343
assign 1 92 350
new 0 92 350
assign 1 92 351
add 1 92 351
assign 1 92 352
new 0 92 352
assign 1 92 353
add 1 92 353
return 1 92 354
getCode 2 97 360
assign 1 98 361
toHexString 1 98 361
assign 1 99 362
new 0 99 362
assign 1 99 363
once 0 99 363
addValue 1 99 364
addValue 1 100 365
assign 1 106 374
new 0 106 374
assign 1 106 375
add 1 106 375
assign 1 106 376
new 0 106 376
assign 1 106 377
add 1 106 377
assign 1 106 378
add 1 106 378
return 1 106 379
assign 1 110 401
new 0 110 401
assign 1 110 402
add 1 110 402
assign 1 110 403
new 0 110 403
assign 1 110 404
add 1 110 404
assign 1 110 405
add 1 110 405
assign 1 111 406
new 0 111 406
assign 1 111 407
addValue 1 111 407
assign 1 111 408
addValue 1 111 408
assign 1 111 409
new 0 111 409
assign 1 111 410
addValue 1 111 410
addValue 1 111 411
assign 1 112 412
new 0 112 412
assign 1 112 413
addValue 1 112 413
addValue 1 112 414
assign 1 113 415
new 0 113 415
assign 1 113 416
addValue 1 113 416
assign 1 113 417
outputPlatformGet 0 113 417
assign 1 113 418
nameGet 0 113 418
assign 1 113 419
addValue 1 113 419
assign 1 113 420
new 0 113 420
assign 1 113 421
addValue 1 113 421
addValue 1 113 422
return 1 114 423
assign 1 118 428
libNameGet 0 118 428
assign 1 118 429
beginNs 1 118 429
return 1 118 430
assign 1 122 439
new 0 122 439
assign 1 122 440
libNs 1 122 440
assign 1 122 441
add 1 122 441
assign 1 122 442
new 0 122 442
assign 1 122 443
add 1 122 443
assign 1 122 444
add 1 122 444
return 1 122 445
assign 1 126 449
getNameSpace 1 126 449
return 1 126 450
assign 1 130 455
new 0 130 455
assign 1 130 456
add 1 130 456
return 1 130 457
assign 1 134 463
new 0 134 463
assign 1 134 464
once 0 134 464
assign 1 134 465
add 1 134 465
return 1 134 466
assign 1 138 470
new 0 138 470
return 1 138 471
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -855254159: return bem_lastMethodsLinesGet_0();
case 1624944174: return bem_serializationIteratorGet_0();
case 39769312: return bem_lastMethodBodyLinesGet_0();
case 1596390344: return bem_emitLangGet_0();
case -999727106: return bem_boolTypeGet_0();
case -152803575: return bem_tagGet_0();
case -168106659: return bem_mnodeGet_0();
case 1757386931: return bem_synEmitPathGet_0();
case 1511030285: return bem_msynGet_0();
case 372806355: return bem_emitLib_0();
case 139618539: return bem_nameToIdGet_0();
case 1033872092: return bem_methodsGet_0();
case 682679642: return bem_buildGet_0();
case 385489744: return bem_iteratorGet_0();
case -1706550611: return bem_methodBodyGet_0();
case 1334927002: return bem_create_0();
case 1002567176: return bem_libEmitPathGet_0();
case -1598491437: return bem_endNs_0();
case -1618533783: return bem_serializeToString_0();
case 1149815960: return bem_fileExtGet_0();
case 703488083: return bem_trueValueGet_0();
case -914943787: return bem_toString_0();
case -1558494121: return bem_ntypesGet_0();
case 1442085734: return bem_constGet_0();
case -1942605555: return bem_toAny_0();
case -1620303979: return bem_once_0();
case 2110768645: return bem_baseSmtdDecGet_0();
case -364829878: return bem_doEmit_0();
case 1353564137: return bem_transGet_0();
case -1404509481: return bem_classCallsGet_0();
case 1267130388: return bem_mainInClassGet_0();
case 391155206: return bem_exceptDecGet_0();
case -1045152636: return bem_lastCallGet_0();
case -739358482: return bem_callNamesGet_0();
case 582747917: return bem_useDynMethodsGet_0();
case -999088817: return bem_stringNpGet_0();
case 1347498479: return bem_maxSpillArgsLenGet_0();
case -481968064: return bem_classEmitsGet_0();
case -892576391: return bem_classesInDepthOrderGet_0();
case 1451327075: return bem_parentConfGet_0();
case 412104333: return bem_boolCcGet_0();
case 342664202: return bem_serializeContents_0();
case 1604950789: return bem_initialDecGet_0();
case 1212741417: return bem_ccCacheGet_0();
case -118800328: return bem_cnodeGet_0();
case -574151444: return bem_ccMethodsGet_0();
case -1247002346: return bem_objectCcGet_0();
case 1639122056: return bem_propertyDecsGet_0();
case -1489889009: return bem_lineCountGet_0();
case 1773724573: return bem_baseMtdDecGet_0();
case -500687892: return bem_idToNameGet_0();
case -849732178: return bem_objectNpGet_0();
case -1517809024: return bem_invpGet_0();
case -698270568: return bem_smnlecsGet_0();
case -137030833: return bem_overrideMtdDecGet_0();
case -420724161: return bem_lastMethodBodySizeGet_0();
case 1898883366: return bem_preClassGet_0();
case -151249409: return bem_scvpGet_0();
case 334471294: return bem_returnTypeGet_0();
case 1303634739: return bem_intNpGet_0();
case -1732379970: return bem_instOfGet_0();
case -60450551: return bem_qGet_0();
case -1549022074: return bem_coanyiantReturnsGet_0();
case -1117992648: return bem_hashGet_0();
case -1983041492: return bem_classConfGet_0();
case -1487734014: return bem_csynGet_0();
case 1374637160: return bem_smnlcsGet_0();
case -537358356: return bem_nativeCSlotsGet_0();
case -1472344384: return bem_fullLibEmitNameGet_0();
case -1888873123: return bem_methodCallsGet_0();
case 633562104: return bem_afterCast_0();
case -103421699: return bem_buildInitial_0();
case -1350679633: return bem_maxDynArgsGet_0();
case -1330722321: return bem_nlGet_0();
case -1661403228: return bem_getClassOutput_0();
case 2071634342: return bem_onceDecsGet_0();
case -1621511032: return bem_propDecGet_0();
case 1081413631: return bem_buildCreate_0();
case 1206859168: return bem_falseValueGet_0();
case -1763242152: return bem_spropDecGet_0();
case 93356535: return bem_deserializeClassNameGet_0();
case 1280569362: return bem_fieldIteratorGet_0();
case 1099128486: return bem_echo_0();
case -260527082: return bem_instanceEqualGet_0();
case 1525937367: return bem_superCallsGet_0();
case -1414360234: return bem_lastMethodsSizeGet_0();
case 1418767123: return bem_getLibOutput_0();
case -40549095: return bem_superNameGet_0();
case -2134488620: return bem_floatNpGet_0();
case -2083341529: return bem_writeBET_0();
case 223887733: return bem_beginNs_0();
case -1752060037: return bem_methodCatchGet_0();
case 1754519730: return bem_classNameGet_0();
case -1244280210: return bem_mainStartGet_0();
case -1749035302: return bem_copy_0();
case -1434088834: return bem_inFilePathedGet_0();
case -813290991: return bem_buildClassInfo_0();
case 1947493020: return bem_saveSyns_0();
case -2135356756: return bem_dynMethodsGet_0();
case 18576657: return bem_onceCountGet_0();
case -1481274317: return bem_nullValueGet_0();
case -1913920105: return bem_typeDecGet_0();
case -1920078604: return bem_sourceFileNameGet_0();
case -541227487: return bem_new_0();
case 2002331218: return bem_classEndGet_0();
case 38289726: return bem_print_0();
case 201707345: return bem_libEmitNameGet_0();
case -1765439981: return bem_mainEndGet_0();
case -1355051191: return bem_boolNpGet_0();
case 1839660356: return bem_runtimeInitGet_0();
case -1248348608: return bem_many_0();
case -20674648: return bem_mainOutsideNsGet_0();
case -1802498397: return bem_instanceNotEqualGet_0();
case 149141073: return bem_randGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -864169695: return bem_randSet_1(bevd_0);
case -1422561283: return bem_floatNpSet_1(bevd_0);
case 1681540348: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 900128657: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1632282212: return bem_propertyDecsSet_1(bevd_0);
case 386964373: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -597710679: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1971982409: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1183684697: return bem_nullValueSet_1(bevd_0);
case 1881386718: return bem_classesInDepthOrderSet_1(bevd_0);
case -1001167064: return bem_def_1(bevd_0);
case 1920889962: return bem_inFilePathedSet_1(bevd_0);
case -3756322: return bem_preClassSet_1(bevd_0);
case -159013933: return bem_classEmitsSet_1(bevd_0);
case 112488084: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -106539960: return bem_fullLibEmitNameSet_1(bevd_0);
case -1403073110: return bem_synEmitPathSet_1(bevd_0);
case -1247312059: return bem_methodCatchSet_1(bevd_0);
case 1621827503: return bem_csynSet_1(bevd_0);
case -1137140510: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1735346900: return bem_smnlecsSet_1(bevd_0);
case 201825107: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -643116125: return bem_returnTypeSet_1(bevd_0);
case 775829179: return bem_end_1(bevd_0);
case 589015080: return bem_otherType_1(bevd_0);
case 1752222743: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1952032161: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 379550532: return bem_superCallsSet_1(bevd_0);
case -946854303: return bem_constSet_1(bevd_0);
case -36576280: return bem_scvpSet_1(bevd_0);
case -995231374: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -929975460: return bem_equals_1(bevd_0);
case -1741262909: return bem_qSet_1(bevd_0);
case 2062091735: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 934176823: return bem_methodBodySet_1(bevd_0);
case -2073177538: return bem_methodCallsSet_1(bevd_0);
case 1694285846: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 778334465: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -406377870: return bem_copyTo_1(bevd_0);
case -2145912021: return bem_mnodeSet_1(bevd_0);
case 1685232431: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -324026669: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1765448471: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -2038006157: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 505374667: return bem_stringNpSet_1(bevd_0);
case 1007450147: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1179426942: return bem_objectNpSet_1(bevd_0);
case -2057956567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1844792679: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -282920986: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1667048917: return bem_emitLangSet_1(bevd_0);
case -1079776340: return bem_lastMethodsLinesSet_1(bevd_0);
case -947035684: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -147916244: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -957470643: return bem_trueValueSet_1(bevd_0);
case -468479547: return bem_callNamesSet_1(bevd_0);
case -2016798747: return bem_fileExtSet_1(bevd_0);
case 408844820: return bem_undefined_1(bevd_0);
case -1324648847: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -900790842: return bem_defined_1(bevd_0);
case -274501637: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -864656959: return bem_ccMethodsSet_1(bevd_0);
case -1584743880: return bem_parentConfSet_1(bevd_0);
case 318691263: return bem_lastCallSet_1(bevd_0);
case 32553456: return bem_sameType_1(bevd_0);
case 2077409857: return bem_boolCcSet_1(bevd_0);
case -514485147: return bem_onceDecsSet_1(bevd_0);
case 905415945: return bem_begin_1(bevd_0);
case 1222671281: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 960625295: return bem_notEquals_1(bevd_0);
case 1356842566: return bem_otherClass_1(bevd_0);
case -1953494001: return bem_nativeCSlotsSet_1(bevd_0);
case -1975825183: return bem_sameObject_1(bevd_0);
case -2043366730: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1529688: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1864183116: return bem_falseValueSet_1(bevd_0);
case -1553866014: return bem_sameClass_1(bevd_0);
case 1980107888: return bem_instanceNotEqualSet_1(bevd_0);
case -2118907209: return bem_lastMethodsSizeSet_1(bevd_0);
case -2128169405: return bem_lineCountSet_1(bevd_0);
case 240357334: return bem_maxDynArgsSet_1(bevd_0);
case 734390949: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 113084351: return bem_onceCountSet_1(bevd_0);
case 707827795: return bem_lastMethodBodySizeSet_1(bevd_0);
case 597490481: return bem_cnodeSet_1(bevd_0);
case 1005433624: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1216622033: return bem_buildSet_1(bevd_0);
case -1324466540: return bem_objectCcSet_1(bevd_0);
case -1521648050: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1479045669: return bem_dynMethodsSet_1(bevd_0);
case 2061513706: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 327551615: return bem_undef_1(bevd_0);
case 1820910142: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -985461870: return bem_msynSet_1(bevd_0);
case -1138381648: return bem_libEmitNameSet_1(bevd_0);
case 1209791403: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 769151235: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1796124572: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -466128433: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 923028866: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -211471945: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1205000695: return bem_ccCacheSet_1(bevd_0);
case -1058945459: return bem_instanceEqualSet_1(bevd_0);
case 1319517865: return bem_invpSet_1(bevd_0);
case 393257421: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1672365254: return bem_intNpSet_1(bevd_0);
case 849227650: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -467884538: return bem_instOfSet_1(bevd_0);
case 717383448: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1052704201: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1417404860: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2117277380: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -230618094: return bem_methodsSet_1(bevd_0);
case 1918430425: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 983325312: return bem_boolNpSet_1(bevd_0);
case 369882525: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -2023895688: return bem_idToNameSet_1(bevd_0);
case -2012889761: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 493026404: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1401612871: return bem_libEmitPathSet_1(bevd_0);
case 604395294: return bem_classCallsSet_1(bevd_0);
case -633317773: return bem_nameToIdSet_1(bevd_0);
case -818587669: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 941456754: return bem_transSet_1(bevd_0);
case 1740353651: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -965095765: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -72034333: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1811180132: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 913622682: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 697950594: return bem_exceptDecSet_1(bevd_0);
case 1669123607: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 941464532: return bem_smnlcsSet_1(bevd_0);
case -1061899107: return bem_classConfSet_1(bevd_0);
case 719368469: return bem_nlSet_1(bevd_0);
case -728701270: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1754927066: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 74189568: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -431709525: return bem_ntypesSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1773287363: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1615755198: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 254021186: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 521875827: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1660210511: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1370390231: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 2146839633: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1183458920: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 161064: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 914119897: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -176370393: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1344222461: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -294037420: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 917023219: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1737092559: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 56185872: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1722418125: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1794036335: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1330737564: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1368984449: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -2050791071: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 88821919: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1768140535: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 65583050: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1476093461: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 1827175886: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
}
