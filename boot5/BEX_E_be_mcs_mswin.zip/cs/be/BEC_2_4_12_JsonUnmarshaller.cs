namespace be {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_12_JsonUnmarshaller : BEC_2_6_6_SystemObject {
public BEC_2_4_12_JsonUnmarshaller() { }
static BEC_2_4_12_JsonUnmarshaller() { }
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x55,0x6E,0x6D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_0 = {0x75,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_1 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_2 = {0x6B,0x65,0x79,0x20,0x75,0x6E,0x64,0x65,0x66,0x20,0x69,0x6E,0x20,0x6B,0x76,0x6D,0x69,0x64};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_3 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
public static new BEC_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;
public BEC_2_4_6_JsonParser bevp_parser;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_9_4_ContainerPair bevp_pair;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_5_ContainerStack bevp_stack;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_parser = (BEC_2_4_6_JsonParser) (new BEC_2_4_6_JsonParser()).bem_new_0();
bevp_list = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_pair = (BEC_2_9_4_ContainerPair) (new BEC_2_9_4_ContainerPair()).bem_new_0();
bevp_map = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_first = null;
bevp_stack = (BEC_2_9_5_ContainerStack) (new BEC_2_9_5_ContainerStack()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_unmarshall_1(BEC_2_4_6_TextString beva_str) {
bem_new_0();
bevp_parser.bem_parse_2(beva_str, this);
return bevp_first;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_addIn_1(BEC_2_6_6_SystemObject beva_o) {
BEC_2_6_6_SystemObject bevl_top = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_first == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevp_first = beva_o;
} /* Line: 485 */
bevl_top = bevp_stack.bem_peek_0();
if (bevl_top == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 488 */ {
bevt_2_tmpany_phold = bevl_top.bemd_1(631500772, BEX_E.bevn_sameClass_1, bevp_pair);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevt_4_tmpany_phold = bevl_top.bemd_0(242848115, BEX_E.bevn_secondGet_0);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 490 */ {
bevt_5_tmpany_phold = bevl_top.bemd_0(-183400265, BEX_E.bevn_firstGet_0);
bevt_6_tmpany_phold = bevl_top.bemd_0(242848115, BEX_E.bevn_secondGet_0);
bevt_5_tmpany_phold.bemd_2(107034370, BEX_E.bevn_put_2, bevt_6_tmpany_phold, beva_o);
bevl_top.bemd_1(253930368, BEX_E.bevn_secondSet_1, null);
} /* Line: 492 */
 else  /* Line: 493 */ {
bevl_top.bemd_1(253930368, BEX_E.bevn_secondSet_1, beva_o);
} /* Line: 494 */
} /* Line: 490 */
 else  /* Line: 489 */ {
bevt_7_tmpany_phold = bevl_top.bemd_1(631500772, BEX_E.bevn_sameClass_1, bevp_list);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 496 */ {
bevl_top.bemd_1(-228068295, BEX_E.bevn_addValueWhole_1, beva_o);
} /* Line: 497 */
 else  /* Line: 498 */ {
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_4_12_JsonUnmarshaller_bels_0));
bevt_8_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpany_phold);
} /* Line: 499 */
} /* Line: 489 */
} /* Line: 489 */
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_beginMap_0() {
BEC_2_9_3_ContainerMap bevl_m = null;
BEC_2_9_4_ContainerPair bevt_0_tmpany_phold = null;
bevl_m = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bem_addIn_1(bevl_m);
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerPair) (new BEC_2_9_4_ContainerPair()).bem_new_2(bevl_m, null);
bevp_stack.bem_push_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_endMap_0() {
BEC_2_9_4_ContainerPair bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 513 */ {
bevl_p = (BEC_2_9_4_ContainerPair) bevp_stack.bem_pop_0();
} /* Line: 514 */
 else  /* Line: 515 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_4_12_JsonUnmarshaller_bels_1));
bevt_1_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 516 */
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_kvMid_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_stack.bem_peek_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(631500772, BEX_E.bevn_sameClass_1, bevp_pair);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(105008580, BEX_E.bevn_not_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 522 */ {
bevt_6_tmpany_phold = bevp_stack.bem_peek_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(242848115, BEX_E.bevn_secondGet_0);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 522 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 522 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_4_12_JsonUnmarshaller_bels_2));
bevt_7_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 523 */
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_beginList_0() {
BEC_2_9_4_ContainerList bevl_l = null;
bevl_l = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bem_addIn_1(bevl_l);
bevp_stack.bem_push_1(bevl_l);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_endList_0() {
BEC_2_9_4_ContainerList bevl_l = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 536 */ {
bevl_l = (BEC_2_9_4_ContainerList) bevp_stack.bem_pop_0();
} /* Line: 537 */
 else  /* Line: 538 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_4_12_JsonUnmarshaller_bels_3));
bevt_1_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 539 */
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleString_1(BEC_2_4_6_TextString beva_str) {
bem_addIn_1(beva_str);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleTrue_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bem_addIn_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleFalse_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bem_addIn_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleNull_0() {
bem_addIn_1(null);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) {
bem_addIn_1(beva_int);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parserGet_0() {
return bevp_parser;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_parserSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_listGet_0() {
return bevp_list;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_pairGet_0() {
return bevp_pair;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_pairSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_mapGet_0() {
return bevp_map;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
return bevp_first;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_stackGet_0() {
return bevp_stack;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_stackSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {467, 468, 469, 470, 472, 473, 478, 479, 480, 484, 484, 485, 487, 488, 488, 489, 490, 490, 490, 491, 491, 491, 492, 494, 496, 497, 499, 499, 499, 506, 507, 508, 508, 513, 514, 516, 516, 516, 522, 522, 522, 0, 522, 522, 522, 522, 0, 0, 523, 523, 523, 529, 530, 531, 536, 537, 539, 539, 539, 546, 551, 551, 556, 556, 561, 566, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 22, 23, 24, 25, 29, 30, 31, 45, 50, 51, 53, 54, 59, 60, 62, 63, 68, 69, 70, 71, 72, 75, 79, 81, 84, 85, 86, 95, 96, 97, 98, 106, 108, 111, 112, 113, 127, 128, 129, 131, 134, 135, 136, 141, 142, 145, 149, 150, 151, 157, 158, 159, 167, 169, 172, 173, 174, 179, 184, 185, 190, 191, 195, 199, 203, 206, 210, 213, 217, 220, 224, 227, 231, 234, 238, 241};
/* BEGIN LINEINFO 
assign 1 467 20
new 0 467 20
assign 1 468 21
new 0 468 21
assign 1 469 22
new 0 469 22
assign 1 470 23
new 0 470 23
assign 1 472 24
assign 1 473 25
new 0 473 25
new 0 478 29
parse 2 479 30
return 1 480 31
assign 1 484 45
undef 1 484 50
assign 1 485 51
assign 1 487 53
peek 0 487 53
assign 1 488 54
def 1 488 59
assign 1 489 60
sameClass 1 489 60
assign 1 490 62
secondGet 0 490 62
assign 1 490 63
def 1 490 68
assign 1 491 69
firstGet 0 491 69
assign 1 491 70
secondGet 0 491 70
put 2 491 71
secondSet 1 492 72
secondSet 1 494 75
assign 1 496 79
sameClass 1 496 79
addValueWhole 1 497 81
assign 1 499 84
new 0 499 84
assign 1 499 85
new 1 499 85
throw 1 499 86
assign 1 506 95
new 0 506 95
addIn 1 507 96
assign 1 508 97
new 2 508 97
push 1 508 98
assign 1 513 106
isEmptyGet 0 513 106
assign 1 514 108
pop 0 514 108
assign 1 516 111
new 0 516 111
assign 1 516 112
new 1 516 112
throw 1 516 113
assign 1 522 127
peek 0 522 127
assign 1 522 128
sameClass 1 522 128
assign 1 522 129
not 0 522 129
assign 1 0 131
assign 1 522 134
peek 0 522 134
assign 1 522 135
secondGet 0 522 135
assign 1 522 136
undef 1 522 141
assign 1 0 142
assign 1 0 145
assign 1 523 149
new 0 523 149
assign 1 523 150
new 1 523 150
throw 1 523 151
assign 1 529 157
new 0 529 157
addIn 1 530 158
push 1 531 159
assign 1 536 167
isEmptyGet 0 536 167
assign 1 537 169
pop 0 537 169
assign 1 539 172
new 0 539 172
assign 1 539 173
new 1 539 173
throw 1 539 174
addIn 1 546 179
assign 1 551 184
new 0 551 184
addIn 1 551 185
assign 1 556 190
new 0 556 190
addIn 1 556 191
addIn 1 561 195
addIn 1 566 199
return 1 0 203
assign 1 0 206
return 1 0 210
assign 1 0 213
return 1 0 217
assign 1 0 220
return 1 0 224
assign 1 0 227
return 1 0 231
assign 1 0 234
return 1 0 238
assign 1 0 241
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1431394368: return bem_handleNull_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -435843368: return bem_beginList_0();
case -1308786538: return bem_echo_0();
case 1398681994: return bem_endList_0();
case 104713553: return bem_new_0();
case -368775858: return bem_kvMid_0();
case -1246679159: return bem_listGet_0();
case -1262128633: return bem_handleTrue_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 1095000804: return bem_beginMap_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -183400265: return bem_firstGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -1286503731: return bem_pairGet_0();
case -506014516: return bem_handleFalse_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 2013904863: return bem_stackGet_0();
case 167292072: return bem_parserGet_0();
case 156467595: return bem_mapGet_0();
case 1820417453: return bem_create_0();
case 1708368370: return bem_endMap_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 167549848: return bem_mapSet_1(bevd_0);
case -1275421478: return bem_pairSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1818023961: return bem_unmarshall_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1774332469: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case -172318012: return bem_firstSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1235596906: return bem_listSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 178374325: return bem_parserSet_1(bevd_0);
case 1512002600: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1148905512: return bem_addIn_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 2024987116: return bem_stackSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_JsonUnmarshaller_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_12_JsonUnmarshaller_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_12_JsonUnmarshaller();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst = (BEC_2_4_12_JsonUnmarshaller) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;
}
}
}
