namespace be {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_12_JsonUnmarshaller : BEC_2_6_6_SystemObject {
public BEC_2_4_12_JsonUnmarshaller() { }
static BEC_2_4_12_JsonUnmarshaller() { }
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x55,0x6E,0x6D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_0 = {0x75,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_1 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_2 = {0x6B,0x65,0x79,0x20,0x75,0x6E,0x64,0x65,0x66,0x20,0x69,0x6E,0x20,0x6B,0x76,0x6D,0x69,0x64};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_3 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
public static new BEC_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;

public static new BET_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;

public BEC_2_4_6_JsonParser bevp_parser;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_9_4_ContainerPair bevp_pair;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_5_ContainerStack bevp_stack;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_parser = (BEC_2_4_6_JsonParser) (new BEC_2_4_6_JsonParser()).bem_new_0();
bevp_list = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_pair = (BEC_2_9_4_ContainerPair) (new BEC_2_9_4_ContainerPair()).bem_new_0();
bevp_map = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_first = null;
bevp_stack = (BEC_2_9_5_ContainerStack) (new BEC_2_9_5_ContainerStack()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_unmarshall_1(BEC_2_4_6_TextString beva_str) {
bem_new_0();
bevp_parser.bem_parse_2(beva_str, this);
return bevp_first;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_addIn_1(BEC_2_6_6_SystemObject beva_o) {
BEC_2_6_6_SystemObject bevl_top = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_9_SystemException bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
if (bevp_first == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 483*/ {
bevp_first = beva_o;
} /* Line: 484*/
bevl_top = bevp_stack.bem_peek_0();
if (bevl_top == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 487*/ {
bevt_2_ta_ph = bevl_top.bemd_1(909810346, bevp_pair);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 488*/ {
bevt_4_ta_ph = bevl_top.bemd_0(443497498);
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 489*/ {
bevt_5_ta_ph = bevl_top.bemd_0(1117833636);
bevt_6_ta_ph = bevl_top.bemd_0(443497498);
bevt_5_ta_ph.bemd_2(-1832936144, bevt_6_ta_ph, beva_o);
bevl_top.bemd_1(659029645, null);
} /* Line: 491*/
 else /* Line: 492*/ {
bevl_top.bemd_1(659029645, beva_o);
} /* Line: 493*/
} /* Line: 489*/
 else /* Line: 488*/ {
bevt_7_ta_ph = bevl_top.bemd_1(909810346, bevp_list);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 495*/ {
bevl_top.bemd_1(1592562054, beva_o);
} /* Line: 496*/
 else /* Line: 497*/ {
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_4_12_JsonUnmarshaller_bels_0));
bevt_8_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_ta_ph);
throw new be.BECS_ThrowBack(bevt_8_ta_ph);
} /* Line: 498*/
} /* Line: 488*/
} /* Line: 488*/
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_beginMap_0() {
BEC_2_9_3_ContainerMap bevl_m = null;
BEC_2_9_4_ContainerPair bevt_0_ta_ph = null;
bevl_m = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bem_addIn_1(bevl_m);
bevt_0_ta_ph = (BEC_2_9_4_ContainerPair) (new BEC_2_9_4_ContainerPair()).bem_new_2(bevl_m, null);
bevp_stack.bem_push_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_endMap_0() {
BEC_2_9_4_ContainerPair bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 512*/ {
bevl_p = (BEC_2_9_4_ContainerPair) bevp_stack.bem_pop_0();
} /* Line: 513*/
 else /* Line: 514*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_4_12_JsonUnmarshaller_bels_1));
bevt_1_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 515*/
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_kvMid_0() {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_9_SystemException bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevt_3_ta_ph = bevp_stack.bem_peek_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(909810346, bevp_pair);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(560923354);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 521*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 521*/ {
bevt_6_ta_ph = bevp_stack.bem_peek_0();
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(443497498);
if (bevt_5_ta_ph == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 521*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 521*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 521*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 521*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_4_12_JsonUnmarshaller_bels_2));
bevt_7_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_ta_ph);
throw new be.BECS_ThrowBack(bevt_7_ta_ph);
} /* Line: 522*/
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_beginList_0() {
BEC_2_9_4_ContainerList bevl_l = null;
bevl_l = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bem_addIn_1(bevl_l);
bevp_stack.bem_push_1(bevl_l);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_endList_0() {
BEC_2_9_4_ContainerList bevl_l = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 535*/ {
bevl_l = (BEC_2_9_4_ContainerList) bevp_stack.bem_pop_0();
} /* Line: 536*/
 else /* Line: 537*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_4_12_JsonUnmarshaller_bels_3));
bevt_1_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 538*/
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleString_1(BEC_2_4_6_TextString beva_str) {
bem_addIn_1(beva_str);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleTrue_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bem_addIn_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleFalse_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bem_addIn_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleNull_0() {
bem_addIn_1(null);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) {
bem_addIn_1(beva_int);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parserGet_0() {
return bevp_parser;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parserGetDirect_0() {
return bevp_parser;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_parserSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_parserSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_listGet_0() {
return bevp_list;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGetDirect_0() {
return bevp_list;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_listSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_pairGet_0() {
return bevp_pair;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_pairGetDirect_0() {
return bevp_pair;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_pairSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_pairSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_mapGet_0() {
return bevp_map;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGetDirect_0() {
return bevp_map;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_mapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
return bevp_first;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGetDirect_0() {
return bevp_first;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_first = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_firstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_first = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_stackGet_0() {
return bevp_stack;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_stackGetDirect_0() {
return bevp_stack;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_stackSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_stackSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {466, 467, 468, 469, 471, 472, 477, 478, 479, 483, 483, 484, 486, 487, 487, 488, 489, 489, 489, 490, 490, 490, 491, 493, 495, 496, 498, 498, 498, 505, 506, 507, 507, 512, 513, 515, 515, 515, 521, 521, 521, 0, 521, 521, 521, 521, 0, 0, 522, 522, 522, 528, 529, 530, 535, 536, 538, 538, 538, 545, 550, 550, 555, 555, 560, 565, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {23, 24, 25, 26, 27, 28, 32, 33, 34, 48, 53, 54, 56, 57, 62, 63, 65, 66, 71, 72, 73, 74, 75, 78, 82, 84, 87, 88, 89, 98, 99, 100, 101, 109, 111, 114, 115, 116, 130, 131, 132, 134, 137, 138, 139, 144, 145, 148, 152, 153, 154, 160, 161, 162, 170, 172, 175, 176, 177, 182, 187, 188, 193, 194, 198, 202, 206, 209, 212, 216, 220, 223, 226, 230, 234, 237, 240, 244, 248, 251, 254, 258, 262, 265, 268, 272, 276, 279, 282, 286};
/* BEGIN LINEINFO 
assign 1 466 23
new 0 466 23
assign 1 467 24
new 0 467 24
assign 1 468 25
new 0 468 25
assign 1 469 26
new 0 469 26
assign 1 471 27
assign 1 472 28
new 0 472 28
new 0 477 32
parse 2 478 33
return 1 479 34
assign 1 483 48
undef 1 483 53
assign 1 484 54
assign 1 486 56
peek 0 486 56
assign 1 487 57
def 1 487 62
assign 1 488 63
sameClass 1 488 63
assign 1 489 65
secondGet 0 489 65
assign 1 489 66
def 1 489 71
assign 1 490 72
firstGet 0 490 72
assign 1 490 73
secondGet 0 490 73
put 2 490 74
secondSet 1 491 75
secondSet 1 493 78
assign 1 495 82
sameClass 1 495 82
addValueWhole 1 496 84
assign 1 498 87
new 0 498 87
assign 1 498 88
new 1 498 88
throw 1 498 89
assign 1 505 98
new 0 505 98
addIn 1 506 99
assign 1 507 100
new 2 507 100
push 1 507 101
assign 1 512 109
isEmptyGet 0 512 109
assign 1 513 111
pop 0 513 111
assign 1 515 114
new 0 515 114
assign 1 515 115
new 1 515 115
throw 1 515 116
assign 1 521 130
peek 0 521 130
assign 1 521 131
sameClass 1 521 131
assign 1 521 132
not 0 521 132
assign 1 0 134
assign 1 521 137
peek 0 521 137
assign 1 521 138
secondGet 0 521 138
assign 1 521 139
undef 1 521 144
assign 1 0 145
assign 1 0 148
assign 1 522 152
new 0 522 152
assign 1 522 153
new 1 522 153
throw 1 522 154
assign 1 528 160
new 0 528 160
addIn 1 529 161
push 1 530 162
assign 1 535 170
isEmptyGet 0 535 170
assign 1 536 172
pop 0 536 172
assign 1 538 175
new 0 538 175
assign 1 538 176
new 1 538 176
throw 1 538 177
addIn 1 545 182
assign 1 550 187
new 0 550 187
addIn 1 550 188
assign 1 555 193
new 0 555 193
addIn 1 555 194
addIn 1 560 198
addIn 1 565 202
return 1 0 206
return 1 0 209
assign 1 0 212
assign 1 0 216
return 1 0 220
return 1 0 223
assign 1 0 226
assign 1 0 230
return 1 0 234
return 1 0 237
assign 1 0 240
assign 1 0 244
return 1 0 248
return 1 0 251
assign 1 0 254
assign 1 0 258
return 1 0 262
return 1 0 265
assign 1 0 268
assign 1 0 272
return 1 0 276
return 1 0 279
assign 1 0 282
assign 1 0 286
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 421239314: return bem_endMap_0();
case 1882778775: return bem_fieldIteratorGet_0();
case 48684490: return bem_echo_0();
case 1865983825: return bem_fieldNamesGet_0();
case 2017345633: return bem_copy_0();
case -160735352: return bem_once_0();
case 1917679951: return bem_handleNull_0();
case 1117833636: return bem_firstGet_0();
case 1641764007: return bem_parserGetDirect_0();
case -145935129: return bem_beginList_0();
case -833421722: return bem_listGet_0();
case 491631767: return bem_mapGetDirect_0();
case -1451048410: return bem_new_0();
case 2065698196: return bem_parserGet_0();
case 872708376: return bem_toAny_0();
case 1200056076: return bem_serializationIteratorGet_0();
case 636591777: return bem_stackGet_0();
case -1229803830: return bem_deserializeClassNameGet_0();
case -166013833: return bem_tagGet_0();
case 88877255: return bem_handleFalse_0();
case -206043242: return bem_many_0();
case -1533701006: return bem_serializeContents_0();
case -1861159986: return bem_handleTrue_0();
case 823972152: return bem_stackGetDirect_0();
case 1330976730: return bem_hashGet_0();
case 1383614670: return bem_kvMid_0();
case 907276784: return bem_serializeToString_0();
case -1990292643: return bem_toString_0();
case 386758871: return bem_mapGet_0();
case -90221396: return bem_firstGetDirect_0();
case -1442560023: return bem_endList_0();
case 157943712: return bem_listGetDirect_0();
case 1674575712: return bem_classNameGet_0();
case 437089080: return bem_print_0();
case 1896893817: return bem_pairGet_0();
case -1419115955: return bem_create_0();
case -464335222: return bem_pairGetDirect_0();
case 239423162: return bem_beginMap_0();
case 1208354139: return bem_sourceFileNameGet_0();
case -2014542803: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 161134859: return bem_defined_1(bevd_0);
case -1183838262: return bem_firstSet_1(bevd_0);
case -577665577: return bem_mapSetDirect_1(bevd_0);
case 2122176784: return bem_undef_1(bevd_0);
case 668967421: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case -807057178: return bem_addIn_1(bevd_0);
case -783799304: return bem_parserSetDirect_1(bevd_0);
case 2010370566: return bem_parserSet_1(bevd_0);
case 805589743: return bem_stackSetDirect_1(bevd_0);
case 170216407: return bem_copyTo_1(bevd_0);
case 1920998617: return bem_sameObject_1(bevd_0);
case 625481528: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1484567824: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1077365190: return bem_firstSetDirect_1(bevd_0);
case -279352105: return bem_undefined_1(bevd_0);
case 1596863802: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1517637963: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -58982997: return bem_listSet_1(bevd_0);
case -1457159726: return bem_unmarshall_1((BEC_2_4_6_TextString) bevd_0);
case -1822027791: return bem_otherClass_1(bevd_0);
case 1441377970: return bem_stackSet_1(bevd_0);
case 1561328648: return bem_otherType_1(bevd_0);
case -560364319: return bem_listSetDirect_1(bevd_0);
case 354557818: return bem_equals_1(bevd_0);
case -1362857524: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case -185383596: return bem_sameType_1(bevd_0);
case 584123032: return bem_def_1(bevd_0);
case -368161826: return bem_mapSet_1(bevd_0);
case -595983381: return bem_pairSet_1(bevd_0);
case 909810346: return bem_sameClass_1(bevd_0);
case -840953319: return bem_notEquals_1(bevd_0);
case -1278598305: return bem_pairSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1467883232: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 465709808: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 936076332: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -758649425: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 105253121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -29810702: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 175222937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_JsonUnmarshaller_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_12_JsonUnmarshaller_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_12_JsonUnmarshaller();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst = (BEC_2_4_12_JsonUnmarshaller) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;
}
}
}
