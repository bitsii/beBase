namespace be {
/* IO:File: source/build/Nodes.be */
public sealed class BEC_2_5_4_BuildNode : BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildNode() { }
static BEC_2_5_4_BuildNode() { }
private static byte[] becc_BEC_2_5_4_BuildNode_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_2_5_4_BuildNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_0 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_1 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_5 = {0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_6 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_7 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_8 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_8, 7));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_9 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_9, 8));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_10 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_10, 1));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_11 = {0x20,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_11, 2));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_12 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_13 = {0x5F,0x74,0x6D,0x70,0x61,0x6E,0x79,0x5F};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_15 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_17 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildNode_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildNode_bels_17, 18));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_18 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_19 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_20 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_5;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_6;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_7;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_8;
private static BEC_2_9_3_ContainerSet bece_BEC_2_5_4_BuildNode_bevo_9;
private static BEC_2_4_3_MathInt bece_BEC_2_5_4_BuildNode_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_4_BuildNode_bels_21 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_22 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_23 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_24 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_25 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_26 = {0x70,0x72,0x69,0x6E,0x74,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_27 = {0x65,0x63,0x68,0x6F,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_28 = {0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_29 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_30 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_31 = {0x70,0x6F,0x77,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_32 = {0x63,0x6F,0x6D,0x70,0x61,0x72,0x65,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_33 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_34 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_35 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_36 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_37 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_38 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_39 = {0x66,0x69,0x6E,0x64,0x5F,0x32};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_40 = {0x66,0x69,0x6E,0x64,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_41 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_42 = {0x69,0x73,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_43 = {0x67,0x65,0x74,0x50,0x6F,0x69,0x6E,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_44 = {0x65,0x6E,0x64,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_45 = {0x62,0x65,0x67,0x69,0x6E,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_46 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_47 = {0x73,0x75,0x62,0x73,0x74,0x72,0x69,0x6E,0x67,0x5F,0x32};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_48 = {0x73,0x69,0x7A,0x65,0x47,0x65,0x74,0x5F,0x30};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_49 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_50 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_51 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_52 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_53 = {0x67,0x65,0x74,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_54 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_55 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_inst;

public static new BET_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_type;

public BEC_2_9_8_ContainerNodeList bevp_contained;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_3_9_10_9_ContainerLinkedListAwareNode bevp_heldBy;
public BEC_2_6_6_SystemObject bevp_condany;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_2_6_6_SystemObject bevp_typeDetail;
public BEC_2_5_4_LogicBool bevp_delayDelete;
public BEC_2_4_3_MathInt bevp_nlc;
public BEC_2_4_3_MathInt bevp_nlec;
public BEC_2_5_4_LogicBool bevp_wideString;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_3_MathInt bevp_typename;
public BEC_2_5_4_LogicBool bevp_inlined;
public BEC_2_5_4_BuildNode bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_delayDelete = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_nlec = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_wideString = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
bevp_inlined = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_copyLoc_1(BEC_2_5_4_BuildNode beva_fromNode) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_fromNode.bem_nlcGet_0();
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpany_phold.bem_copy_0();
bevt_1_tmpany_phold = beva_fromNode.bem_nlecGet_0();
bevp_nlec = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextDescendGet_0() {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (bevp_contained == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevt_4_tmpany_phold = bevp_contained.bem_firstGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 45 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 45 */ {
bevt_5_tmpany_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_5_tmpany_phold;
} /* Line: 46 */
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
 /* Line: 50 */ {
if (bevl_ret == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 50 */ {
if (bevl_con == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 52 */
 else  /* Line: 50 */ {
break;
} /* Line: 50 */
} /* Line: 50 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextAscendGet_0() {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
 /* Line: 60 */ {
if (bevl_ret == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 60 */ {
if (bevl_con == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 60 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 62 */
 else  /* Line: 60 */ {
break;
} /* Line: 60 */
} /* Line: 60 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextPeerGet_0() {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 68 */ {
return null;
} /* Line: 69 */
bevl_hh = bevp_heldBy.bem_nextGet_0();
if (bevl_hh == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 72 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 73 */
bevt_2_tmpany_phold = bevl_hh.bemd_0(1690604512);
return (BEC_2_5_4_BuildNode) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_priorPeerGet_0() {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 79 */ {
return null;
} /* Line: 80 */
bevl_hh = bevp_heldBy.bem_priorGet_0();
if (bevl_hh == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 83 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 84 */
bevt_2_tmpany_phold = bevl_hh.bemd_0(1690604512);
return (BEC_2_5_4_BuildNode) bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_firstGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_secondGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_secondGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_thirdGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_contained.bem_thirdGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFirstGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 102 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 103 */
bevt_3_tmpany_phold = bevp_heldBy.bem_priorGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSecondGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 109 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 109 */ {
bevt_3_tmpany_phold = bevp_heldBy.bem_priorGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 109 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 109 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 109 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 109 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 110 */
bevt_7_tmpany_phold = bevp_heldBy.bem_priorGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_priorGet_0();
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThirdGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_11_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_12_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_4_tmpany_phold = bevp_heldBy.bem_priorGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_7_tmpany_phold = bevp_heldBy.bem_priorGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_priorGet_0();
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 116 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 117 */
bevt_12_tmpany_phold = bevp_heldBy.bem_priorGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_priorGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_priorGet_0();
if (bevt_10_tmpany_phold == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDelete_0() {
bevp_delayDelete = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 127 */ {
return null;
} /* Line: 128 */
bevp_heldBy.bem_delete_0();
bem_containerSet_1(null);
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beforeInsert_1(BEC_2_5_4_BuildNode beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_3_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 136 */ {
return null;
} /* Line: 137 */
bevt_2_tmpany_phold = bevp_heldBy.bem_mylistGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_newNode_1(beva_x);
bevp_heldBy.bem_insertBefore_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = bem_containerGet_0();
beva_x.bem_containerSet_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_prepend_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 144 */ {
bem_initContained_0();
} /* Line: 145 */
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addValue_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 152 */ {
bem_initContained_0();
} /* Line: 153 */
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_reInitContained_0() {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_initContained_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_contained == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 164 */ {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 165 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevl_res = null;
try  /* Line: 171 */ {
bevl_res = bem_toStringCompact_0();
} /* Line: 172 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(455481848);
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 175 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringBig_0() {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_6_6_SystemObject bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
bevl_prefix = bem_prefixGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_2_tmpany_phold = bevl_prefix.bemd_1(2043797984, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_typename.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(2043797984, bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = bevt_1_tmpany_phold.bemd_1(2043797984, bevt_5_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_newlineGet_0();
bevt_8_tmpany_phold = bevl_ret.bemd_1(2043797984, bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(2043797984, bevl_prefix);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_2));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(2043797984, bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpany_phold.bemd_1(2043797984, bevt_12_tmpany_phold);
if (bevp_inClassNp == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 184 */ {
if (bevp_inFile == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 184 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 184 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 184 */
 else  /* Line: 184 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 184 */ {
bevt_22_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_newlineGet_0();
bevt_20_tmpany_phold = bevl_ret.bemd_1(2043797984, bevt_21_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_1(2043797984, bevl_prefix);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_3));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(2043797984, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = bevp_inClassNp.bem_toString_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(2043797984, bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_4));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_1(2043797984, bevt_25_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(2043797984, bevp_inFile);
bevt_27_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_newlineGet_0();
bevl_ret = bevt_15_tmpany_phold.bemd_1(2043797984, bevt_26_tmpany_phold);
} /* Line: 185 */
if (bevp_held == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_32_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_newlineGet_0();
bevt_30_tmpany_phold = bevl_ret.bemd_1(2043797984, bevt_31_tmpany_phold);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_1(2043797984, bevl_prefix);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevl_ret = bevt_29_tmpany_phold.bemd_1(2043797984, bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_held.bemd_0(952056940);
bevl_ret = bevl_ret.bemd_1(2043797984, bevt_34_tmpany_phold);
} /* Line: 189 */
return (BEC_2_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringCompact_0() {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
bevl_prefix = bem_prefixGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_6));
bevt_1_tmpany_phold = bevl_prefix.bemd_1(2043797984, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_typename.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(2043797984, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_7));
bevl_ret = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(2043797984, bevt_4_tmpany_phold);
if (bevp_nlc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_0;
bevt_6_tmpany_phold = bevl_ret.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
} /* Line: 198 */
if (bevp_inClassNp == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_1;
bevt_10_tmpany_phold = bevl_ret.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
} /* Line: 201 */
if (bevp_held == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 203 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_2;
bevt_14_tmpany_phold = bevl_ret.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevp_held.bemd_0(952056940);
bevl_ret = bevt_14_tmpany_phold.bem_add_1(bevt_16_tmpany_phold);
} /* Line: 204 */
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_5_4_BuildNode bevl_c = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_d = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_c = bem_containerGet_0();
while (true)
 /* Line: 212 */ {
if (bevl_c == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevl_d.bevi_int++;
bevl_c = bevl_c.bem_containerGet_0();
} /* Line: 214 */
 else  /* Line: 212 */ {
break;
} /* Line: 212 */
} /* Line: 212 */
return bevl_d;
} /*method end*/
public BEC_2_4_6_TextString bem_prefixGet_0() {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_d = bem_depthGet_0();
bevl_p = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_q = bece_BEC_2_5_4_BuildNode_bevo_3;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 223 */ {
if (bevl_i.bevi_int < bevl_d.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevl_p = bevl_p.bem_add_1(bevl_q);
bevl_i.bevi_int++;
} /* Line: 223 */
 else  /* Line: 223 */ {
break;
} /* Line: 223 */
} /* Line: 223 */
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_transUnitGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 231 */ {
if (bevl_targ == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 231 */ {
bevt_3_tmpany_phold = bevl_targ.bemd_0(-1015889451);
bevt_4_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(1198427025, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 231 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 231 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 231 */
 else  /* Line: 231 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 231 */ {
bevl_targ = bevl_targ.bemd_0(945403285);
} /* Line: 232 */
 else  /* Line: 231 */ {
break;
} /* Line: 231 */
} /* Line: 231 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVar_2(BEC_2_6_6_SystemObject beva_suffix, BEC_2_6_6_SystemObject beva_build) {
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tmpanyn = null;
BEC_2_6_6_SystemObject bevl_tmpany = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevl_clnode = bem_scopeGet_0();
bevt_1_tmpany_phold = bevl_clnode.bemd_0(-1015889451);
bevt_2_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1198427025, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 239 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_4_BuildNode_bels_12));
bevt_3_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_4_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 240 */
bevt_6_tmpany_phold = bevl_clnode.bemd_0(1690604512);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(733351974);
bevl_tmpanyn = bevt_5_tmpany_phold.bemd_0(952056940);
bevt_8_tmpany_phold = bevl_clnode.bemd_0(1690604512);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(733351974);
bevt_7_tmpany_phold.bemd_0(-178227155);
bevl_tmpany = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(1752540050, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(-987238122, bevt_10_tmpany_phold);
bevl_tmpany.bemd_1(620985782, beva_suffix);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_13));
bevt_12_tmpany_phold = bevl_tmpanyn.bemd_1(2043797984, bevt_13_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(2043797984, beva_suffix);
bevl_tmpany.bemd_1(-934701332, bevt_11_tmpany_phold);
return bevl_tmpany;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inPropertiesGet_0() {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_con = bem_containerGet_0();
while (true)
 /* Line: 254 */ {
if (bevl_con == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 254 */ {
bevt_2_tmpany_phold = bevl_con.bem_typenameGet_0();
bevt_3_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 256 */
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 258 */
 else  /* Line: 254 */ {
break;
} /* Line: 254 */
} /* Line: 254 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addVariable_0() {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevl_v = bevp_held;
bevt_2_tmpany_phold = bevl_v.bemd_0(108310915);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1343413621);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 265 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-424797796, bevt_3_tmpany_phold);
bevl_sco = bem_scopeGet_0();
bevt_5_tmpany_phold = bevl_sco.bemd_0(-1015889451);
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(1911701664, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 268 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(54, bece_BEC_2_5_4_BuildNode_bels_14));
bevt_7_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_8_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 269 */
bevt_9_tmpany_phold = bem_inPropertiesGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 271 */ {
bevt_11_tmpany_phold = bevl_v.bemd_0(1246375631);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1343413621);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 271 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 271 */ {
bevl_sco = bem_classGet_0();
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1070617897, bevt_12_tmpany_phold);
} /* Line: 273 */
bevl_sc = bevl_sco.bemd_0(1690604512);
bevt_14_tmpany_phold = bevl_sc.bemd_0(-1729427697);
bevt_15_tmpany_phold = bevl_v.bemd_0(1961725837);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_1(1211387830, bevt_15_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 276 */ {
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bece_BEC_2_5_4_BuildNode_bels_15));
bevt_16_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 277 */
bevt_18_tmpany_phold = bevl_sc.bemd_0(-1729427697);
bevt_19_tmpany_phold = bevl_v.bemd_0(1961725837);
bevt_18_tmpany_phold.bemd_2(-1690307693, bevt_19_tmpany_phold, this);
bevt_20_tmpany_phold = bevl_sc.bemd_0(-355647269);
bevt_20_tmpany_phold.bemd_1(-683455065, this);
} /* Line: 280 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncAddVariable_0() {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevl_v = bevp_held;
bevt_1_tmpany_phold = bevl_v.bemd_0(108310915);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1343413621);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 286 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-424797796, bevt_2_tmpany_phold);
bevl_sco = bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(1690604512);
bevt_4_tmpany_phold = bevl_sc.bemd_0(-1729427697);
bevt_5_tmpany_phold = bevl_v.bemd_0(1961725837);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1211387830, bevt_5_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 290 */ {
bevt_6_tmpany_phold = bevl_sc.bemd_0(-1729427697);
bevt_7_tmpany_phold = bevl_v.bemd_0(1961725837);
bevp_held = bevt_6_tmpany_phold.bemd_1(973819151, bevt_7_tmpany_phold);
} /* Line: 291 */
 else  /* Line: 292 */ {
bevt_8_tmpany_phold = bem_classGet_0();
bevl_cl = bevt_8_tmpany_phold.bemd_0(1690604512);
bevt_10_tmpany_phold = bevl_cl.bemd_0(-1729427697);
bevt_11_tmpany_phold = bevl_v.bemd_0(1961725837);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_1(1211387830, bevt_11_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 294 */ {
bevt_12_tmpany_phold = bevl_cl.bemd_0(-1729427697);
bevt_13_tmpany_phold = bevl_v.bemd_0(1961725837);
bevp_held = bevt_12_tmpany_phold.bemd_1(973819151, bevt_13_tmpany_phold);
} /* Line: 295 */
 else  /* Line: 296 */ {
bevt_14_tmpany_phold = bevl_sc.bemd_0(-1729427697);
bevt_15_tmpany_phold = bevl_v.bemd_0(1961725837);
bevt_14_tmpany_phold.bemd_2(-1690307693, bevt_15_tmpany_phold, this);
bevt_16_tmpany_phold = bevl_sc.bemd_0(-355647269);
bevt_16_tmpany_phold.bemd_1(-683455065, this);
bevt_18_tmpany_phold = bevl_sco.bemd_0(-1015889451);
bevt_19_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(1911701664, bevt_19_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 299 */ {
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_4_BuildNode_bels_16));
bevt_20_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 300 */
} /* Line: 299 */
} /* Line: 294 */
} /* Line: 290 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncVariable_1(BEC_3_5_5_7_BuildVisitVisitor beva_visit) {
BEC_2_6_6_SystemObject bevl_vname = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_13_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
bevl_vname = bevp_held;
bevt_0_tmpany_phold = bem_scopeGet_0();
bevl_sc = bevt_0_tmpany_phold.bemd_0(1690604512);
bevt_2_tmpany_phold = bevl_sc.bemd_0(-1729427697);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(1211387830, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 311 */ {
bevt_4_tmpany_phold = bevl_sc.bemd_0(-1729427697);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(973819151, bevl_vname);
bevp_held = bevt_3_tmpany_phold.bemd_0(1690604512);
} /* Line: 312 */
 else  /* Line: 313 */ {
bevt_5_tmpany_phold = bem_classGet_0();
bevl_cl = bevt_5_tmpany_phold.bemd_0(1690604512);
bevt_7_tmpany_phold = bevl_cl.bemd_0(-1729427697);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(1211387830, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 315 */ {
bevt_9_tmpany_phold = bevl_cl.bemd_0(-1729427697);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_1(973819151, bevl_vname);
bevp_held = bevt_8_tmpany_phold.bemd_0(1690604512);
} /* Line: 316 */
 else  /* Line: 317 */ {
bevl_tunode = bem_transUnitGet_0();
bevt_11_tmpany_phold = bevl_tunode.bemd_0(1690604512);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(679437991);
bevl_np = bevt_10_tmpany_phold.bemd_1(973819151, bevl_vname);
if (bevl_np == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_14_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_aliasedGet_0();
bevl_np = bevt_13_tmpany_phold.bem_get_1(bevl_vname);
} /* Line: 321 */
if (bevl_np == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevt_18_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_4;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevl_np);
bevt_16_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 324 */
 else  /* Line: 325 */ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(-934701332, bevl_vname);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_18));
bevt_19_tmpany_phold = bevl_vname.bemd_1(1911701664, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_19_tmpany_phold).bevi_bool) /* Line: 329 */ {
bevp_held = bevl_v;
bevt_21_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1715337064, bevt_21_tmpany_phold);
bevt_22_tmpany_phold = bevl_cl.bemd_0(-142325041);
bevl_v.bemd_1(1375993718, bevt_22_tmpany_phold);
bevt_23_tmpany_phold = bevl_sc.bemd_0(-1729427697);
bevt_23_tmpany_phold.bemd_2(-1690307693, bevl_vname, this);
bevt_24_tmpany_phold = bevl_sc.bemd_0(-355647269);
bevt_24_tmpany_phold.bemd_1(-683455065, this);
} /* Line: 334 */
 else  /* Line: 335 */ {
bevt_25_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_v.bemd_1(603879729, bevt_25_tmpany_phold);
bevt_26_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1070617897, bevt_26_tmpany_phold);
bevp_held = bevl_v;
bevt_27_tmpany_phold = bevl_cl.bemd_0(-1729427697);
bevt_27_tmpany_phold.bemd_2(-1690307693, bevl_vname, this);
bevt_28_tmpany_phold = bevl_cl.bemd_0(-355647269);
bevt_28_tmpany_phold.bemd_1(-683455065, this);
} /* Line: 340 */
} /* Line: 329 */
} /* Line: 323 */
} /* Line: 315 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorGet_0() {
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_node = this;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 349 */ {
while (true)
 /* Line: 350 */ {
bevt_2_tmpany_phold = bevp_constants.bem_anchorTypesGet_0();
bevt_3_tmpany_phold = bevl_node.bemd_0(-1015889451);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_has_1(bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 351 */ {
return bevl_node;
} /* Line: 352 */
 else  /* Line: 353 */ {
bevl_node = bevl_node.bemd_0(945403285);
if (bevl_node == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 355 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_19));
bevt_5_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_6_tmpany_phold, this);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 356 */
} /* Line: 355 */
} /* Line: 351 */
} /* Line: 350 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 365 */ {
if (bevl_targ == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 365 */ {
bevt_3_tmpany_phold = bevl_targ.bemd_0(-1015889451);
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(1198427025, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 365 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 365 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 365 */
 else  /* Line: 365 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 365 */ {
bevl_targ = bevl_targ.bemd_0(945403285);
} /* Line: 366 */
 else  /* Line: 365 */ {
break;
} /* Line: 365 */
} /* Line: 365 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_scopeGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevl_targ = this;
while (true)
 /* Line: 373 */ {
if (bevl_targ == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevt_5_tmpany_phold = bevl_targ.bemd_0(-1015889451);
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(1198427025, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 373 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 373 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 373 */
 else  /* Line: 373 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 373 */ {
bevt_8_tmpany_phold = bevl_targ.bemd_0(-1015889451);
bevt_9_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(1198427025, bevt_9_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 373 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 373 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 373 */
 else  /* Line: 373 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 373 */ {
bevt_11_tmpany_phold = bevl_targ.bemd_0(-1015889451);
bevt_12_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(1198427025, bevt_12_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 373 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 373 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 373 */
 else  /* Line: 373 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 373 */ {
bevl_targ = bevl_targ.bemd_0(945403285);
} /* Line: 374 */
 else  /* Line: 373 */ {
break;
} /* Line: 373 */
} /* Line: 373 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceWith_1(BEC_2_5_4_BuildNode beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_1_tmpany_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 380 */ {
return null;
} /* Line: 381 */
bevt_1_tmpany_phold = bem_containerGet_0();
beva_other.bem_containerSet_1(bevt_1_tmpany_phold);
bevp_heldBy.bem_heldSet_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_deleteAndAppend_1(BEC_2_5_4_BuildNode beva_other) {
beva_other.bem_delete_0();
bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_takeContents_1(BEC_2_5_4_BuildNode beva_other) {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
 /* Line: 394 */ {
bevt_0_tmpany_phold = bevl_it.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 394 */ {
bevl_i = bevl_it.bemd_0(2034429922);
bevl_i.bemd_1(-490352436, this);
} /* Line: 396 */
 else  /* Line: 394 */ {
break;
} /* Line: 394 */
} /* Line: 394 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_resolveNp_0() {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevp_typename.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 402 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 405 */
} /* Line: 404 */
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevp_typename.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 408 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(79974186);
if (bevl_np == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 410 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 411 */
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(-142325041);
if (bevl_np == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 414 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 415 */
bevt_8_tmpany_phold = bevp_held.bemd_0(79974186);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(952056940);
bevp_held.bemd_1(-934701332, bevt_7_tmpany_phold);
} /* Line: 417 */
bevt_10_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevp_typename.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(79974186);
if (bevl_np == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 421 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 422 */
} /* Line: 421 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_callIsSafe_1(BEC_2_5_4_BuildNode beva_call) {
BEC_2_9_3_ContainerSet bevl_alwaysOkCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses = null;
BEC_2_9_3_ContainerSet bevl_okCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses2 = null;
BEC_2_9_3_ContainerSet bevl_okCalls2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
bevt_2_tmpany_phold = beva_call.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-1175493566);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 432 */ {
bevt_6_tmpany_phold = beva_call.bem_heldGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-91184595);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(952056940);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_20));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1911701664, bevt_7_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 432 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 432 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 432 */
 else  /* Line: 432 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 432 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 433 */
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bece_BEC_2_5_4_BuildNode_bevo_5 == null) {
bece_BEC_2_5_4_BuildNode_bevo_5 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_alwaysOkCalls = bece_BEC_2_5_4_BuildNode_bevo_5;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bece_BEC_2_5_4_BuildNode_bevo_6 == null) {
bece_BEC_2_5_4_BuildNode_bevo_6 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses = bece_BEC_2_5_4_BuildNode_bevo_6;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bece_BEC_2_5_4_BuildNode_bevo_7 == null) {
bece_BEC_2_5_4_BuildNode_bevo_7 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls = bece_BEC_2_5_4_BuildNode_bevo_7;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bece_BEC_2_5_4_BuildNode_bevo_8 == null) {
bece_BEC_2_5_4_BuildNode_bevo_8 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses2 = bece_BEC_2_5_4_BuildNode_bevo_8;
lock (typeof(BEC_2_5_4_BuildNode)) {
if (bece_BEC_2_5_4_BuildNode_bevo_9 == null) {
bece_BEC_2_5_4_BuildNode_bevo_9 = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls2 = bece_BEC_2_5_4_BuildNode_bevo_9;
bevt_10_tmpany_phold = bevl_okClasses.bem_sizeGet_0();
bevt_11_tmpany_phold = bece_BEC_2_5_4_BuildNode_bevo_10;
if (bevt_10_tmpany_phold.bevi_int == bevt_11_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 441 */ {
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_21));
bevl_alwaysOkCalls.bem_put_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_22));
bevl_okClasses.bem_put_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_23));
bevl_okClasses.bem_put_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_24));
bevl_okCalls.bem_put_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_25));
bevl_okCalls.bem_put_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_26));
bevl_okCalls.bem_put_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_27));
bevl_okCalls.bem_put_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_28));
bevl_okCalls.bem_put_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_29));
bevl_okCalls.bem_put_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_30));
bevl_okCalls.bem_put_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_31));
bevl_okCalls.bem_put_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_32));
bevl_okCalls.bem_put_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_33));
bevl_okCalls.bem_put_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_34));
bevl_okCalls.bem_put_1(bevt_25_tmpany_phold);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_35));
bevl_okCalls.bem_put_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_36));
bevl_okCalls.bem_put_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_4_BuildNode_bels_37));
bevl_okCalls.bem_put_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_38));
bevl_okCalls.bem_put_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_39));
bevl_okCalls.bem_put_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_40));
bevl_okCalls.bem_put_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_41));
bevl_okCalls.bem_put_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_42));
bevl_okCalls.bem_put_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildNode_bels_43));
bevl_okCalls.bem_put_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_44));
bevl_okCalls.bem_put_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_45));
bevl_okCalls.bem_put_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_46));
bevl_okCalls.bem_put_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_47));
bevl_okCalls.bem_put_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildNode_bels_48));
bevl_okCalls.bem_put_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_49));
bevl_okClasses2.bem_put_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_50));
bevl_okClasses2.bem_put_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_51));
bevl_okClasses2.bem_put_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_4_BuildNode_bels_52));
bevl_okClasses2.bem_put_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_53));
bevl_okCalls2.bem_put_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_54));
bevl_okCalls2.bem_put_1(bevt_45_tmpany_phold);
} /* Line: 491 */
bevt_48_tmpany_phold = beva_call.bem_heldGet_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(1961725837);
bevt_46_tmpany_phold = bevl_alwaysOkCalls.bem_has_1(bevt_47_tmpany_phold);
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 495 */ {
bevt_49_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_49_tmpany_phold;
} /* Line: 497 */
bevt_54_tmpany_phold = beva_call.bem_containedGet_0();
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_firstGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(1690604512);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(-592984261);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_0(1343413621);
if (((BEC_2_5_4_LogicBool) bevt_50_tmpany_phold).bevi_bool) /* Line: 501 */ {
bevt_55_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_55_tmpany_phold;
} /* Line: 503 */
bevt_61_tmpany_phold = beva_call.bem_containedGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(1690604512);
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(79974186);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bemd_0(952056940);
bevt_56_tmpany_phold = bevl_okClasses.bem_has_1(bevt_57_tmpany_phold);
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 511 */ {
bevt_64_tmpany_phold = beva_call.bem_heldGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(1961725837);
bevt_62_tmpany_phold = bevl_okCalls.bem_has_1(bevt_63_tmpany_phold);
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 512 */ {
bevt_65_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_65_tmpany_phold;
} /* Line: 514 */
 else  /* Line: 515 */ {
} /* Line: 515 */
} /* Line: 512 */
bevt_71_tmpany_phold = beva_call.bem_containedGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bem_firstGet_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bemd_0(1690604512);
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(79974186);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(952056940);
bevt_66_tmpany_phold = bevl_okClasses2.bem_has_1(bevt_67_tmpany_phold);
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 519 */ {
bevt_74_tmpany_phold = beva_call.bem_heldGet_0();
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bemd_0(1961725837);
bevt_72_tmpany_phold = bevl_okCalls2.bem_has_1(bevt_73_tmpany_phold);
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 520 */ {
bevt_75_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_75_tmpany_phold;
} /* Line: 522 */
 else  /* Line: 523 */ {
} /* Line: 523 */
} /* Line: 520 */
bevt_76_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_76_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralOnceGet_0() {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_BuildNode bevl_c0 = null;
BEC_2_5_4_BuildNode bevl_c1 = null;
BEC_2_5_4_BuildNode bevl_call = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_4_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevp_typename.bevi_int != bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 544 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 544 */
bevt_7_tmpany_phold = bevp_held.bemd_0(-1252524057);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_55));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(1911701664, bevt_8_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 545 */ {
bevl_c0 = (BEC_2_5_4_BuildNode) bevp_contained.bem_firstGet_0();
bevl_c1 = (BEC_2_5_4_BuildNode) bevp_contained.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 548 */ {
bevt_11_tmpany_phold = bevl_c1.bem_typenameGet_0();
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_11_tmpany_phold.bevi_int == bevt_12_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 548 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 548 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 548 */
 else  /* Line: 548 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 548 */ {
bevt_14_tmpany_phold = bevl_c1.bem_heldGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(-587722294);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 549 */ {
bevt_17_tmpany_phold = bevl_c0.bem_heldGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(-1772999720);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1343413621);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 549 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 549 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 549 */
 else  /* Line: 549 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 549 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_19_tmpany_phold = bevl_c0.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1164736871);
bevt_0_tmpany_loop = bevt_18_tmpany_phold.bemd_0(1794518227);
while (true)
 /* Line: 551 */ {
bevt_20_tmpany_phold = bevt_0_tmpany_loop.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 551 */ {
bevl_call = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(2034429922);
bevt_21_tmpany_phold = bevl_call.bem_notEquals_1(this);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 552 */ {
bevt_23_tmpany_phold = bem_callIsSafe_1(bevl_call);
if (bevt_23_tmpany_phold.bevi_bool) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 553 */ {
bevt_24_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_24_tmpany_phold;
} /* Line: 554 */
} /* Line: 553 */
} /* Line: 552 */
 else  /* Line: 551 */ {
break;
} /* Line: 551 */
} /* Line: 551 */
} /* Line: 551 */
} /* Line: 549 */
} /* Line: 548 */
return bevl_result;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGet_0() {
return bevp_contained;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGetDirect_0() {
return bevp_contained;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGetDirect_0() {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() {
return bevp_held;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGetDirect_0() {
return bevp_held;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldByGet_0() {
return bevp_heldBy;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldByGetDirect_0() {
return bevp_heldBy;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldBySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heldBy = (BEC_3_9_10_9_ContainerLinkedListAwareNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldBySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heldBy = (BEC_3_9_10_9_ContainerLinkedListAwareNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condanyGet_0() {
return bevp_condany;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condanyGetDirect_0() {
return bevp_condany;
} /*method end*/
public BEC_2_5_4_BuildNode bem_condanySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_condany = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_condanySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_condany = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGetDirect_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGetDirect_0() {
return bevp_inFile;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGet_0() {
return bevp_typeDetail;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGetDirect_0() {
return bevp_typeDetail;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typeDetailSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typeDetail = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typeDetailSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typeDetail = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGet_0() {
return bevp_delayDelete;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGetDirect_0() {
return bevp_delayDelete;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDeleteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDeleteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGet_0() {
return bevp_nlc;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGetDirect_0() {
return bevp_nlc;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGet_0() {
return bevp_nlec;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGetDirect_0() {
return bevp_nlec;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlecSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlecSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGet_0() {
return bevp_wideString;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGetDirect_0() {
return bevp_wideString;
} /*method end*/
public BEC_2_5_4_BuildNode bem_wideStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_wideStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGetDirect_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_4_BuildNode bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_4_BuildNode bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_4_BuildNode bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGet_0() {
return bevp_typename;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGetDirect_0() {
return bevp_typename;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typenameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typenameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGet_0() {
return bevp_inlined;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGetDirect_0() {
return bevp_inlined;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inlinedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inlinedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {24, 25, 26, 27, 29, 30, 31, 32, 33, 38, 38, 39, 39, 40, 41, 45, 45, 45, 45, 45, 0, 0, 0, 46, 46, 48, 49, 50, 50, 50, 50, 0, 0, 0, 51, 52, 54, 58, 59, 60, 60, 60, 60, 0, 0, 0, 61, 62, 64, 68, 68, 69, 71, 72, 72, 73, 75, 75, 79, 79, 80, 82, 83, 83, 84, 86, 86, 90, 90, 94, 94, 98, 98, 102, 102, 103, 103, 105, 105, 105, 109, 109, 0, 109, 109, 109, 0, 0, 110, 110, 112, 112, 112, 112, 116, 116, 0, 116, 116, 116, 0, 0, 0, 116, 116, 116, 116, 0, 0, 117, 117, 119, 119, 119, 119, 119, 123, 127, 127, 128, 130, 131, 132, 136, 136, 137, 139, 139, 139, 140, 140, 144, 144, 145, 147, 148, 152, 152, 153, 155, 156, 160, 164, 164, 165, 172, 174, 175, 177, 181, 182, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 183, 183, 183, 184, 184, 184, 184, 0, 0, 0, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 187, 187, 188, 188, 188, 188, 188, 188, 189, 189, 191, 195, 196, 196, 196, 196, 196, 196, 197, 197, 198, 198, 198, 198, 200, 200, 201, 201, 201, 201, 203, 203, 204, 204, 204, 204, 206, 210, 211, 212, 212, 213, 214, 216, 220, 221, 222, 223, 223, 223, 224, 223, 226, 230, 231, 231, 231, 231, 231, 0, 0, 0, 232, 234, 238, 239, 239, 239, 240, 240, 240, 242, 242, 242, 243, 243, 243, 244, 245, 245, 246, 246, 247, 248, 248, 248, 248, 249, 253, 254, 254, 255, 255, 255, 255, 256, 256, 258, 260, 260, 264, 265, 265, 266, 266, 267, 268, 268, 268, 269, 269, 269, 271, 271, 271, 0, 0, 0, 272, 273, 273, 275, 276, 276, 276, 277, 277, 277, 279, 279, 279, 280, 280, 285, 286, 286, 287, 287, 288, 289, 290, 290, 290, 291, 291, 291, 293, 293, 294, 294, 294, 295, 295, 295, 297, 297, 297, 298, 298, 299, 299, 299, 300, 300, 300, 309, 310, 310, 311, 311, 312, 312, 312, 314, 314, 315, 315, 316, 316, 316, 318, 319, 319, 319, 320, 320, 321, 321, 321, 323, 323, 324, 324, 324, 324, 327, 328, 329, 329, 330, 331, 331, 332, 332, 333, 333, 334, 334, 336, 336, 337, 337, 338, 339, 339, 340, 340, 348, 349, 351, 351, 351, 352, 354, 355, 355, 356, 356, 356, 364, 365, 365, 365, 365, 365, 0, 0, 0, 366, 368, 372, 373, 373, 373, 373, 373, 0, 0, 0, 373, 373, 373, 0, 0, 0, 373, 373, 373, 0, 0, 0, 374, 376, 380, 380, 381, 383, 383, 384, 388, 389, 393, 394, 394, 395, 396, 402, 402, 402, 403, 404, 404, 405, 408, 408, 408, 409, 410, 410, 411, 413, 414, 414, 415, 417, 417, 417, 419, 419, 419, 420, 421, 421, 422, 432, 432, 432, 432, 432, 432, 432, 0, 0, 0, 433, 433, 436, 437, 438, 439, 440, 441, 441, 441, 441, 448, 448, 451, 451, 452, 452, 454, 454, 455, 455, 456, 456, 457, 457, 458, 458, 459, 459, 460, 460, 461, 461, 462, 462, 463, 463, 464, 464, 465, 465, 466, 466, 467, 467, 468, 468, 469, 469, 470, 470, 471, 471, 472, 472, 473, 473, 474, 474, 475, 475, 476, 476, 477, 477, 478, 478, 482, 482, 483, 483, 484, 484, 485, 485, 490, 490, 491, 491, 495, 495, 495, 497, 497, 501, 501, 501, 501, 501, 503, 503, 511, 511, 511, 511, 511, 511, 512, 512, 512, 514, 514, 519, 519, 519, 519, 519, 519, 520, 520, 520, 522, 522, 528, 528, 539, 544, 544, 544, 544, 544, 545, 545, 545, 546, 547, 548, 548, 548, 548, 548, 548, 0, 0, 0, 549, 549, 549, 549, 549, 0, 0, 0, 550, 551, 551, 551, 0, 551, 551, 552, 553, 553, 553, 554, 554, 565, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {97, 98, 99, 100, 101, 102, 103, 104, 105, 111, 112, 113, 114, 115, 116, 130, 135, 136, 137, 142, 143, 146, 150, 153, 154, 156, 157, 160, 165, 166, 171, 172, 175, 179, 182, 183, 189, 197, 198, 201, 206, 207, 212, 213, 216, 220, 223, 224, 230, 237, 242, 243, 245, 246, 251, 252, 254, 255, 262, 267, 268, 270, 271, 276, 277, 279, 280, 284, 285, 289, 290, 294, 295, 302, 307, 308, 309, 311, 312, 317, 328, 333, 334, 337, 338, 343, 344, 347, 351, 352, 354, 355, 356, 361, 377, 382, 383, 386, 387, 392, 393, 396, 400, 403, 404, 405, 410, 411, 414, 418, 419, 421, 422, 423, 424, 429, 432, 437, 442, 443, 445, 446, 447, 455, 460, 461, 463, 464, 465, 466, 467, 472, 477, 478, 480, 481, 486, 491, 492, 494, 495, 499, 504, 509, 510, 518, 522, 523, 525, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 585, 586, 591, 592, 595, 599, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 617, 622, 623, 624, 625, 626, 627, 628, 629, 630, 632, 654, 655, 656, 657, 658, 659, 660, 661, 666, 667, 668, 669, 670, 672, 677, 678, 679, 680, 681, 683, 688, 689, 690, 691, 692, 694, 700, 701, 704, 709, 710, 711, 717, 725, 726, 727, 728, 731, 736, 737, 738, 744, 753, 756, 761, 762, 763, 764, 766, 769, 773, 776, 782, 802, 803, 804, 805, 807, 808, 809, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 837, 840, 845, 846, 847, 848, 853, 854, 855, 857, 863, 864, 891, 892, 893, 895, 896, 897, 898, 899, 900, 902, 903, 904, 906, 908, 909, 911, 914, 918, 921, 922, 923, 925, 926, 927, 928, 930, 931, 932, 934, 935, 936, 937, 938, 969, 970, 971, 973, 974, 975, 976, 977, 978, 979, 981, 982, 983, 986, 987, 988, 989, 990, 992, 993, 994, 997, 998, 999, 1000, 1001, 1002, 1003, 1004, 1006, 1007, 1008, 1051, 1052, 1053, 1054, 1055, 1057, 1058, 1059, 1062, 1063, 1064, 1065, 1067, 1068, 1069, 1072, 1073, 1074, 1075, 1076, 1081, 1082, 1083, 1084, 1086, 1091, 1092, 1093, 1094, 1095, 1098, 1099, 1100, 1101, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1114, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1122, 1138, 1139, 1143, 1144, 1145, 1147, 1150, 1151, 1156, 1157, 1158, 1159, 1173, 1176, 1181, 1182, 1183, 1184, 1186, 1189, 1193, 1196, 1202, 1219, 1222, 1227, 1228, 1229, 1230, 1232, 1235, 1239, 1242, 1243, 1244, 1246, 1249, 1253, 1256, 1257, 1258, 1260, 1263, 1267, 1270, 1276, 1281, 1286, 1287, 1289, 1290, 1291, 1295, 1296, 1303, 1304, 1307, 1309, 1310, 1332, 1333, 1338, 1339, 1340, 1345, 1346, 1349, 1350, 1355, 1356, 1357, 1362, 1363, 1365, 1366, 1371, 1372, 1374, 1375, 1376, 1378, 1379, 1384, 1385, 1386, 1391, 1392, 1480, 1481, 1483, 1484, 1485, 1486, 1487, 1489, 1492, 1496, 1499, 1500, 1502, 1508, 1514, 1520, 1526, 1532, 1533, 1534, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1596, 1597, 1598, 1599, 1600, 1601, 1602, 1603, 1604, 1605, 1606, 1607, 1609, 1610, 1611, 1613, 1614, 1616, 1617, 1618, 1619, 1620, 1622, 1623, 1625, 1626, 1627, 1628, 1629, 1630, 1632, 1633, 1634, 1636, 1637, 1642, 1643, 1644, 1645, 1646, 1647, 1649, 1650, 1651, 1653, 1654, 1659, 1660, 1692, 1693, 1694, 1699, 1700, 1701, 1703, 1704, 1705, 1707, 1708, 1709, 1714, 1715, 1716, 1717, 1722, 1723, 1726, 1730, 1733, 1734, 1736, 1737, 1738, 1740, 1743, 1747, 1750, 1751, 1752, 1753, 1753, 1756, 1758, 1759, 1761, 1762, 1767, 1768, 1769, 1780, 1783, 1786, 1789, 1793, 1797, 1800, 1803, 1807, 1811, 1814, 1817, 1821, 1825, 1828, 1831, 1835, 1839, 1842, 1845, 1849, 1853, 1856, 1859, 1863, 1867, 1870, 1873, 1877, 1881, 1884, 1887, 1891, 1895, 1898, 1901, 1905, 1909, 1912, 1915, 1919, 1923, 1926, 1929, 1933, 1937, 1940, 1943, 1947, 1951, 1954, 1957, 1961, 1965, 1968, 1971, 1975, 1979, 1982, 1985, 1989, 1993, 1996, 1999, 2003, 2007, 2010, 2013, 2017};
/* BEGIN LINEINFO 
assign 1 24 97
new 0 24 97
assign 1 25 98
new 0 25 98
assign 1 26 99
new 0 26 99
assign 1 27 100
new 0 27 100
assign 1 29 101
assign 1 30 102
constantsGet 0 30 102
assign 1 31 103
ntypesGet 0 31 103
assign 1 32 104
TOKENGet 0 32 104
assign 1 33 105
new 0 33 105
assign 1 38 111
nlcGet 0 38 111
assign 1 38 112
copy 0 38 112
assign 1 39 113
nlecGet 0 39 113
assign 1 39 114
copy 0 39 114
assign 1 40 115
inClassNpGet 0 40 115
assign 1 41 116
inFileGet 0 41 116
assign 1 45 130
def 1 45 135
assign 1 45 136
firstGet 0 45 136
assign 1 45 137
def 1 45 142
assign 1 0 143
assign 1 0 146
assign 1 0 150
assign 1 46 153
firstGet 0 46 153
return 1 46 154
assign 1 48 156
nextPeerGet 0 48 156
assign 1 49 157
containerGet 0 49 157
assign 1 50 160
undef 1 50 165
assign 1 50 166
def 1 50 171
assign 1 0 172
assign 1 0 175
assign 1 0 179
assign 1 51 182
nextPeerGet 0 51 182
assign 1 52 183
containerGet 0 52 183
return 1 54 189
assign 1 58 197
nextPeerGet 0 58 197
assign 1 59 198
containerGet 0 59 198
assign 1 60 201
undef 1 60 206
assign 1 60 207
def 1 60 212
assign 1 0 213
assign 1 0 216
assign 1 0 220
assign 1 61 223
nextPeerGet 0 61 223
assign 1 62 224
containerGet 0 62 224
return 1 64 230
assign 1 68 237
undef 1 68 242
return 1 69 243
assign 1 71 245
nextGet 0 71 245
assign 1 72 246
undef 1 72 251
return 1 73 252
assign 1 75 254
heldGet 0 75 254
return 1 75 255
assign 1 79 262
undef 1 79 267
return 1 80 268
assign 1 82 270
priorGet 0 82 270
assign 1 83 271
undef 1 83 276
return 1 84 277
assign 1 86 279
heldGet 0 86 279
return 1 86 280
assign 1 90 284
firstGet 0 90 284
return 1 90 285
assign 1 94 289
secondGet 0 94 289
return 1 94 290
assign 1 98 294
thirdGet 0 98 294
return 1 98 295
assign 1 102 302
undef 1 102 307
assign 1 103 308
new 0 103 308
return 1 103 309
assign 1 105 311
priorGet 0 105 311
assign 1 105 312
undef 1 105 317
return 1 105 317
assign 1 109 328
undef 1 109 333
assign 1 0 334
assign 1 109 337
priorGet 0 109 337
assign 1 109 338
undef 1 109 343
assign 1 0 344
assign 1 0 347
assign 1 110 351
new 0 110 351
return 1 110 352
assign 1 112 354
priorGet 0 112 354
assign 1 112 355
priorGet 0 112 355
assign 1 112 356
undef 1 112 361
return 1 112 361
assign 1 116 377
undef 1 116 382
assign 1 0 383
assign 1 116 386
priorGet 0 116 386
assign 1 116 387
undef 1 116 392
assign 1 0 393
assign 1 0 396
assign 1 0 400
assign 1 116 403
priorGet 0 116 403
assign 1 116 404
priorGet 0 116 404
assign 1 116 405
undef 1 116 410
assign 1 0 411
assign 1 0 414
assign 1 117 418
new 0 117 418
return 1 117 419
assign 1 119 421
priorGet 0 119 421
assign 1 119 422
priorGet 0 119 422
assign 1 119 423
priorGet 0 119 423
assign 1 119 424
undef 1 119 429
return 1 119 429
assign 1 123 432
new 0 123 432
assign 1 127 437
undef 1 127 442
return 1 128 443
delete 0 130 445
containerSet 1 131 446
assign 1 132 447
assign 1 136 455
undef 1 136 460
return 1 137 461
assign 1 139 463
mylistGet 0 139 463
assign 1 139 464
newNode 1 139 464
insertBefore 1 139 465
assign 1 140 466
containerGet 0 140 466
containerSet 1 140 467
assign 1 144 472
undef 1 144 477
initContained 0 145 478
prepend 1 147 480
containerSet 1 148 481
assign 1 152 486
undef 1 152 491
initContained 0 153 492
addValue 1 155 494
containerSet 1 156 495
assign 1 160 499
new 0 160 499
assign 1 164 504
undef 1 164 509
assign 1 165 510
new 0 165 510
assign 1 172 518
toStringCompact 0 172 518
print 0 174 522
throw 1 175 523
return 1 177 525
assign 1 181 565
prefixGet 0 181 565
assign 1 182 566
new 0 182 566
assign 1 182 567
add 1 182 567
assign 1 182 568
toString 0 182 568
assign 1 182 569
add 1 182 569
assign 1 182 570
new 0 182 570
assign 1 182 571
add 1 182 571
assign 1 183 572
new 0 183 572
assign 1 183 573
newlineGet 0 183 573
assign 1 183 574
add 1 183 574
assign 1 183 575
add 1 183 575
assign 1 183 576
new 0 183 576
assign 1 183 577
add 1 183 577
assign 1 183 578
toString 0 183 578
assign 1 183 579
add 1 183 579
assign 1 184 580
def 1 184 585
assign 1 184 586
def 1 184 591
assign 1 0 592
assign 1 0 595
assign 1 0 599
assign 1 185 602
new 0 185 602
assign 1 185 603
newlineGet 0 185 603
assign 1 185 604
add 1 185 604
assign 1 185 605
add 1 185 605
assign 1 185 606
new 0 185 606
assign 1 185 607
add 1 185 607
assign 1 185 608
toString 0 185 608
assign 1 185 609
add 1 185 609
assign 1 185 610
new 0 185 610
assign 1 185 611
add 1 185 611
assign 1 185 612
add 1 185 612
assign 1 185 613
new 0 185 613
assign 1 185 614
newlineGet 0 185 614
assign 1 185 615
add 1 185 615
assign 1 187 617
def 1 187 622
assign 1 188 623
new 0 188 623
assign 1 188 624
newlineGet 0 188 624
assign 1 188 625
add 1 188 625
assign 1 188 626
add 1 188 626
assign 1 188 627
new 0 188 627
assign 1 188 628
add 1 188 628
assign 1 189 629
toString 0 189 629
assign 1 189 630
add 1 189 630
return 1 191 632
assign 1 195 654
prefixGet 0 195 654
assign 1 196 655
new 0 196 655
assign 1 196 656
add 1 196 656
assign 1 196 657
toString 0 196 657
assign 1 196 658
add 1 196 658
assign 1 196 659
new 0 196 659
assign 1 196 660
add 1 196 660
assign 1 197 661
def 1 197 666
assign 1 198 667
new 0 198 667
assign 1 198 668
add 1 198 668
assign 1 198 669
toString 0 198 669
assign 1 198 670
add 1 198 670
assign 1 200 672
def 1 200 677
assign 1 201 678
new 0 201 678
assign 1 201 679
add 1 201 679
assign 1 201 680
toString 0 201 680
assign 1 201 681
add 1 201 681
assign 1 203 683
def 1 203 688
assign 1 204 689
new 0 204 689
assign 1 204 690
add 1 204 690
assign 1 204 691
toString 0 204 691
assign 1 204 692
add 1 204 692
return 1 206 694
assign 1 210 700
new 0 210 700
assign 1 211 701
containerGet 0 211 701
assign 1 212 704
def 1 212 709
incrementValue 0 213 710
assign 1 214 711
containerGet 0 214 711
return 1 216 717
assign 1 220 725
depthGet 0 220 725
assign 1 221 726
new 0 221 726
assign 1 222 727
new 0 222 727
assign 1 223 728
new 0 223 728
assign 1 223 731
lesser 1 223 736
assign 1 224 737
add 1 224 737
incrementValue 0 223 738
return 1 226 744
assign 1 230 753
assign 1 231 756
def 1 231 761
assign 1 231 762
typenameGet 0 231 762
assign 1 231 763
TRANSUNITGet 0 231 763
assign 1 231 764
notEquals 1 231 764
assign 1 0 766
assign 1 0 769
assign 1 0 773
assign 1 232 776
containerGet 0 232 776
return 1 234 782
assign 1 238 802
scopeGet 0 238 802
assign 1 239 803
typenameGet 0 239 803
assign 1 239 804
METHODGet 0 239 804
assign 1 239 805
notEquals 1 239 805
assign 1 240 807
new 0 240 807
assign 1 240 808
new 2 240 808
throw 1 240 809
assign 1 242 811
heldGet 0 242 811
assign 1 242 812
tmpCntGet 0 242 812
assign 1 242 813
toString 0 242 813
assign 1 243 814
heldGet 0 243 814
assign 1 243 815
tmpCntGet 0 243 815
incrementValue 0 243 816
assign 1 244 817
new 0 244 817
assign 1 245 818
new 0 245 818
isTmpVarSet 1 245 819
assign 1 246 820
new 0 246 820
autoTypeSet 1 246 821
suffixSet 1 247 822
assign 1 248 823
new 0 248 823
assign 1 248 824
add 1 248 824
assign 1 248 825
add 1 248 825
nameSet 1 248 826
return 1 249 827
assign 1 253 837
containerGet 0 253 837
assign 1 254 840
def 1 254 845
assign 1 255 846
typenameGet 0 255 846
assign 1 255 847
PROPERTIESGet 0 255 847
assign 1 255 848
equals 1 255 853
assign 1 256 854
new 0 256 854
return 1 256 855
assign 1 258 857
containerGet 0 258 857
assign 1 260 863
new 0 260 863
return 1 260 864
assign 1 264 891
assign 1 265 892
isAddedGet 0 265 892
assign 1 265 893
not 0 265 893
assign 1 266 895
new 0 266 895
isAddedSet 1 266 896
assign 1 267 897
scopeGet 0 267 897
assign 1 268 898
typenameGet 0 268 898
assign 1 268 899
CLASSGet 0 268 899
assign 1 268 900
equals 1 268 900
assign 1 269 902
new 0 269 902
assign 1 269 903
new 2 269 903
throw 1 269 904
assign 1 271 906
inPropertiesGet 0 271 906
assign 1 271 908
isTmpVarGet 0 271 908
assign 1 271 909
not 0 271 909
assign 1 0 911
assign 1 0 914
assign 1 0 918
assign 1 272 921
classGet 0 272 921
assign 1 273 922
new 0 273 922
isPropertySet 1 273 923
assign 1 275 925
heldGet 0 275 925
assign 1 276 926
anyMapGet 0 276 926
assign 1 276 927
nameGet 0 276 927
assign 1 276 928
has 1 276 928
assign 1 277 930
new 0 277 930
assign 1 277 931
new 2 277 931
throw 1 277 932
assign 1 279 934
anyMapGet 0 279 934
assign 1 279 935
nameGet 0 279 935
put 2 279 936
assign 1 280 937
orderedVarsGet 0 280 937
addValue 1 280 938
assign 1 285 969
assign 1 286 970
isAddedGet 0 286 970
assign 1 286 971
not 0 286 971
assign 1 287 973
new 0 287 973
isAddedSet 1 287 974
assign 1 288 975
scopeGet 0 288 975
assign 1 289 976
heldGet 0 289 976
assign 1 290 977
anyMapGet 0 290 977
assign 1 290 978
nameGet 0 290 978
assign 1 290 979
has 1 290 979
assign 1 291 981
anyMapGet 0 291 981
assign 1 291 982
nameGet 0 291 982
assign 1 291 983
get 1 291 983
assign 1 293 986
classGet 0 293 986
assign 1 293 987
heldGet 0 293 987
assign 1 294 988
anyMapGet 0 294 988
assign 1 294 989
nameGet 0 294 989
assign 1 294 990
has 1 294 990
assign 1 295 992
anyMapGet 0 295 992
assign 1 295 993
nameGet 0 295 993
assign 1 295 994
get 1 295 994
assign 1 297 997
anyMapGet 0 297 997
assign 1 297 998
nameGet 0 297 998
put 2 297 999
assign 1 298 1000
orderedVarsGet 0 298 1000
addValue 1 298 1001
assign 1 299 1002
typenameGet 0 299 1002
assign 1 299 1003
CLASSGet 0 299 1003
assign 1 299 1004
equals 1 299 1004
assign 1 300 1006
new 0 300 1006
assign 1 300 1007
new 2 300 1007
throw 1 300 1008
assign 1 309 1051
assign 1 310 1052
scopeGet 0 310 1052
assign 1 310 1053
heldGet 0 310 1053
assign 1 311 1054
anyMapGet 0 311 1054
assign 1 311 1055
has 1 311 1055
assign 1 312 1057
anyMapGet 0 312 1057
assign 1 312 1058
get 1 312 1058
assign 1 312 1059
heldGet 0 312 1059
assign 1 314 1062
classGet 0 314 1062
assign 1 314 1063
heldGet 0 314 1063
assign 1 315 1064
anyMapGet 0 315 1064
assign 1 315 1065
has 1 315 1065
assign 1 316 1067
anyMapGet 0 316 1067
assign 1 316 1068
get 1 316 1068
assign 1 316 1069
heldGet 0 316 1069
assign 1 318 1072
transUnitGet 0 318 1072
assign 1 319 1073
heldGet 0 319 1073
assign 1 319 1074
aliasedGet 0 319 1074
assign 1 319 1075
get 1 319 1075
assign 1 320 1076
undef 1 320 1081
assign 1 321 1082
emitDataGet 0 321 1082
assign 1 321 1083
aliasedGet 0 321 1083
assign 1 321 1084
get 1 321 1084
assign 1 323 1086
def 1 323 1091
assign 1 324 1092
new 0 324 1092
assign 1 324 1093
add 1 324 1093
assign 1 324 1094
new 2 324 1094
throw 1 324 1095
assign 1 327 1098
new 0 327 1098
nameSet 1 328 1099
assign 1 329 1100
new 0 329 1100
assign 1 329 1101
equals 1 329 1101
assign 1 330 1103
assign 1 331 1104
new 0 331 1104
isTypedSet 1 331 1105
assign 1 332 1106
extendsGet 0 332 1106
namepathSet 1 332 1107
assign 1 333 1108
anyMapGet 0 333 1108
put 2 333 1109
assign 1 334 1110
orderedVarsGet 0 334 1110
addValue 1 334 1111
assign 1 336 1114
new 0 336 1114
isDeclaredSet 1 336 1115
assign 1 337 1116
new 0 337 1116
isPropertySet 1 337 1117
assign 1 338 1118
assign 1 339 1119
anyMapGet 0 339 1119
put 2 339 1120
assign 1 340 1121
orderedVarsGet 0 340 1121
addValue 1 340 1122
assign 1 348 1138
assign 1 349 1139
new 0 349 1139
assign 1 351 1143
anchorTypesGet 0 351 1143
assign 1 351 1144
typenameGet 0 351 1144
assign 1 351 1145
has 1 351 1145
return 1 352 1147
assign 1 354 1150
containerGet 0 354 1150
assign 1 355 1151
undef 1 355 1156
assign 1 356 1157
new 0 356 1157
assign 1 356 1158
new 2 356 1158
throw 1 356 1159
assign 1 364 1173
assign 1 365 1176
def 1 365 1181
assign 1 365 1182
typenameGet 0 365 1182
assign 1 365 1183
CLASSGet 0 365 1183
assign 1 365 1184
notEquals 1 365 1184
assign 1 0 1186
assign 1 0 1189
assign 1 0 1193
assign 1 366 1196
containerGet 0 366 1196
return 1 368 1202
assign 1 372 1219
assign 1 373 1222
def 1 373 1227
assign 1 373 1228
typenameGet 0 373 1228
assign 1 373 1229
CLASSGet 0 373 1229
assign 1 373 1230
notEquals 1 373 1230
assign 1 0 1232
assign 1 0 1235
assign 1 0 1239
assign 1 373 1242
typenameGet 0 373 1242
assign 1 373 1243
METHODGet 0 373 1243
assign 1 373 1244
notEquals 1 373 1244
assign 1 0 1246
assign 1 0 1249
assign 1 0 1253
assign 1 373 1256
typenameGet 0 373 1256
assign 1 373 1257
TRANSUNITGet 0 373 1257
assign 1 373 1258
notEquals 1 373 1258
assign 1 0 1260
assign 1 0 1263
assign 1 0 1267
assign 1 374 1270
containerGet 0 374 1270
return 1 376 1276
assign 1 380 1281
undef 1 380 1286
return 1 381 1287
assign 1 383 1289
containerGet 0 383 1289
containerSet 1 383 1290
heldSet 1 384 1291
delete 0 388 1295
addValue 1 389 1296
assign 1 393 1303
containedGet 0 393 1303
assign 1 394 1304
iteratorGet 0 394 1304
assign 1 394 1307
hasNextGet 0 394 1307
assign 1 395 1309
nextGet 0 395 1309
containerSet 1 396 1310
assign 1 402 1332
NAMEPATHGet 0 402 1332
assign 1 402 1333
equals 1 402 1338
assign 1 403 1339
assign 1 404 1340
def 1 404 1345
resolve 1 405 1346
assign 1 408 1349
CLASSGet 0 408 1349
assign 1 408 1350
equals 1 408 1355
assign 1 409 1356
namepathGet 0 409 1356
assign 1 410 1357
def 1 410 1362
resolve 1 411 1363
assign 1 413 1365
extendsGet 0 413 1365
assign 1 414 1366
def 1 414 1371
resolve 1 415 1372
assign 1 417 1374
namepathGet 0 417 1374
assign 1 417 1375
toString 0 417 1375
nameSet 1 417 1376
assign 1 419 1378
VARGet 0 419 1378
assign 1 419 1379
equals 1 419 1384
assign 1 420 1385
namepathGet 0 420 1385
assign 1 421 1386
def 1 421 1391
resolve 1 422 1392
assign 1 432 1480
heldGet 0 432 1480
assign 1 432 1481
isConstructGet 0 432 1481
assign 1 432 1483
heldGet 0 432 1483
assign 1 432 1484
newNpGet 0 432 1484
assign 1 432 1485
toString 0 432 1485
assign 1 432 1486
new 0 432 1486
assign 1 432 1487
equals 1 432 1487
assign 1 0 1489
assign 1 0 1492
assign 1 0 1496
assign 1 433 1499
new 0 433 1499
return 1 433 1500
assign 1 436 1502
new 0 436 1502
assign 1 437 1508
new 0 437 1508
assign 1 438 1514
new 0 438 1514
assign 1 439 1520
new 0 439 1520
assign 1 440 1526
new 0 440 1526
assign 1 441 1532
sizeGet 0 441 1532
assign 1 441 1533
new 0 441 1533
assign 1 441 1534
equals 1 441 1539
assign 1 448 1540
new 0 448 1540
put 1 448 1541
assign 1 451 1542
new 0 451 1542
put 1 451 1543
assign 1 452 1544
new 0 452 1544
put 1 452 1545
assign 1 454 1546
new 0 454 1546
put 1 454 1547
assign 1 455 1548
new 0 455 1548
put 1 455 1549
assign 1 456 1550
new 0 456 1550
put 1 456 1551
assign 1 457 1552
new 0 457 1552
put 1 457 1553
assign 1 458 1554
new 0 458 1554
put 1 458 1555
assign 1 459 1556
new 0 459 1556
put 1 459 1557
assign 1 460 1558
new 0 460 1558
put 1 460 1559
assign 1 461 1560
new 0 461 1560
put 1 461 1561
assign 1 462 1562
new 0 462 1562
put 1 462 1563
assign 1 463 1564
new 0 463 1564
put 1 463 1565
assign 1 464 1566
new 0 464 1566
put 1 464 1567
assign 1 465 1568
new 0 465 1568
put 1 465 1569
assign 1 466 1570
new 0 466 1570
put 1 466 1571
assign 1 467 1572
new 0 467 1572
put 1 467 1573
assign 1 468 1574
new 0 468 1574
put 1 468 1575
assign 1 469 1576
new 0 469 1576
put 1 469 1577
assign 1 470 1578
new 0 470 1578
put 1 470 1579
assign 1 471 1580
new 0 471 1580
put 1 471 1581
assign 1 472 1582
new 0 472 1582
put 1 472 1583
assign 1 473 1584
new 0 473 1584
put 1 473 1585
assign 1 474 1586
new 0 474 1586
put 1 474 1587
assign 1 475 1588
new 0 475 1588
put 1 475 1589
assign 1 476 1590
new 0 476 1590
put 1 476 1591
assign 1 477 1592
new 0 477 1592
put 1 477 1593
assign 1 478 1594
new 0 478 1594
put 1 478 1595
assign 1 482 1596
new 0 482 1596
put 1 482 1597
assign 1 483 1598
new 0 483 1598
put 1 483 1599
assign 1 484 1600
new 0 484 1600
put 1 484 1601
assign 1 485 1602
new 0 485 1602
put 1 485 1603
assign 1 490 1604
new 0 490 1604
put 1 490 1605
assign 1 491 1606
new 0 491 1606
put 1 491 1607
assign 1 495 1609
heldGet 0 495 1609
assign 1 495 1610
nameGet 0 495 1610
assign 1 495 1611
has 1 495 1611
assign 1 497 1613
new 0 497 1613
return 1 497 1614
assign 1 501 1616
containedGet 0 501 1616
assign 1 501 1617
firstGet 0 501 1617
assign 1 501 1618
heldGet 0 501 1618
assign 1 501 1619
isTypedGet 0 501 1619
assign 1 501 1620
not 0 501 1620
assign 1 503 1622
new 0 503 1622
return 1 503 1623
assign 1 511 1625
containedGet 0 511 1625
assign 1 511 1626
firstGet 0 511 1626
assign 1 511 1627
heldGet 0 511 1627
assign 1 511 1628
namepathGet 0 511 1628
assign 1 511 1629
toString 0 511 1629
assign 1 511 1630
has 1 511 1630
assign 1 512 1632
heldGet 0 512 1632
assign 1 512 1633
nameGet 0 512 1633
assign 1 512 1634
has 1 512 1634
assign 1 514 1636
new 0 514 1636
return 1 514 1637
assign 1 519 1642
containedGet 0 519 1642
assign 1 519 1643
firstGet 0 519 1643
assign 1 519 1644
heldGet 0 519 1644
assign 1 519 1645
namepathGet 0 519 1645
assign 1 519 1646
toString 0 519 1646
assign 1 519 1647
has 1 519 1647
assign 1 520 1649
heldGet 0 520 1649
assign 1 520 1650
nameGet 0 520 1650
assign 1 520 1651
has 1 520 1651
assign 1 522 1653
new 0 522 1653
return 1 522 1654
assign 1 528 1659
new 0 528 1659
return 1 528 1660
assign 1 539 1692
new 0 539 1692
assign 1 544 1693
CALLGet 0 544 1693
assign 1 544 1694
notEquals 1 544 1699
assign 1 544 1700
new 0 544 1700
return 1 544 1701
assign 1 545 1703
orgNameGet 0 545 1703
assign 1 545 1704
new 0 545 1704
assign 1 545 1705
equals 1 545 1705
assign 1 546 1707
firstGet 0 546 1707
assign 1 547 1708
secondGet 0 547 1708
assign 1 548 1709
def 1 548 1714
assign 1 548 1715
typenameGet 0 548 1715
assign 1 548 1716
CALLGet 0 548 1716
assign 1 548 1717
equals 1 548 1722
assign 1 0 1723
assign 1 0 1726
assign 1 0 1730
assign 1 549 1733
heldGet 0 549 1733
assign 1 549 1734
isLiteralGet 0 549 1734
assign 1 549 1736
heldGet 0 549 1736
assign 1 549 1737
isPropertyGet 0 549 1737
assign 1 549 1738
not 0 549 1738
assign 1 0 1740
assign 1 0 1743
assign 1 0 1747
assign 1 550 1750
new 0 550 1750
assign 1 551 1751
heldGet 0 551 1751
assign 1 551 1752
allCallsGet 0 551 1752
assign 1 551 1753
iteratorGet 0 0 1753
assign 1 551 1756
hasNextGet 0 551 1756
assign 1 551 1758
nextGet 0 551 1758
assign 1 552 1759
notEquals 1 552 1759
assign 1 553 1761
callIsSafe 1 553 1761
assign 1 553 1762
not 0 553 1767
assign 1 554 1768
new 0 554 1768
return 1 554 1769
return 1 565 1780
return 1 0 1783
return 1 0 1786
assign 1 0 1789
assign 1 0 1793
return 1 0 1797
return 1 0 1800
assign 1 0 1803
assign 1 0 1807
return 1 0 1811
return 1 0 1814
assign 1 0 1817
assign 1 0 1821
return 1 0 1825
return 1 0 1828
assign 1 0 1831
assign 1 0 1835
return 1 0 1839
return 1 0 1842
assign 1 0 1845
assign 1 0 1849
return 1 0 1853
return 1 0 1856
assign 1 0 1859
assign 1 0 1863
return 1 0 1867
return 1 0 1870
assign 1 0 1873
assign 1 0 1877
return 1 0 1881
return 1 0 1884
assign 1 0 1887
assign 1 0 1891
return 1 0 1895
return 1 0 1898
assign 1 0 1901
assign 1 0 1905
return 1 0 1909
return 1 0 1912
assign 1 0 1915
assign 1 0 1919
return 1 0 1923
return 1 0 1926
assign 1 0 1929
assign 1 0 1933
return 1 0 1937
return 1 0 1940
assign 1 0 1943
assign 1 0 1947
return 1 0 1951
return 1 0 1954
assign 1 0 1957
assign 1 0 1961
return 1 0 1965
return 1 0 1968
assign 1 0 1971
assign 1 0 1975
return 1 0 1979
return 1 0 1982
assign 1 0 1985
assign 1 0 1989
return 1 0 1993
return 1 0 1996
assign 1 0 1999
assign 1 0 2003
return 1 0 2007
return 1 0 2010
assign 1 0 2013
assign 1 0 2017
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 945403285: return bem_containerGet_0();
case 228306986: return bem_buildGetDirect_0();
case -1081745400: return bem_inClassNpGet_0();
case 508078997: return bem_delete_0();
case -559768395: return bem_firstGet_0();
case 2087993718: return bem_nlcGetDirect_0();
case -1939172986: return bem_nextPeerGet_0();
case 639029521: return bem_inPropertiesGet_0();
case -1846509601: return bem_prefixGet_0();
case -1434960598: return bem_serializeContents_0();
case -1365568286: return bem_delayDeleteGetDirect_0();
case 192317546: return bem_nlcGet_0();
case -655092564: return bem_serializationIteratorGet_0();
case 1013875881: return bem_anchorGet_0();
case -181500453: return bem_copy_0();
case 137087773: return bem_condanyGetDirect_0();
case -293489754: return bem_toStringBig_0();
case 1452177853: return bem_inFileGet_0();
case -1665576026: return bem_sourceFileNameGet_0();
case 1056222345: return bem_isLiteralOnceGet_0();
case 11184274: return bem_inlinedGetDirect_0();
case 115633205: return bem_containedGet_0();
case 1467850038: return bem_delayDelete_0();
case 529438198: return bem_constantsGetDirect_0();
case 905663076: return bem_inlinedGet_0();
case 144506434: return bem_new_0();
case 1472925586: return bem_nlecGetDirect_0();
case -125389524: return bem_typenameGetDirect_0();
case -1479095149: return bem_secondGet_0();
case -664467345: return bem_create_0();
case 1325971478: return bem_priorPeerGet_0();
case 1369464370: return bem_inClassNpGetDirect_0();
case 1794518227: return bem_iteratorGet_0();
case 1976159668: return bem_isThirdGet_0();
case 1667331006: return bem_toAny_0();
case 1782620959: return bem_echo_0();
case -916152661: return bem_scopeGet_0();
case -1631214314: return bem_reInitContained_0();
case 15839020: return bem_classGet_0();
case 2132306504: return bem_classNameGet_0();
case -12762743: return bem_nextDescendGet_0();
case -1130906267: return bem_ntypesGet_0();
case 1423951047: return bem_wideStringGet_0();
case -2084192273: return bem_transUnitGet_0();
case 1025588467: return bem_condanyGet_0();
case 1690604512: return bem_heldGet_0();
case -1054400757: return bem_deserializeClassNameGet_0();
case 71853008: return bem_nextAscendGet_0();
case 1336306892: return bem_heldByGet_0();
case -452858855: return bem_constantsGet_0();
case -1234818641: return bem_isSecondGet_0();
case -1311874717: return bem_delayDeleteGet_0();
case -377355642: return bem_hashGet_0();
case -1830560348: return bem_fieldNamesGet_0();
case 455481848: return bem_print_0();
case -535267268: return bem_resolveNp_0();
case -1786412925: return bem_depthGet_0();
case 1163400987: return bem_wideStringGetDirect_0();
case 434505298: return bem_initContained_0();
case -157733273: return bem_many_0();
case 1327388078: return bem_containerGetDirect_0();
case 234170221: return bem_thirdGet_0();
case 461243603: return bem_containedGetDirect_0();
case 1761061715: return bem_inFileGetDirect_0();
case -1015889451: return bem_typenameGet_0();
case -1905842422: return bem_nlecGet_0();
case 903187767: return bem_heldGetDirect_0();
case 1699982345: return bem_ntypesGetDirect_0();
case -1427827058: return bem_once_0();
case -1714811768: return bem_fieldIteratorGet_0();
case -1313867098: return bem_tagGet_0();
case 27902321: return bem_isFirstGet_0();
case 1186311332: return bem_syncAddVariable_0();
case -307967317: return bem_heldByGetDirect_0();
case 677572395: return bem_typeDetailGet_0();
case -1574410406: return bem_addVariable_0();
case -123203369: return bem_buildGet_0();
case 2005192015: return bem_serializeToString_0();
case 1904477853: return bem_typeDetailGetDirect_0();
case 952056940: return bem_toString_0();
case 44357133: return bem_toStringCompact_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1377625485: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1455687316: return bem_typenameSet_1(bevd_0);
case 1087770157: return bem_constantsSet_1(bevd_0);
case -1228323660: return bem_inFileSetDirect_1(bevd_0);
case 1445122167: return bem_nlcSetDirect_1(bevd_0);
case 1046739569: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1873037355: return bem_deleteAndAppend_1((BEC_2_5_4_BuildNode) bevd_0);
case 1272963269: return bem_sameObject_1(bevd_0);
case -1240319895: return bem_delayDeleteSet_1(bevd_0);
case 732247719: return bem_inClassNpSet_1(bevd_0);
case -98791052: return bem_defined_1(bevd_0);
case 1838925995: return bem_wideStringSet_1(bevd_0);
case -252645931: return bem_takeContents_1((BEC_2_5_4_BuildNode) bevd_0);
case -1666677787: return bem_ntypesSet_1(bevd_0);
case 1382252506: return bem_typenameSetDirect_1(bevd_0);
case -879450593: return bem_nlcSet_1(bevd_0);
case -957244466: return bem_heldSet_1(bevd_0);
case -510610212: return bem_nlecSet_1(bevd_0);
case 515692612: return bem_heldBySetDirect_1(bevd_0);
case 1607136830: return bem_containedSet_1(bevd_0);
case -2123337515: return bem_undef_1(bevd_0);
case -560923585: return bem_constantsSetDirect_1(bevd_0);
case 754947818: return bem_buildSet_1(bevd_0);
case -1432196319: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1550810969: return bem_inlinedSetDirect_1(bevd_0);
case -26559400: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1501191023: return bem_containerSetDirect_1(bevd_0);
case 1198427025: return bem_notEquals_1(bevd_0);
case 1885412952: return bem_heldBySet_1(bevd_0);
case -523809637: return bem_callIsSafe_1((BEC_2_5_4_BuildNode) bevd_0);
case 1532532742: return bem_undefined_1(bevd_0);
case 1902814965: return bem_wideStringSetDirect_1(bevd_0);
case 1139972121: return bem_prepend_1((BEC_2_5_4_BuildNode) bevd_0);
case 1689995065: return bem_nlecSetDirect_1(bevd_0);
case -1624434577: return bem_containedSetDirect_1(bevd_0);
case 2102889872: return bem_sameClass_1(bevd_0);
case -2135906324: return bem_condanySet_1(bevd_0);
case 241299765: return bem_sameType_1(bevd_0);
case 983903166: return bem_typeDetailSet_1(bevd_0);
case -1574992514: return bem_inFileSet_1(bevd_0);
case -1532620197: return bem_syncVariable_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case -490352436: return bem_containerSet_1(bevd_0);
case 1595530746: return bem_replaceWith_1((BEC_2_5_4_BuildNode) bevd_0);
case 363187330: return bem_buildSetDirect_1(bevd_0);
case -872324038: return bem_typeDetailSetDirect_1(bevd_0);
case 667172176: return bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevd_0);
case 981038037: return bem_copyLoc_1((BEC_2_5_4_BuildNode) bevd_0);
case 1003716077: return bem_def_1(bevd_0);
case 2069326800: return bem_otherType_1(bevd_0);
case -2032331004: return bem_ntypesSetDirect_1(bevd_0);
case -2013611925: return bem_heldSetDirect_1(bevd_0);
case -205196470: return bem_delayDeleteSetDirect_1(bevd_0);
case 1911701664: return bem_equals_1(bevd_0);
case -459360005: return bem_otherClass_1(bevd_0);
case 1135973654: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1337087644: return bem_inlinedSet_1(bevd_0);
case 186942505: return bem_inClassNpSetDirect_1(bevd_0);
case -585494508: return bem_copyTo_1(bevd_0);
case -683455065: return bem_addValue_1((BEC_2_5_4_BuildNode) bevd_0);
case -715454350: return bem_condanySetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1234965347: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -720811311: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 674286989: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1973929830: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -389946827: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2041425680: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1411035525: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -530730066: return bem_tmpVar_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildNode_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_4_BuildNode_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_BuildNode();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst = (BEC_2_5_4_BuildNode) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_type;
}
}
}
