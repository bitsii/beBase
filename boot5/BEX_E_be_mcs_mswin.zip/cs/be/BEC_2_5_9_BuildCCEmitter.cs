namespace be {
/* IO:File: source/build/CCEmitter.be */
public sealed class BEC_2_5_9_BuildCCEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
static BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_24, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x2A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_26, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_34, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_35, 14));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_36, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_37, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_65, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_69, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_70, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_71, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_79, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_80, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_81, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_84, 28));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_85, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_88, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_91, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x2A,0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_92, 3));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_102, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_103, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_104, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x63,0x63,0x53,0x67,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_105, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_106, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x2A,0x29,0x20,0x28,0x62,0x65,0x76,0x73,0x5F,0x73,0x74,0x61,0x63,0x6B,0x46,0x72,0x61,0x6D,0x65,0x2E,0x62,0x65,0x76,0x73,0x5F,0x6C,0x61,0x73,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_107, 45));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_108, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_109, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_110, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_111, 8));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_112, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_113, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_114, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_115, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x66,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_116, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x63,0x63,0x53,0x67,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_117, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_118, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x2A,0x29,0x20,0x28,0x62,0x65,0x76,0x73,0x5F,0x73,0x74,0x61,0x63,0x6B,0x46,0x72,0x61,0x6D,0x65,0x2E,0x62,0x65,0x76,0x73,0x5F,0x6C,0x61,0x73,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_119, 45));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_120, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x66,0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_121, 3));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_122, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_123, 8));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_124, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x66,0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_125, 3));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_126, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_127, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_128, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_129, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_130, 0));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_131, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x63,0x63,0x53,0x67,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_132, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_52 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_133, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x2A,0x29,0x20,0x28,0x62,0x65,0x76,0x73,0x5F,0x73,0x74,0x61,0x63,0x6B,0x46,0x72,0x61,0x6D,0x65,0x2E,0x62,0x65,0x76,0x73,0x5F,0x6C,0x61,0x73,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_53 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_134, 45));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_135, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_55 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_136, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_56 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_137, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_138, 8));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_58 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_139, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_59 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_140, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_60 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_143, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x2A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_61 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_144, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_62 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_145, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_63 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_146, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_64 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_148, 19));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_65 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_149, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_151 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_152 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_153 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_154 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_155 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_156 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_157 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_66 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_157, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_158 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_159 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_160 = {0x63,0x63,0x53,0x67,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_67 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_160, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_161 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_162 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_163 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_164 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_165 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_166 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_68 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_166, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_167 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_69 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_167, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_168 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_169 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_170 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_171 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_172 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_173 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_174 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_175 = {0x5D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_176 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_177 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_178 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_179 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_180 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_181 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_182 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_183 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_184 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_185 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_186 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_187 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_188 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_189 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_190 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_191 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_70 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_191, 22));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_192 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_193 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_194 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_195 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_196 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_197 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_198 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_199 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_200 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_201 = {0x66,0x6F,0x72,0x20,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x69,0x20,0x3D,0x20,0x30,0x3B,0x20,0x69,0x20,0x3C,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x20,0x69,0x2B,0x2B,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_202 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x67,0x5F,0x6C,0x65,0x20,0x3D,0x20,0x2A,0x28,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B,0x69,0x5D,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_203 = {0x62,0x65,0x76,0x67,0x5F,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_204 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_205 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_206 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_207 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_208 = {0x5D,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_209 = {0x7D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_210 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_211 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_212 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_213 = {0x42,0x45,0x44,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_71 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_213, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_214 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_72 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_214, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_215 = {0x42,0x45,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_73 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_215, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_216 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_74 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_216, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_217 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_218 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_219 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_220 = {0x75,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x73,0x74,0x64,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_221 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_222 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_223 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_224 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_225 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_226 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_227 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_228 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_229 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_230 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_231 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_232 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_233 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_234 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_235 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_75 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_235, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_236 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x69,0x6E,0x74,0x20,0x61,0x72,0x67,0x63,0x2C,0x20,0x63,0x68,0x61,0x72,0x20,0x2A,0x2A,0x61,0x72,0x67,0x76,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_237 = {0x63,0x63,0x53,0x67,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_76 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_237, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_238 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_239 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_240 = {0x63,0x63,0x42,0x67,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_77 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_240, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_241 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x2C,0x20,0x67,0x63,0x5F,0x61,0x6C,0x6C,0x6F,0x63,0x61,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_242 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_243 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_244 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_245 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_246 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_247 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_78 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_247, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_248 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_79 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_248, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_249 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_250 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_251 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_252 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_80 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_252, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_253 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_81 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_253, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_254 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_82 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_254, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_255 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_83 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_255, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_256 = {0x3A,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_84 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_256, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_257 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_85 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_257, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_258 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_259 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_260 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_261 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_262 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_263 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_264 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_265 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_266 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_267 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_268 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_269 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_270 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_271 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_272 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_273 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_274 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_275 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_276 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_277 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_278 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_279 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_280 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_281 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_282 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_283 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_284 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_285 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_286 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_287 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_288 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_289 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x42,0x45,0x58,0x5F,0x45,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_290 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x42,0x45,0x58,0x5F,0x45,0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_291 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_86 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_291, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_292 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_87 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_292, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_293 = {0x3A,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_88 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_293, 2));
public static new BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static new BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_6_TextString bevp_onceDecRefs;
public BEC_2_4_3_MathInt bevp_onceDecRefsCount;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
base.bem_new_1(beva__build);
bevp_invp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 45 */
 else  /* Line: 46 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 47 */
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
if (bevp_parentConf == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 56 */
 else  /* Line: 57 */ {
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevl_begin.bem_addValue_1(bevt_20_tmpany_phold);
} /* Line: 62 */
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevl_begin.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevl_begin.bem_addValue_1(bevt_22_tmpany_phold);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevp_heow.bem_write_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevp_heow.bem_write_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_0;
bevt_31_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_1;
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_2;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevp_heow.bem_write_1(bevt_26_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevp_heow.bem_write_1(bevt_41_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_3;
bevt_45_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_4;
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_add_1(bevt_46_tmpany_phold);
bevp_heow.bem_write_1(bevt_42_tmpany_phold);
bevt_49_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_5;
bevt_50_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevt_50_tmpany_phold);
bevt_51_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_6;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_51_tmpany_phold);
bevp_deow.bem_write_1(bevt_47_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
return bevt_52_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bevt_7_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_22_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(-1043940625);
bevt_20_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_tmpany_phold );
bevt_23_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_relEmitName_1(bevt_23_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_26_tmpany_phold);
bevt_25_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
bevp_heow.bem_write_1(bevt_0_tmpany_phold);
return bevl_end;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevt_0_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevt_14_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevp_classHeadBody.bem_addValue_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_22_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_23_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_17_tmpany_phold.bem_addValue_1(bevt_25_tmpany_phold);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevp_classHeadBody.bem_addValue_1(bevt_26_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_tmpany_phold.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 141 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
} /* Line: 142 */
 else  /* Line: 141 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-1929015479);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-905872983, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 143 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
} /* Line: 144 */
 else  /* Line: 141 */ {
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1929015479);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(-905872983, bevt_10_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 145 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
} /* Line: 146 */
 else  /* Line: 147 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_tmpany_phold );
} /* Line: 148 */
} /* Line: 141 */
} /* Line: 141 */
return bevl_tcall;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-1929015479);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-905872983, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 154 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_7;
bevl_tcall = bevt_4_tmpany_phold.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 156 */
bevt_5_tmpany_phold = base.bem_formCallTarg_1(beva_node);
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1821960912);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(2089390654, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 166 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1240261355);
bevp_classHeaders.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 167 */
 else  /* Line: 168 */ {
base.bem_handleClassEmit_1(beva_node);
} /* Line: 169 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_8;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_9;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_10;
bevt_8_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_11;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_12;
bevl_clh = bevt_4_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevt_14_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_11_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_25_tmpany_phold);
bevt_26_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) bevt_24_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevt_23_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) bevt_22_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_13;
bevt_32_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_14;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_33_tmpany_phold);
bevt_21_tmpany_phold.bem_addValue_1(bevt_29_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_15;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-1829007767);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(572714860);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_16;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_17;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_8_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v.bem_isTypedGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevt_4_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_3_tmpany_phold = bevp_objectCc.bem_relEmitName_1(bevt_4_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_2_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 201 */
 else  /* Line: 202 */ {
bevt_9_tmpany_phold = beva_v.bem_namepathGet_0();
bevt_8_tmpany_phold = bem_getClassConfig_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevt_6_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
} /* Line: 203 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_18;
bevt_0_tmpany_phold = beva_type.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
} /* Line: 209 */
 else  /* Line: 210 */ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
} /* Line: 211 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_19;
bevt_4_tmpany_phold = bevl_ccall.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_20;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_afterCast_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevt_8_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(beva_len);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_23_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 229 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_21;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_22;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-2030168238);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 230 */
bevt_12_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_24;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_has_1(bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 232 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_25;
bevt_21_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_20_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_26;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_23_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_24_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_27;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = beva_node.bem_heldGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bemd_0(-2030168238);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_26_tmpany_phold);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_28;
bevl_newCall = bevt_14_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
} /* Line: 233 */
 else  /* Line: 234 */ {
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_29;
bevt_36_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_35_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_36_tmpany_phold);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevt_35_tmpany_phold);
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_30;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_37_tmpany_phold);
bevt_39_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_38_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_39_tmpany_phold);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_31;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
bevt_42_tmpany_phold = beva_node.bem_heldGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_0(-2030168238);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_32;
bevl_newCall = bevt_29_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
} /* Line: 235 */
return bevl_newCall;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 241 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_33;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_34;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-2030168238);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_35;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 242 */
bevt_12_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_36;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_has_1(bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 244 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_37;
bevt_21_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_20_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_38;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_23_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_24_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_39;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = beva_node.bem_heldGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bemd_0(-2030168238);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_26_tmpany_phold);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_40;
bevl_newCall = bevt_14_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
} /* Line: 245 */
 else  /* Line: 246 */ {
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_41;
bevt_36_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_35_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_36_tmpany_phold);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevt_35_tmpany_phold);
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_42;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_37_tmpany_phold);
bevt_39_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_38_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_39_tmpany_phold);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_43;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
bevt_42_tmpany_phold = beva_node.bem_heldGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_0(-2030168238);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_44;
bevl_newCall = bevt_29_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
} /* Line: 247 */
return bevl_newCall;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 253 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_45;
bevt_8_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_46;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_47;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_48;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 254 */
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_49;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_50;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevl_litArgs = bevt_12_tmpany_phold.bem_add_1(beva_belsName);
bevt_17_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_51;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_has_1(bevt_18_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 258 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_52;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_53;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_28_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_54;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevl_litArgs);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_55;
bevl_newCall = bevt_19_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
} /* Line: 259 */
 else  /* Line: 260 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_56;
bevt_39_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_38_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_39_tmpany_phold);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_57;
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
bevt_42_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_41_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_42_tmpany_phold);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_58;
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevl_litArgs);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_59;
bevl_newCall = bevt_32_tmpany_phold.bem_add_1(bevt_44_tmpany_phold);
} /* Line: 261 */
return bevl_newCall;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevp_onceDecRefsCount.bevi_int++;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_notEmpty_1(bevp_onceDecRefs);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevp_onceDecRefs.bem_addValue_1(bevt_2_tmpany_phold);
} /* Line: 269 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevp_onceDecRefs.bem_addValue_1(bevt_4_tmpany_phold);
bevt_3_tmpany_phold.bem_addValue_1(beva_anyName);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_60;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_typeName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_61;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_62;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_63;
bevt_1_tmpany_phold = beva_typeName.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_mainInClassGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_64;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_65;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_150));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_151));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_152));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_153));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-1929015479);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_154));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_155));
return bevt_18_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_156));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_66;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_preClassOutput_0() {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
bevp_setOutputTime = null;
bevt_1_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 324 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 324 */ {
bevt_5_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 324 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 324 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 324 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 324 */ {
return this;
} /* Line: 325 */
 else  /* Line: 326 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevl_outts = bevt_6_tmpany_phold.bem_lastUpdatedGet_0();
bevt_9_tmpany_phold = bevp_inClass.bem_fromFileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-2089391698);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bemd_0(-1317775045);
bevt_10_tmpany_phold = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 329 */ {
return this;
} /* Line: 332 */
bevp_setOutputTime = bevl_outts;
} /* Line: 335 */
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_1_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 340 */ {
bevt_1_tmpany_phold = bem_getLibOutput_0();
return bevt_1_tmpany_phold;
} /* Line: 341 */
bevt_2_tmpany_phold = base.bem_getClassOutput_0();
return bevt_2_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 347 */ {
bevl_clns = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_158));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 350 */
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 355 */ {
bevl_clend = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_159));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 361 */ {
bevt_4_tmpany_phold = beva_cle.bem_pathGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 363 */
} /* Line: 361 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_67;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_has_1(bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 370 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_161));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(beva_mvn);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_162));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(beva_mvn);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_163));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_3_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(beva_mvn);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_164));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_165));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 373 */
return bevl_bet;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_68;
bevt_5_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_69;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevp_deow.bem_write_1(bevt_2_tmpany_phold);
bevl_beh = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_168));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_169));
bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_170));
bevl_beh.bem_addValue_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_171));
bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_172));
bevl_beh.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_173));
bevl_beh.bem_addValue_1(bevt_17_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_174));
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_20_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_175));
bevt_18_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_176));
bevl_beh.bem_addValue_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_177));
bevl_beh.bem_addValue_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_178));
bevl_beh.bem_addValue_1(bevt_24_tmpany_phold);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_28_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_179));
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevt_27_tmpany_phold.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) bevt_26_tmpany_phold.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_180));
bevt_25_tmpany_phold.bem_addValue_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_181));
bevl_bet.bem_addValue_1(bevt_32_tmpany_phold);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_33_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_33_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 396 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-142543557);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 396 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(-515235618);
if (bevl_firstmnsyn.bevi_bool) /* Line: 397 */ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 398 */
 else  /* Line: 399 */ {
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_182));
bevl_bet.bem_addValue_1(bevt_35_tmpany_phold);
} /* Line: 400 */
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_38_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevt_37_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_36_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 402 */
 else  /* Line: 396 */ {
break;
} /* Line: 396 */
} /* Line: 396 */
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_183));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_184));
bevl_bet.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_185));
bevl_bet.bem_addValue_1(bevt_41_tmpany_phold);
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_42_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_42_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 409 */ {
bevt_43_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-142543557);
if (((BEC_2_5_4_LogicBool) bevt_43_tmpany_phold).bevi_bool) /* Line: 409 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(-515235618);
if (bevl_firstptsyn.bevi_bool) /* Line: 410 */ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 411 */
 else  /* Line: 412 */ {
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_186));
bevl_bet.bem_addValue_1(bevt_44_tmpany_phold);
} /* Line: 413 */
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_47_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) bevt_46_tmpany_phold.bem_addValue_1(bevt_47_tmpany_phold);
bevt_45_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 415 */
 else  /* Line: 409 */ {
break;
} /* Line: 409 */
} /* Line: 409 */
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_187));
bevl_bet.bem_addValue_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_188));
bevl_bet.bem_addValue_1(bevt_49_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_189));
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_190));
bevt_50_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_57_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_70;
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bem_equals_1(bevt_57_tmpany_phold);
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 422 */ {
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_192));
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_60_tmpany_phold);
bevt_61_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) bevt_59_tmpany_phold.bem_addValue_1(bevt_61_tmpany_phold);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_193));
bevt_58_tmpany_phold.bem_addValue_1(bevt_62_tmpany_phold);
} /* Line: 423 */
 else  /* Line: 424 */ {
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_194));
bevt_64_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_65_tmpany_phold);
bevt_66_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) bevt_64_tmpany_phold.bem_addValue_1(bevt_66_tmpany_phold);
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_195));
bevt_63_tmpany_phold.bem_addValue_1(bevt_67_tmpany_phold);
} /* Line: 425 */
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_196));
bevl_bet.bem_addValue_1(bevt_68_tmpany_phold);
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_197));
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) bevt_70_tmpany_phold.bem_addValue_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_198));
bevt_69_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_199));
bevl_bet.bem_addValue_1(bevt_74_tmpany_phold);
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_200));
bevt_75_tmpany_phold = bem_genMark_1(bevt_76_tmpany_phold);
bevl_bet.bem_addValue_1(bevt_75_tmpany_phold);
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_201));
bevl_bet.bem_addValue_1(bevt_77_tmpany_phold);
bevt_78_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(56, bece_BEC_2_5_9_BuildCCEmitter_bels_202));
bevl_bet.bem_addValue_1(bevt_78_tmpany_phold);
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_203));
bevt_79_tmpany_phold = bem_genMark_1(bevt_80_tmpany_phold);
bevl_bet.bem_addValue_1(bevt_79_tmpany_phold);
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_204));
bevl_bet.bem_addValue_1(bevt_81_tmpany_phold);
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_205));
bevl_bet.bem_addValue_1(bevt_82_tmpany_phold);
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_206));
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCCEmitter_bels_207));
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) bevt_87_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_208));
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) bevt_86_tmpany_phold.bem_addValue_1(bevt_93_tmpany_phold);
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) bevt_85_tmpany_phold.bem_addValue_1(bevp_onceDecRefs);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_209));
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) bevt_84_tmpany_phold.bem_addValue_1(bevt_94_tmpany_phold);
bevt_83_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_210));
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevt_99_tmpany_phold);
bevt_100_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_211));
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) bevt_97_tmpany_phold.bem_addValue_1(bevt_101_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) bevt_96_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_212));
bevt_95_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevp_onceDecRefs.bem_clear_0();
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_103_tmpany_phold = bem_getClassOutput_0();
bevt_103_tmpany_phold.bem_write_1(bevl_bet);
bevt_104_tmpany_phold = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_104_tmpany_phold.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_20_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_21_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_22_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_31_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
if (bevp_deow == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 456 */ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_71;
bevt_8_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_72;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_libName);
bevp_deon = bevt_4_tmpany_phold.bem_add_1(bevp_headExt);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_73;
bevt_14_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_74;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevl_libName);
bevp_heon = bevt_10_tmpany_phold.bem_add_1(bevp_headExt);
bevt_16_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_tmpany_phold.bem_addStep_1(bevp_deon);
bevt_17_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_tmpany_phold.bem_addStep_1(bevp_heon);
bevt_21_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_existsGet_0();
if (bevt_19_tmpany_phold.bevi_bool) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 462 */ {
bevt_23_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_fileGet_0();
bevt_22_tmpany_phold.bem_makeDirs_0();
} /* Line: 463 */
bevt_25_tmpany_phold = bevp_deop.bem_fileGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_tmpany_phold.bemd_0(1541452525);
bevt_27_tmpany_phold = bevp_heop.bem_fileGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_tmpany_phold.bemd_0(1541452525);
bevt_29_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_217));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_has_1(bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 468 */ {
bevt_32_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_218));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_get_1(bevt_33_tmpany_phold);
bevt_0_tmpany_loop = bevt_31_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 470 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-142543557);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 470 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-515235618);
bevt_35_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_tmpany_phold.bem_fileGet_0();
bevt_37_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(1541452525);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bemd_0(1518642734);
bevt_38_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_38_tmpany_phold.bemd_0(-1196419988);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 476 */
 else  /* Line: 470 */ {
break;
} /* Line: 470 */
} /* Line: 470 */
} /* Line: 470 */
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_219));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_220));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_221));
bevp_deow.bem_write_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_222));
bevp_heow.bem_write_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_223));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_has_1(bevt_45_tmpany_phold);
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 490 */ {
bevt_47_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_224));
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_get_1(bevt_48_tmpany_phold);
bevt_1_tmpany_loop = bevt_46_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 492 */ {
bevt_49_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-142543557);
if (((BEC_2_5_4_LogicBool) bevt_49_tmpany_phold).bevi_bool) /* Line: 492 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(-515235618);
bevt_50_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_50_tmpany_phold.bem_fileGet_0();
bevt_52_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(1541452525);
bevl_inc = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bemd_0(1518642734);
bevt_53_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_53_tmpany_phold.bemd_0(-1196419988);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 498 */
 else  /* Line: 492 */ {
break;
} /* Line: 492 */
} /* Line: 492 */
} /* Line: 492 */
bevt_55_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_225));
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_has_1(bevt_56_tmpany_phold);
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 501 */ {
bevt_58_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_226));
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_get_1(bevt_59_tmpany_phold);
bevt_2_tmpany_loop = bevt_57_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 503 */ {
bevt_60_tmpany_phold = bevt_2_tmpany_loop.bemd_0(-142543557);
if (((BEC_2_5_4_LogicBool) bevt_60_tmpany_phold).bevi_bool) /* Line: 503 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(-515235618);
bevt_61_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_61_tmpany_phold.bem_fileGet_0();
bevt_63_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(1541452525);
bevl_inc = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bemd_0(1518642734);
bevt_64_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_64_tmpany_phold.bemd_0(-1196419988);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 509 */
 else  /* Line: 503 */ {
break;
} /* Line: 503 */
} /* Line: 503 */
} /* Line: 503 */
} /* Line: 501 */
return this;
} /*method end*/
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_27_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_6_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_existsGet_0();
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 524 */ {
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_fileGet_0();
bevt_7_tmpany_phold.bem_makeDirs_0();
} /* Line: 525 */
bevt_10_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_tmpany_phold.bemd_0(1541452525);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_227));
bevp_shlibe.bem_write_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_228));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_has_1(bevt_14_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 531 */ {
bevt_16_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_229));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_get_1(bevt_17_tmpany_phold);
bevt_0_tmpany_loop = bevt_15_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 533 */ {
bevt_18_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-142543557);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 533 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-515235618);
bevt_19_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_tmpany_phold.bem_fileGet_0();
bevt_21_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(1541452525);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bemd_0(1518642734);
bevt_22_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_22_tmpany_phold.bemd_0(-1196419988);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 539 */
 else  /* Line: 533 */ {
break;
} /* Line: 533 */
} /* Line: 533 */
} /* Line: 533 */
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_230));
bevp_shlibe.bem_write_1(bevt_23_tmpany_phold);
bevp_lineCount.bem_increment_0();
bevt_25_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_231));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_has_1(bevt_26_tmpany_phold);
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 545 */ {
bevt_28_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_232));
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_get_1(bevt_29_tmpany_phold);
bevt_1_tmpany_loop = bevt_27_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 546 */ {
bevt_30_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-142543557);
if (((BEC_2_5_4_LogicBool) bevt_30_tmpany_phold).bevi_bool) /* Line: 546 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(-515235618);
bevt_31_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_tmpany_phold.bem_fileGet_0();
bevt_33_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(1541452525);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bemd_0(1518642734);
bevt_34_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_34_tmpany_phold.bemd_0(-1196419988);
bevt_35_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 551 */
 else  /* Line: 546 */ {
break;
} /* Line: 546 */
} /* Line: 546 */
} /* Line: 546 */
} /* Line: 545 */
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
BEC_2_4_6_TextString bevl_mh = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_233));
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_234));
bevp_heow.bem_write_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_75;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_has_1(bevt_4_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 569 */ {
bevl_mh = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_236));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevl_mh.bem_addValue_1(bevt_6_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(bevp_nl);
bevp_heow.bem_write_1(bevl_mh);
} /* Line: 572 */
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_76;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_has_1(bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 585 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_238));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_239));
bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 586 */
 else  /* Line: 585 */ {
bevt_8_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_77;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_has_1(bevt_9_tmpany_phold);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 587 */ {
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(58, bece_BEC_2_5_9_BuildCCEmitter_bels_241));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_12_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_242));
bevt_10_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
} /* Line: 588 */
} /* Line: 585 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(-1107645358);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_243));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 600 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-142543557);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 600 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(-515235618);
if (bevl_first.bevi_bool) /* Line: 601 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 602 */
 else  /* Line: 603 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_244));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 604 */
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_245));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 606 */
 else  /* Line: 600 */ {
break;
} /* Line: 600 */
} /* Line: 600 */
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_246));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_78;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_79;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_249));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_250));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_251));
bevt_4_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_80;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_81;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevl_bein;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_82;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_83;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_84;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_runtimeInitGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_85;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
bevt_1_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_1_tmpany_phold.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-1043940625);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_13_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_258));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_259));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_260));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_261));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_asnr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_262));
bevt_20_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 647 */ {
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_263));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_21_tmpany_phold, bevl_asnr);
} /* Line: 648 */
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_264));
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) bevt_25_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) bevt_24_tmpany_phold.bem_addValue_1(bevl_asnr);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_265));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevt_23_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_266));
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_29_tmpany_phold);
bevt_28_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_267));
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) bevt_35_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) bevt_34_tmpany_phold.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_268));
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_269));
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) bevt_31_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_30_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_270));
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_45_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) bevt_44_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_271));
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) bevt_43_tmpany_phold.bem_addValue_1(bevt_46_tmpany_phold);
bevt_42_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_272));
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_48_tmpany_phold);
bevt_47_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_55_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_55_tmpany_phold);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_273));
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) bevt_54_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_57_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) bevt_53_tmpany_phold.bem_addValue_1(bevt_57_tmpany_phold);
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_274));
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_275));
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) bevt_50_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_49_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_62_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(-1818847089);
if (bevt_61_tmpany_phold == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 667 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 667 */ {
bevt_65_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bemd_0(-1818847089);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_1(-905872983, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_63_tmpany_phold).bevi_bool) /* Line: 667 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 667 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 667 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 667 */ {
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_276));
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_67_tmpany_phold);
bevt_66_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 668 */
 else  /* Line: 669 */ {
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_277));
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_69_tmpany_phold);
bevt_68_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 670 */
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_278));
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_71_tmpany_phold);
bevt_70_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_78_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_78_tmpany_phold);
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_279));
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) bevt_77_tmpany_phold.bem_addValue_1(bevt_79_tmpany_phold);
bevt_80_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) bevt_76_tmpany_phold.bem_addValue_1(bevt_80_tmpany_phold);
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_280));
bevt_74_tmpany_phold = (BEC_2_4_6_TextString) bevt_75_tmpany_phold.bem_addValue_1(bevt_81_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) bevt_74_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_281));
bevt_72_tmpany_phold = (BEC_2_4_6_TextString) bevt_73_tmpany_phold.bem_addValue_1(bevt_82_tmpany_phold);
bevt_72_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_282));
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_84_tmpany_phold);
bevt_83_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_283));
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_86_tmpany_phold);
bevt_85_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_284));
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_285));
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_286));
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_96_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) bevt_95_tmpany_phold.bem_addValue_1(bevl_tinst);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_287));
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) bevt_94_tmpany_phold.bem_addValue_1(bevt_97_tmpany_phold);
bevt_93_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_288));
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_99_tmpany_phold);
bevt_98_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_289));
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCCEmitter_bels_290));
bevp_heow.bem_write_1(bevt_1_tmpany_phold);
base.bem_emitLib_0();
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_86;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_87;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_88;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGetDirect_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGetDirect_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGetDirect_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_onceDecRefsGet_0() {
return bevp_onceDecRefs;
} /*method end*/
public BEC_2_4_6_TextString bem_onceDecRefsGetDirect_0() {
return bevp_onceDecRefs;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceDecRefsCountGet_0() {
return bevp_onceDecRefsCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceDecRefsCountGetDirect_0() {
return bevp_onceDecRefsCount;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGetDirect_0() {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() {
return bevp_deon;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGetDirect_0() {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() {
return bevp_heon;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGetDirect_0() {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() {
return bevp_deop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGetDirect_0() {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() {
return bevp_heop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGetDirect_0() {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() {
return bevp_deow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGetDirect_0() {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() {
return bevp_heow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGetDirect_0() {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 20, 22, 23, 24, 25, 26, 30, 32, 33, 34, 35, 36, 40, 44, 44, 45, 45, 45, 47, 47, 49, 49, 49, 49, 49, 49, 51, 51, 52, 52, 54, 54, 56, 56, 56, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 65, 65, 67, 67, 69, 71, 73, 75, 77, 77, 78, 78, 79, 79, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 85, 85, 86, 86, 87, 87, 88, 88, 88, 88, 88, 88, 90, 90, 90, 90, 90, 90, 92, 92, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 99, 99, 99, 103, 105, 106, 107, 107, 108, 112, 112, 116, 116, 120, 120, 125, 125, 125, 125, 125, 125, 125, 125, 125, 125, 125, 125, 125, 127, 129, 129, 129, 129, 129, 129, 131, 131, 131, 131, 131, 131, 131, 131, 131, 131, 133, 135, 135, 141, 141, 141, 141, 142, 143, 143, 143, 143, 144, 145, 145, 145, 145, 146, 148, 148, 150, 154, 154, 154, 154, 155, 155, 156, 158, 158, 162, 162, 162, 162, 162, 162, 162, 162, 166, 166, 166, 166, 167, 167, 167, 169, 175, 175, 175, 175, 175, 177, 177, 177, 177, 177, 177, 177, 177, 179, 181, 183, 183, 183, 183, 183, 183, 183, 183, 183, 183, 183, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 187, 192, 192, 192, 193, 194, 194, 194, 194, 194, 194, 196, 196, 196, 196, 196, 196, 196, 196, 196, 196, 200, 200, 200, 201, 201, 201, 201, 201, 203, 203, 203, 203, 203, 203, 203, 208, 208, 209, 211, 213, 213, 213, 213, 213, 213, 213, 213, 218, 218, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 223, 223, 223, 223, 223, 223, 223, 223, 223, 225, 225, 225, 230, 230, 230, 230, 230, 230, 230, 230, 230, 230, 230, 230, 232, 232, 232, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 237, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 244, 244, 244, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 249, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 257, 257, 257, 257, 257, 258, 258, 258, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 263, 267, 268, 268, 269, 269, 271, 271, 271, 272, 272, 272, 272, 272, 277, 278, 279, 279, 279, 280, 286, 286, 286, 286, 290, 290, 294, 294, 299, 299, 303, 303, 303, 303, 303, 304, 304, 304, 304, 304, 304, 305, 305, 305, 306, 306, 306, 306, 306, 306, 306, 306, 308, 308, 312, 312, 316, 316, 316, 316, 323, 324, 0, 324, 324, 324, 324, 324, 0, 0, 325, 327, 327, 327, 328, 328, 328, 329, 332, 335, 340, 341, 341, 343, 343, 347, 348, 349, 349, 350, 355, 357, 358, 358, 359, 360, 361, 361, 362, 362, 362, 363, 369, 370, 370, 370, 371, 371, 371, 371, 371, 371, 371, 371, 371, 372, 372, 372, 372, 373, 373, 373, 375, 379, 379, 379, 379, 379, 379, 380, 381, 381, 381, 381, 381, 381, 382, 382, 383, 383, 383, 383, 384, 384, 385, 385, 386, 386, 386, 386, 386, 387, 387, 388, 388, 389, 389, 390, 392, 393, 393, 393, 393, 393, 393, 393, 393, 394, 394, 395, 396, 396, 0, 396, 396, 398, 400, 400, 402, 402, 402, 402, 404, 404, 405, 405, 407, 407, 408, 409, 409, 0, 409, 409, 411, 413, 413, 415, 415, 415, 415, 417, 417, 419, 419, 421, 421, 421, 421, 421, 421, 422, 422, 422, 423, 423, 423, 423, 423, 423, 425, 425, 425, 425, 425, 425, 427, 427, 429, 429, 429, 429, 429, 429, 430, 430, 431, 431, 431, 432, 432, 433, 433, 434, 434, 434, 435, 435, 436, 436, 438, 438, 438, 438, 438, 438, 438, 438, 438, 438, 438, 438, 438, 439, 439, 439, 439, 439, 439, 439, 439, 439, 440, 441, 443, 443, 444, 444, 456, 456, 457, 458, 458, 458, 458, 458, 458, 458, 459, 459, 459, 459, 459, 459, 459, 460, 460, 461, 461, 462, 462, 462, 462, 462, 463, 463, 463, 465, 465, 465, 466, 466, 466, 468, 468, 468, 470, 470, 470, 470, 0, 470, 470, 472, 472, 473, 473, 473, 474, 474, 476, 480, 480, 481, 481, 483, 483, 484, 484, 490, 490, 490, 492, 492, 492, 492, 0, 492, 492, 494, 494, 495, 495, 495, 496, 496, 498, 501, 501, 501, 503, 503, 503, 503, 0, 503, 503, 505, 505, 506, 506, 506, 507, 507, 509, 516, 517, 522, 522, 523, 524, 524, 524, 524, 524, 525, 525, 525, 527, 527, 527, 529, 529, 531, 531, 531, 533, 533, 533, 533, 0, 533, 533, 535, 535, 536, 536, 536, 537, 537, 539, 543, 543, 544, 545, 545, 545, 546, 546, 546, 546, 0, 546, 546, 547, 547, 548, 548, 548, 549, 549, 550, 550, 551, 557, 562, 563, 565, 565, 567, 567, 569, 569, 569, 570, 571, 571, 571, 572, 575, 576, 581, 581, 585, 585, 585, 586, 586, 586, 586, 586, 587, 587, 587, 588, 588, 588, 588, 588, 594, 594, 595, 597, 597, 597, 597, 599, 600, 0, 600, 600, 602, 604, 604, 606, 606, 606, 606, 606, 606, 610, 610, 610, 615, 617, 617, 617, 617, 617, 619, 619, 619, 619, 619, 619, 619, 619, 619, 619, 619, 621, 625, 625, 626, 626, 626, 626, 627, 631, 631, 632, 632, 632, 632, 633, 633, 633, 633, 637, 637, 637, 641, 641, 641, 642, 642, 642, 643, 645, 645, 645, 645, 645, 645, 645, 645, 645, 645, 645, 645, 645, 645, 645, 646, 647, 647, 648, 648, 651, 651, 651, 651, 651, 651, 651, 653, 653, 653, 656, 656, 656, 656, 656, 656, 656, 656, 656, 656, 656, 656, 656, 661, 661, 661, 661, 661, 661, 664, 664, 664, 666, 666, 666, 666, 666, 666, 666, 666, 666, 666, 666, 666, 667, 667, 667, 667, 0, 667, 667, 667, 0, 0, 668, 668, 668, 670, 670, 670, 672, 673, 676, 676, 676, 678, 678, 678, 678, 678, 678, 678, 678, 678, 678, 678, 678, 679, 679, 679, 681, 681, 681, 683, 685, 685, 685, 685, 685, 685, 685, 687, 687, 687, 687, 687, 687, 689, 689, 689, 695, 695, 696, 696, 698, 703, 703, 704, 704, 704, 704, 705, 705, 705, 705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 426, 485, 490, 491, 492, 493, 496, 497, 499, 500, 501, 502, 503, 504, 505, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 524, 525, 526, 527, 528, 529, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 647, 648, 649, 650, 651, 652, 656, 657, 661, 662, 666, 667, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 746, 747, 748, 753, 754, 757, 758, 759, 760, 762, 765, 766, 767, 768, 770, 773, 774, 778, 788, 789, 790, 791, 793, 794, 795, 797, 798, 808, 809, 810, 811, 812, 813, 814, 815, 825, 826, 827, 828, 830, 831, 832, 835, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 972, 973, 978, 979, 980, 981, 982, 983, 986, 987, 988, 989, 990, 991, 992, 1007, 1008, 1010, 1013, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1026, 1027, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 1139, 1140, 1141, 1143, 1144, 1145, 1147, 1148, 1149, 1150, 1151, 1152, 1153, 1154, 1155, 1156, 1157, 1158, 1159, 1160, 1161, 1162, 1165, 1166, 1167, 1168, 1169, 1170, 1171, 1172, 1173, 1174, 1175, 1176, 1177, 1178, 1179, 1180, 1182, 1231, 1232, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1244, 1245, 1246, 1248, 1249, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1259, 1260, 1261, 1262, 1263, 1266, 1267, 1268, 1269, 1270, 1271, 1272, 1273, 1274, 1275, 1276, 1277, 1278, 1279, 1280, 1281, 1283, 1334, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1345, 1346, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1357, 1358, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1373, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1386, 1388, 1400, 1401, 1402, 1404, 1405, 1407, 1408, 1409, 1410, 1411, 1412, 1413, 1414, 1420, 1421, 1422, 1423, 1424, 1425, 1432, 1433, 1434, 1435, 1439, 1440, 1444, 1445, 1449, 1450, 1473, 1474, 1475, 1476, 1477, 1478, 1479, 1480, 1481, 1482, 1483, 1484, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492, 1493, 1494, 1495, 1496, 1500, 1501, 1507, 1508, 1509, 1510, 1526, 1527, 1529, 1532, 1533, 1534, 1535, 1540, 1541, 1544, 1548, 1551, 1552, 1553, 1554, 1555, 1556, 1557, 1559, 1561, 1569, 1571, 1572, 1574, 1575, 1581, 1583, 1584, 1585, 1586, 1597, 1599, 1600, 1601, 1602, 1603, 1604, 1609, 1610, 1611, 1612, 1613, 1636, 1637, 1638, 1639, 1641, 1642, 1643, 1644, 1645, 1646, 1647, 1648, 1649, 1650, 1651, 1652, 1653, 1654, 1655, 1656, 1658, 1772, 1773, 1774, 1775, 1776, 1777, 1778, 1779, 1780, 1781, 1782, 1783, 1784, 1785, 1786, 1787, 1788, 1789, 1790, 1791, 1792, 1793, 1794, 1795, 1796, 1797, 1798, 1799, 1800, 1801, 1802, 1803, 1804, 1805, 1806, 1807, 1808, 1809, 1810, 1811, 1812, 1813, 1814, 1815, 1816, 1817, 1818, 1819, 1820, 1820, 1823, 1825, 1827, 1830, 1831, 1833, 1834, 1835, 1836, 1842, 1843, 1844, 1845, 1846, 1847, 1848, 1849, 1850, 1850, 1853, 1855, 1857, 1860, 1861, 1863, 1864, 1865, 1866, 1872, 1873, 1874, 1875, 1876, 1877, 1878, 1879, 1880, 1881, 1882, 1883, 1884, 1886, 1887, 1888, 1889, 1890, 1891, 1894, 1895, 1896, 1897, 1898, 1899, 1901, 1902, 1903, 1904, 1905, 1906, 1907, 1908, 1909, 1910, 1911, 1912, 1913, 1914, 1915, 1916, 1917, 1918, 1919, 1920, 1921, 1922, 1923, 1924, 1925, 1926, 1927, 1928, 1929, 1930, 1931, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1940, 1941, 1942, 1943, 1944, 1945, 1946, 1947, 1948, 1949, 1950, 1951, 1952, 2025, 2030, 2031, 2032, 2033, 2034, 2035, 2036, 2037, 2038, 2039, 2040, 2041, 2042, 2043, 2044, 2045, 2046, 2047, 2048, 2049, 2050, 2051, 2052, 2053, 2058, 2059, 2060, 2061, 2063, 2064, 2065, 2066, 2067, 2068, 2069, 2070, 2071, 2073, 2074, 2075, 2076, 2076, 2079, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2096, 2097, 2098, 2099, 2100, 2101, 2102, 2103, 2104, 2105, 2106, 2108, 2109, 2110, 2111, 2111, 2114, 2116, 2117, 2118, 2119, 2120, 2121, 2122, 2123, 2124, 2131, 2132, 2133, 2135, 2136, 2137, 2138, 2138, 2141, 2143, 2144, 2145, 2146, 2147, 2148, 2149, 2150, 2151, 2162, 2163, 2206, 2211, 2212, 2213, 2214, 2215, 2216, 2221, 2222, 2223, 2224, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2233, 2235, 2236, 2237, 2238, 2238, 2241, 2243, 2244, 2245, 2246, 2247, 2248, 2249, 2250, 2251, 2258, 2259, 2260, 2261, 2262, 2263, 2265, 2266, 2267, 2268, 2268, 2271, 2273, 2274, 2275, 2276, 2277, 2278, 2279, 2280, 2281, 2282, 2283, 2291, 2302, 2303, 2304, 2305, 2306, 2307, 2308, 2309, 2310, 2312, 2313, 2314, 2315, 2316, 2318, 2319, 2324, 2325, 2342, 2343, 2344, 2346, 2347, 2348, 2349, 2350, 2353, 2354, 2355, 2357, 2358, 2359, 2360, 2361, 2385, 2386, 2387, 2388, 2389, 2390, 2391, 2392, 2393, 2393, 2396, 2398, 2400, 2403, 2404, 2406, 2407, 2408, 2409, 2410, 2411, 2417, 2418, 2419, 2439, 2440, 2441, 2442, 2443, 2444, 2445, 2446, 2447, 2448, 2449, 2450, 2451, 2452, 2453, 2454, 2455, 2456, 2465, 2466, 2467, 2468, 2469, 2470, 2471, 2483, 2484, 2485, 2486, 2487, 2488, 2489, 2490, 2491, 2492, 2497, 2498, 2499, 2607, 2608, 2609, 2610, 2611, 2612, 2613, 2614, 2615, 2616, 2617, 2618, 2619, 2620, 2621, 2622, 2623, 2624, 2625, 2626, 2627, 2628, 2629, 2630, 2631, 2633, 2634, 2636, 2637, 2638, 2639, 2640, 2641, 2642, 2643, 2644, 2645, 2646, 2647, 2648, 2649, 2650, 2651, 2652, 2653, 2654, 2655, 2656, 2657, 2658, 2659, 2660, 2661, 2662, 2663, 2664, 2665, 2666, 2667, 2668, 2669, 2670, 2671, 2672, 2673, 2674, 2675, 2676, 2677, 2678, 2679, 2680, 2681, 2682, 2687, 2688, 2691, 2692, 2693, 2695, 2698, 2702, 2703, 2704, 2707, 2708, 2709, 2711, 2712, 2713, 2714, 2715, 2716, 2717, 2718, 2719, 2720, 2721, 2722, 2723, 2724, 2725, 2726, 2727, 2728, 2729, 2730, 2731, 2732, 2733, 2734, 2735, 2736, 2737, 2738, 2739, 2740, 2741, 2742, 2743, 2744, 2745, 2746, 2747, 2748, 2749, 2750, 2756, 2757, 2758, 2759, 2760, 2773, 2774, 2775, 2776, 2777, 2778, 2779, 2780, 2781, 2782, 2785, 2788, 2791, 2795, 2799, 2802, 2805, 2809, 2813, 2816, 2819, 2823, 2827, 2830, 2833, 2837, 2841, 2844, 2847, 2851, 2855, 2858, 2861, 2865, 2869, 2872, 2875, 2879, 2883, 2886, 2889, 2893, 2897, 2900, 2903, 2907, 2911, 2914, 2917, 2921, 2925, 2928, 2931, 2935, 2939, 2942, 2945, 2949, 2953, 2956, 2959, 2963};
/* BEGIN LINEINFO 
assign 1 18 409
new 0 18 409
assign 1 19 410
new 0 19 410
assign 1 20 411
new 0 20 411
assign 1 22 412
new 0 22 412
assign 1 23 413
new 0 23 413
assign 1 24 414
new 0 24 414
assign 1 25 415
new 0 25 415
assign 1 26 416
new 0 26 416
new 1 30 417
assign 1 32 418
new 0 32 418
assign 1 33 419
new 0 33 419
assign 1 34 420
new 0 34 420
assign 1 35 421
new 0 35 421
assign 1 36 422
new 0 36 422
addValue 1 40 426
assign 1 44 485
def 1 44 490
assign 1 45 491
libNameGet 0 45 491
assign 1 45 492
relEmitName 1 45 492
assign 1 45 493
extend 1 45 493
assign 1 47 496
new 0 47 496
assign 1 47 497
extend 1 47 497
assign 1 49 499
new 0 49 499
assign 1 49 500
emitNameGet 0 49 500
assign 1 49 501
addValue 1 49 501
assign 1 49 502
addValue 1 49 502
assign 1 49 503
new 0 49 503
assign 1 49 504
addValue 1 49 504
assign 1 51 505
def 1 51 510
assign 1 52 511
new 0 52 511
addValue 1 52 512
assign 1 54 513
new 0 54 513
addValue 1 54 514
assign 1 56 515
new 0 56 515
assign 1 56 516
addValue 1 56 516
assign 1 56 517
libNameGet 0 56 517
assign 1 56 518
relEmitName 1 56 518
assign 1 56 519
addValue 1 56 519
assign 1 56 520
new 0 56 520
addValue 1 56 521
assign 1 58 524
new 0 58 524
addValue 1 58 525
assign 1 60 526
new 0 60 526
addValue 1 60 527
assign 1 62 528
new 0 62 528
addValue 1 62 529
assign 1 65 531
new 0 65 531
addValue 1 65 532
assign 1 67 533
new 0 67 533
addValue 1 67 534
write 1 69 535
write 1 71 536
write 1 73 537
clear 0 75 538
assign 1 77 539
new 0 77 539
write 1 77 540
assign 1 78 541
new 0 78 541
write 1 78 542
assign 1 79 543
new 0 79 543
write 1 79 544
assign 1 80 545
new 0 80 545
assign 1 80 546
emitNameGet 0 80 546
assign 1 80 547
add 1 80 547
assign 1 80 548
new 0 80 548
assign 1 80 549
add 1 80 549
assign 1 80 550
getHeaderInitialInst 1 80 550
assign 1 80 551
add 1 80 551
assign 1 80 552
new 0 80 552
assign 1 80 553
add 1 80 553
write 1 80 554
assign 1 81 555
new 0 81 555
write 1 81 556
assign 1 82 557
new 0 82 557
write 1 82 558
assign 1 83 559
new 0 83 559
write 1 83 560
assign 1 84 561
new 0 84 561
write 1 84 562
assign 1 85 563
new 0 85 563
write 1 85 564
assign 1 86 565
new 0 86 565
write 1 86 566
assign 1 87 567
new 0 87 567
write 1 87 568
assign 1 88 569
new 0 88 569
assign 1 88 570
emitNameGet 0 88 570
assign 1 88 571
add 1 88 571
assign 1 88 572
new 0 88 572
assign 1 88 573
add 1 88 573
write 1 88 574
assign 1 90 575
new 0 90 575
assign 1 90 576
emitNameGet 0 90 576
assign 1 90 577
add 1 90 577
assign 1 90 578
new 0 90 578
assign 1 90 579
add 1 90 579
write 1 90 580
assign 1 92 581
new 0 92 581
return 1 92 582
assign 1 96 612
overrideMtdDecGet 0 96 612
assign 1 96 613
addValue 1 96 613
assign 1 96 614
getClassConfig 1 96 614
assign 1 96 615
libNameGet 0 96 615
assign 1 96 616
relEmitName 1 96 616
assign 1 96 617
addValue 1 96 617
assign 1 96 618
new 0 96 618
assign 1 96 619
addValue 1 96 619
assign 1 96 620
emitNameGet 0 96 620
assign 1 96 621
addValue 1 96 621
assign 1 96 622
new 0 96 622
assign 1 96 623
addValue 1 96 623
assign 1 96 624
addValue 1 96 624
assign 1 96 625
new 0 96 625
assign 1 96 626
addValue 1 96 626
addValue 1 96 627
assign 1 97 628
new 0 97 628
assign 1 97 629
addValue 1 97 629
assign 1 97 630
heldGet 0 97 630
assign 1 97 631
namepathGet 0 97 631
assign 1 97 632
getClassConfig 1 97 632
assign 1 97 633
libNameGet 0 97 633
assign 1 97 634
relEmitName 1 97 634
assign 1 97 635
addValue 1 97 635
assign 1 97 636
new 0 97 636
assign 1 97 637
addValue 1 97 637
addValue 1 97 638
assign 1 99 639
new 0 99 639
assign 1 99 640
addValue 1 99 640
addValue 1 99 641
assign 1 103 647
new 0 103 647
write 1 105 648
clear 0 106 649
assign 1 107 650
new 0 107 650
write 1 107 651
return 1 108 652
assign 1 112 656
new 0 112 656
return 1 112 657
assign 1 116 661
new 0 116 661
return 1 116 662
assign 1 120 666
new 0 120 666
return 1 120 667
assign 1 125 697
addValue 1 125 697
assign 1 125 698
libNameGet 0 125 698
assign 1 125 699
relEmitName 1 125 699
assign 1 125 700
addValue 1 125 700
assign 1 125 701
new 0 125 701
assign 1 125 702
addValue 1 125 702
assign 1 125 703
emitNameGet 0 125 703
assign 1 125 704
addValue 1 125 704
assign 1 125 705
new 0 125 705
assign 1 125 706
addValue 1 125 706
assign 1 125 707
addValue 1 125 707
assign 1 125 708
new 0 125 708
addValue 1 125 709
addValue 1 127 710
assign 1 129 711
new 0 129 711
assign 1 129 712
addValue 1 129 712
assign 1 129 713
addValue 1 129 713
assign 1 129 714
new 0 129 714
assign 1 129 715
addValue 1 129 715
addValue 1 129 716
assign 1 131 717
new 0 131 717
assign 1 131 718
addValue 1 131 718
assign 1 131 719
libNameGet 0 131 719
assign 1 131 720
relEmitName 1 131 720
assign 1 131 721
addValue 1 131 721
assign 1 131 722
new 0 131 722
assign 1 131 723
addValue 1 131 723
assign 1 131 724
addValue 1 131 724
assign 1 131 725
new 0 131 725
addValue 1 131 726
addValue 1 133 727
assign 1 135 728
new 0 135 728
addValue 1 135 729
assign 1 141 746
typenameGet 0 141 746
assign 1 141 747
NULLGet 0 141 747
assign 1 141 748
equals 1 141 753
assign 1 142 754
new 0 142 754
assign 1 143 757
heldGet 0 143 757
assign 1 143 758
nameGet 0 143 758
assign 1 143 759
new 0 143 759
assign 1 143 760
equals 1 143 760
assign 1 144 762
new 0 144 762
assign 1 145 765
heldGet 0 145 765
assign 1 145 766
nameGet 0 145 766
assign 1 145 767
new 0 145 767
assign 1 145 768
equals 1 145 768
assign 1 146 770
new 0 146 770
assign 1 148 773
heldGet 0 148 773
assign 1 148 774
nameForVar 1 148 774
return 1 150 778
assign 1 154 788
heldGet 0 154 788
assign 1 154 789
nameGet 0 154 789
assign 1 154 790
new 0 154 790
assign 1 154 791
equals 1 154 791
assign 1 155 793
new 0 155 793
assign 1 155 794
add 1 155 794
return 1 156 795
assign 1 158 797
formCallTarg 1 158 797
return 1 158 798
assign 1 162 808
new 0 162 808
assign 1 162 809
addValue 1 162 809
assign 1 162 810
secondGet 0 162 810
assign 1 162 811
formTarg 1 162 811
assign 1 162 812
addValue 1 162 812
assign 1 162 813
new 0 162 813
assign 1 162 814
addValue 1 162 814
addValue 1 162 815
assign 1 166 825
heldGet 0 166 825
assign 1 166 826
langsGet 0 166 826
assign 1 166 827
new 0 166 827
assign 1 166 828
has 1 166 828
assign 1 167 830
heldGet 0 167 830
assign 1 167 831
textGet 0 167 831
addValue 1 167 832
handleClassEmit 1 169 835
assign 1 175 877
new 0 175 877
assign 1 175 878
emitNameGet 0 175 878
assign 1 175 879
add 1 175 879
assign 1 175 880
new 0 175 880
assign 1 175 881
add 1 175 881
assign 1 177 882
new 0 177 882
assign 1 177 883
typeEmitNameGet 0 177 883
assign 1 177 884
add 1 177 884
assign 1 177 885
new 0 177 885
assign 1 177 886
add 1 177 886
assign 1 177 887
add 1 177 887
assign 1 177 888
new 0 177 888
assign 1 177 889
add 1 177 889
addClassHeader 1 179 890
assign 1 181 891
new 0 181 891
assign 1 183 892
typeEmitNameGet 0 183 892
assign 1 183 893
addValue 1 183 893
assign 1 183 894
new 0 183 894
assign 1 183 895
addValue 1 183 895
assign 1 183 896
emitNameGet 0 183 896
assign 1 183 897
addValue 1 183 897
assign 1 183 898
new 0 183 898
assign 1 183 899
addValue 1 183 899
assign 1 183 900
addValue 1 183 900
assign 1 183 901
new 0 183 901
addValue 1 183 902
assign 1 185 903
new 0 185 903
assign 1 185 904
addValue 1 185 904
assign 1 185 905
typeEmitNameGet 0 185 905
assign 1 185 906
addValue 1 185 906
assign 1 185 907
new 0 185 907
assign 1 185 908
addValue 1 185 908
assign 1 185 909
emitNameGet 0 185 909
assign 1 185 910
addValue 1 185 910
assign 1 185 911
new 0 185 911
assign 1 185 912
emitNameGet 0 185 912
assign 1 185 913
add 1 185 913
assign 1 185 914
new 0 185 914
assign 1 185 915
add 1 185 915
addValue 1 185 916
return 1 187 917
assign 1 192 937
new 0 192 937
assign 1 192 938
toString 0 192 938
assign 1 192 939
add 1 192 939
incrementValue 0 193 940
assign 1 194 941
new 0 194 941
assign 1 194 942
addValue 1 194 942
assign 1 194 943
addValue 1 194 943
assign 1 194 944
new 0 194 944
assign 1 194 945
addValue 1 194 945
addValue 1 194 946
assign 1 196 947
containedGet 0 196 947
assign 1 196 948
firstGet 0 196 948
assign 1 196 949
containedGet 0 196 949
assign 1 196 950
firstGet 0 196 950
assign 1 196 951
new 0 196 951
assign 1 196 952
add 1 196 952
assign 1 196 953
new 0 196 953
assign 1 196 954
add 1 196 954
assign 1 196 955
finalAssign 4 196 955
addValue 1 196 956
assign 1 200 972
isTypedGet 0 200 972
assign 1 200 973
not 0 200 978
assign 1 201 979
libNameGet 0 201 979
assign 1 201 980
relEmitName 1 201 980
assign 1 201 981
addValue 1 201 981
assign 1 201 982
new 0 201 982
addValue 1 201 983
assign 1 203 986
namepathGet 0 203 986
assign 1 203 987
getClassConfig 1 203 987
assign 1 203 988
libNameGet 0 203 988
assign 1 203 989
relEmitName 1 203 989
assign 1 203 990
addValue 1 203 990
assign 1 203 991
new 0 203 991
addValue 1 203 992
assign 1 208 1007
new 0 208 1007
assign 1 208 1008
equals 1 208 1008
assign 1 209 1010
new 0 209 1010
assign 1 211 1013
new 0 211 1013
assign 1 213 1015
new 0 213 1015
assign 1 213 1016
add 1 213 1016
assign 1 213 1017
libNameGet 0 213 1017
assign 1 213 1018
relEmitName 1 213 1018
assign 1 213 1019
add 1 213 1019
assign 1 213 1020
new 0 213 1020
assign 1 213 1021
add 1 213 1021
return 1 213 1022
assign 1 218 1026
new 0 218 1026
return 1 218 1027
assign 1 222 1054
overrideMtdDecGet 0 222 1054
assign 1 222 1055
addValue 1 222 1055
assign 1 222 1056
new 0 222 1056
assign 1 222 1057
addValue 1 222 1057
assign 1 222 1058
emitNameGet 0 222 1058
assign 1 222 1059
addValue 1 222 1059
assign 1 222 1060
new 0 222 1060
assign 1 222 1061
addValue 1 222 1061
assign 1 222 1062
addValue 1 222 1062
assign 1 222 1063
new 0 222 1063
assign 1 222 1064
addValue 1 222 1064
assign 1 222 1065
addValue 1 222 1065
assign 1 222 1066
new 0 222 1066
assign 1 222 1067
addValue 1 222 1067
addValue 1 222 1068
assign 1 223 1069
new 0 223 1069
assign 1 223 1070
addValue 1 223 1070
assign 1 223 1071
addValue 1 223 1071
assign 1 223 1072
new 0 223 1072
assign 1 223 1073
addValue 1 223 1073
assign 1 223 1074
addValue 1 223 1074
assign 1 223 1075
new 0 223 1075
assign 1 223 1076
addValue 1 223 1076
addValue 1 223 1077
assign 1 225 1078
new 0 225 1078
assign 1 225 1079
addValue 1 225 1079
addValue 1 225 1080
assign 1 230 1130
new 0 230 1130
assign 1 230 1131
libNameGet 0 230 1131
assign 1 230 1132
relEmitName 1 230 1132
assign 1 230 1133
add 1 230 1133
assign 1 230 1134
new 0 230 1134
assign 1 230 1135
add 1 230 1135
assign 1 230 1136
heldGet 0 230 1136
assign 1 230 1137
literalValueGet 0 230 1137
assign 1 230 1138
add 1 230 1138
assign 1 230 1139
new 0 230 1139
assign 1 230 1140
add 1 230 1140
return 1 230 1141
assign 1 232 1143
emitChecksGet 0 232 1143
assign 1 232 1144
new 0 232 1144
assign 1 232 1145
has 1 232 1145
assign 1 233 1147
new 0 233 1147
assign 1 233 1148
libNameGet 0 233 1148
assign 1 233 1149
relEmitName 1 233 1149
assign 1 233 1150
add 1 233 1150
assign 1 233 1151
new 0 233 1151
assign 1 233 1152
add 1 233 1152
assign 1 233 1153
libNameGet 0 233 1153
assign 1 233 1154
relEmitName 1 233 1154
assign 1 233 1155
add 1 233 1155
assign 1 233 1156
new 0 233 1156
assign 1 233 1157
add 1 233 1157
assign 1 233 1158
heldGet 0 233 1158
assign 1 233 1159
literalValueGet 0 233 1159
assign 1 233 1160
add 1 233 1160
assign 1 233 1161
new 0 233 1161
assign 1 233 1162
add 1 233 1162
assign 1 235 1165
new 0 235 1165
assign 1 235 1166
libNameGet 0 235 1166
assign 1 235 1167
relEmitName 1 235 1167
assign 1 235 1168
add 1 235 1168
assign 1 235 1169
new 0 235 1169
assign 1 235 1170
add 1 235 1170
assign 1 235 1171
libNameGet 0 235 1171
assign 1 235 1172
relEmitName 1 235 1172
assign 1 235 1173
add 1 235 1173
assign 1 235 1174
new 0 235 1174
assign 1 235 1175
add 1 235 1175
assign 1 235 1176
heldGet 0 235 1176
assign 1 235 1177
literalValueGet 0 235 1177
assign 1 235 1178
add 1 235 1178
assign 1 235 1179
new 0 235 1179
assign 1 235 1180
add 1 235 1180
return 1 237 1182
assign 1 242 1231
new 0 242 1231
assign 1 242 1232
libNameGet 0 242 1232
assign 1 242 1233
relEmitName 1 242 1233
assign 1 242 1234
add 1 242 1234
assign 1 242 1235
new 0 242 1235
assign 1 242 1236
add 1 242 1236
assign 1 242 1237
heldGet 0 242 1237
assign 1 242 1238
literalValueGet 0 242 1238
assign 1 242 1239
add 1 242 1239
assign 1 242 1240
new 0 242 1240
assign 1 242 1241
add 1 242 1241
return 1 242 1242
assign 1 244 1244
emitChecksGet 0 244 1244
assign 1 244 1245
new 0 244 1245
assign 1 244 1246
has 1 244 1246
assign 1 245 1248
new 0 245 1248
assign 1 245 1249
libNameGet 0 245 1249
assign 1 245 1250
relEmitName 1 245 1250
assign 1 245 1251
add 1 245 1251
assign 1 245 1252
new 0 245 1252
assign 1 245 1253
add 1 245 1253
assign 1 245 1254
libNameGet 0 245 1254
assign 1 245 1255
relEmitName 1 245 1255
assign 1 245 1256
add 1 245 1256
assign 1 245 1257
new 0 245 1257
assign 1 245 1258
add 1 245 1258
assign 1 245 1259
heldGet 0 245 1259
assign 1 245 1260
literalValueGet 0 245 1260
assign 1 245 1261
add 1 245 1261
assign 1 245 1262
new 0 245 1262
assign 1 245 1263
add 1 245 1263
assign 1 247 1266
new 0 247 1266
assign 1 247 1267
libNameGet 0 247 1267
assign 1 247 1268
relEmitName 1 247 1268
assign 1 247 1269
add 1 247 1269
assign 1 247 1270
new 0 247 1270
assign 1 247 1271
add 1 247 1271
assign 1 247 1272
libNameGet 0 247 1272
assign 1 247 1273
relEmitName 1 247 1273
assign 1 247 1274
add 1 247 1274
assign 1 247 1275
new 0 247 1275
assign 1 247 1276
add 1 247 1276
assign 1 247 1277
heldGet 0 247 1277
assign 1 247 1278
literalValueGet 0 247 1278
assign 1 247 1279
add 1 247 1279
assign 1 247 1280
new 0 247 1280
assign 1 247 1281
add 1 247 1281
return 1 249 1283
assign 1 254 1334
new 0 254 1334
assign 1 254 1335
libNameGet 0 254 1335
assign 1 254 1336
relEmitName 1 254 1336
assign 1 254 1337
add 1 254 1337
assign 1 254 1338
new 0 254 1338
assign 1 254 1339
add 1 254 1339
assign 1 254 1340
add 1 254 1340
assign 1 254 1341
new 0 254 1341
assign 1 254 1342
add 1 254 1342
assign 1 254 1343
add 1 254 1343
assign 1 254 1344
new 0 254 1344
assign 1 254 1345
add 1 254 1345
return 1 254 1346
assign 1 257 1348
new 0 257 1348
assign 1 257 1349
add 1 257 1349
assign 1 257 1350
new 0 257 1350
assign 1 257 1351
add 1 257 1351
assign 1 257 1352
add 1 257 1352
assign 1 258 1353
emitChecksGet 0 258 1353
assign 1 258 1354
new 0 258 1354
assign 1 258 1355
has 1 258 1355
assign 1 259 1357
new 0 259 1357
assign 1 259 1358
libNameGet 0 259 1358
assign 1 259 1359
relEmitName 1 259 1359
assign 1 259 1360
add 1 259 1360
assign 1 259 1361
new 0 259 1361
assign 1 259 1362
add 1 259 1362
assign 1 259 1363
libNameGet 0 259 1363
assign 1 259 1364
relEmitName 1 259 1364
assign 1 259 1365
add 1 259 1365
assign 1 259 1366
new 0 259 1366
assign 1 259 1367
add 1 259 1367
assign 1 259 1368
add 1 259 1368
assign 1 259 1369
new 0 259 1369
assign 1 259 1370
add 1 259 1370
assign 1 261 1373
new 0 261 1373
assign 1 261 1374
libNameGet 0 261 1374
assign 1 261 1375
relEmitName 1 261 1375
assign 1 261 1376
add 1 261 1376
assign 1 261 1377
new 0 261 1377
assign 1 261 1378
add 1 261 1378
assign 1 261 1379
libNameGet 0 261 1379
assign 1 261 1380
relEmitName 1 261 1380
assign 1 261 1381
add 1 261 1381
assign 1 261 1382
new 0 261 1382
assign 1 261 1383
add 1 261 1383
assign 1 261 1384
add 1 261 1384
assign 1 261 1385
new 0 261 1385
assign 1 261 1386
add 1 261 1386
return 1 263 1388
incrementValue 0 267 1400
assign 1 268 1401
new 0 268 1401
assign 1 268 1402
notEmpty 1 268 1402
assign 1 269 1404
new 0 269 1404
addValue 1 269 1405
assign 1 271 1407
new 0 271 1407
assign 1 271 1408
addValue 1 271 1408
addValue 1 271 1409
assign 1 272 1410
new 0 272 1410
assign 1 272 1411
add 1 272 1411
assign 1 272 1412
new 0 272 1412
assign 1 272 1413
add 1 272 1413
return 1 272 1414
getCode 2 277 1420
assign 1 278 1421
toHexString 1 278 1421
assign 1 279 1422
new 0 279 1422
assign 1 279 1423
once 0 279 1423
addValue 1 279 1424
addValue 1 280 1425
assign 1 286 1432
new 0 286 1432
assign 1 286 1433
add 1 286 1433
assign 1 286 1434
add 1 286 1434
return 1 286 1435
assign 1 290 1439
new 0 290 1439
return 1 290 1440
assign 1 294 1444
new 0 294 1444
return 1 294 1445
assign 1 299 1449
new 0 299 1449
return 1 299 1450
assign 1 303 1473
new 0 303 1473
assign 1 303 1474
add 1 303 1474
assign 1 303 1475
new 0 303 1475
assign 1 303 1476
add 1 303 1476
assign 1 303 1477
add 1 303 1477
assign 1 304 1478
new 0 304 1478
assign 1 304 1479
addValue 1 304 1479
assign 1 304 1480
addValue 1 304 1480
assign 1 304 1481
new 0 304 1481
assign 1 304 1482
addValue 1 304 1482
addValue 1 304 1483
assign 1 305 1484
new 0 305 1484
assign 1 305 1485
addValue 1 305 1485
addValue 1 305 1486
assign 1 306 1487
new 0 306 1487
assign 1 306 1488
addValue 1 306 1488
assign 1 306 1489
outputPlatformGet 0 306 1489
assign 1 306 1490
nameGet 0 306 1490
assign 1 306 1491
addValue 1 306 1491
assign 1 306 1492
new 0 306 1492
assign 1 306 1493
addValue 1 306 1493
addValue 1 306 1494
assign 1 308 1495
new 0 308 1495
return 1 308 1496
assign 1 312 1500
new 0 312 1500
return 1 312 1501
assign 1 316 1507
new 0 316 1507
assign 1 316 1508
once 0 316 1508
assign 1 316 1509
add 1 316 1509
return 1 316 1510
assign 1 323 1526
assign 1 324 1527
singleCCGet 0 324 1527
assign 1 0 1529
assign 1 324 1532
classPathGet 0 324 1532
assign 1 324 1533
fileGet 0 324 1533
assign 1 324 1534
existsGet 0 324 1534
assign 1 324 1535
not 0 324 1540
assign 1 0 1541
assign 1 0 1544
return 1 325 1548
assign 1 327 1551
classPathGet 0 327 1551
assign 1 327 1552
fileGet 0 327 1552
assign 1 327 1553
lastUpdatedGet 0 327 1553
assign 1 328 1554
fromFileGet 0 328 1554
assign 1 328 1555
fileGet 0 328 1555
assign 1 328 1556
lastUpdatedGet 0 328 1556
assign 1 329 1557
greater 1 329 1557
return 1 332 1559
assign 1 335 1561
assign 1 340 1569
singleCCGet 0 340 1569
assign 1 341 1571
getLibOutput 0 341 1571
return 1 341 1572
assign 1 343 1574
getClassOutput 0 343 1574
return 1 343 1575
assign 1 347 1581
singleCCGet 0 347 1581
assign 1 348 1583
new 0 348 1583
assign 1 349 1584
countLines 1 349 1584
addValue 1 349 1585
write 1 350 1586
assign 1 355 1597
singleCCGet 0 355 1597
assign 1 357 1599
new 0 357 1599
assign 1 358 1600
countLines 1 358 1600
addValue 1 358 1601
write 1 359 1602
close 0 360 1603
assign 1 361 1604
def 1 361 1609
assign 1 362 1610
pathGet 0 362 1610
assign 1 362 1611
fileGet 0 362 1611
lastUpdatedSet 1 362 1612
assign 1 363 1613
assign 1 369 1636
new 0 369 1636
assign 1 370 1637
emitChecksGet 0 370 1637
assign 1 370 1638
new 0 370 1638
assign 1 370 1639
has 1 370 1639
assign 1 371 1641
new 0 371 1641
assign 1 371 1642
addValue 1 371 1642
assign 1 371 1643
addValue 1 371 1643
assign 1 371 1644
new 0 371 1644
assign 1 371 1645
addValue 1 371 1645
assign 1 371 1646
addValue 1 371 1646
assign 1 371 1647
new 0 371 1647
assign 1 371 1648
addValue 1 371 1648
addValue 1 371 1649
assign 1 372 1650
addValue 1 372 1650
assign 1 372 1651
new 0 372 1651
assign 1 372 1652
addValue 1 372 1652
addValue 1 372 1653
assign 1 373 1654
new 0 373 1654
assign 1 373 1655
addValue 1 373 1655
addValue 1 373 1656
return 1 375 1658
assign 1 379 1772
new 0 379 1772
assign 1 379 1773
typeEmitNameGet 0 379 1773
assign 1 379 1774
add 1 379 1774
assign 1 379 1775
new 0 379 1775
assign 1 379 1776
add 1 379 1776
write 1 379 1777
assign 1 380 1778
new 0 380 1778
assign 1 381 1779
new 0 381 1779
assign 1 381 1780
addValue 1 381 1780
assign 1 381 1781
typeEmitNameGet 0 381 1781
assign 1 381 1782
addValue 1 381 1782
assign 1 381 1783
new 0 381 1783
addValue 1 381 1784
assign 1 382 1785
new 0 382 1785
addValue 1 382 1786
assign 1 383 1787
typeEmitNameGet 0 383 1787
assign 1 383 1788
addValue 1 383 1788
assign 1 383 1789
new 0 383 1789
addValue 1 383 1790
assign 1 384 1791
new 0 384 1791
addValue 1 384 1792
assign 1 385 1793
new 0 385 1793
addValue 1 385 1794
assign 1 386 1795
new 0 386 1795
assign 1 386 1796
addValue 1 386 1796
assign 1 386 1797
addValue 1 386 1797
assign 1 386 1798
new 0 386 1798
addValue 1 386 1799
assign 1 387 1800
new 0 387 1800
addValue 1 387 1801
assign 1 388 1802
new 0 388 1802
addValue 1 388 1803
assign 1 389 1804
new 0 389 1804
addValue 1 389 1805
write 1 390 1806
assign 1 392 1807
new 0 392 1807
assign 1 393 1808
typeEmitNameGet 0 393 1808
assign 1 393 1809
addValue 1 393 1809
assign 1 393 1810
new 0 393 1810
assign 1 393 1811
addValue 1 393 1811
assign 1 393 1812
typeEmitNameGet 0 393 1812
assign 1 393 1813
addValue 1 393 1813
assign 1 393 1814
new 0 393 1814
addValue 1 393 1815
assign 1 394 1816
new 0 394 1816
addValue 1 394 1817
assign 1 395 1818
new 0 395 1818
assign 1 396 1819
mtdListGet 0 396 1819
assign 1 396 1820
iteratorGet 0 0 1820
assign 1 396 1823
hasNextGet 0 396 1823
assign 1 396 1825
nextGet 0 396 1825
assign 1 398 1827
new 0 398 1827
assign 1 400 1830
new 0 400 1830
addValue 1 400 1831
assign 1 402 1833
addValue 1 402 1833
assign 1 402 1834
nameGet 0 402 1834
assign 1 402 1835
addValue 1 402 1835
addValue 1 402 1836
assign 1 404 1842
new 0 404 1842
addValue 1 404 1843
assign 1 405 1844
new 0 405 1844
addValue 1 405 1845
assign 1 407 1846
new 0 407 1846
addValue 1 407 1847
assign 1 408 1848
new 0 408 1848
assign 1 409 1849
ptyListGet 0 409 1849
assign 1 409 1850
iteratorGet 0 0 1850
assign 1 409 1853
hasNextGet 0 409 1853
assign 1 409 1855
nextGet 0 409 1855
assign 1 411 1857
new 0 411 1857
assign 1 413 1860
new 0 413 1860
addValue 1 413 1861
assign 1 415 1863
addValue 1 415 1863
assign 1 415 1864
nameGet 0 415 1864
assign 1 415 1865
addValue 1 415 1865
addValue 1 415 1866
assign 1 417 1872
new 0 417 1872
addValue 1 417 1873
assign 1 419 1874
new 0 419 1874
addValue 1 419 1875
assign 1 421 1876
new 0 421 1876
assign 1 421 1877
addValue 1 421 1877
assign 1 421 1878
typeEmitNameGet 0 421 1878
assign 1 421 1879
addValue 1 421 1879
assign 1 421 1880
new 0 421 1880
addValue 1 421 1881
assign 1 422 1882
emitNameGet 0 422 1882
assign 1 422 1883
new 0 422 1883
assign 1 422 1884
equals 1 422 1884
assign 1 423 1886
new 0 423 1886
assign 1 423 1887
addValue 1 423 1887
assign 1 423 1888
emitNameGet 0 423 1888
assign 1 423 1889
addValue 1 423 1889
assign 1 423 1890
new 0 423 1890
addValue 1 423 1891
assign 1 425 1894
new 0 425 1894
assign 1 425 1895
addValue 1 425 1895
assign 1 425 1896
emitNameGet 0 425 1896
assign 1 425 1897
addValue 1 425 1897
assign 1 425 1898
new 0 425 1898
addValue 1 425 1899
assign 1 427 1901
new 0 427 1901
addValue 1 427 1902
assign 1 429 1903
new 0 429 1903
assign 1 429 1904
addValue 1 429 1904
assign 1 429 1905
typeEmitNameGet 0 429 1905
assign 1 429 1906
addValue 1 429 1906
assign 1 429 1907
new 0 429 1907
addValue 1 429 1908
assign 1 430 1909
new 0 430 1909
addValue 1 430 1910
assign 1 431 1911
new 0 431 1911
assign 1 431 1912
genMark 1 431 1912
addValue 1 431 1913
assign 1 432 1914
new 0 432 1914
addValue 1 432 1915
assign 1 433 1916
new 0 433 1916
addValue 1 433 1917
assign 1 434 1918
new 0 434 1918
assign 1 434 1919
genMark 1 434 1919
addValue 1 434 1920
assign 1 435 1921
new 0 435 1921
addValue 1 435 1922
assign 1 436 1923
new 0 436 1923
addValue 1 436 1924
assign 1 438 1925
new 0 438 1925
assign 1 438 1926
addValue 1 438 1926
assign 1 438 1927
typeEmitNameGet 0 438 1927
assign 1 438 1928
addValue 1 438 1928
assign 1 438 1929
new 0 438 1929
assign 1 438 1930
addValue 1 438 1930
assign 1 438 1931
addValue 1 438 1931
assign 1 438 1932
new 0 438 1932
assign 1 438 1933
addValue 1 438 1933
assign 1 438 1934
addValue 1 438 1934
assign 1 438 1935
new 0 438 1935
assign 1 438 1936
addValue 1 438 1936
addValue 1 438 1937
assign 1 439 1938
new 0 439 1938
assign 1 439 1939
addValue 1 439 1939
assign 1 439 1940
typeEmitNameGet 0 439 1940
assign 1 439 1941
addValue 1 439 1941
assign 1 439 1942
new 0 439 1942
assign 1 439 1943
addValue 1 439 1943
assign 1 439 1944
addValue 1 439 1944
assign 1 439 1945
new 0 439 1945
addValue 1 439 1946
clear 0 440 1947
assign 1 441 1948
new 0 441 1948
assign 1 443 1949
getClassOutput 0 443 1949
write 1 443 1950
assign 1 444 1951
countLines 1 444 1951
addValue 1 444 1952
assign 1 456 2025
undef 1 456 2030
assign 1 457 2031
libNameGet 0 457 2031
assign 1 458 2032
new 0 458 2032
assign 1 458 2033
sizeGet 0 458 2033
assign 1 458 2034
add 1 458 2034
assign 1 458 2035
new 0 458 2035
assign 1 458 2036
add 1 458 2036
assign 1 458 2037
add 1 458 2037
assign 1 458 2038
add 1 458 2038
assign 1 459 2039
new 0 459 2039
assign 1 459 2040
sizeGet 0 459 2040
assign 1 459 2041
add 1 459 2041
assign 1 459 2042
new 0 459 2042
assign 1 459 2043
add 1 459 2043
assign 1 459 2044
add 1 459 2044
assign 1 459 2045
add 1 459 2045
assign 1 460 2046
parentGet 0 460 2046
assign 1 460 2047
addStep 1 460 2047
assign 1 461 2048
parentGet 0 461 2048
assign 1 461 2049
addStep 1 461 2049
assign 1 462 2050
parentGet 0 462 2050
assign 1 462 2051
fileGet 0 462 2051
assign 1 462 2052
existsGet 0 462 2052
assign 1 462 2053
not 0 462 2058
assign 1 463 2059
parentGet 0 463 2059
assign 1 463 2060
fileGet 0 463 2060
makeDirs 0 463 2061
assign 1 465 2063
fileGet 0 465 2063
assign 1 465 2064
writerGet 0 465 2064
assign 1 465 2065
open 0 465 2065
assign 1 466 2066
fileGet 0 466 2066
assign 1 466 2067
writerGet 0 466 2067
assign 1 466 2068
open 0 466 2068
assign 1 468 2069
paramsGet 0 468 2069
assign 1 468 2070
new 0 468 2070
assign 1 468 2071
has 1 468 2071
assign 1 470 2073
paramsGet 0 470 2073
assign 1 470 2074
new 0 470 2074
assign 1 470 2075
get 1 470 2075
assign 1 470 2076
iteratorGet 0 0 2076
assign 1 470 2079
hasNextGet 0 470 2079
assign 1 470 2081
nextGet 0 470 2081
assign 1 472 2082
apNew 1 472 2082
assign 1 472 2083
fileGet 0 472 2083
assign 1 473 2084
readerGet 0 473 2084
assign 1 473 2085
open 0 473 2085
assign 1 473 2086
readString 0 473 2086
assign 1 474 2087
readerGet 0 474 2087
close 0 474 2088
write 1 476 2089
assign 1 480 2096
new 0 480 2096
write 1 480 2097
assign 1 481 2098
new 0 481 2098
write 1 481 2099
assign 1 483 2100
new 0 483 2100
write 1 483 2101
assign 1 484 2102
new 0 484 2102
write 1 484 2103
assign 1 490 2104
paramsGet 0 490 2104
assign 1 490 2105
new 0 490 2105
assign 1 490 2106
has 1 490 2106
assign 1 492 2108
paramsGet 0 492 2108
assign 1 492 2109
new 0 492 2109
assign 1 492 2110
get 1 492 2110
assign 1 492 2111
iteratorGet 0 0 2111
assign 1 492 2114
hasNextGet 0 492 2114
assign 1 492 2116
nextGet 0 492 2116
assign 1 494 2117
apNew 1 494 2117
assign 1 494 2118
fileGet 0 494 2118
assign 1 495 2119
readerGet 0 495 2119
assign 1 495 2120
open 0 495 2120
assign 1 495 2121
readString 0 495 2121
assign 1 496 2122
readerGet 0 496 2122
close 0 496 2123
write 1 498 2124
assign 1 501 2131
paramsGet 0 501 2131
assign 1 501 2132
new 0 501 2132
assign 1 501 2133
has 1 501 2133
assign 1 503 2135
paramsGet 0 503 2135
assign 1 503 2136
new 0 503 2136
assign 1 503 2137
get 1 503 2137
assign 1 503 2138
iteratorGet 0 0 2138
assign 1 503 2141
hasNextGet 0 503 2141
assign 1 503 2143
nextGet 0 503 2143
assign 1 505 2144
apNew 1 505 2144
assign 1 505 2145
fileGet 0 505 2145
assign 1 506 2146
readerGet 0 506 2146
assign 1 506 2147
open 0 506 2147
assign 1 506 2148
readString 0 506 2148
assign 1 507 2149
readerGet 0 507 2149
close 0 507 2150
write 1 509 2151
begin 1 516 2162
prepHeaderOutput 0 517 2163
assign 1 522 2206
undef 1 522 2211
assign 1 523 2212
new 0 523 2212
assign 1 524 2213
parentGet 0 524 2213
assign 1 524 2214
fileGet 0 524 2214
assign 1 524 2215
existsGet 0 524 2215
assign 1 524 2216
not 0 524 2221
assign 1 525 2222
parentGet 0 525 2222
assign 1 525 2223
fileGet 0 525 2223
makeDirs 0 525 2224
assign 1 527 2226
fileGet 0 527 2226
assign 1 527 2227
writerGet 0 527 2227
assign 1 527 2228
open 0 527 2228
assign 1 529 2229
new 0 529 2229
write 1 529 2230
assign 1 531 2231
paramsGet 0 531 2231
assign 1 531 2232
new 0 531 2232
assign 1 531 2233
has 1 531 2233
assign 1 533 2235
paramsGet 0 533 2235
assign 1 533 2236
new 0 533 2236
assign 1 533 2237
get 1 533 2237
assign 1 533 2238
iteratorGet 0 0 2238
assign 1 533 2241
hasNextGet 0 533 2241
assign 1 533 2243
nextGet 0 533 2243
assign 1 535 2244
apNew 1 535 2244
assign 1 535 2245
fileGet 0 535 2245
assign 1 536 2246
readerGet 0 536 2246
assign 1 536 2247
open 0 536 2247
assign 1 536 2248
readString 0 536 2248
assign 1 537 2249
readerGet 0 537 2249
close 0 537 2250
write 1 539 2251
assign 1 543 2258
new 0 543 2258
write 1 543 2259
increment 0 544 2260
assign 1 545 2261
paramsGet 0 545 2261
assign 1 545 2262
new 0 545 2262
assign 1 545 2263
has 1 545 2263
assign 1 546 2265
paramsGet 0 546 2265
assign 1 546 2266
new 0 546 2266
assign 1 546 2267
get 1 546 2267
assign 1 546 2268
iteratorGet 0 0 2268
assign 1 546 2271
hasNextGet 0 546 2271
assign 1 546 2273
nextGet 0 546 2273
assign 1 547 2274
apNew 1 547 2274
assign 1 547 2275
fileGet 0 547 2275
assign 1 548 2276
readerGet 0 548 2276
assign 1 548 2277
open 0 548 2277
assign 1 548 2278
readString 0 548 2278
assign 1 549 2279
readerGet 0 549 2279
close 0 549 2280
assign 1 550 2281
countLines 1 550 2281
addValue 1 550 2282
write 1 551 2283
return 1 557 2291
close 0 562 2302
assign 1 563 2303
assign 1 565 2304
new 0 565 2304
write 1 565 2305
assign 1 567 2306
new 0 567 2306
write 1 567 2307
assign 1 569 2308
emitChecksGet 0 569 2308
assign 1 569 2309
new 0 569 2309
assign 1 569 2310
has 1 569 2310
assign 1 570 2312
new 0 570 2312
assign 1 571 2313
new 0 571 2313
assign 1 571 2314
addValue 1 571 2314
addValue 1 571 2315
write 1 572 2316
close 0 575 2318
close 0 576 2319
assign 1 581 2324
new 0 581 2324
return 1 581 2325
assign 1 585 2342
emitChecksGet 0 585 2342
assign 1 585 2343
new 0 585 2343
assign 1 585 2344
has 1 585 2344
assign 1 586 2346
new 0 586 2346
assign 1 586 2347
addValue 1 586 2347
assign 1 586 2348
addValue 1 586 2348
assign 1 586 2349
new 0 586 2349
addValue 1 586 2350
assign 1 587 2353
emitChecksGet 0 587 2353
assign 1 587 2354
new 0 587 2354
assign 1 587 2355
has 1 587 2355
assign 1 588 2357
new 0 588 2357
assign 1 588 2358
addValue 1 588 2358
assign 1 588 2359
addValue 1 588 2359
assign 1 588 2360
new 0 588 2360
addValue 1 588 2361
assign 1 594 2385
heldGet 0 594 2385
assign 1 594 2386
synGet 0 594 2386
assign 1 595 2387
ptyListGet 0 595 2387
assign 1 597 2388
emitNameGet 0 597 2388
assign 1 597 2389
addValue 1 597 2389
assign 1 597 2390
new 0 597 2390
addValue 1 597 2391
assign 1 599 2392
new 0 599 2392
assign 1 600 2393
iteratorGet 0 0 2393
assign 1 600 2396
hasNextGet 0 600 2396
assign 1 600 2398
nextGet 0 600 2398
assign 1 602 2400
new 0 602 2400
assign 1 604 2403
new 0 604 2403
addValue 1 604 2404
assign 1 606 2406
addValue 1 606 2406
assign 1 606 2407
new 0 606 2407
assign 1 606 2408
addValue 1 606 2408
assign 1 606 2409
nameGet 0 606 2409
assign 1 606 2410
addValue 1 606 2410
addValue 1 606 2411
assign 1 610 2417
new 0 610 2417
assign 1 610 2418
addValue 1 610 2418
addValue 1 610 2419
assign 1 615 2439
new 0 615 2439
assign 1 617 2440
new 0 617 2440
assign 1 617 2441
emitNameGet 0 617 2441
assign 1 617 2442
add 1 617 2442
assign 1 617 2443
new 0 617 2443
assign 1 617 2444
add 1 617 2444
assign 1 619 2445
emitNameGet 0 619 2445
assign 1 619 2446
addValue 1 619 2446
assign 1 619 2447
new 0 619 2447
assign 1 619 2448
addValue 1 619 2448
assign 1 619 2449
emitNameGet 0 619 2449
assign 1 619 2450
addValue 1 619 2450
assign 1 619 2451
new 0 619 2451
assign 1 619 2452
addValue 1 619 2452
assign 1 619 2453
addValue 1 619 2453
assign 1 619 2454
new 0 619 2454
addValue 1 619 2455
return 1 621 2456
assign 1 625 2465
libNameGet 0 625 2465
assign 1 625 2466
relEmitName 1 625 2466
assign 1 626 2467
new 0 626 2467
assign 1 626 2468
add 1 626 2468
assign 1 626 2469
new 0 626 2469
assign 1 626 2470
add 1 626 2470
return 1 627 2471
assign 1 631 2483
libNameGet 0 631 2483
assign 1 631 2484
relEmitName 1 631 2484
assign 1 632 2485
new 0 632 2485
assign 1 632 2486
add 1 632 2486
assign 1 632 2487
new 0 632 2487
assign 1 632 2488
add 1 632 2488
assign 1 633 2489
new 0 633 2489
assign 1 633 2490
add 1 633 2490
assign 1 633 2491
add 1 633 2491
return 1 633 2492
assign 1 637 2497
new 0 637 2497
assign 1 637 2498
add 1 637 2498
return 1 637 2499
assign 1 641 2607
getClassConfig 1 641 2607
assign 1 641 2608
libNameGet 0 641 2608
assign 1 641 2609
relEmitName 1 641 2609
assign 1 642 2610
heldGet 0 642 2610
assign 1 642 2611
namepathGet 0 642 2611
assign 1 642 2612
getClassConfig 1 642 2612
assign 1 643 2613
getInitialInst 1 643 2613
assign 1 645 2614
overrideMtdDecGet 0 645 2614
assign 1 645 2615
addValue 1 645 2615
assign 1 645 2616
new 0 645 2616
assign 1 645 2617
addValue 1 645 2617
assign 1 645 2618
emitNameGet 0 645 2618
assign 1 645 2619
addValue 1 645 2619
assign 1 645 2620
new 0 645 2620
assign 1 645 2621
addValue 1 645 2621
assign 1 645 2622
addValue 1 645 2622
assign 1 645 2623
new 0 645 2623
assign 1 645 2624
addValue 1 645 2624
assign 1 645 2625
addValue 1 645 2625
assign 1 645 2626
new 0 645 2626
assign 1 645 2627
addValue 1 645 2627
addValue 1 645 2628
assign 1 646 2629
new 0 646 2629
assign 1 647 2630
emitNameGet 0 647 2630
assign 1 647 2631
notEquals 1 647 2631
assign 1 648 2633
new 0 648 2633
assign 1 648 2634
formCast 3 648 2634
assign 1 651 2636
addValue 1 651 2636
assign 1 651 2637
new 0 651 2637
assign 1 651 2638
addValue 1 651 2638
assign 1 651 2639
addValue 1 651 2639
assign 1 651 2640
new 0 651 2640
assign 1 651 2641
addValue 1 651 2641
addValue 1 651 2642
assign 1 653 2643
new 0 653 2643
assign 1 653 2644
addValue 1 653 2644
addValue 1 653 2645
assign 1 656 2646
overrideMtdDecGet 0 656 2646
assign 1 656 2647
addValue 1 656 2647
assign 1 656 2648
addValue 1 656 2648
assign 1 656 2649
new 0 656 2649
assign 1 656 2650
addValue 1 656 2650
assign 1 656 2651
emitNameGet 0 656 2651
assign 1 656 2652
addValue 1 656 2652
assign 1 656 2653
new 0 656 2653
assign 1 656 2654
addValue 1 656 2654
assign 1 656 2655
addValue 1 656 2655
assign 1 656 2656
new 0 656 2656
assign 1 656 2657
addValue 1 656 2657
addValue 1 656 2658
assign 1 661 2659
new 0 661 2659
assign 1 661 2660
addValue 1 661 2660
assign 1 661 2661
addValue 1 661 2661
assign 1 661 2662
new 0 661 2662
assign 1 661 2663
addValue 1 661 2663
addValue 1 661 2664
assign 1 664 2665
new 0 664 2665
assign 1 664 2666
addValue 1 664 2666
addValue 1 664 2667
assign 1 666 2668
overrideMtdDecGet 0 666 2668
assign 1 666 2669
addValue 1 666 2669
assign 1 666 2670
new 0 666 2670
assign 1 666 2671
addValue 1 666 2671
assign 1 666 2672
emitNameGet 0 666 2672
assign 1 666 2673
addValue 1 666 2673
assign 1 666 2674
new 0 666 2674
assign 1 666 2675
addValue 1 666 2675
assign 1 666 2676
addValue 1 666 2676
assign 1 666 2677
new 0 666 2677
assign 1 666 2678
addValue 1 666 2678
addValue 1 666 2679
assign 1 667 2680
heldGet 0 667 2680
assign 1 667 2681
extendsGet 0 667 2681
assign 1 667 2682
undef 1 667 2687
assign 1 0 2688
assign 1 667 2691
heldGet 0 667 2691
assign 1 667 2692
extendsGet 0 667 2692
assign 1 667 2693
equals 1 667 2693
assign 1 0 2695
assign 1 0 2698
assign 1 668 2702
new 0 668 2702
assign 1 668 2703
addValue 1 668 2703
addValue 1 668 2704
assign 1 670 2707
new 0 670 2707
assign 1 670 2708
addValue 1 670 2708
addValue 1 670 2709
addValue 1 672 2711
clear 0 673 2712
assign 1 676 2713
new 0 676 2713
assign 1 676 2714
addValue 1 676 2714
addValue 1 676 2715
assign 1 678 2716
overrideMtdDecGet 0 678 2716
assign 1 678 2717
addValue 1 678 2717
assign 1 678 2718
new 0 678 2718
assign 1 678 2719
addValue 1 678 2719
assign 1 678 2720
emitNameGet 0 678 2720
assign 1 678 2721
addValue 1 678 2721
assign 1 678 2722
new 0 678 2722
assign 1 678 2723
addValue 1 678 2723
assign 1 678 2724
addValue 1 678 2724
assign 1 678 2725
new 0 678 2725
assign 1 678 2726
addValue 1 678 2726
addValue 1 678 2727
assign 1 679 2728
new 0 679 2728
assign 1 679 2729
addValue 1 679 2729
addValue 1 679 2730
assign 1 681 2731
new 0 681 2731
assign 1 681 2732
addValue 1 681 2732
addValue 1 681 2733
assign 1 683 2734
getTypeInst 1 683 2734
assign 1 685 2735
new 0 685 2735
assign 1 685 2736
addValue 1 685 2736
assign 1 685 2737
emitNameGet 0 685 2737
assign 1 685 2738
addValue 1 685 2738
assign 1 685 2739
new 0 685 2739
assign 1 685 2740
addValue 1 685 2740
addValue 1 685 2741
assign 1 687 2742
new 0 687 2742
assign 1 687 2743
addValue 1 687 2743
assign 1 687 2744
addValue 1 687 2744
assign 1 687 2745
new 0 687 2745
assign 1 687 2746
addValue 1 687 2746
addValue 1 687 2747
assign 1 689 2748
new 0 689 2748
assign 1 689 2749
addValue 1 689 2749
addValue 1 689 2750
assign 1 695 2756
new 0 695 2756
write 1 695 2757
assign 1 696 2758
new 0 696 2758
write 1 696 2759
emitLib 0 698 2760
assign 1 703 2773
libNameGet 0 703 2773
assign 1 703 2774
relEmitName 1 703 2774
assign 1 704 2775
new 0 704 2775
assign 1 704 2776
add 1 704 2776
assign 1 704 2777
new 0 704 2777
assign 1 704 2778
add 1 704 2778
assign 1 705 2779
new 0 705 2779
assign 1 705 2780
add 1 705 2780
assign 1 705 2781
add 1 705 2781
return 1 705 2782
return 1 0 2785
return 1 0 2788
assign 1 0 2791
assign 1 0 2795
return 1 0 2799
return 1 0 2802
assign 1 0 2805
assign 1 0 2809
return 1 0 2813
return 1 0 2816
assign 1 0 2819
assign 1 0 2823
return 1 0 2827
return 1 0 2830
assign 1 0 2833
assign 1 0 2837
return 1 0 2841
return 1 0 2844
assign 1 0 2847
assign 1 0 2851
return 1 0 2855
return 1 0 2858
assign 1 0 2861
assign 1 0 2865
return 1 0 2869
return 1 0 2872
assign 1 0 2875
assign 1 0 2879
return 1 0 2883
return 1 0 2886
assign 1 0 2889
assign 1 0 2893
return 1 0 2897
return 1 0 2900
assign 1 0 2903
assign 1 0 2907
return 1 0 2911
return 1 0 2914
assign 1 0 2917
assign 1 0 2921
return 1 0 2925
return 1 0 2928
assign 1 0 2931
assign 1 0 2935
return 1 0 2939
return 1 0 2942
assign 1 0 2945
assign 1 0 2949
return 1 0 2953
return 1 0 2956
assign 1 0 2959
assign 1 0 2963
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1223957181: return bem_heowGet_0();
case 1521176891: return bem_mnodeGet_0();
case 591544491: return bem_mainEndGet_0();
case 1892317725: return bem_heopGetDirect_0();
case 1236464998: return bem_serializeContents_0();
case 580994536: return bem_methodCatchGet_0();
case 262662455: return bem_returnTypeGetDirect_0();
case -1141209554: return bem_methodCallsGet_0();
case 1444888150: return bem_lastMethodsSizeGet_0();
case 1748554419: return bem_instOfGet_0();
case -931510105: return bem_onceCountGetDirect_0();
case 796921760: return bem_falseValueGetDirect_0();
case -101785421: return bem_spropDecGet_0();
case -1939234928: return bem_nameToIdPathGetDirect_0();
case 1944028994: return bem_propertyDecsGetDirect_0();
case -805520262: return bem_setOutputTimeGetDirect_0();
case 803060031: return bem_create_0();
case 12865558: return bem_msynGet_0();
case 1569123884: return bem_lastMethodsSizeGetDirect_0();
case -1779554051: return bem_boolCcGet_0();
case -1775789740: return bem_deowGet_0();
case -1873718178: return bem_boolNpGetDirect_0();
case -1232179830: return bem_smnlecsGet_0();
case 1403008867: return bem_preClassOutput_0();
case -829281071: return bem_lastCallGetDirect_0();
case -791116619: return bem_buildGet_0();
case -504083154: return bem_inClassGet_0();
case -339151919: return bem_nameToIdPathGet_0();
case -749076905: return bem_falseValueGet_0();
case -299023655: return bem_echo_0();
case -541288909: return bem_inFilePathedGet_0();
case -1232978478: return bem_hashGet_0();
case 899052591: return bem_classConfGetDirect_0();
case -135227032: return bem_deonGetDirect_0();
case 1268784474: return bem_getLibOutput_0();
case -525220403: return bem_boolTypeGet_0();
case 1025606721: return bem_nameToIdGetDirect_0();
case -1882135039: return bem_buildClassInfo_0();
case 33090384: return bem_qGetDirect_0();
case -1910927186: return bem_classesInDepthOrderGetDirect_0();
case -254647107: return bem_classEndGet_0();
case 130978737: return bem_useDynMethodsGet_0();
case -1946998339: return bem_classCallsGetDirect_0();
case -1103279899: return bem_maxSpillArgsLenGetDirect_0();
case 1312165499: return bem_callNamesGet_0();
case -1929610243: return bem_classConfGet_0();
case -1968141591: return bem_transGetDirect_0();
case -1303437570: return bem_exceptDecGet_0();
case 2004900231: return bem_beginNs_0();
case 2121039924: return bem_new_0();
case -1566090697: return bem_msynGetDirect_0();
case 1361471999: return bem_heowGetDirect_0();
case 1560843449: return bem_trueValueGet_0();
case -1033295905: return bem_fileExtGet_0();
case -1455830309: return bem_randGet_0();
case -630301587: return bem_writeBET_0();
case 660786310: return bem_classHeadBodyGet_0();
case -457696774: return bem_parentConfGet_0();
case -973667661: return bem_baseSmtdDecGet_0();
case -1798743212: return bem_scvpGetDirect_0();
case -995606308: return bem_lastCallGet_0();
case -1377571519: return bem_headExtGetDirect_0();
case -998698567: return bem_intNpGetDirect_0();
case -1438038411: return bem_sourceFileNameGet_0();
case 1533087311: return bem_nativeCSlotsGetDirect_0();
case -2142664256: return bem_cnodeGetDirect_0();
case -1601924567: return bem_instOfGetDirect_0();
case -1256027405: return bem_stringNpGetDirect_0();
case -632009723: return bem_stringNpGet_0();
case -440373537: return bem_dynMethodsGetDirect_0();
case 1735535715: return bem_lastMethodsLinesGetDirect_0();
case 1644121683: return bem_fileExtGetDirect_0();
case 668786906: return bem_runtimeInitGet_0();
case 2047186960: return bem_deowGetDirect_0();
case -811418832: return bem_many_0();
case -1587668913: return bem_superCallsGetDirect_0();
case -37595091: return bem_transGet_0();
case -1010833462: return bem_mainStartGet_0();
case -54212475: return bem_cnodeGet_0();
case -874725216: return bem_smnlcsGetDirect_0();
case 1461879497: return bem_mainOutsideNsGet_0();
case 1319324662: return bem_onceDecRefsGetDirect_0();
case 1062190131: return bem_lastMethodBodyLinesGetDirect_0();
case -1647244878: return bem_mainInClassGet_0();
case -966774371: return bem_idToNameGet_0();
case 446844919: return bem_shlibeGetDirect_0();
case -1491356078: return bem_libEmitNameGetDirect_0();
case -120944146: return bem_csynGet_0();
case 578886812: return bem_instanceEqualGetDirect_0();
case -1220930812: return bem_exceptDecGetDirect_0();
case 140952840: return bem_saveIds_0();
case -1541975951: return bem_intNpGet_0();
case -539930088: return bem_superCallsGet_0();
case -265928475: return bem_classNameGet_0();
case -286189968: return bem_gcMarksGet_0();
case 433853352: return bem_nlGetDirect_0();
case 24125772: return bem_iteratorGet_0();
case -724173357: return bem_classHeadersGet_0();
case 1103561179: return bem_lastMethodBodyLinesGet_0();
case -1874659580: return bem_qGet_0();
case 2128492244: return bem_prepHeaderOutput_0();
case 129327063: return bem_scvpGet_0();
case 941090219: return bem_objectNpGet_0();
case -1991650219: return bem_setOutputTimeGet_0();
case 673541352: return bem_invpGet_0();
case 1631787098: return bem_getClassOutput_0();
case -1824597926: return bem_classHeadersGetDirect_0();
case 794243928: return bem_deopGetDirect_0();
case 1913339019: return bem_smnlecsGetDirect_0();
case -992120130: return bem_fieldIteratorGet_0();
case 1870744321: return bem_once_0();
case 538632487: return bem_serializationIteratorGet_0();
case -1315813626: return bem_onceDecsGet_0();
case 2039455387: return bem_synEmitPathGet_0();
case 661465401: return bem_methodsGet_0();
case 1086373711: return bem_floatNpGetDirect_0();
case 533952540: return bem_nullValueGet_0();
case 887711380: return bem_inClassGetDirect_0();
case 1351043170: return bem_classCallsGet_0();
case 2111391138: return bem_serializeToString_0();
case -117352988: return bem_libEmitPathGetDirect_0();
case -2034975934: return bem_invpGetDirect_0();
case -1269291305: return bem_instanceNotEqualGet_0();
case -458323589: return bem_emitLangGet_0();
case 1196153339: return bem_nativeCSlotsGet_0();
case -418540583: return bem_onceCountGet_0();
case 1169883100: return bem_idToNamePathGetDirect_0();
case -251324858: return bem_lastMethodBodySizeGet_0();
case -737945580: return bem_propDecGet_0();
case -495772868: return bem_boolNpGet_0();
case 1785231461: return bem_synEmitPathGetDirect_0();
case 1133013598: return bem_objectCcGetDirect_0();
case 615615306: return bem_dynMethodsGet_0();
case 827062869: return bem_lastMethodsLinesGet_0();
case -229851887: return bem_idToNameGetDirect_0();
case -195266806: return bem_toString_0();
case -1816798411: return bem_lineCountGetDirect_0();
case -121416651: return bem_objectCcGet_0();
case -1723152316: return bem_deonGet_0();
case -728123328: return bem_buildCreate_0();
case 547536605: return bem_lineCountGet_0();
case -1242975086: return bem_methodBodyGet_0();
case 1592235863: return bem_fullLibEmitNameGetDirect_0();
case -597875879: return bem_onceDecsGetDirect_0();
case -48485285: return bem_ccCacheGetDirect_0();
case -1254357606: return bem_heonGetDirect_0();
case 251426879: return bem_boolCcGetDirect_0();
case 1051597953: return bem_preClassGetDirect_0();
case 291610738: return bem_typeDecGet_0();
case -1506799927: return bem_deopGet_0();
case 1736258374: return bem_saveSyns_0();
case 164464828: return bem_covariantReturnsGet_0();
case 1255446065: return bem_maxDynArgsGet_0();
case -584668521: return bem_baseMtdDecGet_0();
case -504008002: return bem_maxDynArgsGetDirect_0();
case -1281667008: return bem_ntypesGet_0();
case -1991561682: return bem_newDecGet_0();
case 1300266764: return bem_gcMarksGetDirect_0();
case -1540546537: return bem_methodCatchGetDirect_0();
case -1911613349: return bem_maxSpillArgsLenGet_0();
case 1351564830: return bem_propertyDecsGet_0();
case -137975808: return bem_methodBodyGetDirect_0();
case 1057323332: return bem_toAny_0();
case 938279454: return bem_lastMethodBodySizeGetDirect_0();
case 1244436771: return bem_emitLangGetDirect_0();
case -949051474: return bem_loadIds_0();
case -189856578: return bem_copy_0();
case -471889447: return bem_csynGetDirect_0();
case 703838958: return bem_headExtGet_0();
case -1142420378: return bem_nullValueGetDirect_0();
case 2077432635: return bem_afterCast_0();
case 75181373: return bem_classEmitsGet_0();
case -1735879417: return bem_print_0();
case 1772671941: return bem_callNamesGetDirect_0();
case 1224650212: return bem_constGetDirect_0();
case -17162438: return bem_initialDecGet_0();
case 1816943869: return bem_methodsGetDirect_0();
case 1560965466: return bem_floatNpGet_0();
case -1859446112: return bem_onceDecRefsCountGet_0();
case 2027102740: return bem_buildGetDirect_0();
case -103930433: return bem_randGetDirect_0();
case -1891333612: return bem_mnodeGetDirect_0();
case 165473301: return bem_methodCallsGetDirect_0();
case 587794980: return bem_parentConfGetDirect_0();
case 309921107: return bem_buildPropList_0();
case -592980601: return bem_heopGet_0();
case 657094702: return bem_libEmitPathGet_0();
case 732116455: return bem_ntypesGetDirect_0();
case 1778338684: return bem_shlibeGet_0();
case -645906551: return bem_heonGet_0();
case -330228940: return bem_objectNpGetDirect_0();
case -1437667210: return bem_superNameGet_0();
case 458901046: return bem_instanceNotEqualGetDirect_0();
case 1756261368: return bem_ccMethodsGetDirect_0();
case 893274194: return bem_tagGet_0();
case -773330081: return bem_emitLib_0();
case -1473587306: return bem_ccMethodsGet_0();
case 267317317: return bem_trueValueGetDirect_0();
case -1946254385: return bem_doEmit_0();
case -1505067855: return bem_instanceEqualGet_0();
case -1951880906: return bem_returnTypeGet_0();
case -1326201498: return bem_classEmitsGetDirect_0();
case 921625576: return bem_smnlcsGet_0();
case 1848649764: return bem_buildInitial_0();
case -802467667: return bem_nlGet_0();
case -845974981: return bem_overrideMtdDecGet_0();
case 931605306: return bem_onceDecRefsCountGetDirect_0();
case -706086942: return bem_ccCacheGet_0();
case -1638383063: return bem_onceDecRefsGet_0();
case -731996509: return bem_fullLibEmitNameGet_0();
case 613911445: return bem_constGet_0();
case -1888571635: return bem_classHeadBodyGetDirect_0();
case -969800667: return bem_inFilePathedGetDirect_0();
case 108376572: return bem_endNs_0();
case -1800795610: return bem_classesInDepthOrderGet_0();
case 1154096288: return bem_libEmitNameGet_0();
case -1054219423: return bem_preClassGet_0();
case -166515831: return bem_fieldNamesGet_0();
case 1045540797: return bem_idToNamePathGet_0();
case -1856486979: return bem_deserializeClassNameGet_0();
case 1143586406: return bem_nameToIdGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -352246712: return bem_randSet_1(bevd_0);
case -1703633823: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -2089058991: return bem_heopSetDirect_1(bevd_0);
case 1935432870: return bem_inFilePathedSetDirect_1(bevd_0);
case -37217945: return bem_msynSet_1(bevd_0);
case 250793503: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 620116638: return bem_returnTypeSetDirect_1(bevd_0);
case 991986776: return bem_stringNpSet_1(bevd_0);
case 1536810409: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1493653799: return bem_lineCountSetDirect_1(bevd_0);
case -2051033440: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1374125024: return bem_undef_1(bevd_0);
case 1421290285: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1485044739: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1750262780: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -649675302: return bem_nlSet_1(bevd_0);
case 1504366020: return bem_deopSetDirect_1(bevd_0);
case -1673835204: return bem_classConfSet_1(bevd_0);
case -142896014: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -912371135: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 346505721: return bem_instOfSetDirect_1(bevd_0);
case 90624562: return bem_boolNpSetDirect_1(bevd_0);
case -557398672: return bem_transSet_1(bevd_0);
case 756956644: return bem_heonSetDirect_1(bevd_0);
case -267062499: return bem_sameType_1(bevd_0);
case -677667562: return bem_falseValueSetDirect_1(bevd_0);
case -1315082527: return bem_floatNpSet_1(bevd_0);
case 687214103: return bem_exceptDecSet_1(bevd_0);
case -720232290: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -366437674: return bem_onceDecRefsSet_1(bevd_0);
case 176457078: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 320943752: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -715798271: return bem_nameToIdSet_1(bevd_0);
case -1072657902: return bem_nameToIdPathSetDirect_1(bevd_0);
case 1025270681: return bem_sameClass_1(bevd_0);
case 1868583284: return bem_fullLibEmitNameSet_1(bevd_0);
case 1247603455: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 739714004: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 471245996: return bem_classCallsSetDirect_1(bevd_0);
case 1718386075: return bem_ccMethodsSetDirect_1(bevd_0);
case -680436860: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 832990011: return bem_csynSetDirect_1(bevd_0);
case -21024311: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 47770590: return bem_callNamesSetDirect_1(bevd_0);
case -1873843982: return bem_methodCallsSet_1(bevd_0);
case -1233382567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -66339511: return bem_fileExtSetDirect_1(bevd_0);
case -1433803932: return bem_def_1(bevd_0);
case -617687836: return bem_methodBodySet_1(bevd_0);
case -1575342769: return bem_classHeadersSetDirect_1(bevd_0);
case 903904482: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1107261340: return bem_trueValueSet_1(bevd_0);
case -206527850: return bem_constSetDirect_1(bevd_0);
case -1740717109: return bem_qSet_1(bevd_0);
case -227285977: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -697895958: return bem_dynMethodsSet_1(bevd_0);
case 868943903: return bem_methodsSet_1(bevd_0);
case 12927372: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 689052585: return bem_smnlecsSetDirect_1(bevd_0);
case 928967464: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 775014576: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 591737523: return bem_shlibeSetDirect_1(bevd_0);
case 2087278209: return bem_inClassSet_1(bevd_0);
case -1367577004: return bem_nativeCSlotsSet_1(bevd_0);
case -262795974: return bem_parentConfSet_1(bevd_0);
case 722681547: return bem_begin_1(bevd_0);
case -372667318: return bem_smnlcsSetDirect_1(bevd_0);
case 640617302: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -1105393278: return bem_deonSetDirect_1(bevd_0);
case -1568263635: return bem_randSetDirect_1(bevd_0);
case 302147724: return bem_onceDecRefsCountSetDirect_1(bevd_0);
case -298583217: return bem_classesInDepthOrderSet_1(bevd_0);
case 82066031: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -2109276105: return bem_inClassSetDirect_1(bevd_0);
case -887303563: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 235624363: return bem_invpSet_1(bevd_0);
case 1439509107: return bem_heowSet_1(bevd_0);
case 1405886697: return bem_classHeadersSet_1(bevd_0);
case -2017517480: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -2123423391: return bem_ntypesSetDirect_1(bevd_0);
case -967696770: return bem_ntypesSet_1(bevd_0);
case 570998328: return bem_shlibeSet_1(bevd_0);
case 1235936618: return bem_heowSetDirect_1(bevd_0);
case 1038900983: return bem_qSetDirect_1(bevd_0);
case 84089104: return bem_headExtSetDirect_1(bevd_0);
case 1615441557: return bem_floatNpSetDirect_1(bevd_0);
case -369053855: return bem_propertyDecsSetDirect_1(bevd_0);
case 1360806141: return bem_transSetDirect_1(bevd_0);
case 1131961111: return bem_classConfSetDirect_1(bevd_0);
case 1172126866: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 297035740: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -924256672: return bem_heopSet_1(bevd_0);
case 428029039: return bem_onceCountSet_1(bevd_0);
case -1847610792: return bem_idToNameSet_1(bevd_0);
case -905872983: return bem_equals_1(bevd_0);
case 1505817283: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1324489023: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1613647338: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 974413135: return bem_methodBodySetDirect_1(bevd_0);
case 1376433709: return bem_ccCacheSetDirect_1(bevd_0);
case -995763322: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -585010311: return bem_idToNameSetDirect_1(bevd_0);
case -605867121: return bem_boolCcSetDirect_1(bevd_0);
case -1889996879: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -805166101: return bem_parentConfSetDirect_1(bevd_0);
case -1470721086: return bem_lineCountSet_1(bevd_0);
case -542353264: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 1825194129: return bem_idToNamePathSet_1(bevd_0);
case 1554974702: return bem_maxDynArgsSet_1(bevd_0);
case -1653548074: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1423346320: return bem_lastMethodsSizeSet_1(bevd_0);
case 1087997211: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 66020482: return bem_scvpSetDirect_1(bevd_0);
case -1830658269: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1413707423: return bem_onceDecsSet_1(bevd_0);
case -511086803: return bem_buildSetDirect_1(bevd_0);
case -2047520864: return bem_nameToIdSetDirect_1(bevd_0);
case 72138268: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1171677374: return bem_end_1(bevd_0);
case 2129036307: return bem_classHeadBodySetDirect_1(bevd_0);
case 960118460: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1489037385: return bem_intNpSet_1(bevd_0);
case 1628306760: return bem_notEquals_1(bevd_0);
case -456071073: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -475546475: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1824910780: return bem_gcMarksSet_1(bevd_0);
case 1940831884: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1564503044: return bem_deowSetDirect_1(bevd_0);
case -1262794933: return bem_inFilePathedSet_1(bevd_0);
case -345922380: return bem_mnodeSet_1(bevd_0);
case -1877058996: return bem_libEmitNameSet_1(bevd_0);
case 1657254809: return bem_lastCallSetDirect_1(bevd_0);
case -1108496649: return bem_otherClass_1(bevd_0);
case -543568625: return bem_deopSet_1(bevd_0);
case 971983963: return bem_propertyDecsSet_1(bevd_0);
case 1568881752: return bem_nullValueSetDirect_1(bevd_0);
case -759981062: return bem_objectCcSetDirect_1(bevd_0);
case 1007117456: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 230427006: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 712489064: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1885094820: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -2130800469: return bem_idToNamePathSetDirect_1(bevd_0);
case 1840791155: return bem_csynSet_1(bevd_0);
case -1703180747: return bem_heonSet_1(bevd_0);
case 1768310435: return bem_scvpSet_1(bevd_0);
case -1985943889: return bem_falseValueSet_1(bevd_0);
case -352262426: return bem_smnlecsSet_1(bevd_0);
case 1681509942: return bem_mnodeSetDirect_1(bevd_0);
case 316241014: return bem_lastMethodsLinesSet_1(bevd_0);
case 460641329: return bem_deonSet_1(bevd_0);
case 2145909811: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -443682146: return bem_nlSetDirect_1(bevd_0);
case 368728434: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1498424233: return bem_methodCallsSetDirect_1(bevd_0);
case 475109313: return bem_instOfSet_1(bevd_0);
case 971663896: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case 530433555: return bem_onceDecsSetDirect_1(bevd_0);
case 1096724509: return bem_lastMethodBodySizeSet_1(bevd_0);
case -702295537: return bem_ccMethodsSet_1(bevd_0);
case -487289274: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -227738822: return bem_callNamesSet_1(bevd_0);
case -1232725493: return bem_methodCatchSet_1(bevd_0);
case 1902918064: return bem_lastCallSet_1(bevd_0);
case 1303393248: return bem_onceDecRefsSetDirect_1(bevd_0);
case -24042989: return bem_synEmitPathSetDirect_1(bevd_0);
case 1928141291: return bem_invpSetDirect_1(bevd_0);
case -564148923: return bem_sameObject_1(bevd_0);
case 1669121148: return bem_copyTo_1(bevd_0);
case 1770044117: return bem_onceDecRefsCountSet_1(bevd_0);
case 74951706: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -215090614: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 684985214: return bem_maxDynArgsSetDirect_1(bevd_0);
case -947687101: return bem_fileExtSet_1(bevd_0);
case 1308962355: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1265207521: return bem_ccCacheSet_1(bevd_0);
case -1695275610: return bem_dynMethodsSetDirect_1(bevd_0);
case -629340519: return bem_superCallsSetDirect_1(bevd_0);
case 1454657835: return bem_classCallsSet_1(bevd_0);
case -326152349: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -897487916: return bem_methodsSetDirect_1(bevd_0);
case 990245803: return bem_instanceEqualSetDirect_1(bevd_0);
case 1636374826: return bem_libEmitPathSet_1(bevd_0);
case -795152868: return bem_classHeadBodySet_1(bevd_0);
case 95506734: return bem_instanceNotEqualSet_1(bevd_0);
case -1741084371: return bem_boolNpSet_1(bevd_0);
case -238784694: return bem_returnTypeSet_1(bevd_0);
case -30525107: return bem_deowSet_1(bevd_0);
case 1174503613: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 434383451: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 659139773: return bem_buildSet_1(bevd_0);
case -132983687: return bem_undefined_1(bevd_0);
case -157762694: return bem_preClassSet_1(bevd_0);
case -1995738373: return bem_trueValueSetDirect_1(bevd_0);
case 579591697: return bem_smnlcsSet_1(bevd_0);
case 146723804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1381548393: return bem_objectNpSetDirect_1(bevd_0);
case 1384971079: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1301395906: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1697126188: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -886116394: return bem_classEmitsSet_1(bevd_0);
case -947317767: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -343142980: return bem_emitLangSetDirect_1(bevd_0);
case 1313138103: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1610769882: return bem_nameToIdPathSet_1(bevd_0);
case -571883231: return bem_boolCcSet_1(bevd_0);
case -928551689: return bem_nullValueSet_1(bevd_0);
case -207345723: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -2000629231: return bem_intNpSetDirect_1(bevd_0);
case -839438679: return bem_preClassSetDirect_1(bevd_0);
case 457485558: return bem_headExtSet_1(bevd_0);
case -26671314: return bem_classEmitsSetDirect_1(bevd_0);
case -1171661229: return bem_otherType_1(bevd_0);
case 1435423903: return bem_libEmitNameSetDirect_1(bevd_0);
case 1872312761: return bem_instanceEqualSet_1(bevd_0);
case 1388209450: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1398699541: return bem_setOutputTimeSet_1(bevd_0);
case -1043850402: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1363849873: return bem_emitLangSet_1(bevd_0);
case 1118458783: return bem_methodCatchSetDirect_1(bevd_0);
case 901886103: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -1679415309: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 2601848: return bem_setOutputTimeSetDirect_1(bevd_0);
case 140588493: return bem_objectNpSet_1(bevd_0);
case -665739429: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1147900205: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -148272697: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1368629495: return bem_exceptDecSetDirect_1(bevd_0);
case 1119217527: return bem_cnodeSetDirect_1(bevd_0);
case 1681419755: return bem_defined_1(bevd_0);
case 531613456: return bem_onceCountSetDirect_1(bevd_0);
case -490313093: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1491655069: return bem_stringNpSetDirect_1(bevd_0);
case 1418397330: return bem_msynSetDirect_1(bevd_0);
case 320091648: return bem_objectCcSet_1(bevd_0);
case 2046598805: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1210631125: return bem_constSet_1(bevd_0);
case 2066654020: return bem_cnodeSet_1(bevd_0);
case -1963597288: return bem_superCallsSet_1(bevd_0);
case 525545408: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2135995791: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -202813971: return bem_libEmitPathSetDirect_1(bevd_0);
case -411320263: return bem_gcMarksSetDirect_1(bevd_0);
case -917359622: return bem_synEmitPathSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1961599719: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2022577805: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -110664853: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -653206533: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1765848815: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -359232111: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 721002489: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1365987158: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1931375919: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -383175850: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68692131: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1179173633: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 421859346: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 260530864: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -381061425: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 562043996: return bem_writeOnceDecs_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 9103124: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -725875868: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -675088581: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -415530456: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -629937906: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1169312908: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1554787599: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1044951969: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 1687202771: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -884527250: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 750599360: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCCEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
}
