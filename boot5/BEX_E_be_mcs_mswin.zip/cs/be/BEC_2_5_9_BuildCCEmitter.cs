namespace be {
/* IO:File: source/build/CCEmitter.be */
public sealed class BEC_2_5_9_BuildCCEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
static BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x63,0x63,0x4E,0x6F,0x52,0x74,0x74,0x69};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x2A,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x28,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28,0x29,0x29,0x2D,0x3E,0x62,0x65,0x6D,0x73,0x5F,0x63,0x63,0x73,0x6E,0x65,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x63,0x63,0x53,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x2A,0x29,0x20,0x28,0x28,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x29,0x2D,0x3E,0x62,0x65,0x6D,0x73,0x5F,0x63,0x63,0x69,0x6E,0x65,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x66,0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x28,0x29,0x29,0x2D,0x3E,0x62,0x65,0x6D,0x73,0x5F,0x63,0x63,0x73,0x6E,0x65,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x6E,0x6F,0x52,0x66,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x42,0x45,0x44,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x42,0x45,0x48,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x69,0x6E,0x74,0x20,0x61,0x72,0x67,0x63,0x2C,0x20,0x63,0x68,0x61,0x72,0x20,0x2A,0x2A,0x61,0x72,0x67,0x76,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x63,0x63,0x42,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x2C,0x20,0x67,0x63,0x5F,0x61,0x6C,0x6C,0x6F,0x63,0x61,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
public static new BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static new BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
base.bem_new_1(beva__build);
bevp_invp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 41*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 42*/
 else /* Line: 43*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 44*/
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevl_extends);
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
if (bevp_parentConf == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_libNameGet_0();
bevt_15_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_16_ta_ph);
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
} /* Line: 53*/
 else /* Line: 54*/ {
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_20_ta_ph);
} /* Line: 59*/
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_22_ta_ph);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_24_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_23_ta_ph = bevt_24_ta_ph.bem_has_1(bevt_25_ta_ph);
if (!(bevt_23_ta_ph.bevi_bool))/* Line: 74*/ {
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_26_ta_ph);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_27_ta_ph);
} /* Line: 76*/
bevt_28_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_28_ta_ph);
bevt_33_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_34_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevt_34_ta_ph);
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_31_ta_ph = bevt_32_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_36_ta_ph = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_36_ta_ph);
bevt_37_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_37_ta_ph);
bevp_heow.bem_write_1(bevt_29_ta_ph);
bevt_38_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_38_ta_ph);
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_42_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 85*/ {
bevt_46_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(40, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_46_ta_ph);
bevt_47_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevp_heow.bem_write_1(bevt_47_ta_ph);
} /* Line: 87*/
bevt_50_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevt_51_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_add_1(bevt_51_ta_ph);
bevt_52_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevt_52_ta_ph);
bevp_heow.bem_write_1(bevt_48_ta_ph);
bevt_55_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_56_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_54_ta_ph = bevt_55_ta_ph.bem_add_1(bevt_56_ta_ph);
bevt_57_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_53_ta_ph = bevt_54_ta_ph.bem_add_1(bevt_57_ta_ph);
bevp_deow.bem_write_1(bevt_53_ta_ph);
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_58_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_7_ta_ph = bem_overrideMtdDecGet_0();
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_17_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_22_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(-350299047);
bevt_20_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_ta_ph );
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_relEmitName_1(bevt_23_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) bevt_17_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_15_ta_ph = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_25_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_26_ta_ph);
bevt_25_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevp_heow.bem_write_1(bevt_0_ta_ph);
return bevl_end;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_ta_ph = bevp_build.bem_libNameGet_0();
bevt_6_ta_ph = beva_returnType.bem_relEmitName_1(bevt_7_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_0_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_14_ta_ph = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_15_ta_ph);
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevt_14_ta_ph.bem_addValue_1(beva_exceptDec);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevt_13_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_20_ta_ph = (BEC_2_4_6_TextString) bevp_classHeadBody.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_22_ta_ph = beva_returnType.bem_relEmitName_1(bevt_23_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_18_ta_ph = (BEC_2_4_6_TextString) bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) bevt_18_ta_ph.bem_addValue_1(beva_mtdName);
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_17_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevp_classHeadBody.bem_addValue_1(bevt_26_ta_ph);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_typenameGet_0();
bevt_2_ta_ph = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_ta_ph.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 142*/ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
} /* Line: 143*/
 else /* Line: 142*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(2136811591);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(-696336738, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 144*/ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
} /* Line: 145*/
 else /* Line: 142*/ {
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(2136811591);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(-696336738, bevt_10_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 146*/ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
} /* Line: 147*/
 else /* Line: 148*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_ta_ph );
} /* Line: 149*/
} /* Line: 142*/
} /* Line: 142*/
return bevl_tcall;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(2136811591);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-696336738, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 155*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
bevl_tcall = bevt_4_ta_ph.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 157*/
bevt_5_ta_ph = base.bem_formCallTarg_1(beva_node);
return bevt_5_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-475908396);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-822151472, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 167*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(1253492311);
bevp_classHeaders.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 168*/
 else /* Line: 169*/ {
base.bem_handleClassEmit_1(beva_node);
} /* Line: 170*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_8_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevl_clh = bevt_4_ta_ph.bem_add_1(bevt_10_ta_ph);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_ta_ph = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_14_ta_ph = (BEC_2_4_6_TextString) bevt_15_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevt_14_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevt_13_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) bevt_12_ta_ph.bem_addValue_1(bevl_bein);
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_11_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_24_ta_ph = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_ta_ph = (BEC_2_4_6_TextString) bevt_24_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_22_ta_ph = (BEC_2_4_6_TextString) bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = (BEC_2_4_6_TextString) bevt_22_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_32_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_33_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_21_ta_ph.bem_addValue_1(bevt_29_ta_ph);
return bevl_initialDec;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1910883103);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1128355666);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_8_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_v.bem_isTypedGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 201*/ {
bevt_4_ta_ph = bevp_build.bem_libNameGet_0();
bevt_3_ta_ph = bevp_objectCc.bem_relEmitName_1(bevt_4_ta_ph);
bevt_2_ta_ph = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_2_ta_ph.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 202*/
 else /* Line: 203*/ {
bevt_9_ta_ph = beva_v.bem_namepathGet_0();
bevt_8_ta_ph = bem_getClassConfig_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_6_ta_ph.bem_addValue_1(bevt_11_ta_ph);
} /* Line: 204*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_0_ta_ph = beva_type.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 209*/ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
} /* Line: 210*/
 else /* Line: 211*/ {
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_65));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 212*/ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
} /* Line: 213*/
 else /* Line: 214*/ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
} /* Line: 215*/
} /* Line: 212*/
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_7_ta_ph = bevl_ccall.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_cc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_11_ta_ph);
return bevt_5_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_afterCast_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
bevt_8_ta_ph = bem_overrideMtdDecGet_0();
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(beva_bemBase);
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
bevt_18_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_19_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) bevt_18_ta_ph.bem_addValue_1(beva_len);
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
bevt_16_ta_ph = (BEC_2_4_6_TextString) bevt_17_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_15_ta_ph = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_addValue_1(beva_belsBase);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_14_ta_ph = (BEC_2_4_6_TextString) bevt_15_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_22_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_23_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 234*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-881231289);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 235*/
 else /* Line: 236*/ {
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-881231289);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 237*/
return bevl_newCall;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-881231289);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 244*/
 else /* Line: 245*/ {
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-881231289);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 246*/
return bevl_newCall;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_litArgs = bevt_0_ta_ph.bem_add_1(beva_sdec);
bevt_5_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 253*/ {
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_14_ta_ph = bevp_build.bem_libNameGet_0();
bevt_13_ta_ph = beva_newcc.bem_relEmitName_1(bevt_14_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = bevp_build.bem_libNameGet_0();
bevt_16_ta_ph = beva_newcc.bem_relEmitName_1(bevt_17_ta_ph);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_16_ta_ph);
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_18_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_litArgs);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevl_newCall = bevt_7_ta_ph.bem_add_1(bevt_19_ta_ph);
} /* Line: 254*/
 else /* Line: 255*/ {
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_27_ta_ph = bevp_build.bem_libNameGet_0();
bevt_26_ta_ph = beva_newcc.bem_relEmitName_1(bevt_27_ta_ph);
bevt_24_ta_ph = bevt_25_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_30_ta_ph = bevp_build.bem_libNameGet_0();
bevt_29_ta_ph = beva_newcc.bem_relEmitName_1(bevt_30_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_31_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevl_litArgs);
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevl_newCall = bevt_20_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 256*/
return bevl_newCall;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_1_ta_ph = beva_typeName.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_mainInClassGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_preClassOutput_0() {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevp_setOutputTime = null;
bevt_1_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 305*/ {
bevt_5_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 305*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 305*/ {
return this;
} /* Line: 306*/
 else /* Line: 307*/ {
bevt_7_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevl_outts = bevt_6_ta_ph.bem_lastUpdatedGet_0();
bevt_9_ta_ph = bevp_inClass.bem_fromFileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(2033713911);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_ta_ph.bemd_0(2007660129);
bevt_10_ta_ph = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_ta_ph.bevi_bool)/* Line: 310*/ {
return this;
} /* Line: 313*/
bevp_setOutputTime = bevl_outts;
} /* Line: 316*/
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_1_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 321*/ {
bevt_1_ta_ph = bem_getLibOutput_0();
return bevt_1_ta_ph;
} /* Line: 322*/
bevt_2_ta_ph = base.bem_getClassOutput_0();
return bevt_2_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 328*/ {
bevl_clns = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevt_1_ta_ph = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 331*/
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_2_4_IOFile bevt_3_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_4_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 336*/ {
bevl_clend = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_1_ta_ph = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_4_ta_ph = beva_cle.bem_pathGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_fileGet_0();
bevt_3_ta_ph.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 344*/
} /* Line: 342*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 351*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(beva_mvn);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(beva_mvn);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_3_ta_ph.bem_addValue_1(bevp_nl);
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(beva_mvn);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevt_11_ta_ph = (BEC_2_4_6_TextString) bevt_12_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_14_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 354*/
return bevl_bet;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_4_ContainerList bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_9_4_ContainerList bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
bevp_deow.bem_write_1(bevt_2_ta_ph);
bevl_beh = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_beh.bem_addValue_1(bevt_12_ta_ph);
bevt_14_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevl_beh.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevl_beh.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevl_beh.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevl_beh.bem_addValue_1(bevt_19_ta_ph);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_23_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_22_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_23_ta_ph);
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_21_ta_ph = (BEC_2_4_6_TextString) bevt_22_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_25_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_20_ta_ph = (BEC_2_4_6_TextString) bevt_21_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_20_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevl_bet.bem_addValue_1(bevt_27_ta_ph);
bevt_29_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (!(bevt_28_ta_ph.bevi_bool))/* Line: 374*/ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_31_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 376*/ {
bevt_32_ta_ph = bevt_0_ta_loop.bemd_0(1102233);
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 376*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(199074760);
if (bevl_firstmnsyn.bevi_bool)/* Line: 377*/ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 378*/
 else /* Line: 379*/ {
bevt_33_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevl_bet.bem_addValue_1(bevt_33_ta_ph);
} /* Line: 380*/
bevt_35_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_36_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_34_ta_ph = (BEC_2_4_6_TextString) bevt_35_ta_ph.bem_addValue_1(bevt_36_ta_ph);
bevt_34_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 382*/
 else /* Line: 376*/ {
break;
} /* Line: 376*/
} /* Line: 376*/
} /* Line: 376*/
bevt_37_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevl_bet.bem_addValue_1(bevt_37_ta_ph);
bevt_39_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevt_38_ta_ph = bevt_39_ta_ph.bem_has_1(bevt_40_ta_ph);
if (!(bevt_38_ta_ph.bevi_bool))/* Line: 387*/ {
bevt_41_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevl_bet.bem_addValue_1(bevt_41_ta_ph);
} /* Line: 388*/
bevt_42_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 392*/ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_46_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_46_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 394*/ {
bevt_47_ta_ph = bevt_1_ta_loop.bemd_0(1102233);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 394*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(199074760);
if (bevl_firstptsyn.bevi_bool)/* Line: 395*/ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 396*/
 else /* Line: 397*/ {
bevt_48_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevl_bet.bem_addValue_1(bevt_48_ta_ph);
} /* Line: 398*/
bevt_50_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_51_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_49_ta_ph = (BEC_2_4_6_TextString) bevt_50_ta_ph.bem_addValue_1(bevt_51_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 400*/
 else /* Line: 394*/ {
break;
} /* Line: 394*/
} /* Line: 394*/
} /* Line: 394*/
bevt_52_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevl_bet.bem_addValue_1(bevt_52_ta_ph);
bevt_53_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_55_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_56_ta_ph);
bevt_57_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_54_ta_ph = (BEC_2_4_6_TextString) bevt_55_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevt_54_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_60_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_61_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevt_59_ta_ph = bevt_60_ta_ph.bem_equals_1(bevt_61_ta_ph);
if (bevt_59_ta_ph.bevi_bool)/* Line: 408*/ {
bevt_64_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_63_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_64_ta_ph);
bevt_65_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_62_ta_ph = (BEC_2_4_6_TextString) bevt_63_ta_ph.bem_addValue_1(bevt_65_ta_ph);
bevt_66_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_62_ta_ph.bem_addValue_1(bevt_66_ta_ph);
} /* Line: 409*/
 else /* Line: 410*/ {
bevt_69_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_68_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_69_ta_ph);
bevt_70_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_67_ta_ph = (BEC_2_4_6_TextString) bevt_68_ta_ph.bem_addValue_1(bevt_70_ta_ph);
bevt_71_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_67_ta_ph.bem_addValue_1(bevt_71_ta_ph);
} /* Line: 411*/
bevt_72_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_72_ta_ph);
bevt_75_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_74_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_75_ta_ph);
bevt_76_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_73_ta_ph = (BEC_2_4_6_TextString) bevt_74_ta_ph.bem_addValue_1(bevt_76_ta_ph);
bevt_77_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_73_ta_ph.bem_addValue_1(bevt_77_ta_ph);
bevt_78_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevl_bet.bem_addValue_1(bevt_78_ta_ph);
bevt_80_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevt_79_ta_ph = bem_genMark_1(bevt_80_ta_ph);
bevl_bet.bem_addValue_1(bevt_79_ta_ph);
bevt_81_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_81_ta_ph);
bevt_82_ta_ph = bem_getClassOutput_0();
bevt_82_ta_ph.bem_write_1(bevl_bet);
bevt_83_ta_ph = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_83_ta_ph.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_2_4_IOFile bevt_20_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_2_4_IOFile bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_2_4_IOFile bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_31_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_45_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_56_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
if (bevp_deow == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 434*/ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_8_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_libName);
bevp_deon = bevt_4_ta_ph.bem_add_1(bevp_headExt);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevt_14_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevl_libName);
bevp_heon = bevt_10_ta_ph.bem_add_1(bevp_headExt);
bevt_16_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_ta_ph.bem_addStep_1(bevp_deon);
bevt_17_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_ta_ph.bem_addStep_1(bevp_heon);
bevt_21_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_existsGet_0();
if (bevt_19_ta_ph.bevi_bool) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 440*/ {
bevt_23_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_fileGet_0();
bevt_22_ta_ph.bem_makeDirs_0();
} /* Line: 441*/
bevt_25_ta_ph = bevp_deop.bem_fileGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_ta_ph.bemd_0(-1086290012);
bevt_27_ta_ph = bevp_heop.bem_fileGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_ta_ph.bemd_0(-1086290012);
bevt_29_ta_ph = bevp_build.bem_paramsGet_0();
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (bevt_28_ta_ph.bevi_bool)/* Line: 446*/ {
bevt_32_ta_ph = bevp_build.bem_paramsGet_0();
bevt_33_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_31_ta_ph = bevt_32_ta_ph.bem_get_1(bevt_33_ta_ph);
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 448*/ {
bevt_34_ta_ph = bevt_0_ta_loop.bemd_0(1102233);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 448*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(199074760);
bevt_35_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_ta_ph.bem_fileGet_0();
bevt_37_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(-1086290012);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_ta_ph.bemd_0(-195620474);
bevt_38_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_38_ta_ph.bemd_0(-910720573);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 454*/
 else /* Line: 448*/ {
break;
} /* Line: 448*/
} /* Line: 448*/
} /* Line: 448*/
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevp_deow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_43_ta_ph = bevp_build.bem_paramsGet_0();
bevt_44_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_42_ta_ph = bevt_43_ta_ph.bem_has_1(bevt_44_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 468*/ {
bevt_46_ta_ph = bevp_build.bem_paramsGet_0();
bevt_47_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_45_ta_ph = bevt_46_ta_ph.bem_get_1(bevt_47_ta_ph);
bevt_1_ta_loop = bevt_45_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 470*/ {
bevt_48_ta_ph = bevt_1_ta_loop.bemd_0(1102233);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 470*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(199074760);
bevt_49_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_49_ta_ph.bem_fileGet_0();
bevt_51_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bemd_0(-1086290012);
bevl_inc = (BEC_2_4_6_TextString) bevt_50_ta_ph.bemd_0(-195620474);
bevt_52_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_52_ta_ph.bemd_0(-910720573);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 476*/
 else /* Line: 470*/ {
break;
} /* Line: 470*/
} /* Line: 470*/
} /* Line: 470*/
bevt_54_ta_ph = bevp_build.bem_paramsGet_0();
bevt_55_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_53_ta_ph = bevt_54_ta_ph.bem_has_1(bevt_55_ta_ph);
if (bevt_53_ta_ph.bevi_bool)/* Line: 479*/ {
bevt_57_ta_ph = bevp_build.bem_paramsGet_0();
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_56_ta_ph = bevt_57_ta_ph.bem_get_1(bevt_58_ta_ph);
bevt_2_ta_loop = bevt_56_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 481*/ {
bevt_59_ta_ph = bevt_2_ta_loop.bemd_0(1102233);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 481*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_ta_loop.bemd_0(199074760);
bevt_60_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_60_ta_ph.bem_fileGet_0();
bevt_62_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(-1086290012);
bevl_inc = (BEC_2_4_6_TextString) bevt_61_ta_ph.bemd_0(-195620474);
bevt_63_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_63_ta_ph.bemd_0(-910720573);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 487*/
 else /* Line: 481*/ {
break;
} /* Line: 481*/
} /* Line: 481*/
} /* Line: 481*/
} /* Line: 479*/
return this;
} /*method end*/
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_2_4_IOFile bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_15_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_27_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
if (bevp_shlibe == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 500*/ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_6_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_fileGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_existsGet_0();
if (bevt_4_ta_ph.bevi_bool) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 502*/ {
bevt_8_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_fileGet_0();
bevt_7_ta_ph.bem_makeDirs_0();
} /* Line: 503*/
bevt_10_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_ta_ph.bemd_0(-1086290012);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevp_shlibe.bem_write_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_paramsGet_0();
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevt_12_ta_ph = bevt_13_ta_ph.bem_has_1(bevt_14_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 509*/ {
bevt_16_ta_ph = bevp_build.bem_paramsGet_0();
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevt_15_ta_ph = bevt_16_ta_ph.bem_get_1(bevt_17_ta_ph);
bevt_0_ta_loop = bevt_15_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 511*/ {
bevt_18_ta_ph = bevt_0_ta_loop.bemd_0(1102233);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 511*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(199074760);
bevt_19_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_ta_ph.bem_fileGet_0();
bevt_21_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(-1086290012);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_ta_ph.bemd_0(-195620474);
bevt_22_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_22_ta_ph.bemd_0(-910720573);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 517*/
 else /* Line: 511*/ {
break;
} /* Line: 511*/
} /* Line: 511*/
} /* Line: 511*/
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevp_shlibe.bem_write_1(bevt_23_ta_ph);
bevp_lineCount.bem_increment_0();
bevt_25_ta_ph = bevp_build.bem_paramsGet_0();
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_24_ta_ph = bevt_25_ta_ph.bem_has_1(bevt_26_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 523*/ {
bevt_28_ta_ph = bevp_build.bem_paramsGet_0();
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_27_ta_ph = bevt_28_ta_ph.bem_get_1(bevt_29_ta_ph);
bevt_1_ta_loop = bevt_27_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 524*/ {
bevt_30_ta_ph = bevt_1_ta_loop.bemd_0(1102233);
if (((BEC_2_5_4_LogicBool) bevt_30_ta_ph).bevi_bool)/* Line: 524*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(199074760);
bevt_31_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_ta_ph.bem_fileGet_0();
bevt_33_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(-1086290012);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_ta_ph.bemd_0(-195620474);
bevt_34_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_34_ta_ph.bemd_0(-910720573);
bevt_35_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 529*/
 else /* Line: 524*/ {
break;
} /* Line: 524*/
} /* Line: 524*/
} /* Line: 524*/
} /* Line: 523*/
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
BEC_2_4_6_TextString bevl_mh = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevp_heow.bem_write_1(bevt_1_ta_ph);
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 547*/ {
bevl_mh = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevl_mh.bem_addValue_1(bevt_6_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevp_heow.bem_write_1(bevl_mh);
} /* Line: 550*/
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStartCi_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 571*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_4_ta_ph = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(beva_belsName);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 572*/
 else /* Line: 571*/ {
bevt_8_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_7_ta_ph = bevt_8_ta_ph.bem_has_1(bevt_9_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 573*/ {
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_11_ta_ph = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_12_ta_ph);
bevt_10_ta_ph = (BEC_2_4_6_TextString) bevt_11_ta_ph.bem_addValue_1(beva_belsName);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_10_ta_ph.bem_addValue_1(bevt_13_ta_ph);
} /* Line: 574*/
} /* Line: 571*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(456949799);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 586*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(1102233);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 586*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(199074760);
if (bevl_first.bevi_bool)/* Line: 587*/ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 588*/
 else /* Line: 589*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevp_ccMethods.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 590*/
bevt_9_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevt_9_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_7_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 592*/
 else /* Line: 586*/ {
break;
} /* Line: 586*/
} /* Line: 586*/
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevl_bein);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_4_ta_ph.bem_addValue_1(bevt_13_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevl_bein;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_runtimeInitGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
bevt_1_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_1_ta_ph.bem_relEmitName_1(bevt_2_ta_ph);
bevt_4_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-350299047);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_13_ta_ph = bem_overrideMtdDecGet_0();
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_11_ta_ph = (BEC_2_4_6_TextString) bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_10_ta_ph = (BEC_2_4_6_TextString) bevt_11_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_9_ta_ph = (BEC_2_4_6_TextString) bevt_10_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevt_9_ta_ph.bem_addValue_1(bevl_oname);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevl_asnr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_20_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_notEquals_1(bevl_oname);
if (bevt_19_ta_ph.bevi_bool)/* Line: 633*/ {
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_21_ta_ph, bevl_asnr);
} /* Line: 634*/
bevt_25_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_24_ta_ph = (BEC_2_4_6_TextString) bevt_25_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_23_ta_ph = (BEC_2_4_6_TextString) bevt_24_ta_ph.bem_addValue_1(bevl_asnr);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_22_ta_ph = (BEC_2_4_6_TextString) bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_28_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_29_ta_ph);
bevt_28_ta_ph.bem_addValue_1(bevp_nl);
bevt_37_ta_ph = bem_overrideMtdDecGet_0();
bevt_36_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph = (BEC_2_4_6_TextString) bevt_36_ta_ph.bem_addValue_1(bevl_oname);
bevt_38_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_34_ta_ph = (BEC_2_4_6_TextString) bevt_35_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_33_ta_ph = (BEC_2_4_6_TextString) bevt_34_ta_ph.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_32_ta_ph = (BEC_2_4_6_TextString) bevt_33_ta_ph.bem_addValue_1(bevt_40_ta_ph);
bevt_31_ta_ph = (BEC_2_4_6_TextString) bevt_32_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_41_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_30_ta_ph = (BEC_2_4_6_TextString) bevt_31_ta_ph.bem_addValue_1(bevt_41_ta_ph);
bevt_30_ta_ph.bem_addValue_1(bevp_nl);
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_44_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_45_ta_ph);
bevt_43_ta_ph = (BEC_2_4_6_TextString) bevt_44_ta_ph.bem_addValue_1(bevl_stinst);
bevt_46_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_42_ta_ph = (BEC_2_4_6_TextString) bevt_43_ta_ph.bem_addValue_1(bevt_46_ta_ph);
bevt_42_ta_ph.bem_addValue_1(bevp_nl);
bevt_48_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_47_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_48_ta_ph);
bevt_47_ta_ph.bem_addValue_1(bevp_nl);
bevt_55_ta_ph = bem_overrideMtdDecGet_0();
bevt_54_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_55_ta_ph);
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_53_ta_ph = (BEC_2_4_6_TextString) bevt_54_ta_ph.bem_addValue_1(bevt_56_ta_ph);
bevt_57_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_52_ta_ph = (BEC_2_4_6_TextString) bevt_53_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_51_ta_ph = (BEC_2_4_6_TextString) bevt_52_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_50_ta_ph = (BEC_2_4_6_TextString) bevt_51_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_59_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_49_ta_ph = (BEC_2_4_6_TextString) bevt_50_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_nl);
bevt_62_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(366972657);
if (bevt_61_ta_ph == null) {
bevt_60_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_60_ta_ph.bevi_bool)/* Line: 653*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 653*/ {
bevt_65_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_64_ta_ph = bevt_65_ta_ph.bemd_0(366972657);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_1(-696336738, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 653*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 653*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 653*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 653*/ {
bevt_67_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevt_66_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_67_ta_ph);
bevt_66_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 654*/
 else /* Line: 655*/ {
bevt_69_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_68_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_69_ta_ph);
bevt_68_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 656*/
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_71_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_70_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_71_ta_ph);
bevt_70_ta_ph.bem_addValue_1(bevp_nl);
bevt_78_ta_ph = bem_overrideMtdDecGet_0();
bevt_77_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_78_ta_ph);
bevt_79_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_76_ta_ph = (BEC_2_4_6_TextString) bevt_77_ta_ph.bem_addValue_1(bevt_79_ta_ph);
bevt_80_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_75_ta_ph = (BEC_2_4_6_TextString) bevt_76_ta_ph.bem_addValue_1(bevt_80_ta_ph);
bevt_81_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_74_ta_ph = (BEC_2_4_6_TextString) bevt_75_ta_ph.bem_addValue_1(bevt_81_ta_ph);
bevt_73_ta_ph = (BEC_2_4_6_TextString) bevt_74_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_82_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_72_ta_ph = (BEC_2_4_6_TextString) bevt_73_ta_ph.bem_addValue_1(bevt_82_ta_ph);
bevt_72_ta_ph.bem_addValue_1(bevp_nl);
bevt_84_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_83_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_84_ta_ph);
bevt_83_ta_ph.bem_addValue_1(bevp_nl);
bevt_86_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_85_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_86_ta_ph);
bevt_85_ta_ph.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_90_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_89_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_90_ta_ph);
bevt_91_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_88_ta_ph = (BEC_2_4_6_TextString) bevt_89_ta_ph.bem_addValue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_87_ta_ph = (BEC_2_4_6_TextString) bevt_88_ta_ph.bem_addValue_1(bevt_92_ta_ph);
bevt_87_ta_ph.bem_addValue_1(bevp_nl);
bevt_96_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevt_95_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_96_ta_ph);
bevt_94_ta_ph = (BEC_2_4_6_TextString) bevt_95_ta_ph.bem_addValue_1(bevl_tinst);
bevt_97_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_93_ta_ph = (BEC_2_4_6_TextString) bevt_94_ta_ph.bem_addValue_1(bevt_97_ta_ph);
bevt_93_ta_ph.bem_addValue_1(bevp_nl);
bevt_99_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_98_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_99_ta_ph);
bevt_98_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_libEmitName);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_libEmitName);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
bevp_heow.bem_write_1(bevt_4_ta_ph);
base.bem_emitLib_0();
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGetDirect_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGetDirect_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGetDirect_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGetDirect_0() {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() {
return bevp_deon;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGetDirect_0() {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() {
return bevp_heon;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGetDirect_0() {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() {
return bevp_deop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGetDirect_0() {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() {
return bevp_heop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGetDirect_0() {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() {
return bevp_deow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGetDirect_0() {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() {
return bevp_heow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGetDirect_0() {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 21, 22, 23, 27, 29, 30, 31, 32, 33, 37, 41, 41, 42, 42, 42, 44, 44, 46, 46, 46, 46, 46, 46, 48, 48, 49, 49, 51, 51, 53, 53, 53, 53, 53, 53, 53, 55, 55, 57, 57, 59, 59, 62, 62, 64, 64, 66, 68, 70, 72, 74, 74, 74, 75, 75, 76, 76, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 85, 85, 85, 86, 86, 87, 87, 89, 89, 89, 89, 89, 89, 91, 91, 91, 91, 91, 91, 93, 93, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 100, 100, 100, 104, 106, 107, 108, 108, 109, 113, 113, 117, 117, 121, 121, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 128, 130, 130, 130, 130, 130, 130, 132, 132, 132, 132, 132, 132, 132, 132, 132, 132, 134, 136, 136, 142, 142, 142, 142, 143, 144, 144, 144, 144, 145, 146, 146, 146, 146, 147, 149, 149, 151, 155, 155, 155, 155, 156, 156, 157, 159, 159, 163, 163, 163, 163, 163, 163, 163, 163, 167, 167, 167, 167, 168, 168, 168, 170, 176, 176, 176, 176, 176, 178, 178, 178, 178, 178, 178, 178, 178, 180, 182, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 188, 193, 193, 193, 194, 195, 195, 195, 195, 195, 195, 197, 197, 197, 197, 197, 197, 197, 197, 197, 197, 201, 201, 201, 202, 202, 202, 202, 202, 204, 204, 204, 204, 204, 204, 204, 209, 209, 210, 212, 212, 212, 213, 215, 218, 218, 218, 218, 218, 218, 218, 218, 223, 223, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 228, 228, 228, 228, 228, 228, 228, 228, 228, 230, 230, 230, 234, 234, 234, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 239, 243, 243, 243, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 248, 252, 252, 252, 252, 252, 253, 253, 253, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 258, 263, 264, 265, 265, 266, 272, 272, 272, 272, 276, 276, 280, 280, 285, 285, 289, 289, 293, 293, 297, 297, 297, 304, 305, 0, 305, 305, 305, 305, 305, 0, 0, 306, 308, 308, 308, 309, 309, 309, 310, 313, 316, 321, 322, 322, 324, 324, 328, 329, 330, 330, 331, 336, 338, 339, 339, 340, 341, 342, 342, 343, 343, 343, 344, 350, 351, 351, 351, 352, 352, 352, 352, 352, 352, 352, 352, 352, 353, 353, 353, 353, 354, 354, 354, 356, 360, 360, 360, 360, 360, 360, 361, 362, 362, 362, 362, 362, 362, 363, 363, 364, 364, 364, 364, 365, 365, 366, 366, 367, 367, 368, 368, 369, 371, 372, 372, 372, 372, 372, 372, 372, 372, 373, 373, 374, 374, 374, 375, 376, 376, 0, 376, 376, 378, 380, 380, 382, 382, 382, 382, 385, 385, 387, 387, 387, 388, 388, 391, 391, 392, 392, 392, 393, 394, 394, 0, 394, 394, 396, 398, 398, 400, 400, 400, 400, 403, 403, 405, 405, 407, 407, 407, 407, 407, 407, 408, 408, 408, 409, 409, 409, 409, 409, 409, 411, 411, 411, 411, 411, 411, 413, 413, 415, 415, 415, 415, 415, 415, 416, 416, 417, 417, 417, 418, 418, 421, 421, 422, 422, 434, 434, 435, 436, 436, 436, 436, 436, 436, 436, 437, 437, 437, 437, 437, 437, 437, 438, 438, 439, 439, 440, 440, 440, 440, 440, 441, 441, 441, 443, 443, 443, 444, 444, 444, 446, 446, 446, 448, 448, 448, 448, 0, 448, 448, 450, 450, 451, 451, 451, 452, 452, 454, 458, 458, 461, 461, 462, 462, 468, 468, 468, 470, 470, 470, 470, 0, 470, 470, 472, 472, 473, 473, 473, 474, 474, 476, 479, 479, 479, 481, 481, 481, 481, 0, 481, 481, 483, 483, 484, 484, 484, 485, 485, 487, 494, 495, 500, 500, 501, 502, 502, 502, 502, 502, 503, 503, 503, 505, 505, 505, 507, 507, 509, 509, 509, 511, 511, 511, 511, 0, 511, 511, 513, 513, 514, 514, 514, 515, 515, 517, 521, 521, 522, 523, 523, 523, 524, 524, 524, 524, 0, 524, 524, 525, 525, 526, 526, 526, 527, 527, 528, 528, 529, 535, 540, 541, 543, 543, 545, 545, 547, 547, 547, 548, 549, 549, 549, 550, 553, 554, 559, 559, 563, 563, 567, 567, 571, 571, 571, 572, 572, 572, 572, 572, 573, 573, 573, 574, 574, 574, 574, 574, 580, 580, 581, 583, 583, 583, 583, 585, 586, 0, 586, 586, 588, 590, 590, 592, 592, 592, 592, 592, 592, 596, 596, 596, 601, 603, 603, 603, 603, 603, 605, 605, 605, 605, 605, 605, 605, 605, 605, 605, 605, 607, 611, 611, 612, 612, 612, 612, 613, 617, 617, 618, 618, 618, 618, 619, 619, 619, 619, 623, 623, 623, 627, 627, 627, 628, 628, 628, 629, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 632, 633, 633, 634, 634, 637, 637, 637, 637, 637, 637, 637, 639, 639, 639, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 647, 647, 647, 647, 647, 647, 650, 650, 650, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 653, 653, 653, 653, 0, 653, 653, 653, 0, 0, 654, 654, 654, 656, 656, 656, 658, 659, 662, 662, 662, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 665, 665, 665, 667, 667, 667, 669, 671, 671, 671, 671, 671, 671, 671, 673, 673, 673, 673, 673, 673, 675, 675, 675, 681, 681, 681, 681, 681, 682, 682, 682, 682, 682, 684, 689, 689, 690, 690, 690, 690, 691, 691, 691, 691, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 189, 254, 259, 260, 261, 262, 265, 266, 268, 269, 270, 271, 272, 273, 274, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 293, 294, 295, 296, 297, 298, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 312, 313, 314, 315, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 343, 344, 345, 346, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 426, 427, 428, 429, 430, 431, 435, 436, 440, 441, 445, 446, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 525, 526, 527, 532, 533, 536, 537, 538, 539, 541, 544, 545, 546, 547, 549, 552, 553, 557, 567, 568, 569, 570, 572, 573, 574, 576, 577, 587, 588, 589, 590, 591, 592, 593, 594, 604, 605, 606, 607, 609, 610, 611, 614, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 751, 752, 757, 758, 759, 760, 761, 762, 765, 766, 767, 768, 769, 770, 771, 789, 790, 792, 795, 796, 797, 799, 802, 805, 806, 807, 808, 809, 810, 811, 812, 816, 817, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 908, 909, 910, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 947, 984, 985, 986, 988, 989, 990, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000, 1001, 1002, 1003, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1023, 1061, 1062, 1063, 1064, 1065, 1066, 1067, 1068, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1101, 1106, 1107, 1108, 1109, 1110, 1117, 1118, 1119, 1120, 1124, 1125, 1129, 1130, 1134, 1135, 1139, 1140, 1144, 1145, 1150, 1151, 1152, 1168, 1169, 1171, 1174, 1175, 1176, 1177, 1182, 1183, 1186, 1190, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1201, 1203, 1211, 1213, 1214, 1216, 1217, 1223, 1225, 1226, 1227, 1228, 1239, 1241, 1242, 1243, 1244, 1245, 1246, 1251, 1252, 1253, 1254, 1255, 1278, 1279, 1280, 1281, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1293, 1294, 1295, 1296, 1297, 1298, 1300, 1393, 1394, 1395, 1396, 1397, 1398, 1399, 1400, 1401, 1402, 1403, 1404, 1405, 1406, 1407, 1408, 1409, 1410, 1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1430, 1431, 1432, 1433, 1434, 1436, 1437, 1438, 1438, 1441, 1443, 1445, 1448, 1449, 1451, 1452, 1453, 1454, 1461, 1462, 1463, 1464, 1465, 1467, 1468, 1470, 1471, 1472, 1473, 1474, 1476, 1477, 1478, 1478, 1481, 1483, 1485, 1488, 1489, 1491, 1492, 1493, 1494, 1501, 1502, 1503, 1504, 1505, 1506, 1507, 1508, 1509, 1510, 1511, 1512, 1513, 1515, 1516, 1517, 1518, 1519, 1520, 1523, 1524, 1525, 1526, 1527, 1528, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1620, 1625, 1626, 1627, 1628, 1629, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1641, 1642, 1643, 1644, 1645, 1646, 1647, 1648, 1653, 1654, 1655, 1656, 1658, 1659, 1660, 1661, 1662, 1663, 1664, 1665, 1666, 1668, 1669, 1670, 1671, 1671, 1674, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1683, 1684, 1691, 1692, 1693, 1694, 1695, 1696, 1697, 1698, 1699, 1701, 1702, 1703, 1704, 1704, 1707, 1709, 1710, 1711, 1712, 1713, 1714, 1715, 1716, 1717, 1724, 1725, 1726, 1728, 1729, 1730, 1731, 1731, 1734, 1736, 1737, 1738, 1739, 1740, 1741, 1742, 1743, 1744, 1755, 1756, 1799, 1804, 1805, 1806, 1807, 1808, 1809, 1814, 1815, 1816, 1817, 1819, 1820, 1821, 1822, 1823, 1824, 1825, 1826, 1828, 1829, 1830, 1831, 1831, 1834, 1836, 1837, 1838, 1839, 1840, 1841, 1842, 1843, 1844, 1851, 1852, 1853, 1854, 1855, 1856, 1858, 1859, 1860, 1861, 1861, 1864, 1866, 1867, 1868, 1869, 1870, 1871, 1872, 1873, 1874, 1875, 1876, 1884, 1895, 1896, 1897, 1898, 1899, 1900, 1901, 1902, 1903, 1905, 1906, 1907, 1908, 1909, 1911, 1912, 1917, 1918, 1922, 1923, 1928, 1929, 1947, 1948, 1949, 1951, 1952, 1953, 1954, 1955, 1958, 1959, 1960, 1962, 1963, 1964, 1965, 1966, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1998, 2001, 2003, 2005, 2008, 2009, 2011, 2012, 2013, 2014, 2015, 2016, 2022, 2023, 2024, 2044, 2045, 2046, 2047, 2048, 2049, 2050, 2051, 2052, 2053, 2054, 2055, 2056, 2057, 2058, 2059, 2060, 2061, 2070, 2071, 2072, 2073, 2074, 2075, 2076, 2088, 2089, 2090, 2091, 2092, 2093, 2094, 2095, 2096, 2097, 2102, 2103, 2104, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2233, 2234, 2235, 2236, 2238, 2239, 2241, 2242, 2243, 2244, 2245, 2246, 2247, 2248, 2249, 2250, 2251, 2252, 2253, 2254, 2255, 2256, 2257, 2258, 2259, 2260, 2261, 2262, 2263, 2264, 2265, 2266, 2267, 2268, 2269, 2270, 2271, 2272, 2273, 2274, 2275, 2276, 2277, 2278, 2279, 2280, 2281, 2282, 2283, 2284, 2285, 2286, 2287, 2292, 2293, 2296, 2297, 2298, 2300, 2303, 2307, 2308, 2309, 2312, 2313, 2314, 2316, 2317, 2318, 2319, 2320, 2321, 2322, 2323, 2324, 2325, 2326, 2327, 2328, 2329, 2330, 2331, 2332, 2333, 2334, 2335, 2336, 2337, 2338, 2339, 2340, 2341, 2342, 2343, 2344, 2345, 2346, 2347, 2348, 2349, 2350, 2351, 2352, 2353, 2354, 2355, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2375, 2376, 2377, 2390, 2391, 2392, 2393, 2394, 2395, 2396, 2397, 2398, 2399, 2402, 2405, 2408, 2412, 2416, 2419, 2422, 2426, 2430, 2433, 2436, 2440, 2444, 2447, 2450, 2454, 2458, 2461, 2464, 2468, 2472, 2475, 2478, 2482, 2486, 2489, 2492, 2496, 2500, 2503, 2506, 2510, 2514, 2517, 2520, 2524, 2528, 2531, 2534, 2538, 2542, 2545, 2548, 2552};
/* BEGIN LINEINFO 
assign 1 17 174
new 0 17 174
assign 1 18 175
new 0 18 175
assign 1 19 176
new 0 19 176
assign 1 21 177
new 0 21 177
assign 1 22 178
new 0 22 178
assign 1 23 179
new 0 23 179
new 1 27 180
assign 1 29 181
new 0 29 181
assign 1 30 182
new 0 30 182
assign 1 31 183
new 0 31 183
assign 1 32 184
new 0 32 184
assign 1 33 185
new 0 33 185
addValue 1 37 189
assign 1 41 254
def 1 41 259
assign 1 42 260
libNameGet 0 42 260
assign 1 42 261
relEmitName 1 42 261
assign 1 42 262
extend 1 42 262
assign 1 44 265
new 0 44 265
assign 1 44 266
extend 1 44 266
assign 1 46 268
new 0 46 268
assign 1 46 269
emitNameGet 0 46 269
assign 1 46 270
addValue 1 46 270
assign 1 46 271
addValue 1 46 271
assign 1 46 272
new 0 46 272
assign 1 46 273
addValue 1 46 273
assign 1 48 274
def 1 48 279
assign 1 49 280
new 0 49 280
addValue 1 49 281
assign 1 51 282
new 0 51 282
addValue 1 51 283
assign 1 53 284
new 0 53 284
assign 1 53 285
addValue 1 53 285
assign 1 53 286
libNameGet 0 53 286
assign 1 53 287
relEmitName 1 53 287
assign 1 53 288
addValue 1 53 288
assign 1 53 289
new 0 53 289
addValue 1 53 290
assign 1 55 293
new 0 55 293
addValue 1 55 294
assign 1 57 295
new 0 57 295
addValue 1 57 296
assign 1 59 297
new 0 59 297
addValue 1 59 298
assign 1 62 300
new 0 62 300
addValue 1 62 301
assign 1 64 302
new 0 64 302
addValue 1 64 303
write 1 66 304
write 1 68 305
write 1 70 306
clear 0 72 307
assign 1 74 308
emitChecksGet 0 74 308
assign 1 74 309
new 0 74 309
assign 1 74 310
has 1 74 310
assign 1 75 312
new 0 75 312
write 1 75 313
assign 1 76 314
new 0 76 314
write 1 76 315
assign 1 78 317
new 0 78 317
write 1 78 318
assign 1 79 319
new 0 79 319
assign 1 79 320
emitNameGet 0 79 320
assign 1 79 321
add 1 79 321
assign 1 79 322
new 0 79 322
assign 1 79 323
add 1 79 323
assign 1 79 324
getHeaderInitialInst 1 79 324
assign 1 79 325
add 1 79 325
assign 1 79 326
new 0 79 326
assign 1 79 327
add 1 79 327
write 1 79 328
assign 1 80 329
new 0 80 329
write 1 80 330
assign 1 81 331
new 0 81 331
write 1 81 332
assign 1 82 333
new 0 82 333
write 1 82 334
assign 1 83 335
new 0 83 335
write 1 83 336
assign 1 84 337
new 0 84 337
write 1 84 338
assign 1 85 339
emitChecksGet 0 85 339
assign 1 85 340
new 0 85 340
assign 1 85 341
has 1 85 341
assign 1 86 343
new 0 86 343
write 1 86 344
assign 1 87 345
new 0 87 345
write 1 87 346
assign 1 89 348
new 0 89 348
assign 1 89 349
emitNameGet 0 89 349
assign 1 89 350
add 1 89 350
assign 1 89 351
new 0 89 351
assign 1 89 352
add 1 89 352
write 1 89 353
assign 1 91 354
new 0 91 354
assign 1 91 355
emitNameGet 0 91 355
assign 1 91 356
add 1 91 356
assign 1 91 357
new 0 91 357
assign 1 91 358
add 1 91 358
write 1 91 359
assign 1 93 360
new 0 93 360
return 1 93 361
assign 1 97 391
overrideMtdDecGet 0 97 391
assign 1 97 392
addValue 1 97 392
assign 1 97 393
getClassConfig 1 97 393
assign 1 97 394
libNameGet 0 97 394
assign 1 97 395
relEmitName 1 97 395
assign 1 97 396
addValue 1 97 396
assign 1 97 397
new 0 97 397
assign 1 97 398
addValue 1 97 398
assign 1 97 399
emitNameGet 0 97 399
assign 1 97 400
addValue 1 97 400
assign 1 97 401
new 0 97 401
assign 1 97 402
addValue 1 97 402
assign 1 97 403
addValue 1 97 403
assign 1 97 404
new 0 97 404
assign 1 97 405
addValue 1 97 405
addValue 1 97 406
assign 1 98 407
new 0 98 407
assign 1 98 408
addValue 1 98 408
assign 1 98 409
heldGet 0 98 409
assign 1 98 410
namepathGet 0 98 410
assign 1 98 411
getClassConfig 1 98 411
assign 1 98 412
libNameGet 0 98 412
assign 1 98 413
relEmitName 1 98 413
assign 1 98 414
addValue 1 98 414
assign 1 98 415
new 0 98 415
assign 1 98 416
addValue 1 98 416
addValue 1 98 417
assign 1 100 418
new 0 100 418
assign 1 100 419
addValue 1 100 419
addValue 1 100 420
assign 1 104 426
new 0 104 426
write 1 106 427
clear 0 107 428
assign 1 108 429
new 0 108 429
write 1 108 430
return 1 109 431
assign 1 113 435
new 0 113 435
return 1 113 436
assign 1 117 440
new 0 117 440
return 1 117 441
assign 1 121 445
new 0 121 445
return 1 121 446
assign 1 126 476
addValue 1 126 476
assign 1 126 477
libNameGet 0 126 477
assign 1 126 478
relEmitName 1 126 478
assign 1 126 479
addValue 1 126 479
assign 1 126 480
new 0 126 480
assign 1 126 481
addValue 1 126 481
assign 1 126 482
emitNameGet 0 126 482
assign 1 126 483
addValue 1 126 483
assign 1 126 484
new 0 126 484
assign 1 126 485
addValue 1 126 485
assign 1 126 486
addValue 1 126 486
assign 1 126 487
new 0 126 487
addValue 1 126 488
addValue 1 128 489
assign 1 130 490
new 0 130 490
assign 1 130 491
addValue 1 130 491
assign 1 130 492
addValue 1 130 492
assign 1 130 493
new 0 130 493
assign 1 130 494
addValue 1 130 494
addValue 1 130 495
assign 1 132 496
new 0 132 496
assign 1 132 497
addValue 1 132 497
assign 1 132 498
libNameGet 0 132 498
assign 1 132 499
relEmitName 1 132 499
assign 1 132 500
addValue 1 132 500
assign 1 132 501
new 0 132 501
assign 1 132 502
addValue 1 132 502
assign 1 132 503
addValue 1 132 503
assign 1 132 504
new 0 132 504
addValue 1 132 505
addValue 1 134 506
assign 1 136 507
new 0 136 507
addValue 1 136 508
assign 1 142 525
typenameGet 0 142 525
assign 1 142 526
NULLGet 0 142 526
assign 1 142 527
equals 1 142 532
assign 1 143 533
new 0 143 533
assign 1 144 536
heldGet 0 144 536
assign 1 144 537
nameGet 0 144 537
assign 1 144 538
new 0 144 538
assign 1 144 539
equals 1 144 539
assign 1 145 541
new 0 145 541
assign 1 146 544
heldGet 0 146 544
assign 1 146 545
nameGet 0 146 545
assign 1 146 546
new 0 146 546
assign 1 146 547
equals 1 146 547
assign 1 147 549
new 0 147 549
assign 1 149 552
heldGet 0 149 552
assign 1 149 553
nameForVar 1 149 553
return 1 151 557
assign 1 155 567
heldGet 0 155 567
assign 1 155 568
nameGet 0 155 568
assign 1 155 569
new 0 155 569
assign 1 155 570
equals 1 155 570
assign 1 156 572
new 0 156 572
assign 1 156 573
add 1 156 573
return 1 157 574
assign 1 159 576
formCallTarg 1 159 576
return 1 159 577
assign 1 163 587
new 0 163 587
assign 1 163 588
addValue 1 163 588
assign 1 163 589
secondGet 0 163 589
assign 1 163 590
formTarg 1 163 590
assign 1 163 591
addValue 1 163 591
assign 1 163 592
new 0 163 592
assign 1 163 593
addValue 1 163 593
addValue 1 163 594
assign 1 167 604
heldGet 0 167 604
assign 1 167 605
langsGet 0 167 605
assign 1 167 606
new 0 167 606
assign 1 167 607
has 1 167 607
assign 1 168 609
heldGet 0 168 609
assign 1 168 610
textGet 0 168 610
addValue 1 168 611
handleClassEmit 1 170 614
assign 1 176 656
new 0 176 656
assign 1 176 657
emitNameGet 0 176 657
assign 1 176 658
add 1 176 658
assign 1 176 659
new 0 176 659
assign 1 176 660
add 1 176 660
assign 1 178 661
new 0 178 661
assign 1 178 662
typeEmitNameGet 0 178 662
assign 1 178 663
add 1 178 663
assign 1 178 664
new 0 178 664
assign 1 178 665
add 1 178 665
assign 1 178 666
add 1 178 666
assign 1 178 667
new 0 178 667
assign 1 178 668
add 1 178 668
addClassHeader 1 180 669
assign 1 182 670
new 0 182 670
assign 1 184 671
typeEmitNameGet 0 184 671
assign 1 184 672
addValue 1 184 672
assign 1 184 673
new 0 184 673
assign 1 184 674
addValue 1 184 674
assign 1 184 675
emitNameGet 0 184 675
assign 1 184 676
addValue 1 184 676
assign 1 184 677
new 0 184 677
assign 1 184 678
addValue 1 184 678
assign 1 184 679
addValue 1 184 679
assign 1 184 680
new 0 184 680
addValue 1 184 681
assign 1 186 682
new 0 186 682
assign 1 186 683
addValue 1 186 683
assign 1 186 684
typeEmitNameGet 0 186 684
assign 1 186 685
addValue 1 186 685
assign 1 186 686
new 0 186 686
assign 1 186 687
addValue 1 186 687
assign 1 186 688
emitNameGet 0 186 688
assign 1 186 689
addValue 1 186 689
assign 1 186 690
new 0 186 690
assign 1 186 691
emitNameGet 0 186 691
assign 1 186 692
add 1 186 692
assign 1 186 693
new 0 186 693
assign 1 186 694
add 1 186 694
addValue 1 186 695
return 1 188 696
assign 1 193 716
new 0 193 716
assign 1 193 717
toString 0 193 717
assign 1 193 718
add 1 193 718
incrementValue 0 194 719
assign 1 195 720
new 0 195 720
assign 1 195 721
addValue 1 195 721
assign 1 195 722
addValue 1 195 722
assign 1 195 723
new 0 195 723
assign 1 195 724
addValue 1 195 724
addValue 1 195 725
assign 1 197 726
containedGet 0 197 726
assign 1 197 727
firstGet 0 197 727
assign 1 197 728
containedGet 0 197 728
assign 1 197 729
firstGet 0 197 729
assign 1 197 730
new 0 197 730
assign 1 197 731
add 1 197 731
assign 1 197 732
new 0 197 732
assign 1 197 733
add 1 197 733
assign 1 197 734
finalAssign 4 197 734
addValue 1 197 735
assign 1 201 751
isTypedGet 0 201 751
assign 1 201 752
not 0 201 757
assign 1 202 758
libNameGet 0 202 758
assign 1 202 759
relEmitName 1 202 759
assign 1 202 760
addValue 1 202 760
assign 1 202 761
new 0 202 761
addValue 1 202 762
assign 1 204 765
namepathGet 0 204 765
assign 1 204 766
getClassConfig 1 204 766
assign 1 204 767
libNameGet 0 204 767
assign 1 204 768
relEmitName 1 204 768
assign 1 204 769
addValue 1 204 769
assign 1 204 770
new 0 204 770
addValue 1 204 771
assign 1 209 789
new 0 209 789
assign 1 209 790
equals 1 209 790
assign 1 210 792
new 0 210 792
assign 1 212 795
emitChecksGet 0 212 795
assign 1 212 796
new 0 212 796
assign 1 212 797
has 1 212 797
assign 1 213 799
new 0 213 799
assign 1 215 802
new 0 215 802
assign 1 218 805
new 0 218 805
assign 1 218 806
add 1 218 806
assign 1 218 807
libNameGet 0 218 807
assign 1 218 808
relEmitName 1 218 808
assign 1 218 809
add 1 218 809
assign 1 218 810
new 0 218 810
assign 1 218 811
add 1 218 811
return 1 218 812
assign 1 223 816
new 0 223 816
return 1 223 817
assign 1 227 844
overrideMtdDecGet 0 227 844
assign 1 227 845
addValue 1 227 845
assign 1 227 846
new 0 227 846
assign 1 227 847
addValue 1 227 847
assign 1 227 848
emitNameGet 0 227 848
assign 1 227 849
addValue 1 227 849
assign 1 227 850
new 0 227 850
assign 1 227 851
addValue 1 227 851
assign 1 227 852
addValue 1 227 852
assign 1 227 853
new 0 227 853
assign 1 227 854
addValue 1 227 854
assign 1 227 855
addValue 1 227 855
assign 1 227 856
new 0 227 856
assign 1 227 857
addValue 1 227 857
addValue 1 227 858
assign 1 228 859
new 0 228 859
assign 1 228 860
addValue 1 228 860
assign 1 228 861
addValue 1 228 861
assign 1 228 862
new 0 228 862
assign 1 228 863
addValue 1 228 863
assign 1 228 864
addValue 1 228 864
assign 1 228 865
new 0 228 865
assign 1 228 866
addValue 1 228 866
addValue 1 228 867
assign 1 230 868
new 0 230 868
assign 1 230 869
addValue 1 230 869
addValue 1 230 870
assign 1 234 908
emitChecksGet 0 234 908
assign 1 234 909
new 0 234 909
assign 1 234 910
has 1 234 910
assign 1 235 912
new 0 235 912
assign 1 235 913
libNameGet 0 235 913
assign 1 235 914
relEmitName 1 235 914
assign 1 235 915
add 1 235 915
assign 1 235 916
new 0 235 916
assign 1 235 917
add 1 235 917
assign 1 235 918
libNameGet 0 235 918
assign 1 235 919
relEmitName 1 235 919
assign 1 235 920
add 1 235 920
assign 1 235 921
new 0 235 921
assign 1 235 922
add 1 235 922
assign 1 235 923
heldGet 0 235 923
assign 1 235 924
literalValueGet 0 235 924
assign 1 235 925
add 1 235 925
assign 1 235 926
new 0 235 926
assign 1 235 927
add 1 235 927
assign 1 237 930
new 0 237 930
assign 1 237 931
libNameGet 0 237 931
assign 1 237 932
relEmitName 1 237 932
assign 1 237 933
add 1 237 933
assign 1 237 934
new 0 237 934
assign 1 237 935
add 1 237 935
assign 1 237 936
libNameGet 0 237 936
assign 1 237 937
relEmitName 1 237 937
assign 1 237 938
add 1 237 938
assign 1 237 939
new 0 237 939
assign 1 237 940
add 1 237 940
assign 1 237 941
heldGet 0 237 941
assign 1 237 942
literalValueGet 0 237 942
assign 1 237 943
add 1 237 943
assign 1 237 944
new 0 237 944
assign 1 237 945
add 1 237 945
return 1 239 947
assign 1 243 984
emitChecksGet 0 243 984
assign 1 243 985
new 0 243 985
assign 1 243 986
has 1 243 986
assign 1 244 988
new 0 244 988
assign 1 244 989
libNameGet 0 244 989
assign 1 244 990
relEmitName 1 244 990
assign 1 244 991
add 1 244 991
assign 1 244 992
new 0 244 992
assign 1 244 993
add 1 244 993
assign 1 244 994
libNameGet 0 244 994
assign 1 244 995
relEmitName 1 244 995
assign 1 244 996
add 1 244 996
assign 1 244 997
new 0 244 997
assign 1 244 998
add 1 244 998
assign 1 244 999
heldGet 0 244 999
assign 1 244 1000
literalValueGet 0 244 1000
assign 1 244 1001
add 1 244 1001
assign 1 244 1002
new 0 244 1002
assign 1 244 1003
add 1 244 1003
assign 1 246 1006
new 0 246 1006
assign 1 246 1007
libNameGet 0 246 1007
assign 1 246 1008
relEmitName 1 246 1008
assign 1 246 1009
add 1 246 1009
assign 1 246 1010
new 0 246 1010
assign 1 246 1011
add 1 246 1011
assign 1 246 1012
libNameGet 0 246 1012
assign 1 246 1013
relEmitName 1 246 1013
assign 1 246 1014
add 1 246 1014
assign 1 246 1015
new 0 246 1015
assign 1 246 1016
add 1 246 1016
assign 1 246 1017
heldGet 0 246 1017
assign 1 246 1018
literalValueGet 0 246 1018
assign 1 246 1019
add 1 246 1019
assign 1 246 1020
new 0 246 1020
assign 1 246 1021
add 1 246 1021
return 1 248 1023
assign 1 252 1061
new 0 252 1061
assign 1 252 1062
add 1 252 1062
assign 1 252 1063
new 0 252 1063
assign 1 252 1064
add 1 252 1064
assign 1 252 1065
add 1 252 1065
assign 1 253 1066
emitChecksGet 0 253 1066
assign 1 253 1067
new 0 253 1067
assign 1 253 1068
has 1 253 1068
assign 1 254 1070
new 0 254 1070
assign 1 254 1071
libNameGet 0 254 1071
assign 1 254 1072
relEmitName 1 254 1072
assign 1 254 1073
add 1 254 1073
assign 1 254 1074
new 0 254 1074
assign 1 254 1075
add 1 254 1075
assign 1 254 1076
libNameGet 0 254 1076
assign 1 254 1077
relEmitName 1 254 1077
assign 1 254 1078
add 1 254 1078
assign 1 254 1079
new 0 254 1079
assign 1 254 1080
add 1 254 1080
assign 1 254 1081
add 1 254 1081
assign 1 254 1082
new 0 254 1082
assign 1 254 1083
add 1 254 1083
assign 1 256 1086
new 0 256 1086
assign 1 256 1087
libNameGet 0 256 1087
assign 1 256 1088
relEmitName 1 256 1088
assign 1 256 1089
add 1 256 1089
assign 1 256 1090
new 0 256 1090
assign 1 256 1091
add 1 256 1091
assign 1 256 1092
libNameGet 0 256 1092
assign 1 256 1093
relEmitName 1 256 1093
assign 1 256 1094
add 1 256 1094
assign 1 256 1095
new 0 256 1095
assign 1 256 1096
add 1 256 1096
assign 1 256 1097
add 1 256 1097
assign 1 256 1098
new 0 256 1098
assign 1 256 1099
add 1 256 1099
return 1 258 1101
getCode 2 263 1106
assign 1 264 1107
toHexString 1 264 1107
assign 1 265 1108
new 0 265 1108
addValue 1 265 1109
addValue 1 266 1110
assign 1 272 1117
new 0 272 1117
assign 1 272 1118
add 1 272 1118
assign 1 272 1119
add 1 272 1119
return 1 272 1120
assign 1 276 1124
new 0 276 1124
return 1 276 1125
assign 1 280 1129
new 0 280 1129
return 1 280 1130
assign 1 285 1134
new 0 285 1134
return 1 285 1135
assign 1 289 1139
new 0 289 1139
return 1 289 1140
assign 1 293 1144
new 0 293 1144
return 1 293 1145
assign 1 297 1150
new 0 297 1150
assign 1 297 1151
add 1 297 1151
return 1 297 1152
assign 1 304 1168
assign 1 305 1169
singleCCGet 0 305 1169
assign 1 0 1171
assign 1 305 1174
classPathGet 0 305 1174
assign 1 305 1175
fileGet 0 305 1175
assign 1 305 1176
existsGet 0 305 1176
assign 1 305 1177
not 0 305 1182
assign 1 0 1183
assign 1 0 1186
return 1 306 1190
assign 1 308 1193
classPathGet 0 308 1193
assign 1 308 1194
fileGet 0 308 1194
assign 1 308 1195
lastUpdatedGet 0 308 1195
assign 1 309 1196
fromFileGet 0 309 1196
assign 1 309 1197
fileGet 0 309 1197
assign 1 309 1198
lastUpdatedGet 0 309 1198
assign 1 310 1199
greater 1 310 1199
return 1 313 1201
assign 1 316 1203
assign 1 321 1211
singleCCGet 0 321 1211
assign 1 322 1213
getLibOutput 0 322 1213
return 1 322 1214
assign 1 324 1216
getClassOutput 0 324 1216
return 1 324 1217
assign 1 328 1223
singleCCGet 0 328 1223
assign 1 329 1225
new 0 329 1225
assign 1 330 1226
countLines 1 330 1226
addValue 1 330 1227
write 1 331 1228
assign 1 336 1239
singleCCGet 0 336 1239
assign 1 338 1241
new 0 338 1241
assign 1 339 1242
countLines 1 339 1242
addValue 1 339 1243
write 1 340 1244
close 0 341 1245
assign 1 342 1246
def 1 342 1251
assign 1 343 1252
pathGet 0 343 1252
assign 1 343 1253
fileGet 0 343 1253
lastUpdatedSet 1 343 1254
assign 1 344 1255
assign 1 350 1278
new 0 350 1278
assign 1 351 1279
emitChecksGet 0 351 1279
assign 1 351 1280
new 0 351 1280
assign 1 351 1281
has 1 351 1281
assign 1 352 1283
new 0 352 1283
assign 1 352 1284
addValue 1 352 1284
assign 1 352 1285
addValue 1 352 1285
assign 1 352 1286
new 0 352 1286
assign 1 352 1287
addValue 1 352 1287
assign 1 352 1288
addValue 1 352 1288
assign 1 352 1289
new 0 352 1289
assign 1 352 1290
addValue 1 352 1290
addValue 1 352 1291
assign 1 353 1292
addValue 1 353 1292
assign 1 353 1293
new 0 353 1293
assign 1 353 1294
addValue 1 353 1294
addValue 1 353 1295
assign 1 354 1296
new 0 354 1296
assign 1 354 1297
addValue 1 354 1297
addValue 1 354 1298
return 1 356 1300
assign 1 360 1393
new 0 360 1393
assign 1 360 1394
typeEmitNameGet 0 360 1394
assign 1 360 1395
add 1 360 1395
assign 1 360 1396
new 0 360 1396
assign 1 360 1397
add 1 360 1397
write 1 360 1398
assign 1 361 1399
new 0 361 1399
assign 1 362 1400
new 0 362 1400
assign 1 362 1401
addValue 1 362 1401
assign 1 362 1402
typeEmitNameGet 0 362 1402
assign 1 362 1403
addValue 1 362 1403
assign 1 362 1404
new 0 362 1404
addValue 1 362 1405
assign 1 363 1406
new 0 363 1406
addValue 1 363 1407
assign 1 364 1408
typeEmitNameGet 0 364 1408
assign 1 364 1409
addValue 1 364 1409
assign 1 364 1410
new 0 364 1410
addValue 1 364 1411
assign 1 365 1412
new 0 365 1412
addValue 1 365 1413
assign 1 366 1414
new 0 366 1414
addValue 1 366 1415
assign 1 367 1416
new 0 367 1416
addValue 1 367 1417
assign 1 368 1418
new 0 368 1418
addValue 1 368 1419
write 1 369 1420
assign 1 371 1421
new 0 371 1421
assign 1 372 1422
typeEmitNameGet 0 372 1422
assign 1 372 1423
addValue 1 372 1423
assign 1 372 1424
new 0 372 1424
assign 1 372 1425
addValue 1 372 1425
assign 1 372 1426
typeEmitNameGet 0 372 1426
assign 1 372 1427
addValue 1 372 1427
assign 1 372 1428
new 0 372 1428
addValue 1 372 1429
assign 1 373 1430
new 0 373 1430
addValue 1 373 1431
assign 1 374 1432
emitChecksGet 0 374 1432
assign 1 374 1433
new 0 374 1433
assign 1 374 1434
has 1 374 1434
assign 1 375 1436
new 0 375 1436
assign 1 376 1437
mtdListGet 0 376 1437
assign 1 376 1438
iteratorGet 0 0 1438
assign 1 376 1441
hasNextGet 0 376 1441
assign 1 376 1443
nextGet 0 376 1443
assign 1 378 1445
new 0 378 1445
assign 1 380 1448
new 0 380 1448
addValue 1 380 1449
assign 1 382 1451
addValue 1 382 1451
assign 1 382 1452
nameGet 0 382 1452
assign 1 382 1453
addValue 1 382 1453
addValue 1 382 1454
assign 1 385 1461
new 0 385 1461
addValue 1 385 1462
assign 1 387 1463
emitChecksGet 0 387 1463
assign 1 387 1464
new 0 387 1464
assign 1 387 1465
has 1 387 1465
assign 1 388 1467
new 0 388 1467
addValue 1 388 1468
assign 1 391 1470
new 0 391 1470
addValue 1 391 1471
assign 1 392 1472
emitChecksGet 0 392 1472
assign 1 392 1473
new 0 392 1473
assign 1 392 1474
has 1 392 1474
assign 1 393 1476
new 0 393 1476
assign 1 394 1477
ptyListGet 0 394 1477
assign 1 394 1478
iteratorGet 0 0 1478
assign 1 394 1481
hasNextGet 0 394 1481
assign 1 394 1483
nextGet 0 394 1483
assign 1 396 1485
new 0 396 1485
assign 1 398 1488
new 0 398 1488
addValue 1 398 1489
assign 1 400 1491
addValue 1 400 1491
assign 1 400 1492
nameGet 0 400 1492
assign 1 400 1493
addValue 1 400 1493
addValue 1 400 1494
assign 1 403 1501
new 0 403 1501
addValue 1 403 1502
assign 1 405 1503
new 0 405 1503
addValue 1 405 1504
assign 1 407 1505
new 0 407 1505
assign 1 407 1506
addValue 1 407 1506
assign 1 407 1507
typeEmitNameGet 0 407 1507
assign 1 407 1508
addValue 1 407 1508
assign 1 407 1509
new 0 407 1509
addValue 1 407 1510
assign 1 408 1511
emitNameGet 0 408 1511
assign 1 408 1512
new 0 408 1512
assign 1 408 1513
equals 1 408 1513
assign 1 409 1515
new 0 409 1515
assign 1 409 1516
addValue 1 409 1516
assign 1 409 1517
emitNameGet 0 409 1517
assign 1 409 1518
addValue 1 409 1518
assign 1 409 1519
new 0 409 1519
addValue 1 409 1520
assign 1 411 1523
new 0 411 1523
assign 1 411 1524
addValue 1 411 1524
assign 1 411 1525
emitNameGet 0 411 1525
assign 1 411 1526
addValue 1 411 1526
assign 1 411 1527
new 0 411 1527
addValue 1 411 1528
assign 1 413 1530
new 0 413 1530
addValue 1 413 1531
assign 1 415 1532
new 0 415 1532
assign 1 415 1533
addValue 1 415 1533
assign 1 415 1534
typeEmitNameGet 0 415 1534
assign 1 415 1535
addValue 1 415 1535
assign 1 415 1536
new 0 415 1536
addValue 1 415 1537
assign 1 416 1538
new 0 416 1538
addValue 1 416 1539
assign 1 417 1540
new 0 417 1540
assign 1 417 1541
genMark 1 417 1541
addValue 1 417 1542
assign 1 418 1543
new 0 418 1543
addValue 1 418 1544
assign 1 421 1545
getClassOutput 0 421 1545
write 1 421 1546
assign 1 422 1547
countLines 1 422 1547
addValue 1 422 1548
assign 1 434 1620
undef 1 434 1625
assign 1 435 1626
libNameGet 0 435 1626
assign 1 436 1627
new 0 436 1627
assign 1 436 1628
sizeGet 0 436 1628
assign 1 436 1629
add 1 436 1629
assign 1 436 1630
new 0 436 1630
assign 1 436 1631
add 1 436 1631
assign 1 436 1632
add 1 436 1632
assign 1 436 1633
add 1 436 1633
assign 1 437 1634
new 0 437 1634
assign 1 437 1635
sizeGet 0 437 1635
assign 1 437 1636
add 1 437 1636
assign 1 437 1637
new 0 437 1637
assign 1 437 1638
add 1 437 1638
assign 1 437 1639
add 1 437 1639
assign 1 437 1640
add 1 437 1640
assign 1 438 1641
parentGet 0 438 1641
assign 1 438 1642
addStep 1 438 1642
assign 1 439 1643
parentGet 0 439 1643
assign 1 439 1644
addStep 1 439 1644
assign 1 440 1645
parentGet 0 440 1645
assign 1 440 1646
fileGet 0 440 1646
assign 1 440 1647
existsGet 0 440 1647
assign 1 440 1648
not 0 440 1653
assign 1 441 1654
parentGet 0 441 1654
assign 1 441 1655
fileGet 0 441 1655
makeDirs 0 441 1656
assign 1 443 1658
fileGet 0 443 1658
assign 1 443 1659
writerGet 0 443 1659
assign 1 443 1660
open 0 443 1660
assign 1 444 1661
fileGet 0 444 1661
assign 1 444 1662
writerGet 0 444 1662
assign 1 444 1663
open 0 444 1663
assign 1 446 1664
paramsGet 0 446 1664
assign 1 446 1665
new 0 446 1665
assign 1 446 1666
has 1 446 1666
assign 1 448 1668
paramsGet 0 448 1668
assign 1 448 1669
new 0 448 1669
assign 1 448 1670
get 1 448 1670
assign 1 448 1671
iteratorGet 0 0 1671
assign 1 448 1674
hasNextGet 0 448 1674
assign 1 448 1676
nextGet 0 448 1676
assign 1 450 1677
apNew 1 450 1677
assign 1 450 1678
fileGet 0 450 1678
assign 1 451 1679
readerGet 0 451 1679
assign 1 451 1680
open 0 451 1680
assign 1 451 1681
readString 0 451 1681
assign 1 452 1682
readerGet 0 452 1682
close 0 452 1683
write 1 454 1684
assign 1 458 1691
new 0 458 1691
write 1 458 1692
assign 1 461 1693
new 0 461 1693
write 1 461 1694
assign 1 462 1695
new 0 462 1695
write 1 462 1696
assign 1 468 1697
paramsGet 0 468 1697
assign 1 468 1698
new 0 468 1698
assign 1 468 1699
has 1 468 1699
assign 1 470 1701
paramsGet 0 470 1701
assign 1 470 1702
new 0 470 1702
assign 1 470 1703
get 1 470 1703
assign 1 470 1704
iteratorGet 0 0 1704
assign 1 470 1707
hasNextGet 0 470 1707
assign 1 470 1709
nextGet 0 470 1709
assign 1 472 1710
apNew 1 472 1710
assign 1 472 1711
fileGet 0 472 1711
assign 1 473 1712
readerGet 0 473 1712
assign 1 473 1713
open 0 473 1713
assign 1 473 1714
readString 0 473 1714
assign 1 474 1715
readerGet 0 474 1715
close 0 474 1716
write 1 476 1717
assign 1 479 1724
paramsGet 0 479 1724
assign 1 479 1725
new 0 479 1725
assign 1 479 1726
has 1 479 1726
assign 1 481 1728
paramsGet 0 481 1728
assign 1 481 1729
new 0 481 1729
assign 1 481 1730
get 1 481 1730
assign 1 481 1731
iteratorGet 0 0 1731
assign 1 481 1734
hasNextGet 0 481 1734
assign 1 481 1736
nextGet 0 481 1736
assign 1 483 1737
apNew 1 483 1737
assign 1 483 1738
fileGet 0 483 1738
assign 1 484 1739
readerGet 0 484 1739
assign 1 484 1740
open 0 484 1740
assign 1 484 1741
readString 0 484 1741
assign 1 485 1742
readerGet 0 485 1742
close 0 485 1743
write 1 487 1744
begin 1 494 1755
prepHeaderOutput 0 495 1756
assign 1 500 1799
undef 1 500 1804
assign 1 501 1805
new 0 501 1805
assign 1 502 1806
parentGet 0 502 1806
assign 1 502 1807
fileGet 0 502 1807
assign 1 502 1808
existsGet 0 502 1808
assign 1 502 1809
not 0 502 1814
assign 1 503 1815
parentGet 0 503 1815
assign 1 503 1816
fileGet 0 503 1816
makeDirs 0 503 1817
assign 1 505 1819
fileGet 0 505 1819
assign 1 505 1820
writerGet 0 505 1820
assign 1 505 1821
open 0 505 1821
assign 1 507 1822
new 0 507 1822
write 1 507 1823
assign 1 509 1824
paramsGet 0 509 1824
assign 1 509 1825
new 0 509 1825
assign 1 509 1826
has 1 509 1826
assign 1 511 1828
paramsGet 0 511 1828
assign 1 511 1829
new 0 511 1829
assign 1 511 1830
get 1 511 1830
assign 1 511 1831
iteratorGet 0 0 1831
assign 1 511 1834
hasNextGet 0 511 1834
assign 1 511 1836
nextGet 0 511 1836
assign 1 513 1837
apNew 1 513 1837
assign 1 513 1838
fileGet 0 513 1838
assign 1 514 1839
readerGet 0 514 1839
assign 1 514 1840
open 0 514 1840
assign 1 514 1841
readString 0 514 1841
assign 1 515 1842
readerGet 0 515 1842
close 0 515 1843
write 1 517 1844
assign 1 521 1851
new 0 521 1851
write 1 521 1852
increment 0 522 1853
assign 1 523 1854
paramsGet 0 523 1854
assign 1 523 1855
new 0 523 1855
assign 1 523 1856
has 1 523 1856
assign 1 524 1858
paramsGet 0 524 1858
assign 1 524 1859
new 0 524 1859
assign 1 524 1860
get 1 524 1860
assign 1 524 1861
iteratorGet 0 0 1861
assign 1 524 1864
hasNextGet 0 524 1864
assign 1 524 1866
nextGet 0 524 1866
assign 1 525 1867
apNew 1 525 1867
assign 1 525 1868
fileGet 0 525 1868
assign 1 526 1869
readerGet 0 526 1869
assign 1 526 1870
open 0 526 1870
assign 1 526 1871
readString 0 526 1871
assign 1 527 1872
readerGet 0 527 1872
close 0 527 1873
assign 1 528 1874
countLines 1 528 1874
addValue 1 528 1875
write 1 529 1876
return 1 535 1884
close 0 540 1895
assign 1 541 1896
assign 1 543 1897
new 0 543 1897
write 1 543 1898
assign 1 545 1899
new 0 545 1899
write 1 545 1900
assign 1 547 1901
emitChecksGet 0 547 1901
assign 1 547 1902
new 0 547 1902
assign 1 547 1903
has 1 547 1903
assign 1 548 1905
new 0 548 1905
assign 1 549 1906
new 0 549 1906
assign 1 549 1907
addValue 1 549 1907
addValue 1 549 1908
write 1 550 1909
close 0 553 1911
close 0 554 1912
assign 1 559 1917
new 0 559 1917
return 1 559 1918
assign 1 563 1922
new 0 563 1922
addValue 1 563 1923
assign 1 567 1928
new 0 567 1928
addValue 1 567 1929
assign 1 571 1947
emitChecksGet 0 571 1947
assign 1 571 1948
new 0 571 1948
assign 1 571 1949
has 1 571 1949
assign 1 572 1951
new 0 572 1951
assign 1 572 1952
addValue 1 572 1952
assign 1 572 1953
addValue 1 572 1953
assign 1 572 1954
new 0 572 1954
addValue 1 572 1955
assign 1 573 1958
emitChecksGet 0 573 1958
assign 1 573 1959
new 0 573 1959
assign 1 573 1960
has 1 573 1960
assign 1 574 1962
new 0 574 1962
assign 1 574 1963
addValue 1 574 1963
assign 1 574 1964
addValue 1 574 1964
assign 1 574 1965
new 0 574 1965
addValue 1 574 1966
assign 1 580 1990
heldGet 0 580 1990
assign 1 580 1991
synGet 0 580 1991
assign 1 581 1992
ptyListGet 0 581 1992
assign 1 583 1993
emitNameGet 0 583 1993
assign 1 583 1994
addValue 1 583 1994
assign 1 583 1995
new 0 583 1995
addValue 1 583 1996
assign 1 585 1997
new 0 585 1997
assign 1 586 1998
iteratorGet 0 0 1998
assign 1 586 2001
hasNextGet 0 586 2001
assign 1 586 2003
nextGet 0 586 2003
assign 1 588 2005
new 0 588 2005
assign 1 590 2008
new 0 590 2008
addValue 1 590 2009
assign 1 592 2011
addValue 1 592 2011
assign 1 592 2012
new 0 592 2012
assign 1 592 2013
addValue 1 592 2013
assign 1 592 2014
nameGet 0 592 2014
assign 1 592 2015
addValue 1 592 2015
addValue 1 592 2016
assign 1 596 2022
new 0 596 2022
assign 1 596 2023
addValue 1 596 2023
addValue 1 596 2024
assign 1 601 2044
new 0 601 2044
assign 1 603 2045
new 0 603 2045
assign 1 603 2046
emitNameGet 0 603 2046
assign 1 603 2047
add 1 603 2047
assign 1 603 2048
new 0 603 2048
assign 1 603 2049
add 1 603 2049
assign 1 605 2050
emitNameGet 0 605 2050
assign 1 605 2051
addValue 1 605 2051
assign 1 605 2052
new 0 605 2052
assign 1 605 2053
addValue 1 605 2053
assign 1 605 2054
emitNameGet 0 605 2054
assign 1 605 2055
addValue 1 605 2055
assign 1 605 2056
new 0 605 2056
assign 1 605 2057
addValue 1 605 2057
assign 1 605 2058
addValue 1 605 2058
assign 1 605 2059
new 0 605 2059
addValue 1 605 2060
return 1 607 2061
assign 1 611 2070
libNameGet 0 611 2070
assign 1 611 2071
relEmitName 1 611 2071
assign 1 612 2072
new 0 612 2072
assign 1 612 2073
add 1 612 2073
assign 1 612 2074
new 0 612 2074
assign 1 612 2075
add 1 612 2075
return 1 613 2076
assign 1 617 2088
libNameGet 0 617 2088
assign 1 617 2089
relEmitName 1 617 2089
assign 1 618 2090
new 0 618 2090
assign 1 618 2091
add 1 618 2091
assign 1 618 2092
new 0 618 2092
assign 1 618 2093
add 1 618 2093
assign 1 619 2094
new 0 619 2094
assign 1 619 2095
add 1 619 2095
assign 1 619 2096
add 1 619 2096
return 1 619 2097
assign 1 623 2102
new 0 623 2102
assign 1 623 2103
add 1 623 2103
return 1 623 2104
assign 1 627 2212
getClassConfig 1 627 2212
assign 1 627 2213
libNameGet 0 627 2213
assign 1 627 2214
relEmitName 1 627 2214
assign 1 628 2215
heldGet 0 628 2215
assign 1 628 2216
namepathGet 0 628 2216
assign 1 628 2217
getClassConfig 1 628 2217
assign 1 629 2218
getInitialInst 1 629 2218
assign 1 631 2219
overrideMtdDecGet 0 631 2219
assign 1 631 2220
addValue 1 631 2220
assign 1 631 2221
new 0 631 2221
assign 1 631 2222
addValue 1 631 2222
assign 1 631 2223
emitNameGet 0 631 2223
assign 1 631 2224
addValue 1 631 2224
assign 1 631 2225
new 0 631 2225
assign 1 631 2226
addValue 1 631 2226
assign 1 631 2227
addValue 1 631 2227
assign 1 631 2228
new 0 631 2228
assign 1 631 2229
addValue 1 631 2229
assign 1 631 2230
addValue 1 631 2230
assign 1 631 2231
new 0 631 2231
assign 1 631 2232
addValue 1 631 2232
addValue 1 631 2233
assign 1 632 2234
new 0 632 2234
assign 1 633 2235
emitNameGet 0 633 2235
assign 1 633 2236
notEquals 1 633 2236
assign 1 634 2238
new 0 634 2238
assign 1 634 2239
formCast 3 634 2239
assign 1 637 2241
addValue 1 637 2241
assign 1 637 2242
new 0 637 2242
assign 1 637 2243
addValue 1 637 2243
assign 1 637 2244
addValue 1 637 2244
assign 1 637 2245
new 0 637 2245
assign 1 637 2246
addValue 1 637 2246
addValue 1 637 2247
assign 1 639 2248
new 0 639 2248
assign 1 639 2249
addValue 1 639 2249
addValue 1 639 2250
assign 1 642 2251
overrideMtdDecGet 0 642 2251
assign 1 642 2252
addValue 1 642 2252
assign 1 642 2253
addValue 1 642 2253
assign 1 642 2254
new 0 642 2254
assign 1 642 2255
addValue 1 642 2255
assign 1 642 2256
emitNameGet 0 642 2256
assign 1 642 2257
addValue 1 642 2257
assign 1 642 2258
new 0 642 2258
assign 1 642 2259
addValue 1 642 2259
assign 1 642 2260
addValue 1 642 2260
assign 1 642 2261
new 0 642 2261
assign 1 642 2262
addValue 1 642 2262
addValue 1 642 2263
assign 1 647 2264
new 0 647 2264
assign 1 647 2265
addValue 1 647 2265
assign 1 647 2266
addValue 1 647 2266
assign 1 647 2267
new 0 647 2267
assign 1 647 2268
addValue 1 647 2268
addValue 1 647 2269
assign 1 650 2270
new 0 650 2270
assign 1 650 2271
addValue 1 650 2271
addValue 1 650 2272
assign 1 652 2273
overrideMtdDecGet 0 652 2273
assign 1 652 2274
addValue 1 652 2274
assign 1 652 2275
new 0 652 2275
assign 1 652 2276
addValue 1 652 2276
assign 1 652 2277
emitNameGet 0 652 2277
assign 1 652 2278
addValue 1 652 2278
assign 1 652 2279
new 0 652 2279
assign 1 652 2280
addValue 1 652 2280
assign 1 652 2281
addValue 1 652 2281
assign 1 652 2282
new 0 652 2282
assign 1 652 2283
addValue 1 652 2283
addValue 1 652 2284
assign 1 653 2285
heldGet 0 653 2285
assign 1 653 2286
extendsGet 0 653 2286
assign 1 653 2287
undef 1 653 2292
assign 1 0 2293
assign 1 653 2296
heldGet 0 653 2296
assign 1 653 2297
extendsGet 0 653 2297
assign 1 653 2298
equals 1 653 2298
assign 1 0 2300
assign 1 0 2303
assign 1 654 2307
new 0 654 2307
assign 1 654 2308
addValue 1 654 2308
addValue 1 654 2309
assign 1 656 2312
new 0 656 2312
assign 1 656 2313
addValue 1 656 2313
addValue 1 656 2314
addValue 1 658 2316
clear 0 659 2317
assign 1 662 2318
new 0 662 2318
assign 1 662 2319
addValue 1 662 2319
addValue 1 662 2320
assign 1 664 2321
overrideMtdDecGet 0 664 2321
assign 1 664 2322
addValue 1 664 2322
assign 1 664 2323
new 0 664 2323
assign 1 664 2324
addValue 1 664 2324
assign 1 664 2325
emitNameGet 0 664 2325
assign 1 664 2326
addValue 1 664 2326
assign 1 664 2327
new 0 664 2327
assign 1 664 2328
addValue 1 664 2328
assign 1 664 2329
addValue 1 664 2329
assign 1 664 2330
new 0 664 2330
assign 1 664 2331
addValue 1 664 2331
addValue 1 664 2332
assign 1 665 2333
new 0 665 2333
assign 1 665 2334
addValue 1 665 2334
addValue 1 665 2335
assign 1 667 2336
new 0 667 2336
assign 1 667 2337
addValue 1 667 2337
addValue 1 667 2338
assign 1 669 2339
getTypeInst 1 669 2339
assign 1 671 2340
new 0 671 2340
assign 1 671 2341
addValue 1 671 2341
assign 1 671 2342
emitNameGet 0 671 2342
assign 1 671 2343
addValue 1 671 2343
assign 1 671 2344
new 0 671 2344
assign 1 671 2345
addValue 1 671 2345
addValue 1 671 2346
assign 1 673 2347
new 0 673 2347
assign 1 673 2348
addValue 1 673 2348
assign 1 673 2349
addValue 1 673 2349
assign 1 673 2350
new 0 673 2350
assign 1 673 2351
addValue 1 673 2351
addValue 1 673 2352
assign 1 675 2353
new 0 675 2353
assign 1 675 2354
addValue 1 675 2354
addValue 1 675 2355
assign 1 681 2367
new 0 681 2367
assign 1 681 2368
add 1 681 2368
assign 1 681 2369
new 0 681 2369
assign 1 681 2370
add 1 681 2370
write 1 681 2371
assign 1 682 2372
new 0 682 2372
assign 1 682 2373
add 1 682 2373
assign 1 682 2374
new 0 682 2374
assign 1 682 2375
add 1 682 2375
write 1 682 2376
emitLib 0 684 2377
assign 1 689 2390
libNameGet 0 689 2390
assign 1 689 2391
relEmitName 1 689 2391
assign 1 690 2392
new 0 690 2392
assign 1 690 2393
add 1 690 2393
assign 1 690 2394
new 0 690 2394
assign 1 690 2395
add 1 690 2395
assign 1 691 2396
new 0 691 2396
assign 1 691 2397
add 1 691 2397
assign 1 691 2398
add 1 691 2398
return 1 691 2399
return 1 0 2402
return 1 0 2405
assign 1 0 2408
assign 1 0 2412
return 1 0 2416
return 1 0 2419
assign 1 0 2422
assign 1 0 2426
return 1 0 2430
return 1 0 2433
assign 1 0 2436
assign 1 0 2440
return 1 0 2444
return 1 0 2447
assign 1 0 2450
assign 1 0 2454
return 1 0 2458
return 1 0 2461
assign 1 0 2464
assign 1 0 2468
return 1 0 2472
return 1 0 2475
assign 1 0 2478
assign 1 0 2482
return 1 0 2486
return 1 0 2489
assign 1 0 2492
assign 1 0 2496
return 1 0 2500
return 1 0 2503
assign 1 0 2506
assign 1 0 2510
return 1 0 2514
return 1 0 2517
assign 1 0 2520
assign 1 0 2524
return 1 0 2528
return 1 0 2531
assign 1 0 2534
assign 1 0 2538
return 1 0 2542
return 1 0 2545
assign 1 0 2548
assign 1 0 2552
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1491566135: return bem_spropDecGet_0();
case -1337677722: return bem_heonGetDirect_0();
case -1774052115: return bem_classEndGet_0();
case -1357371049: return bem_constGet_0();
case 2035105248: return bem_buildClassInfo_0();
case 763315063: return bem_callNamesGet_0();
case -1049852967: return bem_shlibeGet_0();
case 1618079372: return bem_gcMarksGet_0();
case -1156903676: return bem_serializationIteratorGet_0();
case -2048326528: return bem_lastMethodBodyLinesGet_0();
case -171220340: return bem_useDynMethodsGet_0();
case -1154843849: return bem_objectCcGetDirect_0();
case 999729990: return bem_callNamesGetDirect_0();
case 372125122: return bem_methodCallsGetDirect_0();
case -515483367: return bem_smnlcsGet_0();
case 96320689: return bem_methodCatchGet_0();
case -713555511: return bem_lastMethodsLinesGet_0();
case 318732337: return bem_instOfGet_0();
case -1432945498: return bem_ccMethodsGet_0();
case -708832446: return bem_gcMarksGetDirect_0();
case 721123821: return bem_tagGet_0();
case -1323132983: return bem_instanceEqualGet_0();
case 523550558: return bem_saveSyns_0();
case 775187999: return bem_inClassGetDirect_0();
case -134968473: return bem_cnodeGetDirect_0();
case -1823156463: return bem_fileExtGet_0();
case -1360887726: return bem_nativeCSlotsGetDirect_0();
case 1597530459: return bem_print_0();
case 19210432: return bem_iteratorGet_0();
case 569064439: return bem_methodBodyGetDirect_0();
case 1324971319: return bem_emitLangGetDirect_0();
case 2023430161: return bem_parentConfGetDirect_0();
case -2030736628: return bem_superCallsGetDirect_0();
case 2025206756: return bem_classEmitsGetDirect_0();
case 1964913802: return bem_libEmitPathGetDirect_0();
case -1346890768: return bem_lastMethodsSizeGet_0();
case 1752549021: return bem_maxSpillArgsLenGetDirect_0();
case 2011452903: return bem_covariantReturnsGet_0();
case 1429817502: return bem_nlGetDirect_0();
case 2018857935: return bem_afterCast_0();
case -1013644510: return bem_baseMtdDecGet_0();
case 1232998630: return bem_smnlcsGetDirect_0();
case 2067087462: return bem_exceptDecGet_0();
case -1835728373: return bem_buildGetDirect_0();
case 559255035: return bem_fieldNamesGet_0();
case -1129307273: return bem_objectCcGet_0();
case 1176129629: return bem_classHeadersGetDirect_0();
case -892778498: return bem_boolCcGetDirect_0();
case -1348036367: return bem_methodsGetDirect_0();
case 782833611: return bem_nameToIdGetDirect_0();
case -2016967628: return bem_setOutputTimeGetDirect_0();
case -1300841498: return bem_mainStartGet_0();
case 194846228: return bem_cnodeGet_0();
case -698388973: return bem_nlGet_0();
case -850223715: return bem_randGetDirect_0();
case -1028223785: return bem_belslitsGet_0();
case -1126453130: return bem_maxSpillArgsLenGet_0();
case 2119504529: return bem_belslitsGetDirect_0();
case -896414893: return bem_idToNameGetDirect_0();
case 664039703: return bem_mainEndGet_0();
case -613119208: return bem_methodCatchGetDirect_0();
case 926056474: return bem_shlibeGetDirect_0();
case 883517012: return bem_propDecGet_0();
case -4385541: return bem_doEmit_0();
case -1630562491: return bem_libEmitNameGetDirect_0();
case 1383525095: return bem_instanceEqualGetDirect_0();
case 1562356496: return bem_hashGet_0();
case -1513511273: return bem_deonGet_0();
case -930256306: return bem_trueValueGetDirect_0();
case 1151085267: return bem_deserializeClassNameGet_0();
case 1751151597: return bem_headExtGet_0();
case 654183960: return bem_deonGetDirect_0();
case 98489140: return bem_maxDynArgsGet_0();
case 216633460: return bem_serializeContents_0();
case -2005861917: return bem_classHeadBodyGetDirect_0();
case -434983830: return bem_exceptDecGetDirect_0();
case 1541804277: return bem_nativeCSlotsGet_0();
case 36798317: return bem_heopGetDirect_0();
case 232906009: return bem_methodCallsGet_0();
case 2133871376: return bem_fullLibEmitNameGet_0();
case -217357083: return bem_setOutputTimeGet_0();
case 812848035: return bem_synEmitPathGet_0();
case 651773240: return bem_getClassOutput_0();
case -1432810857: return bem_classCallsGet_0();
case 24781128: return bem_instanceNotEqualGet_0();
case -410376618: return bem_synEmitPathGetDirect_0();
case -1725432936: return bem_ccCacheGet_0();
case -136742844: return bem_preClassGetDirect_0();
case 1294887147: return bem_superCallsGet_0();
case -1123266766: return bem_classNameGet_0();
case 1406534779: return bem_invpGetDirect_0();
case 595935693: return bem_create_0();
case -1407301463: return bem_deowGetDirect_0();
case 270781002: return bem_new_0();
case -650963619: return bem_lastCallGet_0();
case -360139754: return bem_trueValueGet_0();
case 921638548: return bem_inClassGet_0();
case -745054831: return bem_nullValueGet_0();
case -1004041870: return bem_propertyDecsGet_0();
case 1409964924: return bem_classHeadersGet_0();
case -946249068: return bem_invpGet_0();
case -765807356: return bem_intNpGet_0();
case -1869924457: return bem_sourceFileNameGet_0();
case -89030859: return bem_idToNamePathGetDirect_0();
case 1015939194: return bem_objectNpGet_0();
case -612371614: return bem_scvpGet_0();
case 1812956863: return bem_qGet_0();
case 135092783: return bem_smnlecsGetDirect_0();
case -1116545592: return bem_randGet_0();
case -1835867738: return bem_writeBET_0();
case 1673838446: return bem_idToNamePathGet_0();
case -708815189: return bem_runtimeInitGet_0();
case -1006209646: return bem_classConfGet_0();
case -1562227815: return bem_intNpGetDirect_0();
case 1812661362: return bem_emitLib_0();
case 533155214: return bem_lastMethodBodySizeGetDirect_0();
case -1387543866: return bem_heopGet_0();
case 514040809: return bem_maxDynArgsGetDirect_0();
case -601453628: return bem_fieldIteratorGet_0();
case -661118504: return bem_baseSmtdDecGet_0();
case 1869093355: return bem_buildCreate_0();
case -1428159014: return bem_classHeadBodyGet_0();
case -1493661665: return bem_floatNpGet_0();
case 770712476: return bem_deopGetDirect_0();
case 1836289730: return bem_dynMethodsGet_0();
case 1710771230: return bem_classEmitsGet_0();
case -1326099503: return bem_fullLibEmitNameGetDirect_0();
case 163453708: return bem_returnTypeGet_0();
case -325661599: return bem_msynGet_0();
case 1109421052: return bem_qGetDirect_0();
case 1271225595: return bem_lastMethodsSizeGetDirect_0();
case 1227824030: return bem_emitLangGet_0();
case -949858080: return bem_deowGet_0();
case 716636157: return bem_objectNpGetDirect_0();
case -1475347946: return bem_overrideMtdDecGet_0();
case -1032593916: return bem_classesInDepthOrderGet_0();
case 1848966147: return bem_lastMethodsLinesGetDirect_0();
case -283467075: return bem_preClassOutput_0();
case -860520942: return bem_toString_0();
case 263521330: return bem_methodBodyGet_0();
case 81167556: return bem_onceDecsGet_0();
case 1048906499: return bem_boolNpGet_0();
case -2043826872: return bem_libEmitPathGet_0();
case -1478956612: return bem_instOfGetDirect_0();
case -1761956740: return bem_boolNpGetDirect_0();
case -140817078: return bem_nullValueGetDirect_0();
case 1707981905: return bem_lastMethodBodySizeGet_0();
case 1291824271: return bem_echo_0();
case -390286916: return bem_serializeToString_0();
case 1362548909: return bem_getLibOutput_0();
case 268463226: return bem_beginNs_0();
case 8392423: return bem_buildInitial_0();
case 1674716440: return bem_falseValueGet_0();
case 1026322148: return bem_floatNpGetDirect_0();
case -218740491: return bem_transGet_0();
case -672951514: return bem_newDecGet_0();
case -749809535: return bem_buildGet_0();
case -2119148614: return bem_mnodeGetDirect_0();
case 1113069980: return bem_lineCountGet_0();
case -284086210: return bem_constGetDirect_0();
case -1541709922: return bem_stringNpGetDirect_0();
case 440166883: return bem_libEmitNameGet_0();
case 1684526264: return bem_instanceNotEqualGetDirect_0();
case 1010838011: return bem_prepHeaderOutput_0();
case -1936123701: return bem_methodsGet_0();
case 584538152: return bem_classConfGetDirect_0();
case 1197921161: return bem_mnodeGet_0();
case -927548026: return bem_propertyDecsGetDirect_0();
case -1798520162: return bem_preClassGet_0();
case 700641171: return bem_classesInDepthOrderGetDirect_0();
case 1588969629: return bem_initialDecGet_0();
case 936963694: return bem_lastCallGetDirect_0();
case -598169013: return bem_ntypesGet_0();
case -1627491038: return bem_mainOutsideNsGet_0();
case 455986975: return bem_scvpGetDirect_0();
case 782290178: return bem_lineCountGetDirect_0();
case 1386331491: return bem_buildPropList_0();
case -323790148: return bem_ccCacheGetDirect_0();
case 1748421897: return bem_nameToIdPathGetDirect_0();
case -353807332: return bem_classCallsGetDirect_0();
case 2093636329: return bem_heowGet_0();
case 650065708: return bem_typeDecGet_0();
case 115831507: return bem_ntypesGetDirect_0();
case -960702953: return bem_loadIds_0();
case 1023542275: return bem_csynGet_0();
case 465624407: return bem_csynGetDirect_0();
case -1181362591: return bem_transGetDirect_0();
case 906832810: return bem_saveIds_0();
case -1286873789: return bem_ccMethodsGetDirect_0();
case -1482325642: return bem_endNs_0();
case 1693569725: return bem_dynMethodsGetDirect_0();
case 1475641193: return bem_inFilePathedGet_0();
case 719321820: return bem_lastMethodBodyLinesGetDirect_0();
case 86722817: return bem_superNameGet_0();
case 1460591097: return bem_inFilePathedGetDirect_0();
case 699853346: return bem_falseValueGetDirect_0();
case 1464147375: return bem_nameToIdGet_0();
case 1273267850: return bem_deopGet_0();
case 1205963996: return bem_idToNameGet_0();
case -81159141: return bem_stringNpGet_0();
case -1982731069: return bem_heonGet_0();
case -402856152: return bem_mainInClassGet_0();
case -827080774: return bem_copy_0();
case 1907548081: return bem_parentConfGet_0();
case -618687929: return bem_heowGetDirect_0();
case -1945056477: return bem_smnlecsGet_0();
case -1631506530: return bem_fileExtGetDirect_0();
case -919851112: return bem_boolCcGet_0();
case -127522808: return bem_headExtGetDirect_0();
case 1503500219: return bem_msynGetDirect_0();
case -2093495167: return bem_nameToIdPathGet_0();
case -585345560: return bem_boolTypeGet_0();
case 395426690: return bem_onceDecsGetDirect_0();
case -245691841: return bem_returnTypeGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1535812253: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1486002602: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -684440119: return bem_deopSet_1(bevd_0);
case -2045799345: return bem_fileExtSet_1(bevd_0);
case -1388693707: return bem_idToNamePathSet_1(bevd_0);
case -908803422: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1686277291: return bem_headExtSet_1(bevd_0);
case 691540758: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1073230603: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -408170678: return bem_classConfSetDirect_1(bevd_0);
case -2037952037: return bem_qSet_1(bevd_0);
case 2118881749: return bem_maxDynArgsSet_1(bevd_0);
case 1938426926: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 922382887: return bem_libEmitNameSet_1(bevd_0);
case -216647819: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 396958288: return bem_invpSetDirect_1(bevd_0);
case 1195588977: return bem_setOutputTimeSet_1(bevd_0);
case 1297424424: return bem_propertyDecsSetDirect_1(bevd_0);
case -1341577662: return bem_boolCcSet_1(bevd_0);
case 233717858: return bem_inClassSetDirect_1(bevd_0);
case -6893721: return bem_msynSetDirect_1(bevd_0);
case -1284196768: return bem_objectCcSet_1(bevd_0);
case 724004561: return bem_returnTypeSet_1(bevd_0);
case -1062464101: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1916303516: return bem_idToNamePathSetDirect_1(bevd_0);
case 1488206713: return bem_parentConfSet_1(bevd_0);
case 1002641145: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -104981352: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1693805051: return bem_shlibeSet_1(bevd_0);
case 278229069: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 933382315: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -710827226: return bem_exceptDecSet_1(bevd_0);
case -1276481328: return bem_nullValueSetDirect_1(bevd_0);
case 798800931: return bem_emitLangSet_1(bevd_0);
case 821408118: return bem_methodCatchSet_1(bevd_0);
case -1746207748: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 43212386: return bem_synEmitPathSetDirect_1(bevd_0);
case 860639447: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -124330508: return bem_objectNpSetDirect_1(bevd_0);
case 870998183: return bem_gcMarksSet_1(bevd_0);
case -1992525222: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -458119248: return bem_begin_1(bevd_0);
case -344186119: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 845534717: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -1853178872: return bem_belslitsSetDirect_1(bevd_0);
case -749908266: return bem_csynSet_1(bevd_0);
case -120739693: return bem_gcMarksSetDirect_1(bevd_0);
case -1165380069: return bem_classCallsSetDirect_1(bevd_0);
case 906205474: return bem_idToNameSet_1(bevd_0);
case 1492118681: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1352357874: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -703721200: return bem_synEmitPathSet_1(bevd_0);
case -430559164: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 401699199: return bem_stringNpSetDirect_1(bevd_0);
case 718348966: return bem_maxDynArgsSetDirect_1(bevd_0);
case 1186656395: return bem_returnTypeSetDirect_1(bevd_0);
case 1788911287: return bem_sameType_1(bevd_0);
case -186206966: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1767905120: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 203760290: return bem_floatNpSet_1(bevd_0);
case 1018701226: return bem_buildSet_1(bevd_0);
case 1381255736: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 478548407: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1685989944: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -404970424: return bem_classCallsSet_1(bevd_0);
case 1720726298: return bem_def_1(bevd_0);
case -664804390: return bem_scvpSet_1(bevd_0);
case 1633675574: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -327732297: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2008717075: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1936953266: return bem_deonSet_1(bevd_0);
case -1582378113: return bem_notEquals_1(bevd_0);
case 1268716706: return bem_smnlcsSet_1(bevd_0);
case 1117435754: return bem_mnodeSetDirect_1(bevd_0);
case -480921897: return bem_idToNameSetDirect_1(bevd_0);
case 242734583: return bem_deowSetDirect_1(bevd_0);
case 357665966: return bem_preClassSet_1(bevd_0);
case 1418396858: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1669410142: return bem_lastCallSetDirect_1(bevd_0);
case 942869803: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1283313223: return bem_instOfSet_1(bevd_0);
case 1021671334: return bem_classHeadBodySetDirect_1(bevd_0);
case -992836482: return bem_classEmitsSet_1(bevd_0);
case -274608267: return bem_ccMethodsSet_1(bevd_0);
case -1959943754: return bem_constSet_1(bevd_0);
case -677693650: return bem_heowSet_1(bevd_0);
case 1259632911: return bem_smnlcsSetDirect_1(bevd_0);
case -967486278: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 938318703: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1890967555: return bem_scvpSetDirect_1(bevd_0);
case 1380001208: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -232175653: return bem_floatNpSetDirect_1(bevd_0);
case -552008369: return bem_lastMethodBodySizeSet_1(bevd_0);
case 2013043377: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -407093328: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -969394964: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 944885666: return bem_boolCcSetDirect_1(bevd_0);
case -167744615: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -2114508476: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1840637030: return bem_lastCallSet_1(bevd_0);
case 1242400150: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 278055405: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1625069370: return bem_methodCallsSetDirect_1(bevd_0);
case -1992520849: return bem_deonSetDirect_1(bevd_0);
case -2113799256: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -2035255259: return bem_headExtSetDirect_1(bevd_0);
case -89866327: return bem_copyTo_1(bevd_0);
case -1502416330: return bem_lineCountSet_1(bevd_0);
case -1249500824: return bem_ntypesSet_1(bevd_0);
case 699121125: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1138116572: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1526021642: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 1985207152: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 2005491373: return bem_setOutputTimeSetDirect_1(bevd_0);
case -1175891352: return bem_objectNpSet_1(bevd_0);
case 1032068670: return bem_heonSetDirect_1(bevd_0);
case 567226723: return bem_end_1(bevd_0);
case -1441243612: return bem_heopSet_1(bevd_0);
case 2081480332: return bem_deopSetDirect_1(bevd_0);
case -1287388725: return bem_deowSet_1(bevd_0);
case -1586843066: return bem_heonSet_1(bevd_0);
case 1989105919: return bem_fullLibEmitNameSet_1(bevd_0);
case 854326035: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 815540559: return bem_transSetDirect_1(bevd_0);
case -1703984292: return bem_ccMethodsSetDirect_1(bevd_0);
case -1065687483: return bem_methodBodySet_1(bevd_0);
case 671303544: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 44137667: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 871176280: return bem_classHeadersSetDirect_1(bevd_0);
case 1142988609: return bem_exceptDecSetDirect_1(bevd_0);
case -666921594: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -780270919: return bem_lastMethodsSizeSet_1(bevd_0);
case -794848453: return bem_trueValueSet_1(bevd_0);
case -1190268285: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 1436359612: return bem_inClassSet_1(bevd_0);
case -471638192: return bem_objectCcSetDirect_1(bevd_0);
case -1503854424: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -396101325: return bem_transSet_1(bevd_0);
case 1182157162: return bem_methodsSetDirect_1(bevd_0);
case -148710494: return bem_nullValueSet_1(bevd_0);
case 1299034762: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -962433520: return bem_buildSetDirect_1(bevd_0);
case -762372565: return bem_mnodeSet_1(bevd_0);
case -1126628426: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 625531147: return bem_inFilePathedSetDirect_1(bevd_0);
case -996592363: return bem_classConfSet_1(bevd_0);
case -1952913836: return bem_ntypesSetDirect_1(bevd_0);
case 227857581: return bem_heopSetDirect_1(bevd_0);
case 665271065: return bem_callNamesSetDirect_1(bevd_0);
case -323113819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 847433577: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1253030085: return bem_callNamesSet_1(bevd_0);
case -994401711: return bem_classEmitsSetDirect_1(bevd_0);
case 1161013564: return bem_methodCatchSetDirect_1(bevd_0);
case 1261524354: return bem_intNpSet_1(bevd_0);
case 1693664207: return bem_libEmitNameSetDirect_1(bevd_0);
case -1761937464: return bem_instanceEqualSet_1(bevd_0);
case 1037920894: return bem_propertyDecsSet_1(bevd_0);
case -1965533073: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1395591174: return bem_cnodeSetDirect_1(bevd_0);
case 2140620274: return bem_otherType_1(bevd_0);
case -1053992692: return bem_nlSetDirect_1(bevd_0);
case -385517554: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1752476757: return bem_classHeadBodySet_1(bevd_0);
case 41232090: return bem_dynMethodsSetDirect_1(bevd_0);
case 645677934: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 559380624: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1565863376: return bem_falseValueSetDirect_1(bevd_0);
case 461117449: return bem_nameToIdPathSetDirect_1(bevd_0);
case 691532613: return bem_fileExtSetDirect_1(bevd_0);
case 861886143: return bem_qSetDirect_1(bevd_0);
case -2138090541: return bem_sameClass_1(bevd_0);
case -1344739698: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -978638213: return bem_instanceNotEqualSet_1(bevd_0);
case 1938475386: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 911865439: return bem_heowSetDirect_1(bevd_0);
case 1590624012: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -70695123: return bem_inFilePathedSet_1(bevd_0);
case 218912538: return bem_lastMethodsLinesSet_1(bevd_0);
case -478520463: return bem_undef_1(bevd_0);
case 415363806: return bem_onceDecsSet_1(bevd_0);
case 1711224626: return bem_cnodeSet_1(bevd_0);
case 1572235998: return bem_stringNpSet_1(bevd_0);
case -1849717348: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 626769267: return bem_falseValueSet_1(bevd_0);
case 83653250: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1193892438: return bem_parentConfSetDirect_1(bevd_0);
case 817890470: return bem_libEmitPathSet_1(bevd_0);
case 545506915: return bem_instanceEqualSetDirect_1(bevd_0);
case -1595941877: return bem_shlibeSetDirect_1(bevd_0);
case 1007178536: return bem_belslitsSet_1(bevd_0);
case 2147225704: return bem_nameToIdPathSet_1(bevd_0);
case -1417897931: return bem_invpSet_1(bevd_0);
case -713500063: return bem_ccCacheSetDirect_1(bevd_0);
case 610886167: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1386997645: return bem_smnlecsSetDirect_1(bevd_0);
case 407033242: return bem_smnlecsSet_1(bevd_0);
case 1166263208: return bem_constSetDirect_1(bevd_0);
case -2085638643: return bem_superCallsSetDirect_1(bevd_0);
case -2089078991: return bem_nameToIdSetDirect_1(bevd_0);
case -1196284655: return bem_boolNpSetDirect_1(bevd_0);
case -1275638607: return bem_nlSet_1(bevd_0);
case -1160701013: return bem_libEmitPathSetDirect_1(bevd_0);
case -881568584: return bem_classHeadersSet_1(bevd_0);
case -347185251: return bem_nameToIdSet_1(bevd_0);
case 1132299376: return bem_msynSet_1(bevd_0);
case 623040602: return bem_csynSetDirect_1(bevd_0);
case -1585608692: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 530898432: return bem_ccCacheSet_1(bevd_0);
case 1465328557: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1056706127: return bem_preClassSetDirect_1(bevd_0);
case -451218144: return bem_intNpSetDirect_1(bevd_0);
case -637072093: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2031748671: return bem_instOfSetDirect_1(bevd_0);
case 297670915: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -999783615: return bem_randSetDirect_1(bevd_0);
case 1674580744: return bem_nativeCSlotsSet_1(bevd_0);
case -812140515: return bem_dynMethodsSet_1(bevd_0);
case -1719983305: return bem_onceDecsSetDirect_1(bevd_0);
case 1233162083: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case -334924712: return bem_methodBodySetDirect_1(bevd_0);
case -499138365: return bem_otherClass_1(bevd_0);
case 635609563: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 461018408: return bem_superCallsSet_1(bevd_0);
case -690535851: return bem_sameObject_1(bevd_0);
case -696336738: return bem_equals_1(bevd_0);
case 280406691: return bem_trueValueSetDirect_1(bevd_0);
case 1059858060: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1798546398: return bem_classesInDepthOrderSet_1(bevd_0);
case 626437549: return bem_boolNpSet_1(bevd_0);
case -533924962: return bem_lineCountSetDirect_1(bevd_0);
case 893114482: return bem_emitLangSetDirect_1(bevd_0);
case 952454139: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1383872032: return bem_randSet_1(bevd_0);
case -1233187490: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 479720767: return bem_methodsSet_1(bevd_0);
case -895462529: return bem_methodCallsSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1776236695: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1067657480: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -77252171: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 132367548: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1828646701: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1279514270: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -673722974: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 2099903009: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 350317076: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -126046486: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -104691827: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 88958771: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1662205571: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1175344602: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 470190331: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -733779503: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1518308296: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -984102185: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 348791862: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1270855791: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1294382308: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 818521948: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -977032095: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 361463059: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -552078017: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -465608458: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCCEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
}
