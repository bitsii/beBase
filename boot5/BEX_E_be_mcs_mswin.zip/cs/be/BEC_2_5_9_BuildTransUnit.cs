namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_9_BuildTransUnit : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransUnit() { }
static BEC_2_5_9_BuildTransUnit() { }
private static byte[] becc_BEC_2_5_9_BuildTransUnit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x55,0x6E,0x69,0x74};
private static byte[] becc_BEC_2_5_9_BuildTransUnit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildTransUnit bece_BEC_2_5_9_BuildTransUnit_bevs_inst;

public static new BET_2_5_9_BuildTransUnit bece_BEC_2_5_9_BuildTransUnit_bevs_type;

public BEC_2_9_3_ContainerMap bevp_aliased;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_aliased = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_emits == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 61 */
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGet_0() {
return bevp_aliased;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGetDirect_0() {
return bevp_aliased;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_aliasedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_aliasedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() {
return bevp_emits;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGetDirect_0() {
return bevp_emits;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_emitsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {55, 60, 60, 62, 65, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {15, 20, 25, 26, 28, 32, 35, 38, 42, 46, 49, 52, 56};
/* BEGIN LINEINFO 
assign 1 55 15
new 0 55 15
assign 1 60 20
undef 1 60 25
assign 1 62 26
new 0 62 26
addValue 1 65 28
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
return 1 0 46
return 1 0 49
assign 1 0 52
assign 1 0 56
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1649770762: return bem_serializeContents_0();
case 1743657368: return bem_once_0();
case -1460138897: return bem_print_0();
case 1263254629: return bem_emitsGetDirect_0();
case 641617863: return bem_serializeToString_0();
case 700847419: return bem_iteratorGet_0();
case -1477321659: return bem_create_0();
case -1381809993: return bem_deserializeClassNameGet_0();
case 1165983674: return bem_emitsGet_0();
case -575216772: return bem_hashGet_0();
case 375625109: return bem_copy_0();
case -863375547: return bem_aliasedGet_0();
case 885190018: return bem_serializationIteratorGet_0();
case 1443037619: return bem_new_0();
case -2071582224: return bem_fieldNamesGet_0();
case -2061644084: return bem_echo_0();
case 1357107465: return bem_many_0();
case 1303816937: return bem_classNameGet_0();
case -1836127208: return bem_aliasedGetDirect_0();
case -1824151510: return bem_sourceFileNameGet_0();
case -954029510: return bem_tagGet_0();
case -167133301: return bem_fieldIteratorGet_0();
case -1062508492: return bem_toAny_0();
case -1111980982: return bem_toString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1171201188: return bem_sameType_1(bevd_0);
case 1843091865: return bem_notEquals_1(bevd_0);
case 912665444: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -541272639: return bem_emitsSet_1(bevd_0);
case 1081114988: return bem_copyTo_1(bevd_0);
case -536053857: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1650435450: return bem_undefined_1(bevd_0);
case -961773673: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -240276616: return bem_def_1(bevd_0);
case -2012960734: return bem_otherType_1(bevd_0);
case -599500599: return bem_aliasedSetDirect_1(bevd_0);
case -2012223833: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -860634984: return bem_sameObject_1(bevd_0);
case -158486422: return bem_undef_1(bevd_0);
case -905889959: return bem_emitsSetDirect_1(bevd_0);
case 997965949: return bem_sameClass_1(bevd_0);
case -124594925: return bem_equals_1(bevd_0);
case 467651334: return bem_addEmit_1(bevd_0);
case -700741655: return bem_aliasedSet_1(bevd_0);
case 1434062431: return bem_defined_1(bevd_0);
case 829192566: return bem_otherClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1783314567: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -749136313: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1365145554: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1346654676: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1957573480: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039992278: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1347676005: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildTransUnit_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_9_BuildTransUnit_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildTransUnit();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildTransUnit.bece_BEC_2_5_9_BuildTransUnit_bevs_inst = (BEC_2_5_9_BuildTransUnit) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildTransUnit.bece_BEC_2_5_9_BuildTransUnit_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildTransUnit.bece_BEC_2_5_9_BuildTransUnit_bevs_type;
}
}
}
