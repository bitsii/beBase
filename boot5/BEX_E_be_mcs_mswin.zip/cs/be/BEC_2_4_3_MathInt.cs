namespace be {

using System.IO;
using System;
    /* IO:File: source/base/Int.be */
public sealed class BEC_2_4_3_MathInt : BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }
static BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_0 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_1 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_2 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_3 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_5 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_6 = (new BEC_2_4_3_MathInt(71));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_7 = (new BEC_2_4_3_MathInt(103));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_9 = (new BEC_2_4_3_MathInt(24));
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_0, 39));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_11 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_12 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_13 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_14 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_15 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_17 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_18 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_19 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_20 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_21 = (new BEC_2_4_3_MathInt(43));
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_1, 21));
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_24 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_25 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_26 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_27 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_28 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_29 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_30 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_31 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_32 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_33 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_34 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_35 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_36 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_37 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_38 = (new BEC_2_4_3_MathInt(0));
public static new BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;

public static new BET_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_type;

public BEC_2_4_3_MathInt bem_vintGet_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) {
bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) {
bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_2;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_3;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_4;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_5;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_7;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_8;
if (beva_radix.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_9;
if (beva_radix.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 95 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 95 */ {
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_10;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_radix);
bevt_5_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 96 */
bevt_9_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_11;
if (beva_radix.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevl_max0 = (BEC_2_4_3_MathInt) beva_radix.bem_copy_0();
} /* Line: 99 */
 else  /* Line: 100 */ {
bevl_max0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
} /* Line: 101 */
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_11_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_12;
bevt_13_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_13;
bevt_12_tmpany_phold = beva_radix.bem_subtract_1(bevt_13_tmpany_phold);
bevl_maxA = bevt_11_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_14;
bevt_16_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_15;
bevt_15_tmpany_phold = beva_radix.bem_subtract_1(bevt_16_tmpany_phold);
bevl_maxa = bevt_14_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevi_int = bevt_3_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_j = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 115 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_16;
if (bevl_j.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 115 */ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_17;
if (bevl_ic.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 119 */ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 119 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 119 */
 else  /* Line: 119 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 119 */ {
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 122 */
 else  /* Line: 119 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_18;
if (bevl_ic.bevi_int > bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 123 */ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
 else  /* Line: 123 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 123 */ {
bevt_14_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 126 */
 else  /* Line: 119 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_19;
if (bevl_ic.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 127 */ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 127 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 127 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 127 */
 else  /* Line: 127 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 127 */ {
bevt_18_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 130 */
 else  /* Line: 119 */ {
bevt_20_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_20;
if (bevl_ic.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_21_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_21_tmpany_phold);
} /* Line: 133 */
 else  /* Line: 119 */ {
bevt_23_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_21;
if (bevl_ic.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 134 */ {
} /* Line: 134 */
 else  /* Line: 136 */ {
bevt_28_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_22;
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(beva_str);
bevt_29_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_23;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevl_ic);
bevt_24_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 137 */
} /* Line: 119 */
} /* Line: 119 */
} /* Line: 119 */
} /* Line: 119 */
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 140 */
 else  /* Line: 115 */ {
break;
} /* Line: 115 */
} /* Line: 115 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_toFloat_0() {
BEC_2_4_5_MathFloat bevl_fi = null;
bevl_fi = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_24;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_6_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_25;
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) bevt_6_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(bevt_1_tmpany_phold, bevt_3_tmpany_phold, bevt_5_tmpany_phold, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_toHexString_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_26;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_27;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_3(beva_res, bevt_1_tmpany_phold, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_28;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(bevt_1_tmpany_phold, beva_zeroPad, beva_radix, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_29;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
beva_res.bem_clear_0();
bevl_ts = bem_abs_0();
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 218 */ {
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_30;
if (bevl_ts.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_31;
if (bevl_val.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_tmpany_phold.bevi_int;
} /* Line: 222 */
 else  /* Line: 223 */ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 224 */
bevt_6_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_7_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int <= bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevt_9_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_10_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_32;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_8_tmpany_phold);
} /* Line: 228 */
bevt_11_tmpany_phold = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_tmpany_phold, bevl_val);
bevt_13_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_14_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_33;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 235 */
 else  /* Line: 218 */ {
break;
} /* Line: 218 */
} /* Line: 218 */
while (true)
 /* Line: 238 */ {
bevt_19_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_19_tmpany_phold.bevi_int < beva_zeroPad.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_21_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_22_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_21_tmpany_phold.bevi_int <= bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_24_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_25_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_34;
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_23_tmpany_phold);
} /* Line: 240 */
bevt_26_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_28_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_35;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
beva_res.bem_setIntUnchecked_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_31_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_36;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_29_tmpany_phold);
} /* Line: 244 */
 else  /* Line: 238 */ {
break;
} /* Line: 238 */
} /* Line: 238 */
bevt_36_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_37;
if (bevi_int < bevt_36_tmpany_phold.bevi_int) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 248 */ {
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_37_tmpany_phold);
} /* Line: 249 */
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) beva_res.bem_reverseBytes_0();
return bevt_38_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = bevi_int;
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_absValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_38;
if (bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 265 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_2_tmpany_phold);
} /* Line: 266 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 700 */ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 700 */ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 700 */
 else  /* Line: 700 */ {
break;
} /* Line: 700 */
} /* Line: 700 */
return bevl_result;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int == bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int != bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {76, 76, 79, 83, 87, 87, 87, 87, 87, 87, 87, 87, 87, 91, 91, 91, 91, 91, 91, 91, 91, 91, 95, 95, 95, 0, 95, 95, 95, 0, 0, 96, 96, 96, 96, 98, 98, 98, 99, 101, 103, 103, 104, 104, 104, 104, 105, 105, 105, 105, 106, 110, 110, 111, 111, 112, 113, 114, 115, 115, 115, 117, 119, 119, 119, 119, 119, 0, 0, 0, 120, 120, 121, 122, 123, 123, 123, 123, 123, 0, 0, 0, 124, 124, 125, 126, 127, 127, 127, 127, 127, 0, 0, 0, 128, 128, 129, 130, 131, 131, 131, 133, 133, 134, 134, 134, 137, 137, 137, 137, 137, 137, 137, 139, 140, 145, 145, 149, 153, 153, 157, 168, 191, 195, 195, 195, 195, 195, 195, 195, 195, 199, 199, 199, 199, 203, 203, 203, 203, 203, 203, 207, 207, 207, 207, 207, 211, 211, 211, 211, 215, 216, 217, 218, 218, 218, 219, 220, 221, 221, 221, 222, 222, 224, 227, 227, 227, 227, 228, 228, 228, 228, 230, 230, 231, 231, 231, 231, 235, 238, 238, 238, 239, 239, 239, 239, 240, 240, 240, 240, 242, 242, 242, 242, 243, 243, 243, 243, 248, 248, 248, 249, 249, 251, 251, 255, 256, 257, 261, 261, 261, 265, 265, 265, 266, 266, 287, 291, 302, 306, 317, 336, 355, 359, 370, 389, 393, 404, 423, 427, 438, 457, 461, 478, 503, 507, 518, 537, 541, 557, 576, 580, 596, 615, 619, 635, 654, 658, 674, 693, 698, 700, 700, 700, 701, 700, 703, 742, 742, 778, 778, 806, 806, 834, 834, 862, 862, 890, 890};
public static new int[] bevs_smnlec
 = new int[] {74, 75, 78, 82, 94, 95, 96, 97, 98, 99, 100, 101, 102, 114, 115, 116, 117, 118, 119, 120, 121, 122, 146, 147, 152, 153, 156, 157, 162, 163, 166, 170, 171, 172, 173, 175, 176, 181, 182, 185, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 234, 235, 236, 237, 238, 239, 240, 243, 244, 249, 250, 251, 252, 257, 258, 263, 264, 267, 271, 274, 275, 276, 277, 280, 281, 286, 287, 292, 293, 296, 300, 303, 304, 305, 306, 309, 310, 315, 316, 321, 322, 325, 329, 332, 333, 334, 335, 338, 339, 344, 345, 346, 349, 350, 355, 358, 359, 360, 361, 362, 363, 364, 370, 371, 381, 382, 385, 390, 391, 394, 398, 401, 411, 412, 413, 414, 415, 416, 417, 418, 424, 425, 426, 427, 435, 436, 437, 438, 439, 440, 447, 448, 449, 450, 451, 457, 458, 459, 460, 504, 505, 506, 509, 510, 515, 516, 517, 518, 519, 524, 525, 526, 529, 531, 532, 533, 538, 539, 540, 541, 542, 544, 545, 546, 547, 548, 549, 550, 558, 559, 564, 565, 566, 567, 572, 573, 574, 575, 576, 578, 579, 580, 581, 582, 583, 584, 585, 591, 592, 597, 598, 599, 601, 602, 606, 607, 608, 613, 614, 615, 621, 622, 627, 628, 629, 636, 640, 643, 647, 650, 655, 660, 664, 667, 672, 676, 679, 684, 688, 691, 696, 700, 703, 708, 712, 715, 720, 724, 727, 732, 736, 739, 744, 748, 751, 756, 760, 763, 768, 774, 775, 778, 783, 784, 785, 791, 801, 802, 812, 813, 822, 823, 832, 833, 842, 843, 852, 853};
/* BEGIN LINEINFO 
assign 1 76 74
new 0 76 74
return 1 76 75
setStringValueDec 1 79 78
setStringValueHex 1 83 82
assign 1 87 94
new 0 87 94
assign 1 87 95
once 0 87 95
assign 1 87 96
new 0 87 96
assign 1 87 97
once 0 87 97
assign 1 87 98
new 0 87 98
assign 1 87 99
once 0 87 99
assign 1 87 100
new 0 87 100
assign 1 87 101
once 0 87 101
setStringValue 5 87 102
assign 1 91 114
new 0 91 114
assign 1 91 115
once 0 91 115
assign 1 91 116
new 0 91 116
assign 1 91 117
once 0 91 117
assign 1 91 118
new 0 91 118
assign 1 91 119
once 0 91 119
assign 1 91 120
new 0 91 120
assign 1 91 121
once 0 91 121
setStringValue 5 91 122
assign 1 95 146
new 0 95 146
assign 1 95 147
lesser 1 95 152
assign 1 0 153
assign 1 95 156
new 0 95 156
assign 1 95 157
greater 1 95 162
assign 1 0 163
assign 1 0 166
assign 1 96 170
new 0 96 170
assign 1 96 171
add 1 96 171
assign 1 96 172
new 1 96 172
throw 1 96 173
assign 1 98 175
new 0 98 175
assign 1 98 176
lesser 1 98 181
assign 1 99 182
copy 0 99 182
assign 1 101 185
new 0 101 185
assign 1 103 187
new 0 103 187
addValue 1 103 188
assign 1 104 189
new 0 104 189
assign 1 104 190
new 0 104 190
assign 1 104 191
subtract 1 104 191
assign 1 104 192
add 1 104 192
assign 1 105 193
new 0 105 193
assign 1 105 194
new 0 105 194
assign 1 105 195
subtract 1 105 195
assign 1 105 196
add 1 105 196
setStringValue 5 106 197
assign 1 110 234
new 0 110 234
setValue 1 110 235
assign 1 111 236
sizeGet 0 111 236
assign 1 111 237
copy 0 111 237
decrementValue 0 112 238
assign 1 113 239
new 0 113 239
assign 1 114 240
new 0 114 240
assign 1 115 243
new 0 115 243
assign 1 115 244
greaterEquals 1 115 249
getInt 2 117 250
assign 1 119 251
new 0 119 251
assign 1 119 252
greater 1 119 257
assign 1 119 258
lesser 1 119 263
assign 1 0 264
assign 1 0 267
assign 1 0 271
assign 1 120 274
new 0 120 274
subtractValue 1 120 275
multiplyValue 1 121 276
addValue 1 122 277
assign 1 123 280
new 0 123 280
assign 1 123 281
greater 1 123 286
assign 1 123 287
lesser 1 123 292
assign 1 0 293
assign 1 0 296
assign 1 0 300
assign 1 124 303
new 0 124 303
subtractValue 1 124 304
multiplyValue 1 125 305
addValue 1 126 306
assign 1 127 309
new 0 127 309
assign 1 127 310
greater 1 127 315
assign 1 127 316
lesser 1 127 321
assign 1 0 322
assign 1 0 325
assign 1 0 329
assign 1 128 332
new 0 128 332
subtractValue 1 128 333
multiplyValue 1 129 334
addValue 1 130 335
assign 1 131 338
new 0 131 338
assign 1 131 339
equals 1 131 344
assign 1 133 345
new 0 133 345
multiplyValue 1 133 346
assign 1 134 349
new 0 134 349
assign 1 134 350
equals 1 134 355
assign 1 137 358
new 0 137 358
assign 1 137 359
add 1 137 359
assign 1 137 360
new 0 137 360
assign 1 137 361
add 1 137 361
assign 1 137 362
add 1 137 362
assign 1 137 363
new 1 137 363
throw 1 137 364
decrementValue 0 139 370
multiplyValue 1 140 371
assign 1 145 381
toString 0 145 381
return 1 145 382
new 1 149 385
assign 1 153 390
new 0 153 390
return 1 153 391
return 1 157 394
assign 1 168 398
new 0 168 398
return 1 191 401
assign 1 195 411
new 0 195 411
assign 1 195 412
new 1 195 412
assign 1 195 413
new 0 195 413
assign 1 195 414
once 0 195 414
assign 1 195 415
new 0 195 415
assign 1 195 416
once 0 195 416
assign 1 195 417
toString 4 195 417
return 1 195 418
assign 1 199 424
new 0 199 424
assign 1 199 425
new 1 199 425
assign 1 199 426
toHexString 1 199 426
return 1 199 427
assign 1 203 435
new 0 203 435
assign 1 203 436
once 0 203 436
assign 1 203 437
new 0 203 437
assign 1 203 438
once 0 203 438
assign 1 203 439
toString 3 203 439
return 1 203 440
assign 1 207 447
new 1 207 447
assign 1 207 448
new 0 207 448
assign 1 207 449
once 0 207 449
assign 1 207 450
toString 4 207 450
return 1 207 451
assign 1 211 457
new 0 211 457
assign 1 211 458
once 0 211 458
assign 1 211 459
toString 4 211 459
return 1 211 460
clear 0 215 504
assign 1 216 505
abs 0 216 505
assign 1 217 506
new 0 217 506
assign 1 218 509
new 0 218 509
assign 1 218 510
greater 1 218 515
setValue 1 219 516
modulusValue 1 220 517
assign 1 221 518
new 0 221 518
assign 1 221 519
lesser 1 221 524
assign 1 222 525
new 0 222 525
addValue 1 222 526
addValue 1 224 529
assign 1 227 531
capacityGet 0 227 531
assign 1 227 532
sizeGet 0 227 532
assign 1 227 533
lesserEquals 1 227 538
assign 1 228 539
capacityGet 0 228 539
assign 1 228 540
new 0 228 540
assign 1 228 541
add 1 228 541
capacitySet 1 228 542
assign 1 230 544
sizeGet 0 230 544
setIntUnchecked 2 230 545
assign 1 231 546
sizeGet 0 231 546
assign 1 231 547
new 0 231 547
assign 1 231 548
add 1 231 548
sizeSet 1 231 549
divideValue 1 235 550
assign 1 238 558
sizeGet 0 238 558
assign 1 238 559
lesser 1 238 564
assign 1 239 565
capacityGet 0 239 565
assign 1 239 566
sizeGet 0 239 566
assign 1 239 567
lesserEquals 1 239 572
assign 1 240 573
capacityGet 0 240 573
assign 1 240 574
new 0 240 574
assign 1 240 575
add 1 240 575
capacitySet 1 240 576
assign 1 242 578
sizeGet 0 242 578
assign 1 242 579
new 0 242 579
assign 1 242 580
once 0 242 580
setIntUnchecked 2 242 581
assign 1 243 582
sizeGet 0 243 582
assign 1 243 583
new 0 243 583
assign 1 243 584
add 1 243 584
sizeSet 1 243 585
assign 1 248 591
new 0 248 591
assign 1 248 592
lesser 1 248 597
assign 1 249 598
new 0 249 598
addValue 1 249 599
assign 1 251 601
reverseBytes 0 251 601
return 1 251 602
assign 1 255 606
new 0 255 606
setValue 1 256 607
return 1 257 608
assign 1 261 613
copy 0 261 613
assign 1 261 614
absValue 0 261 614
return 1 261 615
assign 1 265 621
new 0 265 621
assign 1 265 622
lesser 1 265 627
assign 1 266 628
new 0 266 628
multiplyValue 1 266 629
return 1 287 636
assign 1 291 640
new 0 291 640
return 1 302 643
assign 1 306 647
new 0 306 647
return 1 317 650
return 1 336 655
return 1 355 660
assign 1 359 664
new 0 359 664
return 1 370 667
return 1 389 672
assign 1 393 676
new 0 393 676
return 1 404 679
return 1 423 684
assign 1 427 688
new 0 427 688
return 1 438 691
return 1 457 696
assign 1 461 700
new 0 461 700
return 1 478 703
return 1 503 708
assign 1 507 712
new 0 507 712
return 1 518 715
return 1 537 720
assign 1 541 724
new 0 541 724
return 1 557 727
return 1 576 732
assign 1 580 736
new 0 580 736
return 1 596 739
return 1 615 744
assign 1 619 748
new 0 619 748
return 1 635 751
return 1 654 756
assign 1 658 760
new 0 658 760
return 1 674 763
return 1 693 768
assign 1 698 774
new 0 698 774
assign 1 700 775
new 0 700 775
assign 1 700 778
lesser 1 700 783
multiplyValue 1 701 784
incrementValue 0 700 785
return 1 703 791
assign 1 742 801
new 0 742 801
return 1 742 802
assign 1 778 812
new 0 778 812
return 1 778 813
assign 1 806 822
new 0 806 822
return 1 806 823
assign 1 834 832
new 0 834 832
return 1 834 833
assign 1 862 842
new 0 862 842
return 1 862 843
assign 1 890 852
new 0 890 852
return 1 890 853
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 605655591: return bem_sourceFileNameGet_0();
case 1267812147: return bem_classNameGet_0();
case 702246847: return bem_print_0();
case -364249863: return bem_serializeToString_0();
case -1353172126: return bem_toString_0();
case 1966713191: return bem_deserializeClassNameGet_0();
case -1655660203: return bem_hashGet_0();
case -500248069: return bem_serializationIteratorGet_0();
case 1581692921: return bem_toAny_0();
case -1572010998: return bem_copy_0();
case -1161967914: return bem_toFloat_0();
case 1530555194: return bem_serializeContents_0();
case -333821669: return bem_incrementValue_0();
case 812685421: return bem_iteratorGet_0();
case 1642133655: return bem_decrement_0();
case 1467721548: return bem_toHexString_0();
case 33308284: return bem_decrementValue_0();
case -1000018882: return bem_create_0();
case 206222065: return bem_vintSet_0();
case -65082849: return bem_once_0();
case 1652665755: return bem_vintGet_0();
case -1907635971: return bem_tagGet_0();
case -1741749539: return bem_absValue_0();
case -106257945: return bem_fieldNamesGet_0();
case -1577817259: return bem_echo_0();
case 1550760607: return bem_fieldIteratorGet_0();
case -927090833: return bem_new_0();
case -343977604: return bem_increment_0();
case 575375665: return bem_abs_0();
case -1007878556: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -886218051: return bem_equals_1(bevd_0);
case 539540152: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case 1069079556: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1665877975: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -481756547: return bem_undef_1(bevd_0);
case -1734268725: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -227529285: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -100935435: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1109285554: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case 115379467: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case 1385994869: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case -1392204268: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case 1163460144: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case 150021405: return bem_otherClass_1(bevd_0);
case -759946269: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1471457238: return bem_sameObject_1(bevd_0);
case -380623615: return bem_new_1(bevd_0);
case -1862075337: return bem_copyTo_1(bevd_0);
case -1620433619: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 1031112439: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case -1125807792: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case -411537492: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case 726015407: return bem_otherType_1(bevd_0);
case -1556952447: return bem_defined_1(bevd_0);
case -2030360118: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case 853073931: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case 439566061: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case -825541491: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case -674028265: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1673385175: return bem_notEquals_1(bevd_0);
case 259019146: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case 487460999: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case 541707007: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case 56534063: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case 187342537: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1940917614: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1953776597: return bem_sameType_1(bevd_0);
case 140166424: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -785498352: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case -780666633: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case 2141774895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 297381803: return bem_def_1(bevd_0);
case 1244819809: return bem_undefined_1(bevd_0);
case -58459221: return bem_sameClass_1(bevd_0);
case 1205193145: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1385199744: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1970963739: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -967702518: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -427898914: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 414161005: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -157052200: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 316930816: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1722905349: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 611344245: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 940488892: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -443275775: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -2119148653: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_3_MathInt();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_type;
}
}
}
