namespace be {
/* IO:File: source/build/Pass12.be */
public sealed class BEC_3_5_5_9_BuildVisitTypeCheck : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_9_BuildVisitTypeCheck() { }
static BEC_3_5_5_9_BuildVisitTypeCheck() { }
private static byte[] becc_BEC_3_5_5_9_BuildVisitTypeCheck_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x54,0x79,0x70,0x65,0x43,0x68,0x65,0x63,0x6B};
private static byte[] becc_BEC_3_5_5_9_BuildVisitTypeCheck_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_0 = {0x43,0x61,0x74,0x63,0x68,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x75,0x6E,0x74,0x79,0x70,0x65,0x64,0x20,0x28,0x61,0x6E,0x79,0x29};
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_2 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_2, 13));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_3 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_3, 13));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_4 = {0x28,0x42,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_4, 17));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_5 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_5, 10));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_6 = {0x53,0x65,0x6C,0x66,0x20,0x6F,0x61,0x6E,0x79,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x73,0x79,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_7 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_7, 30));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_8 = {0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x73,0x74,0x20,0x74,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_8, 19));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_9 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_10 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_11 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x63,0x61,0x6E,0x20,0x6F,0x6E,0x6C,0x79,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x28,0x73,0x65,0x6C,0x66,0x29,0x3B,0x20,0x28,0x61,0x63,0x74,0x75,0x61,0x6C,0x20,0x73,0x65,0x6C,0x66,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x29,0x20,0x66,0x6F,0x72,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73};
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_12 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_13 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x65,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x63,0x61,0x73,0x74,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66,0x20,0x74,0x79,0x70,0x65,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_13, 67));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_14 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_14, 1));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_15 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2E};
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_16 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_17 = {0x6E,0x65,0x77,0x4E,0x70,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x74,0x79,0x70,0x65,0x63,0x68,0x65,0x63,0x6B,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_2, 13));
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_3, 13));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_18 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_18, 13));
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_5, 10));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_19 = {0x47,0x6F,0x74,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6E,0x6E,0x6F,0x64,0x65};
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_20 = {0x6E,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x61,0x6E,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_20, 19));
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_2, 13));
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_3, 13));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_21 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x61,0x74,0x69,0x62,0x6C,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x2C,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_21, 52));
private static byte[] bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_22 = {0x20,0x67,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_22, 5));
public static new BEC_3_5_5_9_BuildVisitTypeCheck bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevs_inst;

public static new BET_3_5_5_9_BuildVisitTypeCheck bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevs_type;

public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_4_BuildNode bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_4_3_MathInt bevp_cpos;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_cci = null;
BEC_2_5_4_BuildNode bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_5_4_BuildNode bevl_ctarg = null;
BEC_2_6_6_SystemObject bevl_cany = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_5_4_BuildNode bevl_org = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_5_4_LogicBool bevl_castForSelf = null;
BEC_2_6_6_SystemObject bevl_ovnp = null;
BEC_2_6_6_SystemObject bevl_targsyn = null;
BEC_2_9_4_ContainerList bevl_argSyns = null;
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_6_BuildVarSyn bevl_marg = null;
BEC_2_5_3_BuildVar bevl_carg = null;
BEC_2_5_8_BuildClassSyn bevl_argSyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_9_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_10_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_19_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_5_4_LogicBool bevt_54_ta_ph = null;
BEC_2_5_4_LogicBool bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_5_4_LogicBool bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_5_4_LogicBool bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_4_3_MathInt bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_6_6_SystemObject bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_4_3_MathInt bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_6_6_SystemObject bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_6_6_SystemObject bevt_84_ta_ph = null;
BEC_2_6_6_SystemObject bevt_85_ta_ph = null;
BEC_2_6_6_SystemObject bevt_86_ta_ph = null;
BEC_2_6_6_SystemObject bevt_87_ta_ph = null;
BEC_2_6_6_SystemObject bevt_88_ta_ph = null;
BEC_2_5_4_LogicBool bevt_89_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_90_ta_ph = null;
BEC_2_6_6_SystemObject bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_5_4_LogicBool bevt_93_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
BEC_2_5_4_LogicBool bevt_102_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_4_6_TextString bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
BEC_2_6_6_SystemObject bevt_108_ta_ph = null;
BEC_2_6_6_SystemObject bevt_109_ta_ph = null;
BEC_2_4_6_TextString bevt_110_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_111_ta_ph = null;
BEC_2_5_4_LogicBool bevt_112_ta_ph = null;
BEC_2_6_6_SystemObject bevt_113_ta_ph = null;
BEC_2_6_6_SystemObject bevt_114_ta_ph = null;
BEC_2_5_4_LogicBool bevt_115_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_6_6_SystemObject bevt_118_ta_ph = null;
BEC_2_6_6_SystemObject bevt_119_ta_ph = null;
BEC_2_6_6_SystemObject bevt_120_ta_ph = null;
BEC_2_5_4_LogicBool bevt_121_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_122_ta_ph = null;
BEC_2_6_6_SystemObject bevt_123_ta_ph = null;
BEC_2_6_6_SystemObject bevt_124_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_125_ta_ph = null;
BEC_2_5_4_LogicBool bevt_126_ta_ph = null;
BEC_2_6_6_SystemObject bevt_127_ta_ph = null;
BEC_2_6_6_SystemObject bevt_128_ta_ph = null;
BEC_2_6_6_SystemObject bevt_129_ta_ph = null;
BEC_2_6_6_SystemObject bevt_130_ta_ph = null;
BEC_2_6_6_SystemObject bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_6_6_SystemObject bevt_133_ta_ph = null;
BEC_2_6_6_SystemObject bevt_134_ta_ph = null;
BEC_2_6_6_SystemObject bevt_135_ta_ph = null;
BEC_2_6_6_SystemObject bevt_136_ta_ph = null;
BEC_2_5_4_LogicBool bevt_137_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_138_ta_ph = null;
BEC_2_4_6_TextString bevt_139_ta_ph = null;
BEC_2_4_6_TextString bevt_140_ta_ph = null;
BEC_2_4_6_TextString bevt_141_ta_ph = null;
BEC_2_4_6_TextString bevt_142_ta_ph = null;
BEC_2_4_6_TextString bevt_143_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_144_ta_ph = null;
BEC_2_4_6_TextString bevt_145_ta_ph = null;
BEC_2_6_6_SystemObject bevt_146_ta_ph = null;
BEC_2_6_6_SystemObject bevt_147_ta_ph = null;
BEC_2_5_4_LogicBool bevt_148_ta_ph = null;
BEC_2_6_6_SystemObject bevt_149_ta_ph = null;
BEC_2_4_6_TextString bevt_150_ta_ph = null;
BEC_2_5_4_LogicBool bevt_151_ta_ph = null;
BEC_2_6_6_SystemObject bevt_152_ta_ph = null;
BEC_2_6_6_SystemObject bevt_153_ta_ph = null;
BEC_2_6_6_SystemObject bevt_154_ta_ph = null;
BEC_2_6_6_SystemObject bevt_155_ta_ph = null;
BEC_2_6_6_SystemObject bevt_156_ta_ph = null;
BEC_2_4_6_TextString bevt_157_ta_ph = null;
BEC_2_5_4_LogicBool bevt_158_ta_ph = null;
BEC_2_4_3_MathInt bevt_159_ta_ph = null;
BEC_2_4_3_MathInt bevt_160_ta_ph = null;
BEC_2_6_6_SystemObject bevt_161_ta_ph = null;
BEC_2_6_6_SystemObject bevt_162_ta_ph = null;
BEC_2_6_6_SystemObject bevt_163_ta_ph = null;
BEC_2_6_6_SystemObject bevt_164_ta_ph = null;
BEC_2_6_6_SystemObject bevt_165_ta_ph = null;
BEC_2_6_6_SystemObject bevt_166_ta_ph = null;
BEC_2_6_6_SystemObject bevt_167_ta_ph = null;
BEC_2_6_6_SystemObject bevt_168_ta_ph = null;
BEC_2_6_6_SystemObject bevt_169_ta_ph = null;
BEC_2_6_6_SystemObject bevt_170_ta_ph = null;
BEC_2_6_6_SystemObject bevt_171_ta_ph = null;
BEC_2_6_6_SystemObject bevt_172_ta_ph = null;
BEC_2_5_4_LogicBool bevt_173_ta_ph = null;
BEC_2_6_6_SystemObject bevt_174_ta_ph = null;
BEC_2_6_6_SystemObject bevt_175_ta_ph = null;
BEC_2_6_6_SystemObject bevt_176_ta_ph = null;
BEC_2_6_6_SystemObject bevt_177_ta_ph = null;
BEC_2_6_6_SystemObject bevt_178_ta_ph = null;
BEC_2_6_6_SystemObject bevt_179_ta_ph = null;
BEC_2_6_6_SystemObject bevt_180_ta_ph = null;
BEC_2_6_6_SystemObject bevt_181_ta_ph = null;
BEC_2_6_6_SystemObject bevt_182_ta_ph = null;
BEC_2_6_6_SystemObject bevt_183_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_184_ta_ph = null;
BEC_2_4_6_TextString bevt_185_ta_ph = null;
BEC_2_6_6_SystemObject bevt_186_ta_ph = null;
BEC_2_5_4_LogicBool bevt_187_ta_ph = null;
BEC_2_6_6_SystemObject bevt_188_ta_ph = null;
BEC_2_6_6_SystemObject bevt_189_ta_ph = null;
BEC_2_6_6_SystemObject bevt_190_ta_ph = null;
BEC_2_6_6_SystemObject bevt_191_ta_ph = null;
BEC_2_6_6_SystemObject bevt_192_ta_ph = null;
BEC_2_4_6_TextString bevt_193_ta_ph = null;
BEC_2_6_6_SystemObject bevt_194_ta_ph = null;
BEC_2_5_4_LogicBool bevt_195_ta_ph = null;
BEC_2_6_6_SystemObject bevt_196_ta_ph = null;
BEC_2_6_6_SystemObject bevt_197_ta_ph = null;
BEC_2_6_6_SystemObject bevt_198_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_199_ta_ph = null;
BEC_2_4_6_TextString bevt_200_ta_ph = null;
BEC_2_6_6_SystemObject bevt_201_ta_ph = null;
BEC_2_6_6_SystemObject bevt_202_ta_ph = null;
BEC_2_6_6_SystemObject bevt_203_ta_ph = null;
BEC_2_6_6_SystemObject bevt_204_ta_ph = null;
BEC_2_6_6_SystemObject bevt_205_ta_ph = null;
BEC_2_6_6_SystemObject bevt_206_ta_ph = null;
BEC_2_5_4_LogicBool bevt_207_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_208_ta_ph = null;
BEC_2_4_6_TextString bevt_209_ta_ph = null;
BEC_2_4_6_TextString bevt_210_ta_ph = null;
BEC_2_4_6_TextString bevt_211_ta_ph = null;
BEC_2_4_6_TextString bevt_212_ta_ph = null;
BEC_2_6_6_SystemObject bevt_213_ta_ph = null;
BEC_2_4_6_TextString bevt_214_ta_ph = null;
BEC_2_6_6_SystemObject bevt_215_ta_ph = null;
BEC_2_6_6_SystemObject bevt_216_ta_ph = null;
BEC_2_6_6_SystemObject bevt_217_ta_ph = null;
BEC_2_6_6_SystemObject bevt_218_ta_ph = null;
BEC_2_6_6_SystemObject bevt_219_ta_ph = null;
BEC_2_6_6_SystemObject bevt_220_ta_ph = null;
BEC_2_6_6_SystemObject bevt_221_ta_ph = null;
BEC_2_5_4_LogicBool bevt_222_ta_ph = null;
BEC_2_6_6_SystemObject bevt_223_ta_ph = null;
BEC_2_6_6_SystemObject bevt_224_ta_ph = null;
BEC_2_6_6_SystemObject bevt_225_ta_ph = null;
BEC_2_6_6_SystemObject bevt_226_ta_ph = null;
BEC_2_6_6_SystemObject bevt_227_ta_ph = null;
BEC_2_6_6_SystemObject bevt_228_ta_ph = null;
BEC_2_5_4_LogicBool bevt_229_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_230_ta_ph = null;
BEC_2_4_6_TextString bevt_231_ta_ph = null;
BEC_2_6_6_SystemObject bevt_232_ta_ph = null;
BEC_2_5_4_LogicBool bevt_233_ta_ph = null;
BEC_2_6_6_SystemObject bevt_234_ta_ph = null;
BEC_2_5_4_LogicBool bevt_235_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_236_ta_ph = null;
BEC_2_6_6_SystemObject bevt_237_ta_ph = null;
BEC_2_6_6_SystemObject bevt_238_ta_ph = null;
BEC_2_6_6_SystemObject bevt_239_ta_ph = null;
BEC_2_6_6_SystemObject bevt_240_ta_ph = null;
BEC_2_6_6_SystemObject bevt_241_ta_ph = null;
BEC_2_6_6_SystemObject bevt_242_ta_ph = null;
BEC_2_6_6_SystemObject bevt_243_ta_ph = null;
BEC_2_6_6_SystemObject bevt_244_ta_ph = null;
BEC_2_6_6_SystemObject bevt_245_ta_ph = null;
BEC_2_6_6_SystemObject bevt_246_ta_ph = null;
BEC_2_6_6_SystemObject bevt_247_ta_ph = null;
BEC_2_4_6_TextString bevt_248_ta_ph = null;
BEC_2_6_6_SystemObject bevt_249_ta_ph = null;
BEC_2_5_4_LogicBool bevt_250_ta_ph = null;
BEC_2_6_6_SystemObject bevt_251_ta_ph = null;
BEC_2_5_4_LogicBool bevt_252_ta_ph = null;
BEC_2_6_6_SystemObject bevt_253_ta_ph = null;
BEC_2_6_6_SystemObject bevt_254_ta_ph = null;
BEC_2_5_4_LogicBool bevt_255_ta_ph = null;
BEC_2_6_6_SystemObject bevt_256_ta_ph = null;
BEC_2_6_6_SystemObject bevt_257_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_258_ta_ph = null;
BEC_2_4_6_TextString bevt_259_ta_ph = null;
BEC_2_6_6_SystemObject bevt_260_ta_ph = null;
BEC_2_6_6_SystemObject bevt_261_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_262_ta_ph = null;
BEC_2_6_6_SystemObject bevt_263_ta_ph = null;
BEC_2_6_6_SystemObject bevt_264_ta_ph = null;
BEC_2_6_6_SystemObject bevt_265_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_266_ta_ph = null;
BEC_2_6_6_SystemObject bevt_267_ta_ph = null;
BEC_2_6_6_SystemObject bevt_268_ta_ph = null;
BEC_2_5_4_LogicBool bevt_269_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_270_ta_ph = null;
BEC_2_4_6_TextString bevt_271_ta_ph = null;
BEC_2_5_4_LogicBool bevt_272_ta_ph = null;
BEC_2_5_4_LogicBool bevt_273_ta_ph = null;
BEC_2_4_6_TextString bevt_274_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_275_ta_ph = null;
BEC_2_4_6_TextString bevt_276_ta_ph = null;
BEC_2_6_6_SystemObject bevt_277_ta_ph = null;
BEC_2_5_4_LogicBool bevt_278_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_279_ta_ph = null;
BEC_2_4_6_TextString bevt_280_ta_ph = null;
BEC_2_4_6_TextString bevt_281_ta_ph = null;
BEC_2_4_6_TextString bevt_282_ta_ph = null;
BEC_2_4_6_TextString bevt_283_ta_ph = null;
BEC_2_6_6_SystemObject bevt_284_ta_ph = null;
BEC_2_6_6_SystemObject bevt_285_ta_ph = null;
BEC_2_4_6_TextString bevt_286_ta_ph = null;
BEC_2_4_6_TextString bevt_287_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_288_ta_ph = null;
BEC_2_5_4_LogicBool bevt_289_ta_ph = null;
BEC_2_5_4_LogicBool bevt_290_ta_ph = null;
BEC_2_4_3_MathInt bevt_291_ta_ph = null;
BEC_2_5_4_LogicBool bevt_292_ta_ph = null;
BEC_2_5_4_LogicBool bevt_293_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_294_ta_ph = null;
BEC_2_4_6_TextString bevt_295_ta_ph = null;
BEC_2_5_4_LogicBool bevt_296_ta_ph = null;
BEC_2_4_3_MathInt bevt_297_ta_ph = null;
BEC_2_4_3_MathInt bevt_298_ta_ph = null;
BEC_2_5_4_LogicBool bevt_299_ta_ph = null;
BEC_2_4_3_MathInt bevt_300_ta_ph = null;
BEC_2_4_3_MathInt bevt_301_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_302_ta_ph = null;
BEC_2_4_6_TextString bevt_303_ta_ph = null;
BEC_2_4_6_TextString bevt_304_ta_ph = null;
BEC_2_4_6_TextString bevt_305_ta_ph = null;
BEC_2_4_3_MathInt bevt_306_ta_ph = null;
BEC_2_5_4_LogicBool bevt_307_ta_ph = null;
BEC_2_4_3_MathInt bevt_308_ta_ph = null;
BEC_2_4_3_MathInt bevt_309_ta_ph = null;
BEC_2_5_4_LogicBool bevt_310_ta_ph = null;
BEC_2_5_4_LogicBool bevt_311_ta_ph = null;
BEC_2_6_6_SystemObject bevt_312_ta_ph = null;
BEC_2_5_4_LogicBool bevt_313_ta_ph = null;
BEC_2_6_6_SystemObject bevt_314_ta_ph = null;
BEC_2_6_6_SystemObject bevt_315_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_316_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_317_ta_ph = null;
BEC_2_6_6_SystemObject bevt_318_ta_ph = null;
BEC_2_6_6_SystemObject bevt_319_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_320_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_321_ta_ph = null;
BEC_2_4_6_TextString bevt_322_ta_ph = null;
BEC_2_5_4_LogicBool bevt_323_ta_ph = null;
BEC_2_5_4_LogicBool bevt_324_ta_ph = null;
BEC_2_4_6_TextString bevt_325_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_326_ta_ph = null;
BEC_2_4_6_TextString bevt_327_ta_ph = null;
BEC_2_6_6_SystemObject bevt_328_ta_ph = null;
BEC_2_5_4_LogicBool bevt_329_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_330_ta_ph = null;
BEC_2_4_6_TextString bevt_331_ta_ph = null;
BEC_2_4_6_TextString bevt_332_ta_ph = null;
BEC_2_4_6_TextString bevt_333_ta_ph = null;
BEC_2_4_6_TextString bevt_334_ta_ph = null;
BEC_2_4_6_TextString bevt_335_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_336_ta_ph = null;
BEC_2_4_6_TextString bevt_337_ta_ph = null;
BEC_2_4_6_TextString bevt_338_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_339_ta_ph = null;
BEC_2_5_4_BuildNode bevt_340_ta_ph = null;
bevt_12_ta_ph = beva_node.bem_typenameGet_0();
bevt_13_ta_ph = bevp_ntypes.bem_CATCHGet_0();
if (bevt_12_ta_ph.bevi_int == bevt_13_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 493*/ {
bevt_19_ta_ph = beva_node.bem_containedGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bem_firstGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bemd_0(-1599063965);
bevt_16_ta_ph = bevt_17_ta_ph.bemd_0(1117833636);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(1712678790);
bevt_14_ta_ph = bevt_15_ta_ph.bemd_0(1463424675);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 494*/ {
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_0));
bevt_20_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_21_ta_ph);
throw new be.BECS_ThrowBack(bevt_20_ta_ph);
} /* Line: 495*/
} /* Line: 494*/
bevt_23_ta_ph = beva_node.bem_typenameGet_0();
bevt_24_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_23_ta_ph.bevi_int == bevt_24_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 498*/ {
bevp_inClass = beva_node;
bevt_25_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_25_ta_ph.bemd_0(-932925423);
bevt_26_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_26_ta_ph.bemd_0(-940042464);
} /* Line: 501*/
bevt_28_ta_ph = beva_node.bem_typenameGet_0();
bevt_29_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_28_ta_ph.bevi_int == bevt_29_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 503*/ {
bevp_cpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 504*/
bevt_31_ta_ph = beva_node.bem_typenameGet_0();
bevt_32_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_31_ta_ph.bevi_int == bevt_32_ta_ph.bevi_int) {
bevt_30_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_30_ta_ph.bevi_bool)/* Line: 506*/ {
bevt_33_ta_ph = beva_node.bem_heldGet_0();
bevt_33_ta_ph.bemd_1(-322237403, bevp_cpos);
bevp_cpos = bevp_cpos.bem_increment_0();
bevt_34_ta_ph = beva_node.bem_containedGet_0();
bevt_0_ta_loop = bevt_34_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 509*/ {
bevt_35_ta_ph = bevt_0_ta_loop.bemd_0(-1024297580);
if (((BEC_2_5_4_LogicBool) bevt_35_ta_ph).bevi_bool)/* Line: 509*/ {
bevl_cci = (BEC_2_5_4_BuildNode) bevt_0_ta_loop.bemd_0(-12961780);
bevt_37_ta_ph = bevl_cci.bem_typenameGet_0();
bevt_38_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_37_ta_ph.bevi_int == bevt_38_ta_ph.bevi_int) {
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 510*/ {
bevt_39_ta_ph = bevl_cci.bem_heldGet_0();
bevt_39_ta_ph.bemd_1(64937568, beva_node);
} /* Line: 511*/
} /* Line: 510*/
 else /* Line: 509*/ {
break;
} /* Line: 509*/
} /* Line: 509*/
bevt_42_ta_ph = beva_node.bem_heldGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bemd_0(-623202179);
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_1));
bevt_40_ta_ph = bevt_41_ta_ph.bemd_1(354557818, bevt_43_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 522*/ {
bevt_44_ta_ph = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_44_ta_ph.bem_firstGet_0();
bevt_46_ta_ph = bevl_targ.bem_heldGet_0();
bevt_45_ta_ph = bevt_46_ta_ph.bemd_0(-778417959);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 525*/ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 526*/
 else /* Line: 527*/ {
bevt_48_ta_ph = bevp_inClassSyn.bemd_0(-1319528275);
bevt_50_ta_ph = bevl_targ.bem_heldGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bemd_0(-916206427);
bevt_47_ta_ph = bevt_48_ta_ph.bemd_1(-179596882, bevt_49_ta_ph);
bevl_tany = bevt_47_ta_ph.bemd_0(-131723669);
} /* Line: 528*/
bevt_52_ta_ph = bevl_tany.bemd_0(1463424675);
bevt_51_ta_ph = bevt_52_ta_ph.bemd_0(560923354);
if (((BEC_2_5_4_LogicBool) bevt_51_ta_ph).bevi_bool)/* Line: 531*/ {
bevt_53_ta_ph = beva_node.bem_heldGet_0();
bevt_54_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_53_ta_ph.bemd_1(1274739494, bevt_54_ta_ph);
} /* Line: 532*/
 else /* Line: 533*/ {
bevl_org = beva_node.bem_secondGet_0();
bevt_56_ta_ph = bevl_org.bem_typenameGet_0();
bevt_57_ta_ph = bevp_ntypes.bem_TRUEGet_0();
if (bevt_56_ta_ph.bevi_int == bevt_57_ta_ph.bevi_int) {
bevt_55_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_55_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_55_ta_ph.bevi_bool)/* Line: 535*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 535*/ {
bevt_59_ta_ph = bevl_org.bem_typenameGet_0();
bevt_60_ta_ph = bevp_ntypes.bem_FALSEGet_0();
if (bevt_59_ta_ph.bevi_int == bevt_60_ta_ph.bevi_int) {
bevt_58_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_58_ta_ph.bevi_bool)/* Line: 535*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 535*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 535*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 535*/ {
bevt_61_ta_ph = beva_node.bem_heldGet_0();
bevt_62_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_61_ta_ph.bemd_1(1274739494, bevt_62_ta_ph);
} /* Line: 537*/
 else /* Line: 538*/ {
bevt_64_ta_ph = bevl_org.bem_typenameGet_0();
bevt_65_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_64_ta_ph.bevi_int == bevt_65_ta_ph.bevi_int) {
bevt_63_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_63_ta_ph.bevi_bool)/* Line: 539*/ {
bevt_67_ta_ph = bevl_org.bem_heldGet_0();
bevt_66_ta_ph = bevt_67_ta_ph.bemd_0(-778417959);
if (((BEC_2_5_4_LogicBool) bevt_66_ta_ph).bevi_bool)/* Line: 540*/ {
bevl_oany = bevl_org.bem_heldGet_0();
} /* Line: 541*/
 else /* Line: 542*/ {
bevt_69_ta_ph = bevp_inClassSyn.bemd_0(-1319528275);
bevt_71_ta_ph = bevl_org.bem_heldGet_0();
bevt_70_ta_ph = bevt_71_ta_ph.bemd_0(-916206427);
bevt_68_ta_ph = bevt_69_ta_ph.bemd_1(-179596882, bevt_70_ta_ph);
bevl_oany = bevt_68_ta_ph.bemd_0(-131723669);
} /* Line: 544*/
} /* Line: 540*/
 else /* Line: 539*/ {
bevt_73_ta_ph = bevl_org.bem_typenameGet_0();
bevt_74_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_73_ta_ph.bevi_int == bevt_74_ta_ph.bevi_int) {
bevt_72_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_72_ta_ph.bevi_bool)/* Line: 547*/ {
bevt_75_ta_ph = bevl_org.bem_containedGet_0();
bevl_ctarg = (BEC_2_5_4_BuildNode) bevt_75_ta_ph.bem_firstGet_0();
bevt_77_ta_ph = bevl_ctarg.bem_heldGet_0();
bevt_76_ta_ph = bevt_77_ta_ph.bemd_0(-778417959);
if (((BEC_2_5_4_LogicBool) bevt_76_ta_ph).bevi_bool)/* Line: 550*/ {
bevl_cany = bevl_ctarg.bem_heldGet_0();
} /* Line: 552*/
 else /* Line: 553*/ {
bevt_79_ta_ph = bevp_inClassSyn.bemd_0(-1319528275);
bevt_81_ta_ph = bevl_ctarg.bem_heldGet_0();
bevt_80_ta_ph = bevt_81_ta_ph.bemd_0(-916206427);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_1(-179596882, bevt_80_ta_ph);
bevl_cany = bevt_78_ta_ph.bemd_0(-131723669);
} /* Line: 555*/
bevl_syn = null;
bevt_84_ta_ph = bevl_org.bem_heldGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bemd_0(873778313);
if (bevt_83_ta_ph == null) {
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 559*/ {
bevt_86_ta_ph = bevl_org.bem_heldGet_0();
bevt_85_ta_ph = bevt_86_ta_ph.bemd_0(873778313);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_85_ta_ph);
} /* Line: 560*/
 else /* Line: 559*/ {
bevt_87_ta_ph = bevl_cany.bemd_0(1463424675);
if (((BEC_2_5_4_LogicBool) bevt_87_ta_ph).bevi_bool)/* Line: 561*/ {
bevt_88_ta_ph = bevl_cany.bemd_0(-932925423);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_88_ta_ph);
} /* Line: 563*/
} /* Line: 559*/
if (bevl_syn == null) {
bevt_89_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_89_ta_ph.bevi_bool)/* Line: 565*/ {
bevt_90_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_92_ta_ph = bevl_org.bem_heldGet_0();
bevt_91_ta_ph = bevt_92_ta_ph.bemd_0(-916206427);
bevl_mtdc = bevt_90_ta_ph.bem_get_1(bevt_91_ta_ph);
if (bevl_mtdc == null) {
bevt_93_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_93_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_93_ta_ph.bevi_bool)/* Line: 567*/ {
bevt_94_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_95_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_0;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_94_ta_ph.bem_get_1(bevt_95_ta_ph);
if (bevl_fcms == null) {
bevt_96_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_96_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_96_ta_ph.bevi_bool)/* Line: 569*/ {
bevt_99_ta_ph = bevl_fcms.bem_originGet_0();
bevt_98_ta_ph = bevt_99_ta_ph.bem_toString_0();
bevt_100_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_1;
bevt_97_ta_ph = bevt_98_ta_ph.bem_notEquals_1(bevt_100_ta_ph);
if (bevt_97_ta_ph.bevi_bool)/* Line: 569*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 569*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 569*/
 else /* Line: 569*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 569*/ {
bevt_101_ta_ph = bevl_org.bem_heldGet_0();
bevt_102_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_101_ta_ph.bemd_1(-867739393, bevt_102_ta_ph);
} /* Line: 570*/
 else /* Line: 571*/ {
bevt_107_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_2;
bevt_109_ta_ph = bevl_org.bem_heldGet_0();
bevt_108_ta_ph = bevt_109_ta_ph.bemd_0(-916206427);
bevt_106_ta_ph = bevt_107_ta_ph.bem_add_1(bevt_108_ta_ph);
bevt_110_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_3;
bevt_105_ta_ph = bevt_106_ta_ph.bem_add_1(bevt_110_ta_ph);
bevt_111_ta_ph = bevl_syn.bem_namepathGet_0();
bevt_104_ta_ph = bevt_105_ta_ph.bem_add_1(bevt_111_ta_ph);
bevt_103_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_104_ta_ph, bevl_org);
throw new be.BECS_ThrowBack(bevt_103_ta_ph);
} /* Line: 572*/
} /* Line: 569*/
 else /* Line: 574*/ {
bevl_oany = bevl_mtdc.bemd_0(-146333296);
} /* Line: 575*/
} /* Line: 567*/
} /* Line: 565*/
} /* Line: 539*/
if (bevl_oany == null) {
bevt_112_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_112_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_112_ta_ph.bevi_bool)/* Line: 579*/ {
bevt_113_ta_ph = bevl_oany.bemd_0(1463424675);
if (((BEC_2_5_4_LogicBool) bevt_113_ta_ph).bevi_bool)/* Line: 579*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 579*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 579*/
 else /* Line: 579*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 579*/ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_114_ta_ph = bevl_oany.bemd_0(377176253);
if (((BEC_2_5_4_LogicBool) bevt_114_ta_ph).bevi_bool)/* Line: 582*/ {
if (bevl_syn == null) {
bevt_115_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_115_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_115_ta_ph.bevi_bool)/* Line: 584*/ {
bevt_117_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_6));
bevt_116_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_117_ta_ph);
throw new be.BECS_ThrowBack(bevt_116_ta_ph);
} /* Line: 585*/
bevt_119_ta_ph = bevl_mtdc.bemd_0(-1759920707);
bevt_120_ta_ph = bevl_tany.bemd_0(-932925423);
bevt_118_ta_ph = bevt_119_ta_ph.bemd_1(-840953319, bevt_120_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_118_ta_ph).bevi_bool)/* Line: 590*/ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 592*/
 else /* Line: 590*/ {
bevt_122_ta_ph = bevp_build.bem_emitCommonGet_0();
if (bevt_122_ta_ph == null) {
bevt_121_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_121_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_121_ta_ph.bevi_bool)/* Line: 593*/ {
bevt_125_ta_ph = bevp_build.bem_emitCommonGet_0();
bevt_124_ta_ph = bevt_125_ta_ph.bem_covariantReturnsGet_0();
bevt_123_ta_ph = bevt_124_ta_ph.bemd_0(560923354);
if (((BEC_2_5_4_LogicBool) bevt_123_ta_ph).bevi_bool)/* Line: 593*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 593*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 593*/
 else /* Line: 593*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 593*/ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 594*/
} /* Line: 590*/
} /* Line: 590*/
 else /* Line: 582*/ {
if (bevl_mtdc == null) {
bevt_126_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_126_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_126_ta_ph.bevi_bool)/* Line: 596*/ {
bevt_127_ta_ph = bevl_mtdc.bemd_2(636259042, bevl_syn, bevp_build);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_127_ta_ph);
} /* Line: 597*/
 else /* Line: 598*/ {
bevt_128_ta_ph = bevl_oany.bemd_0(-932925423);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_128_ta_ph);
} /* Line: 599*/
} /* Line: 582*/
bevt_130_ta_ph = bevl_tany.bemd_0(-932925423);
bevt_129_ta_ph = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_130_ta_ph );
if (((BEC_2_5_4_LogicBool) bevt_129_ta_ph).bevi_bool)/* Line: 603*/ {
bevt_131_ta_ph = beva_node.bem_heldGet_0();
bevt_132_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_131_ta_ph.bemd_1(1274739494, bevt_132_ta_ph);
} /* Line: 605*/
 else /* Line: 606*/ {
bevt_133_ta_ph = bevl_oany.bemd_0(377176253);
if (((BEC_2_5_4_LogicBool) bevt_133_ta_ph).bevi_bool)/* Line: 607*/ {
bevl_ovnp = bevl_syn.bem_namepathGet_0();
} /* Line: 608*/
 else /* Line: 609*/ {
bevl_ovnp = bevl_oany.bemd_0(-932925423);
} /* Line: 610*/
bevt_134_ta_ph = bevl_tany.bemd_0(-932925423);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_134_ta_ph);
bevt_135_ta_ph = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevl_ovnp );
if (((BEC_2_5_4_LogicBool) bevt_135_ta_ph).bevi_bool)/* Line: 613*/ {
bevt_136_ta_ph = beva_node.bem_heldGet_0();
bevt_137_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_136_ta_ph.bemd_1(1274739494, bevt_137_ta_ph);
} /* Line: 615*/
 else /* Line: 616*/ {
bevt_142_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_4;
bevt_144_ta_ph = bevl_syn.bem_namepathGet_0();
bevt_143_ta_ph = bevt_144_ta_ph.bem_toString_0();
bevt_141_ta_ph = bevt_142_ta_ph.bem_add_1(bevt_143_ta_ph);
bevt_145_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_5;
bevt_140_ta_ph = bevt_141_ta_ph.bem_add_1(bevt_145_ta_ph);
bevt_146_ta_ph = bevl_ovnp.bemd_0(-1990292643);
bevt_139_ta_ph = bevt_140_ta_ph.bem_add_1(bevt_146_ta_ph);
bevt_138_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_139_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_138_ta_ph);
} /* Line: 617*/
} /* Line: 613*/
if (bevl_castForSelf.bevi_bool)/* Line: 621*/ {
bevt_147_ta_ph = beva_node.bem_heldGet_0();
bevt_148_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_147_ta_ph.bemd_1(1274739494, bevt_148_ta_ph);
bevt_149_ta_ph = beva_node.bem_heldGet_0();
bevt_150_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_9));
bevt_149_ta_ph.bemd_1(291095370, bevt_150_ta_ph);
} /* Line: 624*/
} /* Line: 621*/
bevt_153_ta_ph = bevl_targ.bem_heldGet_0();
bevt_152_ta_ph = bevt_153_ta_ph.bemd_0(-932925423);
if (bevt_152_ta_ph == null) {
bevt_151_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_151_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_151_ta_ph.bevi_bool)/* Line: 627*/ {
} /* Line: 627*/
} /* Line: 627*/
} /* Line: 535*/
} /* Line: 531*/
 else /* Line: 522*/ {
bevt_156_ta_ph = beva_node.bem_heldGet_0();
bevt_155_ta_ph = bevt_156_ta_ph.bemd_0(-623202179);
bevt_157_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_10));
bevt_154_ta_ph = bevt_155_ta_ph.bemd_1(354557818, bevt_157_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_154_ta_ph).bevi_bool)/* Line: 632*/ {
bevl_targ = beva_node.bem_secondGet_0();
bevt_159_ta_ph = bevl_targ.bem_typenameGet_0();
bevt_160_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_159_ta_ph.bevi_int == bevt_160_ta_ph.bevi_int) {
bevt_158_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_158_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_158_ta_ph.bevi_bool)/* Line: 634*/ {
bevt_162_ta_ph = bevl_targ.bem_heldGet_0();
bevt_161_ta_ph = bevt_162_ta_ph.bemd_0(-778417959);
if (((BEC_2_5_4_LogicBool) bevt_161_ta_ph).bevi_bool)/* Line: 635*/ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 636*/
 else /* Line: 637*/ {
bevt_164_ta_ph = bevp_inClassSyn.bemd_0(-1319528275);
bevt_166_ta_ph = bevl_targ.bem_heldGet_0();
bevt_165_ta_ph = bevt_166_ta_ph.bemd_0(-916206427);
bevt_163_ta_ph = bevt_164_ta_ph.bemd_1(-179596882, bevt_165_ta_ph);
bevl_tany = bevt_163_ta_ph.bemd_0(-131723669);
} /* Line: 638*/
bevl_mtdmy = beva_node.bem_scopeGet_0();
bevt_168_ta_ph = bevl_targ.bem_heldGet_0();
bevt_167_ta_ph = bevt_168_ta_ph.bemd_0(-778417959);
if (((BEC_2_5_4_LogicBool) bevt_167_ta_ph).bevi_bool)/* Line: 642*/ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 643*/
 else /* Line: 644*/ {
bevt_170_ta_ph = bevp_inClassSyn.bemd_0(-1319528275);
bevt_172_ta_ph = bevl_targ.bem_heldGet_0();
bevt_171_ta_ph = bevt_172_ta_ph.bemd_0(-916206427);
bevt_169_ta_ph = bevt_170_ta_ph.bemd_1(-179596882, bevt_171_ta_ph);
bevl_tany = bevt_169_ta_ph.bemd_0(-131723669);
} /* Line: 645*/
bevt_175_ta_ph = bevl_mtdmy.bemd_0(1712678790);
bevt_174_ta_ph = bevt_175_ta_ph.bemd_0(-2059569868);
if (bevt_174_ta_ph == null) {
bevt_173_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_173_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_173_ta_ph.bevi_bool)/* Line: 648*/ {
bevt_178_ta_ph = bevl_mtdmy.bemd_0(1712678790);
bevt_177_ta_ph = bevt_178_ta_ph.bemd_0(-2059569868);
bevt_176_ta_ph = bevt_177_ta_ph.bemd_0(1463424675);
if (((BEC_2_5_4_LogicBool) bevt_176_ta_ph).bevi_bool)/* Line: 648*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 648*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 648*/
 else /* Line: 648*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 648*/ {
bevt_180_ta_ph = bevl_tany.bemd_0(1463424675);
bevt_179_ta_ph = bevt_180_ta_ph.bemd_0(560923354);
if (((BEC_2_5_4_LogicBool) bevt_179_ta_ph).bevi_bool)/* Line: 649*/ {
bevt_183_ta_ph = bevl_mtdmy.bemd_0(1712678790);
bevt_182_ta_ph = bevt_183_ta_ph.bemd_0(-2059569868);
bevt_181_ta_ph = bevt_182_ta_ph.bemd_0(1953265694);
if (((BEC_2_5_4_LogicBool) bevt_181_ta_ph).bevi_bool)/* Line: 650*/ {
bevt_185_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(104, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_11));
bevt_184_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_185_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_184_ta_ph);
} /* Line: 651*/
bevt_186_ta_ph = beva_node.bem_heldGet_0();
bevt_187_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_186_ta_ph.bemd_1(1274739494, bevt_187_ta_ph);
} /* Line: 654*/
 else /* Line: 655*/ {
bevt_190_ta_ph = bevl_mtdmy.bemd_0(1712678790);
bevt_189_ta_ph = bevt_190_ta_ph.bemd_0(-2059569868);
bevt_188_ta_ph = bevt_189_ta_ph.bemd_0(377176253);
if (((BEC_2_5_4_LogicBool) bevt_188_ta_ph).bevi_bool)/* Line: 658*/ {
bevt_192_ta_ph = bevl_tany.bemd_0(-916206427);
bevt_193_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_12));
bevt_191_ta_ph = bevt_192_ta_ph.bemd_1(354557818, bevt_193_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_191_ta_ph).bevi_bool)/* Line: 659*/ {
bevt_194_ta_ph = beva_node.bem_heldGet_0();
bevt_195_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_194_ta_ph.bemd_1(1274739494, bevt_195_ta_ph);
} /* Line: 661*/
 else /* Line: 662*/ {
bevt_198_ta_ph = bevl_mtdmy.bemd_0(1712678790);
bevt_197_ta_ph = bevt_198_ta_ph.bemd_0(-2059569868);
bevt_196_ta_ph = bevt_197_ta_ph.bemd_0(1953265694);
if (((BEC_2_5_4_LogicBool) bevt_196_ta_ph).bevi_bool)/* Line: 663*/ {
bevt_200_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(104, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_11));
bevt_199_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_200_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_199_ta_ph);
} /* Line: 664*/
bevt_201_ta_ph = bevl_tany.bemd_0(-932925423);
bevl_targsyn = bevp_build.bem_getSynNp_1(bevt_201_ta_ph);
bevt_203_ta_ph = bevl_tany.bemd_0(-932925423);
bevt_202_ta_ph = bevp_inClassSyn.bemd_1(960236367, bevt_203_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_202_ta_ph).bevi_bool)/* Line: 667*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 667*/ {
bevt_205_ta_ph = bevp_inClassSyn.bemd_0(-932925423);
bevt_204_ta_ph = bevl_targsyn.bemd_1(960236367, bevt_205_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_204_ta_ph).bevi_bool)/* Line: 667*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 667*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 667*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 667*/ {
bevt_206_ta_ph = beva_node.bem_heldGet_0();
bevt_207_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_206_ta_ph.bemd_1(1274739494, bevt_207_ta_ph);
} /* Line: 669*/
 else /* Line: 670*/ {
bevt_212_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_6;
bevt_213_ta_ph = bevp_inClassSyn.bemd_0(-932925423);
bevt_211_ta_ph = bevt_212_ta_ph.bem_add_1(bevt_213_ta_ph);
bevt_214_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_7;
bevt_210_ta_ph = bevt_211_ta_ph.bem_add_1(bevt_214_ta_ph);
bevt_215_ta_ph = bevl_tany.bemd_0(-932925423);
bevt_209_ta_ph = bevt_210_ta_ph.bem_add_1(bevt_215_ta_ph);
bevt_208_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_209_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_208_ta_ph);
} /* Line: 671*/
} /* Line: 667*/
} /* Line: 659*/
 else /* Line: 674*/ {
bevt_216_ta_ph = bevl_tany.bemd_0(-932925423);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_216_ta_ph);
bevt_220_ta_ph = bevl_mtdmy.bemd_0(1712678790);
bevt_219_ta_ph = bevt_220_ta_ph.bemd_0(-2059569868);
bevt_218_ta_ph = bevt_219_ta_ph.bemd_0(-932925423);
bevt_217_ta_ph = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_218_ta_ph );
if (((BEC_2_5_4_LogicBool) bevt_217_ta_ph).bevi_bool)/* Line: 676*/ {
bevt_221_ta_ph = beva_node.bem_heldGet_0();
bevt_222_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_221_ta_ph.bemd_1(1274739494, bevt_222_ta_ph);
} /* Line: 678*/
 else /* Line: 679*/ {
bevt_225_ta_ph = bevl_mtdmy.bemd_0(1712678790);
bevt_224_ta_ph = bevt_225_ta_ph.bemd_0(-2059569868);
bevt_223_ta_ph = bevt_224_ta_ph.bemd_0(-932925423);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_223_ta_ph);
bevt_227_ta_ph = bevl_tany.bemd_0(-932925423);
bevt_226_ta_ph = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_227_ta_ph );
if (((BEC_2_5_4_LogicBool) bevt_226_ta_ph).bevi_bool)/* Line: 681*/ {
bevt_228_ta_ph = beva_node.bem_heldGet_0();
bevt_229_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_228_ta_ph.bemd_1(1274739494, bevt_229_ta_ph);
} /* Line: 683*/
 else /* Line: 684*/ {
bevt_231_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_15));
bevt_230_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_231_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_230_ta_ph);
} /* Line: 685*/
} /* Line: 681*/
} /* Line: 676*/
} /* Line: 658*/
} /* Line: 649*/
 else /* Line: 690*/ {
bevt_232_ta_ph = beva_node.bem_heldGet_0();
bevt_233_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_232_ta_ph.bemd_1(1274739494, bevt_233_ta_ph);
} /* Line: 692*/
} /* Line: 648*/
 else /* Line: 694*/ {
bevt_234_ta_ph = beva_node.bem_heldGet_0();
bevt_235_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_234_ta_ph.bemd_1(1274739494, bevt_235_ta_ph);
} /* Line: 695*/
} /* Line: 634*/
 else /* Line: 697*/ {
bevt_236_ta_ph = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_236_ta_ph.bem_firstGet_0();
bevt_238_ta_ph = bevl_targ.bem_heldGet_0();
bevt_237_ta_ph = bevt_238_ta_ph.bemd_0(-778417959);
if (((BEC_2_5_4_LogicBool) bevt_237_ta_ph).bevi_bool)/* Line: 700*/ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 701*/
 else /* Line: 702*/ {
bevt_240_ta_ph = bevp_inClassSyn.bemd_0(-1319528275);
bevt_242_ta_ph = bevl_targ.bem_heldGet_0();
bevt_241_ta_ph = bevt_242_ta_ph.bemd_0(-916206427);
bevt_239_ta_ph = bevt_240_ta_ph.bemd_1(-179596882, bevt_241_ta_ph);
bevl_tany = bevt_239_ta_ph.bemd_0(-131723669);
} /* Line: 703*/
bevt_244_ta_ph = bevl_tany.bemd_0(1463424675);
bevt_243_ta_ph = bevt_244_ta_ph.bemd_0(560923354);
if (((BEC_2_5_4_LogicBool) bevt_243_ta_ph).bevi_bool)/* Line: 706*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 706*/ {
bevt_247_ta_ph = beva_node.bem_heldGet_0();
bevt_246_ta_ph = bevt_247_ta_ph.bemd_0(-623202179);
bevt_248_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_16));
bevt_245_ta_ph = bevt_246_ta_ph.bemd_1(354557818, bevt_248_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_245_ta_ph).bevi_bool)/* Line: 706*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 706*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 706*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 706*/ {
bevt_249_ta_ph = beva_node.bem_heldGet_0();
bevt_250_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_249_ta_ph.bemd_1(1274739494, bevt_250_ta_ph);
} /* Line: 707*/
 else /* Line: 708*/ {
bevt_251_ta_ph = beva_node.bem_heldGet_0();
bevt_252_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_251_ta_ph.bemd_1(1274739494, bevt_252_ta_ph);
bevt_254_ta_ph = beva_node.bem_heldGet_0();
bevt_253_ta_ph = bevt_254_ta_ph.bemd_0(-175420099);
if (((BEC_2_5_4_LogicBool) bevt_253_ta_ph).bevi_bool)/* Line: 710*/ {
bevt_257_ta_ph = beva_node.bem_heldGet_0();
bevt_256_ta_ph = bevt_257_ta_ph.bemd_0(873778313);
if (bevt_256_ta_ph == null) {
bevt_255_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_255_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_255_ta_ph.bevi_bool)/* Line: 711*/ {
bevt_259_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_17));
bevt_258_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_259_ta_ph);
throw new be.BECS_ThrowBack(bevt_258_ta_ph);
} /* Line: 712*/
bevt_261_ta_ph = beva_node.bem_heldGet_0();
bevt_260_ta_ph = bevt_261_ta_ph.bemd_0(873778313);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_260_ta_ph);
bevt_262_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_264_ta_ph = beva_node.bem_heldGet_0();
bevt_263_ta_ph = bevt_264_ta_ph.bemd_0(-916206427);
bevl_mtdc = bevt_262_ta_ph.bem_get_1(bevt_263_ta_ph);
} /* Line: 715*/
 else /* Line: 716*/ {
bevt_265_ta_ph = bevl_tany.bemd_0(-932925423);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_265_ta_ph);
bevt_266_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_268_ta_ph = beva_node.bem_heldGet_0();
bevt_267_ta_ph = bevt_268_ta_ph.bemd_0(-916206427);
bevl_mtdc = bevt_266_ta_ph.bem_get_1(bevt_267_ta_ph);
} /* Line: 718*/
if (bevl_mtdc == null) {
bevt_269_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_269_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_269_ta_ph.bevi_bool)/* Line: 720*/ {
bevt_270_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_271_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_8;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_270_ta_ph.bem_get_1(bevt_271_ta_ph);
if (bevl_fcms == null) {
bevt_272_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_272_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_272_ta_ph.bevi_bool)/* Line: 722*/ {
bevt_275_ta_ph = bevl_fcms.bem_originGet_0();
bevt_274_ta_ph = bevt_275_ta_ph.bem_toString_0();
bevt_276_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_9;
bevt_273_ta_ph = bevt_274_ta_ph.bem_notEquals_1(bevt_276_ta_ph);
if (bevt_273_ta_ph.bevi_bool)/* Line: 722*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 722*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 722*/
 else /* Line: 722*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 722*/ {
bevt_277_ta_ph = beva_node.bem_heldGet_0();
bevt_278_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_277_ta_ph.bemd_1(-867739393, bevt_278_ta_ph);
} /* Line: 723*/
 else /* Line: 724*/ {
bevt_283_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_10;
bevt_285_ta_ph = beva_node.bem_heldGet_0();
bevt_284_ta_ph = bevt_285_ta_ph.bemd_0(-916206427);
bevt_282_ta_ph = bevt_283_ta_ph.bem_add_1(bevt_284_ta_ph);
bevt_286_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_11;
bevt_281_ta_ph = bevt_282_ta_ph.bem_add_1(bevt_286_ta_ph);
bevt_288_ta_ph = bevl_syn.bem_namepathGet_0();
bevt_287_ta_ph = bevt_288_ta_ph.bem_toString_0();
bevt_280_ta_ph = bevt_281_ta_ph.bem_add_1(bevt_287_ta_ph);
bevt_279_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_280_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_279_ta_ph);
} /* Line: 725*/
} /* Line: 722*/
if (bevl_mtdc == null) {
bevt_289_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_289_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_289_ta_ph.bevi_bool)/* Line: 728*/ {
bevl_argSyns = (BEC_2_9_4_ContainerList) bevl_mtdc.bemd_0(-976504889);
bevl_nnode = bevl_targ.bem_nextPeerGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
/* Line: 731*/ {
bevt_291_ta_ph = bevl_argSyns.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_291_ta_ph.bevi_int) {
bevt_290_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_290_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_290_ta_ph.bevi_bool)/* Line: 731*/ {
bevl_marg = (BEC_2_5_6_BuildVarSyn) bevl_argSyns.bem_get_1(bevl_i);
bevt_292_ta_ph = bevl_marg.bem_isTypedGet_0();
if (bevt_292_ta_ph.bevi_bool)/* Line: 733*/ {
if (bevl_nnode == null) {
bevt_293_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_293_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_293_ta_ph.bevi_bool)/* Line: 734*/ {
bevt_295_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_3_5_5_9_BuildVisitTypeCheck_bels_19));
bevt_294_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_295_ta_ph, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_294_ta_ph);
} /* Line: 735*/
 else /* Line: 734*/ {
bevt_297_ta_ph = bevl_nnode.bem_typenameGet_0();
bevt_298_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_297_ta_ph.bevi_int != bevt_298_ta_ph.bevi_int) {
bevt_296_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_296_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_296_ta_ph.bevi_bool)/* Line: 736*/ {
bevt_300_ta_ph = bevl_nnode.bem_typenameGet_0();
bevt_301_ta_ph = bevp_ntypes.bem_NULLGet_0();
if (bevt_300_ta_ph.bevi_int != bevt_301_ta_ph.bevi_int) {
bevt_299_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_299_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_299_ta_ph.bevi_bool)/* Line: 736*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 736*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 736*/
 else /* Line: 736*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_9_ta_anchor.bevi_bool)/* Line: 736*/ {
bevt_304_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_12;
bevt_306_ta_ph = bevl_nnode.bem_typenameGet_0();
bevt_305_ta_ph = bevt_306_ta_ph.bem_toString_0();
bevt_303_ta_ph = bevt_304_ta_ph.bem_add_1(bevt_305_ta_ph);
bevt_302_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_303_ta_ph, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_302_ta_ph);
} /* Line: 737*/
} /* Line: 734*/
bevt_308_ta_ph = bevl_nnode.bem_typenameGet_0();
bevt_309_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_308_ta_ph.bevi_int == bevt_309_ta_ph.bevi_int) {
bevt_307_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_307_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_307_ta_ph.bevi_bool)/* Line: 739*/ {
bevl_carg = (BEC_2_5_3_BuildVar) bevl_nnode.bem_heldGet_0();
bevt_311_ta_ph = bevl_carg.bem_isTypedGet_0();
if (bevt_311_ta_ph.bevi_bool) {
bevt_310_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_310_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_310_ta_ph.bevi_bool)/* Line: 741*/ {
bevt_312_ta_ph = beva_node.bem_heldGet_0();
bevt_313_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_312_ta_ph.bemd_1(1274739494, bevt_313_ta_ph);
bevt_315_ta_ph = beva_node.bem_heldGet_0();
bevt_314_ta_ph = bevt_315_ta_ph.bemd_0(-332731999);
bevt_316_ta_ph = bevl_marg.bem_namepathGet_0();
bevt_314_ta_ph.bemd_2(-1832936144, bevl_i, bevt_316_ta_ph);
} /* Line: 743*/
 else /* Line: 745*/ {
bevt_317_ta_ph = bevl_carg.bem_namepathGet_0();
bevl_argSyn = bevp_build.bem_getSynNp_1(bevt_317_ta_ph);
bevt_320_ta_ph = bevl_marg.bem_namepathGet_0();
bevt_319_ta_ph = bevl_argSyn.bem_castsTo_1(bevt_320_ta_ph);
bevt_318_ta_ph = bevt_319_ta_ph.bemd_0(560923354);
if (((BEC_2_5_4_LogicBool) bevt_318_ta_ph).bevi_bool)/* Line: 747*/ {
bevt_321_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_322_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_13;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_321_ta_ph.bem_get_1(bevt_322_ta_ph);
if (bevl_fcms == null) {
bevt_323_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_323_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_323_ta_ph.bevi_bool)/* Line: 749*/ {
bevt_326_ta_ph = bevl_fcms.bem_originGet_0();
bevt_325_ta_ph = bevt_326_ta_ph.bem_toString_0();
bevt_327_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_14;
bevt_324_ta_ph = bevt_325_ta_ph.bem_notEquals_1(bevt_327_ta_ph);
if (bevt_324_ta_ph.bevi_bool)/* Line: 749*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 749*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 749*/
 else /* Line: 749*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_10_ta_anchor.bevi_bool)/* Line: 749*/ {
bevt_328_ta_ph = beva_node.bem_heldGet_0();
bevt_329_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_328_ta_ph.bemd_1(-867739393, bevt_329_ta_ph);
} /* Line: 750*/
 else /* Line: 751*/ {
bevt_334_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_15;
bevt_336_ta_ph = bevl_argSyn.bem_namepathGet_0();
bevt_335_ta_ph = bevt_336_ta_ph.bem_toString_0();
bevt_333_ta_ph = bevt_334_ta_ph.bem_add_1(bevt_335_ta_ph);
bevt_337_ta_ph = bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevo_16;
bevt_332_ta_ph = bevt_333_ta_ph.bem_add_1(bevt_337_ta_ph);
bevt_339_ta_ph = bevl_marg.bem_namepathGet_0();
bevt_338_ta_ph = bevt_339_ta_ph.bem_toString_0();
bevt_331_ta_ph = bevt_332_ta_ph.bem_add_1(bevt_338_ta_ph);
bevt_330_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_331_ta_ph, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_330_ta_ph);
} /* Line: 752*/
} /* Line: 749*/
} /* Line: 747*/
} /* Line: 741*/
} /* Line: 739*/
bevl_nnode = bevl_nnode.bem_nextPeerGet_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 731*/
 else /* Line: 731*/ {
break;
} /* Line: 731*/
} /* Line: 731*/
} /* Line: 731*/
} /* Line: 728*/
} /* Line: 706*/
} /* Line: 522*/
} /* Line: 522*/
bevt_340_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_340_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGetDirect_0() {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassGetDirect_0() {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClass = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClass = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGetDirect_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassNp = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassNp = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGetDirect_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassSyn = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassSyn = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() {
return bevp_cpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGetDirect_0() {
return bevp_cpos;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_cposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {493, 493, 493, 493, 494, 494, 494, 494, 494, 494, 495, 495, 495, 498, 498, 498, 498, 499, 500, 500, 501, 501, 503, 503, 503, 503, 504, 506, 506, 506, 506, 507, 507, 508, 509, 509, 0, 509, 509, 510, 510, 510, 510, 511, 511, 522, 522, 522, 522, 523, 523, 525, 525, 526, 528, 528, 528, 528, 528, 531, 531, 532, 532, 532, 534, 535, 535, 535, 535, 0, 535, 535, 535, 535, 0, 0, 537, 537, 537, 539, 539, 539, 539, 540, 540, 541, 544, 544, 544, 544, 544, 547, 547, 547, 547, 548, 548, 550, 550, 552, 555, 555, 555, 555, 555, 558, 559, 559, 559, 559, 560, 560, 560, 561, 563, 563, 565, 565, 566, 566, 566, 566, 567, 567, 568, 568, 568, 569, 569, 569, 569, 569, 569, 0, 0, 0, 570, 570, 570, 572, 572, 572, 572, 572, 572, 572, 572, 572, 572, 575, 579, 579, 579, 0, 0, 0, 581, 582, 584, 584, 585, 585, 585, 590, 590, 590, 592, 593, 593, 593, 593, 593, 593, 0, 0, 0, 594, 596, 596, 597, 597, 599, 599, 603, 603, 605, 605, 605, 607, 608, 610, 612, 612, 613, 615, 615, 615, 617, 617, 617, 617, 617, 617, 617, 617, 617, 617, 623, 623, 623, 624, 624, 624, 627, 627, 627, 627, 632, 632, 632, 632, 633, 634, 634, 634, 634, 635, 635, 636, 638, 638, 638, 638, 638, 641, 642, 642, 643, 645, 645, 645, 645, 645, 648, 648, 648, 648, 648, 648, 648, 0, 0, 0, 649, 649, 650, 650, 650, 651, 651, 651, 654, 654, 654, 658, 658, 658, 659, 659, 659, 661, 661, 661, 663, 663, 663, 664, 664, 664, 666, 666, 667, 667, 0, 667, 667, 0, 0, 669, 669, 669, 671, 671, 671, 671, 671, 671, 671, 671, 671, 675, 675, 676, 676, 676, 676, 678, 678, 678, 680, 680, 680, 680, 681, 681, 683, 683, 683, 685, 685, 685, 692, 692, 692, 695, 695, 695, 698, 698, 700, 700, 701, 703, 703, 703, 703, 703, 706, 706, 0, 706, 706, 706, 706, 0, 0, 707, 707, 707, 709, 709, 709, 710, 710, 711, 711, 711, 711, 712, 712, 712, 714, 714, 714, 715, 715, 715, 715, 717, 717, 718, 718, 718, 718, 720, 720, 721, 721, 721, 722, 722, 722, 722, 722, 722, 0, 0, 0, 723, 723, 723, 725, 725, 725, 725, 725, 725, 725, 725, 725, 725, 725, 728, 728, 729, 730, 731, 731, 731, 731, 732, 733, 734, 734, 735, 735, 735, 736, 736, 736, 736, 736, 736, 736, 736, 0, 0, 0, 737, 737, 737, 737, 737, 737, 739, 739, 739, 739, 740, 741, 741, 741, 742, 742, 742, 743, 743, 743, 743, 746, 746, 747, 747, 747, 748, 748, 748, 749, 749, 749, 749, 749, 749, 0, 0, 0, 750, 750, 750, 752, 752, 752, 752, 752, 752, 752, 752, 752, 752, 752, 762, 731, 768, 768, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {422, 423, 424, 429, 430, 431, 432, 433, 434, 435, 437, 438, 439, 442, 443, 444, 449, 450, 451, 452, 453, 454, 456, 457, 458, 463, 464, 466, 467, 468, 473, 474, 475, 476, 477, 478, 478, 481, 483, 484, 485, 486, 491, 492, 493, 500, 501, 502, 503, 505, 506, 507, 508, 510, 513, 514, 515, 516, 517, 519, 520, 522, 523, 524, 527, 528, 529, 530, 535, 536, 539, 540, 541, 546, 547, 550, 554, 555, 556, 559, 560, 561, 566, 567, 568, 570, 573, 574, 575, 576, 577, 581, 582, 583, 588, 589, 590, 591, 592, 594, 597, 598, 599, 600, 601, 603, 604, 605, 606, 611, 612, 613, 614, 617, 619, 620, 623, 628, 629, 630, 631, 632, 633, 638, 639, 640, 641, 642, 647, 648, 649, 650, 651, 653, 656, 660, 663, 664, 665, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 681, 686, 691, 692, 694, 697, 701, 704, 705, 707, 712, 713, 714, 715, 717, 718, 719, 721, 724, 725, 730, 731, 732, 733, 735, 738, 742, 745, 750, 755, 756, 757, 760, 761, 764, 765, 767, 768, 769, 772, 774, 777, 779, 780, 781, 783, 784, 785, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 801, 802, 803, 804, 805, 806, 809, 810, 811, 816, 822, 823, 824, 825, 827, 828, 829, 830, 835, 836, 837, 839, 842, 843, 844, 845, 846, 848, 849, 850, 852, 855, 856, 857, 858, 859, 861, 862, 863, 868, 869, 870, 871, 873, 876, 880, 883, 884, 886, 887, 888, 890, 891, 892, 894, 895, 896, 899, 900, 901, 903, 904, 905, 907, 908, 909, 912, 913, 914, 916, 917, 918, 920, 921, 922, 923, 925, 928, 929, 931, 934, 938, 939, 940, 943, 944, 945, 946, 947, 948, 949, 950, 951, 956, 957, 958, 959, 960, 961, 963, 964, 965, 968, 969, 970, 971, 972, 973, 975, 976, 977, 980, 981, 982, 989, 990, 991, 995, 996, 997, 1001, 1002, 1003, 1004, 1006, 1009, 1010, 1011, 1012, 1013, 1015, 1016, 1018, 1021, 1022, 1023, 1024, 1026, 1029, 1033, 1034, 1035, 1038, 1039, 1040, 1041, 1042, 1044, 1045, 1046, 1051, 1052, 1053, 1054, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1065, 1066, 1067, 1068, 1069, 1070, 1072, 1077, 1078, 1079, 1080, 1081, 1086, 1087, 1088, 1089, 1090, 1092, 1095, 1099, 1102, 1103, 1104, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1115, 1116, 1117, 1120, 1125, 1126, 1127, 1128, 1131, 1132, 1137, 1138, 1139, 1141, 1146, 1147, 1148, 1149, 1152, 1153, 1154, 1159, 1160, 1161, 1162, 1167, 1168, 1171, 1175, 1178, 1179, 1180, 1181, 1182, 1183, 1186, 1187, 1188, 1193, 1194, 1195, 1196, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1211, 1212, 1213, 1214, 1215, 1217, 1218, 1219, 1220, 1225, 1226, 1227, 1228, 1229, 1231, 1234, 1238, 1241, 1242, 1243, 1246, 1247, 1248, 1249, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1262, 1263, 1274, 1275, 1278, 1281, 1284, 1288, 1292, 1295, 1298, 1302, 1306, 1309, 1312, 1316, 1320, 1323, 1326, 1330, 1334, 1337, 1340, 1344};
/* BEGIN LINEINFO 
assign 1 493 422
typenameGet 0 493 422
assign 1 493 423
CATCHGet 0 493 423
assign 1 493 424
equals 1 493 429
assign 1 494 430
containedGet 0 494 430
assign 1 494 431
firstGet 0 494 431
assign 1 494 432
containedGet 0 494 432
assign 1 494 433
firstGet 0 494 433
assign 1 494 434
heldGet 0 494 434
assign 1 494 435
isTypedGet 0 494 435
assign 1 495 437
new 0 495 437
assign 1 495 438
new 1 495 438
throw 1 495 439
assign 1 498 442
typenameGet 0 498 442
assign 1 498 443
CLASSGet 0 498 443
assign 1 498 444
equals 1 498 449
assign 1 499 450
assign 1 500 451
heldGet 0 500 451
assign 1 500 452
namepathGet 0 500 452
assign 1 501 453
heldGet 0 501 453
assign 1 501 454
synGet 0 501 454
assign 1 503 456
typenameGet 0 503 456
assign 1 503 457
METHODGet 0 503 457
assign 1 503 458
equals 1 503 463
assign 1 504 464
new 0 504 464
assign 1 506 466
typenameGet 0 506 466
assign 1 506 467
CALLGet 0 506 467
assign 1 506 468
equals 1 506 473
assign 1 507 474
heldGet 0 507 474
cposSet 1 507 475
assign 1 508 476
increment 0 508 476
assign 1 509 477
containedGet 0 509 477
assign 1 509 478
iteratorGet 0 0 478
assign 1 509 481
hasNextGet 0 509 481
assign 1 509 483
nextGet 0 509 483
assign 1 510 484
typenameGet 0 510 484
assign 1 510 485
VARGet 0 510 485
assign 1 510 486
equals 1 510 491
assign 1 511 492
heldGet 0 511 492
addCall 1 511 493
assign 1 522 500
heldGet 0 522 500
assign 1 522 501
orgNameGet 0 522 501
assign 1 522 502
new 0 522 502
assign 1 522 503
equals 1 522 503
assign 1 523 505
containedGet 0 523 505
assign 1 523 506
firstGet 0 523 506
assign 1 525 507
heldGet 0 525 507
assign 1 525 508
isDeclaredGet 0 525 508
assign 1 526 510
heldGet 0 526 510
assign 1 528 513
ptyMapGet 0 528 513
assign 1 528 514
heldGet 0 528 514
assign 1 528 515
nameGet 0 528 515
assign 1 528 516
get 1 528 516
assign 1 528 517
memSynGet 0 528 517
assign 1 531 519
isTypedGet 0 531 519
assign 1 531 520
not 0 531 520
assign 1 532 522
heldGet 0 532 522
assign 1 532 523
new 0 532 523
checkTypesSet 1 532 524
assign 1 534 527
secondGet 0 534 527
assign 1 535 528
typenameGet 0 535 528
assign 1 535 529
TRUEGet 0 535 529
assign 1 535 530
equals 1 535 535
assign 1 0 536
assign 1 535 539
typenameGet 0 535 539
assign 1 535 540
FALSEGet 0 535 540
assign 1 535 541
equals 1 535 546
assign 1 0 547
assign 1 0 550
assign 1 537 554
heldGet 0 537 554
assign 1 537 555
new 0 537 555
checkTypesSet 1 537 556
assign 1 539 559
typenameGet 0 539 559
assign 1 539 560
VARGet 0 539 560
assign 1 539 561
equals 1 539 566
assign 1 540 567
heldGet 0 540 567
assign 1 540 568
isDeclaredGet 0 540 568
assign 1 541 570
heldGet 0 541 570
assign 1 544 573
ptyMapGet 0 544 573
assign 1 544 574
heldGet 0 544 574
assign 1 544 575
nameGet 0 544 575
assign 1 544 576
get 1 544 576
assign 1 544 577
memSynGet 0 544 577
assign 1 547 581
typenameGet 0 547 581
assign 1 547 582
CALLGet 0 547 582
assign 1 547 583
equals 1 547 588
assign 1 548 589
containedGet 0 548 589
assign 1 548 590
firstGet 0 548 590
assign 1 550 591
heldGet 0 550 591
assign 1 550 592
isDeclaredGet 0 550 592
assign 1 552 594
heldGet 0 552 594
assign 1 555 597
ptyMapGet 0 555 597
assign 1 555 598
heldGet 0 555 598
assign 1 555 599
nameGet 0 555 599
assign 1 555 600
get 1 555 600
assign 1 555 601
memSynGet 0 555 601
assign 1 558 603
assign 1 559 604
heldGet 0 559 604
assign 1 559 605
newNpGet 0 559 605
assign 1 559 606
def 1 559 611
assign 1 560 612
heldGet 0 560 612
assign 1 560 613
newNpGet 0 560 613
assign 1 560 614
getSynNp 1 560 614
assign 1 561 617
isTypedGet 0 561 617
assign 1 563 619
namepathGet 0 563 619
assign 1 563 620
getSynNp 1 563 620
assign 1 565 623
def 1 565 628
assign 1 566 629
mtdMapGet 0 566 629
assign 1 566 630
heldGet 0 566 630
assign 1 566 631
nameGet 0 566 631
assign 1 566 632
get 1 566 632
assign 1 567 633
undef 1 567 638
assign 1 568 639
mtdMapGet 0 568 639
assign 1 568 640
new 0 568 640
assign 1 568 641
get 1 568 641
assign 1 569 642
def 1 569 647
assign 1 569 648
originGet 0 569 648
assign 1 569 649
toString 0 569 649
assign 1 569 650
new 0 569 650
assign 1 569 651
notEquals 1 569 651
assign 1 0 653
assign 1 0 656
assign 1 0 660
assign 1 570 663
heldGet 0 570 663
assign 1 570 664
new 0 570 664
isForwardSet 1 570 665
assign 1 572 668
new 0 572 668
assign 1 572 669
heldGet 0 572 669
assign 1 572 670
nameGet 0 572 670
assign 1 572 671
add 1 572 671
assign 1 572 672
new 0 572 672
assign 1 572 673
add 1 572 673
assign 1 572 674
namepathGet 0 572 674
assign 1 572 675
add 1 572 675
assign 1 572 676
new 2 572 676
throw 1 572 677
assign 1 575 681
rsynGet 0 575 681
assign 1 579 686
def 1 579 691
assign 1 579 692
isTypedGet 0 579 692
assign 1 0 694
assign 1 0 697
assign 1 0 701
assign 1 581 704
new 0 581 704
assign 1 582 705
isSelfGet 0 582 705
assign 1 584 707
undef 1 584 712
assign 1 585 713
new 0 585 713
assign 1 585 714
new 1 585 714
throw 1 585 715
assign 1 590 717
originGet 0 590 717
assign 1 590 718
namepathGet 0 590 718
assign 1 590 719
notEquals 1 590 719
assign 1 592 721
new 0 592 721
assign 1 593 724
emitCommonGet 0 593 724
assign 1 593 725
def 1 593 730
assign 1 593 731
emitCommonGet 0 593 731
assign 1 593 732
covariantReturnsGet 0 593 732
assign 1 593 733
not 0 593 733
assign 1 0 735
assign 1 0 738
assign 1 0 742
assign 1 594 745
new 0 594 745
assign 1 596 750
def 1 596 755
assign 1 597 756
getEmitReturnType 2 597 756
assign 1 597 757
getSynNp 1 597 757
assign 1 599 760
namepathGet 0 599 760
assign 1 599 761
getSynNp 1 599 761
assign 1 603 764
namepathGet 0 603 764
assign 1 603 765
castsTo 1 603 765
assign 1 605 767
heldGet 0 605 767
assign 1 605 768
new 0 605 768
checkTypesSet 1 605 769
assign 1 607 772
isSelfGet 0 607 772
assign 1 608 774
namepathGet 0 608 774
assign 1 610 777
namepathGet 0 610 777
assign 1 612 779
namepathGet 0 612 779
assign 1 612 780
getSynNp 1 612 780
assign 1 613 781
castsTo 1 613 781
assign 1 615 783
heldGet 0 615 783
assign 1 615 784
new 0 615 784
checkTypesSet 1 615 785
assign 1 617 788
new 0 617 788
assign 1 617 789
namepathGet 0 617 789
assign 1 617 790
toString 0 617 790
assign 1 617 791
add 1 617 791
assign 1 617 792
new 0 617 792
assign 1 617 793
add 1 617 793
assign 1 617 794
toString 0 617 794
assign 1 617 795
add 1 617 795
assign 1 617 796
new 2 617 796
throw 1 617 797
assign 1 623 801
heldGet 0 623 801
assign 1 623 802
new 0 623 802
checkTypesSet 1 623 803
assign 1 624 804
heldGet 0 624 804
assign 1 624 805
new 0 624 805
checkTypesTypeSet 1 624 806
assign 1 627 809
heldGet 0 627 809
assign 1 627 810
namepathGet 0 627 810
assign 1 627 811
def 1 627 816
assign 1 632 822
heldGet 0 632 822
assign 1 632 823
orgNameGet 0 632 823
assign 1 632 824
new 0 632 824
assign 1 632 825
equals 1 632 825
assign 1 633 827
secondGet 0 633 827
assign 1 634 828
typenameGet 0 634 828
assign 1 634 829
VARGet 0 634 829
assign 1 634 830
equals 1 634 835
assign 1 635 836
heldGet 0 635 836
assign 1 635 837
isDeclaredGet 0 635 837
assign 1 636 839
heldGet 0 636 839
assign 1 638 842
ptyMapGet 0 638 842
assign 1 638 843
heldGet 0 638 843
assign 1 638 844
nameGet 0 638 844
assign 1 638 845
get 1 638 845
assign 1 638 846
memSynGet 0 638 846
assign 1 641 848
scopeGet 0 641 848
assign 1 642 849
heldGet 0 642 849
assign 1 642 850
isDeclaredGet 0 642 850
assign 1 643 852
heldGet 0 643 852
assign 1 645 855
ptyMapGet 0 645 855
assign 1 645 856
heldGet 0 645 856
assign 1 645 857
nameGet 0 645 857
assign 1 645 858
get 1 645 858
assign 1 645 859
memSynGet 0 645 859
assign 1 648 861
heldGet 0 648 861
assign 1 648 862
rtypeGet 0 648 862
assign 1 648 863
def 1 648 868
assign 1 648 869
heldGet 0 648 869
assign 1 648 870
rtypeGet 0 648 870
assign 1 648 871
isTypedGet 0 648 871
assign 1 0 873
assign 1 0 876
assign 1 0 880
assign 1 649 883
isTypedGet 0 649 883
assign 1 649 884
not 0 649 884
assign 1 650 886
heldGet 0 650 886
assign 1 650 887
rtypeGet 0 650 887
assign 1 650 888
isThisGet 0 650 888
assign 1 651 890
new 0 651 890
assign 1 651 891
new 2 651 891
throw 1 651 892
assign 1 654 894
heldGet 0 654 894
assign 1 654 895
new 0 654 895
checkTypesSet 1 654 896
assign 1 658 899
heldGet 0 658 899
assign 1 658 900
rtypeGet 0 658 900
assign 1 658 901
isSelfGet 0 658 901
assign 1 659 903
nameGet 0 659 903
assign 1 659 904
new 0 659 904
assign 1 659 905
equals 1 659 905
assign 1 661 907
heldGet 0 661 907
assign 1 661 908
new 0 661 908
checkTypesSet 1 661 909
assign 1 663 912
heldGet 0 663 912
assign 1 663 913
rtypeGet 0 663 913
assign 1 663 914
isThisGet 0 663 914
assign 1 664 916
new 0 664 916
assign 1 664 917
new 2 664 917
throw 1 664 918
assign 1 666 920
namepathGet 0 666 920
assign 1 666 921
getSynNp 1 666 921
assign 1 667 922
namepathGet 0 667 922
assign 1 667 923
castsTo 1 667 923
assign 1 0 925
assign 1 667 928
namepathGet 0 667 928
assign 1 667 929
castsTo 1 667 929
assign 1 0 931
assign 1 0 934
assign 1 669 938
heldGet 0 669 938
assign 1 669 939
new 0 669 939
checkTypesSet 1 669 940
assign 1 671 943
new 0 671 943
assign 1 671 944
namepathGet 0 671 944
assign 1 671 945
add 1 671 945
assign 1 671 946
new 0 671 946
assign 1 671 947
add 1 671 947
assign 1 671 948
namepathGet 0 671 948
assign 1 671 949
add 1 671 949
assign 1 671 950
new 2 671 950
throw 1 671 951
assign 1 675 956
namepathGet 0 675 956
assign 1 675 957
getSynNp 1 675 957
assign 1 676 958
heldGet 0 676 958
assign 1 676 959
rtypeGet 0 676 959
assign 1 676 960
namepathGet 0 676 960
assign 1 676 961
castsTo 1 676 961
assign 1 678 963
heldGet 0 678 963
assign 1 678 964
new 0 678 964
checkTypesSet 1 678 965
assign 1 680 968
heldGet 0 680 968
assign 1 680 969
rtypeGet 0 680 969
assign 1 680 970
namepathGet 0 680 970
assign 1 680 971
getSynNp 1 680 971
assign 1 681 972
namepathGet 0 681 972
assign 1 681 973
castsTo 1 681 973
assign 1 683 975
heldGet 0 683 975
assign 1 683 976
new 0 683 976
checkTypesSet 1 683 977
assign 1 685 980
new 0 685 980
assign 1 685 981
new 2 685 981
throw 1 685 982
assign 1 692 989
heldGet 0 692 989
assign 1 692 990
new 0 692 990
checkTypesSet 1 692 991
assign 1 695 995
heldGet 0 695 995
assign 1 695 996
new 0 695 996
checkTypesSet 1 695 997
assign 1 698 1001
containedGet 0 698 1001
assign 1 698 1002
firstGet 0 698 1002
assign 1 700 1003
heldGet 0 700 1003
assign 1 700 1004
isDeclaredGet 0 700 1004
assign 1 701 1006
heldGet 0 701 1006
assign 1 703 1009
ptyMapGet 0 703 1009
assign 1 703 1010
heldGet 0 703 1010
assign 1 703 1011
nameGet 0 703 1011
assign 1 703 1012
get 1 703 1012
assign 1 703 1013
memSynGet 0 703 1013
assign 1 706 1015
isTypedGet 0 706 1015
assign 1 706 1016
not 0 706 1016
assign 1 0 1018
assign 1 706 1021
heldGet 0 706 1021
assign 1 706 1022
orgNameGet 0 706 1022
assign 1 706 1023
new 0 706 1023
assign 1 706 1024
equals 1 706 1024
assign 1 0 1026
assign 1 0 1029
assign 1 707 1033
heldGet 0 707 1033
assign 1 707 1034
new 0 707 1034
checkTypesSet 1 707 1035
assign 1 709 1038
heldGet 0 709 1038
assign 1 709 1039
new 0 709 1039
checkTypesSet 1 709 1040
assign 1 710 1041
heldGet 0 710 1041
assign 1 710 1042
isConstructGet 0 710 1042
assign 1 711 1044
heldGet 0 711 1044
assign 1 711 1045
newNpGet 0 711 1045
assign 1 711 1046
undef 1 711 1051
assign 1 712 1052
new 0 712 1052
assign 1 712 1053
new 1 712 1053
throw 1 712 1054
assign 1 714 1056
heldGet 0 714 1056
assign 1 714 1057
newNpGet 0 714 1057
assign 1 714 1058
getSynNp 1 714 1058
assign 1 715 1059
mtdMapGet 0 715 1059
assign 1 715 1060
heldGet 0 715 1060
assign 1 715 1061
nameGet 0 715 1061
assign 1 715 1062
get 1 715 1062
assign 1 717 1065
namepathGet 0 717 1065
assign 1 717 1066
getSynNp 1 717 1066
assign 1 718 1067
mtdMapGet 0 718 1067
assign 1 718 1068
heldGet 0 718 1068
assign 1 718 1069
nameGet 0 718 1069
assign 1 718 1070
get 1 718 1070
assign 1 720 1072
undef 1 720 1077
assign 1 721 1078
mtdMapGet 0 721 1078
assign 1 721 1079
new 0 721 1079
assign 1 721 1080
get 1 721 1080
assign 1 722 1081
def 1 722 1086
assign 1 722 1087
originGet 0 722 1087
assign 1 722 1088
toString 0 722 1088
assign 1 722 1089
new 0 722 1089
assign 1 722 1090
notEquals 1 722 1090
assign 1 0 1092
assign 1 0 1095
assign 1 0 1099
assign 1 723 1102
heldGet 0 723 1102
assign 1 723 1103
new 0 723 1103
isForwardSet 1 723 1104
assign 1 725 1107
new 0 725 1107
assign 1 725 1108
heldGet 0 725 1108
assign 1 725 1109
nameGet 0 725 1109
assign 1 725 1110
add 1 725 1110
assign 1 725 1111
new 0 725 1111
assign 1 725 1112
add 1 725 1112
assign 1 725 1113
namepathGet 0 725 1113
assign 1 725 1114
toString 0 725 1114
assign 1 725 1115
add 1 725 1115
assign 1 725 1116
new 2 725 1116
throw 1 725 1117
assign 1 728 1120
def 1 728 1125
assign 1 729 1126
argSynsGet 0 729 1126
assign 1 730 1127
nextPeerGet 0 730 1127
assign 1 731 1128
new 0 731 1128
assign 1 731 1131
lengthGet 0 731 1131
assign 1 731 1132
lesser 1 731 1137
assign 1 732 1138
get 1 732 1138
assign 1 733 1139
isTypedGet 0 733 1139
assign 1 734 1141
undef 1 734 1146
assign 1 735 1147
new 0 735 1147
assign 1 735 1148
new 2 735 1148
throw 1 735 1149
assign 1 736 1152
typenameGet 0 736 1152
assign 1 736 1153
VARGet 0 736 1153
assign 1 736 1154
notEquals 1 736 1159
assign 1 736 1160
typenameGet 0 736 1160
assign 1 736 1161
NULLGet 0 736 1161
assign 1 736 1162
notEquals 1 736 1167
assign 1 0 1168
assign 1 0 1171
assign 1 0 1175
assign 1 737 1178
new 0 737 1178
assign 1 737 1179
typenameGet 0 737 1179
assign 1 737 1180
toString 0 737 1180
assign 1 737 1181
add 1 737 1181
assign 1 737 1182
new 2 737 1182
throw 1 737 1183
assign 1 739 1186
typenameGet 0 739 1186
assign 1 739 1187
VARGet 0 739 1187
assign 1 739 1188
equals 1 739 1193
assign 1 740 1194
heldGet 0 740 1194
assign 1 741 1195
isTypedGet 0 741 1195
assign 1 741 1196
not 0 741 1201
assign 1 742 1202
heldGet 0 742 1202
assign 1 742 1203
new 0 742 1203
checkTypesSet 1 742 1204
assign 1 743 1205
heldGet 0 743 1205
assign 1 743 1206
argCastsGet 0 743 1206
assign 1 743 1207
namepathGet 0 743 1207
put 2 743 1208
assign 1 746 1211
namepathGet 0 746 1211
assign 1 746 1212
getSynNp 1 746 1212
assign 1 747 1213
namepathGet 0 747 1213
assign 1 747 1214
castsTo 1 747 1214
assign 1 747 1215
not 0 747 1215
assign 1 748 1217
mtdMapGet 0 748 1217
assign 1 748 1218
new 0 748 1218
assign 1 748 1219
get 1 748 1219
assign 1 749 1220
def 1 749 1225
assign 1 749 1226
originGet 0 749 1226
assign 1 749 1227
toString 0 749 1227
assign 1 749 1228
new 0 749 1228
assign 1 749 1229
notEquals 1 749 1229
assign 1 0 1231
assign 1 0 1234
assign 1 0 1238
assign 1 750 1241
heldGet 0 750 1241
assign 1 750 1242
new 0 750 1242
isForwardSet 1 750 1243
assign 1 752 1246
new 0 752 1246
assign 1 752 1247
namepathGet 0 752 1247
assign 1 752 1248
toString 0 752 1248
assign 1 752 1249
add 1 752 1249
assign 1 752 1250
new 0 752 1250
assign 1 752 1251
add 1 752 1251
assign 1 752 1252
namepathGet 0 752 1252
assign 1 752 1253
toString 0 752 1253
assign 1 752 1254
add 1 752 1254
assign 1 752 1255
new 2 752 1255
throw 1 752 1256
assign 1 762 1262
nextPeerGet 0 762 1262
assign 1 731 1263
increment 0 731 1263
assign 1 768 1274
nextDescendGet 0 768 1274
return 1 768 1275
return 1 0 1278
return 1 0 1281
assign 1 0 1284
assign 1 0 1288
return 1 0 1292
return 1 0 1295
assign 1 0 1298
assign 1 0 1302
return 1 0 1306
return 1 0 1309
assign 1 0 1312
assign 1 0 1316
return 1 0 1320
return 1 0 1323
assign 1 0 1326
assign 1 0 1330
return 1 0 1334
return 1 0 1337
assign 1 0 1340
assign 1 0 1344
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1229803830: return bem_deserializeClassNameGet_0();
case 1384423002: return bem_transGet_0();
case -1533701006: return bem_serializeContents_0();
case -1884859936: return bem_inClassSynGetDirect_0();
case -2077773687: return bem_emitterGet_0();
case 1330976730: return bem_hashGet_0();
case -1760434406: return bem_transGetDirect_0();
case -1191535124: return bem_inClassNpGetDirect_0();
case -1217444056: return bem_constGet_0();
case -1593715630: return bem_ntypesGetDirect_0();
case 437089080: return bem_print_0();
case 2041897687: return bem_inClassNpGet_0();
case -160735352: return bem_once_0();
case -764449153: return bem_emitterGetDirect_0();
case 2066642517: return bem_buildGetDirect_0();
case 907276784: return bem_serializeToString_0();
case 862788409: return bem_buildGet_0();
case -1705055257: return bem_inClassGetDirect_0();
case -1990292643: return bem_toString_0();
case 1208354139: return bem_sourceFileNameGet_0();
case 1882778775: return bem_fieldIteratorGet_0();
case 1674575712: return bem_classNameGet_0();
case -1451048410: return bem_new_0();
case -1145906688: return bem_cposGet_0();
case 797867737: return bem_ntypesGet_0();
case 1738968438: return bem_inClassSynGet_0();
case -1091415372: return bem_cposGetDirect_0();
case -166013833: return bem_tagGet_0();
case 278030248: return bem_constGetDirect_0();
case -1419115955: return bem_create_0();
case 1865983825: return bem_fieldNamesGet_0();
case -206043242: return bem_many_0();
case 872708376: return bem_toAny_0();
case 1200056076: return bem_serializationIteratorGet_0();
case 2017345633: return bem_copy_0();
case 1391274656: return bem_inClassGet_0();
case 48684490: return bem_echo_0();
case -2014542803: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 625481528: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -691436434: return bem_begin_1(bevd_0);
case -1306142247: return bem_transSet_1(bevd_0);
case 494759431: return bem_inClassNpSet_1(bevd_0);
case 1561328648: return bem_otherType_1(bevd_0);
case -583950953: return bem_emitterSet_1(bevd_0);
case 1920998617: return bem_sameObject_1(bevd_0);
case 1596863802: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1484567824: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -332644770: return bem_end_1(bevd_0);
case -1517637963: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1948499177: return bem_inClassNpSetDirect_1(bevd_0);
case 272081757: return bem_inClassSet_1(bevd_0);
case 170216407: return bem_copyTo_1(bevd_0);
case -185383596: return bem_sameType_1(bevd_0);
case -1890809107: return bem_inClassSetDirect_1(bevd_0);
case 448678910: return bem_ntypesSet_1(bevd_0);
case 584123032: return bem_def_1(bevd_0);
case 354557818: return bem_equals_1(bevd_0);
case -1616094339: return bem_buildSet_1(bevd_0);
case -1255859492: return bem_emitterSetDirect_1(bevd_0);
case 2122176784: return bem_undef_1(bevd_0);
case -840953319: return bem_notEquals_1(bevd_0);
case -868055940: return bem_cposSetDirect_1(bevd_0);
case -340249021: return bem_inClassSynSetDirect_1(bevd_0);
case 161134859: return bem_defined_1(bevd_0);
case -1822027791: return bem_otherClass_1(bevd_0);
case -829553391: return bem_inClassSynSet_1(bevd_0);
case 2058785774: return bem_constSet_1(bevd_0);
case 1406812161: return bem_transSetDirect_1(bevd_0);
case 1951809293: return bem_ntypesSetDirect_1(bevd_0);
case -1353297109: return bem_buildSetDirect_1(bevd_0);
case 1153143612: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -279352105: return bem_undefined_1(bevd_0);
case 713581423: return bem_constSetDirect_1(bevd_0);
case -322237403: return bem_cposSet_1(bevd_0);
case 909810346: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1467883232: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 465709808: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 936076332: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -758649425: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 105253121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -29810702: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 175222937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_9_BuildVisitTypeCheck_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_9_BuildVisitTypeCheck_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_9_BuildVisitTypeCheck();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_9_BuildVisitTypeCheck.bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevs_inst = (BEC_3_5_5_9_BuildVisitTypeCheck) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_9_BuildVisitTypeCheck.bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_9_BuildVisitTypeCheck.bece_BEC_3_5_5_9_BuildVisitTypeCheck_bevs_type;
}
}
}
