namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public sealed class BEC_2_6_11_SystemEnvironment : BEC_2_6_6_SystemObject {
public BEC_2_6_11_SystemEnvironment() { }
static BEC_2_6_11_SystemEnvironment() { }
private static byte[] becc_BEC_2_6_11_SystemEnvironment_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x6E,0x76,0x69,0x72,0x6F,0x6E,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_6_11_SystemEnvironment_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_2_6_11_SystemEnvironment bece_BEC_2_6_11_SystemEnvironment_bevs_inst;

public static new BET_2_6_11_SystemEnvironment bece_BEC_2_6_11_SystemEnvironment_bevs_type;

public BEC_2_4_6_TextString bem_getVariable_1(BEC_2_4_6_TextString beva_name) {
BEC_2_4_6_TextString bevl_value = null;

            string value = Environment.GetEnvironmentVariable(beva_name.bems_toCsString());
            if (value != null) {
                bevl_value = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(value));
            }
        return bevl_value;
} /*method end*/
public BEC_2_4_6_TextString bem_getVar_1(BEC_2_4_6_TextString beva_name) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getVariable_1(beva_name);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {506, 510, 510};
public static new int[] bevs_smnlec
 = new int[] {27, 31, 32};
/* BEGIN LINEINFO 
return 1 506 27
assign 1 510 31
getVariable 1 510 31
return 1 510 32
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2084016052: return bem_serializeToString_0();
case 167399763: return bem_deserializeClassNameGet_0();
case -576816204: return bem_sourceFileNameGet_0();
case -630280728: return bem_copy_0();
case -830733381: return bem_echo_0();
case 1945803401: return bem_print_0();
case 1738591028: return bem_fieldNamesGet_0();
case -695733973: return bem_hashGet_0();
case -373483362: return bem_classNameGet_0();
case 1169011989: return bem_toString_0();
case 1606642997: return bem_new_0();
case 2086474367: return bem_create_0();
case -1847620794: return bem_iteratorGet_0();
case 1066489349: return bem_many_0();
case 1425790109: return bem_fieldIteratorGet_0();
case -408522205: return bem_serializeContents_0();
case 2034825137: return bem_tagGet_0();
case -1409233752: return bem_toAny_0();
case 1546544584: return bem_serializationIteratorGet_0();
case 1438915338: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1642039472: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2045883718: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 876386412: return bem_sameObject_1(bevd_0);
case -2073425080: return bem_sameType_1(bevd_0);
case -1371116116: return bem_otherClass_1(bevd_0);
case -85967812: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 575763691: return bem_undefined_1(bevd_0);
case 246840922: return bem_getVariable_1((BEC_2_4_6_TextString) bevd_0);
case 232552830: return bem_otherType_1(bevd_0);
case 1790575350: return bem_sameClass_1(bevd_0);
case -1663786357: return bem_equals_1(bevd_0);
case 1449183263: return bem_notEquals_1(bevd_0);
case -1854318841: return bem_copyTo_1(bevd_0);
case 542523031: return bem_defined_1(bevd_0);
case 491873122: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -463115686: return bem_def_1(bevd_0);
case 1806393077: return bem_getVar_1((BEC_2_4_6_TextString) bevd_0);
case -726390043: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1558133875: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -897682046: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 990151340: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600497328: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 116337276: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2028666619: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1471832670: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_6_11_SystemEnvironment_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_11_SystemEnvironment_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_11_SystemEnvironment();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_inst = (BEC_2_6_11_SystemEnvironment) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_type;
}
}
}
