namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_3_6_4_11_SystemTestInExtending : BEC_3_6_4_10_SystemTestExtendable {
public BEC_3_6_4_11_SystemTestInExtending() { }
static BEC_3_6_4_11_SystemTestInExtending() { }
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x65,0x73,0x74,0x3A,0x49,0x6E,0x45,0x78,0x74,0x65,0x6E,0x64,0x69,0x6E,0x67};
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_3_6_4_11_SystemTestInExtending bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;
public BEC_2_6_6_SystemObject bevp_prop2a;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_3_6_4_10_SystemTestExtendable bem_bcall_0() {
bevp_propa.bemd_0(1190997837);
return this;
} /*method end*/
public virtual BEC_3_6_4_11_SystemTestInExtending bem_ccall_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_prop2aGet_0() {
return bevp_prop2a;
} /*method end*/
public virtual BEC_3_6_4_11_SystemTestInExtending bem_prop2aSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prop2a = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {222, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 21, 24};
/* BEGIN LINEINFO 
print 0 222 14
return 1 0 21
assign 1 0 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 1704272071: return bem_copy_0();
case -1542575328: return bem_bcall_0();
case -606938285: return bem_propbGet_0();
case 285880845: return bem_prop2aGet_0();
case 16424274: return bem_iteratorGet_0();
case 1277077124: return bem_once_0();
case -1046873232: return bem_propaGet_0();
case -146459624: return bem_tagGet_0();
case 1818190775: return bem_toString_0();
case 371037351: return bem_hashGet_0();
case 1190997837: return bem_print_0();
case -1613660155: return bem_serializationIteratorGet_0();
case -1181834336: return bem_serializeToString_0();
case 308705107: return bem_serializeContents_0();
case 1133560869: return bem_new_0();
case -457378134: return bem_sourceFileNameGet_0();
case -2047366253: return bem_ccall_0();
case 1985246514: return bem_classNameGet_0();
case -1751704975: return bem_many_0();
case -67432972: return bem_fieldIteratorGet_0();
case 1567284243: return bem_create_0();
case -1538220610: return bem_echo_0();
case 642325680: return bem_deserializeClassNameGet_0();
case 610512650: return bem_acall_0();
case -563585217: return bem_toAny_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 1024493267: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1170591864: return bem_otherClass_1(bevd_0);
case 2077566448: return bem_sameClass_1(bevd_0);
case 579081683: return bem_defined_1(bevd_0);
case 1745637885: return bem_propbSet_1(bevd_0);
case -1067968167: return bem_propaSet_1(bevd_0);
case 1069670174: return bem_undef_1(bevd_0);
case 598716894: return bem_prop2aSet_1(bevd_0);
case -1210345122: return bem_notEquals_1(bevd_0);
case 1398941771: return bem_def_1(bevd_0);
case -1936197463: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2101700701: return bem_undefined_1(bevd_0);
case -503068138: return bem_sameType_1(bevd_0);
case 1933685650: return bem_equals_1(bevd_0);
case 1270721790: return bem_sameObject_1(bevd_0);
case -1508704559: return bem_copyTo_1(bevd_0);
case -1682170766: return bem_otherType_1(bevd_0);
case -240186291: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -122042490: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1408482482: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1097908484: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1722402091: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1055053136: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2112228411: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -483654719: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1372560242: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_6_4_11_SystemTestInExtending_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_3_6_4_11_SystemTestInExtending_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_4_11_SystemTestInExtending();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst = (BEC_3_6_4_11_SystemTestInExtending) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;
}
}
}
