namespace be {

 using System;
 using System.Security.Cryptography;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_6_SystemRandom : BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }
static BEC_2_6_6_SystemRandom() { }

   
   public RandomNumberGenerator srand = RNGCryptoServiceProvider.Create();
   
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;

public static new BET_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() {

      srand = RNGCryptoServiceProvider.Create();
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getInt_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) {

      byte[] rb = new byte[4];
      srand.GetBytes(rb);
      beva_value.bevi_int = BitConverter.ToInt32(rb, 0);
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_2_ta_ph = bem_getInt_1(bevt_3_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = bem_getInt_1(beva_value);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_ta_ph = bem_getString_2(bevt_1_ta_ph, beva_size);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
bevt_1_ta_ph = beva_str.bem_capacityGet_0();
if (bevt_1_ta_ph.bevi_int < beva_size.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 255*/ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 256*/
bevt_2_ta_ph = (BEC_2_4_3_MathInt) beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_ta_ph);
bevl_value = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 264*/ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 264*/ {
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(26));
bevt_6_ta_ph = bem_getIntMax_2(bevl_value, bevt_7_ta_ph);
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(65));
bevt_6_ta_ph.bevi_int += bevt_8_ta_ph.bevi_int;
bevt_5_ta_ph = bevt_6_ta_ph;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_5_ta_ph);
bevl_i.bevi_int++;
} /* Line: 264*/
 else /* Line: 264*/ {
break;
} /* Line: 264*/
} /* Line: 264*/
return beva_str;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {180, 208, 208, 208, 239, 243, 243, 243, 243, 243, 247, 247, 247, 247, 251, 251, 251, 255, 255, 255, 256, 258, 258, 263, 264, 264, 264, 266, 266, 266, 266, 266, 264, 268};
public static new int[] bevs_smnlec
 = new int[] {23, 34, 35, 36, 43, 50, 51, 52, 53, 54, 60, 61, 62, 63, 68, 69, 70, 84, 85, 90, 91, 93, 94, 95, 96, 99, 104, 105, 106, 107, 108, 110, 111, 117};
/* BEGIN LINEINFO 
seedNow 0 180 23
assign 1 208 34
new 0 208 34
assign 1 208 35
getInt 1 208 35
return 1 208 36
return 1 239 43
assign 1 243 50
new 0 243 50
assign 1 243 51
getInt 1 243 51
assign 1 243 52
absValue 0 243 52
assign 1 243 53
modulusValue 1 243 53
return 1 243 54
assign 1 247 60
getInt 1 247 60
assign 1 247 61
absValue 0 247 61
assign 1 247 62
modulusValue 1 247 62
return 1 247 63
assign 1 251 68
new 1 251 68
assign 1 251 69
getString 2 251 69
return 1 251 70
assign 1 255 84
capacityGet 0 255 84
assign 1 255 85
lesser 1 255 90
capacitySet 1 256 91
assign 1 258 93
copy 0 258 93
sizeSet 1 258 94
assign 1 263 95
new 0 263 95
assign 1 264 96
new 0 264 96
assign 1 264 99
lesser 1 264 104
assign 1 266 105
new 0 266 105
assign 1 266 106
getIntMax 2 266 106
assign 1 266 107
new 0 266 107
assign 1 266 108
addValue 1 266 108
setIntUnchecked 2 266 110
incrementValue 0 264 111
return 1 268 117
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -652053502: return bem_fieldNamesGet_0();
case 944073339: return bem_fieldIteratorGet_0();
case -1785724794: return bem_once_0();
case -832924578: return bem_seedNow_0();
case -1480556491: return bem_toAny_0();
case 168135582: return bem_create_0();
case 2132420479: return bem_many_0();
case -1359614197: return bem_classNameGet_0();
case -1044758745: return bem_serializeToString_0();
case 1779624788: return bem_default_0();
case 759496930: return bem_tagGet_0();
case 350691792: return bem_toString_0();
case 814334258: return bem_serializeContents_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -1642361296: return bem_print_0();
case -202912463: return bem_copy_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 1365897346: return bem_serializationIteratorGet_0();
case 1161638424: return bem_new_0();
case -71162589: return bem_iteratorGet_0();
case -1711670377: return bem_hashGet_0();
case 2064925791: return bem_echo_0();
case -1417372449: return bem_getInt_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -708977637: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case -951966168: return bem_def_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case 1761370853: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case 1386652109: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -262305665: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -346014998: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemRandom();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_type;
}
}
}
