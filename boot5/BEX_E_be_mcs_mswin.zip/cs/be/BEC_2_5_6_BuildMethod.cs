namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_6_BuildMethod : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMethod() { }
static BEC_2_5_6_BuildMethod() { }
private static byte[] becc_BEC_2_5_6_BuildMethod_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_5_6_BuildMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_0 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_0, 1));
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_1, 7));
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_2 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_2, 10));
public static new BEC_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_inst;

public static new BET_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_6_6_SystemObject bevp_property;
public BEC_2_6_6_SystemObject bevp_rtype;
public BEC_2_6_6_SystemObject bevp_tmpVars;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_4_3_MathInt bevp_tmpCnt;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_4_3_MathInt bevp_tryDepth;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_3_MathInt bevp_amax;
public BEC_2_4_3_MathInt bevp_hmax;
public BEC_2_4_3_MathInt bevp_mmax;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_anyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_tmpCnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_tryDepth = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_amax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_hmax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_mmax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
bevt_1_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_0;
bevl_ret = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
if (bevp_name == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_1;
bevt_3_tmpany_phold = bevl_ret.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
} /* Line: 184 */
if (bevp_numargs == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_2;
bevt_7_tmpany_phold = bevl_ret.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_numargs.bem_toString_0();
bevl_ret = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
} /* Line: 187 */
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGetDirect_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGetDirect_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGet_0() {
return bevp_property;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGetDirect_0() {
return bevp_property;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_propertySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_property = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_propertySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_property = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGet_0() {
return bevp_rtype;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGetDirect_0() {
return bevp_rtype;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_rtypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rtype = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_rtypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rtype = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGet_0() {
return bevp_tmpVars;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGetDirect_0() {
return bevp_tmpVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpVars = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpVars = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGetDirect_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_anyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGetDirect_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orderedVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGet_0() {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGetDirect_0() {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpCntSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpCntSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGetDirect_0() {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isGenAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGet_0() {
return bevp_tryDepth;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGetDirect_0() {
return bevp_tryDepth;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tryDepthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tryDepthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGet_0() {
return bevp_amax;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGetDirect_0() {
return bevp_amax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_amaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_amaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGet_0() {
return bevp_hmax;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGetDirect_0() {
return bevp_hmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_hmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_hmaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGet_0() {
return bevp_mmax;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGetDirect_0() {
return bevp_mmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_mmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_mmaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {167, 168, 169, 170, 171, 172, 174, 175, 176, 182, 182, 182, 183, 183, 184, 184, 184, 184, 186, 186, 187, 187, 187, 187, 189, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {34, 35, 36, 37, 38, 39, 40, 41, 42, 57, 58, 59, 60, 65, 66, 67, 68, 69, 71, 76, 77, 78, 79, 80, 82, 85, 88, 91, 95, 99, 102, 105, 109, 113, 116, 119, 123, 127, 130, 133, 137, 141, 144, 147, 151, 155, 158, 161, 165, 169, 172, 175, 179, 183, 186, 189, 193, 197, 200, 203, 207, 211, 214, 217, 221, 225, 228, 231, 235, 239, 242, 245, 249, 253, 256, 259, 263, 267, 270, 273, 277, 281, 284, 287, 291};
/* BEGIN LINEINFO 
assign 1 167 34
new 0 167 34
assign 1 168 35
new 0 168 35
assign 1 169 36
new 0 169 36
assign 1 170 37
new 0 170 37
assign 1 171 38
new 0 171 38
assign 1 172 39
new 0 172 39
assign 1 174 40
new 0 174 40
assign 1 175 41
new 0 175 41
assign 1 176 42
new 0 176 42
assign 1 182 57
classNameGet 0 182 57
assign 1 182 58
new 0 182 58
assign 1 182 59
add 1 182 59
assign 1 183 60
def 1 183 65
assign 1 184 66
new 0 184 66
assign 1 184 67
add 1 184 67
assign 1 184 68
toString 0 184 68
assign 1 184 69
add 1 184 69
assign 1 186 71
def 1 186 76
assign 1 187 77
new 0 187 77
assign 1 187 78
add 1 187 78
assign 1 187 79
toString 0 187 79
assign 1 187 80
add 1 187 80
return 1 189 82
return 1 0 85
return 1 0 88
assign 1 0 91
assign 1 0 95
return 1 0 99
return 1 0 102
assign 1 0 105
assign 1 0 109
return 1 0 113
return 1 0 116
assign 1 0 119
assign 1 0 123
return 1 0 127
return 1 0 130
assign 1 0 133
assign 1 0 137
return 1 0 141
return 1 0 144
assign 1 0 147
assign 1 0 151
return 1 0 155
return 1 0 158
assign 1 0 161
assign 1 0 165
return 1 0 169
return 1 0 172
assign 1 0 175
assign 1 0 179
return 1 0 183
return 1 0 186
assign 1 0 189
assign 1 0 193
return 1 0 197
return 1 0 200
assign 1 0 203
assign 1 0 207
return 1 0 211
return 1 0 214
assign 1 0 217
assign 1 0 221
return 1 0 225
return 1 0 228
assign 1 0 231
assign 1 0 235
return 1 0 239
return 1 0 242
assign 1 0 245
assign 1 0 249
return 1 0 253
return 1 0 256
assign 1 0 259
assign 1 0 263
return 1 0 267
return 1 0 270
assign 1 0 273
assign 1 0 277
return 1 0 281
return 1 0 284
assign 1 0 287
assign 1 0 291
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 941172865: return bem_serializeContents_0();
case -443951235: return bem_numargsGetDirect_0();
case -2132128542: return bem_isGenAccessorGetDirect_0();
case -1431960617: return bem_many_0();
case 1947173801: return bem_print_0();
case 1156921009: return bem_toString_0();
case -654415539: return bem_tagGet_0();
case -378610619: return bem_hmaxGet_0();
case 1434327615: return bem_tmpVarsGet_0();
case -1051263431: return bem_create_0();
case -1747498826: return bem_classNameGet_0();
case -1332510795: return bem_mmaxGetDirect_0();
case 1969869774: return bem_echo_0();
case 1129933523: return bem_hmaxGetDirect_0();
case -1607738197: return bem_anyMapGetDirect_0();
case 317975131: return bem_tryDepthGetDirect_0();
case -1769011681: return bem_tmpCntGet_0();
case 738954757: return bem_orderedVarsGet_0();
case 322540171: return bem_toAny_0();
case -539277844: return bem_fieldIteratorGet_0();
case -665640349: return bem_tmpCntGetDirect_0();
case 1589084317: return bem_propertyGet_0();
case 1525225506: return bem_nameGet_0();
case -1967487908: return bem_anyMapGet_0();
case -457739686: return bem_isGenAccessorGet_0();
case -390616112: return bem_isFinalGet_0();
case -1200671024: return bem_mmaxGet_0();
case 464610233: return bem_once_0();
case -1307080906: return bem_orgNameGet_0();
case -1581666253: return bem_new_0();
case 1454318418: return bem_propertyGetDirect_0();
case -861239656: return bem_nameGetDirect_0();
case -1959038833: return bem_orgNameGetDirect_0();
case 1512772474: return bem_copy_0();
case 1996956156: return bem_isFinalGetDirect_0();
case 1375519361: return bem_sourceFileNameGet_0();
case 1204667399: return bem_tryDepthGet_0();
case -182215192: return bem_serializationIteratorGet_0();
case 180956835: return bem_amaxGet_0();
case 1209094951: return bem_numargsGet_0();
case -323474992: return bem_rtypeGetDirect_0();
case 49134257: return bem_hashGet_0();
case -461205434: return bem_iteratorGet_0();
case -1513971012: return bem_tmpVarsGetDirect_0();
case 874503493: return bem_serializeToString_0();
case 1881939406: return bem_fieldNamesGet_0();
case -1729865830: return bem_rtypeGet_0();
case 1654599916: return bem_amaxGetDirect_0();
case -265651182: return bem_orderedVarsGetDirect_0();
case 1205179000: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1799732970: return bem_tmpVarsSetDirect_1(bevd_0);
case -1940703752: return bem_copyTo_1(bevd_0);
case -429095642: return bem_tryDepthSetDirect_1(bevd_0);
case 1729444335: return bem_propertySetDirect_1(bevd_0);
case -1180180246: return bem_numargsSet_1(bevd_0);
case 238798472: return bem_orderedVarsSetDirect_1(bevd_0);
case 372746140: return bem_sameType_1(bevd_0);
case -373658986: return bem_equals_1(bevd_0);
case -1264044693: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1405212164: return bem_sameClass_1(bevd_0);
case -498298486: return bem_sameObject_1(bevd_0);
case -792375602: return bem_mmaxSetDirect_1(bevd_0);
case -622473078: return bem_anyMapSet_1(bevd_0);
case -1883559164: return bem_tmpCntSetDirect_1(bevd_0);
case 243162876: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2003092091: return bem_tryDepthSet_1(bevd_0);
case -810520761: return bem_tmpCntSet_1(bevd_0);
case 866092917: return bem_orgNameSet_1(bevd_0);
case 1216348897: return bem_amaxSetDirect_1(bevd_0);
case 2028081803: return bem_tmpVarsSet_1(bevd_0);
case -1932503657: return bem_mmaxSet_1(bevd_0);
case 1903764650: return bem_orderedVarsSet_1(bevd_0);
case -801738352: return bem_amaxSet_1(bevd_0);
case -1499911921: return bem_notEquals_1(bevd_0);
case -361423979: return bem_isGenAccessorSet_1(bevd_0);
case -1367029601: return bem_anyMapSetDirect_1(bevd_0);
case 1966156517: return bem_otherClass_1(bevd_0);
case 778331504: return bem_def_1(bevd_0);
case -1295446558: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1510268900: return bem_orgNameSetDirect_1(bevd_0);
case 1422265667: return bem_propertySet_1(bevd_0);
case -1616704023: return bem_nameSet_1(bevd_0);
case 1901435048: return bem_rtypeSet_1(bevd_0);
case 1779380050: return bem_undefined_1(bevd_0);
case -290717480: return bem_numargsSetDirect_1(bevd_0);
case 447923928: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -879111487: return bem_hmaxSetDirect_1(bevd_0);
case 1089354598: return bem_undef_1(bevd_0);
case -1618770752: return bem_rtypeSetDirect_1(bevd_0);
case 1817351105: return bem_defined_1(bevd_0);
case 216252579: return bem_nameSetDirect_1(bevd_0);
case -1610413379: return bem_hmaxSet_1(bevd_0);
case -909480361: return bem_isFinalSet_1(bevd_0);
case 1120133866: return bem_isGenAccessorSetDirect_1(bevd_0);
case 1867273998: return bem_isFinalSetDirect_1(bevd_0);
case -653588721: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 414389553: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1714613573: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -292360250: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1129259785: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 614290015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 888716978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 193506539: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMethod_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_6_BuildMethod_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildMethod();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst = (BEC_2_5_6_BuildMethod) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_type;
}
}
}
