namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_6_BuildMethod : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMethod() { }
static BEC_2_5_6_BuildMethod() { }
private static byte[] becc_BEC_2_5_6_BuildMethod_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_5_6_BuildMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_0 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_0, 1));
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_1, 7));
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_2 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_2, 10));
public static new BEC_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_inst;

public static new BET_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_6_6_SystemObject bevp_property;
public BEC_2_6_6_SystemObject bevp_rtype;
public BEC_2_6_6_SystemObject bevp_tmpVars;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_4_3_MathInt bevp_tmpCnt;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_4_3_MathInt bevp_tryDepth;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_3_MathInt bevp_amax;
public BEC_2_4_3_MathInt bevp_hmax;
public BEC_2_4_3_MathInt bevp_mmax;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_anyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_tmpCnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_tryDepth = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_amax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_hmax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_mmax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
bevt_1_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_0;
bevl_ret = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
if (bevp_name == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_1;
bevt_3_tmpany_phold = bevl_ret.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
} /* Line: 184 */
if (bevp_numargs == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_2;
bevt_7_tmpany_phold = bevl_ret.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_numargs.bem_toString_0();
bevl_ret = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
} /* Line: 187 */
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGetDirect_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGetDirect_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGet_0() {
return bevp_property;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGetDirect_0() {
return bevp_property;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_propertySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_property = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_propertySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_property = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGet_0() {
return bevp_rtype;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGetDirect_0() {
return bevp_rtype;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_rtypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rtype = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_rtypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rtype = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGet_0() {
return bevp_tmpVars;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGetDirect_0() {
return bevp_tmpVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpVars = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpVars = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGetDirect_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_anyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGetDirect_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orderedVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGet_0() {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGetDirect_0() {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpCntSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpCntSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGetDirect_0() {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isGenAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGet_0() {
return bevp_tryDepth;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGetDirect_0() {
return bevp_tryDepth;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tryDepthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tryDepthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGet_0() {
return bevp_amax;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGetDirect_0() {
return bevp_amax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_amaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_amaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGet_0() {
return bevp_hmax;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGetDirect_0() {
return bevp_hmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_hmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_hmaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGet_0() {
return bevp_mmax;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGetDirect_0() {
return bevp_mmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_mmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_mmaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {167, 168, 169, 170, 171, 172, 174, 175, 176, 182, 182, 182, 183, 183, 184, 184, 184, 184, 186, 186, 187, 187, 187, 187, 189, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {34, 35, 36, 37, 38, 39, 40, 41, 42, 57, 58, 59, 60, 65, 66, 67, 68, 69, 71, 76, 77, 78, 79, 80, 82, 85, 88, 91, 95, 99, 102, 105, 109, 113, 116, 119, 123, 127, 130, 133, 137, 141, 144, 147, 151, 155, 158, 161, 165, 169, 172, 175, 179, 183, 186, 189, 193, 197, 200, 203, 207, 211, 214, 217, 221, 225, 228, 231, 235, 239, 242, 245, 249, 253, 256, 259, 263, 267, 270, 273, 277, 281, 284, 287, 291};
/* BEGIN LINEINFO 
assign 1 167 34
new 0 167 34
assign 1 168 35
new 0 168 35
assign 1 169 36
new 0 169 36
assign 1 170 37
new 0 170 37
assign 1 171 38
new 0 171 38
assign 1 172 39
new 0 172 39
assign 1 174 40
new 0 174 40
assign 1 175 41
new 0 175 41
assign 1 176 42
new 0 176 42
assign 1 182 57
classNameGet 0 182 57
assign 1 182 58
new 0 182 58
assign 1 182 59
add 1 182 59
assign 1 183 60
def 1 183 65
assign 1 184 66
new 0 184 66
assign 1 184 67
add 1 184 67
assign 1 184 68
toString 0 184 68
assign 1 184 69
add 1 184 69
assign 1 186 71
def 1 186 76
assign 1 187 77
new 0 187 77
assign 1 187 78
add 1 187 78
assign 1 187 79
toString 0 187 79
assign 1 187 80
add 1 187 80
return 1 189 82
return 1 0 85
return 1 0 88
assign 1 0 91
assign 1 0 95
return 1 0 99
return 1 0 102
assign 1 0 105
assign 1 0 109
return 1 0 113
return 1 0 116
assign 1 0 119
assign 1 0 123
return 1 0 127
return 1 0 130
assign 1 0 133
assign 1 0 137
return 1 0 141
return 1 0 144
assign 1 0 147
assign 1 0 151
return 1 0 155
return 1 0 158
assign 1 0 161
assign 1 0 165
return 1 0 169
return 1 0 172
assign 1 0 175
assign 1 0 179
return 1 0 183
return 1 0 186
assign 1 0 189
assign 1 0 193
return 1 0 197
return 1 0 200
assign 1 0 203
assign 1 0 207
return 1 0 211
return 1 0 214
assign 1 0 217
assign 1 0 221
return 1 0 225
return 1 0 228
assign 1 0 231
assign 1 0 235
return 1 0 239
return 1 0 242
assign 1 0 245
assign 1 0 249
return 1 0 253
return 1 0 256
assign 1 0 259
assign 1 0 263
return 1 0 267
return 1 0 270
assign 1 0 273
assign 1 0 277
return 1 0 281
return 1 0 284
assign 1 0 287
assign 1 0 291
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -604720922: return bem_tmpVarsGetDirect_0();
case 1985057509: return bem_fieldIteratorGet_0();
case -209793605: return bem_tryDepthGet_0();
case -1307912568: return bem_classNameGet_0();
case -1281864300: return bem_mmaxGet_0();
case 681415323: return bem_hashGet_0();
case -936713313: return bem_isGenAccessorGetDirect_0();
case -1541048309: return bem_create_0();
case -1005843071: return bem_serializeContents_0();
case -1192359710: return bem_toAny_0();
case 1825908506: return bem_nameGet_0();
case 201818212: return bem_tagGet_0();
case 1562408751: return bem_once_0();
case -549865366: return bem_amaxGetDirect_0();
case -1128253997: return bem_print_0();
case -1643301227: return bem_anyMapGetDirect_0();
case 2056293875: return bem_isFinalGetDirect_0();
case -160406851: return bem_new_0();
case 1295409335: return bem_isGenAccessorGet_0();
case 995222378: return bem_rtypeGet_0();
case 526864174: return bem_hmaxGetDirect_0();
case 272950674: return bem_deserializeClassNameGet_0();
case -2145700984: return bem_tmpVarsGet_0();
case -969027984: return bem_numargsGetDirect_0();
case 450989839: return bem_toString_0();
case -834294683: return bem_isFinalGet_0();
case -100881992: return bem_mmaxGetDirect_0();
case -221885898: return bem_orgNameGetDirect_0();
case -1989311424: return bem_iteratorGet_0();
case 1558802914: return bem_rtypeGetDirect_0();
case 2077438310: return bem_fieldNamesGet_0();
case -99775224: return bem_tryDepthGetDirect_0();
case 64036809: return bem_serializeToString_0();
case 562943144: return bem_anyMapGet_0();
case -1335607781: return bem_sourceFileNameGet_0();
case 1334629789: return bem_propertyGetDirect_0();
case 572044789: return bem_numargsGet_0();
case -1092094687: return bem_orgNameGet_0();
case -259094594: return bem_echo_0();
case -1950183215: return bem_orderedVarsGet_0();
case 1875317286: return bem_many_0();
case -915147350: return bem_tmpCntGetDirect_0();
case 137938641: return bem_copy_0();
case -1878590297: return bem_amaxGet_0();
case 1519406937: return bem_orderedVarsGetDirect_0();
case 508814854: return bem_propertyGet_0();
case 1900587485: return bem_nameGetDirect_0();
case -144129925: return bem_serializationIteratorGet_0();
case -549477754: return bem_tmpCntGet_0();
case 123088319: return bem_hmaxGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 836420513: return bem_orderedVarsSetDirect_1(bevd_0);
case -1788163537: return bem_propertySet_1(bevd_0);
case -1331926592: return bem_tmpVarsSet_1(bevd_0);
case 2087737174: return bem_orderedVarsSet_1(bevd_0);
case 388088466: return bem_hmaxSetDirect_1(bevd_0);
case -485494216: return bem_isFinalSet_1(bevd_0);
case -1139812471: return bem_defined_1(bevd_0);
case -1534600735: return bem_rtypeSet_1(bevd_0);
case 87713512: return bem_otherType_1(bevd_0);
case 304586649: return bem_amaxSetDirect_1(bevd_0);
case -106030567: return bem_nameSet_1(bevd_0);
case -1459957609: return bem_isFinalSetDirect_1(bevd_0);
case 1917243902: return bem_sameObject_1(bevd_0);
case 1645054849: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1335724683: return bem_anyMapSetDirect_1(bevd_0);
case -973472948: return bem_mmaxSet_1(bevd_0);
case 1151483997: return bem_undef_1(bevd_0);
case -1623632446: return bem_propertySetDirect_1(bevd_0);
case -1632802458: return bem_numargsSet_1(bevd_0);
case 294100036: return bem_def_1(bevd_0);
case -303479648: return bem_tryDepthSet_1(bevd_0);
case -548188016: return bem_hmaxSet_1(bevd_0);
case 1742674668: return bem_equals_1(bevd_0);
case 1113733988: return bem_copyTo_1(bevd_0);
case -1080193293: return bem_tmpCntSetDirect_1(bevd_0);
case 485544276: return bem_nameSetDirect_1(bevd_0);
case 1689954605: return bem_amaxSet_1(bevd_0);
case 1634136691: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1769267387: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1496797900: return bem_undefined_1(bevd_0);
case 1532776773: return bem_numargsSetDirect_1(bevd_0);
case -2045198723: return bem_sameType_1(bevd_0);
case -141254881: return bem_anyMapSet_1(bevd_0);
case -1943396073: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 840134160: return bem_orgNameSetDirect_1(bevd_0);
case -2079119279: return bem_orgNameSet_1(bevd_0);
case 1780588622: return bem_tryDepthSetDirect_1(bevd_0);
case -135579758: return bem_isGenAccessorSet_1(bevd_0);
case 523075897: return bem_tmpVarsSetDirect_1(bevd_0);
case 959879294: return bem_notEquals_1(bevd_0);
case 1349958545: return bem_sameClass_1(bevd_0);
case -1956777375: return bem_rtypeSetDirect_1(bevd_0);
case -1783528224: return bem_tmpCntSet_1(bevd_0);
case 371940317: return bem_otherClass_1(bevd_0);
case 1175054249: return bem_isGenAccessorSetDirect_1(bevd_0);
case -1610163293: return bem_mmaxSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -285325789: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1136827327: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 517362903: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -491501198: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -534690974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -496063349: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1244895026: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMethod_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_6_BuildMethod_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildMethod();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst = (BEC_2_5_6_BuildMethod) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_type;
}
}
}
