namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_6_BuildMethod : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMethod() { }
static BEC_2_5_6_BuildMethod() { }
private static byte[] becc_BEC_2_5_6_BuildMethod_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_5_6_BuildMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_0 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_0, 1));
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_1, 7));
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_2 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildMethod_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildMethod_bels_2, 10));
public static new BEC_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_inst;

public static new BET_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_6_6_SystemObject bevp_property;
public BEC_2_6_6_SystemObject bevp_rtype;
public BEC_2_6_6_SystemObject bevp_tmpVars;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_4_3_MathInt bevp_tmpCnt;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_4_3_MathInt bevp_tryDepth;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_3_MathInt bevp_amax;
public BEC_2_4_3_MathInt bevp_hmax;
public BEC_2_4_3_MathInt bevp_mmax;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_anyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_tmpCnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_tryDepth = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_amax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_hmax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_mmax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
bevt_1_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_0;
bevl_ret = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
if (bevp_name == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_1;
bevt_3_tmpany_phold = bevl_ret.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
} /* Line: 184 */
if (bevp_numargs == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_6_BuildMethod_bevo_2;
bevt_7_tmpany_phold = bevl_ret.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_numargs.bem_toString_0();
bevl_ret = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
} /* Line: 187 */
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGet_0() {
return bevp_property;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_propertySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_property = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGet_0() {
return bevp_rtype;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_rtypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rtype = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGet_0() {
return bevp_tmpVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpVars = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGet_0() {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpCntSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGet_0() {
return bevp_tryDepth;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tryDepthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGet_0() {
return bevp_amax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_amaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGet_0() {
return bevp_hmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_hmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGet_0() {
return bevp_mmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_mmaxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {167, 168, 169, 170, 171, 172, 174, 175, 176, 182, 182, 182, 183, 183, 184, 184, 184, 184, 186, 186, 187, 187, 187, 187, 189, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {34, 35, 36, 37, 38, 39, 40, 41, 42, 57, 58, 59, 60, 65, 66, 67, 68, 69, 71, 76, 77, 78, 79, 80, 82, 85, 88, 92, 95, 99, 102, 106, 109, 113, 116, 120, 123, 127, 130, 134, 137, 141, 144, 148, 151, 155, 158, 162, 165, 169, 172, 176, 179, 183, 186};
/* BEGIN LINEINFO 
assign 1 167 34
new 0 167 34
assign 1 168 35
new 0 168 35
assign 1 169 36
new 0 169 36
assign 1 170 37
new 0 170 37
assign 1 171 38
new 0 171 38
assign 1 172 39
new 0 172 39
assign 1 174 40
new 0 174 40
assign 1 175 41
new 0 175 41
assign 1 176 42
new 0 176 42
assign 1 182 57
classNameGet 0 182 57
assign 1 182 58
new 0 182 58
assign 1 182 59
add 1 182 59
assign 1 183 60
def 1 183 65
assign 1 184 66
new 0 184 66
assign 1 184 67
add 1 184 67
assign 1 184 68
toString 0 184 68
assign 1 184 69
add 1 184 69
assign 1 186 71
def 1 186 76
assign 1 187 77
new 0 187 77
assign 1 187 78
add 1 187 78
assign 1 187 79
toString 0 187 79
assign 1 187 80
add 1 187 80
return 1 189 82
return 1 0 85
assign 1 0 88
return 1 0 92
assign 1 0 95
return 1 0 99
assign 1 0 102
return 1 0 106
assign 1 0 109
return 1 0 113
assign 1 0 116
return 1 0 120
assign 1 0 123
return 1 0 127
assign 1 0 130
return 1 0 134
assign 1 0 137
return 1 0 141
assign 1 0 144
return 1 0 148
assign 1 0 151
return 1 0 155
assign 1 0 158
return 1 0 162
assign 1 0 165
return 1 0 169
assign 1 0 172
return 1 0 176
assign 1 0 179
return 1 0 183
assign 1 0 186
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 500641095: return bem_isGenAccessorGet_0();
case -1230030647: return bem_iteratorGet_0();
case -1380773853: return bem_print_0();
case -331801151: return bem_isFinalGet_0();
case -1453774479: return bem_nameGet_0();
case -853043713: return bem_rtypeGet_0();
case -1546212617: return bem_hashGet_0();
case -1812592029: return bem_copy_0();
case -1098179156: return bem_amaxGet_0();
case -1389643238: return bem_tmpVarsGet_0();
case -1236848882: return bem_anyMapGet_0();
case 1765847529: return bem_toAny_0();
case 111705563: return bem_new_0();
case 1814659174: return bem_echo_0();
case -140254392: return bem_classNameGet_0();
case 1138959219: return bem_create_0();
case 1015515599: return bem_mmaxGet_0();
case 1136611843: return bem_many_0();
case -1346342591: return bem_tagGet_0();
case -154821822: return bem_serializationIteratorGet_0();
case 1099929796: return bem_propertyGet_0();
case 1255291166: return bem_tmpCntGet_0();
case 2031852918: return bem_deserializeClassNameGet_0();
case -108571624: return bem_serializeContents_0();
case -110239012: return bem_sourceFileNameGet_0();
case -153621872: return bem_orgNameGet_0();
case -37436705: return bem_orderedVarsGet_0();
case -90627019: return bem_toString_0();
case 1843946637: return bem_fieldIteratorGet_0();
case -375963306: return bem_serializeToString_0();
case -1010909737: return bem_hmaxGet_0();
case 1826454756: return bem_once_0();
case 380403678: return bem_numargsGet_0();
case -1318470971: return bem_tryDepthGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 452045758: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 14493145: return bem_orderedVarsSet_1(bevd_0);
case -898454377: return bem_equals_1(bevd_0);
case -203680436: return bem_propertySet_1(bevd_0);
case -23076256: return bem_isFinalSet_1(bevd_0);
case -231386564: return bem_sameClass_1(bevd_0);
case 1955134607: return bem_otherClass_1(bevd_0);
case -1198247472: return bem_undef_1(bevd_0);
case -530346669: return bem_anyMapSet_1(bevd_0);
case -1157481258: return bem_sameObject_1(bevd_0);
case 748668477: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1745069966: return bem_def_1(bevd_0);
case 952333473: return bem_mmaxSet_1(bevd_0);
case -56936232: return bem_hmaxSet_1(bevd_0);
case 1340954430: return bem_undefined_1(bevd_0);
case -604934649: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1526501544: return bem_copyTo_1(bevd_0);
case -166605595: return bem_otherType_1(bevd_0);
case -2018573962: return bem_defined_1(bevd_0);
case 864325696: return bem_numargsSet_1(bevd_0);
case -1134487098: return bem_nameSet_1(bevd_0);
case 1845941849: return bem_amaxSet_1(bevd_0);
case 1939898316: return bem_tmpCntSet_1(bevd_0);
case -2050905939: return bem_notEquals_1(bevd_0);
case -1352048316: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1664132213: return bem_orgNameSet_1(bevd_0);
case 295907353: return bem_isGenAccessorSet_1(bevd_0);
case 2033783017: return bem_sameType_1(bevd_0);
case 1114100962: return bem_tryDepthSet_1(bevd_0);
case 1350773602: return bem_tmpVarsSet_1(bevd_0);
case 642058116: return bem_rtypeSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1477024989: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1086183440: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -13817058: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1749882081: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -826896459: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 416141599: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 647643475: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMethod_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_6_BuildMethod_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildMethod();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst = (BEC_2_5_6_BuildMethod) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_type;
}
}
}
