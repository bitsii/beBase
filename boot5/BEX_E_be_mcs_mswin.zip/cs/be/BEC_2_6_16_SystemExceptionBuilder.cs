namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_16_SystemExceptionBuilder : BEC_2_6_6_SystemObject {
public BEC_2_6_16_SystemExceptionBuilder() { }
static BEC_2_6_16_SystemExceptionBuilder() { }
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x42,0x75,0x69,0x6C,0x64,0x65,0x72};
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_0 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_0, 51));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_1 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_1, 25));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_2 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_2, 51));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_3 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_3, 25));
public static new BEC_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;

public static new BET_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;

public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_6_SystemObject bevp_thing;
public BEC_2_6_6_SystemObject bevp_int;
public BEC_2_6_6_SystemObject bevp_lastStr;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_default_0() {
bevp_except = (new BEC_2_6_9_SystemException());
bevp_thing = (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getLineForEmitLine_2(BEC_2_4_6_TextString beva_klass, BEC_2_4_3_MathInt beva_eline) {
BEC_2_4_3_MathInt bevl_line = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 397 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 397 */ {
if (beva_eline == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 397 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 397 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 397 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 397 */ {
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_3_tmpany_phold;
} /* Line: 399 */
bevl_line = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

       bevl_line.bevi_int = 
         be.BECS_Runtime.getNlcForNlec(beva_klass.bems_toCsString(),
           beva_eline.bevi_int);
     return bevl_line;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_printException_1(BEC_2_6_6_SystemObject beva_ex) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_ex == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 433 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 434 */
 else  /* Line: 435 */ {
try  /* Line: 436 */ {
beva_ex.bemd_0(1945803401);
} /* Line: 437 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 439 */
} /* Line: 438 */
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_sendToConsole_1(BEC_2_6_6_SystemObject beva_ex) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_lastStr = null;
if (beva_ex == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 446 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 447 */
 else  /* Line: 448 */ {
try  /* Line: 449 */ {
} /* Line: 449 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 452 */
} /* Line: 451 */
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_buildException_6(BEC_2_6_6_SystemObject beva_passBack, BEC_2_6_6_SystemObject beva_smsg, BEC_2_6_6_SystemObject beva_sinClass, BEC_2_6_6_SystemObject beva_sinMtd, BEC_2_6_6_SystemObject beva_sfname, BEC_2_6_6_SystemObject beva_ilinep) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_passBack == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 458 */ {
bevt_2_tmpany_phold = beva_passBack.bemd_1(-2073425080, bevp_except);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 458 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 458 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 458 */
 else  /* Line: 458 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 458 */ {
beva_passBack.bemd_1(439188161, beva_sinClass);
beva_passBack.bemd_1(1644129281, beva_sinMtd);
beva_passBack.bemd_1(-1032439615, beva_sfname);
beva_passBack.bemd_1(-1413029088, beva_ilinep);
} /* Line: 462 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() {
return bevp_except;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGetDirect_0() {
return bevp_except;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thingGet_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thingGetDirect_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_thing = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_thing = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGet_0() {
return bevp_int;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGetDirect_0() {
return bevp_int;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_int = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_int = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGet_0() {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGetDirect_0() {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {387, 388, 389, 397, 397, 0, 397, 397, 0, 0, 399, 399, 402, 428, 433, 433, 434, 434, 437, 439, 439, 445, 446, 446, 447, 447, 452, 452, 458, 458, 458, 0, 0, 0, 459, 460, 461, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {28, 29, 30, 39, 44, 45, 48, 53, 54, 57, 61, 62, 64, 69, 76, 81, 82, 83, 87, 91, 92, 102, 103, 108, 109, 110, 117, 118, 127, 132, 133, 135, 138, 142, 145, 146, 147, 148, 153, 156, 159, 163, 167, 170, 173, 177, 181, 184, 187, 191, 195, 198, 201, 205};
/* BEGIN LINEINFO 
assign 1 387 28
new 0 387 28
assign 1 388 29
new 0 388 29
assign 1 389 30
new 0 389 30
assign 1 397 39
undef 1 397 44
assign 1 0 45
assign 1 397 48
undef 1 397 53
assign 1 0 54
assign 1 0 57
assign 1 399 61
new 0 399 61
return 1 399 62
assign 1 402 64
new 0 402 64
return 1 428 69
assign 1 433 76
undef 1 433 81
assign 1 434 82
new 0 434 82
print 0 434 83
print 0 437 87
assign 1 439 91
new 0 439 91
print 0 439 92
assign 1 445 102
assign 1 446 103
undef 1 446 108
assign 1 447 109
new 0 447 109
print 0 447 110
assign 1 452 117
new 0 452 117
print 0 452 118
assign 1 458 127
def 1 458 132
assign 1 458 133
sameType 1 458 133
assign 1 0 135
assign 1 0 138
assign 1 0 142
klassNameSet 1 459 145
methodNameSet 1 460 146
fileNameSet 1 461 147
lineNumberSet 1 462 148
return 1 0 153
return 1 0 156
assign 1 0 159
assign 1 0 163
return 1 0 167
return 1 0 170
assign 1 0 173
assign 1 0 177
return 1 0 181
return 1 0 184
assign 1 0 187
assign 1 0 191
return 1 0 195
return 1 0 198
assign 1 0 201
assign 1 0 205
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1125504556: return bem_intGetDirect_0();
case 1546544584: return bem_serializationIteratorGet_0();
case -630280728: return bem_copy_0();
case -576816204: return bem_sourceFileNameGet_0();
case 660381569: return bem_thingGet_0();
case -1858107807: return bem_lastStrGet_0();
case 1438915338: return bem_once_0();
case -1409233752: return bem_toAny_0();
case -695733973: return bem_hashGet_0();
case -373483362: return bem_classNameGet_0();
case -1847620794: return bem_iteratorGet_0();
case 1945803401: return bem_print_0();
case 1122522737: return bem_lastStrGetDirect_0();
case -830733381: return bem_echo_0();
case 1606642997: return bem_new_0();
case 167399763: return bem_deserializeClassNameGet_0();
case 2086474367: return bem_create_0();
case 1169011989: return bem_toString_0();
case 1425790109: return bem_fieldIteratorGet_0();
case -408522205: return bem_serializeContents_0();
case 2035243612: return bem_intGet_0();
case 2034825137: return bem_tagGet_0();
case 1688672409: return bem_default_0();
case -2084016052: return bem_serializeToString_0();
case 264893089: return bem_exceptGetDirect_0();
case 1738591028: return bem_fieldNamesGet_0();
case 2004946455: return bem_exceptGet_0();
case 1066489349: return bem_many_0();
case 1546825318: return bem_thingGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1642039472: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2045883718: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 876386412: return bem_sameObject_1(bevd_0);
case -2073425080: return bem_sameType_1(bevd_0);
case -752304543: return bem_printException_1(bevd_0);
case -1371116116: return bem_otherClass_1(bevd_0);
case -85967812: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 216157237: return bem_lastStrSetDirect_1(bevd_0);
case -835716366: return bem_exceptSetDirect_1(bevd_0);
case 575763691: return bem_undefined_1(bevd_0);
case -1168159279: return bem_intSetDirect_1(bevd_0);
case 232552830: return bem_otherType_1(bevd_0);
case 1774531844: return bem_exceptSet_1(bevd_0);
case 1790575350: return bem_sameClass_1(bevd_0);
case 1394309165: return bem_intSet_1(bevd_0);
case -1663786357: return bem_equals_1(bevd_0);
case 1449183263: return bem_notEquals_1(bevd_0);
case -1308577089: return bem_thingSetDirect_1(bevd_0);
case -1854318841: return bem_copyTo_1(bevd_0);
case 542523031: return bem_defined_1(bevd_0);
case -855629732: return bem_sendToConsole_1(bevd_0);
case -1668775869: return bem_lastStrSet_1(bevd_0);
case 491873122: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2116391362: return bem_thingSet_1(bevd_0);
case -463115686: return bem_def_1(bevd_0);
case -726390043: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1558133875: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 327404083: return bem_getLineForEmitLine_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -897682046: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 990151340: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600497328: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 116337276: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2028666619: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1471832670: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_6(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5) {
switch (callId) {
case -1906644308: return bem_buildException_6(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
return base.bemd_6(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemExceptionBuilder_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemExceptionBuilder_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_16_SystemExceptionBuilder();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst = (BEC_2_6_16_SystemExceptionBuilder) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;
}
}
}
