namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_16_SystemExceptionBuilder : BEC_2_6_6_SystemObject {
public BEC_2_6_16_SystemExceptionBuilder() { }
static BEC_2_6_16_SystemExceptionBuilder() { }
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x42,0x75,0x69,0x6C,0x64,0x65,0x72};
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_0 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_0, 51));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_1 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_1, 25));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_2 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_2, 51));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_3 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_3, 25));
public static new BEC_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;

public static new BET_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;

public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_6_SystemObject bevp_thing;
public BEC_2_6_6_SystemObject bevp_int;
public BEC_2_6_6_SystemObject bevp_lastStr;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_default_0() {
bevp_except = (new BEC_2_6_9_SystemException());
bevp_thing = (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getLineForEmitLine_2(BEC_2_4_6_TextString beva_klass, BEC_2_4_3_MathInt beva_eline) {
BEC_2_4_3_MathInt bevl_line = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 396 */ {
if (beva_eline == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 396 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 396 */ {
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_3_tmpany_phold;
} /* Line: 398 */
bevl_line = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

       bevl_line.bevi_int = 
         be.BECS_Runtime.getNlcForNlec(beva_klass.bems_toCsString(),
           beva_eline.bevi_int);
     return bevl_line;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_printException_1(BEC_2_6_6_SystemObject beva_ex) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_ex == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 432 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 433 */
 else  /* Line: 434 */ {
try  /* Line: 435 */ {
beva_ex.bemd_0(-888502976);
} /* Line: 436 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 438 */
} /* Line: 437 */
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_sendToConsole_1(BEC_2_6_6_SystemObject beva_ex) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_lastStr = null;
if (beva_ex == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 445 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 446 */
 else  /* Line: 447 */ {
try  /* Line: 448 */ {
} /* Line: 448 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 451 */
} /* Line: 450 */
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_buildException_6(BEC_2_6_6_SystemObject beva_passBack, BEC_2_6_6_SystemObject beva_smsg, BEC_2_6_6_SystemObject beva_sinClass, BEC_2_6_6_SystemObject beva_sinMtd, BEC_2_6_6_SystemObject beva_sfname, BEC_2_6_6_SystemObject beva_ilinep) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_passBack == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_2_tmpany_phold = beva_passBack.bemd_1(-1811224480, bevp_except);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 457 */
 else  /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 457 */ {
beva_passBack.bemd_1(223792752, beva_sinClass);
beva_passBack.bemd_1(1337089292, beva_sinMtd);
beva_passBack.bemd_1(-456462670, beva_sfname);
beva_passBack.bemd_1(-1109705603, beva_ilinep);
} /* Line: 461 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() {
return bevp_except;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGetDirect_0() {
return bevp_except;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thingGet_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thingGetDirect_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_thing = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_thing = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGet_0() {
return bevp_int;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGetDirect_0() {
return bevp_int;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_int = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_int = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGet_0() {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGetDirect_0() {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {386, 387, 388, 396, 396, 0, 396, 396, 0, 0, 398, 398, 401, 427, 432, 432, 433, 433, 436, 438, 438, 444, 445, 445, 446, 446, 451, 451, 457, 457, 457, 0, 0, 0, 458, 459, 460, 461, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {28, 29, 30, 39, 44, 45, 48, 53, 54, 57, 61, 62, 64, 69, 76, 81, 82, 83, 87, 91, 92, 102, 103, 108, 109, 110, 117, 118, 127, 132, 133, 135, 138, 142, 145, 146, 147, 148, 153, 156, 159, 163, 167, 170, 173, 177, 181, 184, 187, 191, 195, 198, 201, 205};
/* BEGIN LINEINFO 
assign 1 386 28
new 0 386 28
assign 1 387 29
new 0 387 29
assign 1 388 30
new 0 388 30
assign 1 396 39
undef 1 396 44
assign 1 0 45
assign 1 396 48
undef 1 396 53
assign 1 0 54
assign 1 0 57
assign 1 398 61
new 0 398 61
return 1 398 62
assign 1 401 64
new 0 401 64
return 1 427 69
assign 1 432 76
undef 1 432 81
assign 1 433 82
new 0 433 82
print 0 433 83
print 0 436 87
assign 1 438 91
new 0 438 91
print 0 438 92
assign 1 444 102
assign 1 445 103
undef 1 445 108
assign 1 446 109
new 0 446 109
print 0 446 110
assign 1 451 117
new 0 451 117
print 0 451 118
assign 1 457 127
def 1 457 132
assign 1 457 133
sameType 1 457 133
assign 1 0 135
assign 1 0 138
assign 1 0 142
klassNameSet 1 458 145
methodNameSet 1 459 146
fileNameSet 1 460 147
lineNumberSet 1 461 148
return 1 0 153
return 1 0 156
assign 1 0 159
assign 1 0 163
return 1 0 167
return 1 0 170
assign 1 0 173
assign 1 0 177
return 1 0 181
return 1 0 184
assign 1 0 187
assign 1 0 191
return 1 0 195
return 1 0 198
assign 1 0 201
assign 1 0 205
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1196099876: return bem_echo_0();
case 1452249789: return bem_intGet_0();
case -888502976: return bem_print_0();
case -170941956: return bem_serializeToString_0();
case 1989485633: return bem_many_0();
case -1222154604: return bem_tagGet_0();
case 1975980417: return bem_exceptGet_0();
case -494057832: return bem_serializationIteratorGet_0();
case -937358711: return bem_default_0();
case -294806467: return bem_create_0();
case 213564239: return bem_copy_0();
case -1916548323: return bem_once_0();
case -242463884: return bem_fieldIteratorGet_0();
case 2048807437: return bem_lastStrGetDirect_0();
case -1230714712: return bem_classNameGet_0();
case -671191297: return bem_serializeContents_0();
case -1342633655: return bem_hashGet_0();
case -1712025554: return bem_lastStrGet_0();
case -1297985879: return bem_fieldNamesGet_0();
case 1418348540: return bem_iteratorGet_0();
case -1925247459: return bem_sourceFileNameGet_0();
case 1832806152: return bem_toString_0();
case 1674611563: return bem_thingGet_0();
case 593076356: return bem_intGetDirect_0();
case -302817860: return bem_deserializeClassNameGet_0();
case 1797020795: return bem_toAny_0();
case 789087058: return bem_thingGetDirect_0();
case 612580527: return bem_exceptGetDirect_0();
case -1628841870: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1040130016: return bem_intSet_1(bevd_0);
case 83181817: return bem_undef_1(bevd_0);
case 1450581135: return bem_printException_1(bevd_0);
case -551325862: return bem_exceptSet_1(bevd_0);
case -1451132900: return bem_intSetDirect_1(bevd_0);
case -152296894: return bem_equals_1(bevd_0);
case -810647371: return bem_sameClass_1(bevd_0);
case 1602348302: return bem_sameObject_1(bevd_0);
case -447680398: return bem_lastStrSetDirect_1(bevd_0);
case 1476452596: return bem_exceptSetDirect_1(bevd_0);
case 346995129: return bem_def_1(bevd_0);
case -445991406: return bem_sendToConsole_1(bevd_0);
case -788622974: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -395616432: return bem_otherClass_1(bevd_0);
case 936942966: return bem_undefined_1(bevd_0);
case 1345095935: return bem_defined_1(bevd_0);
case 945449374: return bem_notEquals_1(bevd_0);
case -2046043947: return bem_copyTo_1(bevd_0);
case -1967180933: return bem_thingSetDirect_1(bevd_0);
case 1495593147: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1811224480: return bem_sameType_1(bevd_0);
case 352994056: return bem_lastStrSet_1(bevd_0);
case -118558475: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -4969921: return bem_thingSet_1(bevd_0);
case 79810732: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1796596677: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -174395426: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1117645207: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1434652185: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2038467728: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 6185266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 459469770: return bem_getLineForEmitLine_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 34704188: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1515774718: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_6(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5) {
switch (callId) {
case -1243798314: return bem_buildException_6(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
return base.bemd_6(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemExceptionBuilder_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemExceptionBuilder_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_16_SystemExceptionBuilder();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst = (BEC_2_6_16_SystemExceptionBuilder) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;
}
}
}
