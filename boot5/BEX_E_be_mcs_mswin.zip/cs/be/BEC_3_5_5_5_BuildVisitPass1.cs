namespace be {
/* IO:File: source/build/Pass1.be */
public sealed class BEC_3_5_5_5_BuildVisitPass1 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass1() { }
static BEC_3_5_5_5_BuildVisitPass1() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_0 = {};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_1 = {};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_2 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass1_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass1_bels_2, 1));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_3 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass1_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass1_bels_3, 1));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_4 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass1_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass1_bels_4, 1));
public static new BEC_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;

public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_allAstElements;
public BEC_2_6_6_SystemObject bevp_f;
public BEC_2_4_6_TextString bevp_inClass;
public BEC_2_4_6_TextString bevp_inClassMethod;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_new_2(BEC_2_9_3_ContainerSet beva__printAstElements, BEC_2_4_6_TextString beva__fname) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpany_phold = null;
bevp_printAstElements = beva__printAstElements;
bevp_allAstElements = bevp_printAstElements.bem_isEmptyGet_0();
if (beva__fname == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 26 */ {
bevt_3_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva__fname);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_fileGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_writerGet_0();
bevp_f = bevt_1_tmpany_phold.bemd_0(2007080127);
} /* Line: 27 */
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_inLine = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_46_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_47_tmpany_phold = null;
bevt_5_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_5_tmpany_phold.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 36 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_0));
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_sameType_1(bevt_9_tmpany_phold);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevp_inClass = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 38 */
 else  /* Line: 39 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-745462197);
bevp_inClass = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bemd_0(-914943787);
} /* Line: 40 */
bevp_inClassMethod = null;
bevl_inLine = null;
} /* Line: 43 */
bevt_13_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_14_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_13_tmpany_phold.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 45 */ {
if (bevp_inClass == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 45 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 45 */ {
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_1));
bevt_18_tmpany_phold = beva_node.bem_heldGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_sameType_1(bevt_18_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevp_inClassMethod = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 47 */
 else  /* Line: 46 */ {
bevt_21_tmpany_phold = beva_node.bem_heldGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(446398033);
if (bevt_20_tmpany_phold == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_23_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass1_bevo_0;
bevt_22_tmpany_phold = bevp_inClass.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = beva_node.bem_heldGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(446398033);
bevp_inClassMethod = bevt_22_tmpany_phold.bem_add_1(bevt_24_tmpany_phold);
} /* Line: 49 */
 else  /* Line: 46 */ {
bevt_28_tmpany_phold = beva_node.bem_heldGet_0();
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(594614948);
if (bevt_27_tmpany_phold == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_30_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass1_bevo_1;
bevt_29_tmpany_phold = bevp_inClass.bem_add_1(bevt_30_tmpany_phold);
bevt_32_tmpany_phold = beva_node.bem_heldGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_0(594614948);
bevp_inClassMethod = bevt_29_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
} /* Line: 51 */
} /* Line: 46 */
} /* Line: 46 */
} /* Line: 46 */
if (bevp_inClassMethod == null) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevt_35_tmpany_phold = beva_node.bem_nlcGet_0();
if (bevt_35_tmpany_phold == null) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
 else  /* Line: 55 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 55 */ {
bevt_37_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass1_bevo_2;
bevt_36_tmpany_phold = bevp_inClassMethod.bem_add_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = beva_node.bem_nlcGet_0();
bevl_inLine = bevt_36_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
} /* Line: 56 */
if (bevp_allAstElements.bevi_bool) /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
if (bevp_inClassMethod == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_40_tmpany_phold = bevp_printAstElements.bem_has_1(bevp_inClassMethod);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
 else  /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
if (bevl_inLine == null) {
bevt_41_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_41_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_42_tmpany_phold = bevp_printAstElements.bem_has_1(bevl_inLine);
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
 else  /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 58 */ {
if (bevp_f == null) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_44_tmpany_phold = beva_node.bem_toString_0();
bevp_f.bemd_1(1354761082, bevt_44_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_newlineGet_0();
bevp_f.bemd_1(1354761082, bevt_45_tmpany_phold);
} /* Line: 61 */
 else  /* Line: 62 */ {
beva_node.bem_print_0();
} /* Line: 63 */
} /* Line: 59 */
bevt_47_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_47_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAstElementsGet_0() {
return bevp_allAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_allAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allAstElements = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fGet_0() {
return bevp_f;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_fSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_f = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClass = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassMethodGet_0() {
return bevp_inClassMethod;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassMethodSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassMethod = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {24, 25, 26, 26, 27, 27, 27, 27, 36, 36, 36, 36, 37, 37, 37, 38, 40, 40, 40, 42, 43, 45, 45, 45, 45, 45, 45, 0, 0, 0, 46, 46, 46, 47, 48, 48, 48, 48, 49, 49, 49, 49, 49, 50, 50, 50, 50, 51, 51, 51, 51, 51, 55, 55, 55, 55, 55, 0, 0, 0, 56, 56, 56, 56, 0, 58, 58, 58, 0, 0, 0, 0, 0, 0, 58, 58, 58, 0, 0, 0, 0, 0, 59, 59, 60, 60, 61, 61, 61, 63, 66, 66, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {33, 34, 35, 40, 41, 42, 43, 44, 98, 99, 100, 105, 106, 107, 108, 110, 113, 114, 115, 117, 118, 120, 121, 122, 127, 128, 133, 134, 137, 141, 144, 145, 146, 148, 151, 152, 153, 158, 159, 160, 161, 162, 163, 166, 167, 168, 173, 174, 175, 176, 177, 178, 183, 188, 189, 190, 195, 196, 199, 203, 206, 207, 208, 209, 212, 215, 220, 221, 223, 226, 230, 233, 236, 240, 243, 248, 249, 251, 254, 258, 261, 264, 268, 273, 274, 275, 276, 277, 278, 281, 284, 285, 288, 291, 295, 298, 302, 305, 309, 312, 316, 319};
/* BEGIN LINEINFO 
assign 1 24 33
assign 1 25 34
isEmptyGet 0 25 34
assign 1 26 35
def 1 26 40
assign 1 27 41
new 1 27 41
assign 1 27 42
fileGet 0 27 42
assign 1 27 43
writerGet 0 27 43
assign 1 27 44
open 0 27 44
assign 1 36 98
typenameGet 0 36 98
assign 1 36 99
CLASSGet 0 36 99
assign 1 36 100
equals 1 36 105
assign 1 37 106
new 0 37 106
assign 1 37 107
heldGet 0 37 107
assign 1 37 108
sameType 1 37 108
assign 1 38 110
heldGet 0 38 110
assign 1 40 113
heldGet 0 40 113
assign 1 40 114
namepathGet 0 40 114
assign 1 40 115
toString 0 40 115
assign 1 42 117
assign 1 43 118
assign 1 45 120
typenameGet 0 45 120
assign 1 45 121
METHODGet 0 45 121
assign 1 45 122
equals 1 45 127
assign 1 45 128
def 1 45 133
assign 1 0 134
assign 1 0 137
assign 1 0 141
assign 1 46 144
new 0 46 144
assign 1 46 145
heldGet 0 46 145
assign 1 46 146
sameType 1 46 146
assign 1 47 148
heldGet 0 47 148
assign 1 48 151
heldGet 0 48 151
assign 1 48 152
orgNameGet 0 48 152
assign 1 48 153
def 1 48 158
assign 1 49 159
new 0 49 159
assign 1 49 160
add 1 49 160
assign 1 49 161
heldGet 0 49 161
assign 1 49 162
orgNameGet 0 49 162
assign 1 49 163
add 1 49 163
assign 1 50 166
heldGet 0 50 166
assign 1 50 167
nameGet 0 50 167
assign 1 50 168
def 1 50 173
assign 1 51 174
new 0 51 174
assign 1 51 175
add 1 51 175
assign 1 51 176
heldGet 0 51 176
assign 1 51 177
nameGet 0 51 177
assign 1 51 178
add 1 51 178
assign 1 55 183
def 1 55 188
assign 1 55 189
nlcGet 0 55 189
assign 1 55 190
def 1 55 195
assign 1 0 196
assign 1 0 199
assign 1 0 203
assign 1 56 206
new 0 56 206
assign 1 56 207
add 1 56 207
assign 1 56 208
nlcGet 0 56 208
assign 1 56 209
add 1 56 209
assign 1 0 212
assign 1 58 215
def 1 58 220
assign 1 58 221
has 1 58 221
assign 1 0 223
assign 1 0 226
assign 1 0 230
assign 1 0 233
assign 1 0 236
assign 1 0 240
assign 1 58 243
def 1 58 248
assign 1 58 249
has 1 58 249
assign 1 0 251
assign 1 0 254
assign 1 0 258
assign 1 0 261
assign 1 0 264
assign 1 59 268
def 1 59 273
assign 1 60 274
toString 0 60 274
write 1 60 275
assign 1 61 276
new 0 61 276
assign 1 61 277
newlineGet 0 61 277
write 1 61 278
print 0 63 281
assign 1 66 284
nextDescendGet 0 66 284
return 1 66 285
return 1 0 288
assign 1 0 291
return 1 0 295
assign 1 0 298
return 1 0 302
assign 1 0 305
return 1 0 309
assign 1 0 312
return 1 0 316
assign 1 0 319
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1509977123: return bem_fGet_0();
case 1334927002: return bem_create_0();
case -914943787: return bem_toString_0();
case -1558494121: return bem_ntypesGet_0();
case -1620303979: return bem_once_0();
case 93356535: return bem_deserializeClassNameGet_0();
case -541227487: return bem_new_0();
case 1280569362: return bem_fieldIteratorGet_0();
case 682679642: return bem_buildGet_0();
case 1624944174: return bem_serializationIteratorGet_0();
case -1942605555: return bem_toAny_0();
case 1099128486: return bem_echo_0();
case 1353564137: return bem_transGet_0();
case 342664202: return bem_serializeContents_0();
case -636286022: return bem_printAstElementsGet_0();
case 572982112: return bem_inClassMethodGet_0();
case -1117992648: return bem_hashGet_0();
case -1248348608: return bem_many_0();
case -152803575: return bem_tagGet_0();
case -1618533783: return bem_serializeToString_0();
case -1920078604: return bem_sourceFileNameGet_0();
case 1754519730: return bem_classNameGet_0();
case 38289726: return bem_print_0();
case 385489744: return bem_iteratorGet_0();
case -1009233812: return bem_allAstElementsGet_0();
case 1442085734: return bem_constGet_0();
case -1749035302: return bem_copy_0();
case 1740626193: return bem_inClassGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 960625295: return bem_notEquals_1(bevd_0);
case 1005433624: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1669123607: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 327551615: return bem_undef_1(bevd_0);
case -1977729337: return bem_fSet_1(bevd_0);
case -1001167064: return bem_def_1(bevd_0);
case -842251577: return bem_inClassSet_1(bevd_0);
case -147916244: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 905415945: return bem_begin_1(bevd_0);
case -900790842: return bem_defined_1(bevd_0);
case 2079969726: return bem_printAstElementsSet_1(bevd_0);
case -929975460: return bem_equals_1(bevd_0);
case 589015080: return bem_otherType_1(bevd_0);
case -1553866014: return bem_sameClass_1(bevd_0);
case -946854303: return bem_constSet_1(bevd_0);
case -1975825183: return bem_sameObject_1(bevd_0);
case -1765794133: return bem_inClassMethodSet_1(bevd_0);
case 941456754: return bem_transSet_1(bevd_0);
case 775829179: return bem_end_1(bevd_0);
case -2057956567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -406377870: return bem_copyTo_1(bevd_0);
case -1216622033: return bem_buildSet_1(bevd_0);
case 1356842566: return bem_otherClass_1(bevd_0);
case -431709525: return bem_ntypesSet_1(bevd_0);
case 1996341891: return bem_allAstElementsSet_1(bevd_0);
case 408844820: return bem_undefined_1(bevd_0);
case 32553456: return bem_sameType_1(bevd_0);
case 1417404860: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1615755198: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1430698213: return bem_new_2((BEC_2_9_3_ContainerSet) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 914119897: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1722418125: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1183458920: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -294037420: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1794036335: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1344222461: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass1_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass1_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass1();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst = (BEC_3_5_5_5_BuildVisitPass1) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;
}
}
}
