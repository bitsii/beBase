namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_4_BuildEmit : BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildEmit() { }
static BEC_2_5_4_BuildEmit() { }
private static byte[] becc_BEC_2_5_4_BuildEmit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74};
private static byte[] becc_BEC_2_5_4_BuildEmit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static new BEC_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_inst;

public static new BET_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_type;

public BEC_2_4_6_TextString bevp_text;
public BEC_2_9_3_ContainerSet bevp_langs;
public BEC_2_5_4_BuildEmit bem_new_2(BEC_2_4_6_TextString beva__text, BEC_2_9_3_ContainerSet beva__langs) {
bevp_text = beva__text;
bevp_langs = beva__langs;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_textGet_0() {
return bevp_text;
} /*method end*/
public BEC_2_4_6_TextString bem_textGetDirect_0() {
return bevp_text;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_textSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_text = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_textSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_text = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_langsGet_0() {
return bevp_langs;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_langsGetDirect_0() {
return bevp_langs;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_langsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_langsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {73, 74, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {15, 16, 20, 23, 26, 30, 34, 37, 40, 44};
/* BEGIN LINEINFO 
assign 1 73 15
assign 1 74 16
return 1 0 20
return 1 0 23
assign 1 0 26
assign 1 0 30
return 1 0 34
return 1 0 37
assign 1 0 40
assign 1 0 44
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 270781002: return bem_new_0();
case -601453628: return bem_fieldIteratorGet_0();
case -1156903676: return bem_serializationIteratorGet_0();
case -1869924457: return bem_sourceFileNameGet_0();
case 1291824271: return bem_echo_0();
case -1123266766: return bem_classNameGet_0();
case 482259213: return bem_langsGetDirect_0();
case 1151085267: return bem_deserializeClassNameGet_0();
case 216633460: return bem_serializeContents_0();
case -475908396: return bem_langsGet_0();
case 770261150: return bem_textGetDirect_0();
case 1562356496: return bem_hashGet_0();
case 19210432: return bem_iteratorGet_0();
case 1597530459: return bem_print_0();
case 721123821: return bem_tagGet_0();
case -827080774: return bem_copy_0();
case 595935693: return bem_create_0();
case 1253492311: return bem_textGet_0();
case -390286916: return bem_serializeToString_0();
case 559255035: return bem_fieldNamesGet_0();
case -860520942: return bem_toString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1221937447: return bem_textSetDirect_1(bevd_0);
case -323113819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2138090541: return bem_sameClass_1(bevd_0);
case -690535851: return bem_sameObject_1(bevd_0);
case -499138365: return bem_otherClass_1(bevd_0);
case 2140620274: return bem_otherType_1(bevd_0);
case -696336738: return bem_equals_1(bevd_0);
case 1788911287: return bem_sameType_1(bevd_0);
case -637072093: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1378558194: return bem_textSet_1(bevd_0);
case -1582378113: return bem_notEquals_1(bevd_0);
case -478520463: return bem_undef_1(bevd_0);
case -89866327: return bem_copyTo_1(bevd_0);
case -992886072: return bem_langsSet_1(bevd_0);
case -327732297: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 750129523: return bem_langsSetDirect_1(bevd_0);
case 1720726298: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -77252171: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 350317076: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1828646701: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -104691827: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -733779503: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1327820471: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_3_ContainerSet) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildEmit_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildEmit_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_BuildEmit();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst = (BEC_2_5_4_BuildEmit) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_type;
}
}
}
