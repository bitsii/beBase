namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_4_BuildCall : BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildCall() { }
static BEC_2_5_4_BuildCall() { }
private static byte[] becc_BEC_2_5_4_BuildCall_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x61,0x6C,0x6C};
private static byte[] becc_BEC_2_5_4_BuildCall_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_0 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_1, 7));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_2 = {0x20,0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_2, 10));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_3 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_3, 10));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_4 = {0x20,0x6E,0x6F,0x74,0x42,0x6F,0x75,0x6E,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_4, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_5 = {0x20,0x77,0x61,0x73,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_5, 12));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_6 = {0x47,0x45,0x54};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_6, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_7 = {0x47,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_7, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_8 = {0x53,0x45,0x54};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_8, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_9 = {0x53,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_9, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_10 = {0x47,0x45,0x54,0x44,0x49,0x52,0x45,0x43,0x54};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_10, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_11 = {0x47,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_11, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_12 = {0x53,0x45,0x54,0x44,0x49,0x52,0x45,0x43,0x54};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_12, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_13 = {0x53,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_13, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_14 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72,0x20,0x74,0x79,0x70,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_14, 22));
public static new BEC_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_inst;

public static new BET_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_6_TextString bevp_accessorType;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_literalValue;
public BEC_2_5_8_BuildNamePath bevp_newNp;
public BEC_2_4_3_MathInt bevp_cpos;
public BEC_2_5_4_LogicBool bevp_isConstruct;
public BEC_2_5_4_LogicBool bevp_bound;
public BEC_2_5_4_LogicBool bevp_wasBound;
public BEC_2_5_4_LogicBool bevp_wasAccessor;
public BEC_2_5_4_LogicBool bevp_wasOper;
public BEC_2_5_4_LogicBool bevp_isLiteral;
public BEC_2_5_4_LogicBool bevp_isOnce;
public BEC_2_5_4_LogicBool bevp_isMany;
public BEC_2_5_4_LogicBool bevp_checkTypes;
public BEC_2_4_6_TextString bevp_checkTypesType;
public BEC_2_5_4_LogicBool bevp_superCall;
public BEC_2_5_4_LogicBool bevp_wasImpliedConstruct;
public BEC_2_5_4_LogicBool bevp_wasForeachGenned;
public BEC_2_5_4_LogicBool bevp_untyped;
public BEC_2_5_4_LogicBool bevp_isForward;
public BEC_2_9_4_ContainerList bevp_argCasts;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_isConstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_bound = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_wasBound = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_wasAccessor = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasOper = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isLiteral = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isOnce = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isMany = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_checkTypes = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_checkTypesType = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildCall_bels_0));
bevp_superCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_untyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isForward = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_argCasts = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
bevl_ret = bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_0;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 326 */
if (bevp_orgName == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_1;
bevt_5_tmpany_phold = bevl_ret.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_orgName.bem_toString_0();
bevl_ret = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 329 */
if (bevp_numargs == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_2;
bevt_9_tmpany_phold = bevl_ret.bem_add_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_numargs.bem_toString_0();
bevl_ret = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
} /* Line: 332 */
if (bevp_bound.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_3;
bevl_ret = bevl_ret.bem_add_1(bevt_13_tmpany_phold);
} /* Line: 335 */
if (bevp_wasAccessor.bevi_bool) /* Line: 337 */ {
bevt_14_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_4;
bevl_ret = bevl_ret.bem_add_1(bevt_14_tmpany_phold);
} /* Line: 338 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildCall bem_toAccessorName_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_5;
bevt_0_tmpany_phold = bevp_accessorType.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_6;
bevp_name = bevp_name.bem_add_1(bevt_2_tmpany_phold);
} /* Line: 345 */
 else  /* Line: 344 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_7;
bevt_3_tmpany_phold = bevp_accessorType.bem_equals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_8;
bevp_name = bevp_name.bem_add_1(bevt_5_tmpany_phold);
} /* Line: 347 */
 else  /* Line: 344 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_9;
bevt_6_tmpany_phold = bevp_accessorType.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_10;
bevp_name = bevp_name.bem_add_1(bevt_8_tmpany_phold);
} /* Line: 349 */
 else  /* Line: 344 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_11;
bevt_9_tmpany_phold = bevp_accessorType.bem_equals_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_12;
bevp_name = bevp_name.bem_add_1(bevt_11_tmpany_phold);
} /* Line: 351 */
 else  /* Line: 352 */ {
bevt_14_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_13;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevp_accessorType);
bevt_12_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_13_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_12_tmpany_phold);
} /* Line: 353 */
} /* Line: 344 */
} /* Line: 344 */
} /* Line: 344 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_4_BuildCall bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGetDirect_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_5_4_BuildCall bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_accessorTypeGet_0() {
return bevp_accessorType;
} /*method end*/
public BEC_2_4_6_TextString bem_accessorTypeGetDirect_0() {
return bevp_accessorType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_accessorTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_accessorTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGetDirect_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_5_4_BuildCall bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_literalValueGet_0() {
return bevp_literalValue;
} /*method end*/
public BEC_2_4_6_TextString bem_literalValueGetDirect_0() {
return bevp_literalValue;
} /*method end*/
public BEC_2_5_4_BuildCall bem_literalValueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_literalValueSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_newNpGet_0() {
return bevp_newNp;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_newNpGetDirect_0() {
return bevp_newNp;
} /*method end*/
public BEC_2_5_4_BuildCall bem_newNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_newNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() {
return bevp_cpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGetDirect_0() {
return bevp_cpos;
} /*method end*/
public BEC_2_5_4_BuildCall bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_cposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isConstructGet_0() {
return bevp_isConstruct;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isConstructGetDirect_0() {
return bevp_isConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isConstructSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isConstructSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boundGet_0() {
return bevp_bound;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boundGetDirect_0() {
return bevp_bound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_boundSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_boundSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasBoundGet_0() {
return bevp_wasBound;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasBoundGetDirect_0() {
return bevp_wasBound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasBoundSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasBoundSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasAccessorGet_0() {
return bevp_wasAccessor;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasAccessorGetDirect_0() {
return bevp_wasAccessor;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasOperGet_0() {
return bevp_wasOper;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasOperGetDirect_0() {
return bevp_wasOper;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasOperSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasOperSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralGet_0() {
return bevp_isLiteral;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralGetDirect_0() {
return bevp_isLiteral;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isLiteralSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isLiteralSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOnceGet_0() {
return bevp_isOnce;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOnceGetDirect_0() {
return bevp_isOnce;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isOnceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isOnce = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isOnceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isOnce = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isManyGet_0() {
return bevp_isMany;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isManyGetDirect_0() {
return bevp_isMany;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isManySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isMany = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isManySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isMany = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkTypesGet_0() {
return bevp_checkTypes;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkTypesGetDirect_0() {
return bevp_checkTypes;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_checkTypesTypeGet_0() {
return bevp_checkTypesType;
} /*method end*/
public BEC_2_4_6_TextString bem_checkTypesTypeGetDirect_0() {
return bevp_checkTypesType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_checkTypesType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_checkTypesType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_superCallGet_0() {
return bevp_superCall;
} /*method end*/
public BEC_2_5_4_LogicBool bem_superCallGetDirect_0() {
return bevp_superCall;
} /*method end*/
public BEC_2_5_4_BuildCall bem_superCallSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_superCallSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasImpliedConstructGet_0() {
return bevp_wasImpliedConstruct;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasImpliedConstructGetDirect_0() {
return bevp_wasImpliedConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasImpliedConstructSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasImpliedConstructSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasForeachGennedGet_0() {
return bevp_wasForeachGenned;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasForeachGennedGetDirect_0() {
return bevp_wasForeachGenned;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasForeachGennedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasForeachGennedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_untypedGet_0() {
return bevp_untyped;
} /*method end*/
public BEC_2_5_4_LogicBool bem_untypedGetDirect_0() {
return bevp_untyped;
} /*method end*/
public BEC_2_5_4_BuildCall bem_untypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_untypedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isForwardGet_0() {
return bevp_isForward;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isForwardGetDirect_0() {
return bevp_isForward;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isForwardSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isForward = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isForwardSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isForward = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argCastsGet_0() {
return bevp_argCasts;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argCastsGetDirect_0() {
return bevp_argCasts;
} /*method end*/
public BEC_2_5_4_BuildCall bem_argCastsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_argCastsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 317, 324, 325, 325, 326, 326, 326, 326, 328, 328, 329, 329, 329, 329, 331, 331, 332, 332, 332, 332, 334, 334, 335, 335, 338, 338, 340, 344, 344, 345, 345, 346, 346, 347, 347, 348, 348, 349, 349, 350, 350, 351, 351, 353, 353, 353, 353, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 100, 101, 106, 107, 108, 109, 110, 112, 117, 118, 119, 120, 121, 123, 128, 129, 130, 131, 132, 134, 139, 140, 141, 144, 145, 147, 165, 166, 168, 169, 172, 173, 175, 176, 179, 180, 182, 183, 186, 187, 189, 190, 193, 194, 195, 196, 204, 207, 210, 214, 218, 221, 224, 228, 232, 235, 238, 242, 246, 249, 252, 256, 260, 263, 266, 270, 274, 277, 280, 284, 288, 291, 294, 298, 302, 305, 308, 312, 316, 319, 322, 326, 330, 333, 336, 340, 344, 347, 350, 354, 358, 361, 364, 368, 372, 375, 378, 382, 386, 389, 392, 396, 400, 403, 406, 410, 414, 417, 420, 424, 428, 431, 434, 438, 442, 445, 448, 452, 456, 459, 462, 466, 470, 473, 476, 480, 484, 487, 490, 494, 498, 501, 504, 508, 512, 515, 518, 522};
/* BEGIN LINEINFO 
assign 1 301 65
new 0 301 65
assign 1 302 66
new 0 302 66
assign 1 303 67
new 0 303 67
assign 1 304 68
new 0 304 68
assign 1 305 69
new 0 305 69
assign 1 306 70
new 0 306 70
assign 1 307 71
new 0 307 71
assign 1 308 72
new 0 308 72
assign 1 309 73
new 0 309 73
assign 1 310 74
new 0 310 74
assign 1 311 75
new 0 311 75
assign 1 312 76
new 0 312 76
assign 1 313 77
new 0 313 77
assign 1 314 78
new 0 314 78
assign 1 315 79
new 0 315 79
assign 1 317 80
new 0 317 80
assign 1 324 100
classNameGet 0 324 100
assign 1 325 101
def 1 325 106
assign 1 326 107
new 0 326 107
assign 1 326 108
add 1 326 108
assign 1 326 109
toString 0 326 109
assign 1 326 110
add 1 326 110
assign 1 328 112
def 1 328 117
assign 1 329 118
new 0 329 118
assign 1 329 119
add 1 329 119
assign 1 329 120
toString 0 329 120
assign 1 329 121
add 1 329 121
assign 1 331 123
def 1 331 128
assign 1 332 129
new 0 332 129
assign 1 332 130
add 1 332 130
assign 1 332 131
toString 0 332 131
assign 1 332 132
add 1 332 132
assign 1 334 134
not 0 334 139
assign 1 335 140
new 0 335 140
assign 1 335 141
add 1 335 141
assign 1 338 144
new 0 338 144
assign 1 338 145
add 1 338 145
return 1 340 147
assign 1 344 165
new 0 344 165
assign 1 344 166
equals 1 344 166
assign 1 345 168
new 0 345 168
assign 1 345 169
add 1 345 169
assign 1 346 172
new 0 346 172
assign 1 346 173
equals 1 346 173
assign 1 347 175
new 0 347 175
assign 1 347 176
add 1 347 176
assign 1 348 179
new 0 348 179
assign 1 348 180
equals 1 348 180
assign 1 349 182
new 0 349 182
assign 1 349 183
add 1 349 183
assign 1 350 186
new 0 350 186
assign 1 350 187
equals 1 350 187
assign 1 351 189
new 0 351 189
assign 1 351 190
add 1 351 190
assign 1 353 193
new 0 353 193
assign 1 353 194
add 1 353 194
assign 1 353 195
new 1 353 195
throw 1 353 196
return 1 0 204
return 1 0 207
assign 1 0 210
assign 1 0 214
return 1 0 218
return 1 0 221
assign 1 0 224
assign 1 0 228
return 1 0 232
return 1 0 235
assign 1 0 238
assign 1 0 242
return 1 0 246
return 1 0 249
assign 1 0 252
assign 1 0 256
return 1 0 260
return 1 0 263
assign 1 0 266
assign 1 0 270
return 1 0 274
return 1 0 277
assign 1 0 280
assign 1 0 284
return 1 0 288
return 1 0 291
assign 1 0 294
assign 1 0 298
return 1 0 302
return 1 0 305
assign 1 0 308
assign 1 0 312
return 1 0 316
return 1 0 319
assign 1 0 322
assign 1 0 326
return 1 0 330
return 1 0 333
assign 1 0 336
assign 1 0 340
return 1 0 344
return 1 0 347
assign 1 0 350
assign 1 0 354
return 1 0 358
return 1 0 361
assign 1 0 364
assign 1 0 368
return 1 0 372
return 1 0 375
assign 1 0 378
assign 1 0 382
return 1 0 386
return 1 0 389
assign 1 0 392
assign 1 0 396
return 1 0 400
return 1 0 403
assign 1 0 406
assign 1 0 410
return 1 0 414
return 1 0 417
assign 1 0 420
assign 1 0 424
return 1 0 428
return 1 0 431
assign 1 0 434
assign 1 0 438
return 1 0 442
return 1 0 445
assign 1 0 448
assign 1 0 452
return 1 0 456
return 1 0 459
assign 1 0 462
assign 1 0 466
return 1 0 470
return 1 0 473
assign 1 0 476
assign 1 0 480
return 1 0 484
return 1 0 487
assign 1 0 490
assign 1 0 494
return 1 0 498
return 1 0 501
assign 1 0 504
assign 1 0 508
return 1 0 512
return 1 0 515
assign 1 0 518
assign 1 0 522
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1652434526: return bem_toAccessorName_0();
case -2044460281: return bem_new_0();
case 1698340076: return bem_wasImpliedConstructGetDirect_0();
case 1561881831: return bem_tagGet_0();
case -1686364977: return bem_boundGet_0();
case 1174668765: return bem_superCallGetDirect_0();
case 2093985371: return bem_wasOperGet_0();
case 1662406160: return bem_checkTypesTypeGetDirect_0();
case -427081409: return bem_create_0();
case 1648133590: return bem_numargsGetDirect_0();
case 1930858184: return bem_isOnceGetDirect_0();
case -1999703144: return bem_sourceFileNameGet_0();
case -1546900737: return bem_superCallGet_0();
case -1587523197: return bem_boundGetDirect_0();
case -644242241: return bem_nameGetDirect_0();
case 1992583192: return bem_classNameGet_0();
case -885926245: return bem_untypedGetDirect_0();
case 483473422: return bem_wasBoundGet_0();
case 1814224875: return bem_numargsGet_0();
case -1796959609: return bem_cposGetDirect_0();
case -1292911566: return bem_wasForeachGennedGetDirect_0();
case 970024339: return bem_wasAccessorGetDirect_0();
case -31877142: return bem_many_0();
case -1573383487: return bem_literalValueGet_0();
case -392612242: return bem_checkTypesTypeGet_0();
case 987048722: return bem_serializeContents_0();
case 93235465: return bem_argCastsGetDirect_0();
case 914230152: return bem_newNpGet_0();
case 1599241336: return bem_iteratorGet_0();
case 2015106475: return bem_isManyGetDirect_0();
case -1474345157: return bem_serializeToString_0();
case -1154111865: return bem_isLiteralGet_0();
case -758121927: return bem_cposGet_0();
case 505878419: return bem_accessorTypeGetDirect_0();
case -635457991: return bem_wasBoundGetDirect_0();
case 950624748: return bem_isManyGet_0();
case 1969575499: return bem_untypedGet_0();
case 113641261: return bem_isConstructGet_0();
case -141904644: return bem_toString_0();
case -947799090: return bem_checkTypesGet_0();
case 142719737: return bem_wasOperGetDirect_0();
case -709677651: return bem_fieldNamesGet_0();
case -747859575: return bem_echo_0();
case -1995316249: return bem_orgNameGet_0();
case 629597628: return bem_literalValueGetDirect_0();
case -1813730995: return bem_accessorTypeGet_0();
case 325124813: return bem_wasImpliedConstructGet_0();
case 247818182: return bem_copy_0();
case -331251298: return bem_wasForeachGennedGet_0();
case 1961698652: return bem_wasAccessorGet_0();
case -1503949943: return bem_hashGet_0();
case 421047878: return bem_serializationIteratorGet_0();
case 1374872636: return bem_deserializeClassNameGet_0();
case -991837940: return bem_isForwardGet_0();
case 1410383733: return bem_orgNameGetDirect_0();
case -335942583: return bem_fieldIteratorGet_0();
case 1035232271: return bem_toAny_0();
case 1058055000: return bem_isConstructGetDirect_0();
case 476222825: return bem_nameGet_0();
case -647519736: return bem_print_0();
case -1437805403: return bem_newNpGetDirect_0();
case 1034659716: return bem_once_0();
case 703162258: return bem_isOnceGet_0();
case -1563879420: return bem_argCastsGet_0();
case 1500644939: return bem_isForwardGetDirect_0();
case 1148027265: return bem_checkTypesGetDirect_0();
case -524267492: return bem_isLiteralGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1051165080: return bem_sameObject_1(bevd_0);
case -1103337674: return bem_undefined_1(bevd_0);
case 2013241330: return bem_wasBoundSetDirect_1(bevd_0);
case 1963866397: return bem_isConstructSetDirect_1(bevd_0);
case 1489846899: return bem_checkTypesTypeSet_1(bevd_0);
case 499827148: return bem_newNpSet_1(bevd_0);
case -260777908: return bem_wasImpliedConstructSetDirect_1(bevd_0);
case -226818644: return bem_boundSet_1(bevd_0);
case 544063329: return bem_equals_1(bevd_0);
case 742076548: return bem_checkTypesSetDirect_1(bevd_0);
case -147275381: return bem_newNpSetDirect_1(bevd_0);
case 1334115969: return bem_boundSetDirect_1(bevd_0);
case 1488322431: return bem_isLiteralSetDirect_1(bevd_0);
case 467730220: return bem_otherType_1(bevd_0);
case -2126621920: return bem_cposSetDirect_1(bevd_0);
case 235476031: return bem_checkTypesSet_1(bevd_0);
case 593002763: return bem_wasBoundSet_1(bevd_0);
case -1951692948: return bem_argCastsSet_1(bevd_0);
case 461242022: return bem_orgNameSetDirect_1(bevd_0);
case -522075435: return bem_wasImpliedConstructSet_1(bevd_0);
case -1037648926: return bem_copyTo_1(bevd_0);
case -141282923: return bem_literalValueSetDirect_1(bevd_0);
case 1848290868: return bem_wasForeachGennedSetDirect_1(bevd_0);
case 1832534319: return bem_wasOperSet_1(bevd_0);
case -317049327: return bem_def_1(bevd_0);
case -316141734: return bem_untypedSet_1(bevd_0);
case 1482027850: return bem_sameClass_1(bevd_0);
case 1118935191: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1617324535: return bem_defined_1(bevd_0);
case 2027190115: return bem_checkTypesTypeSetDirect_1(bevd_0);
case -220725237: return bem_literalValueSet_1(bevd_0);
case -771020745: return bem_isLiteralSet_1(bevd_0);
case 1056498349: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2095532162: return bem_untypedSetDirect_1(bevd_0);
case -384031940: return bem_isOnceSetDirect_1(bevd_0);
case -628228719: return bem_isConstructSet_1(bevd_0);
case -394352513: return bem_nameSetDirect_1(bevd_0);
case 1897517537: return bem_wasForeachGennedSet_1(bevd_0);
case -767876115: return bem_undef_1(bevd_0);
case 2020667859: return bem_isManySet_1(bevd_0);
case 1027962447: return bem_isManySetDirect_1(bevd_0);
case 292324374: return bem_accessorTypeSetDirect_1(bevd_0);
case -1259048964: return bem_notEquals_1(bevd_0);
case -257421820: return bem_argCastsSetDirect_1(bevd_0);
case -1732439949: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -974947359: return bem_isOnceSet_1(bevd_0);
case 1379581160: return bem_orgNameSet_1(bevd_0);
case -153120716: return bem_superCallSet_1(bevd_0);
case -1739415947: return bem_isForwardSetDirect_1(bevd_0);
case -919355126: return bem_wasOperSetDirect_1(bevd_0);
case 1313385412: return bem_isForwardSet_1(bevd_0);
case -2136985639: return bem_sameType_1(bevd_0);
case 1402363485: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -342583693: return bem_wasAccessorSet_1(bevd_0);
case 614139318: return bem_numargsSet_1(bevd_0);
case -2096675050: return bem_wasAccessorSetDirect_1(bevd_0);
case -21460778: return bem_accessorTypeSet_1(bevd_0);
case 2144689719: return bem_cposSet_1(bevd_0);
case 2141740909: return bem_otherClass_1(bevd_0);
case -1244786367: return bem_nameSet_1(bevd_0);
case 1318016658: return bem_superCallSetDirect_1(bevd_0);
case -1549048294: return bem_numargsSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1477075576: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2067866135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 930768377: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1135810204: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -78432632: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -657633999: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1155749415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildCall_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildCall_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_BuildCall();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst = (BEC_2_5_4_BuildCall) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_type;
}
}
}
