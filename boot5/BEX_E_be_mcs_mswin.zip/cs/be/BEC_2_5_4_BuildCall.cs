namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_4_BuildCall : BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildCall() { }
static BEC_2_5_4_BuildCall() { }
private static byte[] becc_BEC_2_5_4_BuildCall_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x61,0x6C,0x6C};
private static byte[] becc_BEC_2_5_4_BuildCall_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_0 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_1, 7));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_2 = {0x20,0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_2, 10));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_3 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_3, 10));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_4 = {0x20,0x6E,0x6F,0x74,0x42,0x6F,0x75,0x6E,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_4, 9));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_5 = {0x20,0x77,0x61,0x73,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_5, 12));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_6 = {0x47,0x45,0x54};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_6, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_7 = {0x47,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_7, 3));
private static byte[] bece_BEC_2_5_4_BuildCall_bels_8 = {0x53,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_4_BuildCall_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_4_BuildCall_bels_8, 3));
public static new BEC_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_inst;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_6_TextString bevp_accessorType;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_literalValue;
public BEC_2_5_8_BuildNamePath bevp_newNp;
public BEC_2_4_3_MathInt bevp_cpos;
public BEC_2_5_4_LogicBool bevp_isConstruct;
public BEC_2_5_4_LogicBool bevp_bound;
public BEC_2_5_4_LogicBool bevp_wasBound;
public BEC_2_5_4_LogicBool bevp_wasAccessor;
public BEC_2_5_4_LogicBool bevp_wasOper;
public BEC_2_5_4_LogicBool bevp_isLiteral;
public BEC_2_5_4_LogicBool bevp_isOnce;
public BEC_2_5_4_LogicBool bevp_isMany;
public BEC_2_5_4_LogicBool bevp_checkTypes;
public BEC_2_4_6_TextString bevp_checkTypesType;
public BEC_2_5_4_LogicBool bevp_superCall;
public BEC_2_5_4_LogicBool bevp_wasImpliedConstruct;
public BEC_2_5_4_LogicBool bevp_wasForeachGenned;
public BEC_2_5_4_LogicBool bevp_untyped;
public BEC_2_5_4_LogicBool bevp_isForward;
public BEC_2_9_4_ContainerList bevp_argCasts;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_isConstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_bound = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_wasBound = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_wasAccessor = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasOper = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isLiteral = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isOnce = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isMany = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_checkTypes = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_checkTypesType = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildCall_bels_0));
bevp_superCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_untyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isForward = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_argCasts = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
bevl_ret = bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_0;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 326 */
if (bevp_orgName == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_1;
bevt_5_tmpany_phold = bevl_ret.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_orgName.bem_toString_0();
bevl_ret = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 329 */
if (bevp_numargs == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_2;
bevt_9_tmpany_phold = bevl_ret.bem_add_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_numargs.bem_toString_0();
bevl_ret = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
} /* Line: 332 */
if (bevp_bound.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_3;
bevl_ret = bevl_ret.bem_add_1(bevt_13_tmpany_phold);
} /* Line: 335 */
if (bevp_wasAccessor.bevi_bool) /* Line: 337 */ {
bevt_14_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_4;
bevl_ret = bevl_ret.bem_add_1(bevt_14_tmpany_phold);
} /* Line: 338 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildCall bem_toAccessorName_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_5;
bevt_0_tmpany_phold = bevp_accessorType.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_6;
bevp_name = bevp_name.bem_add_1(bevt_2_tmpany_phold);
} /* Line: 345 */
 else  /* Line: 346 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_4_BuildCall_bevo_7;
bevp_name = bevp_name.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 347 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_4_BuildCall bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_5_4_BuildCall bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_accessorTypeGet_0() {
return bevp_accessorType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_accessorTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_5_4_BuildCall bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_literalValueGet_0() {
return bevp_literalValue;
} /*method end*/
public BEC_2_5_4_BuildCall bem_literalValueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_newNpGet_0() {
return bevp_newNp;
} /*method end*/
public BEC_2_5_4_BuildCall bem_newNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() {
return bevp_cpos;
} /*method end*/
public BEC_2_5_4_BuildCall bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isConstructGet_0() {
return bevp_isConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isConstructSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boundGet_0() {
return bevp_bound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_boundSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasBoundGet_0() {
return bevp_wasBound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasBoundSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasAccessorGet_0() {
return bevp_wasAccessor;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasOperGet_0() {
return bevp_wasOper;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasOperSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralGet_0() {
return bevp_isLiteral;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isLiteralSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOnceGet_0() {
return bevp_isOnce;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isOnceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isOnce = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isManyGet_0() {
return bevp_isMany;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isManySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isMany = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkTypesGet_0() {
return bevp_checkTypes;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_checkTypesTypeGet_0() {
return bevp_checkTypesType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_checkTypesType = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_superCallGet_0() {
return bevp_superCall;
} /*method end*/
public BEC_2_5_4_BuildCall bem_superCallSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasImpliedConstructGet_0() {
return bevp_wasImpliedConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasImpliedConstructSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasForeachGennedGet_0() {
return bevp_wasForeachGenned;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasForeachGennedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_untypedGet_0() {
return bevp_untyped;
} /*method end*/
public BEC_2_5_4_BuildCall bem_untypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isForwardGet_0() {
return bevp_isForward;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isForwardSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isForward = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argCastsGet_0() {
return bevp_argCasts;
} /*method end*/
public BEC_2_5_4_BuildCall bem_argCastsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 317, 324, 325, 325, 326, 326, 326, 326, 328, 328, 329, 329, 329, 329, 331, 331, 332, 332, 332, 332, 334, 334, 335, 335, 338, 338, 340, 344, 344, 345, 345, 347, 347, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 85, 86, 91, 92, 93, 94, 95, 97, 102, 103, 104, 105, 106, 108, 113, 114, 115, 116, 117, 119, 124, 125, 126, 129, 130, 132, 139, 140, 142, 143, 146, 147, 152, 155, 159, 162, 166, 169, 173, 176, 180, 183, 187, 190, 194, 197, 201, 204, 208, 211, 215, 218, 222, 225, 229, 232, 236, 239, 243, 246, 250, 253, 257, 260, 264, 267, 271, 274, 278, 281, 285, 288, 292, 295, 299, 302, 306, 309};
/* BEGIN LINEINFO 
assign 1 301 50
new 0 301 50
assign 1 302 51
new 0 302 51
assign 1 303 52
new 0 303 52
assign 1 304 53
new 0 304 53
assign 1 305 54
new 0 305 54
assign 1 306 55
new 0 306 55
assign 1 307 56
new 0 307 56
assign 1 308 57
new 0 308 57
assign 1 309 58
new 0 309 58
assign 1 310 59
new 0 310 59
assign 1 311 60
new 0 311 60
assign 1 312 61
new 0 312 61
assign 1 313 62
new 0 313 62
assign 1 314 63
new 0 314 63
assign 1 315 64
new 0 315 64
assign 1 317 65
new 0 317 65
assign 1 324 85
classNameGet 0 324 85
assign 1 325 86
def 1 325 91
assign 1 326 92
new 0 326 92
assign 1 326 93
add 1 326 93
assign 1 326 94
toString 0 326 94
assign 1 326 95
add 1 326 95
assign 1 328 97
def 1 328 102
assign 1 329 103
new 0 329 103
assign 1 329 104
add 1 329 104
assign 1 329 105
toString 0 329 105
assign 1 329 106
add 1 329 106
assign 1 331 108
def 1 331 113
assign 1 332 114
new 0 332 114
assign 1 332 115
add 1 332 115
assign 1 332 116
toString 0 332 116
assign 1 332 117
add 1 332 117
assign 1 334 119
not 0 334 124
assign 1 335 125
new 0 335 125
assign 1 335 126
add 1 335 126
assign 1 338 129
new 0 338 129
assign 1 338 130
add 1 338 130
return 1 340 132
assign 1 344 139
new 0 344 139
assign 1 344 140
equals 1 344 140
assign 1 345 142
new 0 345 142
assign 1 345 143
add 1 345 143
assign 1 347 146
new 0 347 146
assign 1 347 147
add 1 347 147
return 1 0 152
assign 1 0 155
return 1 0 159
assign 1 0 162
return 1 0 166
assign 1 0 169
return 1 0 173
assign 1 0 176
return 1 0 180
assign 1 0 183
return 1 0 187
assign 1 0 190
return 1 0 194
assign 1 0 197
return 1 0 201
assign 1 0 204
return 1 0 208
assign 1 0 211
return 1 0 215
assign 1 0 218
return 1 0 222
assign 1 0 225
return 1 0 229
assign 1 0 232
return 1 0 236
assign 1 0 239
return 1 0 243
assign 1 0 246
return 1 0 250
assign 1 0 253
return 1 0 257
assign 1 0 260
return 1 0 264
assign 1 0 267
return 1 0 271
assign 1 0 274
return 1 0 278
assign 1 0 281
return 1 0 285
assign 1 0 288
return 1 0 292
assign 1 0 295
return 1 0 299
assign 1 0 302
return 1 0 306
assign 1 0 309
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case -214013804: return bem_checkTypesGet_0();
case -1682296012: return bem_numargsGet_0();
case 277290104: return bem_cposGet_0();
case -810118941: return bem_orgNameGet_0();
case -1751704975: return bem_many_0();
case -1613660155: return bem_serializationIteratorGet_0();
case 1375005996: return bem_wasBoundGet_0();
case -1610747658: return bem_nameGet_0();
case -457378134: return bem_sourceFileNameGet_0();
case -1493298790: return bem_isForwardGet_0();
case 1567284243: return bem_create_0();
case -1538220610: return bem_echo_0();
case 345309672: return bem_checkTypesTypeGet_0();
case 1535325056: return bem_wasImpliedConstructGet_0();
case 533615893: return bem_isConstructGet_0();
case -1657728137: return bem_isLiteralGet_0();
case 371037351: return bem_hashGet_0();
case 642325680: return bem_deserializeClassNameGet_0();
case -233198130: return bem_untypedGet_0();
case -1485568095: return bem_argCastsGet_0();
case 1277077124: return bem_once_0();
case 1818190775: return bem_toString_0();
case 308705107: return bem_serializeContents_0();
case 16424274: return bem_iteratorGet_0();
case 1985246514: return bem_classNameGet_0();
case -2020190277: return bem_isOnceGet_0();
case -1828840667: return bem_wasAccessorGet_0();
case -1181834336: return bem_serializeToString_0();
case -67432972: return bem_fieldIteratorGet_0();
case 44389954: return bem_wasForeachGennedGet_0();
case -1713134344: return bem_newNpGet_0();
case -146459624: return bem_tagGet_0();
case -129997796: return bem_literalValueGet_0();
case 1704272071: return bem_copy_0();
case -563585217: return bem_toAny_0();
case -275538617: return bem_toAccessorName_0();
case 796550275: return bem_superCallGet_0();
case -1936412867: return bem_isManyGet_0();
case 1190997837: return bem_print_0();
case -1780395885: return bem_accessorTypeGet_0();
case 1733221842: return bem_wasOperGet_0();
case 1133560869: return bem_new_0();
case -24017055: return bem_boundGet_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 2087476253: return bem_isConstructSet_1(bevd_0);
case 1024493267: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 752245311: return bem_wasAccessorSet_1(bevd_0);
case 519734904: return bem_orgNameSet_1(bevd_0);
case -891805962: return bem_literalValueSet_1(bevd_0);
case -948653107: return bem_wasOperSet_1(bevd_0);
case 1170591864: return bem_otherClass_1(bevd_0);
case -572577741: return bem_nameSet_1(bevd_0);
case -529160006: return bem_untypedSet_1(bevd_0);
case 2077566448: return bem_sameClass_1(bevd_0);
case 579081683: return bem_defined_1(bevd_0);
case -1829062470: return bem_superCallSet_1(bevd_0);
case -1028297264: return bem_isLiteralSet_1(bevd_0);
case -861078691: return bem_wasImpliedConstructSet_1(bevd_0);
case 1069670174: return bem_undef_1(bevd_0);
case -1312225281: return bem_argCastsSet_1(bevd_0);
case -1210345122: return bem_notEquals_1(bevd_0);
case 1398941771: return bem_def_1(bevd_0);
case -530068069: return bem_wasBoundSet_1(bevd_0);
case -1936197463: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1136956248: return bem_isOnceSet_1(bevd_0);
case 2101700701: return bem_undefined_1(bevd_0);
case -503068138: return bem_sameType_1(bevd_0);
case 198623882: return bem_checkTypesSet_1(bevd_0);
case 729409636: return bem_cposSet_1(bevd_0);
case 1933685650: return bem_equals_1(bevd_0);
case 1270721790: return bem_sameObject_1(bevd_0);
case -29502564: return bem_accessorTypeSet_1(bevd_0);
case -2108828466: return bem_boundSet_1(bevd_0);
case -1508704559: return bem_copyTo_1(bevd_0);
case -1682170766: return bem_otherType_1(bevd_0);
case 1781493251: return bem_isManySet_1(bevd_0);
case 1246738909: return bem_isForwardSet_1(bevd_0);
case -240186291: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -542202566: return bem_numargsSet_1(bevd_0);
case -122042490: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1697789053: return bem_checkTypesTypeSet_1(bevd_0);
case -1251308409: return bem_newNpSet_1(bevd_0);
case 646596873: return bem_wasForeachGennedSet_1(bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1408482482: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1097908484: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1722402091: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1055053136: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2112228411: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -483654719: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1372560242: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildCall_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildCall_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_BuildCall();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst = (BEC_2_5_4_BuildCall) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst;
}
}
}
