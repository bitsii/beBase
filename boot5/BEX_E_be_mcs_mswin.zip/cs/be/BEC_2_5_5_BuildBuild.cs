namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_12, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_60, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_63, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_68, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_71, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_105, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_106, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_107 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_107, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_108 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_108, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_109 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_109, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_110 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_110, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_111 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_111, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_112 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_113 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_114 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static new BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static new BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_singleCC = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_saveSyns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_saveIds = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 99 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 117 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 117 */
 else  /* Line: 117 */ {
break;
} /* Line: 117 */
} /* Line: 117 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bem_config_0();
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 127 */ {
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 130 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(-141904644);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 135 */
if (bevp_printSteps.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 137 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 137 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 138 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(476222825);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(544063329, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 144 */ {
} /* Line: 144 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_120_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_126_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_129_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpany_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_5_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_6_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 155 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 155 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1511439398);
bevt_9_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpany_phold);
} /* Line: 158 */
} /* Line: 156 */
 else  /* Line: 155 */ {
break;
} /* Line: 155 */
} /* Line: 155 */
} /* Line: 155 */
bevt_13_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_nameGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_equals_1(bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 164 */
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_15_tmpany_phold = bevp_params.bem_get_1(bevt_16_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_17_tmpany_phold = bevp_params.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_19_tmpany_phold = bevp_params.bem_get_1(bevt_20_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_firstGet_0();
} /* Line: 168 */
 else  /* Line: 169 */ {
bevp_exeName = bevp_libName;
} /* Line: 170 */
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_23_tmpany_phold = bevp_params.bem_get_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_firstGet_0();
bevt_21_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpany_phold);
bevp_buildPath = bevt_21_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_29_tmpany_phold = bevp_params.bem_get_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_firstGet_0();
bevt_27_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpany_phold);
bevp_includePath = bevt_27_tmpany_phold.bem_pathGet_0();
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_36_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_nameGet_0();
bevt_33_tmpany_phold = bevp_params.bem_get_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpany_phold );
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_40_tmpany_phold = bevp_platform.bemd_0(476222825);
bevt_38_tmpany_phold = bevp_params.bem_get_2(bevt_39_tmpany_phold, (BEC_2_4_6_TextString) bevt_40_tmpany_phold );
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpany_phold );
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_42_tmpany_phold = bevp_params.bem_get_2(bevt_43_tmpany_phold, bevt_44_tmpany_phold);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_26));
bevt_46_tmpany_phold = bevp_params.bem_get_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpany_phold);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_28));
bevt_50_tmpany_phold = bevp_params.bem_get_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_29));
bevp_loadSyns = bevp_params.bem_get_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_30));
bevp_initLibs = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_31));
bevt_55_tmpany_phold = bevp_params.bem_get_1(bevt_56_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_55_tmpany_phold.bem_firstGet_0();
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_32));
bevt_57_tmpany_phold = bevp_params.bem_get_1(bevt_58_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_57_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_59_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 188 */
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_61_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 192 */
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_63_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 196 */
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_65_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 200 */
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_67_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 203 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 204 */
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_69_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 208 */
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_71_tmpany_phold);
if (bevp_extLibs == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 212 */
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_73_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_74_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 216 */
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_75_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 220 */
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_77_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(601087743);
} /* Line: 224 */
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_79_tmpany_phold);
if (bevp_runArgs == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevp_runArgs = bevp_runArgs.bemd_0(601087743);
} /* Line: 228 */
 else  /* Line: 229 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 230 */
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_44));
bevt_82_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevt_84_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_86_tmpany_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_87_tmpany_phold);
if (bevl_pacm == null) {
bevt_88_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_90_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_90_tmpany_phold.bevi_bool) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
 else  /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 238 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 239 */ {
bevt_91_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_91_tmpany_phold).bevi_bool) /* Line: 239 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 240 */
 else  /* Line: 239 */ {
break;
} /* Line: 239 */
} /* Line: 239 */
} /* Line: 239 */
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_53));
bevt_97_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevp_emitLangs = bevp_params.bem_get_1(bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_55));
bevp_emitFlags = bevp_params.bem_get_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_100_tmpany_phold = bevp_params.bem_get_2(bevt_101_tmpany_phold, bevt_102_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_100_tmpany_phold.bem_firstGet_0();
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_59));
bevt_103_tmpany_phold = bevp_params.bem_get_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_103_tmpany_phold.bem_firstGet_0();
bevt_108_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bem_add_1(bevp_makeName);
bevt_109_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_106_tmpany_phold = bevp_params.bem_get_2(bevt_107_tmpany_phold, bevt_109_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_106_tmpany_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_110_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_110_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_110_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 261 */
 else  /* Line: 262 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_62));
} /* Line: 263 */
bevt_113_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_112_tmpany_phold = bevl_outLang.bem_add_1(bevt_113_tmpany_phold);
bevt_114_tmpany_phold = bevp_platform.bemd_0(476222825);
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bem_add_1(bevt_114_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_111_tmpany_phold);
if (bevl_platformSources == null) {
bevt_115_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_115_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 271 */ {
bevt_116_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_116_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 272 */
bevt_118_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_117_tmpany_phold = bevl_outLang.bem_add_1(bevt_118_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_117_tmpany_phold);
if (bevl_langSources == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_120_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_120_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 277 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_121_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpany_loop = bevt_121_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 281 */ {
bevt_122_tmpany_phold = bevt_2_tmpany_loop.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_122_tmpany_phold).bevi_bool) /* Line: 281 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(1511439398);
bevt_123_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_123_tmpany_phold);
} /* Line: 282 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(1821896017);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_126_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_125_tmpany_phold = bevt_126_tmpany_phold.bem_existsGet_0();
if (bevt_125_tmpany_phold.bevi_bool) {
bevt_124_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_124_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_124_tmpany_phold.bevi_bool) /* Line: 289 */ {
bevt_127_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_127_tmpany_phold.bem_makeDirs_0();
} /* Line: 290 */
if (bevp_emitFileHeader == null) {
bevt_128_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_128_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_128_tmpany_phold.bevi_bool) /* Line: 292 */ {
bevt_129_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_129_tmpany_phold.bem_readerGet_0();
bevt_130_tmpany_phold = bevl_emr.bemd_0(1754703175);
bevp_emitFileHeader = bevt_130_tmpany_phold.bemd_0(1196721294);
bevl_emr.bemd_0(1092690343);
} /* Line: 295 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(119931686, bevp_nl);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(119931686, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(119931686, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(119931686, bevp_nl);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(119931686, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(119931686, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 309 */ {
bevl_clnode = bevl_ci.bemd_0(1511439398);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(-1185997463);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(1169747010);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(-1185997463);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-901565279);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-141904644);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(-1185997463);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(-901565279);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(-141904644);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 315 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 315 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 316 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 315 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(-1185997463);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-901565279);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-141904644);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 321 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 322 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 320 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 327 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 327 */ {
bevl_clnode = bevl_ci.bemd_0(1511439398);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(-1185997463);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(-1185997463);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(-901565279);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(-141904644);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(-170668100, bevt_26_tmpany_phold);
} /* Line: 329 */
 else  /* Line: 327 */ {
break;
} /* Line: 327 */
} /* Line: 327 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 340 */ {
return bevp_emitCommon;
} /* Line: 341 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 349 */
 else  /* Line: 348 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 348 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 354 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 355 */
 else  /* Line: 356 */ {
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_70));
bevt_8_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpany_phold);
} /* Line: 357 */
} /* Line: 348 */
} /* Line: 348 */
return bevp_emitCommon;
} /* Line: 359 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = (BEC_2_4_8_TimeInterval) bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(1754703175);
bevt_5_tmpany_phold = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 383 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 383 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 384 */
 else  /* Line: 383 */ {
break;
} /* Line: 383 */
} /* Line: 383 */
} /* Line: 383 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 391 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 392 */
} /* Line: 391 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(1599241336);
while (true)
 /* Line: 397 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 397 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(1511439398);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 398 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 401 */
} /* Line: 398 */
 else  /* Line: 397 */ {
break;
} /* Line: 397 */
} /* Line: 397 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(1599241336);
while (true)
 /* Line: 404 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 404 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(1511439398);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(-1184059112);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 409 */
} /* Line: 405 */
 else  /* Line: 404 */ {
break;
} /* Line: 404 */
} /* Line: 404 */
if (bevp_parse.bevi_bool) /* Line: 412 */ {
bevl_built = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 415 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 415 */ {
bevl_tb = bevl_i.bemd_0(1511439398);
bevt_20_tmpany_phold = bevl_tb.bemd_0(-141904644);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 418 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(-141904644);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 420 */
} /* Line: 418 */
 else  /* Line: 415 */ {
break;
} /* Line: 415 */
} /* Line: 415 */
bem_buildSyns_1(bevl_em);
} /* Line: 423 */
bevt_23_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 429 */ {
bevt_26_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 438 */
if (bevp_doEmit.bevi_bool) /* Line: 440 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(923191542);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 444 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 444 */ {
bevl_clnode = bevl_ci.bemd_0(1511439398);
bevl_em.bemd_1(2076453482, bevl_clnode);
} /* Line: 446 */
 else  /* Line: 444 */ {
break;
} /* Line: 444 */
} /* Line: 444 */
bevl_em.bemd_0(-956760691);
bevl_em.bemd_0(1543353499);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 450 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 450 */ {
bevl_clnode = bevl_ci.bemd_0(1511439398);
bevl_em.bemd_1(-981662512, bevl_clnode);
} /* Line: 452 */
 else  /* Line: 450 */ {
break;
} /* Line: 450 */
} /* Line: 450 */
} /* Line: 450 */
bevt_44_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 458 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 461 */ {
bevl_em.bemd_1(-1959442452, bevp_deployLibrary);
} /* Line: 463 */
if (bevp_make.bevi_bool) /* Line: 466 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 467 */ {
bevl_em.bemd_1(-288601835, bevp_deployLibrary);
bevl_em.bemd_1(1728523889, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 470 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 471 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 471 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(923191542);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(1004369363);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(893733570);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(1903414097);
bevl_cpTo.bemd_1(1778892000, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(-1729605781);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(-1973960376);
if (((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 475 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(-1729605781);
bevt_58_tmpany_phold.bemd_0(-309127506);
} /* Line: 476 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(-1729605781);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(-1973960376);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(-432882034);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 478 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(-1729605781);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(-1729605781);
bevl_em.bemd_2(947849219, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 479 */
} /* Line: 478 */
 else  /* Line: 471 */ {
break;
} /* Line: 471 */
} /* Line: 471 */
} /* Line: 471 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 486 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 486 */
 else  /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 486 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(1511439398);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(1511439398);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(-1729605781);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(-1973960376);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 490 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(-1729605781);
bevt_76_tmpany_phold.bemd_0(-309127506);
} /* Line: 491 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(-1729605781);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(-1973960376);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(-432882034);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 493 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(-1729605781);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(-1729605781);
bevl_em.bemd_2(947849219, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 494 */
} /* Line: 493 */
 else  /* Line: 486 */ {
break;
} /* Line: 486 */
} /* Line: 486 */
} /* Line: 486 */
} /* Line: 467 */
bevt_83_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 501 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 502 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 504 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 505 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 507 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 508 */
if (bevp_run.bevi_bool) /* Line: 511 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(-1477890218, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 515 */
bevt_98_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 521 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 521 */ {
bevl_kls = bevl_ci.bemd_0(1511439398);
bevt_2_tmpany_phold = bevl_kls.bemd_0(-1185997463);
bevt_2_tmpany_phold.bemd_1(-47388554, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-47388554, bevp_libName);
} /* Line: 525 */
 else  /* Line: 521 */ {
break;
} /* Line: 521 */
} /* Line: 521 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 527 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 527 */ {
bevl_kls = bevl_ci.bemd_0(1511439398);
bevt_5_tmpany_phold = bevl_kls.bemd_0(-1185997463);
bevl_syn = bevt_5_tmpany_phold.bemd_0(1613473153);
bevl_syn.bemd_2(-763777524, this, bevl_kls);
bevl_syn.bemd_1(-2096191861, this);
} /* Line: 531 */
 else  /* Line: 527 */ {
break;
} /* Line: 527 */
} /* Line: 527 */
bevt_6_tmpany_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(-1185997463);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1613473153);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 537 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(-1185997463);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1613473153);
return bevt_3_tmpany_phold;
} /* Line: 538 */
bevt_5_tmpany_phold = beva_klass.bemd_0(-1185997463);
bevt_5_tmpany_phold.bemd_1(-47388554, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(-1185997463);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-139797473);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 541 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 542 */
 else  /* Line: 543 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(-1185997463);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-139797473);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-141904644);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 546 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(-1185997463);
bevt_14_tmpany_phold.bemd_1(-47388554, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 548 */
 else  /* Line: 549 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(-1185997463);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-139797473);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 552 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 554 */
bevt_17_tmpany_phold = beva_klass.bemd_0(-1185997463);
bevt_17_tmpany_phold.bemd_1(1074005869, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(-1185997463);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-901565279);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-141904644);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(-141904644);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 564 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 565 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(681664563, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 580 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 581 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 594 */ {
if (bevp_printSteps.bevi_bool) /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 595 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 595 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 595 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_5_tmpany_phold = beva_toParse.bemd_0(-141904644);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 596 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(-1729605781);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-1409549888);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(1754703175);
bevl_src = bevt_6_tmpany_phold.bemd_1(-1374971125, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(-1729605781);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-1409549888);
bevt_9_tmpany_phold.bemd_0(1092690343);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 605 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 606 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(-348646942);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 609 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_14_tmpany_phold);
} /* Line: 611 */
if (bevp_printSteps.bevi_bool) /* Line: 614 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 615 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-1532091612, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 618 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_18_tmpany_phold);
} /* Line: 620 */
if (bevp_printSteps.bevi_bool) /* Line: 622 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 623 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-1532091612, bevt_20_tmpany_phold);
bevl_trans.bemd_0(-341235511);
if (bevp_printAllAst.bevi_bool) /* Line: 628 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_22_tmpany_phold);
} /* Line: 630 */
if (bevp_printSteps.bevi_bool) /* Line: 633 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 634 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-1532091612, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 637 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_26_tmpany_phold);
} /* Line: 639 */
if (bevp_printSteps.bevi_bool) /* Line: 642 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 643 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-1532091612, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 646 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_30_tmpany_phold);
} /* Line: 648 */
if (bevp_printSteps.bevi_bool) /* Line: 651 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 652 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-1532091612, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 655 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_34_tmpany_phold);
} /* Line: 657 */
if (bevp_printSteps.bevi_bool) /* Line: 660 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 661 */
bevt_36_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-1532091612, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 664 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_38_tmpany_phold);
} /* Line: 666 */
if (bevp_printSteps.bevi_bool) /* Line: 669 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 670 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-1532091612, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 673 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_42_tmpany_phold);
} /* Line: 675 */
if (bevp_printSteps.bevi_bool) /* Line: 678 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 679 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-1532091612, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 682 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_46_tmpany_phold);
} /* Line: 684 */
if (bevp_printSteps.bevi_bool) /* Line: 687 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 688 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-1532091612, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 691 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_50_tmpany_phold);
} /* Line: 693 */
if (bevp_printSteps.bevi_bool) /* Line: 695 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 696 */
bevt_52_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-1532091612, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 699 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_54_tmpany_phold);
} /* Line: 701 */
if (bevp_printSteps.bevi_bool) /* Line: 704 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 706 */
bevt_57_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-1532091612, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 709 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 709 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 709 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 709 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 709 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 709 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1532091612, bevt_59_tmpany_phold);
} /* Line: 711 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 713 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(-1889333024);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 713 */ {
bevl_clnode = bevl_ci.bemd_0(1511439398);
bevl_tunode = bevl_clnode.bemd_0(58744473);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(247537592, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(-1185997463);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(439650997);
bevl_ntt.bemd_1(1552233138, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(45366945, bevl_ntt);
bevl_clnode.bemd_0(-309127506);
bevl_ntunode.bemd_1(-502514557, bevl_clnode);
bevl_ntunode.bemd_1(1811167911, bevl_clnode);
} /* Line: 724 */
 else  /* Line: 713 */ {
break;
} /* Line: 713 */
} /* Line: 713 */
} /* Line: 713 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(255894020);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(882717118);
bevl_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 734 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 734 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(45366945, bevt_2_tmpany_phold);
bevl_node.bemd_1(-1489921082, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(-1185997463);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(544063329, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 738 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 739 */
bevt_6_tmpany_phold = bevl_node.bemd_0(-1185997463);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(-1259048964, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 741 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(-738495515, beva_parnode);
} /* Line: 743 */
} /* Line: 741 */
 else  /* Line: 734 */ {
break;
} /* Line: 734 */
} /* Line: 734 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-441430973, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(247537592, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(45366945, bevl_nlnp);
bevl_nlnpn.bemd_1(1811167911, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_112));
bevl_nlc.bemd_1(-1244786367, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(593002763, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-226818644, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-628228719, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-771020745, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(-1185997463);
bevl_nlc.bemd_1(-220725237, bevt_11_tmpany_phold);
beva_node.bemd_1(-502514557, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(247537592, bevt_12_tmpany_phold);
beva_node.bemd_1(45366945, bevl_nlc);
bevl_nlnpn.bemd_0(1769164100);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_113));
bevt_13_tmpany_phold = beva_tName.bemd_1(544063329, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_114));
bevt_15_tmpany_phold = beva_tName.bemd_1(544063329, bevt_16_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevl_pn = beva_node.bemd_0(-889528684);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 775 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-733819428);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(544063329, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 775 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-733819428);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(544063329, bevt_23_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 775 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 775 */
 else  /* Line: 775 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 775 */ {
bevl_pn2 = bevl_pn.bemd_0(-889528684);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-733819428);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(-1259048964, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-733819428);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(-1259048964, bevt_30_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
 else  /* Line: 777 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-733819428);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(-1259048964, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
 else  /* Line: 777 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-733819428);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(-1259048964, bevt_36_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
 else  /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(-1185997463);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(-1573383487);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(119931686, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(-220725237, bevt_37_tmpany_phold);
bevl_pn.bemd_0(-309127506);
} /* Line: 784 */
} /* Line: 777 */
} /* Line: 775 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGetDirect_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGetDirect_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGetDirect_0() {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGetDirect_0() {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGetDirect_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGetDirect_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGetDirect_0() {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGetDirect_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGetDirect_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGetDirect_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGetDirect_0() {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGetDirect_0() {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGetDirect_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGetDirect_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGetDirect_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGetDirect_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGetDirect_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGetDirect_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGetDirect_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGetDirect_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {51, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 68, 70, 71, 72, 73, 73, 76, 79, 80, 81, 87, 88, 89, 90, 91, 91, 98, 98, 98, 98, 0, 98, 98, 0, 0, 0, 0, 0, 99, 99, 101, 101, 105, 105, 105, 105, 109, 109, 110, 110, 110, 114, 115, 116, 116, 116, 116, 116, 117, 117, 117, 118, 117, 120, 124, 125, 126, 128, 129, 130, 132, 133, 134, 134, 135, 0, 0, 0, 138, 140, 144, 144, 144, 146, 151, 153, 154, 154, 154, 155, 155, 0, 155, 155, 156, 156, 156, 157, 158, 158, 163, 163, 163, 163, 164, 166, 166, 166, 167, 167, 168, 168, 168, 170, 172, 172, 172, 172, 172, 172, 173, 174, 174, 175, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 182, 182, 184, 184, 184, 185, 185, 185, 186, 186, 187, 187, 188, 190, 190, 191, 191, 192, 194, 194, 195, 195, 196, 198, 198, 199, 199, 200, 202, 202, 203, 203, 204, 206, 206, 207, 207, 208, 210, 210, 211, 211, 212, 214, 214, 215, 215, 216, 218, 218, 219, 219, 220, 222, 222, 223, 223, 224, 226, 226, 227, 227, 228, 230, 232, 232, 232, 233, 233, 233, 234, 234, 235, 235, 236, 237, 237, 238, 238, 238, 238, 238, 0, 0, 0, 239, 0, 239, 239, 240, 243, 243, 244, 244, 245, 245, 246, 246, 247, 247, 247, 248, 248, 249, 249, 250, 250, 250, 250, 251, 251, 251, 251, 252, 252, 252, 252, 252, 253, 254, 255, 256, 257, 260, 260, 261, 263, 270, 270, 270, 270, 270, 271, 271, 272, 272, 275, 275, 275, 276, 276, 277, 277, 280, 281, 281, 0, 281, 281, 282, 282, 284, 285, 286, 288, 289, 289, 289, 289, 290, 290, 292, 292, 293, 293, 294, 294, 295, 301, 302, 302, 302, 302, 302, 303, 303, 303, 303, 303, 304, 308, 309, 309, 309, 310, 311, 311, 311, 311, 312, 312, 312, 312, 313, 313, 313, 313, 313, 314, 314, 315, 0, 315, 315, 316, 319, 319, 319, 319, 319, 320, 320, 321, 0, 321, 321, 322, 327, 327, 327, 328, 329, 329, 329, 329, 329, 329, 336, 336, 340, 340, 341, 346, 346, 347, 348, 348, 349, 350, 350, 351, 354, 354, 355, 357, 357, 357, 359, 361, 365, 367, 367, 367, 368, 368, 369, 369, 369, 370, 370, 371, 372, 372, 373, 373, 373, 374, 374, 374, 380, 380, 381, 382, 382, 383, 0, 383, 383, 384, 387, 388, 388, 389, 390, 392, 392, 392, 395, 397, 0, 397, 397, 398, 398, 398, 399, 400, 401, 404, 0, 404, 404, 405, 405, 405, 406, 407, 408, 409, 409, 414, 415, 415, 416, 418, 418, 419, 419, 420, 423, 426, 426, 426, 429, 429, 429, 431, 431, 432, 432, 433, 433, 433, 434, 434, 434, 435, 435, 435, 436, 436, 436, 437, 437, 437, 438, 438, 441, 442, 444, 444, 444, 445, 446, 448, 449, 450, 450, 450, 451, 452, 456, 456, 456, 457, 457, 458, 458, 458, 460, 460, 460, 463, 467, 467, 468, 469, 471, 0, 471, 471, 472, 472, 473, 473, 474, 474, 474, 475, 475, 476, 476, 478, 478, 478, 479, 479, 479, 483, 484, 486, 486, 0, 0, 0, 487, 487, 488, 488, 488, 488, 488, 488, 488, 488, 490, 490, 491, 491, 493, 493, 493, 494, 494, 494, 499, 499, 499, 501, 501, 502, 502, 502, 504, 504, 505, 505, 505, 507, 507, 508, 508, 508, 512, 512, 513, 514, 514, 514, 514, 514, 515, 517, 517, 521, 521, 521, 522, 523, 523, 524, 525, 527, 527, 527, 528, 529, 529, 530, 531, 533, 533, 537, 537, 537, 537, 538, 538, 538, 540, 540, 541, 541, 541, 541, 542, 544, 544, 544, 544, 544, 546, 546, 547, 547, 548, 552, 552, 552, 554, 556, 556, 557, 557, 557, 557, 558, 562, 563, 563, 564, 564, 565, 571, 571, 572, 573, 580, 580, 581, 583, 588, 589, 590, 591, 592, 593, 593, 0, 0, 0, 596, 596, 596, 596, 598, 600, 600, 600, 600, 601, 601, 601, 602, 606, 606, 608, 608, 610, 610, 611, 611, 615, 615, 617, 617, 619, 619, 620, 620, 623, 623, 626, 626, 627, 629, 629, 630, 630, 634, 634, 636, 636, 638, 638, 639, 639, 643, 643, 645, 645, 647, 647, 648, 648, 652, 652, 654, 654, 656, 656, 657, 657, 661, 661, 663, 663, 665, 665, 666, 666, 670, 670, 672, 672, 674, 674, 675, 675, 679, 679, 681, 681, 683, 683, 684, 684, 688, 688, 690, 690, 692, 692, 693, 693, 696, 696, 698, 698, 700, 700, 701, 701, 705, 705, 706, 706, 708, 708, 0, 0, 0, 710, 710, 711, 711, 713, 713, 713, 714, 716, 717, 718, 718, 719, 720, 720, 720, 721, 722, 723, 724, 730, 731, 732, 733, 733, 734, 734, 735, 736, 736, 737, 738, 738, 739, 741, 741, 742, 743, 750, 751, 753, 754, 754, 755, 756, 758, 759, 759, 760, 760, 761, 761, 762, 762, 763, 763, 764, 764, 766, 768, 768, 769, 771, 773, 773, 0, 773, 773, 0, 0, 774, 775, 775, 775, 775, 775, 0, 775, 775, 775, 0, 0, 0, 0, 0, 776, 777, 777, 0, 777, 777, 777, 777, 777, 777, 0, 0, 0, 777, 777, 777, 0, 0, 0, 777, 777, 777, 0, 0, 0, 0, 0, 783, 783, 783, 783, 784, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 293, 298, 299, 300, 302, 305, 306, 308, 311, 315, 318, 322, 325, 326, 328, 329, 335, 336, 337, 338, 345, 346, 347, 348, 349, 361, 362, 363, 364, 365, 366, 367, 368, 371, 376, 377, 378, 384, 392, 393, 394, 396, 397, 398, 402, 403, 404, 405, 406, 409, 413, 416, 420, 422, 428, 429, 430, 433, 576, 577, 578, 579, 584, 585, 586, 586, 589, 591, 592, 593, 598, 599, 600, 601, 609, 610, 611, 612, 614, 616, 617, 618, 619, 620, 622, 623, 624, 627, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 687, 688, 690, 691, 692, 697, 698, 700, 701, 702, 707, 708, 710, 711, 712, 717, 718, 720, 721, 722, 727, 728, 730, 731, 732, 737, 738, 740, 741, 742, 747, 748, 750, 751, 752, 757, 758, 760, 761, 762, 767, 768, 770, 771, 772, 777, 778, 780, 781, 782, 787, 788, 791, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 811, 812, 813, 818, 819, 822, 826, 829, 829, 832, 834, 835, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 880, 881, 884, 886, 887, 888, 889, 890, 891, 896, 897, 898, 900, 901, 902, 903, 908, 909, 910, 912, 913, 914, 914, 917, 919, 920, 921, 927, 928, 929, 930, 931, 932, 933, 938, 939, 940, 942, 947, 948, 949, 950, 951, 952, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 1017, 1018, 1019, 1022, 1024, 1025, 1026, 1027, 1028, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1044, 1045, 1045, 1048, 1050, 1051, 1058, 1059, 1060, 1061, 1062, 1063, 1068, 1069, 1069, 1072, 1074, 1075, 1088, 1089, 1092, 1094, 1095, 1096, 1097, 1098, 1099, 1100, 1110, 1111, 1125, 1130, 1131, 1133, 1138, 1139, 1140, 1141, 1143, 1146, 1147, 1149, 1152, 1153, 1155, 1158, 1159, 1160, 1164, 1166, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1325, 1326, 1327, 1328, 1333, 1334, 1334, 1337, 1339, 1340, 1347, 1348, 1353, 1354, 1355, 1357, 1358, 1359, 1362, 1363, 1363, 1366, 1368, 1369, 1370, 1375, 1376, 1377, 1378, 1385, 1385, 1388, 1390, 1391, 1392, 1397, 1398, 1399, 1400, 1401, 1402, 1410, 1411, 1414, 1416, 1417, 1418, 1420, 1421, 1422, 1429, 1431, 1432, 1433, 1434, 1435, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1461, 1464, 1465, 1466, 1467, 1470, 1472, 1473, 1479, 1480, 1481, 1482, 1485, 1487, 1488, 1495, 1496, 1497, 1498, 1503, 1504, 1505, 1506, 1508, 1509, 1510, 1512, 1515, 1520, 1521, 1522, 1524, 1524, 1527, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1540, 1541, 1543, 1544, 1545, 1547, 1548, 1549, 1557, 1558, 1561, 1563, 1565, 1568, 1572, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1586, 1588, 1589, 1591, 1592, 1593, 1595, 1596, 1597, 1606, 1607, 1608, 1609, 1614, 1615, 1616, 1617, 1619, 1624, 1625, 1626, 1627, 1629, 1634, 1635, 1636, 1637, 1640, 1641, 1642, 1643, 1644, 1645, 1646, 1647, 1648, 1650, 1651, 1664, 1665, 1668, 1670, 1671, 1672, 1673, 1674, 1680, 1681, 1684, 1686, 1687, 1688, 1689, 1690, 1696, 1697, 1725, 1726, 1727, 1732, 1733, 1734, 1735, 1737, 1738, 1739, 1740, 1741, 1746, 1747, 1750, 1751, 1752, 1753, 1754, 1755, 1760, 1761, 1762, 1763, 1766, 1767, 1768, 1770, 1772, 1773, 1774, 1775, 1776, 1777, 1778, 1786, 1787, 1788, 1789, 1794, 1795, 1797, 1798, 1799, 1800, 1804, 1809, 1810, 1812, 1891, 1892, 1893, 1894, 1895, 1896, 1897, 1900, 1904, 1907, 1911, 1912, 1913, 1914, 1916, 1917, 1918, 1919, 1920, 1921, 1922, 1923, 1924, 1926, 1927, 1929, 1930, 1932, 1933, 1934, 1935, 1938, 1939, 1941, 1942, 1944, 1945, 1946, 1947, 1950, 1951, 1953, 1954, 1955, 1957, 1958, 1959, 1960, 1963, 1964, 1966, 1967, 1969, 1970, 1971, 1972, 1975, 1976, 1978, 1979, 1981, 1982, 1983, 1984, 1987, 1988, 1990, 1991, 1993, 1994, 1995, 1996, 1999, 2000, 2002, 2003, 2005, 2006, 2007, 2008, 2011, 2012, 2014, 2015, 2017, 2018, 2019, 2020, 2023, 2024, 2026, 2027, 2029, 2030, 2031, 2032, 2035, 2036, 2038, 2039, 2041, 2042, 2043, 2044, 2047, 2048, 2050, 2051, 2053, 2054, 2055, 2056, 2059, 2060, 2061, 2062, 2064, 2065, 2067, 2071, 2074, 2078, 2079, 2080, 2081, 2083, 2084, 2087, 2089, 2090, 2091, 2092, 2093, 2094, 2095, 2096, 2097, 2098, 2099, 2100, 2101, 2123, 2124, 2125, 2126, 2127, 2128, 2131, 2133, 2134, 2135, 2136, 2137, 2138, 2140, 2142, 2143, 2145, 2146, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2227, 2229, 2232, 2233, 2235, 2238, 2242, 2243, 2248, 2249, 2250, 2251, 2253, 2256, 2257, 2258, 2260, 2263, 2267, 2270, 2274, 2277, 2278, 2283, 2284, 2287, 2288, 2289, 2291, 2292, 2293, 2295, 2298, 2302, 2305, 2306, 2307, 2309, 2312, 2316, 2319, 2320, 2321, 2323, 2326, 2330, 2333, 2336, 2340, 2341, 2342, 2343, 2344, 2351, 2354, 2357, 2361, 2365, 2368, 2371, 2375, 2379, 2382, 2385, 2389, 2393, 2396, 2399, 2403, 2407, 2410, 2413, 2417, 2421, 2424, 2427, 2431, 2435, 2438, 2441, 2445, 2449, 2452, 2455, 2459, 2463, 2466, 2469, 2473, 2477, 2480, 2483, 2487, 2491, 2494, 2497, 2501, 2505, 2508, 2511, 2515, 2519, 2522, 2525, 2529, 2533, 2536, 2539, 2543, 2547, 2550, 2553, 2557, 2561, 2564, 2567, 2571, 2575, 2578, 2581, 2585, 2589, 2592, 2595, 2599, 2603, 2606, 2609, 2613, 2617, 2620, 2623, 2627, 2631, 2634, 2637, 2641, 2645, 2648, 2651, 2655, 2659, 2662, 2665, 2669, 2673, 2676, 2679, 2683, 2687, 2690, 2693, 2697, 2701, 2704, 2707, 2711, 2715, 2718, 2721, 2725, 2729, 2732, 2735, 2739, 2743, 2746, 2749, 2753, 2757, 2760, 2763, 2767, 2771, 2774, 2777, 2781, 2785, 2788, 2791, 2795, 2799, 2802, 2805, 2809, 2813, 2816, 2819, 2823, 2827, 2830, 2833, 2837, 2841, 2844, 2847, 2851, 2855, 2858, 2861, 2865, 2869, 2872, 2875, 2879, 2883, 2886, 2889, 2893, 2897, 2900, 2903, 2907, 2911, 2914, 2917, 2921, 2925, 2928, 2931, 2935, 2939, 2942, 2945, 2949, 2953, 2956, 2959, 2963, 2967, 2970, 2973, 2977, 2981, 2984, 2987, 2991, 2995, 2998, 3001, 3005, 3009, 3012, 3015, 3019, 3023, 3026, 3029, 3033, 3037, 3040, 3043, 3047, 3051, 3054, 3057, 3061, 3065, 3068, 3071, 3075, 3079, 3082, 3085, 3089, 3093, 3096, 3099, 3103, 3107, 3110, 3113, 3117, 3121, 3124, 3127, 3131, 3135, 3138, 3141, 3145, 3149, 3152, 3155, 3159, 3163, 3166, 3169, 3173, 3177, 3180, 3183, 3187, 3191, 3194, 3197, 3201, 3205, 3208, 3211, 3215, 3219, 3222, 3225, 3229, 3233, 3236, 3239, 3243, 3247, 3250, 3253, 3257, 3261, 3264, 3267, 3271, 3275, 3278, 3281, 3285, 3289, 3292, 3295, 3299, 3303, 3306, 3309, 3313, 3317, 3320, 3323, 3327, 3331, 3334, 3337, 3341, 3345, 3348, 3351, 3355, 3359, 3362, 3366};
/* BEGIN LINEINFO 
assign 1 51 254
new 0 51 254
assign 1 53 255
new 0 53 255
assign 1 54 256
new 0 54 256
assign 1 55 257
new 0 55 257
assign 1 56 258
new 0 56 258
assign 1 58 259
new 0 58 259
assign 1 59 260
new 0 59 260
assign 1 60 261
new 0 60 261
assign 1 61 262
new 0 61 262
assign 1 62 263
new 0 62 263
assign 1 63 264
new 0 63 264
assign 1 64 265
new 0 64 265
assign 1 68 266
new 0 68 266
assign 1 70 267
new 1 70 267
assign 1 71 268
ntypesGet 0 71 268
assign 1 72 269
twtokGet 0 72 269
assign 1 73 270
new 0 73 270
assign 1 73 271
new 1 73 271
assign 1 76 272
new 0 76 272
assign 1 79 273
new 0 79 273
assign 1 80 274
new 0 80 274
assign 1 81 275
new 0 81 275
assign 1 87 276
new 0 87 276
assign 1 88 277
new 0 88 277
assign 1 89 278
new 0 89 278
assign 1 90 279
new 0 90 279
assign 1 91 280
new 0 91 280
assign 1 91 281
new 1 91 281
assign 1 98 293
def 1 98 298
assign 1 98 299
new 0 98 299
assign 1 98 300
equals 1 98 300
assign 1 0 302
assign 1 98 305
new 0 98 305
assign 1 98 306
ends 1 98 306
assign 1 0 308
assign 1 0 311
assign 1 0 315
assign 1 0 318
assign 1 0 322
assign 1 99 325
new 0 99 325
return 1 99 326
assign 1 101 328
new 0 101 328
return 1 101 329
assign 1 105 335
new 0 105 335
assign 1 105 336
new 0 105 336
assign 1 105 337
swap 2 105 337
return 1 105 338
assign 1 109 345
new 0 109 345
assign 1 109 346
argsGet 0 109 346
assign 1 110 347
new 0 110 347
assign 1 110 348
main 1 110 348
exit 1 110 349
assign 1 114 361
assign 1 115 362
new 1 115 362
assign 1 116 363
new 0 116 363
assign 1 116 364
new 0 116 364
assign 1 116 365
get 2 116 365
assign 1 116 366
firstGet 0 116 366
assign 1 116 367
new 1 116 367
assign 1 117 368
new 0 117 368
assign 1 117 371
lesser 1 117 376
assign 1 118 377
go 0 118 377
incrementValue 0 117 378
return 1 120 384
assign 1 124 392
new 0 124 392
config 0 125 393
assign 1 126 394
new 0 126 394
assign 1 128 396
new 0 128 396
assign 1 129 397
doWhat 0 129 397
assign 1 130 398
new 0 130 398
assign 1 132 402
toString 0 132 402
assign 1 133 403
new 0 133 403
assign 1 134 404
new 0 134 404
assign 1 134 405
add 1 134 405
assign 1 135 406
new 0 135 406
assign 1 0 409
assign 1 0 413
assign 1 0 416
print 0 138 420
return 1 140 422
assign 1 144 428
nameGet 0 144 428
assign 1 144 429
new 0 144 429
assign 1 144 430
equals 1 144 430
return 1 146 433
assign 1 151 576
new 0 151 576
assign 1 153 577
new 0 153 577
assign 1 154 578
get 1 154 578
assign 1 154 579
def 1 154 584
assign 1 155 585
get 1 155 585
assign 1 155 586
iteratorGet 0 0 586
assign 1 155 589
hasNextGet 0 155 589
assign 1 155 591
nextGet 0 155 591
assign 1 156 592
has 1 156 592
assign 1 156 593
not 0 156 598
put 1 157 599
assign 1 158 600
new 1 158 600
addFile 1 158 601
assign 1 163 609
new 0 163 609
assign 1 163 610
nameGet 0 163 610
assign 1 163 611
new 0 163 611
assign 1 163 612
equals 1 163 612
preProcessorSet 1 164 614
assign 1 166 616
new 0 166 616
assign 1 166 617
get 1 166 617
assign 1 166 618
firstGet 0 166 618
assign 1 167 619
new 0 167 619
assign 1 167 620
has 1 167 620
assign 1 168 622
new 0 168 622
assign 1 168 623
get 1 168 623
assign 1 168 624
firstGet 0 168 624
assign 1 170 627
assign 1 172 629
new 0 172 629
assign 1 172 630
new 0 172 630
assign 1 172 631
get 2 172 631
assign 1 172 632
firstGet 0 172 632
assign 1 172 633
new 1 172 633
assign 1 172 634
pathGet 0 172 634
addStep 1 173 635
assign 1 174 636
new 0 174 636
addStep 1 174 637
assign 1 175 638
new 0 175 638
assign 1 175 639
new 0 175 639
assign 1 175 640
get 2 175 640
assign 1 175 641
firstGet 0 175 641
assign 1 175 642
new 1 175 642
assign 1 175 643
pathGet 0 175 643
assign 1 176 644
new 0 176 644
assign 1 176 645
new 0 176 645
assign 1 176 646
nameGet 0 176 646
assign 1 176 647
get 2 176 647
assign 1 176 648
firstGet 0 176 648
assign 1 176 649
new 1 176 649
assign 1 177 650
new 0 177 650
assign 1 177 651
nameGet 0 177 651
assign 1 177 652
get 2 177 652
assign 1 177 653
firstGet 0 177 653
assign 1 177 654
new 1 177 654
assign 1 178 655
new 0 178 655
assign 1 178 656
new 0 178 656
assign 1 178 657
get 2 178 657
assign 1 178 658
firstGet 0 178 658
assign 1 178 659
new 1 178 659
assign 1 179 660
new 0 179 660
assign 1 179 661
new 0 179 661
assign 1 179 662
get 2 179 662
assign 1 179 663
firstGet 0 179 663
assign 1 179 664
new 1 179 664
assign 1 180 665
new 0 180 665
assign 1 180 666
new 0 180 666
assign 1 180 667
get 2 180 667
assign 1 180 668
firstGet 0 180 668
assign 1 180 669
new 1 180 669
assign 1 181 670
new 0 181 670
assign 1 181 671
get 1 181 671
assign 1 182 672
new 0 182 672
assign 1 182 673
get 1 182 673
assign 1 184 674
new 0 184 674
assign 1 184 675
get 1 184 675
assign 1 184 676
firstGet 0 184 676
assign 1 185 677
new 0 185 677
assign 1 185 678
get 1 185 678
assign 1 185 679
firstGet 0 185 679
assign 1 186 680
new 0 186 680
assign 1 186 681
get 1 186 681
assign 1 187 682
undef 1 187 687
assign 1 188 688
new 0 188 688
assign 1 190 690
new 0 190 690
assign 1 190 691
get 1 190 691
assign 1 191 692
undef 1 191 697
assign 1 192 698
new 0 192 698
assign 1 194 700
new 0 194 700
assign 1 194 701
get 1 194 701
assign 1 195 702
undef 1 195 707
assign 1 196 708
new 0 196 708
assign 1 198 710
new 0 198 710
assign 1 198 711
get 1 198 711
assign 1 199 712
undef 1 199 717
assign 1 200 718
new 0 200 718
assign 1 202 720
new 0 202 720
assign 1 202 721
get 1 202 721
assign 1 203 722
undef 1 203 727
assign 1 204 728
new 0 204 728
assign 1 206 730
new 0 206 730
assign 1 206 731
get 1 206 731
assign 1 207 732
undef 1 207 737
assign 1 208 738
new 0 208 738
assign 1 210 740
new 0 210 740
assign 1 210 741
get 1 210 741
assign 1 211 742
undef 1 211 747
assign 1 212 748
new 0 212 748
assign 1 214 750
new 0 214 750
assign 1 214 751
get 1 214 751
assign 1 215 752
undef 1 215 757
assign 1 216 758
new 0 216 758
assign 1 218 760
new 0 218 760
assign 1 218 761
get 1 218 761
assign 1 219 762
undef 1 219 767
assign 1 220 768
new 0 220 768
assign 1 222 770
new 0 222 770
assign 1 222 771
get 1 222 771
assign 1 223 772
def 1 223 777
assign 1 224 778
firstGet 0 224 778
assign 1 226 780
new 0 226 780
assign 1 226 781
get 1 226 781
assign 1 227 782
def 1 227 787
assign 1 228 788
firstGet 0 228 788
assign 1 230 791
new 0 230 791
assign 1 232 793
new 0 232 793
assign 1 232 794
new 0 232 794
assign 1 232 795
isTrue 2 232 795
assign 1 233 796
new 0 233 796
assign 1 233 797
new 0 233 797
assign 1 233 798
isTrue 2 233 798
assign 1 234 799
new 0 234 799
assign 1 234 800
isTrue 1 234 800
assign 1 235 801
new 0 235 801
assign 1 235 802
isTrue 1 235 802
assign 1 236 803
new 0 236 803
assign 1 237 804
new 0 237 804
assign 1 237 805
get 1 237 805
assign 1 238 806
def 1 238 811
assign 1 238 812
isEmptyGet 0 238 812
assign 1 238 813
not 0 238 818
assign 1 0 819
assign 1 0 822
assign 1 0 826
assign 1 239 829
linkedListIteratorGet 0 0 829
assign 1 239 832
hasNextGet 0 239 832
assign 1 239 834
nextGet 0 239 834
put 1 240 835
assign 1 243 842
new 0 243 842
assign 1 243 843
isTrue 1 243 843
assign 1 244 844
new 0 244 844
assign 1 244 845
isTrue 1 244 845
assign 1 245 846
new 0 245 846
assign 1 245 847
isTrue 1 245 847
assign 1 246 848
new 0 246 848
assign 1 246 849
isTrue 1 246 849
assign 1 247 850
new 0 247 850
assign 1 247 851
new 0 247 851
assign 1 247 852
isTrue 2 247 852
assign 1 248 853
new 0 248 853
assign 1 248 854
get 1 248 854
assign 1 249 855
new 0 249 855
assign 1 249 856
get 1 249 856
assign 1 250 857
new 0 250 857
assign 1 250 858
new 0 250 858
assign 1 250 859
get 2 250 859
assign 1 250 860
firstGet 0 250 860
assign 1 251 861
new 0 251 861
assign 1 251 862
new 0 251 862
assign 1 251 863
get 2 251 863
assign 1 251 864
firstGet 0 251 864
assign 1 252 865
new 0 252 865
assign 1 252 866
add 1 252 866
assign 1 252 867
new 0 252 867
assign 1 252 868
get 2 252 868
assign 1 252 869
firstGet 0 252 869
assign 1 253 870
new 0 253 870
assign 1 254 871
new 0 254 871
assign 1 255 872
new 0 255 872
assign 1 256 873
new 0 256 873
assign 1 257 874
new 0 257 874
assign 1 260 875
def 1 260 880
assign 1 261 881
firstGet 0 261 881
assign 1 263 884
new 0 263 884
assign 1 270 886
new 0 270 886
assign 1 270 887
add 1 270 887
assign 1 270 888
nameGet 0 270 888
assign 1 270 889
add 1 270 889
assign 1 270 890
get 1 270 890
assign 1 271 891
def 1 271 896
assign 1 272 897
orderedGet 0 272 897
addAll 1 272 898
assign 1 275 900
new 0 275 900
assign 1 275 901
add 1 275 901
assign 1 275 902
get 1 275 902
assign 1 276 903
def 1 276 908
assign 1 277 909
orderedGet 0 277 909
addAll 1 277 910
assign 1 280 912
new 0 280 912
assign 1 281 913
orderedGet 0 281 913
assign 1 281 914
iteratorGet 0 0 914
assign 1 281 917
hasNextGet 0 281 917
assign 1 281 919
nextGet 0 281 919
assign 1 282 920
new 1 282 920
addValue 1 282 921
assign 1 284 927
newlineGet 0 284 927
assign 1 285 928
assign 1 286 929
new 1 286 929
assign 1 288 930
copy 0 288 930
assign 1 289 931
fileGet 0 289 931
assign 1 289 932
existsGet 0 289 932
assign 1 289 933
not 0 289 938
assign 1 290 939
fileGet 0 290 939
makeDirs 0 290 940
assign 1 292 942
def 1 292 947
assign 1 293 948
new 1 293 948
assign 1 293 949
readerGet 0 293 949
assign 1 294 950
open 0 294 950
assign 1 294 951
readString 0 294 951
close 0 295 952
assign 1 301 966
classNameGet 0 301 966
assign 1 302 967
add 1 302 967
assign 1 302 968
new 0 302 968
assign 1 302 969
add 1 302 969
assign 1 302 970
toString 0 302 970
assign 1 302 971
add 1 302 971
assign 1 303 972
add 1 303 972
assign 1 303 973
new 0 303 973
assign 1 303 974
add 1 303 974
assign 1 303 975
toString 0 303 975
assign 1 303 976
add 1 303 976
return 1 304 977
assign 1 308 1017
new 0 308 1017
assign 1 309 1018
classesGet 0 309 1018
assign 1 309 1019
valueIteratorGet 0 309 1019
assign 1 309 1022
hasNextGet 0 309 1022
assign 1 310 1024
nextGet 0 310 1024
assign 1 311 1025
shouldEmitGet 0 311 1025
assign 1 311 1026
heldGet 0 311 1026
assign 1 311 1027
fromFileGet 0 311 1027
assign 1 311 1028
has 1 311 1028
assign 1 312 1030
heldGet 0 312 1030
assign 1 312 1031
namepathGet 0 312 1031
assign 1 312 1032
toString 0 312 1032
put 1 312 1033
assign 1 313 1034
usedByGet 0 313 1034
assign 1 313 1035
heldGet 0 313 1035
assign 1 313 1036
namepathGet 0 313 1036
assign 1 313 1037
toString 0 313 1037
assign 1 313 1038
get 1 313 1038
assign 1 314 1039
def 1 314 1044
assign 1 315 1045
setIteratorGet 0 0 1045
assign 1 315 1048
hasNextGet 0 315 1048
assign 1 315 1050
nextGet 0 315 1050
put 1 316 1051
assign 1 319 1058
subClassesGet 0 319 1058
assign 1 319 1059
heldGet 0 319 1059
assign 1 319 1060
namepathGet 0 319 1060
assign 1 319 1061
toString 0 319 1061
assign 1 319 1062
get 1 319 1062
assign 1 320 1063
def 1 320 1068
assign 1 321 1069
setIteratorGet 0 0 1069
assign 1 321 1072
hasNextGet 0 321 1072
assign 1 321 1074
nextGet 0 321 1074
put 1 322 1075
assign 1 327 1088
classesGet 0 327 1088
assign 1 327 1089
valueIteratorGet 0 327 1089
assign 1 327 1092
hasNextGet 0 327 1092
assign 1 328 1094
nextGet 0 328 1094
assign 1 329 1095
heldGet 0 329 1095
assign 1 329 1096
heldGet 0 329 1096
assign 1 329 1097
namepathGet 0 329 1097
assign 1 329 1098
toString 0 329 1098
assign 1 329 1099
has 1 329 1099
shouldWriteSet 1 329 1100
assign 1 336 1110
new 0 336 1110
return 1 336 1111
assign 1 340 1125
def 1 340 1130
return 1 341 1131
assign 1 346 1133
def 1 346 1138
assign 1 347 1139
firstGet 0 347 1139
assign 1 348 1140
new 0 348 1140
assign 1 348 1141
equals 1 348 1141
assign 1 349 1143
new 1 349 1143
assign 1 350 1146
new 0 350 1146
assign 1 350 1147
equals 1 350 1147
assign 1 351 1149
new 1 351 1149
assign 1 354 1152
new 0 354 1152
assign 1 354 1153
equals 1 354 1153
assign 1 355 1155
new 1 355 1155
assign 1 357 1158
new 0 357 1158
assign 1 357 1159
new 1 357 1159
throw 1 357 1160
return 1 359 1164
return 1 361 1166
assign 1 365 1185
apNew 1 365 1185
assign 1 367 1186
new 0 367 1186
assign 1 367 1187
add 1 367 1187
print 0 367 1188
assign 1 368 1189
new 0 368 1189
assign 1 368 1190
now 0 368 1190
assign 1 369 1191
fileGet 0 369 1191
assign 1 369 1192
readerGet 0 369 1192
assign 1 369 1193
open 0 369 1193
assign 1 370 1194
new 0 370 1194
assign 1 370 1195
deserialize 1 370 1195
close 0 371 1196
assign 1 372 1197
synClassesGet 0 372 1197
addValue 1 372 1198
assign 1 373 1199
new 0 373 1199
assign 1 373 1200
now 0 373 1200
assign 1 373 1201
subtract 1 373 1201
assign 1 374 1202
new 0 374 1202
assign 1 374 1203
add 1 374 1203
print 0 374 1204
assign 1 380 1325
new 0 380 1325
assign 1 380 1326
now 0 380 1326
assign 1 381 1327
new 0 381 1327
assign 1 382 1328
def 1 382 1333
assign 1 383 1334
linkedListIteratorGet 0 0 1334
assign 1 383 1337
hasNextGet 0 383 1337
assign 1 383 1339
nextGet 0 383 1339
loadSyns 1 384 1340
assign 1 387 1347
emitterGet 0 387 1347
assign 1 388 1348
def 1 388 1353
assign 1 389 1354
new 4 389 1354
put 1 390 1355
assign 1 392 1357
new 0 392 1357
assign 1 392 1358
add 1 392 1358
print 0 392 1359
assign 1 395 1362
new 0 395 1362
assign 1 397 1363
iteratorGet 0 0 1363
assign 1 397 1366
hasNextGet 0 397 1366
assign 1 397 1368
nextGet 0 397 1368
assign 1 398 1369
has 1 398 1369
assign 1 398 1370
not 0 398 1375
put 1 399 1376
assign 1 400 1377
new 2 400 1377
addValue 1 401 1378
assign 1 404 1385
iteratorGet 0 0 1385
assign 1 404 1388
hasNextGet 0 404 1388
assign 1 404 1390
nextGet 0 404 1390
assign 1 405 1391
has 1 405 1391
assign 1 405 1392
not 0 405 1397
put 1 406 1398
assign 1 407 1399
new 2 407 1399
addValue 1 408 1400
assign 1 409 1401
libNameGet 0 409 1401
put 1 409 1402
assign 1 414 1410
new 0 414 1410
assign 1 415 1411
iteratorGet 0 415 1411
assign 1 415 1414
hasNextGet 0 415 1414
assign 1 416 1416
nextGet 0 416 1416
assign 1 418 1417
toString 0 418 1417
assign 1 418 1418
has 1 418 1418
assign 1 419 1420
toString 0 419 1420
put 1 419 1421
doParse 1 420 1422
buildSyns 1 423 1429
assign 1 426 1431
new 0 426 1431
assign 1 426 1432
now 0 426 1432
assign 1 426 1433
subtract 1 426 1433
assign 1 429 1434
emitCommonGet 0 429 1434
assign 1 429 1435
def 1 429 1440
assign 1 431 1441
new 0 431 1441
assign 1 431 1442
now 0 431 1442
assign 1 432 1443
emitCommonGet 0 432 1443
doEmit 0 432 1444
assign 1 433 1445
new 0 433 1445
assign 1 433 1446
now 0 433 1446
assign 1 433 1447
subtract 1 433 1447
assign 1 434 1448
new 0 434 1448
assign 1 434 1449
now 0 434 1449
assign 1 434 1450
subtract 1 434 1450
assign 1 435 1451
new 0 435 1451
assign 1 435 1452
add 1 435 1452
print 0 435 1453
assign 1 436 1454
new 0 436 1454
assign 1 436 1455
add 1 436 1455
print 0 436 1456
assign 1 437 1457
new 0 437 1457
assign 1 437 1458
add 1 437 1458
print 0 437 1459
assign 1 438 1460
new 0 438 1460
return 1 438 1461
setClassesToWrite 0 441 1464
libnameInfoGet 0 442 1465
assign 1 444 1466
classesGet 0 444 1466
assign 1 444 1467
valueIteratorGet 0 444 1467
assign 1 444 1470
hasNextGet 0 444 1470
assign 1 445 1472
nextGet 0 445 1472
doEmit 1 446 1473
emitMain 0 448 1479
emitCUInit 0 449 1480
assign 1 450 1481
classesGet 0 450 1481
assign 1 450 1482
valueIteratorGet 0 450 1482
assign 1 450 1485
hasNextGet 0 450 1485
assign 1 451 1487
nextGet 0 451 1487
emitSyn 1 452 1488
assign 1 456 1495
new 0 456 1495
assign 1 456 1496
now 0 456 1496
assign 1 456 1497
subtract 1 456 1497
assign 1 457 1498
def 1 457 1503
assign 1 458 1504
new 0 458 1504
assign 1 458 1505
add 1 458 1505
print 0 458 1506
assign 1 460 1508
new 0 460 1508
assign 1 460 1509
add 1 460 1509
print 0 460 1510
prepMake 1 463 1512
assign 1 467 1515
not 0 467 1520
make 1 468 1521
deployLibrary 1 469 1522
assign 1 471 1524
linkedListIteratorGet 0 0 1524
assign 1 471 1527
hasNextGet 0 471 1527
assign 1 471 1529
nextGet 0 471 1529
assign 1 472 1530
libnameInfoGet 0 472 1530
assign 1 472 1531
unitShlibGet 0 472 1531
assign 1 473 1532
emitPathGet 0 473 1532
assign 1 473 1533
copy 0 473 1533
assign 1 474 1534
stepsGet 0 474 1534
assign 1 474 1535
lastGet 0 474 1535
addStep 1 474 1536
assign 1 475 1537
fileGet 0 475 1537
assign 1 475 1538
existsGet 0 475 1538
assign 1 476 1540
fileGet 0 476 1540
delete 0 476 1541
assign 1 478 1543
fileGet 0 478 1543
assign 1 478 1544
existsGet 0 478 1544
assign 1 478 1545
not 0 478 1545
assign 1 479 1547
fileGet 0 479 1547
assign 1 479 1548
fileGet 0 479 1548
deployFile 2 479 1549
assign 1 483 1557
iteratorGet 0 483 1557
assign 1 484 1558
iteratorGet 0 484 1558
assign 1 486 1561
hasNextGet 0 486 1561
assign 1 486 1563
hasNextGet 0 486 1563
assign 1 0 1565
assign 1 0 1568
assign 1 0 1572
assign 1 487 1575
nextGet 0 487 1575
assign 1 487 1576
apNew 1 487 1576
assign 1 488 1577
emitPathGet 0 488 1577
assign 1 488 1578
copy 0 488 1578
assign 1 488 1579
toString 0 488 1579
assign 1 488 1580
new 0 488 1580
assign 1 488 1581
add 1 488 1581
assign 1 488 1582
nextGet 0 488 1582
assign 1 488 1583
add 1 488 1583
assign 1 488 1584
apNew 1 488 1584
assign 1 490 1585
fileGet 0 490 1585
assign 1 490 1586
existsGet 0 490 1586
assign 1 491 1588
fileGet 0 491 1588
delete 0 491 1589
assign 1 493 1591
fileGet 0 493 1591
assign 1 493 1592
existsGet 0 493 1592
assign 1 493 1593
not 0 493 1593
assign 1 494 1595
fileGet 0 494 1595
assign 1 494 1596
fileGet 0 494 1596
deployFile 2 494 1597
assign 1 499 1606
new 0 499 1606
assign 1 499 1607
now 0 499 1607
assign 1 499 1608
subtract 1 499 1608
assign 1 501 1609
def 1 501 1614
assign 1 502 1615
new 0 502 1615
assign 1 502 1616
add 1 502 1616
print 0 502 1617
assign 1 504 1619
def 1 504 1624
assign 1 505 1625
new 0 505 1625
assign 1 505 1626
add 1 505 1626
print 0 505 1627
assign 1 507 1629
def 1 507 1634
assign 1 508 1635
new 0 508 1635
assign 1 508 1636
add 1 508 1636
print 0 508 1637
assign 1 512 1640
new 0 512 1640
print 0 512 1641
assign 1 513 1642
run 2 513 1642
assign 1 514 1643
new 0 514 1643
assign 1 514 1644
add 1 514 1644
assign 1 514 1645
new 0 514 1645
assign 1 514 1646
add 1 514 1646
print 0 514 1647
return 1 515 1648
assign 1 517 1650
new 0 517 1650
return 1 517 1651
assign 1 521 1664
justParsedGet 0 521 1664
assign 1 521 1665
valueIteratorGet 0 521 1665
assign 1 521 1668
hasNextGet 0 521 1668
assign 1 522 1670
nextGet 0 522 1670
assign 1 523 1671
heldGet 0 523 1671
libNameSet 1 523 1672
assign 1 524 1673
getSyn 2 524 1673
libNameSet 1 525 1674
assign 1 527 1680
justParsedGet 0 527 1680
assign 1 527 1681
valueIteratorGet 0 527 1681
assign 1 527 1684
hasNextGet 0 527 1684
assign 1 528 1686
nextGet 0 528 1686
assign 1 529 1687
heldGet 0 529 1687
assign 1 529 1688
synGet 0 529 1688
checkInheritance 2 530 1689
integrate 1 531 1690
assign 1 533 1696
new 0 533 1696
justParsedSet 1 533 1697
assign 1 537 1725
heldGet 0 537 1725
assign 1 537 1726
synGet 0 537 1726
assign 1 537 1727
def 1 537 1732
assign 1 538 1733
heldGet 0 538 1733
assign 1 538 1734
synGet 0 538 1734
return 1 538 1735
assign 1 540 1737
heldGet 0 540 1737
libNameSet 1 540 1738
assign 1 541 1739
heldGet 0 541 1739
assign 1 541 1740
extendsGet 0 541 1740
assign 1 541 1741
undef 1 541 1746
assign 1 542 1747
new 1 542 1747
assign 1 544 1750
classesGet 0 544 1750
assign 1 544 1751
heldGet 0 544 1751
assign 1 544 1752
extendsGet 0 544 1752
assign 1 544 1753
toString 0 544 1753
assign 1 544 1754
get 1 544 1754
assign 1 546 1755
def 1 546 1760
assign 1 547 1761
heldGet 0 547 1761
libNameSet 1 547 1762
assign 1 548 1763
getSyn 2 548 1763
assign 1 552 1766
heldGet 0 552 1766
assign 1 552 1767
extendsGet 0 552 1767
assign 1 552 1768
getSynNp 1 552 1768
assign 1 554 1770
new 2 554 1770
assign 1 556 1772
heldGet 0 556 1772
synSet 1 556 1773
assign 1 557 1774
heldGet 0 557 1774
assign 1 557 1775
namepathGet 0 557 1775
assign 1 557 1776
toString 0 557 1776
addSynClass 2 557 1777
return 1 558 1778
assign 1 562 1786
toString 0 562 1786
assign 1 563 1787
synClassesGet 0 563 1787
assign 1 563 1788
get 1 563 1788
assign 1 564 1789
def 1 564 1794
return 1 565 1795
assign 1 571 1797
emitterGet 0 571 1797
assign 1 571 1798
loadSyn 1 571 1798
addSynClass 2 572 1799
return 1 573 1800
assign 1 580 1804
undef 1 580 1809
assign 1 581 1810
new 1 581 1810
return 1 583 1812
assign 1 588 1891
new 1 588 1891
assign 1 589 1892
new 0 589 1892
assign 1 590 1893
emitterGet 0 590 1893
assign 1 591 1894
assign 1 592 1895
new 0 592 1895
assign 1 593 1896
shouldEmitGet 0 593 1896
put 1 593 1897
assign 1 0 1900
assign 1 0 1904
assign 1 0 1907
assign 1 596 1911
new 0 596 1911
assign 1 596 1912
toString 0 596 1912
assign 1 596 1913
add 1 596 1913
print 0 596 1914
assign 1 598 1916
assign 1 600 1917
fileGet 0 600 1917
assign 1 600 1918
readerGet 0 600 1918
assign 1 600 1919
open 0 600 1919
assign 1 600 1920
readBuffer 1 600 1920
assign 1 601 1921
fileGet 0 601 1921
assign 1 601 1922
readerGet 0 601 1922
close 0 601 1923
assign 1 602 1924
tokenize 1 602 1924
assign 1 606 1926
new 0 606 1926
echo 0 606 1927
assign 1 608 1929
outermostGet 0 608 1929
nodify 2 608 1930
assign 1 610 1932
new 0 610 1932
print 0 610 1933
assign 1 611 1934
new 2 611 1934
traverse 1 611 1935
assign 1 615 1938
new 0 615 1938
echo 0 615 1939
assign 1 617 1941
new 0 617 1941
traverse 1 617 1942
assign 1 619 1944
new 0 619 1944
print 0 619 1945
assign 1 620 1946
new 2 620 1946
traverse 1 620 1947
assign 1 623 1950
new 0 623 1950
echo 0 623 1951
assign 1 626 1953
new 0 626 1953
traverse 1 626 1954
contain 0 627 1955
assign 1 629 1957
new 0 629 1957
print 0 629 1958
assign 1 630 1959
new 2 630 1959
traverse 1 630 1960
assign 1 634 1963
new 0 634 1963
echo 0 634 1964
assign 1 636 1966
new 0 636 1966
traverse 1 636 1967
assign 1 638 1969
new 0 638 1969
print 0 638 1970
assign 1 639 1971
new 2 639 1971
traverse 1 639 1972
assign 1 643 1975
new 0 643 1975
echo 0 643 1976
assign 1 645 1978
new 0 645 1978
traverse 1 645 1979
assign 1 647 1981
new 0 647 1981
print 0 647 1982
assign 1 648 1983
new 2 648 1983
traverse 1 648 1984
assign 1 652 1987
new 0 652 1987
echo 0 652 1988
assign 1 654 1990
new 0 654 1990
traverse 1 654 1991
assign 1 656 1993
new 0 656 1993
print 0 656 1994
assign 1 657 1995
new 2 657 1995
traverse 1 657 1996
assign 1 661 1999
new 0 661 1999
echo 0 661 2000
assign 1 663 2002
new 0 663 2002
traverse 1 663 2003
assign 1 665 2005
new 0 665 2005
print 0 665 2006
assign 1 666 2007
new 2 666 2007
traverse 1 666 2008
assign 1 670 2011
new 0 670 2011
echo 0 670 2012
assign 1 672 2014
new 0 672 2014
traverse 1 672 2015
assign 1 674 2017
new 0 674 2017
print 0 674 2018
assign 1 675 2019
new 2 675 2019
traverse 1 675 2020
assign 1 679 2023
new 0 679 2023
echo 0 679 2024
assign 1 681 2026
new 0 681 2026
traverse 1 681 2027
assign 1 683 2029
new 0 683 2029
print 0 683 2030
assign 1 684 2031
new 2 684 2031
traverse 1 684 2032
assign 1 688 2035
new 0 688 2035
echo 0 688 2036
assign 1 690 2038
new 0 690 2038
traverse 1 690 2039
assign 1 692 2041
new 0 692 2041
print 0 692 2042
assign 1 693 2043
new 2 693 2043
traverse 1 693 2044
assign 1 696 2047
new 0 696 2047
echo 0 696 2048
assign 1 698 2050
new 0 698 2050
traverse 1 698 2051
assign 1 700 2053
new 0 700 2053
print 0 700 2054
assign 1 701 2055
new 2 701 2055
traverse 1 701 2056
assign 1 705 2059
new 0 705 2059
echo 0 705 2060
assign 1 706 2061
new 0 706 2061
print 0 706 2062
assign 1 708 2064
new 0 708 2064
traverse 1 708 2065
assign 1 0 2067
assign 1 0 2071
assign 1 0 2074
assign 1 710 2078
new 0 710 2078
print 0 710 2079
assign 1 711 2080
new 2 711 2080
traverse 1 711 2081
assign 1 713 2083
classesGet 0 713 2083
assign 1 713 2084
valueIteratorGet 0 713 2084
assign 1 713 2087
hasNextGet 0 713 2087
assign 1 714 2089
nextGet 0 714 2089
assign 1 716 2090
transUnitGet 0 716 2090
assign 1 717 2091
new 1 717 2091
assign 1 718 2092
TRANSUNITGet 0 718 2092
typenameSet 1 718 2093
assign 1 719 2094
new 0 719 2094
assign 1 720 2095
heldGet 0 720 2095
assign 1 720 2096
emitsGet 0 720 2096
emitsSet 1 720 2097
heldSet 1 721 2098
delete 0 722 2099
addValue 1 723 2100
copyLoc 1 724 2101
reInitContained 0 730 2123
assign 1 731 2124
containedGet 0 731 2124
assign 1 732 2125
new 0 732 2125
assign 1 733 2126
new 0 733 2126
assign 1 733 2127
crGet 0 733 2127
assign 1 734 2128
linkedListIteratorGet 0 734 2128
assign 1 734 2131
hasNextGet 0 734 2131
assign 1 735 2133
new 1 735 2133
assign 1 736 2134
nextGet 0 736 2134
heldSet 1 736 2135
nlcSet 1 737 2136
assign 1 738 2137
heldGet 0 738 2137
assign 1 738 2138
equals 1 738 2138
assign 1 739 2140
increment 0 739 2140
assign 1 741 2142
heldGet 0 741 2142
assign 1 741 2143
notEquals 1 741 2143
addValue 1 742 2145
containerSet 1 743 2146
assign 1 750 2201
new 0 750 2201
fromString 1 751 2202
assign 1 753 2203
new 1 753 2203
assign 1 754 2204
NAMEPATHGet 0 754 2204
typenameSet 1 754 2205
heldSet 1 755 2206
copyLoc 1 756 2207
assign 1 758 2208
new 0 758 2208
assign 1 759 2209
new 0 759 2209
nameSet 1 759 2210
assign 1 760 2211
new 0 760 2211
wasBoundSet 1 760 2212
assign 1 761 2213
new 0 761 2213
boundSet 1 761 2214
assign 1 762 2215
new 0 762 2215
isConstructSet 1 762 2216
assign 1 763 2217
new 0 763 2217
isLiteralSet 1 763 2218
assign 1 764 2219
heldGet 0 764 2219
literalValueSet 1 764 2220
addValue 1 766 2221
assign 1 768 2222
CALLGet 0 768 2222
typenameSet 1 768 2223
heldSet 1 769 2224
resolveNp 0 771 2225
assign 1 773 2226
new 0 773 2226
assign 1 773 2227
equals 1 773 2227
assign 1 0 2229
assign 1 773 2232
new 0 773 2232
assign 1 773 2233
equals 1 773 2233
assign 1 0 2235
assign 1 0 2238
assign 1 774 2242
priorPeerGet 0 774 2242
assign 1 775 2243
def 1 775 2248
assign 1 775 2249
typenameGet 0 775 2249
assign 1 775 2250
SUBTRACTGet 0 775 2250
assign 1 775 2251
equals 1 775 2251
assign 1 0 2253
assign 1 775 2256
typenameGet 0 775 2256
assign 1 775 2257
ADDGet 0 775 2257
assign 1 775 2258
equals 1 775 2258
assign 1 0 2260
assign 1 0 2263
assign 1 0 2267
assign 1 0 2270
assign 1 0 2274
assign 1 776 2277
priorPeerGet 0 776 2277
assign 1 777 2278
undef 1 777 2283
assign 1 0 2284
assign 1 777 2287
typenameGet 0 777 2287
assign 1 777 2288
CALLGet 0 777 2288
assign 1 777 2289
notEquals 1 777 2289
assign 1 777 2291
typenameGet 0 777 2291
assign 1 777 2292
IDGet 0 777 2292
assign 1 777 2293
notEquals 1 777 2293
assign 1 0 2295
assign 1 0 2298
assign 1 0 2302
assign 1 777 2305
typenameGet 0 777 2305
assign 1 777 2306
VARGet 0 777 2306
assign 1 777 2307
notEquals 1 777 2307
assign 1 0 2309
assign 1 0 2312
assign 1 0 2316
assign 1 777 2319
typenameGet 0 777 2319
assign 1 777 2320
ACCESSORGet 0 777 2320
assign 1 777 2321
notEquals 1 777 2321
assign 1 0 2323
assign 1 0 2326
assign 1 0 2330
assign 1 0 2333
assign 1 0 2336
assign 1 783 2340
heldGet 0 783 2340
assign 1 783 2341
literalValueGet 0 783 2341
assign 1 783 2342
add 1 783 2342
literalValueSet 1 783 2343
delete 0 784 2344
return 1 0 2351
return 1 0 2354
assign 1 0 2357
assign 1 0 2361
return 1 0 2365
return 1 0 2368
assign 1 0 2371
assign 1 0 2375
return 1 0 2379
return 1 0 2382
assign 1 0 2385
assign 1 0 2389
return 1 0 2393
return 1 0 2396
assign 1 0 2399
assign 1 0 2403
return 1 0 2407
return 1 0 2410
assign 1 0 2413
assign 1 0 2417
return 1 0 2421
return 1 0 2424
assign 1 0 2427
assign 1 0 2431
return 1 0 2435
return 1 0 2438
assign 1 0 2441
assign 1 0 2445
return 1 0 2449
return 1 0 2452
assign 1 0 2455
assign 1 0 2459
return 1 0 2463
return 1 0 2466
assign 1 0 2469
assign 1 0 2473
return 1 0 2477
return 1 0 2480
assign 1 0 2483
assign 1 0 2487
return 1 0 2491
return 1 0 2494
assign 1 0 2497
assign 1 0 2501
return 1 0 2505
return 1 0 2508
assign 1 0 2511
assign 1 0 2515
return 1 0 2519
return 1 0 2522
assign 1 0 2525
assign 1 0 2529
return 1 0 2533
return 1 0 2536
assign 1 0 2539
assign 1 0 2543
return 1 0 2547
return 1 0 2550
assign 1 0 2553
assign 1 0 2557
return 1 0 2561
return 1 0 2564
assign 1 0 2567
assign 1 0 2571
return 1 0 2575
return 1 0 2578
assign 1 0 2581
assign 1 0 2585
return 1 0 2589
return 1 0 2592
assign 1 0 2595
assign 1 0 2599
return 1 0 2603
return 1 0 2606
assign 1 0 2609
assign 1 0 2613
return 1 0 2617
return 1 0 2620
assign 1 0 2623
assign 1 0 2627
return 1 0 2631
return 1 0 2634
assign 1 0 2637
assign 1 0 2641
return 1 0 2645
return 1 0 2648
assign 1 0 2651
assign 1 0 2655
return 1 0 2659
return 1 0 2662
assign 1 0 2665
assign 1 0 2669
return 1 0 2673
return 1 0 2676
assign 1 0 2679
assign 1 0 2683
return 1 0 2687
return 1 0 2690
assign 1 0 2693
assign 1 0 2697
return 1 0 2701
return 1 0 2704
assign 1 0 2707
assign 1 0 2711
return 1 0 2715
return 1 0 2718
assign 1 0 2721
assign 1 0 2725
return 1 0 2729
return 1 0 2732
assign 1 0 2735
assign 1 0 2739
return 1 0 2743
return 1 0 2746
assign 1 0 2749
assign 1 0 2753
return 1 0 2757
return 1 0 2760
assign 1 0 2763
assign 1 0 2767
return 1 0 2771
return 1 0 2774
assign 1 0 2777
assign 1 0 2781
return 1 0 2785
return 1 0 2788
assign 1 0 2791
assign 1 0 2795
return 1 0 2799
return 1 0 2802
assign 1 0 2805
assign 1 0 2809
return 1 0 2813
return 1 0 2816
assign 1 0 2819
assign 1 0 2823
return 1 0 2827
return 1 0 2830
assign 1 0 2833
assign 1 0 2837
return 1 0 2841
return 1 0 2844
assign 1 0 2847
assign 1 0 2851
return 1 0 2855
return 1 0 2858
assign 1 0 2861
assign 1 0 2865
return 1 0 2869
return 1 0 2872
assign 1 0 2875
assign 1 0 2879
return 1 0 2883
return 1 0 2886
assign 1 0 2889
assign 1 0 2893
return 1 0 2897
return 1 0 2900
assign 1 0 2903
assign 1 0 2907
return 1 0 2911
return 1 0 2914
assign 1 0 2917
assign 1 0 2921
return 1 0 2925
return 1 0 2928
assign 1 0 2931
assign 1 0 2935
return 1 0 2939
return 1 0 2942
assign 1 0 2945
assign 1 0 2949
return 1 0 2953
return 1 0 2956
assign 1 0 2959
assign 1 0 2963
return 1 0 2967
return 1 0 2970
assign 1 0 2973
assign 1 0 2977
return 1 0 2981
return 1 0 2984
assign 1 0 2987
assign 1 0 2991
return 1 0 2995
return 1 0 2998
assign 1 0 3001
assign 1 0 3005
return 1 0 3009
return 1 0 3012
assign 1 0 3015
assign 1 0 3019
return 1 0 3023
return 1 0 3026
assign 1 0 3029
assign 1 0 3033
return 1 0 3037
return 1 0 3040
assign 1 0 3043
assign 1 0 3047
return 1 0 3051
return 1 0 3054
assign 1 0 3057
assign 1 0 3061
return 1 0 3065
return 1 0 3068
assign 1 0 3071
assign 1 0 3075
return 1 0 3079
return 1 0 3082
assign 1 0 3085
assign 1 0 3089
return 1 0 3093
return 1 0 3096
assign 1 0 3099
assign 1 0 3103
return 1 0 3107
return 1 0 3110
assign 1 0 3113
assign 1 0 3117
return 1 0 3121
return 1 0 3124
assign 1 0 3127
assign 1 0 3131
return 1 0 3135
return 1 0 3138
assign 1 0 3141
assign 1 0 3145
return 1 0 3149
return 1 0 3152
assign 1 0 3155
assign 1 0 3159
return 1 0 3163
return 1 0 3166
assign 1 0 3169
assign 1 0 3173
return 1 0 3177
return 1 0 3180
assign 1 0 3183
assign 1 0 3187
return 1 0 3191
return 1 0 3194
assign 1 0 3197
assign 1 0 3201
return 1 0 3205
return 1 0 3208
assign 1 0 3211
assign 1 0 3215
return 1 0 3219
return 1 0 3222
assign 1 0 3225
assign 1 0 3229
return 1 0 3233
return 1 0 3236
assign 1 0 3239
assign 1 0 3243
return 1 0 3247
return 1 0 3250
assign 1 0 3253
assign 1 0 3257
return 1 0 3261
return 1 0 3264
assign 1 0 3267
assign 1 0 3271
return 1 0 3275
return 1 0 3278
assign 1 0 3281
assign 1 0 3285
return 1 0 3289
return 1 0 3292
assign 1 0 3295
assign 1 0 3299
return 1 0 3303
return 1 0 3306
assign 1 0 3309
assign 1 0 3313
return 1 0 3317
return 1 0 3320
assign 1 0 3323
assign 1 0 3327
return 1 0 3331
return 1 0 3334
assign 1 0 3337
assign 1 0 3341
return 1 0 3345
return 1 0 3348
assign 1 0 3351
assign 1 0 3355
return 1 0 3359
assign 1 0 3362
assign 1 0 3366
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1561881831: return bem_tagGet_0();
case 1374872636: return bem_deserializeClassNameGet_0();
case -1502614600: return bem_includePathGetDirect_0();
case -2044460281: return bem_new_0();
case 2079047285: return bem_buildMessageGet_0();
case 916402762: return bem_linkLibArgsGetDirect_0();
case 1089711043: return bem_outputPlatformGet_0();
case -603677073: return bem_printAllAstGet_0();
case 14318384: return bem_emitFileHeaderGet_0();
case -1662571641: return bem_twtokGet_0();
case 1500732523: return bem_deployLibraryGetDirect_0();
case -1138791230: return bem_usedLibrarysStrGetDirect_0();
case -911573863: return bem_emitLibraryGetDirect_0();
case 1406331780: return bem_argsGetDirect_0();
case -1536500811: return bem_startTimeGet_0();
case -413150963: return bem_emitCommonGetDirect_0();
case -606457027: return bem_emitFlagsGet_0();
case -2041946683: return bem_buildPathGetDirect_0();
case 1100744008: return bem_saveSynsGetDirect_0();
case 1783908172: return bem_prepMakeGet_0();
case 891651777: return bem_saveIdsGet_0();
case -1965140286: return bem_parseTimeGet_0();
case -1511357591: return bem_builtGet_0();
case 1227062233: return bem_deployFilesToGet_0();
case -1775749738: return bem_codeGet_0();
case -1061394316: return bem_printPlacesGetDirect_0();
case 926073469: return bem_lctokGet_0();
case 2046345772: return bem_ntypesGet_0();
case -1474345157: return bem_serializeToString_0();
case -816585790: return bem_constantsGetDirect_0();
case 453042718: return bem_doEmitGet_0();
case 33031170: return bem_printAstGet_0();
case -139275945: return bem_estrGetDirect_0();
case 1731222959: return bem_emitPathGetDirect_0();
case 1992583192: return bem_classNameGet_0();
case -141904644: return bem_toString_0();
case 547522272: return bem_makeGet_0();
case 620386500: return bem_fromFileGetDirect_0();
case 2055822604: return bem_emitterGet_0();
case -2076683499: return bem_codeGetDirect_0();
case 702807890: return bem_putLineNumbersInTraceGetDirect_0();
case -744521805: return bem_ccObjArgsGetDirect_0();
case -1554525414: return bem_linkLibArgsGet_0();
case -286837859: return bem_emitCs_0();
case -1138133235: return bem_loadSynsGetDirect_0();
case -459602774: return bem_printStepsGet_0();
case -837657909: return bem_buildSucceededGet_0();
case -589773386: return bem_genOnlyGetDirect_0();
case -1958749226: return bem_compilerProfileGet_0();
case -1376485911: return bem_printAstGetDirect_0();
case -1741221276: return bem_initLibsGet_0();
case 1599241336: return bem_iteratorGet_0();
case 1953285587: return bem_outputPlatformGetDirect_0();
case 61634994: return bem_emitCommonGet_0();
case 1035232271: return bem_toAny_0();
case -1095216167: return bem_mainNameGet_0();
case -1164317725: return bem_parseEmitCompileTimeGetDirect_0();
case -243834178: return bem_doWhat_0();
case -899508256: return bem_estrGet_0();
case 795029067: return bem_deployPathGetDirect_0();
case -481892295: return bem_deployLibraryGet_0();
case 542422696: return bem_emitFileHeaderGetDirect_0();
case -1660141923: return bem_parseTimeGetDirect_0();
case 1804196163: return bem_parseEmitCompileTimeGet_0();
case 1821896017: return bem_newlineGet_0();
case 1298618024: return bem_emitDataGetDirect_0();
case 1404688002: return bem_extLinkObjectsGet_0();
case 1700036772: return bem_constantsGet_0();
case -618189751: return bem_makeArgsGetDirect_0();
case 1706987270: return bem_go_0();
case -572991999: return bem_singleCCGet_0();
case 881747131: return bem_compilerGet_0();
case -31877142: return bem_many_0();
case 1729928752: return bem_extIncludesGetDirect_0();
case 1084756778: return bem_exeNameGet_0();
case -1547844578: return bem_deployFilesToGetDirect_0();
case 1664862370: return bem_exeNameGetDirect_0();
case 1262980646: return bem_runArgsGetDirect_0();
case 532415323: return bem_buildMessageGetDirect_0();
case -747859575: return bem_echo_0();
case 1168835037: return bem_usedLibrarysStrGet_0();
case 971988389: return bem_closeLibrariesGetDirect_0();
case 340126756: return bem_printAllAstGetDirect_0();
case -1415974614: return bem_sharedEmitterGetDirect_0();
case -1433233468: return bem_prepMakeGetDirect_0();
case 1169747010: return bem_fromFileGet_0();
case -427589696: return bem_parseEmitTimeGet_0();
case -1986869633: return bem_deployFilesFromGet_0();
case 1900553338: return bem_makeGetDirect_0();
case -1726413475: return bem_usedLibrarysGetDirect_0();
case -1480557568: return bem_putLineNumbersInTraceGet_0();
case -1411155194: return bem_deployPathGet_0();
case 1730677021: return bem_emitDebugGetDirect_0();
case -1184059112: return bem_libNameGet_0();
case 1014822223: return bem_parseEmitTimeGetDirect_0();
case -295239377: return bem_printPlacesGet_0();
case -1343663328: return bem_main_0();
case -642304803: return bem_platformGet_0();
case 1135448362: return bem_emitLangsGet_0();
case 987048722: return bem_serializeContents_0();
case -1664116025: return bem_readBufferGet_0();
case -1337999691: return bem_deployFilesFromGetDirect_0();
case -129343122: return bem_extLibsGet_0();
case -1974022504: return bem_parseGetDirect_0();
case 2060381332: return bem_setClassesToWrite_0();
case -264931733: return bem_closeLibrariesStrGet_0();
case -516374207: return bem_usedLibrarysGet_0();
case -1879645384: return bem_deployUsedLibrariesGetDirect_0();
case -647519736: return bem_print_0();
case -264300199: return bem_makeNameGet_0();
case 1526812325: return bem_toBuildGetDirect_0();
case 1286172803: return bem_toBuildGet_0();
case -1725295404: return bem_sharedEmitterGet_0();
case 1234443509: return bem_paramsGet_0();
case -1350423363: return bem_genOnlyGet_0();
case -1642207881: return bem_buildPathGet_0();
case 1872945388: return bem_ownProcessGetDirect_0();
case 1343954869: return bem_lctokGetDirect_0();
case -393643982: return bem_runArgsGet_0();
case 1480915312: return bem_emitFlagsGetDirect_0();
case -1994555891: return bem_parseGet_0();
case -1368332745: return bem_compilerProfileGetDirect_0();
case -82830355: return bem_closeLibrariesGet_0();
case -1199110042: return bem_emitDataGet_0();
case 1622594470: return bem_printAstElementsGetDirect_0();
case -491739750: return bem_makeArgsGet_0();
case -1192731314: return bem_readBufferGetDirect_0();
case -671080319: return bem_emitLibraryGet_0();
case -730823220: return bem_emitDebugGet_0();
case 536523364: return bem_emitPathGet_0();
case -1138247425: return bem_platformGetDirect_0();
case -1614458142: return bem_builtGetDirect_0();
case -1272557142: return bem_extLinkObjectsGetDirect_0();
case -1999703144: return bem_sourceFileNameGet_0();
case -1870939020: return bem_nlGet_0();
case 2071671195: return bem_twtokGetDirect_0();
case -212934947: return bem_closeLibrariesStrGetDirect_0();
case -427081409: return bem_create_0();
case -625084115: return bem_singleCCGetDirect_0();
case 1034659716: return bem_once_0();
case 2008790928: return bem_extIncludesGet_0();
case -1775672031: return bem_ccObjArgsGet_0();
case -1522801060: return bem_argsGet_0();
case -1922984937: return bem_nlGetDirect_0();
case -1334667321: return bem_loadSynsGet_0();
case -1412125825: return bem_startTimeGetDirect_0();
case -697817657: return bem_mainNameGetDirect_0();
case 812532783: return bem_buildSucceededGetDirect_0();
case 1578795495: return bem_ntypesGetDirect_0();
case -1503949943: return bem_hashGet_0();
case -335518871: return bem_makeNameGetDirect_0();
case -1845567478: return bem_deployUsedLibrariesGet_0();
case 247818182: return bem_copy_0();
case -335942583: return bem_fieldIteratorGet_0();
case -1926952465: return bem_saveSynsGet_0();
case 1868847584: return bem_saveIdsGetDirect_0();
case 757497663: return bem_extLibsGetDirect_0();
case 1158401336: return bem_runGetDirect_0();
case 777635655: return bem_initLibsGetDirect_0();
case -1299938748: return bem_libNameGetDirect_0();
case -1112006601: return bem_ownProcessGet_0();
case 779795009: return bem_doEmitGetDirect_0();
case 1072705659: return bem_printStepsGetDirect_0();
case 1537147980: return bem_emitLangsGetDirect_0();
case 363847009: return bem_printAstElementsGet_0();
case -1791173436: return bem_config_0();
case 564021636: return bem_compilerGetDirect_0();
case 1346421791: return bem_newlineGetDirect_0();
case -709677651: return bem_fieldNamesGet_0();
case 421047878: return bem_serializationIteratorGet_0();
case -1528288629: return bem_paramsGetDirect_0();
case -1556939457: return bem_runGet_0();
case -1956789435: return bem_includePathGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1921379997: return bem_argsSetDirect_1(bevd_0);
case -1961171508: return bem_prepMakeSet_1(bevd_0);
case -1939583597: return bem_prepMakeSetDirect_1(bevd_0);
case -1570793301: return bem_outputPlatformSetDirect_1(bevd_0);
case 351827939: return bem_platformSetDirect_1(bevd_0);
case 1756559319: return bem_makeSet_1(bevd_0);
case -1602759286: return bem_compilerSet_1(bevd_0);
case -2013833275: return bem_deployFilesToSetDirect_1(bevd_0);
case -1230295986: return bem_buildSyns_1(bevd_0);
case 1795408137: return bem_printPlacesSet_1(bevd_0);
case -1550867414: return bem_toBuildSet_1(bevd_0);
case -66448650: return bem_parseEmitTimeSet_1(bevd_0);
case 1347657870: return bem_paramsSet_1(bevd_0);
case -1275614972: return bem_emitPathSetDirect_1(bevd_0);
case 1913477894: return bem_libNameSetDirect_1(bevd_0);
case -1127914902: return bem_exeNameSet_1(bevd_0);
case 1482027850: return bem_sameClass_1(bevd_0);
case -886639458: return bem_includePathSet_1(bevd_0);
case 1979991725: return bem_printPlacesSetDirect_1(bevd_0);
case 2068626797: return bem_builtSet_1(bevd_0);
case 2068636585: return bem_extIncludesSetDirect_1(bevd_0);
case -1259048964: return bem_notEquals_1(bevd_0);
case -1452090869: return bem_emitDebugSet_1(bevd_0);
case -1614404733: return bem_twtokSet_1(bevd_0);
case 1056498349: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1101786340: return bem_deployFilesFromSet_1(bevd_0);
case -1958682756: return bem_ownProcessSetDirect_1(bevd_0);
case 1552027161: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case -1975837620: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case 467730220: return bem_otherType_1(bevd_0);
case 781487324: return bem_emitFileHeaderSet_1(bevd_0);
case -1037648926: return bem_copyTo_1(bevd_0);
case 296279513: return bem_buildPathSet_1(bevd_0);
case -1507337796: return bem_deployFilesToSet_1(bevd_0);
case -554700062: return bem_emitDataSetDirect_1(bevd_0);
case 98757306: return bem_deployUsedLibrariesSet_1(bevd_0);
case 1051165080: return bem_sameObject_1(bevd_0);
case -752613797: return bem_sharedEmitterSetDirect_1(bevd_0);
case 1314795050: return bem_doEmitSetDirect_1(bevd_0);
case 2092860342: return bem_compilerSetDirect_1(bevd_0);
case 912306679: return bem_printAstElementsSetDirect_1(bevd_0);
case -1054467922: return bem_singleCCSet_1(bevd_0);
case 1402363485: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 85287022: return bem_usedLibrarysStrSetDirect_1(bevd_0);
case -1038179203: return bem_emitLibrarySet_1(bevd_0);
case 1222628994: return bem_printStepsSet_1(bevd_0);
case -312858827: return bem_doParse_1(bevd_0);
case -355556776: return bem_extLinkObjectsSetDirect_1(bevd_0);
case -1931774750: return bem_fromFileSetDirect_1(bevd_0);
case 1939114252: return bem_estrSetDirect_1(bevd_0);
case 235327624: return bem_newlineSet_1(bevd_0);
case -1103337674: return bem_undefined_1(bevd_0);
case -1738568162: return bem_emitPathSet_1(bevd_0);
case -1259657633: return bem_emitCommonSet_1(bevd_0);
case 15728199: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case -1617324535: return bem_defined_1(bevd_0);
case 2047009858: return bem_readBufferSetDirect_1(bevd_0);
case 1076739396: return bem_initLibsSetDirect_1(bevd_0);
case 911520728: return bem_mainNameSet_1(bevd_0);
case -2136985639: return bem_sameType_1(bevd_0);
case 274368973: return bem_extLibsSet_1(bevd_0);
case -1598152187: return bem_linkLibArgsSetDirect_1(bevd_0);
case 1874410970: return bem_emitLibrarySetDirect_1(bevd_0);
case -861413197: return bem_parseTimeSet_1(bevd_0);
case -826508169: return bem_makeArgsSetDirect_1(bevd_0);
case 1291458978: return bem_codeSetDirect_1(bevd_0);
case 141669220: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case 1785227932: return bem_usedLibrarysStrSet_1(bevd_0);
case 2078501325: return bem_buildMessageSet_1(bevd_0);
case 458261040: return bem_ntypesSetDirect_1(bevd_0);
case 1068542106: return bem_genOnlySetDirect_1(bevd_0);
case -1145632953: return bem_estrSet_1(bevd_0);
case 1203915126: return bem_includePathSetDirect_1(bevd_0);
case -2139112591: return bem_buildPathSetDirect_1(bevd_0);
case 515851688: return bem_extIncludesSet_1(bevd_0);
case 1443117599: return bem_singleCCSetDirect_1(bevd_0);
case 21327600: return bem_sharedEmitterSet_1(bevd_0);
case -961537131: return bem_lctokSetDirect_1(bevd_0);
case 971363914: return bem_doEmitSet_1(bevd_0);
case -1995491654: return bem_parseTimeSetDirect_1(bevd_0);
case -830667357: return bem_fromFileSet_1(bevd_0);
case 1118935191: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 663238686: return bem_makeNameSet_1(bevd_0);
case 949409055: return bem_parseEmitTimeSetDirect_1(bevd_0);
case 394020949: return bem_ccObjArgsSet_1(bevd_0);
case -169060382: return bem_paramsSetDirect_1(bevd_0);
case -173304255: return bem_outputPlatformSet_1(bevd_0);
case -325853370: return bem_runArgsSetDirect_1(bevd_0);
case 1909971917: return bem_parseSetDirect_1(bevd_0);
case 960876708: return bem_twtokSetDirect_1(bevd_0);
case -13569076: return bem_extLinkObjectsSet_1(bevd_0);
case 825542855: return bem_emitLangsSetDirect_1(bevd_0);
case -1440113444: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1286556430: return bem_saveSynsSetDirect_1(bevd_0);
case -801762887: return bem_deployFilesFromSetDirect_1(bevd_0);
case 1528927930: return bem_builtSetDirect_1(bevd_0);
case -396718725: return bem_genOnlySet_1(bevd_0);
case -1712723703: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case -500109490: return bem_closeLibrariesStrSet_1(bevd_0);
case 1503238105: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case 1857316792: return bem_initLibsSet_1(bevd_0);
case -317049327: return bem_def_1(bevd_0);
case 544063329: return bem_equals_1(bevd_0);
case -1854832824: return bem_makeNameSetDirect_1(bevd_0);
case -1765586143: return bem_printAstSet_1(bevd_0);
case -1231906633: return bem_startTimeSetDirect_1(bevd_0);
case 1043297796: return bem_printAstElementsSet_1(bevd_0);
case -618257599: return bem_loadSynsSet_1(bevd_0);
case -1680276730: return bem_deployLibrarySetDirect_1(bevd_0);
case -1225120091: return bem_compilerProfileSetDirect_1(bevd_0);
case -216221008: return bem_toBuildSetDirect_1(bevd_0);
case 137453505: return bem_printStepsSetDirect_1(bevd_0);
case -1241580172: return bem_makeArgsSet_1(bevd_0);
case 1173812139: return bem_nlSetDirect_1(bevd_0);
case -1858308608: return bem_loadSynsSetDirect_1(bevd_0);
case 1894952309: return bem_mainNameSetDirect_1(bevd_0);
case -1440620949: return bem_ownProcessSet_1(bevd_0);
case 1770118846: return bem_ccObjArgsSetDirect_1(bevd_0);
case 1678394676: return bem_buildMessageSetDirect_1(bevd_0);
case -1032782900: return bem_nlSet_1(bevd_0);
case 1662123849: return bem_constantsSet_1(bevd_0);
case 503045546: return bem_exeNameSetDirect_1(bevd_0);
case 551673817: return bem_emitFileHeaderSetDirect_1(bevd_0);
case 1067056776: return bem_printAllAstSet_1(bevd_0);
case -344078527: return bem_constantsSetDirect_1(bevd_0);
case -268470267: return bem_saveIdsSetDirect_1(bevd_0);
case -1187754064: return bem_runArgsSet_1(bevd_0);
case 1238248196: return bem_deployPathSet_1(bevd_0);
case -1715759338: return bem_getSynNp_1(bevd_0);
case 984309694: return bem_emitFlagsSet_1(bevd_0);
case 1614712429: return bem_extLibsSetDirect_1(bevd_0);
case -485264532: return bem_saveIdsSet_1(bevd_0);
case -1074419262: return bem_makeSetDirect_1(bevd_0);
case -778870647: return bem_saveSynsSet_1(bevd_0);
case -1447318064: return bem_emitDebugSetDirect_1(bevd_0);
case 1375904729: return bem_argsSet_1(bevd_0);
case 617904013: return bem_usedLibrarysSetDirect_1(bevd_0);
case -1579282288: return bem_printAstSetDirect_1(bevd_0);
case 978761136: return bem_printAllAstSetDirect_1(bevd_0);
case -664087428: return bem_emitLangsSet_1(bevd_0);
case -767876115: return bem_undef_1(bevd_0);
case 1125848008: return bem_linkLibArgsSet_1(bevd_0);
case -1279210947: return bem_startTimeSet_1(bevd_0);
case -792776635: return bem_buildSucceededSetDirect_1(bevd_0);
case 1345865047: return bem_platformSet_1(bevd_0);
case -1248554701: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case 1718256646: return bem_compilerProfileSet_1(bevd_0);
case 161987437: return bem_closeLibrariesSetDirect_1(bevd_0);
case 2142701564: return bem_deployLibrarySet_1(bevd_0);
case 2141740909: return bem_otherClass_1(bevd_0);
case -1865893143: return bem_emitFlagsSetDirect_1(bevd_0);
case -1784359456: return bem_emitDataSet_1(bevd_0);
case -222906936: return bem_buildSucceededSet_1(bevd_0);
case -1586837255: return bem_readBufferSet_1(bevd_0);
case -1951879526: return bem_deployPathSetDirect_1(bevd_0);
case -47388554: return bem_libNameSet_1(bevd_0);
case 1937918169: return bem_emitCommonSetDirect_1(bevd_0);
case 1553447441: return bem_usedLibrarysSet_1(bevd_0);
case -1033189458: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 684106532: return bem_lctokSet_1(bevd_0);
case -1732439949: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1154447825: return bem_runSet_1(bevd_0);
case 332844637: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1391575676: return bem_parseSet_1(bevd_0);
case -1164485025: return bem_runSetDirect_1(bevd_0);
case -2113071366: return bem_ntypesSet_1(bevd_0);
case -56300453: return bem_codeSet_1(bevd_0);
case 1013969840: return bem_closeLibrariesSet_1(bevd_0);
case 184772717: return bem_newlineSetDirect_1(bevd_0);
case -1585126486: return bem_parseEmitCompileTimeSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1155749415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -830439297: return bem_getSyn_2(bevd_0, bevd_1);
case -78432632: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 930768377: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1135810204: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -657633999: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2067866135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 685516895: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -1477075576: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -196798587: return bem_buildLiteral_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
}
