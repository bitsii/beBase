namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_12, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_60, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_63, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_68, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_71, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_105, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_106, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_107 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_107, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_108 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_108, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_109 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_109, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_110 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_110, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_111 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_111, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_112 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_113 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_114 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static new BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static new BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_singleCC = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_saveSyns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_saveIds = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 97 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 97 */
 else  /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 97 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 98 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 116 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 116 */
 else  /* Line: 116 */ {
break;
} /* Line: 116 */
} /* Line: 116 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bem_config_0();
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 126 */ {
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 129 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1156921009);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 134 */
if (bevp_printSteps.bevi_bool) /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 136 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 136 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 137 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(1525225506);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-373658986, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 143 */ {
} /* Line: 143 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_120_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_126_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_129_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpany_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_5_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_6_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 154 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 154 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-999307174);
bevt_9_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpany_phold);
} /* Line: 157 */
} /* Line: 155 */
 else  /* Line: 154 */ {
break;
} /* Line: 154 */
} /* Line: 154 */
} /* Line: 154 */
bevt_13_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_nameGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_equals_1(bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 162 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 163 */
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_15_tmpany_phold = bevp_params.bem_get_1(bevt_16_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_17_tmpany_phold = bevp_params.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_19_tmpany_phold = bevp_params.bem_get_1(bevt_20_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_firstGet_0();
} /* Line: 167 */
 else  /* Line: 168 */ {
bevp_exeName = bevp_libName;
} /* Line: 169 */
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_23_tmpany_phold = bevp_params.bem_get_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_firstGet_0();
bevt_21_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpany_phold);
bevp_buildPath = bevt_21_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_29_tmpany_phold = bevp_params.bem_get_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_firstGet_0();
bevt_27_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpany_phold);
bevp_includePath = bevt_27_tmpany_phold.bem_pathGet_0();
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_36_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_nameGet_0();
bevt_33_tmpany_phold = bevp_params.bem_get_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpany_phold );
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_40_tmpany_phold = bevp_platform.bemd_0(1525225506);
bevt_38_tmpany_phold = bevp_params.bem_get_2(bevt_39_tmpany_phold, (BEC_2_4_6_TextString) bevt_40_tmpany_phold );
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpany_phold );
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_42_tmpany_phold = bevp_params.bem_get_2(bevt_43_tmpany_phold, bevt_44_tmpany_phold);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_26));
bevt_46_tmpany_phold = bevp_params.bem_get_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpany_phold);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_28));
bevt_50_tmpany_phold = bevp_params.bem_get_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_29));
bevp_loadSyns = bevp_params.bem_get_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_30));
bevp_initLibs = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_31));
bevt_55_tmpany_phold = bevp_params.bem_get_1(bevt_56_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_55_tmpany_phold.bem_firstGet_0();
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_32));
bevt_57_tmpany_phold = bevp_params.bem_get_1(bevt_58_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_57_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_59_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 187 */
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_61_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 191 */
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_63_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 195 */
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_65_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 199 */
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_67_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 202 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 203 */
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_69_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 206 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 207 */
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_71_tmpany_phold);
if (bevp_extLibs == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 210 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 211 */
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_73_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_74_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 215 */
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_75_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 219 */
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_77_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(1185130494);
} /* Line: 223 */
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_79_tmpany_phold);
if (bevp_runArgs == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 226 */ {
bevp_runArgs = bevp_runArgs.bemd_0(1185130494);
} /* Line: 227 */
 else  /* Line: 228 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 229 */
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_44));
bevt_82_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevt_84_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_86_tmpany_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_87_tmpany_phold);
if (bevl_pacm == null) {
bevt_88_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_90_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_90_tmpany_phold.bevi_bool) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
 else  /* Line: 237 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 237 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 238 */ {
bevt_91_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_91_tmpany_phold).bevi_bool) /* Line: 238 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 239 */
 else  /* Line: 238 */ {
break;
} /* Line: 238 */
} /* Line: 238 */
} /* Line: 238 */
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_53));
bevt_97_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevp_emitLangs = bevp_params.bem_get_1(bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_55));
bevp_emitFlags = bevp_params.bem_get_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_100_tmpany_phold = bevp_params.bem_get_2(bevt_101_tmpany_phold, bevt_102_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_100_tmpany_phold.bem_firstGet_0();
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_59));
bevt_103_tmpany_phold = bevp_params.bem_get_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_103_tmpany_phold.bem_firstGet_0();
bevt_108_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bem_add_1(bevp_makeName);
bevt_109_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_106_tmpany_phold = bevp_params.bem_get_2(bevt_107_tmpany_phold, bevt_109_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_106_tmpany_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_110_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_110_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_110_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 260 */
 else  /* Line: 261 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_62));
} /* Line: 262 */
bevt_113_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_112_tmpany_phold = bevl_outLang.bem_add_1(bevt_113_tmpany_phold);
bevt_114_tmpany_phold = bevp_platform.bemd_0(1525225506);
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bem_add_1(bevt_114_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_111_tmpany_phold);
if (bevl_platformSources == null) {
bevt_115_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_115_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_116_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_116_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 271 */
bevt_118_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_117_tmpany_phold = bevl_outLang.bem_add_1(bevt_118_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_117_tmpany_phold);
if (bevl_langSources == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 275 */ {
bevt_120_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_120_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 276 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_121_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpany_loop = bevt_121_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 280 */ {
bevt_122_tmpany_phold = bevt_2_tmpany_loop.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_122_tmpany_phold).bevi_bool) /* Line: 280 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(-999307174);
bevt_123_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_123_tmpany_phold);
} /* Line: 281 */
 else  /* Line: 280 */ {
break;
} /* Line: 280 */
} /* Line: 280 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(-1107359933);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_126_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_125_tmpany_phold = bevt_126_tmpany_phold.bem_existsGet_0();
if (bevt_125_tmpany_phold.bevi_bool) {
bevt_124_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_124_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_124_tmpany_phold.bevi_bool) /* Line: 288 */ {
bevt_127_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_127_tmpany_phold.bem_makeDirs_0();
} /* Line: 289 */
if (bevp_emitFileHeader == null) {
bevt_128_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_128_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_128_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_129_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_129_tmpany_phold.bem_readerGet_0();
bevt_130_tmpany_phold = bevl_emr.bemd_0(684860601);
bevp_emitFileHeader = bevt_130_tmpany_phold.bemd_0(-1748667265);
bevl_emr.bemd_0(26136785);
} /* Line: 294 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(-2016123429, bevp_nl);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-2016123429, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(-2016123429, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(-2016123429, bevp_nl);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(-2016123429, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(-2016123429, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 308 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 308 */ {
bevl_clnode = bevl_ci.bemd_0(-999307174);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(-586040121);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1208063422);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 310 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(-586040121);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1489263396);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1156921009);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(-586040121);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1489263396);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(1156921009);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 313 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 314 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 315 */
 else  /* Line: 314 */ {
break;
} /* Line: 314 */
} /* Line: 314 */
} /* Line: 314 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(-586040121);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(1489263396);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1156921009);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 319 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 320 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 321 */
 else  /* Line: 320 */ {
break;
} /* Line: 320 */
} /* Line: 320 */
} /* Line: 320 */
} /* Line: 319 */
} /* Line: 310 */
 else  /* Line: 308 */ {
break;
} /* Line: 308 */
} /* Line: 308 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 326 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 326 */ {
bevl_clnode = bevl_ci.bemd_0(-999307174);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(-586040121);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(-586040121);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(1489263396);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(1156921009);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(1057372278, bevt_26_tmpany_phold);
} /* Line: 328 */
 else  /* Line: 326 */ {
break;
} /* Line: 326 */
} /* Line: 326 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 339 */ {
return bevp_emitCommon;
} /* Line: 340 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 347 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 348 */
 else  /* Line: 347 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 350 */
 else  /* Line: 347 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 351 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 352 */
 else  /* Line: 353 */ {
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_70));
bevt_8_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpany_phold);
} /* Line: 354 */
} /* Line: 347 */
} /* Line: 347 */
return bevp_emitCommon;
} /* Line: 356 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = (BEC_2_4_8_TimeInterval) bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(684860601);
bevt_5_tmpany_phold = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 379 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 380 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 380 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 381 */
 else  /* Line: 380 */ {
break;
} /* Line: 380 */
} /* Line: 380 */
} /* Line: 380 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 385 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 388 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 389 */
} /* Line: 388 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(-461205434);
while (true)
 /* Line: 394 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 394 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(-999307174);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 395 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 398 */
} /* Line: 395 */
 else  /* Line: 394 */ {
break;
} /* Line: 394 */
} /* Line: 394 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(-461205434);
while (true)
 /* Line: 401 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 401 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(-999307174);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 402 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(-1449398557);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 406 */
} /* Line: 402 */
 else  /* Line: 401 */ {
break;
} /* Line: 401 */
} /* Line: 401 */
if (bevp_parse.bevi_bool) /* Line: 409 */ {
bevl_built = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 412 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 412 */ {
bevl_tb = bevl_i.bemd_0(-999307174);
bevt_20_tmpany_phold = bevl_tb.bemd_0(1156921009);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 415 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(1156921009);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 417 */
} /* Line: 415 */
 else  /* Line: 412 */ {
break;
} /* Line: 412 */
} /* Line: 412 */
bem_buildSyns_1(bevl_em);
} /* Line: 420 */
bevt_23_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 426 */ {
bevt_26_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 435 */
if (bevp_doEmit.bevi_bool) /* Line: 437 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(292127621);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 441 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 441 */ {
bevl_clnode = bevl_ci.bemd_0(-999307174);
bevl_em.bemd_1(-1048336534, bevl_clnode);
} /* Line: 443 */
 else  /* Line: 441 */ {
break;
} /* Line: 441 */
} /* Line: 441 */
bevl_em.bemd_0(913984923);
bevl_em.bemd_0(-2147241193);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 447 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 447 */ {
bevl_clnode = bevl_ci.bemd_0(-999307174);
bevl_em.bemd_1(-1946550511, bevl_clnode);
} /* Line: 449 */
 else  /* Line: 447 */ {
break;
} /* Line: 447 */
} /* Line: 447 */
} /* Line: 447 */
bevt_44_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 454 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 455 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 458 */ {
bevl_em.bemd_1(1135756620, bevp_deployLibrary);
} /* Line: 460 */
if (bevp_make.bevi_bool) /* Line: 463 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 464 */ {
bevl_em.bemd_1(-1829351806, bevp_deployLibrary);
bevl_em.bemd_1(790476676, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 467 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 468 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 468 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(292127621);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(-442720415);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(1789707820);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(-1710750100);
bevl_cpTo.bemd_1(811439182, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(-1194629397);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(1500239384);
if (((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 472 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(-1194629397);
bevt_58_tmpany_phold.bemd_0(-1844083341);
} /* Line: 473 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(-1194629397);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(1500239384);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(-2147249211);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 475 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(-1194629397);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(-1194629397);
bevl_em.bemd_2(1958712598, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 476 */
} /* Line: 475 */
 else  /* Line: 468 */ {
break;
} /* Line: 468 */
} /* Line: 468 */
} /* Line: 468 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 483 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 483 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 483 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 483 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 483 */
 else  /* Line: 483 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 483 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(-999307174);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(-999307174);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(-1194629397);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(1500239384);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 487 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(-1194629397);
bevt_76_tmpany_phold.bemd_0(-1844083341);
} /* Line: 488 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(-1194629397);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(1500239384);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(-2147249211);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 490 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(-1194629397);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(-1194629397);
bevl_em.bemd_2(1958712598, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 491 */
} /* Line: 490 */
 else  /* Line: 483 */ {
break;
} /* Line: 483 */
} /* Line: 483 */
} /* Line: 483 */
} /* Line: 464 */
bevt_83_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 498 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 499 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 501 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 502 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 504 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 505 */
if (bevp_run.bevi_bool) /* Line: 508 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(1189363562, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 512 */
bevt_98_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 518 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 518 */ {
bevl_kls = bevl_ci.bemd_0(-999307174);
bevt_2_tmpany_phold = bevl_kls.bemd_0(-586040121);
bevt_2_tmpany_phold.bemd_1(-404723038, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-404723038, bevp_libName);
} /* Line: 522 */
 else  /* Line: 518 */ {
break;
} /* Line: 518 */
} /* Line: 518 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 524 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 524 */ {
bevl_kls = bevl_ci.bemd_0(-999307174);
bevt_5_tmpany_phold = bevl_kls.bemd_0(-586040121);
bevl_syn = bevt_5_tmpany_phold.bemd_0(1171959922);
bevl_syn.bemd_2(871953150, this, bevl_kls);
bevl_syn.bemd_1(1096216526, this);
} /* Line: 528 */
 else  /* Line: 524 */ {
break;
} /* Line: 524 */
} /* Line: 524 */
bevt_6_tmpany_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(-586040121);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1171959922);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 534 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(-586040121);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1171959922);
return bevt_3_tmpany_phold;
} /* Line: 535 */
bevt_5_tmpany_phold = beva_klass.bemd_0(-586040121);
bevt_5_tmpany_phold.bemd_1(-404723038, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(-586040121);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-727369202);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 538 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 539 */
 else  /* Line: 540 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(-586040121);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-727369202);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1156921009);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(-586040121);
bevt_14_tmpany_phold.bemd_1(-404723038, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 545 */
 else  /* Line: 546 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(-586040121);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-727369202);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 549 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 551 */
bevt_17_tmpany_phold = beva_klass.bemd_0(-586040121);
bevt_17_tmpany_phold.bemd_1(-1114250607, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(-586040121);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(1489263396);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1156921009);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(1156921009);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 561 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 562 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(846211129, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 577 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 578 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 591 */ {
if (bevp_printSteps.bevi_bool) /* Line: 592 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 592 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 592 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 592 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 592 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 592 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_5_tmpany_phold = beva_toParse.bemd_0(1156921009);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 593 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(-1194629397);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-280953503);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(684860601);
bevl_src = bevt_6_tmpany_phold.bemd_1(574685433, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(-1194629397);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-280953503);
bevt_9_tmpany_phold.bemd_0(26136785);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 602 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 603 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(166366830);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 606 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_14_tmpany_phold);
} /* Line: 608 */
if (bevp_printSteps.bevi_bool) /* Line: 611 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 612 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-894092778, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 615 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_18_tmpany_phold);
} /* Line: 617 */
if (bevp_printSteps.bevi_bool) /* Line: 619 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 620 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-894092778, bevt_20_tmpany_phold);
bevl_trans.bemd_0(-352512486);
if (bevp_printAllAst.bevi_bool) /* Line: 625 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_22_tmpany_phold);
} /* Line: 627 */
if (bevp_printSteps.bevi_bool) /* Line: 630 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 631 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-894092778, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 634 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_26_tmpany_phold);
} /* Line: 636 */
if (bevp_printSteps.bevi_bool) /* Line: 639 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 640 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-894092778, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 643 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_30_tmpany_phold);
} /* Line: 645 */
if (bevp_printSteps.bevi_bool) /* Line: 648 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 649 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-894092778, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 652 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_34_tmpany_phold);
} /* Line: 654 */
if (bevp_printSteps.bevi_bool) /* Line: 657 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 658 */
bevt_36_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-894092778, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 661 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_38_tmpany_phold);
} /* Line: 663 */
if (bevp_printSteps.bevi_bool) /* Line: 666 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 667 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-894092778, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 670 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_42_tmpany_phold);
} /* Line: 672 */
if (bevp_printSteps.bevi_bool) /* Line: 675 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 676 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-894092778, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 679 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_46_tmpany_phold);
} /* Line: 681 */
if (bevp_printSteps.bevi_bool) /* Line: 684 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 685 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-894092778, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 688 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_50_tmpany_phold);
} /* Line: 690 */
if (bevp_printSteps.bevi_bool) /* Line: 692 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 693 */
bevt_52_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-894092778, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 696 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_54_tmpany_phold);
} /* Line: 698 */
if (bevp_printSteps.bevi_bool) /* Line: 701 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 703 */
bevt_57_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-894092778, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 706 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 706 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 706 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 706 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 706 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 706 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-894092778, bevt_59_tmpany_phold);
} /* Line: 708 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 710 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(1389189613);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 710 */ {
bevl_clnode = bevl_ci.bemd_0(-999307174);
bevl_tunode = bevl_clnode.bemd_0(1677093634);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(606773809, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(-586040121);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(1173859784);
bevl_ntt.bemd_1(358054978, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(718027914, bevl_ntt);
bevl_clnode.bemd_0(-1844083341);
bevl_ntunode.bemd_1(-1586212682, bevl_clnode);
bevl_ntunode.bemd_1(-1358768911, bevl_clnode);
} /* Line: 721 */
 else  /* Line: 710 */ {
break;
} /* Line: 710 */
} /* Line: 710 */
} /* Line: 710 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(-679051533);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(-1234001624);
bevl_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 731 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 731 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(718027914, bevt_2_tmpany_phold);
bevl_node.bemd_1(1359555306, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(-586040121);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-373658986, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 735 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 736 */
bevt_6_tmpany_phold = bevl_node.bemd_0(-586040121);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(-1499911921, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 738 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(-1669409768, beva_parnode);
} /* Line: 740 */
} /* Line: 738 */
 else  /* Line: 731 */ {
break;
} /* Line: 731 */
} /* Line: 731 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-2062359963, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(606773809, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(718027914, bevl_nlnp);
bevl_nlnpn.bemd_1(-1358768911, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_112));
bevl_nlc.bemd_1(-1616704023, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1323474067, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-594457277, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-750824710, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-295943922, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(-586040121);
bevl_nlc.bemd_1(543661626, bevt_11_tmpany_phold);
beva_node.bemd_1(-1586212682, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(606773809, bevt_12_tmpany_phold);
beva_node.bemd_1(718027914, bevl_nlc);
bevl_nlnpn.bemd_0(-653110464);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_113));
bevt_13_tmpany_phold = beva_tName.bemd_1(-373658986, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 770 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 770 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_114));
bevt_15_tmpany_phold = beva_tName.bemd_1(-373658986, bevt_16_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 770 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 770 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 770 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 770 */ {
bevl_pn = beva_node.bemd_0(-325799214);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 772 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-512402233);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(-373658986, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 772 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-512402233);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(-373658986, bevt_23_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 772 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 772 */
 else  /* Line: 772 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 772 */ {
bevl_pn2 = bevl_pn.bemd_0(-325799214);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-512402233);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(-1499911921, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 774 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-512402233);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(-1499911921, bevt_30_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 774 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 774 */
 else  /* Line: 774 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 774 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-512402233);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(-1499911921, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 774 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 774 */
 else  /* Line: 774 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 774 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-512402233);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(-1499911921, bevt_36_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 774 */
 else  /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 774 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 774 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(-586040121);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(-141453707);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(-2016123429, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(543661626, bevt_37_tmpany_phold);
bevl_pn.bemd_0(-1844083341);
} /* Line: 781 */
} /* Line: 774 */
} /* Line: 772 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGetDirect_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGetDirect_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGetDirect_0() {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGetDirect_0() {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGetDirect_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGetDirect_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGetDirect_0() {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGetDirect_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGetDirect_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGetDirect_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGetDirect_0() {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGetDirect_0() {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGetDirect_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGetDirect_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGetDirect_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGetDirect_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGetDirect_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGetDirect_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGetDirect_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGetDirect_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {50, 52, 53, 54, 55, 57, 58, 59, 60, 61, 62, 63, 67, 69, 70, 71, 72, 72, 75, 78, 79, 80, 86, 87, 88, 89, 90, 90, 97, 97, 97, 97, 0, 97, 97, 0, 0, 0, 0, 0, 98, 98, 100, 100, 104, 104, 104, 104, 108, 108, 109, 109, 109, 113, 114, 115, 115, 115, 115, 115, 116, 116, 116, 117, 116, 119, 123, 124, 125, 127, 128, 129, 131, 132, 133, 133, 134, 0, 0, 0, 137, 139, 143, 143, 143, 145, 150, 152, 153, 153, 153, 154, 154, 0, 154, 154, 155, 155, 155, 156, 157, 157, 162, 162, 162, 162, 163, 165, 165, 165, 166, 166, 167, 167, 167, 169, 171, 171, 171, 171, 171, 171, 172, 173, 173, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 181, 181, 183, 183, 183, 184, 184, 184, 185, 185, 186, 186, 187, 189, 189, 190, 190, 191, 193, 193, 194, 194, 195, 197, 197, 198, 198, 199, 201, 201, 202, 202, 203, 205, 205, 206, 206, 207, 209, 209, 210, 210, 211, 213, 213, 214, 214, 215, 217, 217, 218, 218, 219, 221, 221, 222, 222, 223, 225, 225, 226, 226, 227, 229, 231, 231, 231, 232, 232, 232, 233, 233, 234, 234, 235, 236, 236, 237, 237, 237, 237, 237, 0, 0, 0, 238, 0, 238, 238, 239, 242, 242, 243, 243, 244, 244, 245, 245, 246, 246, 246, 247, 247, 248, 248, 249, 249, 249, 249, 250, 250, 250, 250, 251, 251, 251, 251, 251, 252, 253, 254, 255, 256, 259, 259, 260, 262, 269, 269, 269, 269, 269, 270, 270, 271, 271, 274, 274, 274, 275, 275, 276, 276, 279, 280, 280, 0, 280, 280, 281, 281, 283, 284, 285, 287, 288, 288, 288, 288, 289, 289, 291, 291, 292, 292, 293, 293, 294, 300, 301, 301, 301, 301, 301, 302, 302, 302, 302, 302, 303, 307, 308, 308, 308, 309, 310, 310, 310, 310, 311, 311, 311, 311, 312, 312, 312, 312, 312, 313, 313, 314, 0, 314, 314, 315, 318, 318, 318, 318, 318, 319, 319, 320, 0, 320, 320, 321, 326, 326, 326, 327, 328, 328, 328, 328, 328, 328, 335, 335, 339, 339, 340, 345, 345, 346, 347, 347, 348, 349, 349, 350, 351, 351, 352, 354, 354, 354, 356, 358, 362, 364, 364, 364, 365, 365, 366, 366, 366, 367, 367, 368, 369, 369, 370, 370, 370, 371, 371, 371, 377, 377, 378, 379, 379, 380, 0, 380, 380, 381, 384, 385, 385, 386, 387, 389, 389, 389, 392, 394, 0, 394, 394, 395, 395, 395, 396, 397, 398, 401, 0, 401, 401, 402, 402, 402, 403, 404, 405, 406, 406, 411, 412, 412, 413, 415, 415, 416, 416, 417, 420, 423, 423, 423, 426, 426, 426, 428, 428, 429, 429, 430, 430, 430, 431, 431, 431, 432, 432, 432, 433, 433, 433, 434, 434, 434, 435, 435, 438, 439, 441, 441, 441, 442, 443, 445, 446, 447, 447, 447, 448, 449, 453, 453, 453, 454, 454, 455, 455, 455, 457, 457, 457, 460, 464, 464, 465, 466, 468, 0, 468, 468, 469, 469, 470, 470, 471, 471, 471, 472, 472, 473, 473, 475, 475, 475, 476, 476, 476, 480, 481, 483, 483, 0, 0, 0, 484, 484, 485, 485, 485, 485, 485, 485, 485, 485, 487, 487, 488, 488, 490, 490, 490, 491, 491, 491, 496, 496, 496, 498, 498, 499, 499, 499, 501, 501, 502, 502, 502, 504, 504, 505, 505, 505, 509, 509, 510, 511, 511, 511, 511, 511, 512, 514, 514, 518, 518, 518, 519, 520, 520, 521, 522, 524, 524, 524, 525, 526, 526, 527, 528, 530, 530, 534, 534, 534, 534, 535, 535, 535, 537, 537, 538, 538, 538, 538, 539, 541, 541, 541, 541, 541, 543, 543, 544, 544, 545, 549, 549, 549, 551, 553, 553, 554, 554, 554, 554, 555, 559, 560, 560, 561, 561, 562, 568, 568, 569, 570, 577, 577, 578, 580, 585, 586, 587, 588, 589, 590, 590, 0, 0, 0, 593, 593, 593, 593, 595, 597, 597, 597, 597, 598, 598, 598, 599, 603, 603, 605, 605, 607, 607, 608, 608, 612, 612, 614, 614, 616, 616, 617, 617, 620, 620, 623, 623, 624, 626, 626, 627, 627, 631, 631, 633, 633, 635, 635, 636, 636, 640, 640, 642, 642, 644, 644, 645, 645, 649, 649, 651, 651, 653, 653, 654, 654, 658, 658, 660, 660, 662, 662, 663, 663, 667, 667, 669, 669, 671, 671, 672, 672, 676, 676, 678, 678, 680, 680, 681, 681, 685, 685, 687, 687, 689, 689, 690, 690, 693, 693, 695, 695, 697, 697, 698, 698, 702, 702, 703, 703, 705, 705, 0, 0, 0, 707, 707, 708, 708, 710, 710, 710, 711, 713, 714, 715, 715, 716, 717, 717, 717, 718, 719, 720, 721, 727, 728, 729, 730, 730, 731, 731, 732, 733, 733, 734, 735, 735, 736, 738, 738, 739, 740, 747, 748, 750, 751, 751, 752, 753, 755, 756, 756, 757, 757, 758, 758, 759, 759, 760, 760, 761, 761, 763, 765, 765, 766, 768, 770, 770, 0, 770, 770, 0, 0, 771, 772, 772, 772, 772, 772, 0, 772, 772, 772, 0, 0, 0, 0, 0, 773, 774, 774, 0, 774, 774, 774, 774, 774, 774, 0, 0, 0, 774, 774, 774, 0, 0, 0, 774, 774, 774, 0, 0, 0, 0, 0, 780, 780, 780, 780, 781, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 293, 298, 299, 300, 302, 305, 306, 308, 311, 315, 318, 322, 325, 326, 328, 329, 335, 336, 337, 338, 345, 346, 347, 348, 349, 361, 362, 363, 364, 365, 366, 367, 368, 371, 376, 377, 378, 384, 392, 393, 394, 396, 397, 398, 402, 403, 404, 405, 406, 409, 413, 416, 420, 422, 428, 429, 430, 433, 576, 577, 578, 579, 584, 585, 586, 586, 589, 591, 592, 593, 598, 599, 600, 601, 609, 610, 611, 612, 614, 616, 617, 618, 619, 620, 622, 623, 624, 627, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 687, 688, 690, 691, 692, 697, 698, 700, 701, 702, 707, 708, 710, 711, 712, 717, 718, 720, 721, 722, 727, 728, 730, 731, 732, 737, 738, 740, 741, 742, 747, 748, 750, 751, 752, 757, 758, 760, 761, 762, 767, 768, 770, 771, 772, 777, 778, 780, 781, 782, 787, 788, 791, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 811, 812, 813, 818, 819, 822, 826, 829, 829, 832, 834, 835, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 880, 881, 884, 886, 887, 888, 889, 890, 891, 896, 897, 898, 900, 901, 902, 903, 908, 909, 910, 912, 913, 914, 914, 917, 919, 920, 921, 927, 928, 929, 930, 931, 932, 933, 938, 939, 940, 942, 947, 948, 949, 950, 951, 952, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 1017, 1018, 1019, 1022, 1024, 1025, 1026, 1027, 1028, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1044, 1045, 1045, 1048, 1050, 1051, 1058, 1059, 1060, 1061, 1062, 1063, 1068, 1069, 1069, 1072, 1074, 1075, 1088, 1089, 1092, 1094, 1095, 1096, 1097, 1098, 1099, 1100, 1110, 1111, 1125, 1130, 1131, 1133, 1138, 1139, 1140, 1141, 1143, 1146, 1147, 1149, 1152, 1153, 1155, 1158, 1159, 1160, 1164, 1166, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1325, 1326, 1327, 1328, 1333, 1334, 1334, 1337, 1339, 1340, 1347, 1348, 1353, 1354, 1355, 1357, 1358, 1359, 1362, 1363, 1363, 1366, 1368, 1369, 1370, 1375, 1376, 1377, 1378, 1385, 1385, 1388, 1390, 1391, 1392, 1397, 1398, 1399, 1400, 1401, 1402, 1410, 1411, 1414, 1416, 1417, 1418, 1420, 1421, 1422, 1429, 1431, 1432, 1433, 1434, 1435, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1461, 1464, 1465, 1466, 1467, 1470, 1472, 1473, 1479, 1480, 1481, 1482, 1485, 1487, 1488, 1495, 1496, 1497, 1498, 1503, 1504, 1505, 1506, 1508, 1509, 1510, 1512, 1515, 1520, 1521, 1522, 1524, 1524, 1527, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1540, 1541, 1543, 1544, 1545, 1547, 1548, 1549, 1557, 1558, 1561, 1563, 1565, 1568, 1572, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1586, 1588, 1589, 1591, 1592, 1593, 1595, 1596, 1597, 1606, 1607, 1608, 1609, 1614, 1615, 1616, 1617, 1619, 1624, 1625, 1626, 1627, 1629, 1634, 1635, 1636, 1637, 1640, 1641, 1642, 1643, 1644, 1645, 1646, 1647, 1648, 1650, 1651, 1664, 1665, 1668, 1670, 1671, 1672, 1673, 1674, 1680, 1681, 1684, 1686, 1687, 1688, 1689, 1690, 1696, 1697, 1725, 1726, 1727, 1732, 1733, 1734, 1735, 1737, 1738, 1739, 1740, 1741, 1746, 1747, 1750, 1751, 1752, 1753, 1754, 1755, 1760, 1761, 1762, 1763, 1766, 1767, 1768, 1770, 1772, 1773, 1774, 1775, 1776, 1777, 1778, 1786, 1787, 1788, 1789, 1794, 1795, 1797, 1798, 1799, 1800, 1804, 1809, 1810, 1812, 1891, 1892, 1893, 1894, 1895, 1896, 1897, 1900, 1904, 1907, 1911, 1912, 1913, 1914, 1916, 1917, 1918, 1919, 1920, 1921, 1922, 1923, 1924, 1926, 1927, 1929, 1930, 1932, 1933, 1934, 1935, 1938, 1939, 1941, 1942, 1944, 1945, 1946, 1947, 1950, 1951, 1953, 1954, 1955, 1957, 1958, 1959, 1960, 1963, 1964, 1966, 1967, 1969, 1970, 1971, 1972, 1975, 1976, 1978, 1979, 1981, 1982, 1983, 1984, 1987, 1988, 1990, 1991, 1993, 1994, 1995, 1996, 1999, 2000, 2002, 2003, 2005, 2006, 2007, 2008, 2011, 2012, 2014, 2015, 2017, 2018, 2019, 2020, 2023, 2024, 2026, 2027, 2029, 2030, 2031, 2032, 2035, 2036, 2038, 2039, 2041, 2042, 2043, 2044, 2047, 2048, 2050, 2051, 2053, 2054, 2055, 2056, 2059, 2060, 2061, 2062, 2064, 2065, 2067, 2071, 2074, 2078, 2079, 2080, 2081, 2083, 2084, 2087, 2089, 2090, 2091, 2092, 2093, 2094, 2095, 2096, 2097, 2098, 2099, 2100, 2101, 2123, 2124, 2125, 2126, 2127, 2128, 2131, 2133, 2134, 2135, 2136, 2137, 2138, 2140, 2142, 2143, 2145, 2146, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2227, 2229, 2232, 2233, 2235, 2238, 2242, 2243, 2248, 2249, 2250, 2251, 2253, 2256, 2257, 2258, 2260, 2263, 2267, 2270, 2274, 2277, 2278, 2283, 2284, 2287, 2288, 2289, 2291, 2292, 2293, 2295, 2298, 2302, 2305, 2306, 2307, 2309, 2312, 2316, 2319, 2320, 2321, 2323, 2326, 2330, 2333, 2336, 2340, 2341, 2342, 2343, 2344, 2351, 2354, 2357, 2361, 2365, 2368, 2371, 2375, 2379, 2382, 2385, 2389, 2393, 2396, 2399, 2403, 2407, 2410, 2413, 2417, 2421, 2424, 2427, 2431, 2435, 2438, 2441, 2445, 2449, 2452, 2455, 2459, 2463, 2466, 2469, 2473, 2477, 2480, 2483, 2487, 2491, 2494, 2497, 2501, 2505, 2508, 2511, 2515, 2519, 2522, 2525, 2529, 2533, 2536, 2539, 2543, 2547, 2550, 2553, 2557, 2561, 2564, 2567, 2571, 2575, 2578, 2581, 2585, 2589, 2592, 2595, 2599, 2603, 2606, 2609, 2613, 2617, 2620, 2623, 2627, 2631, 2634, 2637, 2641, 2645, 2648, 2651, 2655, 2659, 2662, 2665, 2669, 2673, 2676, 2679, 2683, 2687, 2690, 2693, 2697, 2701, 2704, 2707, 2711, 2715, 2718, 2721, 2725, 2729, 2732, 2735, 2739, 2743, 2746, 2749, 2753, 2757, 2760, 2763, 2767, 2771, 2774, 2777, 2781, 2785, 2788, 2791, 2795, 2799, 2802, 2805, 2809, 2813, 2816, 2819, 2823, 2827, 2830, 2833, 2837, 2841, 2844, 2847, 2851, 2855, 2858, 2861, 2865, 2869, 2872, 2875, 2879, 2883, 2886, 2889, 2893, 2897, 2900, 2903, 2907, 2911, 2914, 2917, 2921, 2925, 2928, 2931, 2935, 2939, 2942, 2945, 2949, 2953, 2956, 2959, 2963, 2967, 2970, 2973, 2977, 2981, 2984, 2987, 2991, 2995, 2998, 3001, 3005, 3009, 3012, 3015, 3019, 3023, 3026, 3029, 3033, 3037, 3040, 3043, 3047, 3051, 3054, 3057, 3061, 3065, 3068, 3071, 3075, 3079, 3082, 3085, 3089, 3093, 3096, 3099, 3103, 3107, 3110, 3113, 3117, 3121, 3124, 3127, 3131, 3135, 3138, 3141, 3145, 3149, 3152, 3155, 3159, 3163, 3166, 3169, 3173, 3177, 3180, 3183, 3187, 3191, 3194, 3197, 3201, 3205, 3208, 3211, 3215, 3219, 3222, 3225, 3229, 3233, 3236, 3239, 3243, 3247, 3250, 3253, 3257, 3261, 3264, 3267, 3271, 3275, 3278, 3281, 3285, 3289, 3292, 3295, 3299, 3303, 3306, 3309, 3313, 3317, 3320, 3323, 3327, 3331, 3334, 3337, 3341, 3345, 3348, 3351, 3355, 3359, 3362, 3366};
/* BEGIN LINEINFO 
assign 1 50 254
new 0 50 254
assign 1 52 255
new 0 52 255
assign 1 53 256
new 0 53 256
assign 1 54 257
new 0 54 257
assign 1 55 258
new 0 55 258
assign 1 57 259
new 0 57 259
assign 1 58 260
new 0 58 260
assign 1 59 261
new 0 59 261
assign 1 60 262
new 0 60 262
assign 1 61 263
new 0 61 263
assign 1 62 264
new 0 62 264
assign 1 63 265
new 0 63 265
assign 1 67 266
new 0 67 266
assign 1 69 267
new 1 69 267
assign 1 70 268
ntypesGet 0 70 268
assign 1 71 269
twtokGet 0 71 269
assign 1 72 270
new 0 72 270
assign 1 72 271
new 1 72 271
assign 1 75 272
new 0 75 272
assign 1 78 273
new 0 78 273
assign 1 79 274
new 0 79 274
assign 1 80 275
new 0 80 275
assign 1 86 276
new 0 86 276
assign 1 87 277
new 0 87 277
assign 1 88 278
new 0 88 278
assign 1 89 279
new 0 89 279
assign 1 90 280
new 0 90 280
assign 1 90 281
new 1 90 281
assign 1 97 293
def 1 97 298
assign 1 97 299
new 0 97 299
assign 1 97 300
equals 1 97 300
assign 1 0 302
assign 1 97 305
new 0 97 305
assign 1 97 306
ends 1 97 306
assign 1 0 308
assign 1 0 311
assign 1 0 315
assign 1 0 318
assign 1 0 322
assign 1 98 325
new 0 98 325
return 1 98 326
assign 1 100 328
new 0 100 328
return 1 100 329
assign 1 104 335
new 0 104 335
assign 1 104 336
new 0 104 336
assign 1 104 337
swap 2 104 337
return 1 104 338
assign 1 108 345
new 0 108 345
assign 1 108 346
argsGet 0 108 346
assign 1 109 347
new 0 109 347
assign 1 109 348
main 1 109 348
exit 1 109 349
assign 1 113 361
assign 1 114 362
new 1 114 362
assign 1 115 363
new 0 115 363
assign 1 115 364
new 0 115 364
assign 1 115 365
get 2 115 365
assign 1 115 366
firstGet 0 115 366
assign 1 115 367
new 1 115 367
assign 1 116 368
new 0 116 368
assign 1 116 371
lesser 1 116 376
assign 1 117 377
go 0 117 377
incrementValue 0 116 378
return 1 119 384
assign 1 123 392
new 0 123 392
config 0 124 393
assign 1 125 394
new 0 125 394
assign 1 127 396
new 0 127 396
assign 1 128 397
doWhat 0 128 397
assign 1 129 398
new 0 129 398
assign 1 131 402
toString 0 131 402
assign 1 132 403
new 0 132 403
assign 1 133 404
new 0 133 404
assign 1 133 405
add 1 133 405
assign 1 134 406
new 0 134 406
assign 1 0 409
assign 1 0 413
assign 1 0 416
print 0 137 420
return 1 139 422
assign 1 143 428
nameGet 0 143 428
assign 1 143 429
new 0 143 429
assign 1 143 430
equals 1 143 430
return 1 145 433
assign 1 150 576
new 0 150 576
assign 1 152 577
new 0 152 577
assign 1 153 578
get 1 153 578
assign 1 153 579
def 1 153 584
assign 1 154 585
get 1 154 585
assign 1 154 586
iteratorGet 0 0 586
assign 1 154 589
hasNextGet 0 154 589
assign 1 154 591
nextGet 0 154 591
assign 1 155 592
has 1 155 592
assign 1 155 593
not 0 155 598
put 1 156 599
assign 1 157 600
new 1 157 600
addFile 1 157 601
assign 1 162 609
new 0 162 609
assign 1 162 610
nameGet 0 162 610
assign 1 162 611
new 0 162 611
assign 1 162 612
equals 1 162 612
preProcessorSet 1 163 614
assign 1 165 616
new 0 165 616
assign 1 165 617
get 1 165 617
assign 1 165 618
firstGet 0 165 618
assign 1 166 619
new 0 166 619
assign 1 166 620
has 1 166 620
assign 1 167 622
new 0 167 622
assign 1 167 623
get 1 167 623
assign 1 167 624
firstGet 0 167 624
assign 1 169 627
assign 1 171 629
new 0 171 629
assign 1 171 630
new 0 171 630
assign 1 171 631
get 2 171 631
assign 1 171 632
firstGet 0 171 632
assign 1 171 633
new 1 171 633
assign 1 171 634
pathGet 0 171 634
addStep 1 172 635
assign 1 173 636
new 0 173 636
addStep 1 173 637
assign 1 174 638
new 0 174 638
assign 1 174 639
new 0 174 639
assign 1 174 640
get 2 174 640
assign 1 174 641
firstGet 0 174 641
assign 1 174 642
new 1 174 642
assign 1 174 643
pathGet 0 174 643
assign 1 175 644
new 0 175 644
assign 1 175 645
new 0 175 645
assign 1 175 646
nameGet 0 175 646
assign 1 175 647
get 2 175 647
assign 1 175 648
firstGet 0 175 648
assign 1 175 649
new 1 175 649
assign 1 176 650
new 0 176 650
assign 1 176 651
nameGet 0 176 651
assign 1 176 652
get 2 176 652
assign 1 176 653
firstGet 0 176 653
assign 1 176 654
new 1 176 654
assign 1 177 655
new 0 177 655
assign 1 177 656
new 0 177 656
assign 1 177 657
get 2 177 657
assign 1 177 658
firstGet 0 177 658
assign 1 177 659
new 1 177 659
assign 1 178 660
new 0 178 660
assign 1 178 661
new 0 178 661
assign 1 178 662
get 2 178 662
assign 1 178 663
firstGet 0 178 663
assign 1 178 664
new 1 178 664
assign 1 179 665
new 0 179 665
assign 1 179 666
new 0 179 666
assign 1 179 667
get 2 179 667
assign 1 179 668
firstGet 0 179 668
assign 1 179 669
new 1 179 669
assign 1 180 670
new 0 180 670
assign 1 180 671
get 1 180 671
assign 1 181 672
new 0 181 672
assign 1 181 673
get 1 181 673
assign 1 183 674
new 0 183 674
assign 1 183 675
get 1 183 675
assign 1 183 676
firstGet 0 183 676
assign 1 184 677
new 0 184 677
assign 1 184 678
get 1 184 678
assign 1 184 679
firstGet 0 184 679
assign 1 185 680
new 0 185 680
assign 1 185 681
get 1 185 681
assign 1 186 682
undef 1 186 687
assign 1 187 688
new 0 187 688
assign 1 189 690
new 0 189 690
assign 1 189 691
get 1 189 691
assign 1 190 692
undef 1 190 697
assign 1 191 698
new 0 191 698
assign 1 193 700
new 0 193 700
assign 1 193 701
get 1 193 701
assign 1 194 702
undef 1 194 707
assign 1 195 708
new 0 195 708
assign 1 197 710
new 0 197 710
assign 1 197 711
get 1 197 711
assign 1 198 712
undef 1 198 717
assign 1 199 718
new 0 199 718
assign 1 201 720
new 0 201 720
assign 1 201 721
get 1 201 721
assign 1 202 722
undef 1 202 727
assign 1 203 728
new 0 203 728
assign 1 205 730
new 0 205 730
assign 1 205 731
get 1 205 731
assign 1 206 732
undef 1 206 737
assign 1 207 738
new 0 207 738
assign 1 209 740
new 0 209 740
assign 1 209 741
get 1 209 741
assign 1 210 742
undef 1 210 747
assign 1 211 748
new 0 211 748
assign 1 213 750
new 0 213 750
assign 1 213 751
get 1 213 751
assign 1 214 752
undef 1 214 757
assign 1 215 758
new 0 215 758
assign 1 217 760
new 0 217 760
assign 1 217 761
get 1 217 761
assign 1 218 762
undef 1 218 767
assign 1 219 768
new 0 219 768
assign 1 221 770
new 0 221 770
assign 1 221 771
get 1 221 771
assign 1 222 772
def 1 222 777
assign 1 223 778
firstGet 0 223 778
assign 1 225 780
new 0 225 780
assign 1 225 781
get 1 225 781
assign 1 226 782
def 1 226 787
assign 1 227 788
firstGet 0 227 788
assign 1 229 791
new 0 229 791
assign 1 231 793
new 0 231 793
assign 1 231 794
new 0 231 794
assign 1 231 795
isTrue 2 231 795
assign 1 232 796
new 0 232 796
assign 1 232 797
new 0 232 797
assign 1 232 798
isTrue 2 232 798
assign 1 233 799
new 0 233 799
assign 1 233 800
isTrue 1 233 800
assign 1 234 801
new 0 234 801
assign 1 234 802
isTrue 1 234 802
assign 1 235 803
new 0 235 803
assign 1 236 804
new 0 236 804
assign 1 236 805
get 1 236 805
assign 1 237 806
def 1 237 811
assign 1 237 812
isEmptyGet 0 237 812
assign 1 237 813
not 0 237 818
assign 1 0 819
assign 1 0 822
assign 1 0 826
assign 1 238 829
linkedListIteratorGet 0 0 829
assign 1 238 832
hasNextGet 0 238 832
assign 1 238 834
nextGet 0 238 834
put 1 239 835
assign 1 242 842
new 0 242 842
assign 1 242 843
isTrue 1 242 843
assign 1 243 844
new 0 243 844
assign 1 243 845
isTrue 1 243 845
assign 1 244 846
new 0 244 846
assign 1 244 847
isTrue 1 244 847
assign 1 245 848
new 0 245 848
assign 1 245 849
isTrue 1 245 849
assign 1 246 850
new 0 246 850
assign 1 246 851
new 0 246 851
assign 1 246 852
isTrue 2 246 852
assign 1 247 853
new 0 247 853
assign 1 247 854
get 1 247 854
assign 1 248 855
new 0 248 855
assign 1 248 856
get 1 248 856
assign 1 249 857
new 0 249 857
assign 1 249 858
new 0 249 858
assign 1 249 859
get 2 249 859
assign 1 249 860
firstGet 0 249 860
assign 1 250 861
new 0 250 861
assign 1 250 862
new 0 250 862
assign 1 250 863
get 2 250 863
assign 1 250 864
firstGet 0 250 864
assign 1 251 865
new 0 251 865
assign 1 251 866
add 1 251 866
assign 1 251 867
new 0 251 867
assign 1 251 868
get 2 251 868
assign 1 251 869
firstGet 0 251 869
assign 1 252 870
new 0 252 870
assign 1 253 871
new 0 253 871
assign 1 254 872
new 0 254 872
assign 1 255 873
new 0 255 873
assign 1 256 874
new 0 256 874
assign 1 259 875
def 1 259 880
assign 1 260 881
firstGet 0 260 881
assign 1 262 884
new 0 262 884
assign 1 269 886
new 0 269 886
assign 1 269 887
add 1 269 887
assign 1 269 888
nameGet 0 269 888
assign 1 269 889
add 1 269 889
assign 1 269 890
get 1 269 890
assign 1 270 891
def 1 270 896
assign 1 271 897
orderedGet 0 271 897
addAll 1 271 898
assign 1 274 900
new 0 274 900
assign 1 274 901
add 1 274 901
assign 1 274 902
get 1 274 902
assign 1 275 903
def 1 275 908
assign 1 276 909
orderedGet 0 276 909
addAll 1 276 910
assign 1 279 912
new 0 279 912
assign 1 280 913
orderedGet 0 280 913
assign 1 280 914
iteratorGet 0 0 914
assign 1 280 917
hasNextGet 0 280 917
assign 1 280 919
nextGet 0 280 919
assign 1 281 920
new 1 281 920
addValue 1 281 921
assign 1 283 927
newlineGet 0 283 927
assign 1 284 928
assign 1 285 929
new 1 285 929
assign 1 287 930
copy 0 287 930
assign 1 288 931
fileGet 0 288 931
assign 1 288 932
existsGet 0 288 932
assign 1 288 933
not 0 288 938
assign 1 289 939
fileGet 0 289 939
makeDirs 0 289 940
assign 1 291 942
def 1 291 947
assign 1 292 948
new 1 292 948
assign 1 292 949
readerGet 0 292 949
assign 1 293 950
open 0 293 950
assign 1 293 951
readString 0 293 951
close 0 294 952
assign 1 300 966
classNameGet 0 300 966
assign 1 301 967
add 1 301 967
assign 1 301 968
new 0 301 968
assign 1 301 969
add 1 301 969
assign 1 301 970
toString 0 301 970
assign 1 301 971
add 1 301 971
assign 1 302 972
add 1 302 972
assign 1 302 973
new 0 302 973
assign 1 302 974
add 1 302 974
assign 1 302 975
toString 0 302 975
assign 1 302 976
add 1 302 976
return 1 303 977
assign 1 307 1017
new 0 307 1017
assign 1 308 1018
classesGet 0 308 1018
assign 1 308 1019
valueIteratorGet 0 308 1019
assign 1 308 1022
hasNextGet 0 308 1022
assign 1 309 1024
nextGet 0 309 1024
assign 1 310 1025
shouldEmitGet 0 310 1025
assign 1 310 1026
heldGet 0 310 1026
assign 1 310 1027
fromFileGet 0 310 1027
assign 1 310 1028
has 1 310 1028
assign 1 311 1030
heldGet 0 311 1030
assign 1 311 1031
namepathGet 0 311 1031
assign 1 311 1032
toString 0 311 1032
put 1 311 1033
assign 1 312 1034
usedByGet 0 312 1034
assign 1 312 1035
heldGet 0 312 1035
assign 1 312 1036
namepathGet 0 312 1036
assign 1 312 1037
toString 0 312 1037
assign 1 312 1038
get 1 312 1038
assign 1 313 1039
def 1 313 1044
assign 1 314 1045
setIteratorGet 0 0 1045
assign 1 314 1048
hasNextGet 0 314 1048
assign 1 314 1050
nextGet 0 314 1050
put 1 315 1051
assign 1 318 1058
subClassesGet 0 318 1058
assign 1 318 1059
heldGet 0 318 1059
assign 1 318 1060
namepathGet 0 318 1060
assign 1 318 1061
toString 0 318 1061
assign 1 318 1062
get 1 318 1062
assign 1 319 1063
def 1 319 1068
assign 1 320 1069
setIteratorGet 0 0 1069
assign 1 320 1072
hasNextGet 0 320 1072
assign 1 320 1074
nextGet 0 320 1074
put 1 321 1075
assign 1 326 1088
classesGet 0 326 1088
assign 1 326 1089
valueIteratorGet 0 326 1089
assign 1 326 1092
hasNextGet 0 326 1092
assign 1 327 1094
nextGet 0 327 1094
assign 1 328 1095
heldGet 0 328 1095
assign 1 328 1096
heldGet 0 328 1096
assign 1 328 1097
namepathGet 0 328 1097
assign 1 328 1098
toString 0 328 1098
assign 1 328 1099
has 1 328 1099
shouldWriteSet 1 328 1100
assign 1 335 1110
new 0 335 1110
return 1 335 1111
assign 1 339 1125
def 1 339 1130
return 1 340 1131
assign 1 345 1133
def 1 345 1138
assign 1 346 1139
firstGet 0 346 1139
assign 1 347 1140
new 0 347 1140
assign 1 347 1141
equals 1 347 1141
assign 1 348 1143
new 1 348 1143
assign 1 349 1146
new 0 349 1146
assign 1 349 1147
equals 1 349 1147
assign 1 350 1149
new 1 350 1149
assign 1 351 1152
new 0 351 1152
assign 1 351 1153
equals 1 351 1153
assign 1 352 1155
new 1 352 1155
assign 1 354 1158
new 0 354 1158
assign 1 354 1159
new 1 354 1159
throw 1 354 1160
return 1 356 1164
return 1 358 1166
assign 1 362 1185
apNew 1 362 1185
assign 1 364 1186
new 0 364 1186
assign 1 364 1187
add 1 364 1187
print 0 364 1188
assign 1 365 1189
new 0 365 1189
assign 1 365 1190
now 0 365 1190
assign 1 366 1191
fileGet 0 366 1191
assign 1 366 1192
readerGet 0 366 1192
assign 1 366 1193
open 0 366 1193
assign 1 367 1194
new 0 367 1194
assign 1 367 1195
deserialize 1 367 1195
close 0 368 1196
assign 1 369 1197
synClassesGet 0 369 1197
addValue 1 369 1198
assign 1 370 1199
new 0 370 1199
assign 1 370 1200
now 0 370 1200
assign 1 370 1201
subtract 1 370 1201
assign 1 371 1202
new 0 371 1202
assign 1 371 1203
add 1 371 1203
print 0 371 1204
assign 1 377 1325
new 0 377 1325
assign 1 377 1326
now 0 377 1326
assign 1 378 1327
new 0 378 1327
assign 1 379 1328
def 1 379 1333
assign 1 380 1334
linkedListIteratorGet 0 0 1334
assign 1 380 1337
hasNextGet 0 380 1337
assign 1 380 1339
nextGet 0 380 1339
loadSyns 1 381 1340
assign 1 384 1347
emitterGet 0 384 1347
assign 1 385 1348
def 1 385 1353
assign 1 386 1354
new 4 386 1354
put 1 387 1355
assign 1 389 1357
new 0 389 1357
assign 1 389 1358
add 1 389 1358
print 0 389 1359
assign 1 392 1362
new 0 392 1362
assign 1 394 1363
iteratorGet 0 0 1363
assign 1 394 1366
hasNextGet 0 394 1366
assign 1 394 1368
nextGet 0 394 1368
assign 1 395 1369
has 1 395 1369
assign 1 395 1370
not 0 395 1375
put 1 396 1376
assign 1 397 1377
new 2 397 1377
addValue 1 398 1378
assign 1 401 1385
iteratorGet 0 0 1385
assign 1 401 1388
hasNextGet 0 401 1388
assign 1 401 1390
nextGet 0 401 1390
assign 1 402 1391
has 1 402 1391
assign 1 402 1392
not 0 402 1397
put 1 403 1398
assign 1 404 1399
new 2 404 1399
addValue 1 405 1400
assign 1 406 1401
libNameGet 0 406 1401
put 1 406 1402
assign 1 411 1410
new 0 411 1410
assign 1 412 1411
iteratorGet 0 412 1411
assign 1 412 1414
hasNextGet 0 412 1414
assign 1 413 1416
nextGet 0 413 1416
assign 1 415 1417
toString 0 415 1417
assign 1 415 1418
has 1 415 1418
assign 1 416 1420
toString 0 416 1420
put 1 416 1421
doParse 1 417 1422
buildSyns 1 420 1429
assign 1 423 1431
new 0 423 1431
assign 1 423 1432
now 0 423 1432
assign 1 423 1433
subtract 1 423 1433
assign 1 426 1434
emitCommonGet 0 426 1434
assign 1 426 1435
def 1 426 1440
assign 1 428 1441
new 0 428 1441
assign 1 428 1442
now 0 428 1442
assign 1 429 1443
emitCommonGet 0 429 1443
doEmit 0 429 1444
assign 1 430 1445
new 0 430 1445
assign 1 430 1446
now 0 430 1446
assign 1 430 1447
subtract 1 430 1447
assign 1 431 1448
new 0 431 1448
assign 1 431 1449
now 0 431 1449
assign 1 431 1450
subtract 1 431 1450
assign 1 432 1451
new 0 432 1451
assign 1 432 1452
add 1 432 1452
print 0 432 1453
assign 1 433 1454
new 0 433 1454
assign 1 433 1455
add 1 433 1455
print 0 433 1456
assign 1 434 1457
new 0 434 1457
assign 1 434 1458
add 1 434 1458
print 0 434 1459
assign 1 435 1460
new 0 435 1460
return 1 435 1461
setClassesToWrite 0 438 1464
libnameInfoGet 0 439 1465
assign 1 441 1466
classesGet 0 441 1466
assign 1 441 1467
valueIteratorGet 0 441 1467
assign 1 441 1470
hasNextGet 0 441 1470
assign 1 442 1472
nextGet 0 442 1472
doEmit 1 443 1473
emitMain 0 445 1479
emitCUInit 0 446 1480
assign 1 447 1481
classesGet 0 447 1481
assign 1 447 1482
valueIteratorGet 0 447 1482
assign 1 447 1485
hasNextGet 0 447 1485
assign 1 448 1487
nextGet 0 448 1487
emitSyn 1 449 1488
assign 1 453 1495
new 0 453 1495
assign 1 453 1496
now 0 453 1496
assign 1 453 1497
subtract 1 453 1497
assign 1 454 1498
def 1 454 1503
assign 1 455 1504
new 0 455 1504
assign 1 455 1505
add 1 455 1505
print 0 455 1506
assign 1 457 1508
new 0 457 1508
assign 1 457 1509
add 1 457 1509
print 0 457 1510
prepMake 1 460 1512
assign 1 464 1515
not 0 464 1520
make 1 465 1521
deployLibrary 1 466 1522
assign 1 468 1524
linkedListIteratorGet 0 0 1524
assign 1 468 1527
hasNextGet 0 468 1527
assign 1 468 1529
nextGet 0 468 1529
assign 1 469 1530
libnameInfoGet 0 469 1530
assign 1 469 1531
unitShlibGet 0 469 1531
assign 1 470 1532
emitPathGet 0 470 1532
assign 1 470 1533
copy 0 470 1533
assign 1 471 1534
stepsGet 0 471 1534
assign 1 471 1535
lastGet 0 471 1535
addStep 1 471 1536
assign 1 472 1537
fileGet 0 472 1537
assign 1 472 1538
existsGet 0 472 1538
assign 1 473 1540
fileGet 0 473 1540
delete 0 473 1541
assign 1 475 1543
fileGet 0 475 1543
assign 1 475 1544
existsGet 0 475 1544
assign 1 475 1545
not 0 475 1545
assign 1 476 1547
fileGet 0 476 1547
assign 1 476 1548
fileGet 0 476 1548
deployFile 2 476 1549
assign 1 480 1557
iteratorGet 0 480 1557
assign 1 481 1558
iteratorGet 0 481 1558
assign 1 483 1561
hasNextGet 0 483 1561
assign 1 483 1563
hasNextGet 0 483 1563
assign 1 0 1565
assign 1 0 1568
assign 1 0 1572
assign 1 484 1575
nextGet 0 484 1575
assign 1 484 1576
apNew 1 484 1576
assign 1 485 1577
emitPathGet 0 485 1577
assign 1 485 1578
copy 0 485 1578
assign 1 485 1579
toString 0 485 1579
assign 1 485 1580
new 0 485 1580
assign 1 485 1581
add 1 485 1581
assign 1 485 1582
nextGet 0 485 1582
assign 1 485 1583
add 1 485 1583
assign 1 485 1584
apNew 1 485 1584
assign 1 487 1585
fileGet 0 487 1585
assign 1 487 1586
existsGet 0 487 1586
assign 1 488 1588
fileGet 0 488 1588
delete 0 488 1589
assign 1 490 1591
fileGet 0 490 1591
assign 1 490 1592
existsGet 0 490 1592
assign 1 490 1593
not 0 490 1593
assign 1 491 1595
fileGet 0 491 1595
assign 1 491 1596
fileGet 0 491 1596
deployFile 2 491 1597
assign 1 496 1606
new 0 496 1606
assign 1 496 1607
now 0 496 1607
assign 1 496 1608
subtract 1 496 1608
assign 1 498 1609
def 1 498 1614
assign 1 499 1615
new 0 499 1615
assign 1 499 1616
add 1 499 1616
print 0 499 1617
assign 1 501 1619
def 1 501 1624
assign 1 502 1625
new 0 502 1625
assign 1 502 1626
add 1 502 1626
print 0 502 1627
assign 1 504 1629
def 1 504 1634
assign 1 505 1635
new 0 505 1635
assign 1 505 1636
add 1 505 1636
print 0 505 1637
assign 1 509 1640
new 0 509 1640
print 0 509 1641
assign 1 510 1642
run 2 510 1642
assign 1 511 1643
new 0 511 1643
assign 1 511 1644
add 1 511 1644
assign 1 511 1645
new 0 511 1645
assign 1 511 1646
add 1 511 1646
print 0 511 1647
return 1 512 1648
assign 1 514 1650
new 0 514 1650
return 1 514 1651
assign 1 518 1664
justParsedGet 0 518 1664
assign 1 518 1665
valueIteratorGet 0 518 1665
assign 1 518 1668
hasNextGet 0 518 1668
assign 1 519 1670
nextGet 0 519 1670
assign 1 520 1671
heldGet 0 520 1671
libNameSet 1 520 1672
assign 1 521 1673
getSyn 2 521 1673
libNameSet 1 522 1674
assign 1 524 1680
justParsedGet 0 524 1680
assign 1 524 1681
valueIteratorGet 0 524 1681
assign 1 524 1684
hasNextGet 0 524 1684
assign 1 525 1686
nextGet 0 525 1686
assign 1 526 1687
heldGet 0 526 1687
assign 1 526 1688
synGet 0 526 1688
checkInheritance 2 527 1689
integrate 1 528 1690
assign 1 530 1696
new 0 530 1696
justParsedSet 1 530 1697
assign 1 534 1725
heldGet 0 534 1725
assign 1 534 1726
synGet 0 534 1726
assign 1 534 1727
def 1 534 1732
assign 1 535 1733
heldGet 0 535 1733
assign 1 535 1734
synGet 0 535 1734
return 1 535 1735
assign 1 537 1737
heldGet 0 537 1737
libNameSet 1 537 1738
assign 1 538 1739
heldGet 0 538 1739
assign 1 538 1740
extendsGet 0 538 1740
assign 1 538 1741
undef 1 538 1746
assign 1 539 1747
new 1 539 1747
assign 1 541 1750
classesGet 0 541 1750
assign 1 541 1751
heldGet 0 541 1751
assign 1 541 1752
extendsGet 0 541 1752
assign 1 541 1753
toString 0 541 1753
assign 1 541 1754
get 1 541 1754
assign 1 543 1755
def 1 543 1760
assign 1 544 1761
heldGet 0 544 1761
libNameSet 1 544 1762
assign 1 545 1763
getSyn 2 545 1763
assign 1 549 1766
heldGet 0 549 1766
assign 1 549 1767
extendsGet 0 549 1767
assign 1 549 1768
getSynNp 1 549 1768
assign 1 551 1770
new 2 551 1770
assign 1 553 1772
heldGet 0 553 1772
synSet 1 553 1773
assign 1 554 1774
heldGet 0 554 1774
assign 1 554 1775
namepathGet 0 554 1775
assign 1 554 1776
toString 0 554 1776
addSynClass 2 554 1777
return 1 555 1778
assign 1 559 1786
toString 0 559 1786
assign 1 560 1787
synClassesGet 0 560 1787
assign 1 560 1788
get 1 560 1788
assign 1 561 1789
def 1 561 1794
return 1 562 1795
assign 1 568 1797
emitterGet 0 568 1797
assign 1 568 1798
loadSyn 1 568 1798
addSynClass 2 569 1799
return 1 570 1800
assign 1 577 1804
undef 1 577 1809
assign 1 578 1810
new 1 578 1810
return 1 580 1812
assign 1 585 1891
new 1 585 1891
assign 1 586 1892
new 0 586 1892
assign 1 587 1893
emitterGet 0 587 1893
assign 1 588 1894
assign 1 589 1895
new 0 589 1895
assign 1 590 1896
shouldEmitGet 0 590 1896
put 1 590 1897
assign 1 0 1900
assign 1 0 1904
assign 1 0 1907
assign 1 593 1911
new 0 593 1911
assign 1 593 1912
toString 0 593 1912
assign 1 593 1913
add 1 593 1913
print 0 593 1914
assign 1 595 1916
assign 1 597 1917
fileGet 0 597 1917
assign 1 597 1918
readerGet 0 597 1918
assign 1 597 1919
open 0 597 1919
assign 1 597 1920
readBuffer 1 597 1920
assign 1 598 1921
fileGet 0 598 1921
assign 1 598 1922
readerGet 0 598 1922
close 0 598 1923
assign 1 599 1924
tokenize 1 599 1924
assign 1 603 1926
new 0 603 1926
echo 0 603 1927
assign 1 605 1929
outermostGet 0 605 1929
nodify 2 605 1930
assign 1 607 1932
new 0 607 1932
print 0 607 1933
assign 1 608 1934
new 2 608 1934
traverse 1 608 1935
assign 1 612 1938
new 0 612 1938
echo 0 612 1939
assign 1 614 1941
new 0 614 1941
traverse 1 614 1942
assign 1 616 1944
new 0 616 1944
print 0 616 1945
assign 1 617 1946
new 2 617 1946
traverse 1 617 1947
assign 1 620 1950
new 0 620 1950
echo 0 620 1951
assign 1 623 1953
new 0 623 1953
traverse 1 623 1954
contain 0 624 1955
assign 1 626 1957
new 0 626 1957
print 0 626 1958
assign 1 627 1959
new 2 627 1959
traverse 1 627 1960
assign 1 631 1963
new 0 631 1963
echo 0 631 1964
assign 1 633 1966
new 0 633 1966
traverse 1 633 1967
assign 1 635 1969
new 0 635 1969
print 0 635 1970
assign 1 636 1971
new 2 636 1971
traverse 1 636 1972
assign 1 640 1975
new 0 640 1975
echo 0 640 1976
assign 1 642 1978
new 0 642 1978
traverse 1 642 1979
assign 1 644 1981
new 0 644 1981
print 0 644 1982
assign 1 645 1983
new 2 645 1983
traverse 1 645 1984
assign 1 649 1987
new 0 649 1987
echo 0 649 1988
assign 1 651 1990
new 0 651 1990
traverse 1 651 1991
assign 1 653 1993
new 0 653 1993
print 0 653 1994
assign 1 654 1995
new 2 654 1995
traverse 1 654 1996
assign 1 658 1999
new 0 658 1999
echo 0 658 2000
assign 1 660 2002
new 0 660 2002
traverse 1 660 2003
assign 1 662 2005
new 0 662 2005
print 0 662 2006
assign 1 663 2007
new 2 663 2007
traverse 1 663 2008
assign 1 667 2011
new 0 667 2011
echo 0 667 2012
assign 1 669 2014
new 0 669 2014
traverse 1 669 2015
assign 1 671 2017
new 0 671 2017
print 0 671 2018
assign 1 672 2019
new 2 672 2019
traverse 1 672 2020
assign 1 676 2023
new 0 676 2023
echo 0 676 2024
assign 1 678 2026
new 0 678 2026
traverse 1 678 2027
assign 1 680 2029
new 0 680 2029
print 0 680 2030
assign 1 681 2031
new 2 681 2031
traverse 1 681 2032
assign 1 685 2035
new 0 685 2035
echo 0 685 2036
assign 1 687 2038
new 0 687 2038
traverse 1 687 2039
assign 1 689 2041
new 0 689 2041
print 0 689 2042
assign 1 690 2043
new 2 690 2043
traverse 1 690 2044
assign 1 693 2047
new 0 693 2047
echo 0 693 2048
assign 1 695 2050
new 0 695 2050
traverse 1 695 2051
assign 1 697 2053
new 0 697 2053
print 0 697 2054
assign 1 698 2055
new 2 698 2055
traverse 1 698 2056
assign 1 702 2059
new 0 702 2059
echo 0 702 2060
assign 1 703 2061
new 0 703 2061
print 0 703 2062
assign 1 705 2064
new 0 705 2064
traverse 1 705 2065
assign 1 0 2067
assign 1 0 2071
assign 1 0 2074
assign 1 707 2078
new 0 707 2078
print 0 707 2079
assign 1 708 2080
new 2 708 2080
traverse 1 708 2081
assign 1 710 2083
classesGet 0 710 2083
assign 1 710 2084
valueIteratorGet 0 710 2084
assign 1 710 2087
hasNextGet 0 710 2087
assign 1 711 2089
nextGet 0 711 2089
assign 1 713 2090
transUnitGet 0 713 2090
assign 1 714 2091
new 1 714 2091
assign 1 715 2092
TRANSUNITGet 0 715 2092
typenameSet 1 715 2093
assign 1 716 2094
new 0 716 2094
assign 1 717 2095
heldGet 0 717 2095
assign 1 717 2096
emitsGet 0 717 2096
emitsSet 1 717 2097
heldSet 1 718 2098
delete 0 719 2099
addValue 1 720 2100
copyLoc 1 721 2101
reInitContained 0 727 2123
assign 1 728 2124
containedGet 0 728 2124
assign 1 729 2125
new 0 729 2125
assign 1 730 2126
new 0 730 2126
assign 1 730 2127
crGet 0 730 2127
assign 1 731 2128
linkedListIteratorGet 0 731 2128
assign 1 731 2131
hasNextGet 0 731 2131
assign 1 732 2133
new 1 732 2133
assign 1 733 2134
nextGet 0 733 2134
heldSet 1 733 2135
nlcSet 1 734 2136
assign 1 735 2137
heldGet 0 735 2137
assign 1 735 2138
equals 1 735 2138
assign 1 736 2140
increment 0 736 2140
assign 1 738 2142
heldGet 0 738 2142
assign 1 738 2143
notEquals 1 738 2143
addValue 1 739 2145
containerSet 1 740 2146
assign 1 747 2201
new 0 747 2201
fromString 1 748 2202
assign 1 750 2203
new 1 750 2203
assign 1 751 2204
NAMEPATHGet 0 751 2204
typenameSet 1 751 2205
heldSet 1 752 2206
copyLoc 1 753 2207
assign 1 755 2208
new 0 755 2208
assign 1 756 2209
new 0 756 2209
nameSet 1 756 2210
assign 1 757 2211
new 0 757 2211
wasBoundSet 1 757 2212
assign 1 758 2213
new 0 758 2213
boundSet 1 758 2214
assign 1 759 2215
new 0 759 2215
isConstructSet 1 759 2216
assign 1 760 2217
new 0 760 2217
isLiteralSet 1 760 2218
assign 1 761 2219
heldGet 0 761 2219
literalValueSet 1 761 2220
addValue 1 763 2221
assign 1 765 2222
CALLGet 0 765 2222
typenameSet 1 765 2223
heldSet 1 766 2224
resolveNp 0 768 2225
assign 1 770 2226
new 0 770 2226
assign 1 770 2227
equals 1 770 2227
assign 1 0 2229
assign 1 770 2232
new 0 770 2232
assign 1 770 2233
equals 1 770 2233
assign 1 0 2235
assign 1 0 2238
assign 1 771 2242
priorPeerGet 0 771 2242
assign 1 772 2243
def 1 772 2248
assign 1 772 2249
typenameGet 0 772 2249
assign 1 772 2250
SUBTRACTGet 0 772 2250
assign 1 772 2251
equals 1 772 2251
assign 1 0 2253
assign 1 772 2256
typenameGet 0 772 2256
assign 1 772 2257
ADDGet 0 772 2257
assign 1 772 2258
equals 1 772 2258
assign 1 0 2260
assign 1 0 2263
assign 1 0 2267
assign 1 0 2270
assign 1 0 2274
assign 1 773 2277
priorPeerGet 0 773 2277
assign 1 774 2278
undef 1 774 2283
assign 1 0 2284
assign 1 774 2287
typenameGet 0 774 2287
assign 1 774 2288
CALLGet 0 774 2288
assign 1 774 2289
notEquals 1 774 2289
assign 1 774 2291
typenameGet 0 774 2291
assign 1 774 2292
IDGet 0 774 2292
assign 1 774 2293
notEquals 1 774 2293
assign 1 0 2295
assign 1 0 2298
assign 1 0 2302
assign 1 774 2305
typenameGet 0 774 2305
assign 1 774 2306
VARGet 0 774 2306
assign 1 774 2307
notEquals 1 774 2307
assign 1 0 2309
assign 1 0 2312
assign 1 0 2316
assign 1 774 2319
typenameGet 0 774 2319
assign 1 774 2320
ACCESSORGet 0 774 2320
assign 1 774 2321
notEquals 1 774 2321
assign 1 0 2323
assign 1 0 2326
assign 1 0 2330
assign 1 0 2333
assign 1 0 2336
assign 1 780 2340
heldGet 0 780 2340
assign 1 780 2341
literalValueGet 0 780 2341
assign 1 780 2342
add 1 780 2342
literalValueSet 1 780 2343
delete 0 781 2344
return 1 0 2351
return 1 0 2354
assign 1 0 2357
assign 1 0 2361
return 1 0 2365
return 1 0 2368
assign 1 0 2371
assign 1 0 2375
return 1 0 2379
return 1 0 2382
assign 1 0 2385
assign 1 0 2389
return 1 0 2393
return 1 0 2396
assign 1 0 2399
assign 1 0 2403
return 1 0 2407
return 1 0 2410
assign 1 0 2413
assign 1 0 2417
return 1 0 2421
return 1 0 2424
assign 1 0 2427
assign 1 0 2431
return 1 0 2435
return 1 0 2438
assign 1 0 2441
assign 1 0 2445
return 1 0 2449
return 1 0 2452
assign 1 0 2455
assign 1 0 2459
return 1 0 2463
return 1 0 2466
assign 1 0 2469
assign 1 0 2473
return 1 0 2477
return 1 0 2480
assign 1 0 2483
assign 1 0 2487
return 1 0 2491
return 1 0 2494
assign 1 0 2497
assign 1 0 2501
return 1 0 2505
return 1 0 2508
assign 1 0 2511
assign 1 0 2515
return 1 0 2519
return 1 0 2522
assign 1 0 2525
assign 1 0 2529
return 1 0 2533
return 1 0 2536
assign 1 0 2539
assign 1 0 2543
return 1 0 2547
return 1 0 2550
assign 1 0 2553
assign 1 0 2557
return 1 0 2561
return 1 0 2564
assign 1 0 2567
assign 1 0 2571
return 1 0 2575
return 1 0 2578
assign 1 0 2581
assign 1 0 2585
return 1 0 2589
return 1 0 2592
assign 1 0 2595
assign 1 0 2599
return 1 0 2603
return 1 0 2606
assign 1 0 2609
assign 1 0 2613
return 1 0 2617
return 1 0 2620
assign 1 0 2623
assign 1 0 2627
return 1 0 2631
return 1 0 2634
assign 1 0 2637
assign 1 0 2641
return 1 0 2645
return 1 0 2648
assign 1 0 2651
assign 1 0 2655
return 1 0 2659
return 1 0 2662
assign 1 0 2665
assign 1 0 2669
return 1 0 2673
return 1 0 2676
assign 1 0 2679
assign 1 0 2683
return 1 0 2687
return 1 0 2690
assign 1 0 2693
assign 1 0 2697
return 1 0 2701
return 1 0 2704
assign 1 0 2707
assign 1 0 2711
return 1 0 2715
return 1 0 2718
assign 1 0 2721
assign 1 0 2725
return 1 0 2729
return 1 0 2732
assign 1 0 2735
assign 1 0 2739
return 1 0 2743
return 1 0 2746
assign 1 0 2749
assign 1 0 2753
return 1 0 2757
return 1 0 2760
assign 1 0 2763
assign 1 0 2767
return 1 0 2771
return 1 0 2774
assign 1 0 2777
assign 1 0 2781
return 1 0 2785
return 1 0 2788
assign 1 0 2791
assign 1 0 2795
return 1 0 2799
return 1 0 2802
assign 1 0 2805
assign 1 0 2809
return 1 0 2813
return 1 0 2816
assign 1 0 2819
assign 1 0 2823
return 1 0 2827
return 1 0 2830
assign 1 0 2833
assign 1 0 2837
return 1 0 2841
return 1 0 2844
assign 1 0 2847
assign 1 0 2851
return 1 0 2855
return 1 0 2858
assign 1 0 2861
assign 1 0 2865
return 1 0 2869
return 1 0 2872
assign 1 0 2875
assign 1 0 2879
return 1 0 2883
return 1 0 2886
assign 1 0 2889
assign 1 0 2893
return 1 0 2897
return 1 0 2900
assign 1 0 2903
assign 1 0 2907
return 1 0 2911
return 1 0 2914
assign 1 0 2917
assign 1 0 2921
return 1 0 2925
return 1 0 2928
assign 1 0 2931
assign 1 0 2935
return 1 0 2939
return 1 0 2942
assign 1 0 2945
assign 1 0 2949
return 1 0 2953
return 1 0 2956
assign 1 0 2959
assign 1 0 2963
return 1 0 2967
return 1 0 2970
assign 1 0 2973
assign 1 0 2977
return 1 0 2981
return 1 0 2984
assign 1 0 2987
assign 1 0 2991
return 1 0 2995
return 1 0 2998
assign 1 0 3001
assign 1 0 3005
return 1 0 3009
return 1 0 3012
assign 1 0 3015
assign 1 0 3019
return 1 0 3023
return 1 0 3026
assign 1 0 3029
assign 1 0 3033
return 1 0 3037
return 1 0 3040
assign 1 0 3043
assign 1 0 3047
return 1 0 3051
return 1 0 3054
assign 1 0 3057
assign 1 0 3061
return 1 0 3065
return 1 0 3068
assign 1 0 3071
assign 1 0 3075
return 1 0 3079
return 1 0 3082
assign 1 0 3085
assign 1 0 3089
return 1 0 3093
return 1 0 3096
assign 1 0 3099
assign 1 0 3103
return 1 0 3107
return 1 0 3110
assign 1 0 3113
assign 1 0 3117
return 1 0 3121
return 1 0 3124
assign 1 0 3127
assign 1 0 3131
return 1 0 3135
return 1 0 3138
assign 1 0 3141
assign 1 0 3145
return 1 0 3149
return 1 0 3152
assign 1 0 3155
assign 1 0 3159
return 1 0 3163
return 1 0 3166
assign 1 0 3169
assign 1 0 3173
return 1 0 3177
return 1 0 3180
assign 1 0 3183
assign 1 0 3187
return 1 0 3191
return 1 0 3194
assign 1 0 3197
assign 1 0 3201
return 1 0 3205
return 1 0 3208
assign 1 0 3211
assign 1 0 3215
return 1 0 3219
return 1 0 3222
assign 1 0 3225
assign 1 0 3229
return 1 0 3233
return 1 0 3236
assign 1 0 3239
assign 1 0 3243
return 1 0 3247
return 1 0 3250
assign 1 0 3253
assign 1 0 3257
return 1 0 3261
return 1 0 3264
assign 1 0 3267
assign 1 0 3271
return 1 0 3275
return 1 0 3278
assign 1 0 3281
assign 1 0 3285
return 1 0 3289
return 1 0 3292
assign 1 0 3295
assign 1 0 3299
return 1 0 3303
return 1 0 3306
assign 1 0 3309
assign 1 0 3313
return 1 0 3317
return 1 0 3320
assign 1 0 3323
assign 1 0 3327
return 1 0 3331
return 1 0 3334
assign 1 0 3337
assign 1 0 3341
return 1 0 3345
return 1 0 3348
assign 1 0 3351
assign 1 0 3355
return 1 0 3359
assign 1 0 3362
assign 1 0 3366
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1664828825: return bem_doWhat_0();
case -1320367063: return bem_prepMakeGetDirect_0();
case 868223655: return bem_singleCCGet_0();
case -182215192: return bem_serializationIteratorGet_0();
case -994921210: return bem_libNameGetDirect_0();
case -2000083740: return bem_printAstGet_0();
case -1816171731: return bem_startTimeGet_0();
case -131297171: return bem_includePathGet_0();
case -1107359933: return bem_newlineGet_0();
case -770879118: return bem_initLibsGet_0();
case -1120863791: return bem_parseEmitTimeGetDirect_0();
case 249698855: return bem_mainNameGet_0();
case 1247700327: return bem_linkLibArgsGet_0();
case -785595032: return bem_emitCs_0();
case -392308897: return bem_parseEmitCompileTimeGet_0();
case 322540171: return bem_toAny_0();
case 145477345: return bem_extLibsGetDirect_0();
case 2042994679: return bem_emitLibraryGet_0();
case -872332340: return bem_paramsGetDirect_0();
case 609103510: return bem_emitDataGet_0();
case 1752086570: return bem_lctokGet_0();
case -1051263431: return bem_create_0();
case 417638271: return bem_builtGetDirect_0();
case -1358016112: return bem_argsGet_0();
case 20583242: return bem_emitCommonGetDirect_0();
case 2067482591: return bem_deployPathGet_0();
case 977988334: return bem_exeNameGetDirect_0();
case 1156921009: return bem_toString_0();
case 666508018: return bem_deployUsedLibrariesGet_0();
case -461205434: return bem_iteratorGet_0();
case 912156882: return bem_buildMessageGet_0();
case -665808604: return bem_runArgsGet_0();
case -835454076: return bem_config_0();
case -447843690: return bem_toBuildGet_0();
case 635303819: return bem_runGetDirect_0();
case -1276381893: return bem_printAllAstGet_0();
case -539277844: return bem_fieldIteratorGet_0();
case 1561691507: return bem_outputPlatformGetDirect_0();
case -1406882351: return bem_toBuildGetDirect_0();
case -142681412: return bem_platformGet_0();
case -1581666253: return bem_new_0();
case 1167889715: return bem_constantsGetDirect_0();
case -1854234771: return bem_emitPathGetDirect_0();
case -823560738: return bem_putLineNumbersInTraceGet_0();
case -654415539: return bem_tagGet_0();
case -1678570812: return bem_printStepsGetDirect_0();
case 338607326: return bem_linkLibArgsGetDirect_0();
case 874503493: return bem_serializeToString_0();
case 510460722: return bem_readBufferGetDirect_0();
case 339916662: return bem_buildPathGetDirect_0();
case -1586372435: return bem_emitterGet_0();
case 832915875: return bem_nlGet_0();
case -812674048: return bem_buildSucceededGetDirect_0();
case 667490184: return bem_runGet_0();
case -1912820371: return bem_platformGetDirect_0();
case 119926028: return bem_makeGetDirect_0();
case -119476728: return bem_usedLibrarysGet_0();
case 670661576: return bem_exeNameGet_0();
case 369936697: return bem_closeLibrariesStrGetDirect_0();
case 178326299: return bem_go_0();
case -315745396: return bem_outputPlatformGet_0();
case 6775570: return bem_printPlacesGetDirect_0();
case 182197135: return bem_printPlacesGet_0();
case 1465586920: return bem_deployFilesFromGetDirect_0();
case 1835327062: return bem_main_0();
case 1389629861: return bem_prepMakeGet_0();
case 1790833630: return bem_doEmitGetDirect_0();
case 1205179000: return bem_deserializeClassNameGet_0();
case 1186337589: return bem_parseTimeGet_0();
case 464610233: return bem_once_0();
case -376741204: return bem_makeArgsGetDirect_0();
case 657923681: return bem_buildSucceededGet_0();
case 1969869774: return bem_echo_0();
case 773700566: return bem_deployFilesToGet_0();
case 1375519361: return bem_sourceFileNameGet_0();
case -2073777924: return bem_saveSynsGetDirect_0();
case 845711213: return bem_parseGet_0();
case 1116633813: return bem_argsGetDirect_0();
case 1566300663: return bem_loadSynsGet_0();
case 1292118688: return bem_deployLibraryGetDirect_0();
case 85013320: return bem_ntypesGetDirect_0();
case -1147490678: return bem_initLibsGetDirect_0();
case 629210027: return bem_compilerGetDirect_0();
case -1359815398: return bem_makeNameGetDirect_0();
case -1485358058: return bem_buildPathGet_0();
case -576479395: return bem_printStepsGet_0();
case 2034846068: return bem_emitFileHeaderGetDirect_0();
case -757732657: return bem_newlineGetDirect_0();
case -1208063422: return bem_fromFileGet_0();
case -1377535959: return bem_saveIdsGetDirect_0();
case -1232123584: return bem_loadSynsGetDirect_0();
case 494493039: return bem_sharedEmitterGet_0();
case 454004749: return bem_estrGet_0();
case 1609830818: return bem_closeLibrariesGet_0();
case 1576920478: return bem_extIncludesGetDirect_0();
case -494236831: return bem_ownProcessGet_0();
case 563162541: return bem_deployFilesFromGet_0();
case -1835926517: return bem_deployLibraryGet_0();
case 2055267163: return bem_makeNameGet_0();
case 92941992: return bem_compilerProfileGetDirect_0();
case 1562249448: return bem_deployFilesToGetDirect_0();
case -1881857451: return bem_paramsGet_0();
case -1566160441: return bem_builtGet_0();
case 326201836: return bem_parseEmitTimeGet_0();
case 651950325: return bem_codeGetDirect_0();
case 1614731598: return bem_deployUsedLibrariesGetDirect_0();
case -1431960617: return bem_many_0();
case -1449398557: return bem_libNameGet_0();
case -97356360: return bem_emitFlagsGetDirect_0();
case -1644720740: return bem_emitFlagsGet_0();
case -1613379092: return bem_parseGetDirect_0();
case -1508354669: return bem_saveIdsGet_0();
case 1424398126: return bem_mainNameGetDirect_0();
case 1356770927: return bem_printAstElementsGet_0();
case 1344959339: return bem_emitLibraryGetDirect_0();
case 1728680407: return bem_parseTimeGetDirect_0();
case 464067221: return bem_parseEmitCompileTimeGetDirect_0();
case 1881939406: return bem_fieldNamesGet_0();
case -710350663: return bem_emitDebugGet_0();
case -307605998: return bem_emitPathGet_0();
case -1136389693: return bem_ntypesGet_0();
case -1604493442: return bem_extLibsGet_0();
case 374623337: return bem_printAstGetDirect_0();
case -1344224463: return bem_estrGetDirect_0();
case 49134257: return bem_hashGet_0();
case -573458131: return bem_doEmitGet_0();
case -877470189: return bem_printAllAstGetDirect_0();
case -1919898710: return bem_saveSynsGet_0();
case 1147702657: return bem_nlGetDirect_0();
case -561501450: return bem_emitDebugGetDirect_0();
case 1351519933: return bem_sharedEmitterGetDirect_0();
case 1218819309: return bem_emitLangsGetDirect_0();
case -1550044371: return bem_ccObjArgsGet_0();
case 1932090189: return bem_genOnlyGet_0();
case -1747498826: return bem_classNameGet_0();
case -193867367: return bem_runArgsGetDirect_0();
case 910908688: return bem_closeLibrariesGetDirect_0();
case 1411374680: return bem_usedLibrarysStrGetDirect_0();
case -461802330: return bem_closeLibrariesStrGet_0();
case 1492065676: return bem_extLinkObjectsGet_0();
case -1925832412: return bem_twtokGet_0();
case -1224030388: return bem_lctokGetDirect_0();
case -1830496619: return bem_ccObjArgsGetDirect_0();
case -568871063: return bem_twtokGetDirect_0();
case 1908999762: return bem_codeGet_0();
case 134716799: return bem_buildMessageGetDirect_0();
case -1927984794: return bem_includePathGetDirect_0();
case 515448694: return bem_emitFileHeaderGet_0();
case 659479196: return bem_startTimeGetDirect_0();
case 2040272225: return bem_extIncludesGet_0();
case -2103931350: return bem_fromFileGetDirect_0();
case -1074290264: return bem_genOnlyGetDirect_0();
case -2049984013: return bem_usedLibrarysGetDirect_0();
case -570154210: return bem_compilerProfileGet_0();
case 264409808: return bem_usedLibrarysStrGet_0();
case 767446555: return bem_compilerGet_0();
case 1273064877: return bem_makeGet_0();
case -1905295855: return bem_singleCCGetDirect_0();
case -152303103: return bem_ownProcessGetDirect_0();
case 142355115: return bem_emitLangsGet_0();
case -243110380: return bem_putLineNumbersInTraceGetDirect_0();
case -796060020: return bem_emitDataGetDirect_0();
case 941172865: return bem_serializeContents_0();
case 1512772474: return bem_copy_0();
case 1947173801: return bem_print_0();
case 985978249: return bem_extLinkObjectsGetDirect_0();
case -2056455068: return bem_printAstElementsGetDirect_0();
case 426235045: return bem_emitCommonGet_0();
case 1402520141: return bem_setClassesToWrite_0();
case 2090213122: return bem_readBufferGet_0();
case 530817908: return bem_makeArgsGet_0();
case -309263182: return bem_deployPathGetDirect_0();
case 322387185: return bem_constantsGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1216541394: return bem_deployFilesFromSet_1(bevd_0);
case -1942605170: return bem_runSet_1(bevd_0);
case 1932737348: return bem_runArgsSet_1(bevd_0);
case -2020072589: return bem_nlSet_1(bevd_0);
case -1851320603: return bem_closeLibrariesSetDirect_1(bevd_0);
case 302105915: return bem_nlSetDirect_1(bevd_0);
case 1560008361: return bem_singleCCSet_1(bevd_0);
case -569032859: return bem_ownProcessSet_1(bevd_0);
case 569036043: return bem_includePathSetDirect_1(bevd_0);
case -1755564246: return bem_closeLibrariesSet_1(bevd_0);
case 1280701441: return bem_constantsSet_1(bevd_0);
case 415073118: return bem_paramsSetDirect_1(bevd_0);
case 874551402: return bem_ntypesSetDirect_1(bevd_0);
case -1327502996: return bem_readBufferSet_1(bevd_0);
case 524562569: return bem_ownProcessSetDirect_1(bevd_0);
case 629227657: return bem_runSetDirect_1(bevd_0);
case -1830676721: return bem_buildPathSetDirect_1(bevd_0);
case 572937848: return bem_compilerProfileSetDirect_1(bevd_0);
case -2111370033: return bem_runArgsSetDirect_1(bevd_0);
case 472533400: return bem_emitFlagsSetDirect_1(bevd_0);
case 366921916: return bem_ccObjArgsSetDirect_1(bevd_0);
case -1690002243: return bem_extLinkObjectsSetDirect_1(bevd_0);
case -2125439788: return bem_prepMakeSet_1(bevd_0);
case 1643399234: return bem_initLibsSetDirect_1(bevd_0);
case -117834637: return bem_emitPathSet_1(bevd_0);
case -628009811: return bem_emitLibrarySetDirect_1(bevd_0);
case -2109980640: return bem_loadSynsSetDirect_1(bevd_0);
case 778331504: return bem_def_1(bevd_0);
case 306816195: return bem_fromFileSet_1(bevd_0);
case -395043903: return bem_extIncludesSet_1(bevd_0);
case -1540865310: return bem_lctokSet_1(bevd_0);
case -991223576: return bem_parseSetDirect_1(bevd_0);
case 225367733: return bem_extLibsSetDirect_1(bevd_0);
case 243162876: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1354010168: return bem_printPlacesSet_1(bevd_0);
case -1915001342: return bem_emitLangsSetDirect_1(bevd_0);
case -1516260895: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case -549022807: return bem_parseEmitTimeSet_1(bevd_0);
case 1157663509: return bem_compilerProfileSet_1(bevd_0);
case -310570330: return bem_platformSetDirect_1(bevd_0);
case 2002911470: return bem_parseSet_1(bevd_0);
case 837130500: return bem_genOnlySetDirect_1(bevd_0);
case 222838116: return bem_emitLangsSet_1(bevd_0);
case 1576863791: return bem_emitFileHeaderSet_1(bevd_0);
case -879364979: return bem_makeNameSet_1(bevd_0);
case 1813126449: return bem_twtokSet_1(bevd_0);
case 701229510: return bem_includePathSet_1(bevd_0);
case -566525822: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case -1144292634: return bem_usedLibrarysStrSet_1(bevd_0);
case 1278151507: return bem_doEmitSet_1(bevd_0);
case -1326301265: return bem_deployPathSet_1(bevd_0);
case -1405212164: return bem_sameClass_1(bevd_0);
case -2101677206: return bem_linkLibArgsSet_1(bevd_0);
case 305372896: return bem_emitCommonSetDirect_1(bevd_0);
case 56709590: return bem_printAstElementsSet_1(bevd_0);
case -970835441: return bem_outputPlatformSet_1(bevd_0);
case -1680668287: return bem_genOnlySet_1(bevd_0);
case -766127977: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case -1980201623: return bem_emitDataSet_1(bevd_0);
case 1357761206: return bem_makeSet_1(bevd_0);
case -879668411: return bem_twtokSetDirect_1(bevd_0);
case -1645829191: return bem_loadSynsSet_1(bevd_0);
case -404723038: return bem_libNameSet_1(bevd_0);
case -1212562475: return bem_deployUsedLibrariesSet_1(bevd_0);
case -1172865658: return bem_printPlacesSetDirect_1(bevd_0);
case -1295446558: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -431817523: return bem_codeSet_1(bevd_0);
case -1360972218: return bem_saveIdsSetDirect_1(bevd_0);
case 384082261: return bem_makeArgsSetDirect_1(bevd_0);
case 1578344014: return bem_buildSucceededSetDirect_1(bevd_0);
case 1779380050: return bem_undefined_1(bevd_0);
case -1948729138: return bem_startTimeSetDirect_1(bevd_0);
case -1423763336: return bem_deployLibrarySet_1(bevd_0);
case -1621675778: return bem_saveIdsSet_1(bevd_0);
case -372656618: return bem_buildSucceededSet_1(bevd_0);
case 934275054: return bem_printAllAstSet_1(bevd_0);
case -293212160: return bem_startTimeSet_1(bevd_0);
case 1809421860: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 834385120: return bem_printStepsSetDirect_1(bevd_0);
case -1368246910: return bem_extIncludesSetDirect_1(bevd_0);
case -767719309: return bem_doEmitSetDirect_1(bevd_0);
case 1902213522: return bem_ntypesSet_1(bevd_0);
case 400734135: return bem_saveSynsSetDirect_1(bevd_0);
case 888788498: return bem_deployFilesToSet_1(bevd_0);
case -1166404251: return bem_constantsSetDirect_1(bevd_0);
case 1291282988: return bem_printAllAstSetDirect_1(bevd_0);
case 845712463: return bem_estrSetDirect_1(bevd_0);
case 682542322: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case 1142992462: return bem_platformSet_1(bevd_0);
case 1829959681: return bem_usedLibrarysStrSetDirect_1(bevd_0);
case 1215244882: return bem_emitFileHeaderSetDirect_1(bevd_0);
case 1089354598: return bem_undef_1(bevd_0);
case -1081613102: return bem_toBuildSetDirect_1(bevd_0);
case -1607191882: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case -189330209: return bem_extLibsSet_1(bevd_0);
case -1489044696: return bem_extLinkObjectsSet_1(bevd_0);
case 739192685: return bem_deployFilesFromSetDirect_1(bevd_0);
case 204668710: return bem_argsSetDirect_1(bevd_0);
case -1712444553: return bem_emitDebugSet_1(bevd_0);
case -980143123: return bem_printAstSetDirect_1(bevd_0);
case 22579128: return bem_buildSyns_1(bevd_0);
case -1396343642: return bem_buildMessageSet_1(bevd_0);
case 722544133: return bem_ccObjArgsSet_1(bevd_0);
case -1415593402: return bem_deployFilesToSetDirect_1(bevd_0);
case 1458259788: return bem_makeNameSetDirect_1(bevd_0);
case 427919344: return bem_outputPlatformSetDirect_1(bevd_0);
case -1240681566: return bem_sharedEmitterSetDirect_1(bevd_0);
case -373658986: return bem_equals_1(bevd_0);
case -1940703752: return bem_copyTo_1(bevd_0);
case 1428605518: return bem_sharedEmitterSet_1(bevd_0);
case 62985870: return bem_parseTimeSetDirect_1(bevd_0);
case 1817351105: return bem_defined_1(bevd_0);
case 209701196: return bem_emitDataSetDirect_1(bevd_0);
case -267744196: return bem_singleCCSetDirect_1(bevd_0);
case 1863843005: return bem_emitFlagsSet_1(bevd_0);
case -2144078956: return bem_paramsSet_1(bevd_0);
case 1436162854: return bem_parseEmitTimeSetDirect_1(bevd_0);
case -1690490591: return bem_printAstSet_1(bevd_0);
case 1497761385: return bem_compilerSet_1(bevd_0);
case -419183868: return bem_makeArgsSet_1(bevd_0);
case 886382998: return bem_saveSynsSet_1(bevd_0);
case -1240149708: return bem_mainNameSetDirect_1(bevd_0);
case 917839703: return bem_toBuildSet_1(bevd_0);
case 1350277511: return bem_fromFileSetDirect_1(bevd_0);
case 172151464: return bem_usedLibrarysSetDirect_1(bevd_0);
case -469145581: return bem_emitDebugSetDirect_1(bevd_0);
case -1258899272: return bem_emitPathSetDirect_1(bevd_0);
case -2144028250: return bem_argsSet_1(bevd_0);
case 118251588: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case 735407145: return bem_printStepsSet_1(bevd_0);
case -1031751774: return bem_parseTimeSet_1(bevd_0);
case 558742154: return bem_linkLibArgsSetDirect_1(bevd_0);
case 561597387: return bem_exeNameSet_1(bevd_0);
case 412446085: return bem_codeSetDirect_1(bevd_0);
case 1283337045: return bem_emitCommonSet_1(bevd_0);
case -1514202094: return bem_getSynNp_1(bevd_0);
case -1114837563: return bem_newlineSetDirect_1(bevd_0);
case 680579909: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case -146562532: return bem_readBufferSetDirect_1(bevd_0);
case -296461795: return bem_buildPathSet_1(bevd_0);
case 372746140: return bem_sameType_1(bevd_0);
case -653588721: return bem_otherType_1(bevd_0);
case 664954045: return bem_makeSetDirect_1(bevd_0);
case 1966156517: return bem_otherClass_1(bevd_0);
case -1509828842: return bem_mainNameSet_1(bevd_0);
case -1272041752: return bem_emitLibrarySet_1(bevd_0);
case 862352080: return bem_newlineSet_1(bevd_0);
case 358862402: return bem_initLibsSet_1(bevd_0);
case -1267119008: return bem_lctokSetDirect_1(bevd_0);
case 222680326: return bem_closeLibrariesStrSet_1(bevd_0);
case -127698872: return bem_estrSet_1(bevd_0);
case -52054497: return bem_usedLibrarysSet_1(bevd_0);
case -1499911921: return bem_notEquals_1(bevd_0);
case -1264044693: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1205760336: return bem_doParse_1(bevd_0);
case 66756220: return bem_buildMessageSetDirect_1(bevd_0);
case 1752440459: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -1774111907: return bem_compilerSetDirect_1(bevd_0);
case -422172873: return bem_deployLibrarySetDirect_1(bevd_0);
case 541172837: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -918368894: return bem_builtSet_1(bevd_0);
case -1199024095: return bem_prepMakeSetDirect_1(bevd_0);
case -1553421234: return bem_exeNameSetDirect_1(bevd_0);
case -156508450: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case 447923928: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -38159591: return bem_builtSetDirect_1(bevd_0);
case -722728926: return bem_deployPathSetDirect_1(bevd_0);
case -498298486: return bem_sameObject_1(bevd_0);
case -2021678012: return bem_printAstElementsSetDirect_1(bevd_0);
case 1733900664: return bem_libNameSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 414389553: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1714613573: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -292360250: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -246128114: return bem_buildLiteral_2(bevd_0, bevd_1);
case 1129259785: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 614290015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 888716978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 193506539: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -188471242: return bem_getSyn_2(bevd_0, bevd_1);
case 454549642: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
}
