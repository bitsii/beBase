namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_12, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_57, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_60, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_61, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_65, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x63,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_66, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_70, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_71, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_105, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_106, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_107 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_107, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_108 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_108, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_109 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_109, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_110 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_111 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_112 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static new BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;
public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_saveSyns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
 else  /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 96 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 97 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 115 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 115 */
 else  /* Line: 115 */ {
break;
} /* Line: 115 */
} /* Line: 115 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bem_config_0();
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 125 */ {
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 128 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(364146106);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 133 */
if (bevp_printSteps.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 136 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(1714019821);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1049342566, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 142 */ {
} /* Line: 142 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_110_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_115_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_116_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_121_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_122_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_123_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_124_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_125_tmpany_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_5_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_6_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 153 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 153 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(532230223);
bevt_9_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpany_phold);
} /* Line: 156 */
} /* Line: 154 */
 else  /* Line: 153 */ {
break;
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
bevt_13_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_nameGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_equals_1(bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 162 */
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_15_tmpany_phold = bevp_params.bem_get_1(bevt_16_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_17_tmpany_phold = bevp_params.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 165 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_19_tmpany_phold = bevp_params.bem_get_1(bevt_20_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_firstGet_0();
} /* Line: 166 */
 else  /* Line: 167 */ {
bevp_exeName = bevp_libName;
} /* Line: 168 */
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_23_tmpany_phold = bevp_params.bem_get_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_firstGet_0();
bevt_21_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpany_phold);
bevp_buildPath = bevt_21_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_29_tmpany_phold = bevp_params.bem_get_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_firstGet_0();
bevt_27_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpany_phold);
bevp_includePath = bevt_27_tmpany_phold.bem_pathGet_0();
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_36_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_nameGet_0();
bevt_33_tmpany_phold = bevp_params.bem_get_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpany_phold );
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_40_tmpany_phold = bevp_platform.bemd_0(1714019821);
bevt_38_tmpany_phold = bevp_params.bem_get_2(bevt_39_tmpany_phold, (BEC_2_4_6_TextString) bevt_40_tmpany_phold );
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpany_phold );
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_42_tmpany_phold = bevp_params.bem_get_2(bevt_43_tmpany_phold, bevt_44_tmpany_phold);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_26));
bevt_46_tmpany_phold = bevp_params.bem_get_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpany_phold);
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_27));
bevp_loadSyns = bevp_params.bem_get_1(bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_28));
bevp_initLibs = bevp_params.bem_get_1(bevt_50_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_29));
bevt_51_tmpany_phold = bevp_params.bem_get_1(bevt_52_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_firstGet_0();
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_30));
bevt_53_tmpany_phold = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_53_tmpany_phold.bem_firstGet_0();
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_31));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_55_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 184 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 185 */
bevt_57_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_32));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_57_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_58_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 188 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 189 */
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_59_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193 */
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_61_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 196 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_extIncludes = bevp_params.bem_get_1(bevt_63_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_65_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 204 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extLibs = bevp_params.bem_get_1(bevt_67_tmpany_phold);
if (bevp_extLibs == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_69_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_71_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_73_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_74_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(1799820853);
} /* Line: 221 */
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_runArgs = bevp_params.bem_get_1(bevt_75_tmpany_phold);
if (bevp_runArgs == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevp_runArgs = bevp_runArgs.bemd_0(1799820853);
} /* Line: 225 */
 else  /* Line: 226 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 227 */
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_42));
bevt_78_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_77_tmpany_phold, bevt_78_tmpany_phold);
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_43));
bevt_80_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_79_tmpany_phold, bevt_80_tmpany_phold);
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_44));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_81_tmpany_phold);
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_82_tmpany_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_46));
bevl_pacm = bevp_params.bem_get_1(bevt_83_tmpany_phold);
if (bevl_pacm == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_86_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_86_tmpany_phold.bevi_bool) {
bevt_85_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_85_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_85_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 235 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 235 */
 else  /* Line: 235 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 235 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 236 */ {
bevt_87_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_87_tmpany_phold).bevi_bool) /* Line: 236 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 237 */
 else  /* Line: 236 */ {
break;
} /* Line: 236 */
} /* Line: 236 */
} /* Line: 236 */
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_88_tmpany_phold);
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_48));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_89_tmpany_phold);
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_run = bevp_params.bem_isTrue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_50));
bevt_92_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_91_tmpany_phold, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_emitLangs = bevp_params.bem_get_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_emitFlags = bevp_params.bem_get_1(bevt_94_tmpany_phold);
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_53));
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_54));
bevt_95_tmpany_phold = bevp_params.bem_get_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_95_tmpany_phold.bem_firstGet_0();
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_55));
bevt_100_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_98_tmpany_phold = bevp_params.bem_get_2(bevt_99_tmpany_phold, bevt_100_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_98_tmpany_phold.bem_firstGet_0();
bevt_103_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_102_tmpany_phold = bevt_103_tmpany_phold.bem_add_1(bevp_makeName);
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_101_tmpany_phold = bevp_params.bem_get_2(bevt_102_tmpany_phold, bevt_104_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_101_tmpany_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_105_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_105_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_105_tmpany_phold.bevi_bool) /* Line: 256 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 257 */
 else  /* Line: 258 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_59));
} /* Line: 259 */
bevt_108_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_107_tmpany_phold = bevl_outLang.bem_add_1(bevt_108_tmpany_phold);
bevt_109_tmpany_phold = bevp_platform.bemd_0(1714019821);
bevt_106_tmpany_phold = bevt_107_tmpany_phold.bem_add_1(bevt_109_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_106_tmpany_phold);
if (bevl_platformSources == null) {
bevt_110_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_110_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_110_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevt_111_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_111_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 268 */
bevt_113_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_112_tmpany_phold = bevl_outLang.bem_add_1(bevt_113_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_112_tmpany_phold);
if (bevl_langSources == null) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_115_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_115_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 273 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_116_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpany_loop = bevt_116_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 277 */ {
bevt_117_tmpany_phold = bevt_2_tmpany_loop.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_117_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(532230223);
bevt_118_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_118_tmpany_phold);
} /* Line: 278 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(-1510717441);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_121_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_120_tmpany_phold = bevt_121_tmpany_phold.bem_existsGet_0();
if (bevt_120_tmpany_phold.bevi_bool) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevt_122_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_122_tmpany_phold.bem_makeDirs_0();
} /* Line: 286 */
if (bevp_emitFileHeader == null) {
bevt_123_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_123_tmpany_phold.bevi_bool) /* Line: 288 */ {
bevt_124_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_124_tmpany_phold.bem_readerGet_0();
bevt_125_tmpany_phold = bevl_emr.bemd_0(2074093346);
bevp_emitFileHeader = bevt_125_tmpany_phold.bemd_0(728776417);
bevl_emr.bemd_0(-803854418);
} /* Line: 291 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(597900509, bevp_nl);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_62));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(597900509, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(597900509, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(597900509, bevp_nl);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_63));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(597900509, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(597900509, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 305 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 305 */ {
bevl_clnode = bevl_ci.bemd_0(532230223);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(434489845);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(1204467547);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(434489845);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1613105647);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(364146106);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(434489845);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1613105647);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(364146106);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 310 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 311 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 312 */
 else  /* Line: 311 */ {
break;
} /* Line: 311 */
} /* Line: 311 */
} /* Line: 311 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(434489845);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(1613105647);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(364146106);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 316 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 317 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 317 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 318 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
} /* Line: 317 */
} /* Line: 316 */
} /* Line: 307 */
 else  /* Line: 305 */ {
break;
} /* Line: 305 */
} /* Line: 305 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 323 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 323 */ {
bevl_clnode = bevl_ci.bemd_0(532230223);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(434489845);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(434489845);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(1613105647);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(364146106);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(-592206308, bevt_26_tmpany_phold);
} /* Line: 325 */
 else  /* Line: 323 */ {
break;
} /* Line: 323 */
} /* Line: 323 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 336 */ {
return bevp_emitCommon;
} /* Line: 337 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 342 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 345 */
 else  /* Line: 344 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 347 */
 else  /* Line: 344 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 349 */
 else  /* Line: 344 */ {
bevt_9_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_8_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 352 */ {
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_68));
bevt_10_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 353 */
} /* Line: 344 */
} /* Line: 344 */
} /* Line: 344 */
return bevp_emitCommon;
} /* Line: 355 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = (BEC_2_4_8_TimeInterval) bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(2074093346);
bevt_5_tmpany_phold = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 378 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 379 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 379 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 380 */
 else  /* Line: 379 */ {
break;
} /* Line: 379 */
} /* Line: 379 */
} /* Line: 379 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 387 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 388 */
} /* Line: 387 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(173912112);
while (true)
 /* Line: 393 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 393 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(532230223);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 397 */
} /* Line: 394 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(173912112);
while (true)
 /* Line: 400 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 400 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(532230223);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 401 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(1304433578);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 405 */
} /* Line: 401 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
if (bevp_parse.bevi_bool) /* Line: 408 */ {
bevl_built = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 411 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevl_tb = bevl_i.bemd_0(532230223);
bevt_20_tmpany_phold = bevl_tb.bemd_0(364146106);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 414 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(364146106);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 416 */
} /* Line: 414 */
 else  /* Line: 411 */ {
break;
} /* Line: 411 */
} /* Line: 411 */
bem_buildSyns_1(bevl_em);
} /* Line: 419 */
bevt_23_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 425 */ {
bevt_26_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 434 */
if (bevp_doEmit.bevi_bool) /* Line: 436 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(1411868381);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 440 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 440 */ {
bevl_clnode = bevl_ci.bemd_0(532230223);
bevl_em.bemd_1(684960772, bevl_clnode);
} /* Line: 442 */
 else  /* Line: 440 */ {
break;
} /* Line: 440 */
} /* Line: 440 */
bevl_em.bemd_0(2115403098);
bevl_em.bemd_0(-1297733561);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 446 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 446 */ {
bevl_clnode = bevl_ci.bemd_0(532230223);
bevl_em.bemd_1(-486195938, bevl_clnode);
} /* Line: 448 */
 else  /* Line: 446 */ {
break;
} /* Line: 446 */
} /* Line: 446 */
} /* Line: 446 */
bevt_44_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 453 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 454 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 457 */ {
bevl_em.bemd_1(1382631420, bevp_deployLibrary);
} /* Line: 459 */
if (bevp_make.bevi_bool) /* Line: 462 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 463 */ {
bevl_em.bemd_1(-1443732047, bevp_deployLibrary);
bevl_em.bemd_1(-570136114, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 466 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 467 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 467 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(1411868381);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(1926785529);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(604677000);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(-2045951255);
bevl_cpTo.bemd_1(-1200603097, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(-2129526420);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(-637983439);
if (((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 471 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(-2129526420);
bevt_58_tmpany_phold.bemd_0(-1630915433);
} /* Line: 472 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(-2129526420);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(-637983439);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(-1110349331);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 474 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(-2129526420);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(-2129526420);
bevl_em.bemd_2(1569074843, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 475 */
} /* Line: 474 */
 else  /* Line: 467 */ {
break;
} /* Line: 467 */
} /* Line: 467 */
} /* Line: 467 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 482 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 482 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 482 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 482 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 482 */
 else  /* Line: 482 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 482 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(532230223);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(532230223);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(-2129526420);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(-637983439);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(-2129526420);
bevt_76_tmpany_phold.bemd_0(-1630915433);
} /* Line: 487 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(-2129526420);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(-637983439);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(-1110349331);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(-2129526420);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(-2129526420);
bevl_em.bemd_2(1569074843, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 490 */
} /* Line: 489 */
 else  /* Line: 482 */ {
break;
} /* Line: 482 */
} /* Line: 482 */
} /* Line: 482 */
} /* Line: 463 */
bevt_83_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 497 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 498 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 500 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 501 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 504 */
if (bevp_run.bevi_bool) /* Line: 507 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(-2106462856, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 511 */
bevt_98_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 517 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 517 */ {
bevl_kls = bevl_ci.bemd_0(532230223);
bevt_2_tmpany_phold = bevl_kls.bemd_0(434489845);
bevt_2_tmpany_phold.bemd_1(-1166622465, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-1166622465, bevp_libName);
} /* Line: 521 */
 else  /* Line: 517 */ {
break;
} /* Line: 517 */
} /* Line: 517 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 523 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 523 */ {
bevl_kls = bevl_ci.bemd_0(532230223);
bevt_5_tmpany_phold = bevl_kls.bemd_0(434489845);
bevl_syn = bevt_5_tmpany_phold.bemd_0(2083427164);
bevl_syn.bemd_2(-190533591, this, bevl_kls);
bevl_syn.bemd_1(-1560578080, this);
} /* Line: 527 */
 else  /* Line: 523 */ {
break;
} /* Line: 523 */
} /* Line: 523 */
bevt_6_tmpany_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(434489845);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(2083427164);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 533 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(434489845);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(2083427164);
return bevt_3_tmpany_phold;
} /* Line: 534 */
bevt_5_tmpany_phold = beva_klass.bemd_0(434489845);
bevt_5_tmpany_phold.bemd_1(-1166622465, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(434489845);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1242580111);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 537 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 538 */
 else  /* Line: 539 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(434489845);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1242580111);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(364146106);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 542 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(434489845);
bevt_14_tmpany_phold.bemd_1(-1166622465, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 544 */
 else  /* Line: 545 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(434489845);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1242580111);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 548 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 550 */
bevt_17_tmpany_phold = beva_klass.bemd_0(434489845);
bevt_17_tmpany_phold.bemd_1(1979245128, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(434489845);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(1613105647);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(364146106);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(364146106);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 560 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 561 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(-2136734832, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 576 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 577 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 590 */ {
if (bevp_printSteps.bevi_bool) /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 591 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 591 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 591 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_5_tmpany_phold = beva_toParse.bemd_0(364146106);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 592 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(-2129526420);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-103192116);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(2074093346);
bevl_src = bevt_6_tmpany_phold.bemd_1(-1236651896, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(-2129526420);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-103192116);
bevt_9_tmpany_phold.bemd_0(-803854418);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 601 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 602 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(650477408);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 605 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_14_tmpany_phold);
} /* Line: 607 */
if (bevp_printSteps.bevi_bool) /* Line: 610 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 611 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-205149094, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 614 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_18_tmpany_phold);
} /* Line: 616 */
if (bevp_printSteps.bevi_bool) /* Line: 618 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 619 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-205149094, bevt_20_tmpany_phold);
bevl_trans.bemd_0(757960106);
if (bevp_printAllAst.bevi_bool) /* Line: 624 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_22_tmpany_phold);
} /* Line: 626 */
if (bevp_printSteps.bevi_bool) /* Line: 629 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 630 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-205149094, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 633 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_26_tmpany_phold);
} /* Line: 635 */
if (bevp_printSteps.bevi_bool) /* Line: 638 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 639 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-205149094, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 642 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_30_tmpany_phold);
} /* Line: 644 */
if (bevp_printSteps.bevi_bool) /* Line: 647 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 648 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-205149094, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 651 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_34_tmpany_phold);
} /* Line: 653 */
if (bevp_printSteps.bevi_bool) /* Line: 656 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 657 */
bevt_36_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-205149094, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 660 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_38_tmpany_phold);
} /* Line: 662 */
if (bevp_printSteps.bevi_bool) /* Line: 665 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 666 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-205149094, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 669 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_42_tmpany_phold);
} /* Line: 671 */
if (bevp_printSteps.bevi_bool) /* Line: 674 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 675 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-205149094, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 678 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_46_tmpany_phold);
} /* Line: 680 */
if (bevp_printSteps.bevi_bool) /* Line: 683 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 684 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-205149094, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 687 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_50_tmpany_phold);
} /* Line: 689 */
if (bevp_printSteps.bevi_bool) /* Line: 691 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 692 */
bevt_52_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-205149094, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 695 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_54_tmpany_phold);
} /* Line: 697 */
if (bevp_printSteps.bevi_bool) /* Line: 700 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 702 */
bevt_57_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-205149094, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 705 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 705 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 705 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 705 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 705 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 705 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_51;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-205149094, bevt_59_tmpany_phold);
} /* Line: 707 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 709 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(-92073040);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 709 */ {
bevl_clnode = bevl_ci.bemd_0(532230223);
bevl_tunode = bevl_clnode.bemd_0(914950081);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(1008160609, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(434489845);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(858161552);
bevl_ntt.bemd_1(1544112214, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(1483672160, bevl_ntt);
bevl_clnode.bemd_0(-1630915433);
bevl_ntunode.bemd_1(778374132, bevl_clnode);
bevl_ntunode.bemd_1(-94904346, bevl_clnode);
} /* Line: 720 */
 else  /* Line: 709 */ {
break;
} /* Line: 709 */
} /* Line: 709 */
} /* Line: 709 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(236088236);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(-778477374);
bevl_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 730 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 730 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(1483672160, bevt_2_tmpany_phold);
bevl_node.bemd_1(991239989, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(434489845);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1049342566, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 734 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 735 */
bevt_6_tmpany_phold = bevl_node.bemd_0(434489845);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(-2078921482, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 737 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(206543328, beva_parnode);
} /* Line: 739 */
} /* Line: 737 */
 else  /* Line: 730 */ {
break;
} /* Line: 730 */
} /* Line: 730 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-238449838, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(1008160609, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(1483672160, bevl_nlnp);
bevl_nlnpn.bemd_1(-94904346, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_110));
bevl_nlc.bemd_1(1314653339, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1217056789, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(875743672, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1261997691, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(573266016, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(434489845);
bevl_nlc.bemd_1(1670741398, bevt_11_tmpany_phold);
beva_node.bemd_1(778374132, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(1008160609, bevt_12_tmpany_phold);
beva_node.bemd_1(1483672160, bevl_nlc);
bevl_nlnpn.bemd_0(1695150387);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_111));
bevt_13_tmpany_phold = beva_tName.bemd_1(1049342566, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 769 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 769 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_112));
bevt_15_tmpany_phold = beva_tName.bemd_1(1049342566, bevt_16_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 769 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 769 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 769 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 769 */ {
bevl_pn = beva_node.bemd_0(-528164128);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 771 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-25601069);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(1049342566, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 771 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-25601069);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(1049342566, bevt_23_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 771 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 771 */
 else  /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 771 */ {
bevl_pn2 = bevl_pn.bemd_0(-528164128);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-25601069);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(-2078921482, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-25601069);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(-2078921482, bevt_30_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
 else  /* Line: 773 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-25601069);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(-2078921482, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
 else  /* Line: 773 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-25601069);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(-2078921482, bevt_36_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
 else  /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(434489845);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(-1787862928);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(597900509, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(1670741398, bevt_37_tmpany_phold);
bevl_pn.bemd_0(-1630915433);
} /* Line: 780 */
} /* Line: 773 */
} /* Line: 771 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {51, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 68, 70, 71, 72, 73, 73, 76, 79, 80, 86, 87, 88, 89, 89, 96, 96, 96, 96, 0, 96, 96, 0, 0, 0, 0, 0, 97, 97, 99, 99, 103, 103, 103, 103, 107, 107, 108, 108, 108, 112, 113, 114, 114, 114, 114, 114, 115, 115, 115, 116, 115, 118, 122, 123, 124, 126, 127, 128, 130, 131, 132, 132, 133, 0, 0, 0, 136, 138, 142, 142, 142, 144, 149, 151, 152, 152, 152, 153, 153, 0, 153, 153, 154, 154, 154, 155, 156, 156, 161, 161, 161, 161, 162, 164, 164, 164, 165, 165, 166, 166, 166, 168, 170, 170, 170, 170, 170, 170, 171, 172, 172, 173, 173, 173, 173, 173, 173, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 178, 178, 179, 179, 181, 181, 181, 182, 182, 182, 183, 183, 184, 184, 185, 187, 187, 188, 188, 189, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 229, 229, 229, 230, 230, 230, 231, 231, 232, 232, 233, 234, 234, 235, 235, 235, 235, 235, 0, 0, 0, 236, 0, 236, 236, 237, 240, 240, 241, 241, 242, 242, 243, 243, 243, 244, 244, 245, 245, 246, 246, 246, 246, 247, 247, 247, 247, 248, 248, 248, 248, 248, 249, 250, 251, 252, 253, 256, 256, 257, 259, 266, 266, 266, 266, 266, 267, 267, 268, 268, 271, 271, 271, 272, 272, 273, 273, 276, 277, 277, 0, 277, 277, 278, 278, 280, 281, 282, 284, 285, 285, 285, 285, 286, 286, 288, 288, 289, 289, 290, 290, 291, 297, 298, 298, 298, 298, 298, 299, 299, 299, 299, 299, 300, 304, 305, 305, 305, 306, 307, 307, 307, 307, 308, 308, 308, 308, 309, 309, 309, 309, 309, 310, 310, 311, 0, 311, 311, 312, 315, 315, 315, 315, 315, 316, 316, 317, 0, 317, 317, 318, 323, 323, 323, 324, 325, 325, 325, 325, 325, 325, 332, 332, 336, 336, 337, 342, 342, 343, 344, 344, 345, 346, 346, 347, 348, 348, 349, 350, 350, 351, 353, 353, 353, 355, 357, 361, 363, 363, 363, 364, 364, 365, 365, 365, 366, 366, 367, 368, 368, 369, 369, 369, 370, 370, 370, 376, 376, 377, 378, 378, 379, 0, 379, 379, 380, 383, 384, 384, 385, 386, 388, 388, 388, 391, 393, 0, 393, 393, 394, 394, 394, 395, 396, 397, 400, 0, 400, 400, 401, 401, 401, 402, 403, 404, 405, 405, 410, 411, 411, 412, 414, 414, 415, 415, 416, 419, 422, 422, 422, 425, 425, 425, 427, 427, 428, 428, 429, 429, 429, 430, 430, 430, 431, 431, 431, 432, 432, 432, 433, 433, 433, 434, 434, 437, 438, 440, 440, 440, 441, 442, 444, 445, 446, 446, 446, 447, 448, 452, 452, 452, 453, 453, 454, 454, 454, 456, 456, 456, 459, 463, 463, 464, 465, 467, 0, 467, 467, 468, 468, 469, 469, 470, 470, 470, 471, 471, 472, 472, 474, 474, 474, 475, 475, 475, 479, 480, 482, 482, 0, 0, 0, 483, 483, 484, 484, 484, 484, 484, 484, 484, 484, 486, 486, 487, 487, 489, 489, 489, 490, 490, 490, 495, 495, 495, 497, 497, 498, 498, 498, 500, 500, 501, 501, 501, 503, 503, 504, 504, 504, 508, 508, 509, 510, 510, 510, 510, 510, 511, 513, 513, 517, 517, 517, 518, 519, 519, 520, 521, 523, 523, 523, 524, 525, 525, 526, 527, 529, 529, 533, 533, 533, 533, 534, 534, 534, 536, 536, 537, 537, 537, 537, 538, 540, 540, 540, 540, 540, 542, 542, 543, 543, 544, 548, 548, 548, 550, 552, 552, 553, 553, 553, 553, 554, 558, 559, 559, 560, 560, 561, 567, 567, 568, 569, 576, 576, 577, 579, 584, 585, 586, 587, 588, 589, 589, 0, 0, 0, 592, 592, 592, 592, 594, 596, 596, 596, 596, 597, 597, 597, 598, 602, 602, 604, 604, 606, 606, 607, 607, 611, 611, 613, 613, 615, 615, 616, 616, 619, 619, 622, 622, 623, 625, 625, 626, 626, 630, 630, 632, 632, 634, 634, 635, 635, 639, 639, 641, 641, 643, 643, 644, 644, 648, 648, 650, 650, 652, 652, 653, 653, 657, 657, 659, 659, 661, 661, 662, 662, 666, 666, 668, 668, 670, 670, 671, 671, 675, 675, 677, 677, 679, 679, 680, 680, 684, 684, 686, 686, 688, 688, 689, 689, 692, 692, 694, 694, 696, 696, 697, 697, 701, 701, 702, 702, 704, 704, 0, 0, 0, 706, 706, 707, 707, 709, 709, 709, 710, 712, 713, 714, 714, 715, 716, 716, 716, 717, 718, 719, 720, 726, 727, 728, 729, 729, 730, 730, 731, 732, 732, 733, 734, 734, 735, 737, 737, 738, 739, 746, 747, 749, 750, 750, 751, 752, 754, 755, 755, 756, 756, 757, 757, 758, 758, 759, 759, 760, 760, 762, 764, 764, 765, 767, 769, 769, 0, 769, 769, 0, 0, 770, 771, 771, 771, 771, 771, 0, 771, 771, 771, 0, 0, 0, 0, 0, 772, 773, 773, 0, 773, 773, 773, 773, 773, 773, 0, 0, 0, 773, 773, 773, 0, 0, 0, 773, 773, 773, 0, 0, 0, 0, 0, 779, 779, 779, 779, 780, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 285, 290, 291, 292, 294, 297, 298, 300, 303, 307, 310, 314, 317, 318, 320, 321, 327, 328, 329, 330, 337, 338, 339, 340, 341, 353, 354, 355, 356, 357, 358, 359, 360, 363, 368, 369, 370, 376, 384, 385, 386, 388, 389, 390, 394, 395, 396, 397, 398, 401, 405, 408, 412, 414, 420, 421, 422, 425, 563, 564, 565, 566, 571, 572, 573, 573, 576, 578, 579, 580, 585, 586, 587, 588, 596, 597, 598, 599, 601, 603, 604, 605, 606, 607, 609, 610, 611, 614, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 669, 670, 672, 673, 674, 679, 680, 682, 683, 684, 689, 690, 692, 693, 694, 699, 700, 702, 703, 704, 709, 710, 712, 713, 714, 719, 720, 722, 723, 724, 729, 730, 732, 733, 734, 739, 740, 742, 743, 744, 749, 750, 752, 753, 754, 759, 760, 762, 763, 764, 769, 770, 773, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 793, 794, 795, 800, 801, 804, 808, 811, 811, 814, 816, 817, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 860, 861, 864, 866, 867, 868, 869, 870, 871, 876, 877, 878, 880, 881, 882, 883, 888, 889, 890, 892, 893, 894, 894, 897, 899, 900, 901, 907, 908, 909, 910, 911, 912, 913, 918, 919, 920, 922, 927, 928, 929, 930, 931, 932, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 997, 998, 999, 1002, 1004, 1005, 1006, 1007, 1008, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1024, 1025, 1025, 1028, 1030, 1031, 1038, 1039, 1040, 1041, 1042, 1043, 1048, 1049, 1049, 1052, 1054, 1055, 1068, 1069, 1072, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1090, 1091, 1107, 1112, 1113, 1115, 1120, 1121, 1122, 1123, 1125, 1128, 1129, 1131, 1134, 1135, 1137, 1140, 1141, 1143, 1146, 1147, 1148, 1153, 1155, 1174, 1175, 1176, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1314, 1315, 1316, 1317, 1322, 1323, 1323, 1326, 1328, 1329, 1336, 1337, 1342, 1343, 1344, 1346, 1347, 1348, 1351, 1352, 1352, 1355, 1357, 1358, 1359, 1364, 1365, 1366, 1367, 1374, 1374, 1377, 1379, 1380, 1381, 1386, 1387, 1388, 1389, 1390, 1391, 1399, 1400, 1403, 1405, 1406, 1407, 1409, 1410, 1411, 1418, 1420, 1421, 1422, 1423, 1424, 1429, 1430, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1453, 1454, 1455, 1456, 1459, 1461, 1462, 1468, 1469, 1470, 1471, 1474, 1476, 1477, 1484, 1485, 1486, 1487, 1492, 1493, 1494, 1495, 1497, 1498, 1499, 1501, 1504, 1509, 1510, 1511, 1513, 1513, 1516, 1518, 1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1529, 1530, 1532, 1533, 1534, 1536, 1537, 1538, 1546, 1547, 1550, 1552, 1554, 1557, 1561, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1577, 1578, 1580, 1581, 1582, 1584, 1585, 1586, 1595, 1596, 1597, 1598, 1603, 1604, 1605, 1606, 1608, 1613, 1614, 1615, 1616, 1618, 1623, 1624, 1625, 1626, 1629, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1639, 1640, 1653, 1654, 1657, 1659, 1660, 1661, 1662, 1663, 1669, 1670, 1673, 1675, 1676, 1677, 1678, 1679, 1685, 1686, 1714, 1715, 1716, 1721, 1722, 1723, 1724, 1726, 1727, 1728, 1729, 1730, 1735, 1736, 1739, 1740, 1741, 1742, 1743, 1744, 1749, 1750, 1751, 1752, 1755, 1756, 1757, 1759, 1761, 1762, 1763, 1764, 1765, 1766, 1767, 1775, 1776, 1777, 1778, 1783, 1784, 1786, 1787, 1788, 1789, 1793, 1798, 1799, 1801, 1880, 1881, 1882, 1883, 1884, 1885, 1886, 1889, 1893, 1896, 1900, 1901, 1902, 1903, 1905, 1906, 1907, 1908, 1909, 1910, 1911, 1912, 1913, 1915, 1916, 1918, 1919, 1921, 1922, 1923, 1924, 1927, 1928, 1930, 1931, 1933, 1934, 1935, 1936, 1939, 1940, 1942, 1943, 1944, 1946, 1947, 1948, 1949, 1952, 1953, 1955, 1956, 1958, 1959, 1960, 1961, 1964, 1965, 1967, 1968, 1970, 1971, 1972, 1973, 1976, 1977, 1979, 1980, 1982, 1983, 1984, 1985, 1988, 1989, 1991, 1992, 1994, 1995, 1996, 1997, 2000, 2001, 2003, 2004, 2006, 2007, 2008, 2009, 2012, 2013, 2015, 2016, 2018, 2019, 2020, 2021, 2024, 2025, 2027, 2028, 2030, 2031, 2032, 2033, 2036, 2037, 2039, 2040, 2042, 2043, 2044, 2045, 2048, 2049, 2050, 2051, 2053, 2054, 2056, 2060, 2063, 2067, 2068, 2069, 2070, 2072, 2073, 2076, 2078, 2079, 2080, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2112, 2113, 2114, 2115, 2116, 2117, 2120, 2122, 2123, 2124, 2125, 2126, 2127, 2129, 2131, 2132, 2134, 2135, 2190, 2191, 2192, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2218, 2221, 2222, 2224, 2227, 2231, 2232, 2237, 2238, 2239, 2240, 2242, 2245, 2246, 2247, 2249, 2252, 2256, 2259, 2263, 2266, 2267, 2272, 2273, 2276, 2277, 2278, 2280, 2281, 2282, 2284, 2287, 2291, 2294, 2295, 2296, 2298, 2301, 2305, 2308, 2309, 2310, 2312, 2315, 2319, 2322, 2325, 2329, 2330, 2331, 2332, 2333, 2340, 2343, 2347, 2350, 2354, 2357, 2361, 2364, 2368, 2371, 2375, 2378, 2382, 2385, 2389, 2392, 2396, 2399, 2403, 2406, 2410, 2413, 2417, 2420, 2424, 2427, 2431, 2434, 2438, 2441, 2445, 2448, 2452, 2455, 2459, 2462, 2466, 2469, 2473, 2476, 2480, 2483, 2487, 2490, 2494, 2497, 2501, 2504, 2508, 2511, 2515, 2518, 2522, 2525, 2529, 2532, 2536, 2539, 2543, 2546, 2550, 2553, 2557, 2560, 2564, 2567, 2571, 2574, 2578, 2581, 2585, 2588, 2592, 2595, 2599, 2602, 2606, 2609, 2613, 2616, 2620, 2623, 2627, 2630, 2634, 2637, 2641, 2644, 2648, 2651, 2655, 2658, 2662, 2665, 2669, 2672, 2676, 2679, 2683, 2686, 2690, 2693, 2697, 2700, 2704, 2707, 2711, 2714, 2718, 2721, 2725, 2728, 2732, 2735, 2739, 2742, 2746, 2749, 2753, 2756, 2760, 2763, 2767, 2770, 2774, 2777, 2781, 2784, 2788, 2791, 2795, 2798, 2802, 2805, 2809, 2812, 2816, 2819, 2823, 2826, 2830};
/* BEGIN LINEINFO 
assign 1 51 248
new 0 51 248
assign 1 53 249
new 0 53 249
assign 1 54 250
new 0 54 250
assign 1 55 251
new 0 55 251
assign 1 56 252
new 0 56 252
assign 1 58 253
new 0 58 253
assign 1 59 254
new 0 59 254
assign 1 60 255
new 0 60 255
assign 1 61 256
new 0 61 256
assign 1 62 257
new 0 62 257
assign 1 63 258
new 0 63 258
assign 1 64 259
new 0 64 259
assign 1 68 260
new 0 68 260
assign 1 70 261
new 1 70 261
assign 1 71 262
ntypesGet 0 71 262
assign 1 72 263
twtokGet 0 72 263
assign 1 73 264
new 0 73 264
assign 1 73 265
new 1 73 265
assign 1 76 266
new 0 76 266
assign 1 79 267
new 0 79 267
assign 1 80 268
new 0 80 268
assign 1 86 269
new 0 86 269
assign 1 87 270
new 0 87 270
assign 1 88 271
new 0 88 271
assign 1 89 272
new 0 89 272
assign 1 89 273
new 1 89 273
assign 1 96 285
def 1 96 290
assign 1 96 291
new 0 96 291
assign 1 96 292
equals 1 96 292
assign 1 0 294
assign 1 96 297
new 0 96 297
assign 1 96 298
ends 1 96 298
assign 1 0 300
assign 1 0 303
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 97 317
new 0 97 317
return 1 97 318
assign 1 99 320
new 0 99 320
return 1 99 321
assign 1 103 327
new 0 103 327
assign 1 103 328
new 0 103 328
assign 1 103 329
swap 2 103 329
return 1 103 330
assign 1 107 337
new 0 107 337
assign 1 107 338
argsGet 0 107 338
assign 1 108 339
new 0 108 339
assign 1 108 340
main 1 108 340
exit 1 108 341
assign 1 112 353
assign 1 113 354
new 1 113 354
assign 1 114 355
new 0 114 355
assign 1 114 356
new 0 114 356
assign 1 114 357
get 2 114 357
assign 1 114 358
firstGet 0 114 358
assign 1 114 359
new 1 114 359
assign 1 115 360
new 0 115 360
assign 1 115 363
lesser 1 115 368
assign 1 116 369
go 0 116 369
incrementValue 0 115 370
return 1 118 376
assign 1 122 384
new 0 122 384
config 0 123 385
assign 1 124 386
new 0 124 386
assign 1 126 388
new 0 126 388
assign 1 127 389
doWhat 0 127 389
assign 1 128 390
new 0 128 390
assign 1 130 394
toString 0 130 394
assign 1 131 395
new 0 131 395
assign 1 132 396
new 0 132 396
assign 1 132 397
add 1 132 397
assign 1 133 398
new 0 133 398
assign 1 0 401
assign 1 0 405
assign 1 0 408
print 0 136 412
return 1 138 414
assign 1 142 420
nameGet 0 142 420
assign 1 142 421
new 0 142 421
assign 1 142 422
equals 1 142 422
return 1 144 425
assign 1 149 563
new 0 149 563
assign 1 151 564
new 0 151 564
assign 1 152 565
get 1 152 565
assign 1 152 566
def 1 152 571
assign 1 153 572
get 1 153 572
assign 1 153 573
iteratorGet 0 0 573
assign 1 153 576
hasNextGet 0 153 576
assign 1 153 578
nextGet 0 153 578
assign 1 154 579
has 1 154 579
assign 1 154 580
not 0 154 585
put 1 155 586
assign 1 156 587
new 1 156 587
addFile 1 156 588
assign 1 161 596
new 0 161 596
assign 1 161 597
nameGet 0 161 597
assign 1 161 598
new 0 161 598
assign 1 161 599
equals 1 161 599
preProcessorSet 1 162 601
assign 1 164 603
new 0 164 603
assign 1 164 604
get 1 164 604
assign 1 164 605
firstGet 0 164 605
assign 1 165 606
new 0 165 606
assign 1 165 607
has 1 165 607
assign 1 166 609
new 0 166 609
assign 1 166 610
get 1 166 610
assign 1 166 611
firstGet 0 166 611
assign 1 168 614
assign 1 170 616
new 0 170 616
assign 1 170 617
new 0 170 617
assign 1 170 618
get 2 170 618
assign 1 170 619
firstGet 0 170 619
assign 1 170 620
new 1 170 620
assign 1 170 621
pathGet 0 170 621
addStep 1 171 622
assign 1 172 623
new 0 172 623
addStep 1 172 624
assign 1 173 625
new 0 173 625
assign 1 173 626
new 0 173 626
assign 1 173 627
get 2 173 627
assign 1 173 628
firstGet 0 173 628
assign 1 173 629
new 1 173 629
assign 1 173 630
pathGet 0 173 630
assign 1 174 631
new 0 174 631
assign 1 174 632
new 0 174 632
assign 1 174 633
nameGet 0 174 633
assign 1 174 634
get 2 174 634
assign 1 174 635
firstGet 0 174 635
assign 1 174 636
new 1 174 636
assign 1 175 637
new 0 175 637
assign 1 175 638
nameGet 0 175 638
assign 1 175 639
get 2 175 639
assign 1 175 640
firstGet 0 175 640
assign 1 175 641
new 1 175 641
assign 1 176 642
new 0 176 642
assign 1 176 643
new 0 176 643
assign 1 176 644
get 2 176 644
assign 1 176 645
firstGet 0 176 645
assign 1 176 646
new 1 176 646
assign 1 177 647
new 0 177 647
assign 1 177 648
new 0 177 648
assign 1 177 649
get 2 177 649
assign 1 177 650
firstGet 0 177 650
assign 1 177 651
new 1 177 651
assign 1 178 652
new 0 178 652
assign 1 178 653
get 1 178 653
assign 1 179 654
new 0 179 654
assign 1 179 655
get 1 179 655
assign 1 181 656
new 0 181 656
assign 1 181 657
get 1 181 657
assign 1 181 658
firstGet 0 181 658
assign 1 182 659
new 0 182 659
assign 1 182 660
get 1 182 660
assign 1 182 661
firstGet 0 182 661
assign 1 183 662
new 0 183 662
assign 1 183 663
get 1 183 663
assign 1 184 664
undef 1 184 669
assign 1 185 670
new 0 185 670
assign 1 187 672
new 0 187 672
assign 1 187 673
get 1 187 673
assign 1 188 674
undef 1 188 679
assign 1 189 680
new 0 189 680
assign 1 191 682
new 0 191 682
assign 1 191 683
get 1 191 683
assign 1 192 684
undef 1 192 689
assign 1 193 690
new 0 193 690
assign 1 195 692
new 0 195 692
assign 1 195 693
get 1 195 693
assign 1 196 694
undef 1 196 699
assign 1 197 700
new 0 197 700
assign 1 199 702
new 0 199 702
assign 1 199 703
get 1 199 703
assign 1 200 704
undef 1 200 709
assign 1 201 710
new 0 201 710
assign 1 203 712
new 0 203 712
assign 1 203 713
get 1 203 713
assign 1 204 714
undef 1 204 719
assign 1 205 720
new 0 205 720
assign 1 207 722
new 0 207 722
assign 1 207 723
get 1 207 723
assign 1 208 724
undef 1 208 729
assign 1 209 730
new 0 209 730
assign 1 211 732
new 0 211 732
assign 1 211 733
get 1 211 733
assign 1 212 734
undef 1 212 739
assign 1 213 740
new 0 213 740
assign 1 215 742
new 0 215 742
assign 1 215 743
get 1 215 743
assign 1 216 744
undef 1 216 749
assign 1 217 750
new 0 217 750
assign 1 219 752
new 0 219 752
assign 1 219 753
get 1 219 753
assign 1 220 754
def 1 220 759
assign 1 221 760
firstGet 0 221 760
assign 1 223 762
new 0 223 762
assign 1 223 763
get 1 223 763
assign 1 224 764
def 1 224 769
assign 1 225 770
firstGet 0 225 770
assign 1 227 773
new 0 227 773
assign 1 229 775
new 0 229 775
assign 1 229 776
new 0 229 776
assign 1 229 777
isTrue 2 229 777
assign 1 230 778
new 0 230 778
assign 1 230 779
new 0 230 779
assign 1 230 780
isTrue 2 230 780
assign 1 231 781
new 0 231 781
assign 1 231 782
isTrue 1 231 782
assign 1 232 783
new 0 232 783
assign 1 232 784
isTrue 1 232 784
assign 1 233 785
new 0 233 785
assign 1 234 786
new 0 234 786
assign 1 234 787
get 1 234 787
assign 1 235 788
def 1 235 793
assign 1 235 794
isEmptyGet 0 235 794
assign 1 235 795
not 0 235 800
assign 1 0 801
assign 1 0 804
assign 1 0 808
assign 1 236 811
linkedListIteratorGet 0 0 811
assign 1 236 814
hasNextGet 0 236 814
assign 1 236 816
nextGet 0 236 816
put 1 237 817
assign 1 240 824
new 0 240 824
assign 1 240 825
isTrue 1 240 825
assign 1 241 826
new 0 241 826
assign 1 241 827
isTrue 1 241 827
assign 1 242 828
new 0 242 828
assign 1 242 829
isTrue 1 242 829
assign 1 243 830
new 0 243 830
assign 1 243 831
new 0 243 831
assign 1 243 832
isTrue 2 243 832
assign 1 244 833
new 0 244 833
assign 1 244 834
get 1 244 834
assign 1 245 835
new 0 245 835
assign 1 245 836
get 1 245 836
assign 1 246 837
new 0 246 837
assign 1 246 838
new 0 246 838
assign 1 246 839
get 2 246 839
assign 1 246 840
firstGet 0 246 840
assign 1 247 841
new 0 247 841
assign 1 247 842
new 0 247 842
assign 1 247 843
get 2 247 843
assign 1 247 844
firstGet 0 247 844
assign 1 248 845
new 0 248 845
assign 1 248 846
add 1 248 846
assign 1 248 847
new 0 248 847
assign 1 248 848
get 2 248 848
assign 1 248 849
firstGet 0 248 849
assign 1 249 850
new 0 249 850
assign 1 250 851
new 0 250 851
assign 1 251 852
new 0 251 852
assign 1 252 853
new 0 252 853
assign 1 253 854
new 0 253 854
assign 1 256 855
def 1 256 860
assign 1 257 861
firstGet 0 257 861
assign 1 259 864
new 0 259 864
assign 1 266 866
new 0 266 866
assign 1 266 867
add 1 266 867
assign 1 266 868
nameGet 0 266 868
assign 1 266 869
add 1 266 869
assign 1 266 870
get 1 266 870
assign 1 267 871
def 1 267 876
assign 1 268 877
orderedGet 0 268 877
addAll 1 268 878
assign 1 271 880
new 0 271 880
assign 1 271 881
add 1 271 881
assign 1 271 882
get 1 271 882
assign 1 272 883
def 1 272 888
assign 1 273 889
orderedGet 0 273 889
addAll 1 273 890
assign 1 276 892
new 0 276 892
assign 1 277 893
orderedGet 0 277 893
assign 1 277 894
iteratorGet 0 0 894
assign 1 277 897
hasNextGet 0 277 897
assign 1 277 899
nextGet 0 277 899
assign 1 278 900
new 1 278 900
addValue 1 278 901
assign 1 280 907
newlineGet 0 280 907
assign 1 281 908
assign 1 282 909
new 1 282 909
assign 1 284 910
copy 0 284 910
assign 1 285 911
fileGet 0 285 911
assign 1 285 912
existsGet 0 285 912
assign 1 285 913
not 0 285 918
assign 1 286 919
fileGet 0 286 919
makeDirs 0 286 920
assign 1 288 922
def 1 288 927
assign 1 289 928
new 1 289 928
assign 1 289 929
readerGet 0 289 929
assign 1 290 930
open 0 290 930
assign 1 290 931
readString 0 290 931
close 0 291 932
assign 1 297 946
classNameGet 0 297 946
assign 1 298 947
add 1 298 947
assign 1 298 948
new 0 298 948
assign 1 298 949
add 1 298 949
assign 1 298 950
toString 0 298 950
assign 1 298 951
add 1 298 951
assign 1 299 952
add 1 299 952
assign 1 299 953
new 0 299 953
assign 1 299 954
add 1 299 954
assign 1 299 955
toString 0 299 955
assign 1 299 956
add 1 299 956
return 1 300 957
assign 1 304 997
new 0 304 997
assign 1 305 998
classesGet 0 305 998
assign 1 305 999
valueIteratorGet 0 305 999
assign 1 305 1002
hasNextGet 0 305 1002
assign 1 306 1004
nextGet 0 306 1004
assign 1 307 1005
shouldEmitGet 0 307 1005
assign 1 307 1006
heldGet 0 307 1006
assign 1 307 1007
fromFileGet 0 307 1007
assign 1 307 1008
has 1 307 1008
assign 1 308 1010
heldGet 0 308 1010
assign 1 308 1011
namepathGet 0 308 1011
assign 1 308 1012
toString 0 308 1012
put 1 308 1013
assign 1 309 1014
usedByGet 0 309 1014
assign 1 309 1015
heldGet 0 309 1015
assign 1 309 1016
namepathGet 0 309 1016
assign 1 309 1017
toString 0 309 1017
assign 1 309 1018
get 1 309 1018
assign 1 310 1019
def 1 310 1024
assign 1 311 1025
setIteratorGet 0 0 1025
assign 1 311 1028
hasNextGet 0 311 1028
assign 1 311 1030
nextGet 0 311 1030
put 1 312 1031
assign 1 315 1038
subClassesGet 0 315 1038
assign 1 315 1039
heldGet 0 315 1039
assign 1 315 1040
namepathGet 0 315 1040
assign 1 315 1041
toString 0 315 1041
assign 1 315 1042
get 1 315 1042
assign 1 316 1043
def 1 316 1048
assign 1 317 1049
setIteratorGet 0 0 1049
assign 1 317 1052
hasNextGet 0 317 1052
assign 1 317 1054
nextGet 0 317 1054
put 1 318 1055
assign 1 323 1068
classesGet 0 323 1068
assign 1 323 1069
valueIteratorGet 0 323 1069
assign 1 323 1072
hasNextGet 0 323 1072
assign 1 324 1074
nextGet 0 324 1074
assign 1 325 1075
heldGet 0 325 1075
assign 1 325 1076
heldGet 0 325 1076
assign 1 325 1077
namepathGet 0 325 1077
assign 1 325 1078
toString 0 325 1078
assign 1 325 1079
has 1 325 1079
shouldWriteSet 1 325 1080
assign 1 332 1090
new 0 332 1090
return 1 332 1091
assign 1 336 1107
def 1 336 1112
return 1 337 1113
assign 1 342 1115
def 1 342 1120
assign 1 343 1121
firstGet 0 343 1121
assign 1 344 1122
new 0 344 1122
assign 1 344 1123
equals 1 344 1123
assign 1 345 1125
new 1 345 1125
assign 1 346 1128
new 0 346 1128
assign 1 346 1129
equals 1 346 1129
assign 1 347 1131
new 1 347 1131
assign 1 348 1134
new 0 348 1134
assign 1 348 1135
equals 1 348 1135
assign 1 349 1137
new 1 349 1137
assign 1 350 1140
new 0 350 1140
assign 1 350 1141
equals 1 350 1141
assign 1 351 1143
new 1 351 1143
assign 1 353 1146
new 0 353 1146
assign 1 353 1147
new 1 353 1147
throw 1 353 1148
return 1 355 1153
return 1 357 1155
assign 1 361 1174
apNew 1 361 1174
assign 1 363 1175
new 0 363 1175
assign 1 363 1176
add 1 363 1176
print 0 363 1177
assign 1 364 1178
new 0 364 1178
assign 1 364 1179
now 0 364 1179
assign 1 365 1180
fileGet 0 365 1180
assign 1 365 1181
readerGet 0 365 1181
assign 1 365 1182
open 0 365 1182
assign 1 366 1183
new 0 366 1183
assign 1 366 1184
deserialize 1 366 1184
close 0 367 1185
assign 1 368 1186
synClassesGet 0 368 1186
addValue 1 368 1187
assign 1 369 1188
new 0 369 1188
assign 1 369 1189
now 0 369 1189
assign 1 369 1190
subtract 1 369 1190
assign 1 370 1191
new 0 370 1191
assign 1 370 1192
add 1 370 1192
print 0 370 1193
assign 1 376 1314
new 0 376 1314
assign 1 376 1315
now 0 376 1315
assign 1 377 1316
new 0 377 1316
assign 1 378 1317
def 1 378 1322
assign 1 379 1323
linkedListIteratorGet 0 0 1323
assign 1 379 1326
hasNextGet 0 379 1326
assign 1 379 1328
nextGet 0 379 1328
loadSyns 1 380 1329
assign 1 383 1336
emitterGet 0 383 1336
assign 1 384 1337
def 1 384 1342
assign 1 385 1343
new 4 385 1343
put 1 386 1344
assign 1 388 1346
new 0 388 1346
assign 1 388 1347
add 1 388 1347
print 0 388 1348
assign 1 391 1351
new 0 391 1351
assign 1 393 1352
iteratorGet 0 0 1352
assign 1 393 1355
hasNextGet 0 393 1355
assign 1 393 1357
nextGet 0 393 1357
assign 1 394 1358
has 1 394 1358
assign 1 394 1359
not 0 394 1364
put 1 395 1365
assign 1 396 1366
new 2 396 1366
addValue 1 397 1367
assign 1 400 1374
iteratorGet 0 0 1374
assign 1 400 1377
hasNextGet 0 400 1377
assign 1 400 1379
nextGet 0 400 1379
assign 1 401 1380
has 1 401 1380
assign 1 401 1381
not 0 401 1386
put 1 402 1387
assign 1 403 1388
new 2 403 1388
addValue 1 404 1389
assign 1 405 1390
libNameGet 0 405 1390
put 1 405 1391
assign 1 410 1399
new 0 410 1399
assign 1 411 1400
iteratorGet 0 411 1400
assign 1 411 1403
hasNextGet 0 411 1403
assign 1 412 1405
nextGet 0 412 1405
assign 1 414 1406
toString 0 414 1406
assign 1 414 1407
has 1 414 1407
assign 1 415 1409
toString 0 415 1409
put 1 415 1410
doParse 1 416 1411
buildSyns 1 419 1418
assign 1 422 1420
new 0 422 1420
assign 1 422 1421
now 0 422 1421
assign 1 422 1422
subtract 1 422 1422
assign 1 425 1423
emitCommonGet 0 425 1423
assign 1 425 1424
def 1 425 1429
assign 1 427 1430
new 0 427 1430
assign 1 427 1431
now 0 427 1431
assign 1 428 1432
emitCommonGet 0 428 1432
doEmit 0 428 1433
assign 1 429 1434
new 0 429 1434
assign 1 429 1435
now 0 429 1435
assign 1 429 1436
subtract 1 429 1436
assign 1 430 1437
new 0 430 1437
assign 1 430 1438
now 0 430 1438
assign 1 430 1439
subtract 1 430 1439
assign 1 431 1440
new 0 431 1440
assign 1 431 1441
add 1 431 1441
print 0 431 1442
assign 1 432 1443
new 0 432 1443
assign 1 432 1444
add 1 432 1444
print 0 432 1445
assign 1 433 1446
new 0 433 1446
assign 1 433 1447
add 1 433 1447
print 0 433 1448
assign 1 434 1449
new 0 434 1449
return 1 434 1450
setClassesToWrite 0 437 1453
libnameInfoGet 0 438 1454
assign 1 440 1455
classesGet 0 440 1455
assign 1 440 1456
valueIteratorGet 0 440 1456
assign 1 440 1459
hasNextGet 0 440 1459
assign 1 441 1461
nextGet 0 441 1461
doEmit 1 442 1462
emitMain 0 444 1468
emitCUInit 0 445 1469
assign 1 446 1470
classesGet 0 446 1470
assign 1 446 1471
valueIteratorGet 0 446 1471
assign 1 446 1474
hasNextGet 0 446 1474
assign 1 447 1476
nextGet 0 447 1476
emitSyn 1 448 1477
assign 1 452 1484
new 0 452 1484
assign 1 452 1485
now 0 452 1485
assign 1 452 1486
subtract 1 452 1486
assign 1 453 1487
def 1 453 1492
assign 1 454 1493
new 0 454 1493
assign 1 454 1494
add 1 454 1494
print 0 454 1495
assign 1 456 1497
new 0 456 1497
assign 1 456 1498
add 1 456 1498
print 0 456 1499
prepMake 1 459 1501
assign 1 463 1504
not 0 463 1509
make 1 464 1510
deployLibrary 1 465 1511
assign 1 467 1513
linkedListIteratorGet 0 0 1513
assign 1 467 1516
hasNextGet 0 467 1516
assign 1 467 1518
nextGet 0 467 1518
assign 1 468 1519
libnameInfoGet 0 468 1519
assign 1 468 1520
unitShlibGet 0 468 1520
assign 1 469 1521
emitPathGet 0 469 1521
assign 1 469 1522
copy 0 469 1522
assign 1 470 1523
stepsGet 0 470 1523
assign 1 470 1524
lastGet 0 470 1524
addStep 1 470 1525
assign 1 471 1526
fileGet 0 471 1526
assign 1 471 1527
existsGet 0 471 1527
assign 1 472 1529
fileGet 0 472 1529
delete 0 472 1530
assign 1 474 1532
fileGet 0 474 1532
assign 1 474 1533
existsGet 0 474 1533
assign 1 474 1534
not 0 474 1534
assign 1 475 1536
fileGet 0 475 1536
assign 1 475 1537
fileGet 0 475 1537
deployFile 2 475 1538
assign 1 479 1546
iteratorGet 0 479 1546
assign 1 480 1547
iteratorGet 0 480 1547
assign 1 482 1550
hasNextGet 0 482 1550
assign 1 482 1552
hasNextGet 0 482 1552
assign 1 0 1554
assign 1 0 1557
assign 1 0 1561
assign 1 483 1564
nextGet 0 483 1564
assign 1 483 1565
apNew 1 483 1565
assign 1 484 1566
emitPathGet 0 484 1566
assign 1 484 1567
copy 0 484 1567
assign 1 484 1568
toString 0 484 1568
assign 1 484 1569
new 0 484 1569
assign 1 484 1570
add 1 484 1570
assign 1 484 1571
nextGet 0 484 1571
assign 1 484 1572
add 1 484 1572
assign 1 484 1573
apNew 1 484 1573
assign 1 486 1574
fileGet 0 486 1574
assign 1 486 1575
existsGet 0 486 1575
assign 1 487 1577
fileGet 0 487 1577
delete 0 487 1578
assign 1 489 1580
fileGet 0 489 1580
assign 1 489 1581
existsGet 0 489 1581
assign 1 489 1582
not 0 489 1582
assign 1 490 1584
fileGet 0 490 1584
assign 1 490 1585
fileGet 0 490 1585
deployFile 2 490 1586
assign 1 495 1595
new 0 495 1595
assign 1 495 1596
now 0 495 1596
assign 1 495 1597
subtract 1 495 1597
assign 1 497 1598
def 1 497 1603
assign 1 498 1604
new 0 498 1604
assign 1 498 1605
add 1 498 1605
print 0 498 1606
assign 1 500 1608
def 1 500 1613
assign 1 501 1614
new 0 501 1614
assign 1 501 1615
add 1 501 1615
print 0 501 1616
assign 1 503 1618
def 1 503 1623
assign 1 504 1624
new 0 504 1624
assign 1 504 1625
add 1 504 1625
print 0 504 1626
assign 1 508 1629
new 0 508 1629
print 0 508 1630
assign 1 509 1631
run 2 509 1631
assign 1 510 1632
new 0 510 1632
assign 1 510 1633
add 1 510 1633
assign 1 510 1634
new 0 510 1634
assign 1 510 1635
add 1 510 1635
print 0 510 1636
return 1 511 1637
assign 1 513 1639
new 0 513 1639
return 1 513 1640
assign 1 517 1653
justParsedGet 0 517 1653
assign 1 517 1654
valueIteratorGet 0 517 1654
assign 1 517 1657
hasNextGet 0 517 1657
assign 1 518 1659
nextGet 0 518 1659
assign 1 519 1660
heldGet 0 519 1660
libNameSet 1 519 1661
assign 1 520 1662
getSyn 2 520 1662
libNameSet 1 521 1663
assign 1 523 1669
justParsedGet 0 523 1669
assign 1 523 1670
valueIteratorGet 0 523 1670
assign 1 523 1673
hasNextGet 0 523 1673
assign 1 524 1675
nextGet 0 524 1675
assign 1 525 1676
heldGet 0 525 1676
assign 1 525 1677
synGet 0 525 1677
checkInheritance 2 526 1678
integrate 1 527 1679
assign 1 529 1685
new 0 529 1685
justParsedSet 1 529 1686
assign 1 533 1714
heldGet 0 533 1714
assign 1 533 1715
synGet 0 533 1715
assign 1 533 1716
def 1 533 1721
assign 1 534 1722
heldGet 0 534 1722
assign 1 534 1723
synGet 0 534 1723
return 1 534 1724
assign 1 536 1726
heldGet 0 536 1726
libNameSet 1 536 1727
assign 1 537 1728
heldGet 0 537 1728
assign 1 537 1729
extendsGet 0 537 1729
assign 1 537 1730
undef 1 537 1735
assign 1 538 1736
new 1 538 1736
assign 1 540 1739
classesGet 0 540 1739
assign 1 540 1740
heldGet 0 540 1740
assign 1 540 1741
extendsGet 0 540 1741
assign 1 540 1742
toString 0 540 1742
assign 1 540 1743
get 1 540 1743
assign 1 542 1744
def 1 542 1749
assign 1 543 1750
heldGet 0 543 1750
libNameSet 1 543 1751
assign 1 544 1752
getSyn 2 544 1752
assign 1 548 1755
heldGet 0 548 1755
assign 1 548 1756
extendsGet 0 548 1756
assign 1 548 1757
getSynNp 1 548 1757
assign 1 550 1759
new 2 550 1759
assign 1 552 1761
heldGet 0 552 1761
synSet 1 552 1762
assign 1 553 1763
heldGet 0 553 1763
assign 1 553 1764
namepathGet 0 553 1764
assign 1 553 1765
toString 0 553 1765
addSynClass 2 553 1766
return 1 554 1767
assign 1 558 1775
toString 0 558 1775
assign 1 559 1776
synClassesGet 0 559 1776
assign 1 559 1777
get 1 559 1777
assign 1 560 1778
def 1 560 1783
return 1 561 1784
assign 1 567 1786
emitterGet 0 567 1786
assign 1 567 1787
loadSyn 1 567 1787
addSynClass 2 568 1788
return 1 569 1789
assign 1 576 1793
undef 1 576 1798
assign 1 577 1799
new 1 577 1799
return 1 579 1801
assign 1 584 1880
new 1 584 1880
assign 1 585 1881
new 0 585 1881
assign 1 586 1882
emitterGet 0 586 1882
assign 1 587 1883
assign 1 588 1884
new 0 588 1884
assign 1 589 1885
shouldEmitGet 0 589 1885
put 1 589 1886
assign 1 0 1889
assign 1 0 1893
assign 1 0 1896
assign 1 592 1900
new 0 592 1900
assign 1 592 1901
toString 0 592 1901
assign 1 592 1902
add 1 592 1902
print 0 592 1903
assign 1 594 1905
assign 1 596 1906
fileGet 0 596 1906
assign 1 596 1907
readerGet 0 596 1907
assign 1 596 1908
open 0 596 1908
assign 1 596 1909
readBuffer 1 596 1909
assign 1 597 1910
fileGet 0 597 1910
assign 1 597 1911
readerGet 0 597 1911
close 0 597 1912
assign 1 598 1913
tokenize 1 598 1913
assign 1 602 1915
new 0 602 1915
echo 0 602 1916
assign 1 604 1918
outermostGet 0 604 1918
nodify 2 604 1919
assign 1 606 1921
new 0 606 1921
print 0 606 1922
assign 1 607 1923
new 2 607 1923
traverse 1 607 1924
assign 1 611 1927
new 0 611 1927
echo 0 611 1928
assign 1 613 1930
new 0 613 1930
traverse 1 613 1931
assign 1 615 1933
new 0 615 1933
print 0 615 1934
assign 1 616 1935
new 2 616 1935
traverse 1 616 1936
assign 1 619 1939
new 0 619 1939
echo 0 619 1940
assign 1 622 1942
new 0 622 1942
traverse 1 622 1943
contain 0 623 1944
assign 1 625 1946
new 0 625 1946
print 0 625 1947
assign 1 626 1948
new 2 626 1948
traverse 1 626 1949
assign 1 630 1952
new 0 630 1952
echo 0 630 1953
assign 1 632 1955
new 0 632 1955
traverse 1 632 1956
assign 1 634 1958
new 0 634 1958
print 0 634 1959
assign 1 635 1960
new 2 635 1960
traverse 1 635 1961
assign 1 639 1964
new 0 639 1964
echo 0 639 1965
assign 1 641 1967
new 0 641 1967
traverse 1 641 1968
assign 1 643 1970
new 0 643 1970
print 0 643 1971
assign 1 644 1972
new 2 644 1972
traverse 1 644 1973
assign 1 648 1976
new 0 648 1976
echo 0 648 1977
assign 1 650 1979
new 0 650 1979
traverse 1 650 1980
assign 1 652 1982
new 0 652 1982
print 0 652 1983
assign 1 653 1984
new 2 653 1984
traverse 1 653 1985
assign 1 657 1988
new 0 657 1988
echo 0 657 1989
assign 1 659 1991
new 0 659 1991
traverse 1 659 1992
assign 1 661 1994
new 0 661 1994
print 0 661 1995
assign 1 662 1996
new 2 662 1996
traverse 1 662 1997
assign 1 666 2000
new 0 666 2000
echo 0 666 2001
assign 1 668 2003
new 0 668 2003
traverse 1 668 2004
assign 1 670 2006
new 0 670 2006
print 0 670 2007
assign 1 671 2008
new 2 671 2008
traverse 1 671 2009
assign 1 675 2012
new 0 675 2012
echo 0 675 2013
assign 1 677 2015
new 0 677 2015
traverse 1 677 2016
assign 1 679 2018
new 0 679 2018
print 0 679 2019
assign 1 680 2020
new 2 680 2020
traverse 1 680 2021
assign 1 684 2024
new 0 684 2024
echo 0 684 2025
assign 1 686 2027
new 0 686 2027
traverse 1 686 2028
assign 1 688 2030
new 0 688 2030
print 0 688 2031
assign 1 689 2032
new 2 689 2032
traverse 1 689 2033
assign 1 692 2036
new 0 692 2036
echo 0 692 2037
assign 1 694 2039
new 0 694 2039
traverse 1 694 2040
assign 1 696 2042
new 0 696 2042
print 0 696 2043
assign 1 697 2044
new 2 697 2044
traverse 1 697 2045
assign 1 701 2048
new 0 701 2048
echo 0 701 2049
assign 1 702 2050
new 0 702 2050
print 0 702 2051
assign 1 704 2053
new 0 704 2053
traverse 1 704 2054
assign 1 0 2056
assign 1 0 2060
assign 1 0 2063
assign 1 706 2067
new 0 706 2067
print 0 706 2068
assign 1 707 2069
new 2 707 2069
traverse 1 707 2070
assign 1 709 2072
classesGet 0 709 2072
assign 1 709 2073
valueIteratorGet 0 709 2073
assign 1 709 2076
hasNextGet 0 709 2076
assign 1 710 2078
nextGet 0 710 2078
assign 1 712 2079
transUnitGet 0 712 2079
assign 1 713 2080
new 1 713 2080
assign 1 714 2081
TRANSUNITGet 0 714 2081
typenameSet 1 714 2082
assign 1 715 2083
new 0 715 2083
assign 1 716 2084
heldGet 0 716 2084
assign 1 716 2085
emitsGet 0 716 2085
emitsSet 1 716 2086
heldSet 1 717 2087
delete 0 718 2088
addValue 1 719 2089
copyLoc 1 720 2090
reInitContained 0 726 2112
assign 1 727 2113
containedGet 0 727 2113
assign 1 728 2114
new 0 728 2114
assign 1 729 2115
new 0 729 2115
assign 1 729 2116
crGet 0 729 2116
assign 1 730 2117
linkedListIteratorGet 0 730 2117
assign 1 730 2120
hasNextGet 0 730 2120
assign 1 731 2122
new 1 731 2122
assign 1 732 2123
nextGet 0 732 2123
heldSet 1 732 2124
nlcSet 1 733 2125
assign 1 734 2126
heldGet 0 734 2126
assign 1 734 2127
equals 1 734 2127
assign 1 735 2129
increment 0 735 2129
assign 1 737 2131
heldGet 0 737 2131
assign 1 737 2132
notEquals 1 737 2132
addValue 1 738 2134
containerSet 1 739 2135
assign 1 746 2190
new 0 746 2190
fromString 1 747 2191
assign 1 749 2192
new 1 749 2192
assign 1 750 2193
NAMEPATHGet 0 750 2193
typenameSet 1 750 2194
heldSet 1 751 2195
copyLoc 1 752 2196
assign 1 754 2197
new 0 754 2197
assign 1 755 2198
new 0 755 2198
nameSet 1 755 2199
assign 1 756 2200
new 0 756 2200
wasBoundSet 1 756 2201
assign 1 757 2202
new 0 757 2202
boundSet 1 757 2203
assign 1 758 2204
new 0 758 2204
isConstructSet 1 758 2205
assign 1 759 2206
new 0 759 2206
isLiteralSet 1 759 2207
assign 1 760 2208
heldGet 0 760 2208
literalValueSet 1 760 2209
addValue 1 762 2210
assign 1 764 2211
CALLGet 0 764 2211
typenameSet 1 764 2212
heldSet 1 765 2213
resolveNp 0 767 2214
assign 1 769 2215
new 0 769 2215
assign 1 769 2216
equals 1 769 2216
assign 1 0 2218
assign 1 769 2221
new 0 769 2221
assign 1 769 2222
equals 1 769 2222
assign 1 0 2224
assign 1 0 2227
assign 1 770 2231
priorPeerGet 0 770 2231
assign 1 771 2232
def 1 771 2237
assign 1 771 2238
typenameGet 0 771 2238
assign 1 771 2239
SUBTRACTGet 0 771 2239
assign 1 771 2240
equals 1 771 2240
assign 1 0 2242
assign 1 771 2245
typenameGet 0 771 2245
assign 1 771 2246
ADDGet 0 771 2246
assign 1 771 2247
equals 1 771 2247
assign 1 0 2249
assign 1 0 2252
assign 1 0 2256
assign 1 0 2259
assign 1 0 2263
assign 1 772 2266
priorPeerGet 0 772 2266
assign 1 773 2267
undef 1 773 2272
assign 1 0 2273
assign 1 773 2276
typenameGet 0 773 2276
assign 1 773 2277
CALLGet 0 773 2277
assign 1 773 2278
notEquals 1 773 2278
assign 1 773 2280
typenameGet 0 773 2280
assign 1 773 2281
IDGet 0 773 2281
assign 1 773 2282
notEquals 1 773 2282
assign 1 0 2284
assign 1 0 2287
assign 1 0 2291
assign 1 773 2294
typenameGet 0 773 2294
assign 1 773 2295
VARGet 0 773 2295
assign 1 773 2296
notEquals 1 773 2296
assign 1 0 2298
assign 1 0 2301
assign 1 0 2305
assign 1 773 2308
typenameGet 0 773 2308
assign 1 773 2309
ACCESSORGet 0 773 2309
assign 1 773 2310
notEquals 1 773 2310
assign 1 0 2312
assign 1 0 2315
assign 1 0 2319
assign 1 0 2322
assign 1 0 2325
assign 1 779 2329
heldGet 0 779 2329
assign 1 779 2330
literalValueGet 0 779 2330
assign 1 779 2331
add 1 779 2331
literalValueSet 1 779 2332
delete 0 780 2333
return 1 0 2340
assign 1 0 2343
return 1 0 2347
assign 1 0 2350
return 1 0 2354
assign 1 0 2357
return 1 0 2361
assign 1 0 2364
return 1 0 2368
assign 1 0 2371
return 1 0 2375
assign 1 0 2378
return 1 0 2382
assign 1 0 2385
return 1 0 2389
assign 1 0 2392
return 1 0 2396
assign 1 0 2399
return 1 0 2403
assign 1 0 2406
return 1 0 2410
assign 1 0 2413
return 1 0 2417
assign 1 0 2420
return 1 0 2424
assign 1 0 2427
return 1 0 2431
assign 1 0 2434
return 1 0 2438
assign 1 0 2441
return 1 0 2445
assign 1 0 2448
return 1 0 2452
assign 1 0 2455
return 1 0 2459
assign 1 0 2462
return 1 0 2466
assign 1 0 2469
return 1 0 2473
assign 1 0 2476
return 1 0 2480
assign 1 0 2483
return 1 0 2487
assign 1 0 2490
return 1 0 2494
assign 1 0 2497
return 1 0 2501
assign 1 0 2504
return 1 0 2508
assign 1 0 2511
return 1 0 2515
assign 1 0 2518
return 1 0 2522
assign 1 0 2525
return 1 0 2529
assign 1 0 2532
return 1 0 2536
assign 1 0 2539
return 1 0 2543
assign 1 0 2546
return 1 0 2550
assign 1 0 2553
return 1 0 2557
assign 1 0 2560
return 1 0 2564
assign 1 0 2567
return 1 0 2571
assign 1 0 2574
return 1 0 2578
assign 1 0 2581
return 1 0 2585
assign 1 0 2588
return 1 0 2592
assign 1 0 2595
return 1 0 2599
assign 1 0 2602
return 1 0 2606
assign 1 0 2609
return 1 0 2613
assign 1 0 2616
return 1 0 2620
assign 1 0 2623
return 1 0 2627
assign 1 0 2630
return 1 0 2634
assign 1 0 2637
return 1 0 2641
assign 1 0 2644
return 1 0 2648
assign 1 0 2651
return 1 0 2655
assign 1 0 2658
return 1 0 2662
assign 1 0 2665
return 1 0 2669
assign 1 0 2672
return 1 0 2676
assign 1 0 2679
return 1 0 2683
assign 1 0 2686
return 1 0 2690
assign 1 0 2693
return 1 0 2697
assign 1 0 2700
return 1 0 2704
assign 1 0 2707
return 1 0 2711
assign 1 0 2714
return 1 0 2718
assign 1 0 2721
return 1 0 2725
assign 1 0 2728
return 1 0 2732
assign 1 0 2735
return 1 0 2739
assign 1 0 2742
return 1 0 2746
assign 1 0 2749
return 1 0 2753
assign 1 0 2756
return 1 0 2760
assign 1 0 2763
return 1 0 2767
assign 1 0 2770
return 1 0 2774
assign 1 0 2777
return 1 0 2781
assign 1 0 2784
return 1 0 2788
assign 1 0 2791
return 1 0 2795
assign 1 0 2798
return 1 0 2802
assign 1 0 2805
return 1 0 2809
assign 1 0 2812
return 1 0 2816
assign 1 0 2819
return 1 0 2823
assign 1 0 2826
assign 1 0 2830
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1826655669: return bem_echo_0();
case 1232567589: return bem_new_0();
case -2125321342: return bem_readBufferGet_0();
case 1147159390: return bem_emitFileHeaderGet_0();
case -1852234885: return bem_paramsGet_0();
case 1331509596: return bem_initLibsGet_0();
case 1080618778: return bem_toBuildGet_0();
case -2117276183: return bem_estrGet_0();
case -751534347: return bem_tagGet_0();
case 1286809812: return bem_doEmitGet_0();
case -686059026: return bem_emitterGet_0();
case 889832628: return bem_codeGet_0();
case 591133328: return bem_once_0();
case 1852738769: return bem_loadSynsGet_0();
case 2032036219: return bem_nlGet_0();
case 1776714267: return bem_printPlacesGet_0();
case 1309335590: return bem_putLineNumbersInTraceGet_0();
case 1943460864: return bem_printAllAstGet_0();
case 156988171: return bem_toAny_0();
case 464576196: return bem_sharedEmitterGet_0();
case -1510717441: return bem_newlineGet_0();
case -1096274441: return bem_emitLangsGet_0();
case 1711478499: return bem_linkLibArgsGet_0();
case -413416355: return bem_makeGet_0();
case -204006126: return bem_usedLibrarysGet_0();
case 492009704: return bem_deployUsedLibrariesGet_0();
case 1304433578: return bem_libNameGet_0();
case 1485341832: return bem_emitFlagsGet_0();
case -216680392: return bem_outputPlatformGet_0();
case 1120764293: return bem_closeLibrariesGet_0();
case 364146106: return bem_toString_0();
case -1984451363: return bem_config_0();
case -898231284: return bem_emitCs_0();
case 1521168988: return bem_makeNameGet_0();
case 331587070: return bem_makeArgsGet_0();
case 699093085: return bem_ntypesGet_0();
case 169016919: return bem_deserializeClassNameGet_0();
case -1620581911: return bem_saveSynsGet_0();
case -2063172864: return bem_main_0();
case -1694865880: return bem_serializeToString_0();
case -134095758: return bem_doWhat_0();
case -149685634: return bem_printAstGet_0();
case -2037273379: return bem_ownProcessGet_0();
case 1153840868: return bem_emitDebugGet_0();
case 1743501024: return bem_emitLibraryGet_0();
case -1136097126: return bem_closeLibrariesStrGet_0();
case -2020453198: return bem_includePathGet_0();
case -1815534169: return bem_genOnlyGet_0();
case -584825720: return bem_compilerGet_0();
case 1388275186: return bem_extIncludesGet_0();
case 2058891631: return bem_prepMakeGet_0();
case -602501422: return bem_extLinkObjectsGet_0();
case 100118237: return bem_runArgsGet_0();
case -1633658372: return bem_twtokGet_0();
case -1838224962: return bem_compilerProfileGet_0();
case 747222940: return bem_serializationIteratorGet_0();
case 576731698: return bem_buildPathGet_0();
case -922777323: return bem_buildMessageGet_0();
case 1651099395: return bem_copy_0();
case -769266490: return bem_usedLibrarysStrGet_0();
case 1987646781: return bem_printStepsGet_0();
case 2014511524: return bem_emitDataGet_0();
case 138118576: return bem_classNameGet_0();
case 1168231810: return bem_builtGet_0();
case 86234609: return bem_print_0();
case -1209311909: return bem_deployPathGet_0();
case 1553389494: return bem_exeNameGet_0();
case -930290801: return bem_parseTimeGet_0();
case -159488501: return bem_ccObjArgsGet_0();
case 173912112: return bem_iteratorGet_0();
case -804026772: return bem_printAstElementsGet_0();
case 1030306077: return bem_hashGet_0();
case 338711465: return bem_mainNameGet_0();
case 1296866865: return bem_deployFilesFromGet_0();
case -1322014294: return bem_parseGet_0();
case -1249085648: return bem_startTimeGet_0();
case 1204467547: return bem_fromFileGet_0();
case 774868823: return bem_many_0();
case 1145929678: return bem_extLibsGet_0();
case 1118637242: return bem_buildSucceededGet_0();
case -2038972632: return bem_setClassesToWrite_0();
case 1019449422: return bem_lctokGet_0();
case -1515350928: return bem_argsGet_0();
case 1335363828: return bem_serializeContents_0();
case 1315116957: return bem_emitCommonGet_0();
case -280775252: return bem_runGet_0();
case 780221192: return bem_go_0();
case -260000531: return bem_platformGet_0();
case 47142795: return bem_constantsGet_0();
case -2016811412: return bem_parseEmitTimeGet_0();
case 1287251000: return bem_emitPathGet_0();
case 1246581829: return bem_parseEmitCompileTimeGet_0();
case 605463834: return bem_sourceFileNameGet_0();
case 1804394239: return bem_create_0();
case -936851177: return bem_deployLibraryGet_0();
case 2128738390: return bem_deployFilesToGet_0();
case 441873246: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1395913548: return bem_lctokSet_1(bevd_0);
case -2062539484: return bem_compilerSet_1(bevd_0);
case -1909590624: return bem_makeArgsSet_1(bevd_0);
case 811064880: return bem_emitFileHeaderSet_1(bevd_0);
case -1166622465: return bem_libNameSet_1(bevd_0);
case 818668120: return bem_def_1(bevd_0);
case -2053908234: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 233607642: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 799088842: return bem_makeSet_1(bevd_0);
case -1035786087: return bem_emitLibrarySet_1(bevd_0);
case -66688367: return bem_sameClass_1(bevd_0);
case 2118556574: return bem_codeSet_1(bevd_0);
case 1989264620: return bem_saveSynsSet_1(bevd_0);
case -1956631655: return bem_loadSynsSet_1(bevd_0);
case 1772062470: return bem_prepMakeSet_1(bevd_0);
case 104199801: return bem_buildPathSet_1(bevd_0);
case 1549364272: return bem_emitDebugSet_1(bevd_0);
case 2142760047: return bem_usedLibrarysStrSet_1(bevd_0);
case -1634052615: return bem_nlSet_1(bevd_0);
case 214046985: return bem_deployLibrarySet_1(bevd_0);
case -1155639850: return bem_compilerProfileSet_1(bevd_0);
case 1697983615: return bem_emitFlagsSet_1(bevd_0);
case -729372880: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -293276429: return bem_undefined_1(bevd_0);
case 841231410: return bem_toBuildSet_1(bevd_0);
case 1634584505: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case 2045171968: return bem_mainNameSet_1(bevd_0);
case 1022281941: return bem_defined_1(bevd_0);
case -1611890014: return bem_ntypesSet_1(bevd_0);
case -1631371934: return bem_parseEmitTimeSet_1(bevd_0);
case 1089503579: return bem_argsSet_1(bevd_0);
case 1579581723: return bem_extIncludesSet_1(bevd_0);
case 1955243497: return bem_deployFilesFromSet_1(bevd_0);
case -651163126: return bem_exeNameSet_1(bevd_0);
case -1527766771: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case -1790149278: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1778648585: return bem_runArgsSet_1(bevd_0);
case -1660628501: return bem_printStepsSet_1(bevd_0);
case -956577031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 777322209: return bem_builtSet_1(bevd_0);
case -1860642290: return bem_deployUsedLibrariesSet_1(bevd_0);
case 775327877: return bem_runSet_1(bevd_0);
case -468516453: return bem_closeLibrariesSet_1(bevd_0);
case -1209387497: return bem_otherType_1(bevd_0);
case -2077086955: return bem_sameType_1(bevd_0);
case 1484558: return bem_parseTimeSet_1(bevd_0);
case 571236585: return bem_fromFileSet_1(bevd_0);
case 1236794240: return bem_includePathSet_1(bevd_0);
case 347406732: return bem_buildSucceededSet_1(bevd_0);
case 682569502: return bem_buildSyns_1(bevd_0);
case -1213491412: return bem_printPlacesSet_1(bevd_0);
case -645967962: return bem_getSynNp_1(bevd_0);
case 1474300848: return bem_readBufferSet_1(bevd_0);
case 1049342566: return bem_equals_1(bevd_0);
case -381322928: return bem_genOnlySet_1(bevd_0);
case 1388122193: return bem_otherClass_1(bevd_0);
case 82508960: return bem_closeLibrariesStrSet_1(bevd_0);
case 1102156266: return bem_sharedEmitterSet_1(bevd_0);
case 2077405559: return bem_emitLangsSet_1(bevd_0);
case 46646439: return bem_emitPathSet_1(bevd_0);
case 1457561605: return bem_newlineSet_1(bevd_0);
case -2057161492: return bem_ownProcessSet_1(bevd_0);
case 52212852: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -1095839380: return bem_linkLibArgsSet_1(bevd_0);
case -1510418614: return bem_twtokSet_1(bevd_0);
case 1088093158: return bem_deployFilesToSet_1(bevd_0);
case 2105172549: return bem_deployPathSet_1(bevd_0);
case 1626251132: return bem_printAstSet_1(bevd_0);
case 1014783398: return bem_outputPlatformSet_1(bevd_0);
case -2078921482: return bem_notEquals_1(bevd_0);
case 397202009: return bem_ccObjArgsSet_1(bevd_0);
case 2029274791: return bem_printAstElementsSet_1(bevd_0);
case 143426895: return bem_undef_1(bevd_0);
case 848974926: return bem_doEmitSet_1(bevd_0);
case -501339836: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 2106885574: return bem_makeNameSet_1(bevd_0);
case 280312858: return bem_sameObject_1(bevd_0);
case 619316649: return bem_doParse_1(bevd_0);
case 534197754: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1938602708: return bem_startTimeSet_1(bevd_0);
case 1731809749: return bem_buildMessageSet_1(bevd_0);
case 1581578746: return bem_initLibsSet_1(bevd_0);
case -1452139128: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -1801886846: return bem_extLibsSet_1(bevd_0);
case 1794573498: return bem_extLinkObjectsSet_1(bevd_0);
case -1596391761: return bem_constantsSet_1(bevd_0);
case 1764830786: return bem_usedLibrarysSet_1(bevd_0);
case 1891585784: return bem_emitDataSet_1(bevd_0);
case -2137782420: return bem_paramsSet_1(bevd_0);
case -320853656: return bem_platformSet_1(bevd_0);
case 1072049651: return bem_printAllAstSet_1(bevd_0);
case 968223386: return bem_estrSet_1(bevd_0);
case -938959949: return bem_parseSet_1(bevd_0);
case 1841110471: return bem_emitCommonSet_1(bevd_0);
case -548232463: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -265807180: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -936134816: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2076718904: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -1675250987: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2037027110: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 808469705: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1426116931: return bem_buildLiteral_2(bevd_0, bevd_1);
case -156190820: return bem_getSyn_2(bevd_0, bevd_1);
case -1991243589: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2096067718: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
}
}
