namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_12, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_60, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_63, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_68, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x63,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_70, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_105, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_106, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_107 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_107, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_108 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_108, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_109 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_109, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_110 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_110, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_111 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_111, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_112 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_112, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_113 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_114 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_115 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static new BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static new BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_singleCC = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_saveSyns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_saveIds = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 99 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 117 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 117 */
 else  /* Line: 117 */ {
break;
} /* Line: 117 */
} /* Line: 117 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bem_config_0();
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 127 */ {
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 130 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(952056940);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 135 */
if (bevp_printSteps.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 137 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 137 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 138 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(1961725837);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1911701664, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 144 */ {
} /* Line: 144 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_120_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_126_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_129_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpany_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_5_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_6_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 155 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 155 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(2034429922);
bevt_9_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpany_phold);
} /* Line: 158 */
} /* Line: 156 */
 else  /* Line: 155 */ {
break;
} /* Line: 155 */
} /* Line: 155 */
} /* Line: 155 */
bevt_13_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_nameGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_equals_1(bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 164 */
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_15_tmpany_phold = bevp_params.bem_get_1(bevt_16_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_17_tmpany_phold = bevp_params.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_19_tmpany_phold = bevp_params.bem_get_1(bevt_20_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_firstGet_0();
} /* Line: 168 */
 else  /* Line: 169 */ {
bevp_exeName = bevp_libName;
} /* Line: 170 */
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_23_tmpany_phold = bevp_params.bem_get_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_firstGet_0();
bevt_21_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpany_phold);
bevp_buildPath = bevt_21_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_29_tmpany_phold = bevp_params.bem_get_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_firstGet_0();
bevt_27_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpany_phold);
bevp_includePath = bevt_27_tmpany_phold.bem_pathGet_0();
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_36_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_nameGet_0();
bevt_33_tmpany_phold = bevp_params.bem_get_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpany_phold );
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_40_tmpany_phold = bevp_platform.bemd_0(1961725837);
bevt_38_tmpany_phold = bevp_params.bem_get_2(bevt_39_tmpany_phold, (BEC_2_4_6_TextString) bevt_40_tmpany_phold );
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpany_phold );
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_42_tmpany_phold = bevp_params.bem_get_2(bevt_43_tmpany_phold, bevt_44_tmpany_phold);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_26));
bevt_46_tmpany_phold = bevp_params.bem_get_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpany_phold);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_28));
bevt_50_tmpany_phold = bevp_params.bem_get_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_29));
bevp_loadSyns = bevp_params.bem_get_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_30));
bevp_initLibs = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_31));
bevt_55_tmpany_phold = bevp_params.bem_get_1(bevt_56_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_55_tmpany_phold.bem_firstGet_0();
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_32));
bevt_57_tmpany_phold = bevp_params.bem_get_1(bevt_58_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_57_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_59_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 188 */
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_61_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 192 */
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_63_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 196 */
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_65_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 200 */
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_67_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 203 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 204 */
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_69_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 208 */
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_71_tmpany_phold);
if (bevp_extLibs == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 212 */
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_73_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_74_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 216 */
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_75_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 220 */
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_77_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-559768395);
} /* Line: 224 */
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_79_tmpany_phold);
if (bevp_runArgs == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-559768395);
} /* Line: 228 */
 else  /* Line: 229 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 230 */
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_44));
bevt_82_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevt_84_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_86_tmpany_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_87_tmpany_phold);
if (bevl_pacm == null) {
bevt_88_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_90_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_90_tmpany_phold.bevi_bool) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
 else  /* Line: 238 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 238 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 239 */ {
bevt_91_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_91_tmpany_phold).bevi_bool) /* Line: 239 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 240 */
 else  /* Line: 239 */ {
break;
} /* Line: 239 */
} /* Line: 239 */
} /* Line: 239 */
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_53));
bevt_97_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevp_emitLangs = bevp_params.bem_get_1(bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_55));
bevp_emitFlags = bevp_params.bem_get_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_100_tmpany_phold = bevp_params.bem_get_2(bevt_101_tmpany_phold, bevt_102_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_100_tmpany_phold.bem_firstGet_0();
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_59));
bevt_103_tmpany_phold = bevp_params.bem_get_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_103_tmpany_phold.bem_firstGet_0();
bevt_108_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bem_add_1(bevp_makeName);
bevt_109_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_106_tmpany_phold = bevp_params.bem_get_2(bevt_107_tmpany_phold, bevt_109_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_106_tmpany_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_110_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_110_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_110_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 261 */
 else  /* Line: 262 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_62));
} /* Line: 263 */
bevt_113_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_112_tmpany_phold = bevl_outLang.bem_add_1(bevt_113_tmpany_phold);
bevt_114_tmpany_phold = bevp_platform.bemd_0(1961725837);
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bem_add_1(bevt_114_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_111_tmpany_phold);
if (bevl_platformSources == null) {
bevt_115_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_115_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 271 */ {
bevt_116_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_116_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 272 */
bevt_118_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_117_tmpany_phold = bevl_outLang.bem_add_1(bevt_118_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_117_tmpany_phold);
if (bevl_langSources == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_120_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_120_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 277 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_121_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpany_loop = bevt_121_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 281 */ {
bevt_122_tmpany_phold = bevt_2_tmpany_loop.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_122_tmpany_phold).bevi_bool) /* Line: 281 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(2034429922);
bevt_123_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_123_tmpany_phold);
} /* Line: 282 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(-1400395933);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_126_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_125_tmpany_phold = bevt_126_tmpany_phold.bem_existsGet_0();
if (bevt_125_tmpany_phold.bevi_bool) {
bevt_124_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_124_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_124_tmpany_phold.bevi_bool) /* Line: 289 */ {
bevt_127_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_127_tmpany_phold.bem_makeDirs_0();
} /* Line: 290 */
if (bevp_emitFileHeader == null) {
bevt_128_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_128_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_128_tmpany_phold.bevi_bool) /* Line: 292 */ {
bevt_129_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_129_tmpany_phold.bem_readerGet_0();
bevt_130_tmpany_phold = bevl_emr.bemd_0(669384034);
bevp_emitFileHeader = bevt_130_tmpany_phold.bemd_0(1485896198);
bevl_emr.bemd_0(639555649);
} /* Line: 295 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(2043797984, bevp_nl);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(2043797984, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(2043797984, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(2043797984, bevp_nl);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(2043797984, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(2043797984, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 309 */ {
bevl_clnode = bevl_ci.bemd_0(2034429922);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(1690604512);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(1510609291);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(1690604512);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(79974186);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(952056940);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(1690604512);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(79974186);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(952056940);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 315 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 315 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 316 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 315 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(1690604512);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(79974186);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(952056940);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 321 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 322 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 320 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 327 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 327 */ {
bevl_clnode = bevl_ci.bemd_0(2034429922);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(1690604512);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(1690604512);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(79974186);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(952056940);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(389268375, bevt_26_tmpany_phold);
} /* Line: 329 */
 else  /* Line: 327 */ {
break;
} /* Line: 327 */
} /* Line: 327 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 340 */ {
return bevp_emitCommon;
} /* Line: 341 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 349 */
 else  /* Line: 348 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 348 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 352 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 353 */
 else  /* Line: 348 */ {
bevt_9_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_8_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 354 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 355 */
 else  /* Line: 356 */ {
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_71));
bevt_10_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 357 */
} /* Line: 348 */
} /* Line: 348 */
} /* Line: 348 */
return bevp_emitCommon;
} /* Line: 359 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = (BEC_2_4_8_TimeInterval) bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(669384034);
bevt_5_tmpany_phold = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 383 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 383 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 384 */
 else  /* Line: 383 */ {
break;
} /* Line: 383 */
} /* Line: 383 */
} /* Line: 383 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 391 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 392 */
} /* Line: 391 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(1794518227);
while (true)
 /* Line: 397 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 397 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(2034429922);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 398 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 401 */
} /* Line: 398 */
 else  /* Line: 397 */ {
break;
} /* Line: 397 */
} /* Line: 397 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(1794518227);
while (true)
 /* Line: 404 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 404 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(2034429922);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(-500511233);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 409 */
} /* Line: 405 */
 else  /* Line: 404 */ {
break;
} /* Line: 404 */
} /* Line: 404 */
if (bevp_parse.bevi_bool) /* Line: 412 */ {
bevl_built = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 415 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 415 */ {
bevl_tb = bevl_i.bemd_0(2034429922);
bevt_20_tmpany_phold = bevl_tb.bemd_0(952056940);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 418 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(952056940);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 420 */
} /* Line: 418 */
 else  /* Line: 415 */ {
break;
} /* Line: 415 */
} /* Line: 415 */
bem_buildSyns_1(bevl_em);
} /* Line: 423 */
bevt_23_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 429 */ {
bevt_26_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 438 */
if (bevp_doEmit.bevi_bool) /* Line: 440 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(1948151804);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 444 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 444 */ {
bevl_clnode = bevl_ci.bemd_0(2034429922);
bevl_em.bemd_1(906368108, bevl_clnode);
} /* Line: 446 */
 else  /* Line: 444 */ {
break;
} /* Line: 444 */
} /* Line: 444 */
bevl_em.bemd_0(-373007813);
bevl_em.bemd_0(-1663455327);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 450 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 450 */ {
bevl_clnode = bevl_ci.bemd_0(2034429922);
bevl_em.bemd_1(-1034786014, bevl_clnode);
} /* Line: 452 */
 else  /* Line: 450 */ {
break;
} /* Line: 450 */
} /* Line: 450 */
} /* Line: 450 */
bevt_44_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 458 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 461 */ {
bevl_em.bemd_1(124800040, bevp_deployLibrary);
} /* Line: 463 */
if (bevp_make.bevi_bool) /* Line: 466 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 467 */ {
bevl_em.bemd_1(1533107845, bevp_deployLibrary);
bevl_em.bemd_1(2058349527, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 470 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 471 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 471 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(1948151804);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(-1436136551);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(1020856154);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(-2146908948);
bevl_cpTo.bemd_1(996563628, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(1166825207);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(-178905337);
if (((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 475 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(1166825207);
bevt_58_tmpany_phold.bemd_0(508078997);
} /* Line: 476 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(1166825207);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(-178905337);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(1343413621);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 478 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(1166825207);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(1166825207);
bevl_em.bemd_2(1163441681, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 479 */
} /* Line: 478 */
 else  /* Line: 471 */ {
break;
} /* Line: 471 */
} /* Line: 471 */
} /* Line: 471 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 486 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 486 */
 else  /* Line: 486 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 486 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(2034429922);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(2034429922);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(1166825207);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(-178905337);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 490 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(1166825207);
bevt_76_tmpany_phold.bemd_0(508078997);
} /* Line: 491 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(1166825207);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(-178905337);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(1343413621);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 493 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(1166825207);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(1166825207);
bevl_em.bemd_2(1163441681, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 494 */
} /* Line: 493 */
 else  /* Line: 486 */ {
break;
} /* Line: 486 */
} /* Line: 486 */
} /* Line: 486 */
} /* Line: 467 */
bevt_83_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 501 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 502 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 504 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 505 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 507 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 508 */
if (bevp_run.bevi_bool) /* Line: 511 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(-1502805544, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 515 */
bevt_98_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 521 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 521 */ {
bevl_kls = bevl_ci.bemd_0(2034429922);
bevt_2_tmpany_phold = bevl_kls.bemd_0(1690604512);
bevt_2_tmpany_phold.bemd_1(585852282, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(585852282, bevp_libName);
} /* Line: 525 */
 else  /* Line: 521 */ {
break;
} /* Line: 521 */
} /* Line: 521 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 527 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 527 */ {
bevl_kls = bevl_ci.bemd_0(2034429922);
bevt_5_tmpany_phold = bevl_kls.bemd_0(1690604512);
bevl_syn = bevt_5_tmpany_phold.bemd_0(-23896719);
bevl_syn.bemd_2(619875365, this, bevl_kls);
bevl_syn.bemd_1(2064782550, this);
} /* Line: 531 */
 else  /* Line: 527 */ {
break;
} /* Line: 527 */
} /* Line: 527 */
bevt_6_tmpany_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(1690604512);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-23896719);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 537 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(1690604512);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-23896719);
return bevt_3_tmpany_phold;
} /* Line: 538 */
bevt_5_tmpany_phold = beva_klass.bemd_0(1690604512);
bevt_5_tmpany_phold.bemd_1(585852282, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(1690604512);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-142325041);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 541 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 542 */
 else  /* Line: 543 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(1690604512);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-142325041);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(952056940);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 546 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(1690604512);
bevt_14_tmpany_phold.bemd_1(585852282, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 548 */
 else  /* Line: 549 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(1690604512);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-142325041);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 552 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 554 */
bevt_17_tmpany_phold = beva_klass.bemd_0(1690604512);
bevt_17_tmpany_phold.bemd_1(-331801579, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(1690604512);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(79974186);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(952056940);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(952056940);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 564 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 565 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(-1895444838, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 580 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 581 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 594 */ {
if (bevp_printSteps.bevi_bool) /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 595 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 595 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 595 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 595 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_5_tmpany_phold = beva_toParse.bemd_0(952056940);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 596 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(1166825207);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(710992024);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(669384034);
bevl_src = bevt_6_tmpany_phold.bemd_1(-324711976, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(1166825207);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(710992024);
bevt_9_tmpany_phold.bemd_0(639555649);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 607 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 608 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(690659568);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 611 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_14_tmpany_phold);
} /* Line: 613 */
if (bevp_printSteps.bevi_bool) /* Line: 616 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 617 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-463411174, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 620 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_18_tmpany_phold);
} /* Line: 622 */
if (bevp_printSteps.bevi_bool) /* Line: 624 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 625 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-463411174, bevt_20_tmpany_phold);
bevl_trans.bemd_0(513631706);
if (bevp_printAllAst.bevi_bool) /* Line: 630 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_22_tmpany_phold);
} /* Line: 632 */
if (bevp_printSteps.bevi_bool) /* Line: 635 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 636 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-463411174, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 639 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_26_tmpany_phold);
} /* Line: 641 */
if (bevp_printSteps.bevi_bool) /* Line: 644 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 645 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-463411174, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 648 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_30_tmpany_phold);
} /* Line: 650 */
if (bevp_printSteps.bevi_bool) /* Line: 653 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 654 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-463411174, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 657 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_34_tmpany_phold);
} /* Line: 659 */
if (bevp_printSteps.bevi_bool) /* Line: 662 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 663 */
bevt_36_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-463411174, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 666 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_38_tmpany_phold);
} /* Line: 668 */
if (bevp_printSteps.bevi_bool) /* Line: 671 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 672 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-463411174, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 675 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_42_tmpany_phold);
} /* Line: 677 */
if (bevp_printSteps.bevi_bool) /* Line: 680 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 681 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-463411174, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 684 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_46_tmpany_phold);
} /* Line: 686 */
if (bevp_printSteps.bevi_bool) /* Line: 689 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 690 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-463411174, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 693 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_50_tmpany_phold);
} /* Line: 695 */
if (bevp_printSteps.bevi_bool) /* Line: 697 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 698 */
bevt_52_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-463411174, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 701 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_54_tmpany_phold);
} /* Line: 703 */
if (bevp_printSteps.bevi_bool) /* Line: 706 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 708 */
bevt_57_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-463411174, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 711 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 711 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 711 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 711 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 711 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 711 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_51;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-463411174, bevt_59_tmpany_phold);
} /* Line: 713 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 715 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(179779414);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 715 */ {
bevl_clnode = bevl_ci.bemd_0(2034429922);
bevl_tunode = bevl_clnode.bemd_0(-2084192273);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(-1455687316, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(1690604512);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-1490500036);
bevl_ntt.bemd_1(-292988694, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(-957244466, bevl_ntt);
bevl_clnode.bemd_0(508078997);
bevl_ntunode.bemd_1(-683455065, bevl_clnode);
bevl_ntunode.bemd_1(981038037, bevl_clnode);
} /* Line: 726 */
 else  /* Line: 715 */ {
break;
} /* Line: 715 */
} /* Line: 715 */
} /* Line: 715 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(-1631214314);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(115633205);
bevl_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 736 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 736 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(-957244466, bevt_2_tmpany_phold);
bevl_node.bemd_1(-879450593, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(1690604512);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1911701664, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 740 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 741 */
bevt_6_tmpany_phold = bevl_node.bemd_0(1690604512);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(1198427025, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 743 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(-490352436, beva_parnode);
} /* Line: 745 */
} /* Line: 743 */
 else  /* Line: 736 */ {
break;
} /* Line: 736 */
} /* Line: 736 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-184186231, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(-1455687316, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(-957244466, bevl_nlnp);
bevl_nlnpn.bemd_1(981038037, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_113));
bevl_nlc.bemd_1(-934701332, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1462295620, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(677813232, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-1482362124, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1100957654, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(1690604512);
bevl_nlc.bemd_1(-2052669942, bevt_11_tmpany_phold);
beva_node.bemd_1(-683455065, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(-1455687316, bevt_12_tmpany_phold);
beva_node.bemd_1(-957244466, bevl_nlc);
bevl_nlnpn.bemd_0(-535267268);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_114));
bevt_13_tmpany_phold = beva_tName.bemd_1(1911701664, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 775 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 775 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_115));
bevt_15_tmpany_phold = beva_tName.bemd_1(1911701664, bevt_16_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 775 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 775 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 775 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 775 */ {
bevl_pn = beva_node.bemd_0(1325971478);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 777 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-1015889451);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(1911701664, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-1015889451);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(1911701664, bevt_23_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 777 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 777 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 777 */
 else  /* Line: 777 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 777 */ {
bevl_pn2 = bevl_pn.bemd_0(1325971478);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 779 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 779 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-1015889451);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(1198427025, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 779 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-1015889451);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(1198427025, bevt_30_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 779 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 779 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 779 */
 else  /* Line: 779 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 779 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-1015889451);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(1198427025, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 779 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 779 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 779 */
 else  /* Line: 779 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 779 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-1015889451);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(1198427025, bevt_36_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 779 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 779 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 779 */
 else  /* Line: 779 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 779 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 779 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 779 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 779 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(1690604512);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(-1657287524);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(2043797984, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(-2052669942, bevt_37_tmpany_phold);
bevl_pn.bemd_0(508078997);
} /* Line: 786 */
} /* Line: 779 */
} /* Line: 777 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGetDirect_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGetDirect_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGetDirect_0() {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGetDirect_0() {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGetDirect_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGetDirect_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGetDirect_0() {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGetDirect_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGetDirect_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGetDirect_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGetDirect_0() {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGetDirect_0() {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGetDirect_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGetDirect_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGetDirect_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGetDirect_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGetDirect_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGetDirect_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGetDirect_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGetDirect_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {51, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 68, 70, 71, 72, 73, 73, 76, 79, 80, 81, 87, 88, 89, 90, 91, 91, 98, 98, 98, 98, 0, 98, 98, 0, 0, 0, 0, 0, 99, 99, 101, 101, 105, 105, 105, 105, 109, 109, 110, 110, 110, 114, 115, 116, 116, 116, 116, 116, 117, 117, 117, 118, 117, 120, 124, 125, 126, 128, 129, 130, 132, 133, 134, 134, 135, 0, 0, 0, 138, 140, 144, 144, 144, 146, 151, 153, 154, 154, 154, 155, 155, 0, 155, 155, 156, 156, 156, 157, 158, 158, 163, 163, 163, 163, 164, 166, 166, 166, 167, 167, 168, 168, 168, 170, 172, 172, 172, 172, 172, 172, 173, 174, 174, 175, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 182, 182, 184, 184, 184, 185, 185, 185, 186, 186, 187, 187, 188, 190, 190, 191, 191, 192, 194, 194, 195, 195, 196, 198, 198, 199, 199, 200, 202, 202, 203, 203, 204, 206, 206, 207, 207, 208, 210, 210, 211, 211, 212, 214, 214, 215, 215, 216, 218, 218, 219, 219, 220, 222, 222, 223, 223, 224, 226, 226, 227, 227, 228, 230, 232, 232, 232, 233, 233, 233, 234, 234, 235, 235, 236, 237, 237, 238, 238, 238, 238, 238, 0, 0, 0, 239, 0, 239, 239, 240, 243, 243, 244, 244, 245, 245, 246, 246, 247, 247, 247, 248, 248, 249, 249, 250, 250, 250, 250, 251, 251, 251, 251, 252, 252, 252, 252, 252, 253, 254, 255, 256, 257, 260, 260, 261, 263, 270, 270, 270, 270, 270, 271, 271, 272, 272, 275, 275, 275, 276, 276, 277, 277, 280, 281, 281, 0, 281, 281, 282, 282, 284, 285, 286, 288, 289, 289, 289, 289, 290, 290, 292, 292, 293, 293, 294, 294, 295, 301, 302, 302, 302, 302, 302, 303, 303, 303, 303, 303, 304, 308, 309, 309, 309, 310, 311, 311, 311, 311, 312, 312, 312, 312, 313, 313, 313, 313, 313, 314, 314, 315, 0, 315, 315, 316, 319, 319, 319, 319, 319, 320, 320, 321, 0, 321, 321, 322, 327, 327, 327, 328, 329, 329, 329, 329, 329, 329, 336, 336, 340, 340, 341, 346, 346, 347, 348, 348, 349, 350, 350, 351, 352, 352, 353, 354, 354, 355, 357, 357, 357, 359, 361, 365, 367, 367, 367, 368, 368, 369, 369, 369, 370, 370, 371, 372, 372, 373, 373, 373, 374, 374, 374, 380, 380, 381, 382, 382, 383, 0, 383, 383, 384, 387, 388, 388, 389, 390, 392, 392, 392, 395, 397, 0, 397, 397, 398, 398, 398, 399, 400, 401, 404, 0, 404, 404, 405, 405, 405, 406, 407, 408, 409, 409, 414, 415, 415, 416, 418, 418, 419, 419, 420, 423, 426, 426, 426, 429, 429, 429, 431, 431, 432, 432, 433, 433, 433, 434, 434, 434, 435, 435, 435, 436, 436, 436, 437, 437, 437, 438, 438, 441, 442, 444, 444, 444, 445, 446, 448, 449, 450, 450, 450, 451, 452, 456, 456, 456, 457, 457, 458, 458, 458, 460, 460, 460, 463, 467, 467, 468, 469, 471, 0, 471, 471, 472, 472, 473, 473, 474, 474, 474, 475, 475, 476, 476, 478, 478, 478, 479, 479, 479, 483, 484, 486, 486, 0, 0, 0, 487, 487, 488, 488, 488, 488, 488, 488, 488, 488, 490, 490, 491, 491, 493, 493, 493, 494, 494, 494, 499, 499, 499, 501, 501, 502, 502, 502, 504, 504, 505, 505, 505, 507, 507, 508, 508, 508, 512, 512, 513, 514, 514, 514, 514, 514, 515, 517, 517, 521, 521, 521, 522, 523, 523, 524, 525, 527, 527, 527, 528, 529, 529, 530, 531, 533, 533, 537, 537, 537, 537, 538, 538, 538, 540, 540, 541, 541, 541, 541, 542, 544, 544, 544, 544, 544, 546, 546, 547, 547, 548, 552, 552, 552, 554, 556, 556, 557, 557, 557, 557, 558, 562, 563, 563, 564, 564, 565, 571, 571, 572, 573, 580, 580, 581, 583, 588, 589, 590, 591, 592, 593, 593, 0, 0, 0, 596, 596, 596, 596, 598, 600, 600, 600, 600, 601, 601, 601, 604, 608, 608, 610, 610, 612, 612, 613, 613, 617, 617, 619, 619, 621, 621, 622, 622, 625, 625, 628, 628, 629, 631, 631, 632, 632, 636, 636, 638, 638, 640, 640, 641, 641, 645, 645, 647, 647, 649, 649, 650, 650, 654, 654, 656, 656, 658, 658, 659, 659, 663, 663, 665, 665, 667, 667, 668, 668, 672, 672, 674, 674, 676, 676, 677, 677, 681, 681, 683, 683, 685, 685, 686, 686, 690, 690, 692, 692, 694, 694, 695, 695, 698, 698, 700, 700, 702, 702, 703, 703, 707, 707, 708, 708, 710, 710, 0, 0, 0, 712, 712, 713, 713, 715, 715, 715, 716, 718, 719, 720, 720, 721, 722, 722, 722, 723, 724, 725, 726, 732, 733, 734, 735, 735, 736, 736, 737, 738, 738, 739, 740, 740, 741, 743, 743, 744, 745, 752, 753, 755, 756, 756, 757, 758, 760, 761, 761, 762, 762, 763, 763, 764, 764, 765, 765, 766, 766, 768, 770, 770, 771, 773, 775, 775, 0, 775, 775, 0, 0, 776, 777, 777, 777, 777, 777, 0, 777, 777, 777, 0, 0, 0, 0, 0, 778, 779, 779, 0, 779, 779, 779, 779, 779, 779, 0, 0, 0, 779, 779, 779, 0, 0, 0, 779, 779, 779, 0, 0, 0, 0, 0, 785, 785, 785, 785, 786, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 295, 300, 301, 302, 304, 307, 308, 310, 313, 317, 320, 324, 327, 328, 330, 331, 337, 338, 339, 340, 347, 348, 349, 350, 351, 363, 364, 365, 366, 367, 368, 369, 370, 373, 378, 379, 380, 386, 394, 395, 396, 398, 399, 400, 404, 405, 406, 407, 408, 411, 415, 418, 422, 424, 430, 431, 432, 435, 578, 579, 580, 581, 586, 587, 588, 588, 591, 593, 594, 595, 600, 601, 602, 603, 611, 612, 613, 614, 616, 618, 619, 620, 621, 622, 624, 625, 626, 629, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 689, 690, 692, 693, 694, 699, 700, 702, 703, 704, 709, 710, 712, 713, 714, 719, 720, 722, 723, 724, 729, 730, 732, 733, 734, 739, 740, 742, 743, 744, 749, 750, 752, 753, 754, 759, 760, 762, 763, 764, 769, 770, 772, 773, 774, 779, 780, 782, 783, 784, 789, 790, 793, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 813, 814, 815, 820, 821, 824, 828, 831, 831, 834, 836, 837, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 882, 883, 886, 888, 889, 890, 891, 892, 893, 898, 899, 900, 902, 903, 904, 905, 910, 911, 912, 914, 915, 916, 916, 919, 921, 922, 923, 929, 930, 931, 932, 933, 934, 935, 940, 941, 942, 944, 949, 950, 951, 952, 953, 954, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 978, 979, 1019, 1020, 1021, 1024, 1026, 1027, 1028, 1029, 1030, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1046, 1047, 1047, 1050, 1052, 1053, 1060, 1061, 1062, 1063, 1064, 1065, 1070, 1071, 1071, 1074, 1076, 1077, 1090, 1091, 1094, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1112, 1113, 1129, 1134, 1135, 1137, 1142, 1143, 1144, 1145, 1147, 1150, 1151, 1153, 1156, 1157, 1159, 1162, 1163, 1165, 1168, 1169, 1170, 1175, 1177, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1336, 1337, 1338, 1339, 1344, 1345, 1345, 1348, 1350, 1351, 1358, 1359, 1364, 1365, 1366, 1368, 1369, 1370, 1373, 1374, 1374, 1377, 1379, 1380, 1381, 1386, 1387, 1388, 1389, 1396, 1396, 1399, 1401, 1402, 1403, 1408, 1409, 1410, 1411, 1412, 1413, 1421, 1422, 1425, 1427, 1428, 1429, 1431, 1432, 1433, 1440, 1442, 1443, 1444, 1445, 1446, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1461, 1462, 1463, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1475, 1476, 1477, 1478, 1481, 1483, 1484, 1490, 1491, 1492, 1493, 1496, 1498, 1499, 1506, 1507, 1508, 1509, 1514, 1515, 1516, 1517, 1519, 1520, 1521, 1523, 1526, 1531, 1532, 1533, 1535, 1535, 1538, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1549, 1551, 1552, 1554, 1555, 1556, 1558, 1559, 1560, 1568, 1569, 1572, 1574, 1576, 1579, 1583, 1586, 1587, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1596, 1597, 1599, 1600, 1602, 1603, 1604, 1606, 1607, 1608, 1617, 1618, 1619, 1620, 1625, 1626, 1627, 1628, 1630, 1635, 1636, 1637, 1638, 1640, 1645, 1646, 1647, 1648, 1651, 1652, 1653, 1654, 1655, 1656, 1657, 1658, 1659, 1661, 1662, 1675, 1676, 1679, 1681, 1682, 1683, 1684, 1685, 1691, 1692, 1695, 1697, 1698, 1699, 1700, 1701, 1707, 1708, 1736, 1737, 1738, 1743, 1744, 1745, 1746, 1748, 1749, 1750, 1751, 1752, 1757, 1758, 1761, 1762, 1763, 1764, 1765, 1766, 1771, 1772, 1773, 1774, 1777, 1778, 1779, 1781, 1783, 1784, 1785, 1786, 1787, 1788, 1789, 1797, 1798, 1799, 1800, 1805, 1806, 1808, 1809, 1810, 1811, 1815, 1820, 1821, 1823, 1902, 1903, 1904, 1905, 1906, 1907, 1908, 1911, 1915, 1918, 1922, 1923, 1924, 1925, 1927, 1928, 1929, 1930, 1931, 1932, 1933, 1934, 1935, 1937, 1938, 1940, 1941, 1943, 1944, 1945, 1946, 1949, 1950, 1952, 1953, 1955, 1956, 1957, 1958, 1961, 1962, 1964, 1965, 1966, 1968, 1969, 1970, 1971, 1974, 1975, 1977, 1978, 1980, 1981, 1982, 1983, 1986, 1987, 1989, 1990, 1992, 1993, 1994, 1995, 1998, 1999, 2001, 2002, 2004, 2005, 2006, 2007, 2010, 2011, 2013, 2014, 2016, 2017, 2018, 2019, 2022, 2023, 2025, 2026, 2028, 2029, 2030, 2031, 2034, 2035, 2037, 2038, 2040, 2041, 2042, 2043, 2046, 2047, 2049, 2050, 2052, 2053, 2054, 2055, 2058, 2059, 2061, 2062, 2064, 2065, 2066, 2067, 2070, 2071, 2072, 2073, 2075, 2076, 2078, 2082, 2085, 2089, 2090, 2091, 2092, 2094, 2095, 2098, 2100, 2101, 2102, 2103, 2104, 2105, 2106, 2107, 2108, 2109, 2110, 2111, 2112, 2134, 2135, 2136, 2137, 2138, 2139, 2142, 2144, 2145, 2146, 2147, 2148, 2149, 2151, 2153, 2154, 2156, 2157, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2233, 2234, 2235, 2236, 2237, 2238, 2240, 2243, 2244, 2246, 2249, 2253, 2254, 2259, 2260, 2261, 2262, 2264, 2267, 2268, 2269, 2271, 2274, 2278, 2281, 2285, 2288, 2289, 2294, 2295, 2298, 2299, 2300, 2302, 2303, 2304, 2306, 2309, 2313, 2316, 2317, 2318, 2320, 2323, 2327, 2330, 2331, 2332, 2334, 2337, 2341, 2344, 2347, 2351, 2352, 2353, 2354, 2355, 2362, 2365, 2368, 2372, 2376, 2379, 2382, 2386, 2390, 2393, 2396, 2400, 2404, 2407, 2410, 2414, 2418, 2421, 2424, 2428, 2432, 2435, 2438, 2442, 2446, 2449, 2452, 2456, 2460, 2463, 2466, 2470, 2474, 2477, 2480, 2484, 2488, 2491, 2494, 2498, 2502, 2505, 2508, 2512, 2516, 2519, 2522, 2526, 2530, 2533, 2536, 2540, 2544, 2547, 2550, 2554, 2558, 2561, 2564, 2568, 2572, 2575, 2578, 2582, 2586, 2589, 2592, 2596, 2600, 2603, 2606, 2610, 2614, 2617, 2620, 2624, 2628, 2631, 2634, 2638, 2642, 2645, 2648, 2652, 2656, 2659, 2662, 2666, 2670, 2673, 2676, 2680, 2684, 2687, 2690, 2694, 2698, 2701, 2704, 2708, 2712, 2715, 2718, 2722, 2726, 2729, 2732, 2736, 2740, 2743, 2746, 2750, 2754, 2757, 2760, 2764, 2768, 2771, 2774, 2778, 2782, 2785, 2788, 2792, 2796, 2799, 2802, 2806, 2810, 2813, 2816, 2820, 2824, 2827, 2830, 2834, 2838, 2841, 2844, 2848, 2852, 2855, 2858, 2862, 2866, 2869, 2872, 2876, 2880, 2883, 2886, 2890, 2894, 2897, 2900, 2904, 2908, 2911, 2914, 2918, 2922, 2925, 2928, 2932, 2936, 2939, 2942, 2946, 2950, 2953, 2956, 2960, 2964, 2967, 2970, 2974, 2978, 2981, 2984, 2988, 2992, 2995, 2998, 3002, 3006, 3009, 3012, 3016, 3020, 3023, 3026, 3030, 3034, 3037, 3040, 3044, 3048, 3051, 3054, 3058, 3062, 3065, 3068, 3072, 3076, 3079, 3082, 3086, 3090, 3093, 3096, 3100, 3104, 3107, 3110, 3114, 3118, 3121, 3124, 3128, 3132, 3135, 3138, 3142, 3146, 3149, 3152, 3156, 3160, 3163, 3166, 3170, 3174, 3177, 3180, 3184, 3188, 3191, 3194, 3198, 3202, 3205, 3208, 3212, 3216, 3219, 3222, 3226, 3230, 3233, 3236, 3240, 3244, 3247, 3250, 3254, 3258, 3261, 3264, 3268, 3272, 3275, 3278, 3282, 3286, 3289, 3292, 3296, 3300, 3303, 3306, 3310, 3314, 3317, 3320, 3324, 3328, 3331, 3334, 3338, 3342, 3345, 3348, 3352, 3356, 3359, 3362, 3366, 3370, 3373, 3377};
/* BEGIN LINEINFO 
assign 1 51 256
new 0 51 256
assign 1 53 257
new 0 53 257
assign 1 54 258
new 0 54 258
assign 1 55 259
new 0 55 259
assign 1 56 260
new 0 56 260
assign 1 58 261
new 0 58 261
assign 1 59 262
new 0 59 262
assign 1 60 263
new 0 60 263
assign 1 61 264
new 0 61 264
assign 1 62 265
new 0 62 265
assign 1 63 266
new 0 63 266
assign 1 64 267
new 0 64 267
assign 1 68 268
new 0 68 268
assign 1 70 269
new 1 70 269
assign 1 71 270
ntypesGet 0 71 270
assign 1 72 271
twtokGet 0 72 271
assign 1 73 272
new 0 73 272
assign 1 73 273
new 1 73 273
assign 1 76 274
new 0 76 274
assign 1 79 275
new 0 79 275
assign 1 80 276
new 0 80 276
assign 1 81 277
new 0 81 277
assign 1 87 278
new 0 87 278
assign 1 88 279
new 0 88 279
assign 1 89 280
new 0 89 280
assign 1 90 281
new 0 90 281
assign 1 91 282
new 0 91 282
assign 1 91 283
new 1 91 283
assign 1 98 295
def 1 98 300
assign 1 98 301
new 0 98 301
assign 1 98 302
equals 1 98 302
assign 1 0 304
assign 1 98 307
new 0 98 307
assign 1 98 308
ends 1 98 308
assign 1 0 310
assign 1 0 313
assign 1 0 317
assign 1 0 320
assign 1 0 324
assign 1 99 327
new 0 99 327
return 1 99 328
assign 1 101 330
new 0 101 330
return 1 101 331
assign 1 105 337
new 0 105 337
assign 1 105 338
new 0 105 338
assign 1 105 339
swap 2 105 339
return 1 105 340
assign 1 109 347
new 0 109 347
assign 1 109 348
argsGet 0 109 348
assign 1 110 349
new 0 110 349
assign 1 110 350
main 1 110 350
exit 1 110 351
assign 1 114 363
assign 1 115 364
new 1 115 364
assign 1 116 365
new 0 116 365
assign 1 116 366
new 0 116 366
assign 1 116 367
get 2 116 367
assign 1 116 368
firstGet 0 116 368
assign 1 116 369
new 1 116 369
assign 1 117 370
new 0 117 370
assign 1 117 373
lesser 1 117 378
assign 1 118 379
go 0 118 379
incrementValue 0 117 380
return 1 120 386
assign 1 124 394
new 0 124 394
config 0 125 395
assign 1 126 396
new 0 126 396
assign 1 128 398
new 0 128 398
assign 1 129 399
doWhat 0 129 399
assign 1 130 400
new 0 130 400
assign 1 132 404
toString 0 132 404
assign 1 133 405
new 0 133 405
assign 1 134 406
new 0 134 406
assign 1 134 407
add 1 134 407
assign 1 135 408
new 0 135 408
assign 1 0 411
assign 1 0 415
assign 1 0 418
print 0 138 422
return 1 140 424
assign 1 144 430
nameGet 0 144 430
assign 1 144 431
new 0 144 431
assign 1 144 432
equals 1 144 432
return 1 146 435
assign 1 151 578
new 0 151 578
assign 1 153 579
new 0 153 579
assign 1 154 580
get 1 154 580
assign 1 154 581
def 1 154 586
assign 1 155 587
get 1 155 587
assign 1 155 588
iteratorGet 0 0 588
assign 1 155 591
hasNextGet 0 155 591
assign 1 155 593
nextGet 0 155 593
assign 1 156 594
has 1 156 594
assign 1 156 595
not 0 156 600
put 1 157 601
assign 1 158 602
new 1 158 602
addFile 1 158 603
assign 1 163 611
new 0 163 611
assign 1 163 612
nameGet 0 163 612
assign 1 163 613
new 0 163 613
assign 1 163 614
equals 1 163 614
preProcessorSet 1 164 616
assign 1 166 618
new 0 166 618
assign 1 166 619
get 1 166 619
assign 1 166 620
firstGet 0 166 620
assign 1 167 621
new 0 167 621
assign 1 167 622
has 1 167 622
assign 1 168 624
new 0 168 624
assign 1 168 625
get 1 168 625
assign 1 168 626
firstGet 0 168 626
assign 1 170 629
assign 1 172 631
new 0 172 631
assign 1 172 632
new 0 172 632
assign 1 172 633
get 2 172 633
assign 1 172 634
firstGet 0 172 634
assign 1 172 635
new 1 172 635
assign 1 172 636
pathGet 0 172 636
addStep 1 173 637
assign 1 174 638
new 0 174 638
addStep 1 174 639
assign 1 175 640
new 0 175 640
assign 1 175 641
new 0 175 641
assign 1 175 642
get 2 175 642
assign 1 175 643
firstGet 0 175 643
assign 1 175 644
new 1 175 644
assign 1 175 645
pathGet 0 175 645
assign 1 176 646
new 0 176 646
assign 1 176 647
new 0 176 647
assign 1 176 648
nameGet 0 176 648
assign 1 176 649
get 2 176 649
assign 1 176 650
firstGet 0 176 650
assign 1 176 651
new 1 176 651
assign 1 177 652
new 0 177 652
assign 1 177 653
nameGet 0 177 653
assign 1 177 654
get 2 177 654
assign 1 177 655
firstGet 0 177 655
assign 1 177 656
new 1 177 656
assign 1 178 657
new 0 178 657
assign 1 178 658
new 0 178 658
assign 1 178 659
get 2 178 659
assign 1 178 660
firstGet 0 178 660
assign 1 178 661
new 1 178 661
assign 1 179 662
new 0 179 662
assign 1 179 663
new 0 179 663
assign 1 179 664
get 2 179 664
assign 1 179 665
firstGet 0 179 665
assign 1 179 666
new 1 179 666
assign 1 180 667
new 0 180 667
assign 1 180 668
new 0 180 668
assign 1 180 669
get 2 180 669
assign 1 180 670
firstGet 0 180 670
assign 1 180 671
new 1 180 671
assign 1 181 672
new 0 181 672
assign 1 181 673
get 1 181 673
assign 1 182 674
new 0 182 674
assign 1 182 675
get 1 182 675
assign 1 184 676
new 0 184 676
assign 1 184 677
get 1 184 677
assign 1 184 678
firstGet 0 184 678
assign 1 185 679
new 0 185 679
assign 1 185 680
get 1 185 680
assign 1 185 681
firstGet 0 185 681
assign 1 186 682
new 0 186 682
assign 1 186 683
get 1 186 683
assign 1 187 684
undef 1 187 689
assign 1 188 690
new 0 188 690
assign 1 190 692
new 0 190 692
assign 1 190 693
get 1 190 693
assign 1 191 694
undef 1 191 699
assign 1 192 700
new 0 192 700
assign 1 194 702
new 0 194 702
assign 1 194 703
get 1 194 703
assign 1 195 704
undef 1 195 709
assign 1 196 710
new 0 196 710
assign 1 198 712
new 0 198 712
assign 1 198 713
get 1 198 713
assign 1 199 714
undef 1 199 719
assign 1 200 720
new 0 200 720
assign 1 202 722
new 0 202 722
assign 1 202 723
get 1 202 723
assign 1 203 724
undef 1 203 729
assign 1 204 730
new 0 204 730
assign 1 206 732
new 0 206 732
assign 1 206 733
get 1 206 733
assign 1 207 734
undef 1 207 739
assign 1 208 740
new 0 208 740
assign 1 210 742
new 0 210 742
assign 1 210 743
get 1 210 743
assign 1 211 744
undef 1 211 749
assign 1 212 750
new 0 212 750
assign 1 214 752
new 0 214 752
assign 1 214 753
get 1 214 753
assign 1 215 754
undef 1 215 759
assign 1 216 760
new 0 216 760
assign 1 218 762
new 0 218 762
assign 1 218 763
get 1 218 763
assign 1 219 764
undef 1 219 769
assign 1 220 770
new 0 220 770
assign 1 222 772
new 0 222 772
assign 1 222 773
get 1 222 773
assign 1 223 774
def 1 223 779
assign 1 224 780
firstGet 0 224 780
assign 1 226 782
new 0 226 782
assign 1 226 783
get 1 226 783
assign 1 227 784
def 1 227 789
assign 1 228 790
firstGet 0 228 790
assign 1 230 793
new 0 230 793
assign 1 232 795
new 0 232 795
assign 1 232 796
new 0 232 796
assign 1 232 797
isTrue 2 232 797
assign 1 233 798
new 0 233 798
assign 1 233 799
new 0 233 799
assign 1 233 800
isTrue 2 233 800
assign 1 234 801
new 0 234 801
assign 1 234 802
isTrue 1 234 802
assign 1 235 803
new 0 235 803
assign 1 235 804
isTrue 1 235 804
assign 1 236 805
new 0 236 805
assign 1 237 806
new 0 237 806
assign 1 237 807
get 1 237 807
assign 1 238 808
def 1 238 813
assign 1 238 814
isEmptyGet 0 238 814
assign 1 238 815
not 0 238 820
assign 1 0 821
assign 1 0 824
assign 1 0 828
assign 1 239 831
linkedListIteratorGet 0 0 831
assign 1 239 834
hasNextGet 0 239 834
assign 1 239 836
nextGet 0 239 836
put 1 240 837
assign 1 243 844
new 0 243 844
assign 1 243 845
isTrue 1 243 845
assign 1 244 846
new 0 244 846
assign 1 244 847
isTrue 1 244 847
assign 1 245 848
new 0 245 848
assign 1 245 849
isTrue 1 245 849
assign 1 246 850
new 0 246 850
assign 1 246 851
isTrue 1 246 851
assign 1 247 852
new 0 247 852
assign 1 247 853
new 0 247 853
assign 1 247 854
isTrue 2 247 854
assign 1 248 855
new 0 248 855
assign 1 248 856
get 1 248 856
assign 1 249 857
new 0 249 857
assign 1 249 858
get 1 249 858
assign 1 250 859
new 0 250 859
assign 1 250 860
new 0 250 860
assign 1 250 861
get 2 250 861
assign 1 250 862
firstGet 0 250 862
assign 1 251 863
new 0 251 863
assign 1 251 864
new 0 251 864
assign 1 251 865
get 2 251 865
assign 1 251 866
firstGet 0 251 866
assign 1 252 867
new 0 252 867
assign 1 252 868
add 1 252 868
assign 1 252 869
new 0 252 869
assign 1 252 870
get 2 252 870
assign 1 252 871
firstGet 0 252 871
assign 1 253 872
new 0 253 872
assign 1 254 873
new 0 254 873
assign 1 255 874
new 0 255 874
assign 1 256 875
new 0 256 875
assign 1 257 876
new 0 257 876
assign 1 260 877
def 1 260 882
assign 1 261 883
firstGet 0 261 883
assign 1 263 886
new 0 263 886
assign 1 270 888
new 0 270 888
assign 1 270 889
add 1 270 889
assign 1 270 890
nameGet 0 270 890
assign 1 270 891
add 1 270 891
assign 1 270 892
get 1 270 892
assign 1 271 893
def 1 271 898
assign 1 272 899
orderedGet 0 272 899
addAll 1 272 900
assign 1 275 902
new 0 275 902
assign 1 275 903
add 1 275 903
assign 1 275 904
get 1 275 904
assign 1 276 905
def 1 276 910
assign 1 277 911
orderedGet 0 277 911
addAll 1 277 912
assign 1 280 914
new 0 280 914
assign 1 281 915
orderedGet 0 281 915
assign 1 281 916
iteratorGet 0 0 916
assign 1 281 919
hasNextGet 0 281 919
assign 1 281 921
nextGet 0 281 921
assign 1 282 922
new 1 282 922
addValue 1 282 923
assign 1 284 929
newlineGet 0 284 929
assign 1 285 930
assign 1 286 931
new 1 286 931
assign 1 288 932
copy 0 288 932
assign 1 289 933
fileGet 0 289 933
assign 1 289 934
existsGet 0 289 934
assign 1 289 935
not 0 289 940
assign 1 290 941
fileGet 0 290 941
makeDirs 0 290 942
assign 1 292 944
def 1 292 949
assign 1 293 950
new 1 293 950
assign 1 293 951
readerGet 0 293 951
assign 1 294 952
open 0 294 952
assign 1 294 953
readString 0 294 953
close 0 295 954
assign 1 301 968
classNameGet 0 301 968
assign 1 302 969
add 1 302 969
assign 1 302 970
new 0 302 970
assign 1 302 971
add 1 302 971
assign 1 302 972
toString 0 302 972
assign 1 302 973
add 1 302 973
assign 1 303 974
add 1 303 974
assign 1 303 975
new 0 303 975
assign 1 303 976
add 1 303 976
assign 1 303 977
toString 0 303 977
assign 1 303 978
add 1 303 978
return 1 304 979
assign 1 308 1019
new 0 308 1019
assign 1 309 1020
classesGet 0 309 1020
assign 1 309 1021
valueIteratorGet 0 309 1021
assign 1 309 1024
hasNextGet 0 309 1024
assign 1 310 1026
nextGet 0 310 1026
assign 1 311 1027
shouldEmitGet 0 311 1027
assign 1 311 1028
heldGet 0 311 1028
assign 1 311 1029
fromFileGet 0 311 1029
assign 1 311 1030
has 1 311 1030
assign 1 312 1032
heldGet 0 312 1032
assign 1 312 1033
namepathGet 0 312 1033
assign 1 312 1034
toString 0 312 1034
put 1 312 1035
assign 1 313 1036
usedByGet 0 313 1036
assign 1 313 1037
heldGet 0 313 1037
assign 1 313 1038
namepathGet 0 313 1038
assign 1 313 1039
toString 0 313 1039
assign 1 313 1040
get 1 313 1040
assign 1 314 1041
def 1 314 1046
assign 1 315 1047
setIteratorGet 0 0 1047
assign 1 315 1050
hasNextGet 0 315 1050
assign 1 315 1052
nextGet 0 315 1052
put 1 316 1053
assign 1 319 1060
subClassesGet 0 319 1060
assign 1 319 1061
heldGet 0 319 1061
assign 1 319 1062
namepathGet 0 319 1062
assign 1 319 1063
toString 0 319 1063
assign 1 319 1064
get 1 319 1064
assign 1 320 1065
def 1 320 1070
assign 1 321 1071
setIteratorGet 0 0 1071
assign 1 321 1074
hasNextGet 0 321 1074
assign 1 321 1076
nextGet 0 321 1076
put 1 322 1077
assign 1 327 1090
classesGet 0 327 1090
assign 1 327 1091
valueIteratorGet 0 327 1091
assign 1 327 1094
hasNextGet 0 327 1094
assign 1 328 1096
nextGet 0 328 1096
assign 1 329 1097
heldGet 0 329 1097
assign 1 329 1098
heldGet 0 329 1098
assign 1 329 1099
namepathGet 0 329 1099
assign 1 329 1100
toString 0 329 1100
assign 1 329 1101
has 1 329 1101
shouldWriteSet 1 329 1102
assign 1 336 1112
new 0 336 1112
return 1 336 1113
assign 1 340 1129
def 1 340 1134
return 1 341 1135
assign 1 346 1137
def 1 346 1142
assign 1 347 1143
firstGet 0 347 1143
assign 1 348 1144
new 0 348 1144
assign 1 348 1145
equals 1 348 1145
assign 1 349 1147
new 1 349 1147
assign 1 350 1150
new 0 350 1150
assign 1 350 1151
equals 1 350 1151
assign 1 351 1153
new 1 351 1153
assign 1 352 1156
new 0 352 1156
assign 1 352 1157
equals 1 352 1157
assign 1 353 1159
new 1 353 1159
assign 1 354 1162
new 0 354 1162
assign 1 354 1163
equals 1 354 1163
assign 1 355 1165
new 1 355 1165
assign 1 357 1168
new 0 357 1168
assign 1 357 1169
new 1 357 1169
throw 1 357 1170
return 1 359 1175
return 1 361 1177
assign 1 365 1196
apNew 1 365 1196
assign 1 367 1197
new 0 367 1197
assign 1 367 1198
add 1 367 1198
print 0 367 1199
assign 1 368 1200
new 0 368 1200
assign 1 368 1201
now 0 368 1201
assign 1 369 1202
fileGet 0 369 1202
assign 1 369 1203
readerGet 0 369 1203
assign 1 369 1204
open 0 369 1204
assign 1 370 1205
new 0 370 1205
assign 1 370 1206
deserialize 1 370 1206
close 0 371 1207
assign 1 372 1208
synClassesGet 0 372 1208
addValue 1 372 1209
assign 1 373 1210
new 0 373 1210
assign 1 373 1211
now 0 373 1211
assign 1 373 1212
subtract 1 373 1212
assign 1 374 1213
new 0 374 1213
assign 1 374 1214
add 1 374 1214
print 0 374 1215
assign 1 380 1336
new 0 380 1336
assign 1 380 1337
now 0 380 1337
assign 1 381 1338
new 0 381 1338
assign 1 382 1339
def 1 382 1344
assign 1 383 1345
linkedListIteratorGet 0 0 1345
assign 1 383 1348
hasNextGet 0 383 1348
assign 1 383 1350
nextGet 0 383 1350
loadSyns 1 384 1351
assign 1 387 1358
emitterGet 0 387 1358
assign 1 388 1359
def 1 388 1364
assign 1 389 1365
new 4 389 1365
put 1 390 1366
assign 1 392 1368
new 0 392 1368
assign 1 392 1369
add 1 392 1369
print 0 392 1370
assign 1 395 1373
new 0 395 1373
assign 1 397 1374
iteratorGet 0 0 1374
assign 1 397 1377
hasNextGet 0 397 1377
assign 1 397 1379
nextGet 0 397 1379
assign 1 398 1380
has 1 398 1380
assign 1 398 1381
not 0 398 1386
put 1 399 1387
assign 1 400 1388
new 2 400 1388
addValue 1 401 1389
assign 1 404 1396
iteratorGet 0 0 1396
assign 1 404 1399
hasNextGet 0 404 1399
assign 1 404 1401
nextGet 0 404 1401
assign 1 405 1402
has 1 405 1402
assign 1 405 1403
not 0 405 1408
put 1 406 1409
assign 1 407 1410
new 2 407 1410
addValue 1 408 1411
assign 1 409 1412
libNameGet 0 409 1412
put 1 409 1413
assign 1 414 1421
new 0 414 1421
assign 1 415 1422
iteratorGet 0 415 1422
assign 1 415 1425
hasNextGet 0 415 1425
assign 1 416 1427
nextGet 0 416 1427
assign 1 418 1428
toString 0 418 1428
assign 1 418 1429
has 1 418 1429
assign 1 419 1431
toString 0 419 1431
put 1 419 1432
doParse 1 420 1433
buildSyns 1 423 1440
assign 1 426 1442
new 0 426 1442
assign 1 426 1443
now 0 426 1443
assign 1 426 1444
subtract 1 426 1444
assign 1 429 1445
emitCommonGet 0 429 1445
assign 1 429 1446
def 1 429 1451
assign 1 431 1452
new 0 431 1452
assign 1 431 1453
now 0 431 1453
assign 1 432 1454
emitCommonGet 0 432 1454
doEmit 0 432 1455
assign 1 433 1456
new 0 433 1456
assign 1 433 1457
now 0 433 1457
assign 1 433 1458
subtract 1 433 1458
assign 1 434 1459
new 0 434 1459
assign 1 434 1460
now 0 434 1460
assign 1 434 1461
subtract 1 434 1461
assign 1 435 1462
new 0 435 1462
assign 1 435 1463
add 1 435 1463
print 0 435 1464
assign 1 436 1465
new 0 436 1465
assign 1 436 1466
add 1 436 1466
print 0 436 1467
assign 1 437 1468
new 0 437 1468
assign 1 437 1469
add 1 437 1469
print 0 437 1470
assign 1 438 1471
new 0 438 1471
return 1 438 1472
setClassesToWrite 0 441 1475
libnameInfoGet 0 442 1476
assign 1 444 1477
classesGet 0 444 1477
assign 1 444 1478
valueIteratorGet 0 444 1478
assign 1 444 1481
hasNextGet 0 444 1481
assign 1 445 1483
nextGet 0 445 1483
doEmit 1 446 1484
emitMain 0 448 1490
emitCUInit 0 449 1491
assign 1 450 1492
classesGet 0 450 1492
assign 1 450 1493
valueIteratorGet 0 450 1493
assign 1 450 1496
hasNextGet 0 450 1496
assign 1 451 1498
nextGet 0 451 1498
emitSyn 1 452 1499
assign 1 456 1506
new 0 456 1506
assign 1 456 1507
now 0 456 1507
assign 1 456 1508
subtract 1 456 1508
assign 1 457 1509
def 1 457 1514
assign 1 458 1515
new 0 458 1515
assign 1 458 1516
add 1 458 1516
print 0 458 1517
assign 1 460 1519
new 0 460 1519
assign 1 460 1520
add 1 460 1520
print 0 460 1521
prepMake 1 463 1523
assign 1 467 1526
not 0 467 1531
make 1 468 1532
deployLibrary 1 469 1533
assign 1 471 1535
linkedListIteratorGet 0 0 1535
assign 1 471 1538
hasNextGet 0 471 1538
assign 1 471 1540
nextGet 0 471 1540
assign 1 472 1541
libnameInfoGet 0 472 1541
assign 1 472 1542
unitShlibGet 0 472 1542
assign 1 473 1543
emitPathGet 0 473 1543
assign 1 473 1544
copy 0 473 1544
assign 1 474 1545
stepsGet 0 474 1545
assign 1 474 1546
lastGet 0 474 1546
addStep 1 474 1547
assign 1 475 1548
fileGet 0 475 1548
assign 1 475 1549
existsGet 0 475 1549
assign 1 476 1551
fileGet 0 476 1551
delete 0 476 1552
assign 1 478 1554
fileGet 0 478 1554
assign 1 478 1555
existsGet 0 478 1555
assign 1 478 1556
not 0 478 1556
assign 1 479 1558
fileGet 0 479 1558
assign 1 479 1559
fileGet 0 479 1559
deployFile 2 479 1560
assign 1 483 1568
iteratorGet 0 483 1568
assign 1 484 1569
iteratorGet 0 484 1569
assign 1 486 1572
hasNextGet 0 486 1572
assign 1 486 1574
hasNextGet 0 486 1574
assign 1 0 1576
assign 1 0 1579
assign 1 0 1583
assign 1 487 1586
nextGet 0 487 1586
assign 1 487 1587
apNew 1 487 1587
assign 1 488 1588
emitPathGet 0 488 1588
assign 1 488 1589
copy 0 488 1589
assign 1 488 1590
toString 0 488 1590
assign 1 488 1591
new 0 488 1591
assign 1 488 1592
add 1 488 1592
assign 1 488 1593
nextGet 0 488 1593
assign 1 488 1594
add 1 488 1594
assign 1 488 1595
apNew 1 488 1595
assign 1 490 1596
fileGet 0 490 1596
assign 1 490 1597
existsGet 0 490 1597
assign 1 491 1599
fileGet 0 491 1599
delete 0 491 1600
assign 1 493 1602
fileGet 0 493 1602
assign 1 493 1603
existsGet 0 493 1603
assign 1 493 1604
not 0 493 1604
assign 1 494 1606
fileGet 0 494 1606
assign 1 494 1607
fileGet 0 494 1607
deployFile 2 494 1608
assign 1 499 1617
new 0 499 1617
assign 1 499 1618
now 0 499 1618
assign 1 499 1619
subtract 1 499 1619
assign 1 501 1620
def 1 501 1625
assign 1 502 1626
new 0 502 1626
assign 1 502 1627
add 1 502 1627
print 0 502 1628
assign 1 504 1630
def 1 504 1635
assign 1 505 1636
new 0 505 1636
assign 1 505 1637
add 1 505 1637
print 0 505 1638
assign 1 507 1640
def 1 507 1645
assign 1 508 1646
new 0 508 1646
assign 1 508 1647
add 1 508 1647
print 0 508 1648
assign 1 512 1651
new 0 512 1651
print 0 512 1652
assign 1 513 1653
run 2 513 1653
assign 1 514 1654
new 0 514 1654
assign 1 514 1655
add 1 514 1655
assign 1 514 1656
new 0 514 1656
assign 1 514 1657
add 1 514 1657
print 0 514 1658
return 1 515 1659
assign 1 517 1661
new 0 517 1661
return 1 517 1662
assign 1 521 1675
justParsedGet 0 521 1675
assign 1 521 1676
valueIteratorGet 0 521 1676
assign 1 521 1679
hasNextGet 0 521 1679
assign 1 522 1681
nextGet 0 522 1681
assign 1 523 1682
heldGet 0 523 1682
libNameSet 1 523 1683
assign 1 524 1684
getSyn 2 524 1684
libNameSet 1 525 1685
assign 1 527 1691
justParsedGet 0 527 1691
assign 1 527 1692
valueIteratorGet 0 527 1692
assign 1 527 1695
hasNextGet 0 527 1695
assign 1 528 1697
nextGet 0 528 1697
assign 1 529 1698
heldGet 0 529 1698
assign 1 529 1699
synGet 0 529 1699
checkInheritance 2 530 1700
integrate 1 531 1701
assign 1 533 1707
new 0 533 1707
justParsedSet 1 533 1708
assign 1 537 1736
heldGet 0 537 1736
assign 1 537 1737
synGet 0 537 1737
assign 1 537 1738
def 1 537 1743
assign 1 538 1744
heldGet 0 538 1744
assign 1 538 1745
synGet 0 538 1745
return 1 538 1746
assign 1 540 1748
heldGet 0 540 1748
libNameSet 1 540 1749
assign 1 541 1750
heldGet 0 541 1750
assign 1 541 1751
extendsGet 0 541 1751
assign 1 541 1752
undef 1 541 1757
assign 1 542 1758
new 1 542 1758
assign 1 544 1761
classesGet 0 544 1761
assign 1 544 1762
heldGet 0 544 1762
assign 1 544 1763
extendsGet 0 544 1763
assign 1 544 1764
toString 0 544 1764
assign 1 544 1765
get 1 544 1765
assign 1 546 1766
def 1 546 1771
assign 1 547 1772
heldGet 0 547 1772
libNameSet 1 547 1773
assign 1 548 1774
getSyn 2 548 1774
assign 1 552 1777
heldGet 0 552 1777
assign 1 552 1778
extendsGet 0 552 1778
assign 1 552 1779
getSynNp 1 552 1779
assign 1 554 1781
new 2 554 1781
assign 1 556 1783
heldGet 0 556 1783
synSet 1 556 1784
assign 1 557 1785
heldGet 0 557 1785
assign 1 557 1786
namepathGet 0 557 1786
assign 1 557 1787
toString 0 557 1787
addSynClass 2 557 1788
return 1 558 1789
assign 1 562 1797
toString 0 562 1797
assign 1 563 1798
synClassesGet 0 563 1798
assign 1 563 1799
get 1 563 1799
assign 1 564 1800
def 1 564 1805
return 1 565 1806
assign 1 571 1808
emitterGet 0 571 1808
assign 1 571 1809
loadSyn 1 571 1809
addSynClass 2 572 1810
return 1 573 1811
assign 1 580 1815
undef 1 580 1820
assign 1 581 1821
new 1 581 1821
return 1 583 1823
assign 1 588 1902
new 1 588 1902
assign 1 589 1903
new 0 589 1903
assign 1 590 1904
emitterGet 0 590 1904
assign 1 591 1905
assign 1 592 1906
new 0 592 1906
assign 1 593 1907
shouldEmitGet 0 593 1907
put 1 593 1908
assign 1 0 1911
assign 1 0 1915
assign 1 0 1918
assign 1 596 1922
new 0 596 1922
assign 1 596 1923
toString 0 596 1923
assign 1 596 1924
add 1 596 1924
print 0 596 1925
assign 1 598 1927
assign 1 600 1928
fileGet 0 600 1928
assign 1 600 1929
readerGet 0 600 1929
assign 1 600 1930
open 0 600 1930
assign 1 600 1931
readBuffer 1 600 1931
assign 1 601 1932
fileGet 0 601 1932
assign 1 601 1933
readerGet 0 601 1933
close 0 601 1934
assign 1 604 1935
tokenize 1 604 1935
assign 1 608 1937
new 0 608 1937
echo 0 608 1938
assign 1 610 1940
outermostGet 0 610 1940
nodify 2 610 1941
assign 1 612 1943
new 0 612 1943
print 0 612 1944
assign 1 613 1945
new 2 613 1945
traverse 1 613 1946
assign 1 617 1949
new 0 617 1949
echo 0 617 1950
assign 1 619 1952
new 0 619 1952
traverse 1 619 1953
assign 1 621 1955
new 0 621 1955
print 0 621 1956
assign 1 622 1957
new 2 622 1957
traverse 1 622 1958
assign 1 625 1961
new 0 625 1961
echo 0 625 1962
assign 1 628 1964
new 0 628 1964
traverse 1 628 1965
contain 0 629 1966
assign 1 631 1968
new 0 631 1968
print 0 631 1969
assign 1 632 1970
new 2 632 1970
traverse 1 632 1971
assign 1 636 1974
new 0 636 1974
echo 0 636 1975
assign 1 638 1977
new 0 638 1977
traverse 1 638 1978
assign 1 640 1980
new 0 640 1980
print 0 640 1981
assign 1 641 1982
new 2 641 1982
traverse 1 641 1983
assign 1 645 1986
new 0 645 1986
echo 0 645 1987
assign 1 647 1989
new 0 647 1989
traverse 1 647 1990
assign 1 649 1992
new 0 649 1992
print 0 649 1993
assign 1 650 1994
new 2 650 1994
traverse 1 650 1995
assign 1 654 1998
new 0 654 1998
echo 0 654 1999
assign 1 656 2001
new 0 656 2001
traverse 1 656 2002
assign 1 658 2004
new 0 658 2004
print 0 658 2005
assign 1 659 2006
new 2 659 2006
traverse 1 659 2007
assign 1 663 2010
new 0 663 2010
echo 0 663 2011
assign 1 665 2013
new 0 665 2013
traverse 1 665 2014
assign 1 667 2016
new 0 667 2016
print 0 667 2017
assign 1 668 2018
new 2 668 2018
traverse 1 668 2019
assign 1 672 2022
new 0 672 2022
echo 0 672 2023
assign 1 674 2025
new 0 674 2025
traverse 1 674 2026
assign 1 676 2028
new 0 676 2028
print 0 676 2029
assign 1 677 2030
new 2 677 2030
traverse 1 677 2031
assign 1 681 2034
new 0 681 2034
echo 0 681 2035
assign 1 683 2037
new 0 683 2037
traverse 1 683 2038
assign 1 685 2040
new 0 685 2040
print 0 685 2041
assign 1 686 2042
new 2 686 2042
traverse 1 686 2043
assign 1 690 2046
new 0 690 2046
echo 0 690 2047
assign 1 692 2049
new 0 692 2049
traverse 1 692 2050
assign 1 694 2052
new 0 694 2052
print 0 694 2053
assign 1 695 2054
new 2 695 2054
traverse 1 695 2055
assign 1 698 2058
new 0 698 2058
echo 0 698 2059
assign 1 700 2061
new 0 700 2061
traverse 1 700 2062
assign 1 702 2064
new 0 702 2064
print 0 702 2065
assign 1 703 2066
new 2 703 2066
traverse 1 703 2067
assign 1 707 2070
new 0 707 2070
echo 0 707 2071
assign 1 708 2072
new 0 708 2072
print 0 708 2073
assign 1 710 2075
new 0 710 2075
traverse 1 710 2076
assign 1 0 2078
assign 1 0 2082
assign 1 0 2085
assign 1 712 2089
new 0 712 2089
print 0 712 2090
assign 1 713 2091
new 2 713 2091
traverse 1 713 2092
assign 1 715 2094
classesGet 0 715 2094
assign 1 715 2095
valueIteratorGet 0 715 2095
assign 1 715 2098
hasNextGet 0 715 2098
assign 1 716 2100
nextGet 0 716 2100
assign 1 718 2101
transUnitGet 0 718 2101
assign 1 719 2102
new 1 719 2102
assign 1 720 2103
TRANSUNITGet 0 720 2103
typenameSet 1 720 2104
assign 1 721 2105
new 0 721 2105
assign 1 722 2106
heldGet 0 722 2106
assign 1 722 2107
emitsGet 0 722 2107
emitsSet 1 722 2108
heldSet 1 723 2109
delete 0 724 2110
addValue 1 725 2111
copyLoc 1 726 2112
reInitContained 0 732 2134
assign 1 733 2135
containedGet 0 733 2135
assign 1 734 2136
new 0 734 2136
assign 1 735 2137
new 0 735 2137
assign 1 735 2138
crGet 0 735 2138
assign 1 736 2139
linkedListIteratorGet 0 736 2139
assign 1 736 2142
hasNextGet 0 736 2142
assign 1 737 2144
new 1 737 2144
assign 1 738 2145
nextGet 0 738 2145
heldSet 1 738 2146
nlcSet 1 739 2147
assign 1 740 2148
heldGet 0 740 2148
assign 1 740 2149
equals 1 740 2149
assign 1 741 2151
increment 0 741 2151
assign 1 743 2153
heldGet 0 743 2153
assign 1 743 2154
notEquals 1 743 2154
addValue 1 744 2156
containerSet 1 745 2157
assign 1 752 2212
new 0 752 2212
fromString 1 753 2213
assign 1 755 2214
new 1 755 2214
assign 1 756 2215
NAMEPATHGet 0 756 2215
typenameSet 1 756 2216
heldSet 1 757 2217
copyLoc 1 758 2218
assign 1 760 2219
new 0 760 2219
assign 1 761 2220
new 0 761 2220
nameSet 1 761 2221
assign 1 762 2222
new 0 762 2222
wasBoundSet 1 762 2223
assign 1 763 2224
new 0 763 2224
boundSet 1 763 2225
assign 1 764 2226
new 0 764 2226
isConstructSet 1 764 2227
assign 1 765 2228
new 0 765 2228
isLiteralSet 1 765 2229
assign 1 766 2230
heldGet 0 766 2230
literalValueSet 1 766 2231
addValue 1 768 2232
assign 1 770 2233
CALLGet 0 770 2233
typenameSet 1 770 2234
heldSet 1 771 2235
resolveNp 0 773 2236
assign 1 775 2237
new 0 775 2237
assign 1 775 2238
equals 1 775 2238
assign 1 0 2240
assign 1 775 2243
new 0 775 2243
assign 1 775 2244
equals 1 775 2244
assign 1 0 2246
assign 1 0 2249
assign 1 776 2253
priorPeerGet 0 776 2253
assign 1 777 2254
def 1 777 2259
assign 1 777 2260
typenameGet 0 777 2260
assign 1 777 2261
SUBTRACTGet 0 777 2261
assign 1 777 2262
equals 1 777 2262
assign 1 0 2264
assign 1 777 2267
typenameGet 0 777 2267
assign 1 777 2268
ADDGet 0 777 2268
assign 1 777 2269
equals 1 777 2269
assign 1 0 2271
assign 1 0 2274
assign 1 0 2278
assign 1 0 2281
assign 1 0 2285
assign 1 778 2288
priorPeerGet 0 778 2288
assign 1 779 2289
undef 1 779 2294
assign 1 0 2295
assign 1 779 2298
typenameGet 0 779 2298
assign 1 779 2299
CALLGet 0 779 2299
assign 1 779 2300
notEquals 1 779 2300
assign 1 779 2302
typenameGet 0 779 2302
assign 1 779 2303
IDGet 0 779 2303
assign 1 779 2304
notEquals 1 779 2304
assign 1 0 2306
assign 1 0 2309
assign 1 0 2313
assign 1 779 2316
typenameGet 0 779 2316
assign 1 779 2317
VARGet 0 779 2317
assign 1 779 2318
notEquals 1 779 2318
assign 1 0 2320
assign 1 0 2323
assign 1 0 2327
assign 1 779 2330
typenameGet 0 779 2330
assign 1 779 2331
ACCESSORGet 0 779 2331
assign 1 779 2332
notEquals 1 779 2332
assign 1 0 2334
assign 1 0 2337
assign 1 0 2341
assign 1 0 2344
assign 1 0 2347
assign 1 785 2351
heldGet 0 785 2351
assign 1 785 2352
literalValueGet 0 785 2352
assign 1 785 2353
add 1 785 2353
literalValueSet 1 785 2354
delete 0 786 2355
return 1 0 2362
return 1 0 2365
assign 1 0 2368
assign 1 0 2372
return 1 0 2376
return 1 0 2379
assign 1 0 2382
assign 1 0 2386
return 1 0 2390
return 1 0 2393
assign 1 0 2396
assign 1 0 2400
return 1 0 2404
return 1 0 2407
assign 1 0 2410
assign 1 0 2414
return 1 0 2418
return 1 0 2421
assign 1 0 2424
assign 1 0 2428
return 1 0 2432
return 1 0 2435
assign 1 0 2438
assign 1 0 2442
return 1 0 2446
return 1 0 2449
assign 1 0 2452
assign 1 0 2456
return 1 0 2460
return 1 0 2463
assign 1 0 2466
assign 1 0 2470
return 1 0 2474
return 1 0 2477
assign 1 0 2480
assign 1 0 2484
return 1 0 2488
return 1 0 2491
assign 1 0 2494
assign 1 0 2498
return 1 0 2502
return 1 0 2505
assign 1 0 2508
assign 1 0 2512
return 1 0 2516
return 1 0 2519
assign 1 0 2522
assign 1 0 2526
return 1 0 2530
return 1 0 2533
assign 1 0 2536
assign 1 0 2540
return 1 0 2544
return 1 0 2547
assign 1 0 2550
assign 1 0 2554
return 1 0 2558
return 1 0 2561
assign 1 0 2564
assign 1 0 2568
return 1 0 2572
return 1 0 2575
assign 1 0 2578
assign 1 0 2582
return 1 0 2586
return 1 0 2589
assign 1 0 2592
assign 1 0 2596
return 1 0 2600
return 1 0 2603
assign 1 0 2606
assign 1 0 2610
return 1 0 2614
return 1 0 2617
assign 1 0 2620
assign 1 0 2624
return 1 0 2628
return 1 0 2631
assign 1 0 2634
assign 1 0 2638
return 1 0 2642
return 1 0 2645
assign 1 0 2648
assign 1 0 2652
return 1 0 2656
return 1 0 2659
assign 1 0 2662
assign 1 0 2666
return 1 0 2670
return 1 0 2673
assign 1 0 2676
assign 1 0 2680
return 1 0 2684
return 1 0 2687
assign 1 0 2690
assign 1 0 2694
return 1 0 2698
return 1 0 2701
assign 1 0 2704
assign 1 0 2708
return 1 0 2712
return 1 0 2715
assign 1 0 2718
assign 1 0 2722
return 1 0 2726
return 1 0 2729
assign 1 0 2732
assign 1 0 2736
return 1 0 2740
return 1 0 2743
assign 1 0 2746
assign 1 0 2750
return 1 0 2754
return 1 0 2757
assign 1 0 2760
assign 1 0 2764
return 1 0 2768
return 1 0 2771
assign 1 0 2774
assign 1 0 2778
return 1 0 2782
return 1 0 2785
assign 1 0 2788
assign 1 0 2792
return 1 0 2796
return 1 0 2799
assign 1 0 2802
assign 1 0 2806
return 1 0 2810
return 1 0 2813
assign 1 0 2816
assign 1 0 2820
return 1 0 2824
return 1 0 2827
assign 1 0 2830
assign 1 0 2834
return 1 0 2838
return 1 0 2841
assign 1 0 2844
assign 1 0 2848
return 1 0 2852
return 1 0 2855
assign 1 0 2858
assign 1 0 2862
return 1 0 2866
return 1 0 2869
assign 1 0 2872
assign 1 0 2876
return 1 0 2880
return 1 0 2883
assign 1 0 2886
assign 1 0 2890
return 1 0 2894
return 1 0 2897
assign 1 0 2900
assign 1 0 2904
return 1 0 2908
return 1 0 2911
assign 1 0 2914
assign 1 0 2918
return 1 0 2922
return 1 0 2925
assign 1 0 2928
assign 1 0 2932
return 1 0 2936
return 1 0 2939
assign 1 0 2942
assign 1 0 2946
return 1 0 2950
return 1 0 2953
assign 1 0 2956
assign 1 0 2960
return 1 0 2964
return 1 0 2967
assign 1 0 2970
assign 1 0 2974
return 1 0 2978
return 1 0 2981
assign 1 0 2984
assign 1 0 2988
return 1 0 2992
return 1 0 2995
assign 1 0 2998
assign 1 0 3002
return 1 0 3006
return 1 0 3009
assign 1 0 3012
assign 1 0 3016
return 1 0 3020
return 1 0 3023
assign 1 0 3026
assign 1 0 3030
return 1 0 3034
return 1 0 3037
assign 1 0 3040
assign 1 0 3044
return 1 0 3048
return 1 0 3051
assign 1 0 3054
assign 1 0 3058
return 1 0 3062
return 1 0 3065
assign 1 0 3068
assign 1 0 3072
return 1 0 3076
return 1 0 3079
assign 1 0 3082
assign 1 0 3086
return 1 0 3090
return 1 0 3093
assign 1 0 3096
assign 1 0 3100
return 1 0 3104
return 1 0 3107
assign 1 0 3110
assign 1 0 3114
return 1 0 3118
return 1 0 3121
assign 1 0 3124
assign 1 0 3128
return 1 0 3132
return 1 0 3135
assign 1 0 3138
assign 1 0 3142
return 1 0 3146
return 1 0 3149
assign 1 0 3152
assign 1 0 3156
return 1 0 3160
return 1 0 3163
assign 1 0 3166
assign 1 0 3170
return 1 0 3174
return 1 0 3177
assign 1 0 3180
assign 1 0 3184
return 1 0 3188
return 1 0 3191
assign 1 0 3194
assign 1 0 3198
return 1 0 3202
return 1 0 3205
assign 1 0 3208
assign 1 0 3212
return 1 0 3216
return 1 0 3219
assign 1 0 3222
assign 1 0 3226
return 1 0 3230
return 1 0 3233
assign 1 0 3236
assign 1 0 3240
return 1 0 3244
return 1 0 3247
assign 1 0 3250
assign 1 0 3254
return 1 0 3258
return 1 0 3261
assign 1 0 3264
assign 1 0 3268
return 1 0 3272
return 1 0 3275
assign 1 0 3278
assign 1 0 3282
return 1 0 3286
return 1 0 3289
assign 1 0 3292
assign 1 0 3296
return 1 0 3300
return 1 0 3303
assign 1 0 3306
assign 1 0 3310
return 1 0 3314
return 1 0 3317
assign 1 0 3320
assign 1 0 3324
return 1 0 3328
return 1 0 3331
assign 1 0 3334
assign 1 0 3338
return 1 0 3342
return 1 0 3345
assign 1 0 3348
assign 1 0 3352
return 1 0 3356
return 1 0 3359
assign 1 0 3362
assign 1 0 3366
return 1 0 3370
assign 1 0 3373
assign 1 0 3377
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1707848862: return bem_printAstGet_0();
case 163985511: return bem_saveSynsGet_0();
case -469941761: return bem_deployPathGetDirect_0();
case 2132306504: return bem_classNameGet_0();
case 381625944: return bem_emitCommonGetDirect_0();
case 1125147089: return bem_sharedEmitterGet_0();
case 1794518227: return bem_iteratorGet_0();
case 1598756390: return bem_buildSucceededGetDirect_0();
case 156566888: return bem_fromFileGetDirect_0();
case -2084513575: return bem_deployUsedLibrariesGetDirect_0();
case -708238285: return bem_deployPathGet_0();
case 1537689016: return bem_doWhat_0();
case -1631767743: return bem_emitterGet_0();
case -500511233: return bem_libNameGet_0();
case -575527849: return bem_printPlacesGetDirect_0();
case 273548735: return bem_extLinkObjectsGetDirect_0();
case -1895774437: return bem_buildMessageGet_0();
case 783431458: return bem_putLineNumbersInTraceGetDirect_0();
case -2091282514: return bem_sharedEmitterGetDirect_0();
case 2005192015: return bem_serializeToString_0();
case -2002941964: return bem_deployFilesFromGet_0();
case -181500453: return bem_copy_0();
case 1729829918: return bem_deployLibraryGetDirect_0();
case 1879714610: return bem_compilerGet_0();
case 454922082: return bem_deployFilesToGetDirect_0();
case -2102446340: return bem_twtokGetDirect_0();
case 244616884: return bem_saveIdsGet_0();
case -1555819880: return bem_printAstElementsGet_0();
case 704725832: return bem_usedLibrarysStrGet_0();
case 1368612627: return bem_parseEmitCompileTimeGet_0();
case -1794432024: return bem_loadSynsGet_0();
case -1844047973: return bem_ownProcessGet_0();
case -2089085321: return bem_paramsGet_0();
case -130621946: return bem_outputPlatformGetDirect_0();
case 1290142126: return bem_libNameGetDirect_0();
case -653020958: return bem_genOnlyGet_0();
case 2021304985: return bem_readBufferGet_0();
case 1516473378: return bem_saveSynsGetDirect_0();
case 26617766: return bem_main_0();
case -1958584856: return bem_mainNameGetDirect_0();
case -687561235: return bem_parseGet_0();
case -377355642: return bem_hashGet_0();
case 965999886: return bem_builtGet_0();
case 628536570: return bem_extIncludesGetDirect_0();
case 144506434: return bem_new_0();
case 952056940: return bem_toString_0();
case -1830560348: return bem_fieldNamesGet_0();
case 663801073: return bem_emitLibraryGet_0();
case -1052170964: return bem_linkLibArgsGet_0();
case 1795642598: return bem_ownProcessGetDirect_0();
case 1699982345: return bem_ntypesGetDirect_0();
case -1434960598: return bem_serializeContents_0();
case 1760003723: return bem_prepMakeGet_0();
case 118372406: return bem_emitLangsGet_0();
case 1298201956: return bem_printAstGetDirect_0();
case -19809120: return bem_compilerProfileGetDirect_0();
case 1364444265: return bem_makeArgsGet_0();
case 1022867717: return bem_mainNameGet_0();
case 1299241955: return bem_parseEmitCompileTimeGetDirect_0();
case 107487451: return bem_printAllAstGet_0();
case -1348969336: return bem_loadSynsGetDirect_0();
case -1864410651: return bem_deployUsedLibrariesGet_0();
case 561471372: return bem_estrGetDirect_0();
case 662727399: return bem_singleCCGetDirect_0();
case -1400395933: return bem_newlineGet_0();
case -1305008040: return bem_compilerGetDirect_0();
case 529438198: return bem_constantsGetDirect_0();
case -2072292626: return bem_closeLibrariesStrGet_0();
case 927904052: return bem_genOnlyGetDirect_0();
case -1427827058: return bem_once_0();
case -2021110714: return bem_lctokGetDirect_0();
case -1031029518: return bem_compilerProfileGet_0();
case -826140546: return bem_setClassesToWrite_0();
case -1651242797: return bem_extLinkObjectsGet_0();
case -1308756292: return bem_deployFilesToGet_0();
case -1573397368: return bem_usedLibrarysGetDirect_0();
case -452858855: return bem_constantsGet_0();
case -185057791: return bem_nlGet_0();
case -1543846384: return bem_prepMakeGetDirect_0();
case 1683492785: return bem_printStepsGet_0();
case 1522017359: return bem_closeLibrariesGetDirect_0();
case 1398381398: return bem_newlineGetDirect_0();
case -1717757609: return bem_emitFileHeaderGetDirect_0();
case 1501844231: return bem_usedLibrarysStrGetDirect_0();
case 1302479808: return bem_doEmitGetDirect_0();
case 277867678: return bem_paramsGetDirect_0();
case 1510609291: return bem_fromFileGet_0();
case -450005417: return bem_printPlacesGet_0();
case 485981730: return bem_exeNameGetDirect_0();
case 558556403: return bem_lctokGet_0();
case -1580014737: return bem_parseGetDirect_0();
case -655092564: return bem_serializationIteratorGet_0();
case -1492082702: return bem_extIncludesGet_0();
case 1761356990: return bem_makeNameGet_0();
case -1665576026: return bem_sourceFileNameGet_0();
case -341547425: return bem_toBuildGetDirect_0();
case -664467345: return bem_create_0();
case -799013242: return bem_makeGet_0();
case -559002193: return bem_startTimeGet_0();
case 178360525: return bem_emitDataGet_0();
case -1970900968: return bem_emitDebugGetDirect_0();
case 1667331006: return bem_toAny_0();
case -1468663016: return bem_config_0();
case -805181679: return bem_emitDataGetDirect_0();
case 692269892: return bem_makeArgsGetDirect_0();
case -1541896954: return bem_extLibsGet_0();
case 1504707435: return bem_buildMessageGetDirect_0();
case -424202713: return bem_linkLibArgsGetDirect_0();
case 2122992509: return bem_initLibsGetDirect_0();
case 853525656: return bem_emitLibraryGetDirect_0();
case 752142795: return bem_runArgsGetDirect_0();
case -2598804: return bem_extLibsGetDirect_0();
case -459327958: return bem_buildPathGetDirect_0();
case 663430840: return bem_emitFileHeaderGet_0();
case -2101064537: return bem_saveIdsGetDirect_0();
case -1960573206: return bem_singleCCGet_0();
case 191276239: return bem_exeNameGet_0();
case -613260949: return bem_startTimeGetDirect_0();
case 1943560083: return bem_printStepsGetDirect_0();
case -752842409: return bem_ccObjArgsGetDirect_0();
case -1998025907: return bem_parseEmitTimeGet_0();
case -1932659509: return bem_closeLibrariesStrGetDirect_0();
case 1528096585: return bem_outputPlatformGet_0();
case -1714811768: return bem_fieldIteratorGet_0();
case -1852133824: return bem_initLibsGet_0();
case -752446320: return bem_runGet_0();
case -1572899898: return bem_codeGet_0();
case 1158408225: return bem_emitDebugGet_0();
case -1054400757: return bem_deserializeClassNameGet_0();
case 1882186379: return bem_runArgsGet_0();
case 299765544: return bem_putLineNumbersInTraceGet_0();
case -881659591: return bem_nlGetDirect_0();
case -1991155198: return bem_buildSucceededGet_0();
case 934813140: return bem_platformGetDirect_0();
case -1313867098: return bem_tagGet_0();
case 75622594: return bem_includePathGet_0();
case 595040971: return bem_usedLibrarysGet_0();
case 2104565345: return bem_makeNameGetDirect_0();
case -399195596: return bem_printAstElementsGetDirect_0();
case -2090408829: return bem_emitCs_0();
case 1480876437: return bem_emitCommonGet_0();
case -1665279661: return bem_ccObjArgsGet_0();
case -534146922: return bem_emitFlagsGet_0();
case 985753857: return bem_platformGet_0();
case -1130906267: return bem_ntypesGet_0();
case 273674837: return bem_go_0();
case 1536456516: return bem_printAllAstGetDirect_0();
case 903609506: return bem_deployFilesFromGetDirect_0();
case -410990743: return bem_estrGet_0();
case 375788226: return bem_twtokGet_0();
case 168967950: return bem_emitPathGetDirect_0();
case 304767292: return bem_buildPathGet_0();
case -2118793314: return bem_emitFlagsGetDirect_0();
case 1879107239: return bem_closeLibrariesGet_0();
case 1741389031: return bem_parseTimeGetDirect_0();
case -157733273: return bem_many_0();
case 1088508101: return bem_readBufferGetDirect_0();
case -1351013647: return bem_emitPathGet_0();
case -1608861197: return bem_doEmitGet_0();
case 488653803: return bem_toBuildGet_0();
case -144273157: return bem_argsGet_0();
case -464553043: return bem_argsGetDirect_0();
case 927645542: return bem_runGetDirect_0();
case 1343604317: return bem_makeGetDirect_0();
case -598065248: return bem_deployLibraryGet_0();
case -1142800764: return bem_parseEmitTimeGetDirect_0();
case 955219055: return bem_emitLangsGetDirect_0();
case 838320946: return bem_builtGetDirect_0();
case -310437759: return bem_codeGetDirect_0();
case 2052990851: return bem_includePathGetDirect_0();
case 455481848: return bem_print_0();
case -2125252933: return bem_parseTimeGet_0();
case 1782620959: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1454653039: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 2093821098: return bem_emitDataSetDirect_1(bevd_0);
case -823661151: return bem_makeSetDirect_1(bevd_0);
case 723338127: return bem_makeSet_1(bevd_0);
case -1730386133: return bem_deployUsedLibrariesSet_1(bevd_0);
case 1135973654: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1052851111: return bem_deployFilesToSet_1(bevd_0);
case 708795066: return bem_loadSynsSetDirect_1(bevd_0);
case 1861125595: return bem_startTimeSet_1(bevd_0);
case -1654205298: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -1561814336: return bem_saveSynsSet_1(bevd_0);
case 1773732729: return bem_emitFileHeaderSetDirect_1(bevd_0);
case 1678773940: return bem_paramsSet_1(bevd_0);
case 241299765: return bem_sameType_1(bevd_0);
case -1106695990: return bem_lctokSetDirect_1(bevd_0);
case 2069326800: return bem_otherType_1(bevd_0);
case 70427451: return bem_printStepsSetDirect_1(bevd_0);
case -839061866: return bem_ownProcessSet_1(bevd_0);
case -1640793267: return bem_printStepsSet_1(bevd_0);
case -1362575853: return bem_emitDebugSet_1(bevd_0);
case 21990174: return bem_nlSet_1(bevd_0);
case 54867777: return bem_usedLibrarysSet_1(bevd_0);
case -350199173: return bem_doParse_1(bevd_0);
case 1060994965: return bem_buildMessageSet_1(bevd_0);
case 1184435851: return bem_buildPathSet_1(bevd_0);
case 1045980679: return bem_deployLibrarySet_1(bevd_0);
case 1308402021: return bem_fromFileSet_1(bevd_0);
case -1818489954: return bem_linkLibArgsSet_1(bevd_0);
case 1923074131: return bem_outputPlatformSet_1(bevd_0);
case -392162998: return bem_emitLibrarySet_1(bevd_0);
case -1652512217: return bem_emitDebugSetDirect_1(bevd_0);
case 675670520: return bem_doEmitSet_1(bevd_0);
case -2074525902: return bem_printAstElementsSet_1(bevd_0);
case 1705511928: return bem_extLibsSet_1(bevd_0);
case -754281714: return bem_deployPathSetDirect_1(bevd_0);
case -1460176770: return bem_buildMessageSetDirect_1(bevd_0);
case -2076443281: return bem_emitPathSet_1(bevd_0);
case -479946903: return bem_emitFileHeaderSet_1(bevd_0);
case 1159240150: return bem_sharedEmitterSet_1(bevd_0);
case 519688951: return bem_saveSynsSetDirect_1(bevd_0);
case 589521413: return bem_extLibsSetDirect_1(bevd_0);
case -339835542: return bem_runArgsSetDirect_1(bevd_0);
case 1682388013: return bem_newlineSetDirect_1(bevd_0);
case 519239404: return bem_buildSucceededSetDirect_1(bevd_0);
case 644545085: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case -1392003734: return bem_includePathSet_1(bevd_0);
case -796145132: return bem_exeNameSetDirect_1(bevd_0);
case 1962729847: return bem_buildSucceededSet_1(bevd_0);
case -1178826209: return bem_linkLibArgsSetDirect_1(bevd_0);
case -1653924526: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case 1879967302: return bem_argsSetDirect_1(bevd_0);
case 1208164230: return bem_emitPathSetDirect_1(bevd_0);
case -1249239602: return bem_extLinkObjectsSetDirect_1(bevd_0);
case -560923585: return bem_constantsSetDirect_1(bevd_0);
case -1336033095: return bem_mainNameSetDirect_1(bevd_0);
case -139413600: return bem_outputPlatformSetDirect_1(bevd_0);
case -1739843574: return bem_deployFilesToSetDirect_1(bevd_0);
case -1113636535: return bem_deployLibrarySetDirect_1(bevd_0);
case -513604886: return bem_emitFlagsSet_1(bevd_0);
case -1212751383: return bem_twtokSetDirect_1(bevd_0);
case -1265802051: return bem_compilerProfileSet_1(bevd_0);
case 1087770157: return bem_constantsSet_1(bevd_0);
case 1525939883: return bem_libNameSetDirect_1(bevd_0);
case 1911701664: return bem_equals_1(bevd_0);
case 655114549: return bem_readBufferSetDirect_1(bevd_0);
case -1064313990: return bem_runSet_1(bevd_0);
case 1284535205: return bem_printAstElementsSetDirect_1(bevd_0);
case 1822947621: return bem_compilerSetDirect_1(bevd_0);
case -459360005: return bem_otherClass_1(bevd_0);
case 585852282: return bem_libNameSet_1(bevd_0);
case 1003716077: return bem_def_1(bevd_0);
case -98791052: return bem_defined_1(bevd_0);
case -559442072: return bem_builtSet_1(bevd_0);
case -1556583535: return bem_builtSetDirect_1(bevd_0);
case -1339639270: return bem_buildPathSetDirect_1(bevd_0);
case -577985184: return bem_paramsSetDirect_1(bevd_0);
case 1272963269: return bem_sameObject_1(bevd_0);
case -1499526712: return bem_ccObjArgsSet_1(bevd_0);
case 273008382: return bem_saveIdsSetDirect_1(bevd_0);
case 1499415488: return bem_toBuildSetDirect_1(bevd_0);
case 1328824315: return bem_fromFileSetDirect_1(bevd_0);
case 2017929855: return bem_deployFilesFromSet_1(bevd_0);
case 2054656057: return bem_twtokSet_1(bevd_0);
case -2123337515: return bem_undef_1(bevd_0);
case 127372110: return bem_printAstSet_1(bevd_0);
case -2115816475: return bem_prepMakeSet_1(bevd_0);
case -440562172: return bem_deployFilesFromSetDirect_1(bevd_0);
case -771411573: return bem_singleCCSet_1(bevd_0);
case -1974538613: return bem_ownProcessSetDirect_1(bevd_0);
case 1123900248: return bem_extLinkObjectsSet_1(bevd_0);
case 589592902: return bem_sharedEmitterSetDirect_1(bevd_0);
case -2142447696: return bem_codeSet_1(bevd_0);
case -2140141016: return bem_printAstSetDirect_1(bevd_0);
case 1865056862: return bem_printAllAstSetDirect_1(bevd_0);
case 449056644: return bem_closeLibrariesSet_1(bevd_0);
case -26559400: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -557880279: return bem_argsSet_1(bevd_0);
case 507893361: return bem_initLibsSetDirect_1(bevd_0);
case 124283769: return bem_usedLibrarysStrSet_1(bevd_0);
case -406983241: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 436724492: return bem_parseTimeSetDirect_1(bevd_0);
case 1532532742: return bem_undefined_1(bevd_0);
case 1183829348: return bem_ccObjArgsSetDirect_1(bevd_0);
case -698418162: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case 1196727012: return bem_usedLibrarysSetDirect_1(bevd_0);
case -2032331004: return bem_ntypesSetDirect_1(bevd_0);
case 26279832: return bem_emitCommonSetDirect_1(bevd_0);
case 1316894055: return bem_printAllAstSet_1(bevd_0);
case -1210866902: return bem_genOnlySet_1(bevd_0);
case 1935751561: return bem_printPlacesSet_1(bevd_0);
case -1736256528: return bem_makeNameSetDirect_1(bevd_0);
case -2126464846: return bem_compilerProfileSetDirect_1(bevd_0);
case -352208492: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 344171409: return bem_includePathSetDirect_1(bevd_0);
case 1398666363: return bem_codeSetDirect_1(bevd_0);
case -625984053: return bem_emitFlagsSetDirect_1(bevd_0);
case -682302425: return bem_printPlacesSetDirect_1(bevd_0);
case 467626228: return bem_lctokSet_1(bevd_0);
case -819986655: return bem_newlineSet_1(bevd_0);
case 1640319862: return bem_emitLangsSet_1(bevd_0);
case -1632061846: return bem_readBufferSet_1(bevd_0);
case 67119013: return bem_saveIdsSet_1(bevd_0);
case 1927516865: return bem_extIncludesSetDirect_1(bevd_0);
case -866727599: return bem_makeArgsSetDirect_1(bevd_0);
case -1636648998: return bem_makeNameSet_1(bevd_0);
case 201827602: return bem_initLibsSet_1(bevd_0);
case 772596976: return bem_platformSet_1(bevd_0);
case 2102889872: return bem_sameClass_1(bevd_0);
case -1317601914: return bem_buildSyns_1(bevd_0);
case 1175579360: return bem_platformSetDirect_1(bevd_0);
case 952745557: return bem_parseSet_1(bevd_0);
case 1918866504: return bem_exeNameSet_1(bevd_0);
case -45864551: return bem_runArgsSet_1(bevd_0);
case -802404705: return bem_closeLibrariesStrSet_1(bevd_0);
case 53856843: return bem_extIncludesSet_1(bevd_0);
case 874046360: return bem_estrSet_1(bevd_0);
case -787549535: return bem_singleCCSetDirect_1(bevd_0);
case -82853437: return bem_estrSetDirect_1(bevd_0);
case 769372656: return bem_emitLangsSetDirect_1(bevd_0);
case -697446727: return bem_deployPathSet_1(bevd_0);
case -255579820: return bem_putLineNumbersInTraceSet_1(bevd_0);
case -273477102: return bem_compilerSet_1(bevd_0);
case 1272877349: return bem_makeArgsSet_1(bevd_0);
case 1019285691: return bem_genOnlySetDirect_1(bevd_0);
case -2079939009: return bem_parseTimeSet_1(bevd_0);
case -1142507173: return bem_closeLibrariesSetDirect_1(bevd_0);
case -585494508: return bem_copyTo_1(bevd_0);
case -1666677787: return bem_ntypesSet_1(bevd_0);
case 1014380353: return bem_getSynNp_1(bevd_0);
case 1554796638: return bem_mainNameSet_1(bevd_0);
case 1416995014: return bem_startTimeSetDirect_1(bevd_0);
case -850165437: return bem_nlSetDirect_1(bevd_0);
case -196621193: return bem_emitDataSet_1(bevd_0);
case 774981129: return bem_emitLibrarySetDirect_1(bevd_0);
case -1432196319: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 980243657: return bem_parseEmitTimeSetDirect_1(bevd_0);
case -1510051968: return bem_toBuildSet_1(bevd_0);
case 1198427025: return bem_notEquals_1(bevd_0);
case -317412406: return bem_runSetDirect_1(bevd_0);
case -658900682: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case -1452125318: return bem_parseSetDirect_1(bevd_0);
case -2069255494: return bem_prepMakeSetDirect_1(bevd_0);
case 2021769919: return bem_parseEmitTimeSet_1(bevd_0);
case 1093872283: return bem_usedLibrarysStrSetDirect_1(bevd_0);
case -925838087: return bem_loadSynsSet_1(bevd_0);
case 540487301: return bem_doEmitSetDirect_1(bevd_0);
case 1538305477: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case 1377625485: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -41282380: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case -753675717: return bem_emitCommonSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1973929830: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -720811311: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 198639161: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 2041425680: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1234965347: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -851449571: return bem_buildLiteral_2(bevd_0, bevd_1);
case 674286989: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1287222546: return bem_getSyn_2(bevd_0, bevd_1);
case 1411035525: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -389946827: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
}
