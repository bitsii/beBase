namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x64,0x6F,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x6C,0x6F,0x61,0x64,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x63,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static new BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static new BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_9_3_ContainerSet bevp_emitChecks;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_doMain;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_loadIds;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_ta_ph);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_singleCC = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doMain = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_saveSyns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_saveIds = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (beva_name == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevt_2_ta_ph = beva_name.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_2));
bevt_4_ta_ph = beva_name.bem_ends_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 101*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 101*/
 else /* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 101*/ {
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /* Line: 102*/
bevt_7_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_ta_ph = beva_arg.bem_swap_2(bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_ta_ph.bem_argsGet_0();
bevt_1_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_ta_ph = bem_main_1(bevl__args);
bevt_1_ta_ph.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_ta_ph );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_ta_ph = bevp_params.bem_get_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_ta_ph);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 120*/ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 120*/ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 120*/
 else /* Line: 120*/ {
break;
} /* Line: 120*/
} /* Line: 120*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try /* Line: 129*/ {
bem_config_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 133*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(350691792);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_5_BuildBuild_bels_9));
bevp_buildMessage = bevt_1_ta_ph.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 138*/
if (bevp_printSteps.bevi_bool)/* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 140*/ {
if (bevl_buildFailed.bevi_bool)/* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 140*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 140*/ {
bevp_buildMessage.bem_print_0();
} /* Line: 141*/
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bevp_platform.bemd_0(-2079457415);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1408797910, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 147*/ {
} /* Line: 147*/
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_ec = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_ta_loop = null;
BEC_2_6_6_SystemObject bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_6_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_2_4_IOFile bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_2_4_IOFile bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_5_4_LogicBool bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_5_4_LogicBool bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_5_4_LogicBool bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_108_ta_ph = null;
BEC_2_4_6_TextString bevt_109_ta_ph = null;
BEC_2_4_6_TextString bevt_110_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_114_ta_ph = null;
BEC_2_4_6_TextString bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_4_6_TextString bevt_119_ta_ph = null;
BEC_2_4_6_TextString bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_6_6_SystemObject bevt_122_ta_ph = null;
BEC_2_5_4_LogicBool bevt_123_ta_ph = null;
BEC_2_9_4_ContainerList bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_4_6_TextString bevt_126_ta_ph = null;
BEC_2_5_4_LogicBool bevt_127_ta_ph = null;
BEC_2_9_4_ContainerList bevt_128_ta_ph = null;
BEC_2_9_4_ContainerList bevt_129_ta_ph = null;
BEC_2_6_6_SystemObject bevt_130_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_5_4_LogicBool bevt_133_ta_ph = null;
BEC_2_2_4_IOFile bevt_134_ta_ph = null;
BEC_2_2_4_IOFile bevt_135_ta_ph = null;
BEC_2_5_4_LogicBool bevt_136_ta_ph = null;
BEC_2_2_4_IOFile bevt_137_ta_ph = null;
BEC_2_6_6_SystemObject bevt_138_ta_ph = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_6_ta_ph = bevp_params.bem_get_1(bevl_bkey);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 157*/ {
bevt_7_ta_ph = bevp_params.bem_get_1(bevl_bkey);
bevt_0_ta_loop = bevt_7_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 158*/ {
bevt_8_ta_ph = bevt_0_ta_loop.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 158*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-641452021);
bevt_10_ta_ph = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_10_ta_ph.bevi_bool) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 159*/ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_11_ta_ph = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_11_ta_ph);
} /* Line: 161*/
} /* Line: 159*/
 else /* Line: 158*/ {
break;
} /* Line: 158*/
} /* Line: 158*/
} /* Line: 158*/
bevt_14_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_nameGet_0();
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_12_ta_ph = bevt_13_ta_ph.bem_equals_1(bevt_15_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 166*/ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 167*/
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_12));
bevt_16_ta_ph = bevp_params.bem_get_1(bevt_17_ta_ph);
bevp_libName = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_firstGet_0();
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_18_ta_ph = bevp_params.bem_has_1(bevt_19_ta_ph);
if (bevt_18_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_20_ta_ph = bevp_params.bem_get_1(bevt_21_ta_ph);
bevp_exeName = (BEC_2_4_6_TextString) bevt_20_ta_ph.bem_firstGet_0();
} /* Line: 171*/
 else /* Line: 172*/ {
bevp_exeName = bevp_libName;
} /* Line: 173*/
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_24_ta_ph = bevp_params.bem_get_2(bevt_25_ta_ph, bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_firstGet_0();
bevt_22_ta_ph = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_23_ta_ph);
bevp_buildPath = bevt_22_ta_ph.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevp_buildPath.bem_addStep_1(bevt_27_ta_ph);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_30_ta_ph = bevp_params.bem_get_2(bevt_31_ta_ph, bevt_32_ta_ph);
bevt_29_ta_ph = bevt_30_ta_ph.bem_firstGet_0();
bevt_28_ta_ph = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_29_ta_ph);
bevp_includePath = bevt_28_ta_ph.bem_pathGet_0();
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_18));
bevt_37_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_36_ta_ph = bevt_37_ta_ph.bem_nameGet_0();
bevt_34_ta_ph = bevp_params.bem_get_2(bevt_35_ta_ph, bevt_36_ta_ph);
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_33_ta_ph );
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_41_ta_ph = bevp_platform.bemd_0(-2079457415);
bevt_39_ta_ph = bevp_params.bem_get_2(bevt_40_ta_ph, (BEC_2_4_6_TextString) bevt_41_ta_ph );
bevt_38_ta_ph = bevt_39_ta_ph.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_38_ta_ph );
bevt_44_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_43_ta_ph = bevp_params.bem_get_2(bevt_44_ta_ph, bevt_45_ta_ph);
bevt_42_ta_ph = bevt_43_ta_ph.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_42_ta_ph);
bevt_48_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_49_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_47_ta_ph = bevp_params.bem_get_2(bevt_48_ta_ph, bevt_49_ta_ph);
bevt_46_ta_ph = bevt_47_ta_ph.bem_firstGet_0();
bevp_doMain = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_46_ta_ph);
bevt_52_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_53_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_51_ta_ph = bevp_params.bem_get_2(bevt_52_ta_ph, bevt_53_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_50_ta_ph);
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_57_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_55_ta_ph = bevp_params.bem_get_2(bevt_56_ta_ph, bevt_57_ta_ph);
bevt_54_ta_ph = bevt_55_ta_ph.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_54_ta_ph);
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_26));
bevp_loadSyns = bevp_params.bem_get_1(bevt_58_ta_ph);
bevt_59_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevp_loadIds = bevp_params.bem_get_1(bevt_59_ta_ph);
bevt_60_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_28));
bevp_initLibs = bevp_params.bem_get_1(bevt_60_ta_ph);
bevt_62_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_29));
bevt_61_ta_ph = bevp_params.bem_get_1(bevt_62_ta_ph);
bevp_mainName = (BEC_2_4_6_TextString) bevt_61_ta_ph.bem_firstGet_0();
bevt_64_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_30));
bevt_63_ta_ph = bevp_params.bem_get_1(bevt_64_ta_ph);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_63_ta_ph.bem_firstGet_0();
bevt_65_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_31));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_65_ta_ph);
if (bevp_usedLibrarysStr == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 192*/ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193*/
bevt_67_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_32));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_67_ta_ph);
if (bevp_closeLibrariesStr == null) {
bevt_68_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_68_ta_ph.bevi_bool)/* Line: 196*/ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197*/
bevt_69_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_69_ta_ph);
if (bevp_deployFilesFrom == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 200*/ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201*/
bevt_71_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_71_ta_ph);
if (bevp_deployFilesTo == null) {
bevt_72_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_72_ta_ph.bevi_bool)/* Line: 204*/ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205*/
bevt_73_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_extIncludes = bevp_params.bem_get_1(bevt_73_ta_ph);
if (bevp_extIncludes == null) {
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_74_ta_ph.bevi_bool)/* Line: 208*/ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209*/
bevt_75_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_75_ta_ph);
if (bevp_ccObjArgs == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 212*/ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213*/
bevt_77_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extLibs = bevp_params.bem_get_1(bevt_77_ta_ph);
if (bevp_extLibs == null) {
bevt_78_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_78_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_78_ta_ph.bevi_bool)/* Line: 216*/ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217*/
bevt_79_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_79_ta_ph);
if (bevp_linkLibArgs == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 220*/ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221*/
bevt_81_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_81_ta_ph);
if (bevp_extLinkObjects == null) {
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 224*/ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 225*/
bevt_83_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_83_ta_ph);
if (bevp_emitFileHeader == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 228*/ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-1081918788);
} /* Line: 229*/
bevt_85_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_runArgs = bevp_params.bem_get_1(bevt_85_ta_ph);
if (bevp_runArgs == null) {
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 232*/ {
bevp_runArgs = bevp_runArgs.bemd_0(-1081918788);
} /* Line: 233*/
 else /* Line: 234*/ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 235*/
bevt_87_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_42));
bevt_88_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_87_ta_ph, bevt_88_ta_ph);
bevt_89_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_43));
bevt_90_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_89_ta_ph, bevt_90_ta_ph);
bevt_91_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_44));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_92_ta_ph);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_93_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_46));
bevl_pacm = bevp_params.bem_get_1(bevt_93_ta_ph);
if (bevl_pacm == null) {
bevt_94_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_94_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_94_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_96_ta_ph = bevl_pacm.bem_isEmptyGet_0();
if (bevt_96_ta_ph.bevi_bool) {
bevt_95_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_95_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_95_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 243*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 243*/
 else /* Line: 243*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 243*/ {
bevt_1_ta_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
/* Line: 244*/ {
bevt_97_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_97_ta_ph).bevi_bool)/* Line: 244*/ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 245*/
 else /* Line: 244*/ {
break;
} /* Line: 244*/
} /* Line: 244*/
} /* Line: 244*/
bevt_98_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_98_ta_ph);
bevt_99_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_48));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_99_ta_ph);
bevt_100_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_run = bevp_params.bem_isTrue_1(bevt_100_ta_ph);
bevt_101_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_101_ta_ph);
bevt_102_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_51));
bevt_103_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_102_ta_ph, bevt_103_ta_ph);
bevt_104_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_emitLangs = bevp_params.bem_get_1(bevt_104_ta_ph);
bevt_105_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_53));
bevp_emitFlags = bevp_params.bem_get_1(bevt_105_ta_ph);
bevp_emitChecks = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (bevp_emitFlags == null) {
bevt_106_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_106_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_106_ta_ph.bevi_bool)/* Line: 256*/ {
bevt_2_ta_loop = bevp_emitFlags.bem_linkedListIteratorGet_0();
while (true)
/* Line: 257*/ {
bevt_107_ta_ph = bevt_2_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_107_ta_ph).bevi_bool)/* Line: 257*/ {
bevl_ec = (BEC_2_4_6_TextString) bevt_2_ta_loop.bem_nextGet_0();
bevp_emitChecks.bem_addValue_1(bevl_ec);
} /* Line: 259*/
 else /* Line: 257*/ {
break;
} /* Line: 257*/
} /* Line: 257*/
} /* Line: 257*/
bevt_109_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevt_110_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_55));
bevt_108_ta_ph = bevp_params.bem_get_2(bevt_109_ta_ph, bevt_110_ta_ph);
bevp_compiler = (BEC_2_4_6_TextString) bevt_108_ta_ph.bem_firstGet_0();
bevt_112_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_113_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_111_ta_ph = bevp_params.bem_get_2(bevt_112_ta_ph, bevt_113_ta_ph);
bevp_makeName = (BEC_2_4_6_TextString) bevt_111_ta_ph.bem_firstGet_0();
bevt_116_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_115_ta_ph = bevt_116_ta_ph.bem_add_1(bevp_makeName);
bevt_117_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_114_ta_ph = bevp_params.bem_get_2(bevt_115_ta_ph, bevt_117_ta_ph);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_114_ta_ph.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_118_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_118_ta_ph.bevi_bool)/* Line: 272*/ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 273*/
 else /* Line: 274*/ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_59));
} /* Line: 275*/
bevt_121_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_60));
bevt_120_ta_ph = bevl_outLang.bem_add_1(bevt_121_ta_ph);
bevt_122_ta_ph = bevp_platform.bemd_0(-2079457415);
bevt_119_ta_ph = bevt_120_ta_ph.bem_add_1(bevt_122_ta_ph);
bevl_platformSources = bevp_params.bem_get_1(bevt_119_ta_ph);
if (bevl_platformSources == null) {
bevt_123_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_123_ta_ph.bevi_bool)/* Line: 283*/ {
bevt_124_ta_ph = bevp_params.bem_orderedGet_0();
bevt_124_ta_ph.bem_addAll_1(bevl_platformSources);
} /* Line: 284*/
bevt_126_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_125_ta_ph = bevl_outLang.bem_add_1(bevt_126_ta_ph);
bevl_langSources = bevp_params.bem_get_1(bevt_125_ta_ph);
if (bevl_langSources == null) {
bevt_127_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_127_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_127_ta_ph.bevi_bool)/* Line: 288*/ {
bevt_128_ta_ph = bevp_params.bem_orderedGet_0();
bevt_128_ta_ph.bem_addAll_1(bevl_langSources);
} /* Line: 289*/
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_129_ta_ph = bevp_params.bem_orderedGet_0();
bevt_3_ta_loop = bevt_129_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 293*/ {
bevt_130_ta_ph = bevt_3_ta_loop.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_130_ta_ph).bevi_bool)/* Line: 293*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_3_ta_loop.bemd_0(-641452021);
bevt_131_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_131_ta_ph);
} /* Line: 294*/
 else /* Line: 293*/ {
break;
} /* Line: 293*/
} /* Line: 293*/
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(707417315);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_134_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_133_ta_ph = bevt_134_ta_ph.bem_existsGet_0();
if (bevt_133_ta_ph.bevi_bool) {
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 301*/ {
bevt_135_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_135_ta_ph.bem_makeDirs_0();
} /* Line: 302*/
if (bevp_emitFileHeader == null) {
bevt_136_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_136_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_136_ta_ph.bevi_bool)/* Line: 304*/ {
bevt_137_ta_ph = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_137_ta_ph.bem_readerGet_0();
bevt_138_ta_ph = bevl_emr.bemd_0(-476757857);
bevp_emitFileHeader = bevt_138_ta_ph.bemd_0(-1751369017);
bevl_emr.bemd_0(-645051051);
} /* Line: 307*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_ta_ph = bevl_toRet.bemd_1(1688096367, bevp_nl);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_62));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1688096367, bevt_2_ta_ph);
bevt_3_ta_ph = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_ta_ph.bemd_1(1688096367, bevt_3_ta_ph);
bevt_5_ta_ph = bevl_toRet.bemd_1(1688096367, bevp_nl);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_63));
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(1688096367, bevt_6_ta_ph);
bevt_7_ta_ph = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_ta_ph.bemd_1(1688096367, bevt_7_ta_ph);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_9_3_ContainerMap bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 321*/ {
bevt_3_ta_ph = bevl_ci.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 321*/ {
bevl_clnode = bevl_ci.bemd_0(-641452021);
bevt_5_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(-289805241);
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 323*/ {
bevt_10_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-507142367);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(350691792);
bevl_toEmit.bem_put_1(bevt_8_ta_ph);
bevt_11_ta_ph = bevp_emitData.bem_usedByGet_0();
bevt_14_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(-507142367);
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(350691792);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_ta_ph.bem_get_1(bevt_12_ta_ph);
if (bevl_usedBy == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_0_ta_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
/* Line: 327*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_16_ta_ph.bevi_bool)/* Line: 327*/ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 328*/
 else /* Line: 327*/ {
break;
} /* Line: 327*/
} /* Line: 327*/
} /* Line: 327*/
bevt_17_ta_ph = bevp_emitData.bem_subClassesGet_0();
bevt_20_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-507142367);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(350691792);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_ta_ph.bem_get_1(bevt_18_ta_ph);
if (bevl_subClasses == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 332*/ {
bevt_1_ta_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
/* Line: 333*/ {
bevt_22_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_22_ta_ph.bevi_bool)/* Line: 333*/ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 334*/
 else /* Line: 333*/ {
break;
} /* Line: 333*/
} /* Line: 333*/
} /* Line: 333*/
} /* Line: 332*/
} /* Line: 323*/
 else /* Line: 321*/ {
break;
} /* Line: 321*/
} /* Line: 321*/
bevt_23_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 339*/ {
bevt_24_ta_ph = bevl_ci.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 339*/ {
bevl_clnode = bevl_ci.bemd_0(-641452021);
bevt_25_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_29_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(-507142367);
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(350691792);
bevt_26_ta_ph = bevl_toEmit.bem_has_1(bevt_27_ta_ph);
bevt_25_ta_ph.bemd_1(151915200, bevt_26_ta_ph);
} /* Line: 341*/
 else /* Line: 339*/ {
break;
} /* Line: 339*/
} /* Line: 339*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_9_SystemException bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
if (bevp_emitCommon == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 352*/ {
return bevp_emitCommon;
} /* Line: 353*/
if (bevp_emitLangs == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 358*/ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_64));
bevt_2_ta_ph = bevl_emitLang.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 360*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 361*/
 else /* Line: 360*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_4_ta_ph = bevl_emitLang.bem_equals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 362*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 363*/
 else /* Line: 360*/ {
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_6_ta_ph = bevl_emitLang.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 364*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 365*/
 else /* Line: 360*/ {
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_67));
bevt_8_ta_ph = bevl_emitLang.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 366*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 367*/
 else /* Line: 370*/ {
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_68));
bevt_10_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_ta_ph);
throw new be.BECS_ThrowBack(bevt_10_ta_ph);
} /* Line: 371*/
} /* Line: 360*/
} /* Line: 360*/
} /* Line: 360*/
return bevp_emitCommon;
} /* Line: 373*/
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_2_6_10_SystemSerializer bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_7_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevl_synEmitPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_69));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_lsp);
bevt_0_ta_ph.bem_print_0();
bevt_2_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = (BEC_2_4_8_TimeInterval) bevt_2_ta_ph.bem_now_0();
bevt_4_ta_ph = bevl_synEmitPath.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_ta_ph.bemd_0(-476757857);
bevt_5_ta_ph = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_ta_ph.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevt_6_ta_ph.bem_addValue_1(bevl_scls);
bevt_8_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_ta_ph = (BEC_2_4_8_TimeInterval) bevt_8_ta_ph.bem_now_0();
bevl_sse = bevt_7_ta_ph.bem_subtract_1(bevl_sst);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_5_BuildBuild_bels_70));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevl_sse);
bevt_9_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_22_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_25_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_26_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_27_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_28_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_29_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_30_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_43_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_70_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_6_6_SystemObject bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_82_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_3_MathInt bevt_98_ta_ph = null;
bevt_5_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_5_ta_ph.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 396*/ {
bevt_0_ta_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
/* Line: 397*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 397*/ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 398*/
 else /* Line: 397*/ {
break;
} /* Line: 397*/
} /* Line: 397*/
} /* Line: 397*/
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 402*/ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool)/* Line: 405*/ {
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_71));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevp_libName);
bevt_9_ta_ph.bem_print_0();
} /* Line: 406*/
} /* Line: 405*/
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_ta_loop = bevp_usedLibrarysStr.bemd_0(-71162589);
while (true)
/* Line: 411*/ {
bevt_11_ta_ph = bevt_1_ta_loop.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 411*/ {
bevl_ups = bevt_1_ta_loop.bemd_0(-641452021);
bevt_13_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 412*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 415*/
} /* Line: 412*/
 else /* Line: 411*/ {
break;
} /* Line: 411*/
} /* Line: 411*/
bevt_2_ta_loop = bevp_closeLibrariesStr.bemd_0(-71162589);
while (true)
/* Line: 418*/ {
bevt_14_ta_ph = bevt_2_ta_loop.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 418*/ {
bevl_ups = bevt_2_ta_loop.bemd_0(-641452021);
bevt_16_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_ta_ph.bevi_bool) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 419*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_ta_ph = bevl_pack.bemd_0(1504098000);
bevp_closeLibraries.bem_put_1(bevt_17_ta_ph);
} /* Line: 423*/
} /* Line: 419*/
 else /* Line: 418*/ {
break;
} /* Line: 418*/
} /* Line: 418*/
if (bevp_parse.bevi_bool)/* Line: 426*/ {
bevl_built = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
/* Line: 429*/ {
bevt_18_ta_ph = bevl_i.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 429*/ {
bevl_tb = bevl_i.bemd_0(-641452021);
bevt_20_ta_ph = bevl_tb.bemd_0(350691792);
bevt_19_ta_ph = bevl_built.bem_has_1(bevt_20_ta_ph);
if (!(bevt_19_ta_ph.bevi_bool))/* Line: 432*/ {
bevt_21_ta_ph = bevl_tb.bemd_0(350691792);
bevl_built.bem_put_1(bevt_21_ta_ph);
bem_doParse_1(bevl_tb);
} /* Line: 434*/
} /* Line: 432*/
 else /* Line: 429*/ {
break;
} /* Line: 429*/
} /* Line: 429*/
bem_buildSyns_1(bevl_em);
} /* Line: 437*/
bevt_23_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_ta_ph = (BEC_2_4_8_TimeInterval) bevt_23_ta_ph.bem_now_0();
bevp_parseTime = bevt_22_ta_ph.bem_subtract_1(bevp_startTime);
bevt_25_ta_ph = bem_emitCommonGet_0();
if (bevt_25_ta_ph == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 443*/ {
bevt_26_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_26_ta_ph.bem_now_0();
bevt_27_ta_ph = bem_emitCommonGet_0();
bevt_27_ta_ph.bem_doEmit_0();
bevt_29_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_ta_ph = (BEC_2_4_8_TimeInterval) bevt_29_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_28_ta_ph.bem_subtract_1(bevp_startTime);
bevt_31_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_ta_ph = (BEC_2_4_8_TimeInterval) bevt_31_ta_ph.bem_now_0();
bevl_emitTime = bevt_30_ta_ph.bem_subtract_1(bevl_emitStart);
bevt_33_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevp_parseTime);
bevt_32_ta_ph.bem_print_0();
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bece_BEC_2_5_5_BuildBuild_bels_73));
bevt_34_ta_ph = bevt_35_ta_ph.bem_add_1(bevl_emitTime);
bevt_34_ta_ph.bem_print_0();
bevt_37_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_36_ta_ph.bem_print_0();
bevt_38_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_38_ta_ph;
} /* Line: 452*/
if (bevp_doEmit.bevi_bool)/* Line: 454*/ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(-1256688673);
bevt_39_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 458*/ {
bevt_40_ta_ph = bevl_ci.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 458*/ {
bevl_clnode = bevl_ci.bemd_0(-641452021);
bevl_em.bemd_1(1736808703, bevl_clnode);
} /* Line: 460*/
 else /* Line: 458*/ {
break;
} /* Line: 458*/
} /* Line: 458*/
bevl_em.bemd_0(1041288236);
bevl_em.bemd_0(-2137782023);
bevt_41_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 464*/ {
bevt_42_ta_ph = bevl_ci.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_42_ta_ph).bevi_bool)/* Line: 464*/ {
bevl_clnode = bevl_ci.bemd_0(-641452021);
bevl_em.bemd_1(1706348888, bevl_clnode);
} /* Line: 466*/
 else /* Line: 464*/ {
break;
} /* Line: 464*/
} /* Line: 464*/
} /* Line: 464*/
bevt_44_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_ta_ph = (BEC_2_4_8_TimeInterval) bevt_44_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_43_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 471*/ {
bevt_47_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_46_ta_ph = bevt_47_ta_ph.bem_add_1(bevp_parseTime);
bevt_46_ta_ph.bem_print_0();
} /* Line: 472*/
bevt_49_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_48_ta_ph.bem_print_0();
if (bevp_prepMake.bevi_bool)/* Line: 475*/ {
bevl_em.bemd_1(118383525, bevp_deployLibrary);
} /* Line: 477*/
if (bevp_make.bevi_bool)/* Line: 480*/ {
if (bevp_genOnly.bevi_bool) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 481*/ {
bevl_em.bemd_1(-20804404, bevp_deployLibrary);
bevl_em.bemd_1(45357218, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool)/* Line: 484*/ {
bevt_3_ta_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
/* Line: 485*/ {
bevt_51_ta_ph = bevt_3_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_ta_ph).bevi_bool)/* Line: 485*/ {
bevl_bp = bevt_3_ta_loop.bem_nextGet_0();
bevt_52_ta_ph = bevl_bp.bemd_0(-1256688673);
bevl_cpFrom = bevt_52_ta_ph.bemd_0(1750350730);
bevt_53_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_ta_ph.bem_copy_0();
bevt_55_ta_ph = bevl_cpFrom.bemd_0(383112607);
bevt_54_ta_ph = bevt_55_ta_ph.bemd_0(1597186000);
bevl_cpTo.bemd_1(1847502032, bevt_54_ta_ph);
bevt_57_ta_ph = bevl_cpTo.bemd_0(1743454158);
bevt_56_ta_ph = bevt_57_ta_ph.bemd_0(-1094470142);
if (((BEC_2_5_4_LogicBool) bevt_56_ta_ph).bevi_bool)/* Line: 489*/ {
bevt_58_ta_ph = bevl_cpTo.bemd_0(1743454158);
bevt_58_ta_ph.bemd_0(1547390618);
} /* Line: 490*/
bevt_61_ta_ph = bevl_cpTo.bemd_0(1743454158);
bevt_60_ta_ph = bevt_61_ta_ph.bemd_0(-1094470142);
bevt_59_ta_ph = bevt_60_ta_ph.bemd_0(1203131605);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 492*/ {
bevt_62_ta_ph = bevl_cpFrom.bemd_0(1743454158);
bevt_63_ta_ph = bevl_cpTo.bemd_0(1743454158);
bevl_em.bemd_2(1891034587, bevt_62_ta_ph, bevt_63_ta_ph);
} /* Line: 493*/
} /* Line: 492*/
 else /* Line: 485*/ {
break;
} /* Line: 485*/
} /* Line: 485*/
} /* Line: 485*/
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
/* Line: 500*/ {
bevt_64_ta_ph = bevl_fIter.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 500*/ {
bevt_65_ta_ph = bevl_tIter.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_65_ta_ph).bevi_bool)/* Line: 500*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 500*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 500*/
 else /* Line: 500*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 500*/ {
bevt_66_ta_ph = bevl_fIter.bemd_0(-641452021);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_ta_ph );
bevt_71_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_71_ta_ph.bem_copy_0();
bevt_69_ta_ph = bevt_70_ta_ph.bem_toString_0();
bevt_72_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_68_ta_ph = bevt_69_ta_ph.bem_add_1(bevt_72_ta_ph);
bevt_73_ta_ph = bevl_tIter.bemd_0(-641452021);
bevt_67_ta_ph = bevt_68_ta_ph.bem_add_1(bevt_73_ta_ph);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_ta_ph);
bevt_75_ta_ph = bevl_cpTo.bemd_0(1743454158);
bevt_74_ta_ph = bevt_75_ta_ph.bemd_0(-1094470142);
if (((BEC_2_5_4_LogicBool) bevt_74_ta_ph).bevi_bool)/* Line: 504*/ {
bevt_76_ta_ph = bevl_cpTo.bemd_0(1743454158);
bevt_76_ta_ph.bemd_0(1547390618);
} /* Line: 505*/
bevt_79_ta_ph = bevl_cpTo.bemd_0(1743454158);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_0(-1094470142);
bevt_77_ta_ph = bevt_78_ta_ph.bemd_0(1203131605);
if (((BEC_2_5_4_LogicBool) bevt_77_ta_ph).bevi_bool)/* Line: 507*/ {
bevt_80_ta_ph = bevl_cpFrom.bemd_0(1743454158);
bevt_81_ta_ph = bevl_cpTo.bemd_0(1743454158);
bevl_em.bemd_2(1891034587, bevt_80_ta_ph, bevt_81_ta_ph);
} /* Line: 508*/
} /* Line: 507*/
 else /* Line: 500*/ {
break;
} /* Line: 500*/
} /* Line: 500*/
} /* Line: 500*/
} /* Line: 481*/
bevt_83_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_ta_ph = (BEC_2_4_8_TimeInterval) bevt_83_ta_ph.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 515*/ {
bevt_86_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_85_ta_ph = bevt_86_ta_ph.bem_add_1(bevp_parseTime);
bevt_85_ta_ph.bem_print_0();
} /* Line: 516*/
if (bevp_parseEmitTime == null) {
bevt_87_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_87_ta_ph.bevi_bool)/* Line: 518*/ {
bevt_89_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_88_ta_ph = bevt_89_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_88_ta_ph.bem_print_0();
} /* Line: 519*/
if (bevp_parseEmitCompileTime == null) {
bevt_90_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_90_ta_ph.bevi_bool)/* Line: 521*/ {
bevt_92_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(51, bece_BEC_2_5_5_BuildBuild_bels_75));
bevt_91_ta_ph = bevt_92_ta_ph.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_ta_ph.bem_print_0();
} /* Line: 522*/
if (bevp_run.bevi_bool)/* Line: 525*/ {
bevt_93_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_76));
bevt_93_ta_ph.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(-1429856458, bevp_deployLibrary, bevp_runArgs);
bevt_96_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_77));
bevt_95_ta_ph = bevt_96_ta_ph.bem_add_1(bevl_result);
bevt_97_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_78));
bevt_94_ta_ph = bevt_95_ta_ph.bem_add_1(bevt_97_ta_ph);
bevt_94_ta_ph.bem_print_0();
return bevl_result;
} /* Line: 529*/
bevt_98_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_98_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 535*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 535*/ {
bevl_kls = bevl_ci.bemd_0(-641452021);
bevt_2_ta_ph = bevl_kls.bemd_0(1211029271);
bevt_2_ta_ph.bemd_1(-1989672097, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-1989672097, bevp_libName);
} /* Line: 539*/
 else /* Line: 535*/ {
break;
} /* Line: 535*/
} /* Line: 535*/
bevt_3_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 541*/ {
bevt_4_ta_ph = bevl_ci.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 541*/ {
bevl_kls = bevl_ci.bemd_0(-641452021);
bevt_5_ta_ph = bevl_kls.bemd_0(1211029271);
bevl_syn = bevt_5_ta_ph.bemd_0(576833844);
bevl_syn.bemd_2(-1021309478, this, bevl_kls);
bevl_syn.bemd_1(-1085811133, this);
} /* Line: 545*/
 else /* Line: 541*/ {
break;
} /* Line: 541*/
} /* Line: 541*/
bevt_6_ta_ph = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
bevt_2_ta_ph = beva_klass.bemd_0(1211029271);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(576833844);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 551*/ {
bevt_4_ta_ph = beva_klass.bemd_0(1211029271);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(576833844);
return bevt_3_ta_ph;
} /* Line: 552*/
bevt_5_ta_ph = beva_klass.bemd_0(1211029271);
bevt_5_ta_ph.bemd_1(-1989672097, bevp_libName);
bevt_8_ta_ph = beva_klass.bemd_0(1211029271);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(-818795774);
if (bevt_7_ta_ph == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 555*/ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 556*/
 else /* Line: 557*/ {
bevt_9_ta_ph = bevp_emitData.bem_classesGet_0();
bevt_12_ta_ph = beva_klass.bemd_0(1211029271);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(-818795774);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(350691792);
bevl_pklass = bevt_9_ta_ph.bem_get_1(bevt_10_ta_ph);
if (bevl_pklass == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 560*/ {
bevt_14_ta_ph = bevl_pklass.bemd_0(1211029271);
bevt_14_ta_ph.bemd_1(-1989672097, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 562*/
 else /* Line: 563*/ {
bevt_16_ta_ph = beva_klass.bemd_0(1211029271);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-818795774);
bevl_psyn = bem_getSynNp_1(bevt_15_ta_ph);
} /* Line: 566*/
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 568*/
bevt_17_ta_ph = beva_klass.bemd_0(1211029271);
bevt_17_ta_ph.bemd_1(1642352375, bevl_syn);
bevt_20_ta_ph = beva_klass.bemd_0(1211029271);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-507142367);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(350691792);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_ta_ph , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_nps = beva_np.bemd_0(350691792);
bevt_0_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_ta_ph.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 578*/ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 579*/
bevt_2_ta_ph = bem_emitterGet_0();
bevl_syn = bevt_2_ta_ph.bemd_1(613852993, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_sharedEmitter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 594*/ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 595*/
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_ta_ph.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool)/* Line: 608*/ {
if (bevp_printSteps.bevi_bool)/* Line: 609*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 609*/ {
if (bevp_printPlaces.bevi_bool)/* Line: 609*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 609*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 609*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 609*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_79));
bevt_5_ta_ph = beva_toParse.bemd_0(350691792);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_3_ta_ph.bem_print_0();
} /* Line: 610*/
bevp_fromFile = beva_toParse;
bevt_8_ta_ph = beva_toParse.bemd_0(1743454158);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(1834015481);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(-476757857);
bevl_src = bevt_6_ta_ph.bemd_1(-1564017567, bevp_readBuffer);
bevt_10_ta_ph = beva_toParse.bemd_0(1743454158);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1834015481);
bevt_9_ta_ph.bemd_0(-645051051);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool)/* Line: 621*/ {
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_80));
bevt_11_ta_ph.bem_echo_0();
} /* Line: 622*/
bevt_12_ta_ph = bevl_trans.bemd_0(792474324);
bem_nodify_2(bevt_12_ta_ph, bevl_toks);
if (bevp_printAllAst.bevi_bool)/* Line: 625*/ {
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_5_BuildBuild_bels_81));
bevt_13_ta_ph.bem_print_0();
bevt_14_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_14_ta_ph);
} /* Line: 627*/
if (bevp_printSteps.bevi_bool)/* Line: 630*/ {
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_82));
bevt_15_ta_ph.bem_echo_0();
} /* Line: 631*/
bevt_16_ta_ph = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-376303063, bevt_16_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 634*/ {
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_83));
bevt_17_ta_ph.bem_print_0();
bevt_18_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_18_ta_ph);
} /* Line: 636*/
if (bevp_printSteps.bevi_bool)/* Line: 638*/ {
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_84));
bevt_19_ta_ph.bem_echo_0();
} /* Line: 639*/
bevt_20_ta_ph = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-376303063, bevt_20_ta_ph);
bevl_trans.bemd_0(2052790754);
if (bevp_printAllAst.bevi_bool)/* Line: 644*/ {
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_85));
bevt_21_ta_ph.bem_print_0();
bevt_22_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_22_ta_ph);
} /* Line: 646*/
if (bevp_printSteps.bevi_bool)/* Line: 649*/ {
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_86));
bevt_23_ta_ph.bem_echo_0();
} /* Line: 650*/
bevt_24_ta_ph = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-376303063, bevt_24_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 653*/ {
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_87));
bevt_25_ta_ph.bem_print_0();
bevt_26_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_26_ta_ph);
} /* Line: 655*/
if (bevp_printSteps.bevi_bool)/* Line: 658*/ {
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_88));
bevt_27_ta_ph.bem_echo_0();
} /* Line: 659*/
bevt_28_ta_ph = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-376303063, bevt_28_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 662*/ {
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_89));
bevt_29_ta_ph.bem_print_0();
bevt_30_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_30_ta_ph);
} /* Line: 664*/
if (bevp_printSteps.bevi_bool)/* Line: 667*/ {
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_90));
bevt_31_ta_ph.bem_echo_0();
} /* Line: 668*/
bevt_32_ta_ph = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-376303063, bevt_32_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 671*/ {
bevt_33_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_91));
bevt_33_ta_ph.bem_print_0();
bevt_34_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_34_ta_ph);
} /* Line: 673*/
if (bevp_printSteps.bevi_bool)/* Line: 676*/ {
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_92));
bevt_35_ta_ph.bem_echo_0();
} /* Line: 677*/
bevt_36_ta_ph = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-376303063, bevt_36_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 680*/ {
bevt_37_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_93));
bevt_37_ta_ph.bem_print_0();
bevt_38_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_38_ta_ph);
} /* Line: 682*/
if (bevp_printSteps.bevi_bool)/* Line: 685*/ {
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_94));
bevt_39_ta_ph.bem_echo_0();
} /* Line: 686*/
bevt_40_ta_ph = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-376303063, bevt_40_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 689*/ {
bevt_41_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_95));
bevt_41_ta_ph.bem_print_0();
bevt_42_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_42_ta_ph);
} /* Line: 691*/
if (bevp_printSteps.bevi_bool)/* Line: 694*/ {
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_96));
bevt_43_ta_ph.bem_echo_0();
} /* Line: 695*/
bevt_44_ta_ph = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-376303063, bevt_44_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 698*/ {
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_97));
bevt_45_ta_ph.bem_print_0();
bevt_46_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_46_ta_ph);
} /* Line: 700*/
if (bevp_printSteps.bevi_bool)/* Line: 703*/ {
bevt_47_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_98));
bevt_47_ta_ph.bem_echo_0();
} /* Line: 704*/
bevt_48_ta_ph = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-376303063, bevt_48_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 707*/ {
bevt_49_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_99));
bevt_49_ta_ph.bem_print_0();
bevt_50_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_50_ta_ph);
} /* Line: 709*/
if (bevp_printSteps.bevi_bool)/* Line: 711*/ {
bevt_51_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_100));
bevt_51_ta_ph.bem_echo_0();
} /* Line: 712*/
bevt_52_ta_ph = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-376303063, bevt_52_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 715*/ {
bevt_53_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_101));
bevt_53_ta_ph.bem_print_0();
bevt_54_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_54_ta_ph);
} /* Line: 717*/
if (bevp_printSteps.bevi_bool)/* Line: 720*/ {
bevt_55_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_102));
bevt_55_ta_ph.bem_echo_0();
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_103));
bevt_56_ta_ph.bem_print_0();
} /* Line: 722*/
bevt_57_ta_ph = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-376303063, bevt_57_ta_ph);
if (bevp_printAst.bevi_bool)/* Line: 725*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 725*/ {
if (bevp_printAllAst.bevi_bool)/* Line: 725*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 725*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 725*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 725*/ {
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_104));
bevt_58_ta_ph.bem_print_0();
bevt_59_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-376303063, bevt_59_ta_ph);
} /* Line: 727*/
bevt_60_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 729*/ {
bevt_61_ta_ph = bevl_ci.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_61_ta_ph).bevi_bool)/* Line: 729*/ {
bevl_clnode = bevl_ci.bemd_0(-641452021);
bevl_tunode = bevl_clnode.bemd_0(1074329694);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(27083027, bevt_62_ta_ph);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_ta_ph = bevl_tunode.bemd_0(1211029271);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_0(650912036);
bevl_ntt.bemd_1(-1742321511, bevt_63_ta_ph);
bevl_ntunode.bemd_1(1854508188, bevl_ntt);
bevl_clnode.bemd_0(1547390618);
bevl_ntunode.bemd_1(1628522769, bevl_clnode);
bevl_ntunode.bemd_1(-1226564681, bevl_clnode);
} /* Line: 740*/
 else /* Line: 729*/ {
break;
} /* Line: 729*/
} /* Line: 729*/
} /* Line: 729*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
beva_parnode.bemd_0(570845112);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(1427477189);
bevl_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_ta_ph.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 750*/ {
bevt_1_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 750*/ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_ta_ph = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(1854508188, bevt_2_ta_ph);
bevl_node.bemd_1(1764173651, bevl_nlc);
bevt_4_ta_ph = bevl_node.bemd_0(1211029271);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(1408797910, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 754*/ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 755*/
bevt_6_ta_ph = bevl_node.bemd_0(1211029271);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(-143491207, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 757*/ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(81364865, beva_parnode);
} /* Line: 759*/
} /* Line: 757*/
 else /* Line: 750*/ {
break;
} /* Line: 750*/
} /* Line: 750*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-1409612680, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(27083027, bevt_5_ta_ph);
bevl_nlnpn.bemd_1(1854508188, bevl_nlnp);
bevl_nlnpn.bemd_1(-1226564681, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevl_nlc.bemd_1(1432148458, bevt_6_ta_ph);
bevt_7_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1167311398, bevt_7_ta_ph);
bevt_8_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1494400535, bevt_8_ta_ph);
bevt_9_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(476066766, bevt_9_ta_ph);
bevt_10_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1198499638, bevt_10_ta_ph);
bevt_11_ta_ph = beva_node.bemd_0(1211029271);
bevl_nlc.bemd_1(-159553073, bevt_11_ta_ph);
beva_node.bemd_1(1628522769, bevl_nlnpn);
bevt_12_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(27083027, bevt_12_ta_ph);
beva_node.bemd_1(1854508188, bevl_nlc);
bevl_nlnpn.bemd_0(-133249146);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_105));
bevt_13_ta_ph = beva_tName.bemd_1(1408797910, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 789*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 789*/ {
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_106));
bevt_15_ta_ph = beva_tName.bemd_1(1408797910, bevt_16_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 789*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 789*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 789*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 789*/ {
bevl_pn = beva_node.bemd_0(1492461624);
if (bevl_pn == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 791*/ {
bevt_19_ta_ph = bevl_pn.bemd_0(822998896);
bevt_20_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(1408797910, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 791*/ {
bevt_22_ta_ph = bevl_pn.bemd_0(822998896);
bevt_23_ta_ph = bevp_ntypes.bem_ADDGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(1408797910, bevt_23_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 791*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 791*/
 else /* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 791*/ {
bevl_pn2 = bevl_pn.bemd_0(1492461624);
if (bevl_pn2 == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_26_ta_ph = bevl_pn2.bemd_0(822998896);
bevt_27_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(-143491207, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_25_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_29_ta_ph = bevl_pn2.bemd_0(822998896);
bevt_30_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bemd_1(-143491207, bevt_30_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
 else /* Line: 793*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_32_ta_ph = bevl_pn2.bemd_0(822998896);
bevt_33_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_31_ta_ph = bevt_32_ta_ph.bemd_1(-143491207, bevt_33_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_31_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
 else /* Line: 793*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_35_ta_ph = bevl_pn2.bemd_0(822998896);
bevt_36_ta_ph = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bemd_1(-143491207, bevt_36_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
 else /* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_38_ta_ph = bevl_pn.bemd_0(1211029271);
bevt_39_ta_ph = bevl_nlc.bemd_0(-558666375);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(1688096367, bevt_39_ta_ph);
bevl_nlc.bemd_1(-159553073, bevt_37_ta_ph);
bevl_pn.bemd_0(1547390618);
} /* Line: 800*/
} /* Line: 793*/
} /* Line: 791*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGetDirect_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGetDirect_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitFileHeader = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitFileHeader = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGetDirect_0() {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_platform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_platform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outputPlatform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outputPlatform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLibrary = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLibrary = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_usedLibrarysStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_usedLibrarysStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_closeLibrariesStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_closeLibrariesStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGetDirect_0() {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_runArgs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_runArgs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGetDirect_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGetDirect_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_includePath = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_includePath = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGetDirect_0() {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGetDirect_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGetDirect_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGetDirect_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGetDirect_0() {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_code = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_code = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGetDirect_0() {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sharedEmitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sharedEmitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGetDirect_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGetDirect_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGetDirect_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGetDirect_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGet_0() {
return bevp_emitChecks;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGetDirect_0() {
return bevp_emitChecks;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGetDirect_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGetDirect_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doMainGet_0() {
return bevp_doMain;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doMainGetDirect_0() {
return bevp_doMain;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doMainSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_doMain = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doMainSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_doMain = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGetDirect_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGetDirect_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadIdsGet_0() {
return bevp_loadIds;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadIdsGetDirect_0() {
return bevp_loadIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_loadIds = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_loadIds = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {51, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 68, 70, 71, 72, 73, 73, 76, 79, 80, 81, 88, 89, 90, 91, 92, 93, 93, 101, 101, 101, 101, 0, 101, 101, 0, 0, 0, 0, 0, 102, 102, 104, 104, 108, 108, 108, 108, 112, 112, 113, 113, 113, 117, 118, 119, 119, 119, 119, 119, 120, 120, 120, 121, 120, 123, 127, 128, 130, 131, 132, 133, 135, 136, 137, 137, 138, 0, 0, 0, 141, 143, 147, 147, 147, 149, 154, 156, 157, 157, 157, 158, 158, 0, 158, 158, 159, 159, 159, 160, 161, 161, 166, 166, 166, 166, 167, 169, 169, 169, 170, 170, 171, 171, 171, 173, 175, 175, 175, 175, 175, 175, 176, 177, 177, 178, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 184, 184, 184, 184, 184, 185, 185, 186, 186, 187, 187, 189, 189, 189, 190, 190, 190, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 231, 232, 232, 233, 235, 237, 237, 237, 238, 238, 238, 239, 239, 240, 240, 241, 242, 242, 243, 243, 243, 243, 243, 0, 0, 0, 244, 0, 244, 244, 245, 248, 248, 249, 249, 250, 250, 251, 251, 252, 252, 252, 253, 253, 254, 254, 255, 256, 256, 257, 0, 257, 257, 259, 262, 262, 262, 262, 263, 263, 263, 263, 264, 264, 264, 264, 264, 265, 266, 267, 268, 269, 272, 272, 273, 275, 282, 282, 282, 282, 282, 283, 283, 284, 284, 287, 287, 287, 288, 288, 289, 289, 292, 293, 293, 0, 293, 293, 294, 294, 296, 297, 298, 300, 301, 301, 301, 301, 302, 302, 304, 304, 305, 305, 306, 306, 307, 313, 314, 314, 314, 314, 314, 315, 315, 315, 315, 315, 316, 320, 321, 321, 321, 322, 323, 323, 323, 323, 324, 324, 324, 324, 325, 325, 325, 325, 325, 326, 326, 327, 0, 327, 327, 328, 331, 331, 331, 331, 331, 332, 332, 333, 0, 333, 333, 334, 339, 339, 339, 340, 341, 341, 341, 341, 341, 341, 348, 348, 352, 352, 353, 358, 358, 359, 360, 360, 361, 362, 362, 363, 364, 364, 365, 366, 366, 367, 371, 371, 371, 373, 375, 379, 381, 381, 381, 382, 382, 383, 383, 383, 384, 384, 385, 386, 386, 387, 387, 387, 388, 388, 388, 394, 394, 395, 396, 396, 397, 0, 397, 397, 398, 401, 402, 402, 403, 404, 406, 406, 406, 409, 411, 0, 411, 411, 412, 412, 412, 413, 414, 415, 418, 0, 418, 418, 419, 419, 419, 420, 421, 422, 423, 423, 428, 429, 429, 430, 432, 432, 433, 433, 434, 437, 440, 440, 440, 443, 443, 443, 445, 445, 446, 446, 447, 447, 447, 448, 448, 448, 449, 449, 449, 450, 450, 450, 451, 451, 451, 452, 452, 455, 456, 458, 458, 458, 459, 460, 462, 463, 464, 464, 464, 465, 466, 470, 470, 470, 471, 471, 472, 472, 472, 474, 474, 474, 477, 481, 481, 482, 483, 485, 0, 485, 485, 486, 486, 487, 487, 488, 488, 488, 489, 489, 490, 490, 492, 492, 492, 493, 493, 493, 497, 498, 500, 500, 0, 0, 0, 501, 501, 502, 502, 502, 502, 502, 502, 502, 502, 504, 504, 505, 505, 507, 507, 507, 508, 508, 508, 513, 513, 513, 515, 515, 516, 516, 516, 518, 518, 519, 519, 519, 521, 521, 522, 522, 522, 526, 526, 527, 528, 528, 528, 528, 528, 529, 531, 531, 535, 535, 535, 536, 537, 537, 538, 539, 541, 541, 541, 542, 543, 543, 544, 545, 547, 547, 551, 551, 551, 551, 552, 552, 552, 554, 554, 555, 555, 555, 555, 556, 558, 558, 558, 558, 558, 560, 560, 561, 561, 562, 566, 566, 566, 568, 570, 570, 571, 571, 571, 571, 572, 576, 577, 577, 578, 578, 579, 585, 585, 586, 587, 594, 594, 595, 597, 602, 603, 604, 605, 606, 607, 607, 0, 0, 0, 610, 610, 610, 610, 612, 614, 614, 614, 614, 615, 615, 615, 618, 622, 622, 624, 624, 626, 626, 627, 627, 631, 631, 633, 633, 635, 635, 636, 636, 639, 639, 642, 642, 643, 645, 645, 646, 646, 650, 650, 652, 652, 654, 654, 655, 655, 659, 659, 661, 661, 663, 663, 664, 664, 668, 668, 670, 670, 672, 672, 673, 673, 677, 677, 679, 679, 681, 681, 682, 682, 686, 686, 688, 688, 690, 690, 691, 691, 695, 695, 697, 697, 699, 699, 700, 700, 704, 704, 706, 706, 708, 708, 709, 709, 712, 712, 714, 714, 716, 716, 717, 717, 721, 721, 722, 722, 724, 724, 0, 0, 0, 726, 726, 727, 727, 729, 729, 729, 730, 732, 733, 734, 734, 735, 736, 736, 736, 737, 738, 739, 740, 746, 747, 748, 749, 749, 750, 750, 751, 752, 752, 753, 754, 754, 755, 757, 757, 758, 759, 766, 767, 769, 770, 770, 771, 772, 774, 775, 775, 776, 776, 777, 777, 778, 778, 779, 779, 780, 780, 782, 784, 784, 785, 787, 789, 789, 0, 789, 789, 0, 0, 790, 791, 791, 791, 791, 791, 0, 791, 791, 791, 0, 0, 0, 0, 0, 792, 793, 793, 0, 793, 793, 793, 793, 793, 793, 0, 0, 0, 793, 793, 793, 0, 0, 0, 793, 793, 793, 0, 0, 0, 0, 0, 799, 799, 799, 799, 800, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 238, 243, 244, 245, 247, 250, 251, 253, 256, 260, 263, 267, 270, 271, 273, 274, 280, 281, 282, 283, 290, 291, 292, 293, 294, 306, 307, 308, 309, 310, 311, 312, 313, 316, 321, 322, 323, 329, 337, 338, 340, 341, 342, 343, 347, 348, 349, 350, 351, 354, 358, 361, 365, 367, 373, 374, 375, 378, 530, 531, 532, 533, 538, 539, 540, 540, 543, 545, 546, 547, 552, 553, 554, 555, 563, 564, 565, 566, 568, 570, 571, 572, 573, 574, 576, 577, 578, 581, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 648, 649, 651, 652, 653, 658, 659, 661, 662, 663, 668, 669, 671, 672, 673, 678, 679, 681, 682, 683, 688, 689, 691, 692, 693, 698, 699, 701, 702, 703, 708, 709, 711, 712, 713, 718, 719, 721, 722, 723, 728, 729, 731, 732, 733, 738, 739, 741, 742, 743, 748, 749, 752, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 772, 773, 774, 779, 780, 783, 787, 790, 790, 793, 795, 796, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 824, 825, 825, 828, 830, 831, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 861, 862, 865, 867, 868, 869, 870, 871, 872, 877, 878, 879, 881, 882, 883, 884, 889, 890, 891, 893, 894, 895, 895, 898, 900, 901, 902, 908, 909, 910, 911, 912, 913, 914, 919, 920, 921, 923, 928, 929, 930, 931, 932, 933, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 998, 999, 1000, 1003, 1005, 1006, 1007, 1008, 1009, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1025, 1026, 1026, 1029, 1031, 1032, 1039, 1040, 1041, 1042, 1043, 1044, 1049, 1050, 1050, 1053, 1055, 1056, 1069, 1070, 1073, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1091, 1092, 1108, 1113, 1114, 1116, 1121, 1122, 1123, 1124, 1126, 1129, 1130, 1132, 1135, 1136, 1138, 1141, 1142, 1144, 1147, 1148, 1149, 1154, 1156, 1175, 1176, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1315, 1316, 1317, 1318, 1323, 1324, 1324, 1327, 1329, 1330, 1337, 1338, 1343, 1344, 1345, 1347, 1348, 1349, 1352, 1353, 1353, 1356, 1358, 1359, 1360, 1365, 1366, 1367, 1368, 1375, 1375, 1378, 1380, 1381, 1382, 1387, 1388, 1389, 1390, 1391, 1392, 1400, 1401, 1404, 1406, 1407, 1408, 1410, 1411, 1412, 1419, 1421, 1422, 1423, 1424, 1425, 1430, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1454, 1455, 1456, 1457, 1460, 1462, 1463, 1469, 1470, 1471, 1472, 1475, 1477, 1478, 1485, 1486, 1487, 1488, 1493, 1494, 1495, 1496, 1498, 1499, 1500, 1502, 1505, 1510, 1511, 1512, 1514, 1514, 1517, 1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1530, 1531, 1533, 1534, 1535, 1537, 1538, 1539, 1547, 1548, 1551, 1553, 1555, 1558, 1562, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1578, 1579, 1581, 1582, 1583, 1585, 1586, 1587, 1596, 1597, 1598, 1599, 1604, 1605, 1606, 1607, 1609, 1614, 1615, 1616, 1617, 1619, 1624, 1625, 1626, 1627, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1640, 1641, 1654, 1655, 1658, 1660, 1661, 1662, 1663, 1664, 1670, 1671, 1674, 1676, 1677, 1678, 1679, 1680, 1686, 1687, 1715, 1716, 1717, 1722, 1723, 1724, 1725, 1727, 1728, 1729, 1730, 1731, 1736, 1737, 1740, 1741, 1742, 1743, 1744, 1745, 1750, 1751, 1752, 1753, 1756, 1757, 1758, 1760, 1762, 1763, 1764, 1765, 1766, 1767, 1768, 1776, 1777, 1778, 1779, 1784, 1785, 1787, 1788, 1789, 1790, 1794, 1799, 1800, 1802, 1881, 1882, 1883, 1884, 1885, 1886, 1887, 1890, 1894, 1897, 1901, 1902, 1903, 1904, 1906, 1907, 1908, 1909, 1910, 1911, 1912, 1913, 1914, 1916, 1917, 1919, 1920, 1922, 1923, 1924, 1925, 1928, 1929, 1931, 1932, 1934, 1935, 1936, 1937, 1940, 1941, 1943, 1944, 1945, 1947, 1948, 1949, 1950, 1953, 1954, 1956, 1957, 1959, 1960, 1961, 1962, 1965, 1966, 1968, 1969, 1971, 1972, 1973, 1974, 1977, 1978, 1980, 1981, 1983, 1984, 1985, 1986, 1989, 1990, 1992, 1993, 1995, 1996, 1997, 1998, 2001, 2002, 2004, 2005, 2007, 2008, 2009, 2010, 2013, 2014, 2016, 2017, 2019, 2020, 2021, 2022, 2025, 2026, 2028, 2029, 2031, 2032, 2033, 2034, 2037, 2038, 2040, 2041, 2043, 2044, 2045, 2046, 2049, 2050, 2051, 2052, 2054, 2055, 2057, 2061, 2064, 2068, 2069, 2070, 2071, 2073, 2074, 2077, 2079, 2080, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2091, 2113, 2114, 2115, 2116, 2117, 2118, 2121, 2123, 2124, 2125, 2126, 2127, 2128, 2130, 2132, 2133, 2135, 2136, 2191, 2192, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2219, 2222, 2223, 2225, 2228, 2232, 2233, 2238, 2239, 2240, 2241, 2243, 2246, 2247, 2248, 2250, 2253, 2257, 2260, 2264, 2267, 2268, 2273, 2274, 2277, 2278, 2279, 2281, 2282, 2283, 2285, 2288, 2292, 2295, 2296, 2297, 2299, 2302, 2306, 2309, 2310, 2311, 2313, 2316, 2320, 2323, 2326, 2330, 2331, 2332, 2333, 2334, 2341, 2344, 2347, 2351, 2355, 2358, 2361, 2365, 2369, 2372, 2375, 2379, 2383, 2386, 2389, 2393, 2397, 2400, 2403, 2407, 2411, 2414, 2417, 2421, 2425, 2428, 2431, 2435, 2439, 2442, 2445, 2449, 2453, 2456, 2459, 2463, 2467, 2470, 2473, 2477, 2481, 2484, 2487, 2491, 2495, 2498, 2501, 2505, 2509, 2512, 2515, 2519, 2523, 2526, 2529, 2533, 2537, 2540, 2543, 2547, 2551, 2554, 2557, 2561, 2565, 2568, 2571, 2575, 2579, 2582, 2585, 2589, 2593, 2596, 2599, 2603, 2607, 2610, 2613, 2617, 2621, 2624, 2627, 2631, 2635, 2638, 2641, 2645, 2649, 2652, 2655, 2659, 2663, 2666, 2669, 2673, 2677, 2680, 2683, 2687, 2691, 2694, 2697, 2701, 2705, 2708, 2711, 2715, 2719, 2722, 2725, 2729, 2733, 2736, 2739, 2743, 2747, 2750, 2753, 2757, 2761, 2764, 2767, 2771, 2775, 2778, 2781, 2785, 2789, 2792, 2795, 2799, 2803, 2806, 2809, 2813, 2817, 2820, 2823, 2827, 2831, 2834, 2837, 2841, 2845, 2848, 2851, 2855, 2859, 2862, 2865, 2869, 2873, 2876, 2879, 2883, 2887, 2890, 2893, 2897, 2901, 2904, 2907, 2911, 2915, 2918, 2921, 2925, 2929, 2932, 2935, 2939, 2943, 2946, 2949, 2953, 2957, 2960, 2963, 2967, 2971, 2974, 2977, 2981, 2985, 2988, 2991, 2995, 2999, 3002, 3005, 3009, 3013, 3016, 3019, 3023, 3027, 3030, 3033, 3037, 3041, 3044, 3047, 3051, 3055, 3058, 3061, 3065, 3069, 3072, 3075, 3079, 3083, 3086, 3089, 3093, 3097, 3100, 3103, 3107, 3111, 3114, 3117, 3121, 3125, 3128, 3131, 3135, 3139, 3142, 3145, 3149, 3153, 3156, 3159, 3163, 3167, 3170, 3173, 3177, 3181, 3184, 3187, 3191, 3195, 3198, 3201, 3205, 3209, 3212, 3215, 3219, 3223, 3226, 3229, 3233, 3237, 3240, 3243, 3247, 3251, 3254, 3257, 3261, 3265, 3268, 3271, 3275, 3279, 3282, 3285, 3289, 3293, 3296, 3299, 3303, 3307, 3310, 3313, 3317, 3321, 3324, 3327, 3331, 3335, 3338, 3341, 3345, 3349, 3352, 3355, 3359, 3363, 3366, 3369, 3373, 3377, 3380, 3383, 3387, 3391, 3394, 3398};
/* BEGIN LINEINFO 
assign 1 51 198
new 0 51 198
assign 1 53 199
new 0 53 199
assign 1 54 200
new 0 54 200
assign 1 55 201
new 0 55 201
assign 1 56 202
new 0 56 202
assign 1 58 203
new 0 58 203
assign 1 59 204
new 0 59 204
assign 1 60 205
new 0 60 205
assign 1 61 206
new 0 61 206
assign 1 62 207
new 0 62 207
assign 1 63 208
new 0 63 208
assign 1 64 209
new 0 64 209
assign 1 68 210
new 0 68 210
assign 1 70 211
new 1 70 211
assign 1 71 212
ntypesGet 0 71 212
assign 1 72 213
twtokGet 0 72 213
assign 1 73 214
new 0 73 214
assign 1 73 215
new 1 73 215
assign 1 76 216
new 0 76 216
assign 1 79 217
new 0 79 217
assign 1 80 218
new 0 80 218
assign 1 81 219
new 0 81 219
assign 1 88 220
new 0 88 220
assign 1 89 221
new 0 89 221
assign 1 90 222
new 0 90 222
assign 1 91 223
new 0 91 223
assign 1 92 224
new 0 92 224
assign 1 93 225
new 0 93 225
assign 1 93 226
new 1 93 226
assign 1 101 238
def 1 101 243
assign 1 101 244
new 0 101 244
assign 1 101 245
equals 1 101 245
assign 1 0 247
assign 1 101 250
new 0 101 250
assign 1 101 251
ends 1 101 251
assign 1 0 253
assign 1 0 256
assign 1 0 260
assign 1 0 263
assign 1 0 267
assign 1 102 270
new 0 102 270
return 1 102 271
assign 1 104 273
new 0 104 273
return 1 104 274
assign 1 108 280
new 0 108 280
assign 1 108 281
new 0 108 281
assign 1 108 282
swap 2 108 282
return 1 108 283
assign 1 112 290
new 0 112 290
assign 1 112 291
argsGet 0 112 291
assign 1 113 292
new 0 113 292
assign 1 113 293
main 1 113 293
exit 1 113 294
assign 1 117 306
assign 1 118 307
new 1 118 307
assign 1 119 308
new 0 119 308
assign 1 119 309
new 0 119 309
assign 1 119 310
get 2 119 310
assign 1 119 311
firstGet 0 119 311
assign 1 119 312
new 1 119 312
assign 1 120 313
new 0 120 313
assign 1 120 316
lesser 1 120 321
assign 1 121 322
go 0 121 322
incrementValue 0 120 323
return 1 123 329
assign 1 127 337
new 0 127 337
assign 1 128 338
new 0 128 338
config 0 130 340
assign 1 131 341
new 0 131 341
assign 1 132 342
doWhat 0 132 342
assign 1 133 343
new 0 133 343
assign 1 135 347
toString 0 135 347
assign 1 136 348
new 0 136 348
assign 1 137 349
new 0 137 349
assign 1 137 350
add 1 137 350
assign 1 138 351
new 0 138 351
assign 1 0 354
assign 1 0 358
assign 1 0 361
print 0 141 365
return 1 143 367
assign 1 147 373
nameGet 0 147 373
assign 1 147 374
new 0 147 374
assign 1 147 375
equals 1 147 375
return 1 149 378
assign 1 154 530
new 0 154 530
assign 1 156 531
new 0 156 531
assign 1 157 532
get 1 157 532
assign 1 157 533
def 1 157 538
assign 1 158 539
get 1 158 539
assign 1 158 540
iteratorGet 0 0 540
assign 1 158 543
hasNextGet 0 158 543
assign 1 158 545
nextGet 0 158 545
assign 1 159 546
has 1 159 546
assign 1 159 547
not 0 159 552
put 1 160 553
assign 1 161 554
new 1 161 554
addFile 1 161 555
assign 1 166 563
new 0 166 563
assign 1 166 564
nameGet 0 166 564
assign 1 166 565
new 0 166 565
assign 1 166 566
equals 1 166 566
preProcessorSet 1 167 568
assign 1 169 570
new 0 169 570
assign 1 169 571
get 1 169 571
assign 1 169 572
firstGet 0 169 572
assign 1 170 573
new 0 170 573
assign 1 170 574
has 1 170 574
assign 1 171 576
new 0 171 576
assign 1 171 577
get 1 171 577
assign 1 171 578
firstGet 0 171 578
assign 1 173 581
assign 1 175 583
new 0 175 583
assign 1 175 584
new 0 175 584
assign 1 175 585
get 2 175 585
assign 1 175 586
firstGet 0 175 586
assign 1 175 587
new 1 175 587
assign 1 175 588
pathGet 0 175 588
addStep 1 176 589
assign 1 177 590
new 0 177 590
addStep 1 177 591
assign 1 178 592
new 0 178 592
assign 1 178 593
new 0 178 593
assign 1 178 594
get 2 178 594
assign 1 178 595
firstGet 0 178 595
assign 1 178 596
new 1 178 596
assign 1 178 597
pathGet 0 178 597
assign 1 179 598
new 0 179 598
assign 1 179 599
new 0 179 599
assign 1 179 600
nameGet 0 179 600
assign 1 179 601
get 2 179 601
assign 1 179 602
firstGet 0 179 602
assign 1 179 603
new 1 179 603
assign 1 180 604
new 0 180 604
assign 1 180 605
nameGet 0 180 605
assign 1 180 606
get 2 180 606
assign 1 180 607
firstGet 0 180 607
assign 1 180 608
new 1 180 608
assign 1 181 609
new 0 181 609
assign 1 181 610
new 0 181 610
assign 1 181 611
get 2 181 611
assign 1 181 612
firstGet 0 181 612
assign 1 181 613
new 1 181 613
assign 1 182 614
new 0 182 614
assign 1 182 615
new 0 182 615
assign 1 182 616
get 2 182 616
assign 1 182 617
firstGet 0 182 617
assign 1 182 618
new 1 182 618
assign 1 183 619
new 0 183 619
assign 1 183 620
new 0 183 620
assign 1 183 621
get 2 183 621
assign 1 183 622
firstGet 0 183 622
assign 1 183 623
new 1 183 623
assign 1 184 624
new 0 184 624
assign 1 184 625
new 0 184 625
assign 1 184 626
get 2 184 626
assign 1 184 627
firstGet 0 184 627
assign 1 184 628
new 1 184 628
assign 1 185 629
new 0 185 629
assign 1 185 630
get 1 185 630
assign 1 186 631
new 0 186 631
assign 1 186 632
get 1 186 632
assign 1 187 633
new 0 187 633
assign 1 187 634
get 1 187 634
assign 1 189 635
new 0 189 635
assign 1 189 636
get 1 189 636
assign 1 189 637
firstGet 0 189 637
assign 1 190 638
new 0 190 638
assign 1 190 639
get 1 190 639
assign 1 190 640
firstGet 0 190 640
assign 1 191 641
new 0 191 641
assign 1 191 642
get 1 191 642
assign 1 192 643
undef 1 192 648
assign 1 193 649
new 0 193 649
assign 1 195 651
new 0 195 651
assign 1 195 652
get 1 195 652
assign 1 196 653
undef 1 196 658
assign 1 197 659
new 0 197 659
assign 1 199 661
new 0 199 661
assign 1 199 662
get 1 199 662
assign 1 200 663
undef 1 200 668
assign 1 201 669
new 0 201 669
assign 1 203 671
new 0 203 671
assign 1 203 672
get 1 203 672
assign 1 204 673
undef 1 204 678
assign 1 205 679
new 0 205 679
assign 1 207 681
new 0 207 681
assign 1 207 682
get 1 207 682
assign 1 208 683
undef 1 208 688
assign 1 209 689
new 0 209 689
assign 1 211 691
new 0 211 691
assign 1 211 692
get 1 211 692
assign 1 212 693
undef 1 212 698
assign 1 213 699
new 0 213 699
assign 1 215 701
new 0 215 701
assign 1 215 702
get 1 215 702
assign 1 216 703
undef 1 216 708
assign 1 217 709
new 0 217 709
assign 1 219 711
new 0 219 711
assign 1 219 712
get 1 219 712
assign 1 220 713
undef 1 220 718
assign 1 221 719
new 0 221 719
assign 1 223 721
new 0 223 721
assign 1 223 722
get 1 223 722
assign 1 224 723
undef 1 224 728
assign 1 225 729
new 0 225 729
assign 1 227 731
new 0 227 731
assign 1 227 732
get 1 227 732
assign 1 228 733
def 1 228 738
assign 1 229 739
firstGet 0 229 739
assign 1 231 741
new 0 231 741
assign 1 231 742
get 1 231 742
assign 1 232 743
def 1 232 748
assign 1 233 749
firstGet 0 233 749
assign 1 235 752
new 0 235 752
assign 1 237 754
new 0 237 754
assign 1 237 755
new 0 237 755
assign 1 237 756
isTrue 2 237 756
assign 1 238 757
new 0 238 757
assign 1 238 758
new 0 238 758
assign 1 238 759
isTrue 2 238 759
assign 1 239 760
new 0 239 760
assign 1 239 761
isTrue 1 239 761
assign 1 240 762
new 0 240 762
assign 1 240 763
isTrue 1 240 763
assign 1 241 764
new 0 241 764
assign 1 242 765
new 0 242 765
assign 1 242 766
get 1 242 766
assign 1 243 767
def 1 243 772
assign 1 243 773
isEmptyGet 0 243 773
assign 1 243 774
not 0 243 779
assign 1 0 780
assign 1 0 783
assign 1 0 787
assign 1 244 790
linkedListIteratorGet 0 0 790
assign 1 244 793
hasNextGet 0 244 793
assign 1 244 795
nextGet 0 244 795
put 1 245 796
assign 1 248 803
new 0 248 803
assign 1 248 804
isTrue 1 248 804
assign 1 249 805
new 0 249 805
assign 1 249 806
isTrue 1 249 806
assign 1 250 807
new 0 250 807
assign 1 250 808
isTrue 1 250 808
assign 1 251 809
new 0 251 809
assign 1 251 810
isTrue 1 251 810
assign 1 252 811
new 0 252 811
assign 1 252 812
new 0 252 812
assign 1 252 813
isTrue 2 252 813
assign 1 253 814
new 0 253 814
assign 1 253 815
get 1 253 815
assign 1 254 816
new 0 254 816
assign 1 254 817
get 1 254 817
assign 1 255 818
new 0 255 818
assign 1 256 819
def 1 256 824
assign 1 257 825
linkedListIteratorGet 0 0 825
assign 1 257 828
hasNextGet 0 257 828
assign 1 257 830
nextGet 0 257 830
addValue 1 259 831
assign 1 262 838
new 0 262 838
assign 1 262 839
new 0 262 839
assign 1 262 840
get 2 262 840
assign 1 262 841
firstGet 0 262 841
assign 1 263 842
new 0 263 842
assign 1 263 843
new 0 263 843
assign 1 263 844
get 2 263 844
assign 1 263 845
firstGet 0 263 845
assign 1 264 846
new 0 264 846
assign 1 264 847
add 1 264 847
assign 1 264 848
new 0 264 848
assign 1 264 849
get 2 264 849
assign 1 264 850
firstGet 0 264 850
assign 1 265 851
new 0 265 851
assign 1 266 852
new 0 266 852
assign 1 267 853
new 0 267 853
assign 1 268 854
new 0 268 854
assign 1 269 855
new 0 269 855
assign 1 272 856
def 1 272 861
assign 1 273 862
firstGet 0 273 862
assign 1 275 865
new 0 275 865
assign 1 282 867
new 0 282 867
assign 1 282 868
add 1 282 868
assign 1 282 869
nameGet 0 282 869
assign 1 282 870
add 1 282 870
assign 1 282 871
get 1 282 871
assign 1 283 872
def 1 283 877
assign 1 284 878
orderedGet 0 284 878
addAll 1 284 879
assign 1 287 881
new 0 287 881
assign 1 287 882
add 1 287 882
assign 1 287 883
get 1 287 883
assign 1 288 884
def 1 288 889
assign 1 289 890
orderedGet 0 289 890
addAll 1 289 891
assign 1 292 893
new 0 292 893
assign 1 293 894
orderedGet 0 293 894
assign 1 293 895
iteratorGet 0 0 895
assign 1 293 898
hasNextGet 0 293 898
assign 1 293 900
nextGet 0 293 900
assign 1 294 901
new 1 294 901
addValue 1 294 902
assign 1 296 908
newlineGet 0 296 908
assign 1 297 909
assign 1 298 910
new 1 298 910
assign 1 300 911
copy 0 300 911
assign 1 301 912
fileGet 0 301 912
assign 1 301 913
existsGet 0 301 913
assign 1 301 914
not 0 301 919
assign 1 302 920
fileGet 0 302 920
makeDirs 0 302 921
assign 1 304 923
def 1 304 928
assign 1 305 929
new 1 305 929
assign 1 305 930
readerGet 0 305 930
assign 1 306 931
open 0 306 931
assign 1 306 932
readString 0 306 932
close 0 307 933
assign 1 313 947
classNameGet 0 313 947
assign 1 314 948
add 1 314 948
assign 1 314 949
new 0 314 949
assign 1 314 950
add 1 314 950
assign 1 314 951
toString 0 314 951
assign 1 314 952
add 1 314 952
assign 1 315 953
add 1 315 953
assign 1 315 954
new 0 315 954
assign 1 315 955
add 1 315 955
assign 1 315 956
toString 0 315 956
assign 1 315 957
add 1 315 957
return 1 316 958
assign 1 320 998
new 0 320 998
assign 1 321 999
classesGet 0 321 999
assign 1 321 1000
valueIteratorGet 0 321 1000
assign 1 321 1003
hasNextGet 0 321 1003
assign 1 322 1005
nextGet 0 322 1005
assign 1 323 1006
shouldEmitGet 0 323 1006
assign 1 323 1007
heldGet 0 323 1007
assign 1 323 1008
fromFileGet 0 323 1008
assign 1 323 1009
has 1 323 1009
assign 1 324 1011
heldGet 0 324 1011
assign 1 324 1012
namepathGet 0 324 1012
assign 1 324 1013
toString 0 324 1013
put 1 324 1014
assign 1 325 1015
usedByGet 0 325 1015
assign 1 325 1016
heldGet 0 325 1016
assign 1 325 1017
namepathGet 0 325 1017
assign 1 325 1018
toString 0 325 1018
assign 1 325 1019
get 1 325 1019
assign 1 326 1020
def 1 326 1025
assign 1 327 1026
setIteratorGet 0 0 1026
assign 1 327 1029
hasNextGet 0 327 1029
assign 1 327 1031
nextGet 0 327 1031
put 1 328 1032
assign 1 331 1039
subClassesGet 0 331 1039
assign 1 331 1040
heldGet 0 331 1040
assign 1 331 1041
namepathGet 0 331 1041
assign 1 331 1042
toString 0 331 1042
assign 1 331 1043
get 1 331 1043
assign 1 332 1044
def 1 332 1049
assign 1 333 1050
setIteratorGet 0 0 1050
assign 1 333 1053
hasNextGet 0 333 1053
assign 1 333 1055
nextGet 0 333 1055
put 1 334 1056
assign 1 339 1069
classesGet 0 339 1069
assign 1 339 1070
valueIteratorGet 0 339 1070
assign 1 339 1073
hasNextGet 0 339 1073
assign 1 340 1075
nextGet 0 340 1075
assign 1 341 1076
heldGet 0 341 1076
assign 1 341 1077
heldGet 0 341 1077
assign 1 341 1078
namepathGet 0 341 1078
assign 1 341 1079
toString 0 341 1079
assign 1 341 1080
has 1 341 1080
shouldWriteSet 1 341 1081
assign 1 348 1091
new 0 348 1091
return 1 348 1092
assign 1 352 1108
def 1 352 1113
return 1 353 1114
assign 1 358 1116
def 1 358 1121
assign 1 359 1122
firstGet 0 359 1122
assign 1 360 1123
new 0 360 1123
assign 1 360 1124
equals 1 360 1124
assign 1 361 1126
new 1 361 1126
assign 1 362 1129
new 0 362 1129
assign 1 362 1130
equals 1 362 1130
assign 1 363 1132
new 1 363 1132
assign 1 364 1135
new 0 364 1135
assign 1 364 1136
equals 1 364 1136
assign 1 365 1138
new 1 365 1138
assign 1 366 1141
new 0 366 1141
assign 1 366 1142
equals 1 366 1142
assign 1 367 1144
new 1 367 1144
assign 1 371 1147
new 0 371 1147
assign 1 371 1148
new 1 371 1148
throw 1 371 1149
return 1 373 1154
return 1 375 1156
assign 1 379 1175
apNew 1 379 1175
assign 1 381 1176
new 0 381 1176
assign 1 381 1177
add 1 381 1177
print 0 381 1178
assign 1 382 1179
new 0 382 1179
assign 1 382 1180
now 0 382 1180
assign 1 383 1181
fileGet 0 383 1181
assign 1 383 1182
readerGet 0 383 1182
assign 1 383 1183
open 0 383 1183
assign 1 384 1184
new 0 384 1184
assign 1 384 1185
deserialize 1 384 1185
close 0 385 1186
assign 1 386 1187
synClassesGet 0 386 1187
addValue 1 386 1188
assign 1 387 1189
new 0 387 1189
assign 1 387 1190
now 0 387 1190
assign 1 387 1191
subtract 1 387 1191
assign 1 388 1192
new 0 388 1192
assign 1 388 1193
add 1 388 1193
print 0 388 1194
assign 1 394 1315
new 0 394 1315
assign 1 394 1316
now 0 394 1316
assign 1 395 1317
new 0 395 1317
assign 1 396 1318
def 1 396 1323
assign 1 397 1324
linkedListIteratorGet 0 0 1324
assign 1 397 1327
hasNextGet 0 397 1327
assign 1 397 1329
nextGet 0 397 1329
loadSyns 1 398 1330
assign 1 401 1337
emitterGet 0 401 1337
assign 1 402 1338
def 1 402 1343
assign 1 403 1344
new 4 403 1344
put 1 404 1345
assign 1 406 1347
new 0 406 1347
assign 1 406 1348
add 1 406 1348
print 0 406 1349
assign 1 409 1352
new 0 409 1352
assign 1 411 1353
iteratorGet 0 0 1353
assign 1 411 1356
hasNextGet 0 411 1356
assign 1 411 1358
nextGet 0 411 1358
assign 1 412 1359
has 1 412 1359
assign 1 412 1360
not 0 412 1365
put 1 413 1366
assign 1 414 1367
new 2 414 1367
addValue 1 415 1368
assign 1 418 1375
iteratorGet 0 0 1375
assign 1 418 1378
hasNextGet 0 418 1378
assign 1 418 1380
nextGet 0 418 1380
assign 1 419 1381
has 1 419 1381
assign 1 419 1382
not 0 419 1387
put 1 420 1388
assign 1 421 1389
new 2 421 1389
addValue 1 422 1390
assign 1 423 1391
libNameGet 0 423 1391
put 1 423 1392
assign 1 428 1400
new 0 428 1400
assign 1 429 1401
iteratorGet 0 429 1401
assign 1 429 1404
hasNextGet 0 429 1404
assign 1 430 1406
nextGet 0 430 1406
assign 1 432 1407
toString 0 432 1407
assign 1 432 1408
has 1 432 1408
assign 1 433 1410
toString 0 433 1410
put 1 433 1411
doParse 1 434 1412
buildSyns 1 437 1419
assign 1 440 1421
new 0 440 1421
assign 1 440 1422
now 0 440 1422
assign 1 440 1423
subtract 1 440 1423
assign 1 443 1424
emitCommonGet 0 443 1424
assign 1 443 1425
def 1 443 1430
assign 1 445 1431
new 0 445 1431
assign 1 445 1432
now 0 445 1432
assign 1 446 1433
emitCommonGet 0 446 1433
doEmit 0 446 1434
assign 1 447 1435
new 0 447 1435
assign 1 447 1436
now 0 447 1436
assign 1 447 1437
subtract 1 447 1437
assign 1 448 1438
new 0 448 1438
assign 1 448 1439
now 0 448 1439
assign 1 448 1440
subtract 1 448 1440
assign 1 449 1441
new 0 449 1441
assign 1 449 1442
add 1 449 1442
print 0 449 1443
assign 1 450 1444
new 0 450 1444
assign 1 450 1445
add 1 450 1445
print 0 450 1446
assign 1 451 1447
new 0 451 1447
assign 1 451 1448
add 1 451 1448
print 0 451 1449
assign 1 452 1450
new 0 452 1450
return 1 452 1451
setClassesToWrite 0 455 1454
libnameInfoGet 0 456 1455
assign 1 458 1456
classesGet 0 458 1456
assign 1 458 1457
valueIteratorGet 0 458 1457
assign 1 458 1460
hasNextGet 0 458 1460
assign 1 459 1462
nextGet 0 459 1462
doEmit 1 460 1463
emitMain 0 462 1469
emitCUInit 0 463 1470
assign 1 464 1471
classesGet 0 464 1471
assign 1 464 1472
valueIteratorGet 0 464 1472
assign 1 464 1475
hasNextGet 0 464 1475
assign 1 465 1477
nextGet 0 465 1477
emitSyn 1 466 1478
assign 1 470 1485
new 0 470 1485
assign 1 470 1486
now 0 470 1486
assign 1 470 1487
subtract 1 470 1487
assign 1 471 1488
def 1 471 1493
assign 1 472 1494
new 0 472 1494
assign 1 472 1495
add 1 472 1495
print 0 472 1496
assign 1 474 1498
new 0 474 1498
assign 1 474 1499
add 1 474 1499
print 0 474 1500
prepMake 1 477 1502
assign 1 481 1505
not 0 481 1510
make 1 482 1511
deployLibrary 1 483 1512
assign 1 485 1514
linkedListIteratorGet 0 0 1514
assign 1 485 1517
hasNextGet 0 485 1517
assign 1 485 1519
nextGet 0 485 1519
assign 1 486 1520
libnameInfoGet 0 486 1520
assign 1 486 1521
unitShlibGet 0 486 1521
assign 1 487 1522
emitPathGet 0 487 1522
assign 1 487 1523
copy 0 487 1523
assign 1 488 1524
stepsGet 0 488 1524
assign 1 488 1525
lastGet 0 488 1525
addStep 1 488 1526
assign 1 489 1527
fileGet 0 489 1527
assign 1 489 1528
existsGet 0 489 1528
assign 1 490 1530
fileGet 0 490 1530
delete 0 490 1531
assign 1 492 1533
fileGet 0 492 1533
assign 1 492 1534
existsGet 0 492 1534
assign 1 492 1535
not 0 492 1535
assign 1 493 1537
fileGet 0 493 1537
assign 1 493 1538
fileGet 0 493 1538
deployFile 2 493 1539
assign 1 497 1547
iteratorGet 0 497 1547
assign 1 498 1548
iteratorGet 0 498 1548
assign 1 500 1551
hasNextGet 0 500 1551
assign 1 500 1553
hasNextGet 0 500 1553
assign 1 0 1555
assign 1 0 1558
assign 1 0 1562
assign 1 501 1565
nextGet 0 501 1565
assign 1 501 1566
apNew 1 501 1566
assign 1 502 1567
emitPathGet 0 502 1567
assign 1 502 1568
copy 0 502 1568
assign 1 502 1569
toString 0 502 1569
assign 1 502 1570
new 0 502 1570
assign 1 502 1571
add 1 502 1571
assign 1 502 1572
nextGet 0 502 1572
assign 1 502 1573
add 1 502 1573
assign 1 502 1574
apNew 1 502 1574
assign 1 504 1575
fileGet 0 504 1575
assign 1 504 1576
existsGet 0 504 1576
assign 1 505 1578
fileGet 0 505 1578
delete 0 505 1579
assign 1 507 1581
fileGet 0 507 1581
assign 1 507 1582
existsGet 0 507 1582
assign 1 507 1583
not 0 507 1583
assign 1 508 1585
fileGet 0 508 1585
assign 1 508 1586
fileGet 0 508 1586
deployFile 2 508 1587
assign 1 513 1596
new 0 513 1596
assign 1 513 1597
now 0 513 1597
assign 1 513 1598
subtract 1 513 1598
assign 1 515 1599
def 1 515 1604
assign 1 516 1605
new 0 516 1605
assign 1 516 1606
add 1 516 1606
print 0 516 1607
assign 1 518 1609
def 1 518 1614
assign 1 519 1615
new 0 519 1615
assign 1 519 1616
add 1 519 1616
print 0 519 1617
assign 1 521 1619
def 1 521 1624
assign 1 522 1625
new 0 522 1625
assign 1 522 1626
add 1 522 1626
print 0 522 1627
assign 1 526 1630
new 0 526 1630
print 0 526 1631
assign 1 527 1632
run 2 527 1632
assign 1 528 1633
new 0 528 1633
assign 1 528 1634
add 1 528 1634
assign 1 528 1635
new 0 528 1635
assign 1 528 1636
add 1 528 1636
print 0 528 1637
return 1 529 1638
assign 1 531 1640
new 0 531 1640
return 1 531 1641
assign 1 535 1654
justParsedGet 0 535 1654
assign 1 535 1655
valueIteratorGet 0 535 1655
assign 1 535 1658
hasNextGet 0 535 1658
assign 1 536 1660
nextGet 0 536 1660
assign 1 537 1661
heldGet 0 537 1661
libNameSet 1 537 1662
assign 1 538 1663
getSyn 2 538 1663
libNameSet 1 539 1664
assign 1 541 1670
justParsedGet 0 541 1670
assign 1 541 1671
valueIteratorGet 0 541 1671
assign 1 541 1674
hasNextGet 0 541 1674
assign 1 542 1676
nextGet 0 542 1676
assign 1 543 1677
heldGet 0 543 1677
assign 1 543 1678
synGet 0 543 1678
checkInheritance 2 544 1679
integrate 1 545 1680
assign 1 547 1686
new 0 547 1686
justParsedSet 1 547 1687
assign 1 551 1715
heldGet 0 551 1715
assign 1 551 1716
synGet 0 551 1716
assign 1 551 1717
def 1 551 1722
assign 1 552 1723
heldGet 0 552 1723
assign 1 552 1724
synGet 0 552 1724
return 1 552 1725
assign 1 554 1727
heldGet 0 554 1727
libNameSet 1 554 1728
assign 1 555 1729
heldGet 0 555 1729
assign 1 555 1730
extendsGet 0 555 1730
assign 1 555 1731
undef 1 555 1736
assign 1 556 1737
new 1 556 1737
assign 1 558 1740
classesGet 0 558 1740
assign 1 558 1741
heldGet 0 558 1741
assign 1 558 1742
extendsGet 0 558 1742
assign 1 558 1743
toString 0 558 1743
assign 1 558 1744
get 1 558 1744
assign 1 560 1745
def 1 560 1750
assign 1 561 1751
heldGet 0 561 1751
libNameSet 1 561 1752
assign 1 562 1753
getSyn 2 562 1753
assign 1 566 1756
heldGet 0 566 1756
assign 1 566 1757
extendsGet 0 566 1757
assign 1 566 1758
getSynNp 1 566 1758
assign 1 568 1760
new 2 568 1760
assign 1 570 1762
heldGet 0 570 1762
synSet 1 570 1763
assign 1 571 1764
heldGet 0 571 1764
assign 1 571 1765
namepathGet 0 571 1765
assign 1 571 1766
toString 0 571 1766
addSynClass 2 571 1767
return 1 572 1768
assign 1 576 1776
toString 0 576 1776
assign 1 577 1777
synClassesGet 0 577 1777
assign 1 577 1778
get 1 577 1778
assign 1 578 1779
def 1 578 1784
return 1 579 1785
assign 1 585 1787
emitterGet 0 585 1787
assign 1 585 1788
loadSyn 1 585 1788
addSynClass 2 586 1789
return 1 587 1790
assign 1 594 1794
undef 1 594 1799
assign 1 595 1800
new 1 595 1800
return 1 597 1802
assign 1 602 1881
new 1 602 1881
assign 1 603 1882
new 0 603 1882
assign 1 604 1883
emitterGet 0 604 1883
assign 1 605 1884
assign 1 606 1885
new 0 606 1885
assign 1 607 1886
shouldEmitGet 0 607 1886
put 1 607 1887
assign 1 0 1890
assign 1 0 1894
assign 1 0 1897
assign 1 610 1901
new 0 610 1901
assign 1 610 1902
toString 0 610 1902
assign 1 610 1903
add 1 610 1903
print 0 610 1904
assign 1 612 1906
assign 1 614 1907
fileGet 0 614 1907
assign 1 614 1908
readerGet 0 614 1908
assign 1 614 1909
open 0 614 1909
assign 1 614 1910
readBuffer 1 614 1910
assign 1 615 1911
fileGet 0 615 1911
assign 1 615 1912
readerGet 0 615 1912
close 0 615 1913
assign 1 618 1914
tokenize 1 618 1914
assign 1 622 1916
new 0 622 1916
echo 0 622 1917
assign 1 624 1919
outermostGet 0 624 1919
nodify 2 624 1920
assign 1 626 1922
new 0 626 1922
print 0 626 1923
assign 1 627 1924
new 2 627 1924
traverse 1 627 1925
assign 1 631 1928
new 0 631 1928
echo 0 631 1929
assign 1 633 1931
new 0 633 1931
traverse 1 633 1932
assign 1 635 1934
new 0 635 1934
print 0 635 1935
assign 1 636 1936
new 2 636 1936
traverse 1 636 1937
assign 1 639 1940
new 0 639 1940
echo 0 639 1941
assign 1 642 1943
new 0 642 1943
traverse 1 642 1944
contain 0 643 1945
assign 1 645 1947
new 0 645 1947
print 0 645 1948
assign 1 646 1949
new 2 646 1949
traverse 1 646 1950
assign 1 650 1953
new 0 650 1953
echo 0 650 1954
assign 1 652 1956
new 0 652 1956
traverse 1 652 1957
assign 1 654 1959
new 0 654 1959
print 0 654 1960
assign 1 655 1961
new 2 655 1961
traverse 1 655 1962
assign 1 659 1965
new 0 659 1965
echo 0 659 1966
assign 1 661 1968
new 0 661 1968
traverse 1 661 1969
assign 1 663 1971
new 0 663 1971
print 0 663 1972
assign 1 664 1973
new 2 664 1973
traverse 1 664 1974
assign 1 668 1977
new 0 668 1977
echo 0 668 1978
assign 1 670 1980
new 0 670 1980
traverse 1 670 1981
assign 1 672 1983
new 0 672 1983
print 0 672 1984
assign 1 673 1985
new 2 673 1985
traverse 1 673 1986
assign 1 677 1989
new 0 677 1989
echo 0 677 1990
assign 1 679 1992
new 0 679 1992
traverse 1 679 1993
assign 1 681 1995
new 0 681 1995
print 0 681 1996
assign 1 682 1997
new 2 682 1997
traverse 1 682 1998
assign 1 686 2001
new 0 686 2001
echo 0 686 2002
assign 1 688 2004
new 0 688 2004
traverse 1 688 2005
assign 1 690 2007
new 0 690 2007
print 0 690 2008
assign 1 691 2009
new 2 691 2009
traverse 1 691 2010
assign 1 695 2013
new 0 695 2013
echo 0 695 2014
assign 1 697 2016
new 0 697 2016
traverse 1 697 2017
assign 1 699 2019
new 0 699 2019
print 0 699 2020
assign 1 700 2021
new 2 700 2021
traverse 1 700 2022
assign 1 704 2025
new 0 704 2025
echo 0 704 2026
assign 1 706 2028
new 0 706 2028
traverse 1 706 2029
assign 1 708 2031
new 0 708 2031
print 0 708 2032
assign 1 709 2033
new 2 709 2033
traverse 1 709 2034
assign 1 712 2037
new 0 712 2037
echo 0 712 2038
assign 1 714 2040
new 0 714 2040
traverse 1 714 2041
assign 1 716 2043
new 0 716 2043
print 0 716 2044
assign 1 717 2045
new 2 717 2045
traverse 1 717 2046
assign 1 721 2049
new 0 721 2049
echo 0 721 2050
assign 1 722 2051
new 0 722 2051
print 0 722 2052
assign 1 724 2054
new 0 724 2054
traverse 1 724 2055
assign 1 0 2057
assign 1 0 2061
assign 1 0 2064
assign 1 726 2068
new 0 726 2068
print 0 726 2069
assign 1 727 2070
new 2 727 2070
traverse 1 727 2071
assign 1 729 2073
classesGet 0 729 2073
assign 1 729 2074
valueIteratorGet 0 729 2074
assign 1 729 2077
hasNextGet 0 729 2077
assign 1 730 2079
nextGet 0 730 2079
assign 1 732 2080
transUnitGet 0 732 2080
assign 1 733 2081
new 1 733 2081
assign 1 734 2082
TRANSUNITGet 0 734 2082
typenameSet 1 734 2083
assign 1 735 2084
new 0 735 2084
assign 1 736 2085
heldGet 0 736 2085
assign 1 736 2086
emitsGet 0 736 2086
emitsSet 1 736 2087
heldSet 1 737 2088
delete 0 738 2089
addValue 1 739 2090
copyLoc 1 740 2091
reInitContained 0 746 2113
assign 1 747 2114
containedGet 0 747 2114
assign 1 748 2115
new 0 748 2115
assign 1 749 2116
new 0 749 2116
assign 1 749 2117
crGet 0 749 2117
assign 1 750 2118
linkedListIteratorGet 0 750 2118
assign 1 750 2121
hasNextGet 0 750 2121
assign 1 751 2123
new 1 751 2123
assign 1 752 2124
nextGet 0 752 2124
heldSet 1 752 2125
nlcSet 1 753 2126
assign 1 754 2127
heldGet 0 754 2127
assign 1 754 2128
equals 1 754 2128
assign 1 755 2130
increment 0 755 2130
assign 1 757 2132
heldGet 0 757 2132
assign 1 757 2133
notEquals 1 757 2133
addValue 1 758 2135
containerSet 1 759 2136
assign 1 766 2191
new 0 766 2191
fromString 1 767 2192
assign 1 769 2193
new 1 769 2193
assign 1 770 2194
NAMEPATHGet 0 770 2194
typenameSet 1 770 2195
heldSet 1 771 2196
copyLoc 1 772 2197
assign 1 774 2198
new 0 774 2198
assign 1 775 2199
new 0 775 2199
nameSet 1 775 2200
assign 1 776 2201
new 0 776 2201
wasBoundSet 1 776 2202
assign 1 777 2203
new 0 777 2203
boundSet 1 777 2204
assign 1 778 2205
new 0 778 2205
isConstructSet 1 778 2206
assign 1 779 2207
new 0 779 2207
isLiteralSet 1 779 2208
assign 1 780 2209
heldGet 0 780 2209
literalValueSet 1 780 2210
addValue 1 782 2211
assign 1 784 2212
CALLGet 0 784 2212
typenameSet 1 784 2213
heldSet 1 785 2214
resolveNp 0 787 2215
assign 1 789 2216
new 0 789 2216
assign 1 789 2217
equals 1 789 2217
assign 1 0 2219
assign 1 789 2222
new 0 789 2222
assign 1 789 2223
equals 1 789 2223
assign 1 0 2225
assign 1 0 2228
assign 1 790 2232
priorPeerGet 0 790 2232
assign 1 791 2233
def 1 791 2238
assign 1 791 2239
typenameGet 0 791 2239
assign 1 791 2240
SUBTRACTGet 0 791 2240
assign 1 791 2241
equals 1 791 2241
assign 1 0 2243
assign 1 791 2246
typenameGet 0 791 2246
assign 1 791 2247
ADDGet 0 791 2247
assign 1 791 2248
equals 1 791 2248
assign 1 0 2250
assign 1 0 2253
assign 1 0 2257
assign 1 0 2260
assign 1 0 2264
assign 1 792 2267
priorPeerGet 0 792 2267
assign 1 793 2268
undef 1 793 2273
assign 1 0 2274
assign 1 793 2277
typenameGet 0 793 2277
assign 1 793 2278
CALLGet 0 793 2278
assign 1 793 2279
notEquals 1 793 2279
assign 1 793 2281
typenameGet 0 793 2281
assign 1 793 2282
IDGet 0 793 2282
assign 1 793 2283
notEquals 1 793 2283
assign 1 0 2285
assign 1 0 2288
assign 1 0 2292
assign 1 793 2295
typenameGet 0 793 2295
assign 1 793 2296
VARGet 0 793 2296
assign 1 793 2297
notEquals 1 793 2297
assign 1 0 2299
assign 1 0 2302
assign 1 0 2306
assign 1 793 2309
typenameGet 0 793 2309
assign 1 793 2310
ACCESSORGet 0 793 2310
assign 1 793 2311
notEquals 1 793 2311
assign 1 0 2313
assign 1 0 2316
assign 1 0 2320
assign 1 0 2323
assign 1 0 2326
assign 1 799 2330
heldGet 0 799 2330
assign 1 799 2331
literalValueGet 0 799 2331
assign 1 799 2332
add 1 799 2332
literalValueSet 1 799 2333
delete 0 800 2334
return 1 0 2341
return 1 0 2344
assign 1 0 2347
assign 1 0 2351
return 1 0 2355
return 1 0 2358
assign 1 0 2361
assign 1 0 2365
return 1 0 2369
return 1 0 2372
assign 1 0 2375
assign 1 0 2379
return 1 0 2383
return 1 0 2386
assign 1 0 2389
assign 1 0 2393
return 1 0 2397
return 1 0 2400
assign 1 0 2403
assign 1 0 2407
return 1 0 2411
return 1 0 2414
assign 1 0 2417
assign 1 0 2421
return 1 0 2425
return 1 0 2428
assign 1 0 2431
assign 1 0 2435
return 1 0 2439
return 1 0 2442
assign 1 0 2445
assign 1 0 2449
return 1 0 2453
return 1 0 2456
assign 1 0 2459
assign 1 0 2463
return 1 0 2467
return 1 0 2470
assign 1 0 2473
assign 1 0 2477
return 1 0 2481
return 1 0 2484
assign 1 0 2487
assign 1 0 2491
return 1 0 2495
return 1 0 2498
assign 1 0 2501
assign 1 0 2505
return 1 0 2509
return 1 0 2512
assign 1 0 2515
assign 1 0 2519
return 1 0 2523
return 1 0 2526
assign 1 0 2529
assign 1 0 2533
return 1 0 2537
return 1 0 2540
assign 1 0 2543
assign 1 0 2547
return 1 0 2551
return 1 0 2554
assign 1 0 2557
assign 1 0 2561
return 1 0 2565
return 1 0 2568
assign 1 0 2571
assign 1 0 2575
return 1 0 2579
return 1 0 2582
assign 1 0 2585
assign 1 0 2589
return 1 0 2593
return 1 0 2596
assign 1 0 2599
assign 1 0 2603
return 1 0 2607
return 1 0 2610
assign 1 0 2613
assign 1 0 2617
return 1 0 2621
return 1 0 2624
assign 1 0 2627
assign 1 0 2631
return 1 0 2635
return 1 0 2638
assign 1 0 2641
assign 1 0 2645
return 1 0 2649
return 1 0 2652
assign 1 0 2655
assign 1 0 2659
return 1 0 2663
return 1 0 2666
assign 1 0 2669
assign 1 0 2673
return 1 0 2677
return 1 0 2680
assign 1 0 2683
assign 1 0 2687
return 1 0 2691
return 1 0 2694
assign 1 0 2697
assign 1 0 2701
return 1 0 2705
return 1 0 2708
assign 1 0 2711
assign 1 0 2715
return 1 0 2719
return 1 0 2722
assign 1 0 2725
assign 1 0 2729
return 1 0 2733
return 1 0 2736
assign 1 0 2739
assign 1 0 2743
return 1 0 2747
return 1 0 2750
assign 1 0 2753
assign 1 0 2757
return 1 0 2761
return 1 0 2764
assign 1 0 2767
assign 1 0 2771
return 1 0 2775
return 1 0 2778
assign 1 0 2781
assign 1 0 2785
return 1 0 2789
return 1 0 2792
assign 1 0 2795
assign 1 0 2799
return 1 0 2803
return 1 0 2806
assign 1 0 2809
assign 1 0 2813
return 1 0 2817
return 1 0 2820
assign 1 0 2823
assign 1 0 2827
return 1 0 2831
return 1 0 2834
assign 1 0 2837
assign 1 0 2841
return 1 0 2845
return 1 0 2848
assign 1 0 2851
assign 1 0 2855
return 1 0 2859
return 1 0 2862
assign 1 0 2865
assign 1 0 2869
return 1 0 2873
return 1 0 2876
assign 1 0 2879
assign 1 0 2883
return 1 0 2887
return 1 0 2890
assign 1 0 2893
assign 1 0 2897
return 1 0 2901
return 1 0 2904
assign 1 0 2907
assign 1 0 2911
return 1 0 2915
return 1 0 2918
assign 1 0 2921
assign 1 0 2925
return 1 0 2929
return 1 0 2932
assign 1 0 2935
assign 1 0 2939
return 1 0 2943
return 1 0 2946
assign 1 0 2949
assign 1 0 2953
return 1 0 2957
return 1 0 2960
assign 1 0 2963
assign 1 0 2967
return 1 0 2971
return 1 0 2974
assign 1 0 2977
assign 1 0 2981
return 1 0 2985
return 1 0 2988
assign 1 0 2991
assign 1 0 2995
return 1 0 2999
return 1 0 3002
assign 1 0 3005
assign 1 0 3009
return 1 0 3013
return 1 0 3016
assign 1 0 3019
assign 1 0 3023
return 1 0 3027
return 1 0 3030
assign 1 0 3033
assign 1 0 3037
return 1 0 3041
return 1 0 3044
assign 1 0 3047
assign 1 0 3051
return 1 0 3055
return 1 0 3058
assign 1 0 3061
assign 1 0 3065
return 1 0 3069
return 1 0 3072
assign 1 0 3075
assign 1 0 3079
return 1 0 3083
return 1 0 3086
assign 1 0 3089
assign 1 0 3093
return 1 0 3097
return 1 0 3100
assign 1 0 3103
assign 1 0 3107
return 1 0 3111
return 1 0 3114
assign 1 0 3117
assign 1 0 3121
return 1 0 3125
return 1 0 3128
assign 1 0 3131
assign 1 0 3135
return 1 0 3139
return 1 0 3142
assign 1 0 3145
assign 1 0 3149
return 1 0 3153
return 1 0 3156
assign 1 0 3159
assign 1 0 3163
return 1 0 3167
return 1 0 3170
assign 1 0 3173
assign 1 0 3177
return 1 0 3181
return 1 0 3184
assign 1 0 3187
assign 1 0 3191
return 1 0 3195
return 1 0 3198
assign 1 0 3201
assign 1 0 3205
return 1 0 3209
return 1 0 3212
assign 1 0 3215
assign 1 0 3219
return 1 0 3223
return 1 0 3226
assign 1 0 3229
assign 1 0 3233
return 1 0 3237
return 1 0 3240
assign 1 0 3243
assign 1 0 3247
return 1 0 3251
return 1 0 3254
assign 1 0 3257
assign 1 0 3261
return 1 0 3265
return 1 0 3268
assign 1 0 3271
assign 1 0 3275
return 1 0 3279
return 1 0 3282
assign 1 0 3285
assign 1 0 3289
return 1 0 3293
return 1 0 3296
assign 1 0 3299
assign 1 0 3303
return 1 0 3307
return 1 0 3310
assign 1 0 3313
assign 1 0 3317
return 1 0 3321
return 1 0 3324
assign 1 0 3327
assign 1 0 3331
return 1 0 3335
return 1 0 3338
assign 1 0 3341
assign 1 0 3345
return 1 0 3349
return 1 0 3352
assign 1 0 3355
assign 1 0 3359
return 1 0 3363
return 1 0 3366
assign 1 0 3369
assign 1 0 3373
return 1 0 3377
return 1 0 3380
assign 1 0 3383
assign 1 0 3387
return 1 0 3391
assign 1 0 3394
assign 1 0 3398
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 867768075: return bem_argsGet_0();
case 118871137: return bem_closeLibrariesStrGetDirect_0();
case 219532045: return bem_newlineGetDirect_0();
case -658284271: return bem_buildPathGet_0();
case 1832322865: return bem_emitChecksGetDirect_0();
case -1897474013: return bem_doMainGet_0();
case -2000107535: return bem_nlGetDirect_0();
case -1642361296: return bem_print_0();
case 1369038363: return bem_deployFilesFromGetDirect_0();
case -1983468723: return bem_sharedEmitterGet_0();
case -1736271043: return bem_lctokGetDirect_0();
case -1785724794: return bem_once_0();
case -108258267: return bem_compilerGetDirect_0();
case 616782874: return bem_mainNameGet_0();
case -1103365080: return bem_compilerProfileGetDirect_0();
case 433232954: return bem_setClassesToWrite_0();
case 1161638424: return bem_new_0();
case 602323429: return bem_deployUsedLibrariesGet_0();
case 1102025385: return bem_parseEmitCompileTimeGet_0();
case 1534535703: return bem_deployFilesToGet_0();
case 707417315: return bem_newlineGet_0();
case 212657668: return bem_extLinkObjectsGetDirect_0();
case 653651059: return bem_lctokGet_0();
case -367461465: return bem_makeGet_0();
case -1480556491: return bem_toAny_0();
case -332779021: return bem_toBuildGet_0();
case 1870416830: return bem_constantsGet_0();
case 1504098000: return bem_libNameGet_0();
case 158647598: return bem_saveIdsGet_0();
case -749984065: return bem_initLibsGet_0();
case -1702595250: return bem_extIncludesGet_0();
case 424617382: return bem_ntypesGetDirect_0();
case -2037482278: return bem_startTimeGet_0();
case 1709037870: return bem_ccObjArgsGet_0();
case 54674447: return bem_outputPlatformGetDirect_0();
case -1133602563: return bem_doWhat_0();
case -1786586412: return bem_readBufferGet_0();
case -1359614197: return bem_classNameGet_0();
case -454292794: return bem_singleCCGetDirect_0();
case 2064925791: return bem_echo_0();
case -1044758745: return bem_serializeToString_0();
case 154847670: return bem_emitDebugGet_0();
case -1866953448: return bem_estrGetDirect_0();
case -540975831: return bem_mainNameGetDirect_0();
case 436743297: return bem_parseGetDirect_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -444726311: return bem_saveSynsGet_0();
case 469555058: return bem_ownProcessGetDirect_0();
case -186230208: return bem_ownProcessGet_0();
case -289805241: return bem_fromFileGet_0();
case 478887081: return bem_runArgsGet_0();
case -843356830: return bem_deployPathGet_0();
case 680573150: return bem_usedLibrarysGet_0();
case 1237335211: return bem_platformGetDirect_0();
case 944073339: return bem_fieldIteratorGet_0();
case -1675457731: return bem_saveIdsGetDirect_0();
case -202912463: return bem_copy_0();
case -1981626428: return bem_extLibsGet_0();
case 582493096: return bem_extLibsGetDirect_0();
case -929796040: return bem_makeNameGet_0();
case -367360083: return bem_emitLibraryGet_0();
case -514437142: return bem_main_0();
case 507241361: return bem_makeGetDirect_0();
case -1750280603: return bem_saveSynsGetDirect_0();
case 169872434: return bem_parseEmitTimeGetDirect_0();
case -1506907700: return bem_runGetDirect_0();
case -39817173: return bem_loadIdsGet_0();
case -71162589: return bem_iteratorGet_0();
case 1820324707: return bem_doEmitGet_0();
case -508328104: return bem_linkLibArgsGetDirect_0();
case -436626370: return bem_printAllAstGet_0();
case 2091171948: return bem_doEmitGetDirect_0();
case -378982839: return bem_makeArgsGet_0();
case 756041374: return bem_closeLibrariesGet_0();
case 463057292: return bem_loadSynsGet_0();
case 2132420479: return bem_many_0();
case -1922828619: return bem_codeGetDirect_0();
case 338126434: return bem_deployFilesFromGet_0();
case -646323262: return bem_deployUsedLibrariesGetDirect_0();
case -1082102731: return bem_buildSucceededGet_0();
case 753963895: return bem_closeLibrariesStrGet_0();
case -2108045587: return bem_runGet_0();
case 1493328217: return bem_emitLibraryGetDirect_0();
case -1655929819: return bem_emitPathGetDirect_0();
case -2022569728: return bem_nlGet_0();
case 1132013454: return bem_buildMessageGetDirect_0();
case -825400275: return bem_usedLibrarysStrGet_0();
case -596774002: return bem_extLinkObjectsGet_0();
case -65192614: return bem_builtGet_0();
case -22283395: return bem_printPlacesGetDirect_0();
case 779046016: return bem_emitDataGetDirect_0();
case -1810252228: return bem_readBufferGetDirect_0();
case -1340383047: return bem_deployPathGetDirect_0();
case 1211741591: return bem_printStepsGet_0();
case -184647330: return bem_genOnlyGet_0();
case 941721753: return bem_twtokGetDirect_0();
case -196424276: return bem_genOnlyGetDirect_0();
case -1224006315: return bem_buildMessageGet_0();
case -687599960: return bem_loadSynsGetDirect_0();
case -231733410: return bem_prepMakeGetDirect_0();
case -1013309343: return bem_singleCCGet_0();
case 2057823599: return bem_runArgsGetDirect_0();
case 727542709: return bem_deployFilesToGetDirect_0();
case 907595075: return bem_emitChecksGet_0();
case 1811348296: return bem_printPlacesGet_0();
case 300178451: return bem_usedLibrarysGetDirect_0();
case 169227948: return bem_closeLibrariesGetDirect_0();
case -277044525: return bem_fromFileGetDirect_0();
case 173395416: return bem_argsGetDirect_0();
case 1365897346: return bem_serializationIteratorGet_0();
case 203271425: return bem_includePathGetDirect_0();
case 548722189: return bem_sharedEmitterGetDirect_0();
case 1346202357: return bem_compilerGet_0();
case -1412112913: return bem_buildPathGetDirect_0();
case -226522816: return bem_compilerProfileGet_0();
case 1766926560: return bem_emitLangsGetDirect_0();
case 2145936101: return bem_emitterGet_0();
case -879827763: return bem_emitDebugGetDirect_0();
case 1097742200: return bem_loadIdsGetDirect_0();
case -396057844: return bem_emitFlagsGetDirect_0();
case -652053502: return bem_fieldNamesGet_0();
case 1206731837: return bem_printAstElementsGet_0();
case 1333820549: return bem_emitFileHeaderGetDirect_0();
case -1094204533: return bem_codeGet_0();
case 1292559786: return bem_paramsGet_0();
case 52944109: return bem_estrGet_0();
case 168135582: return bem_create_0();
case 1708338675: return bem_parseTimeGetDirect_0();
case 383815040: return bem_makeArgsGetDirect_0();
case 814334258: return bem_serializeContents_0();
case 473390544: return bem_parseEmitTimeGet_0();
case -1723304555: return bem_emitFlagsGet_0();
case -657619679: return bem_paramsGetDirect_0();
case 313502561: return bem_go_0();
case 650723367: return bem_prepMakeGet_0();
case -1489544626: return bem_includePathGet_0();
case 759496930: return bem_tagGet_0();
case -1843833500: return bem_emitLangsGet_0();
case 146773790: return bem_printStepsGetDirect_0();
case 163483744: return bem_linkLibArgsGet_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case -1443625619: return bem_emitDataGet_0();
case 350691792: return bem_toString_0();
case 517476228: return bem_initLibsGetDirect_0();
case 4682316: return bem_exeNameGet_0();
case 242529535: return bem_makeNameGetDirect_0();
case 379993656: return bem_config_0();
case 1713722746: return bem_deployLibraryGet_0();
case 301691909: return bem_ccObjArgsGetDirect_0();
case -112971286: return bem_platformGet_0();
case 1224510469: return bem_putLineNumbersInTraceGetDirect_0();
case 565661347: return bem_startTimeGetDirect_0();
case -161307577: return bem_emitCommonGetDirect_0();
case 2096109526: return bem_ntypesGet_0();
case -1716720377: return bem_putLineNumbersInTraceGet_0();
case 1159816319: return bem_toBuildGetDirect_0();
case 283904769: return bem_emitCs_0();
case 1430330133: return bem_parseEmitCompileTimeGetDirect_0();
case -610117347: return bem_deployLibraryGetDirect_0();
case 735894078: return bem_emitPathGet_0();
case -308202592: return bem_parseTimeGet_0();
case -587897148: return bem_libNameGetDirect_0();
case 604215051: return bem_outputPlatformGet_0();
case 1286000628: return bem_parseGet_0();
case 962933756: return bem_usedLibrarysStrGetDirect_0();
case 1413268478: return bem_emitCommonGet_0();
case 1550627682: return bem_extIncludesGetDirect_0();
case 330756437: return bem_printAllAstGetDirect_0();
case -1711670377: return bem_hashGet_0();
case 1286334273: return bem_printAstGet_0();
case 1133617313: return bem_emitFileHeaderGet_0();
case -493438343: return bem_exeNameGetDirect_0();
case 1316244237: return bem_printAstGetDirect_0();
case -638024165: return bem_printAstElementsGetDirect_0();
case 264889270: return bem_builtGetDirect_0();
case -1730121479: return bem_buildSucceededGetDirect_0();
case -1746362195: return bem_twtokGet_0();
case -2010739053: return bem_constantsGetDirect_0();
case -710547136: return bem_doMainGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 440130050: return bem_compilerProfileSet_1(bevd_0);
case -213181468: return bem_parseEmitTimeSetDirect_1(bevd_0);
case 608867360: return bem_compilerProfileSetDirect_1(bevd_0);
case -2105425957: return bem_emitLangsSet_1(bevd_0);
case -2130823723: return bem_emitChecksSetDirect_1(bevd_0);
case 2022343736: return bem_toBuildSet_1(bevd_0);
case -177646145: return bem_loadSynsSet_1(bevd_0);
case -1088205397: return bem_includePathSet_1(bevd_0);
case -437878371: return bem_emitDebugSetDirect_1(bevd_0);
case -1085002862: return bem_deployLibrarySetDirect_1(bevd_0);
case 1525894777: return bem_printAllAstSet_1(bevd_0);
case -165117050: return bem_printAstElementsSet_1(bevd_0);
case -869793943: return bem_libNameSetDirect_1(bevd_0);
case -44215448: return bem_nlSet_1(bevd_0);
case -517963933: return bem_emitLangsSetDirect_1(bevd_0);
case -781369504: return bem_makeNameSet_1(bevd_0);
case 11672234: return bem_loadSynsSetDirect_1(bevd_0);
case 622729912: return bem_outputPlatformSetDirect_1(bevd_0);
case 1562457798: return bem_extIncludesSetDirect_1(bevd_0);
case -50510026: return bem_sharedEmitterSet_1(bevd_0);
case -171784913: return bem_usedLibrarysSetDirect_1(bevd_0);
case 1910314196: return bem_deployPathSetDirect_1(bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case -531970776: return bem_emitDataSetDirect_1(bevd_0);
case -1332957925: return bem_extIncludesSet_1(bevd_0);
case 217069292: return bem_doMainSetDirect_1(bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 696339698: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 2099440383: return bem_buildSucceededSet_1(bevd_0);
case 544447770: return bem_deployFilesToSetDirect_1(bevd_0);
case 1964776223: return bem_ownProcessSetDirect_1(bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case -1017200937: return bem_extLibsSetDirect_1(bevd_0);
case -234513709: return bem_buildMessageSet_1(bevd_0);
case 1126339886: return bem_doEmitSet_1(bevd_0);
case 90380088: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case -388711230: return bem_putLineNumbersInTraceSet_1(bevd_0);
case -1206678852: return bem_estrSetDirect_1(bevd_0);
case 682875207: return bem_emitCommonSet_1(bevd_0);
case -1208561992: return bem_usedLibrarysStrSet_1(bevd_0);
case -459298120: return bem_extLinkObjectsSetDirect_1(bevd_0);
case -1904674129: return bem_closeLibrariesSetDirect_1(bevd_0);
case 193476437: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case -1296262998: return bem_parseTimeSetDirect_1(bevd_0);
case -151827807: return bem_genOnlySet_1(bevd_0);
case 1528401767: return bem_buildPathSetDirect_1(bevd_0);
case 1966705515: return bem_readBufferSetDirect_1(bevd_0);
case -914500974: return bem_deployFilesFromSet_1(bevd_0);
case -435665263: return bem_codeSetDirect_1(bevd_0);
case 2118035337: return bem_doMainSet_1(bevd_0);
case 1115351447: return bem_exeNameSet_1(bevd_0);
case 161739674: return bem_emitFlagsSet_1(bevd_0);
case -367706523: return bem_genOnlySetDirect_1(bevd_0);
case -432044958: return bem_parseTimeSet_1(bevd_0);
case -979605925: return bem_paramsSet_1(bevd_0);
case -388353477: return bem_makeSetDirect_1(bevd_0);
case 2078626247: return bem_initLibsSet_1(bevd_0);
case -990353357: return bem_deployLibrarySet_1(bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -911333850: return bem_twtokSetDirect_1(bevd_0);
case -61257713: return bem_emitLibrarySetDirect_1(bevd_0);
case -709720074: return bem_ownProcessSet_1(bevd_0);
case -1170719761: return bem_doParse_1(bevd_0);
case -101247511: return bem_makeArgsSetDirect_1(bevd_0);
case 1715618850: return bem_platformSet_1(bevd_0);
case 652264492: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case -1428942894: return bem_initLibsSetDirect_1(bevd_0);
case -608311856: return bem_lctokSetDirect_1(bevd_0);
case -988392000: return bem_doEmitSetDirect_1(bevd_0);
case 397641796: return bem_codeSet_1(bevd_0);
case 669586018: return bem_extLibsSet_1(bevd_0);
case 1832003183: return bem_singleCCSetDirect_1(bevd_0);
case 1360918131: return bem_buildSyns_1(bevd_0);
case 1424215160: return bem_emitCommonSetDirect_1(bevd_0);
case 276377722: return bem_saveSynsSet_1(bevd_0);
case 1551591044: return bem_deployPathSet_1(bevd_0);
case 424283784: return bem_runArgsSet_1(bevd_0);
case -1818630793: return bem_loadIdsSetDirect_1(bevd_0);
case 702513292: return bem_exeNameSetDirect_1(bevd_0);
case 619924114: return bem_printPlacesSetDirect_1(bevd_0);
case -1890901141: return bem_runSet_1(bevd_0);
case -1685490337: return bem_printAllAstSetDirect_1(bevd_0);
case -1989672097: return bem_libNameSet_1(bevd_0);
case 900867762: return bem_parseSetDirect_1(bevd_0);
case 1290100918: return bem_estrSet_1(bevd_0);
case -1364137655: return bem_startTimeSet_1(bevd_0);
case -864158906: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case 2134695099: return bem_constantsSetDirect_1(bevd_0);
case -839865542: return bem_fromFileSetDirect_1(bevd_0);
case -229469900: return bem_emitFileHeaderSetDirect_1(bevd_0);
case 766000848: return bem_loadIdsSet_1(bevd_0);
case -1427797204: return bem_closeLibrariesSet_1(bevd_0);
case -1026703065: return bem_printPlacesSet_1(bevd_0);
case 447374570: return bem_makeSet_1(bevd_0);
case -385332474: return bem_buildSucceededSetDirect_1(bevd_0);
case -622427905: return bem_lctokSet_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case -164810505: return bem_ntypesSet_1(bevd_0);
case 1678529292: return bem_runArgsSetDirect_1(bevd_0);
case -1539724045: return bem_constantsSet_1(bevd_0);
case -1371598103: return bem_parseSet_1(bevd_0);
case -1236970781: return bem_newlineSet_1(bevd_0);
case -2042363178: return bem_deployFilesToSet_1(bevd_0);
case 1528130367: return bem_deployUsedLibrariesSet_1(bevd_0);
case 608161600: return bem_saveSynsSetDirect_1(bevd_0);
case -1375041858: return bem_printAstSetDirect_1(bevd_0);
case 281159516: return bem_extLinkObjectsSet_1(bevd_0);
case -408062316: return bem_prepMakeSet_1(bevd_0);
case -922580845: return bem_builtSet_1(bevd_0);
case -746449289: return bem_readBufferSet_1(bevd_0);
case -1209889694: return bem_paramsSetDirect_1(bevd_0);
case -1806111134: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case 1035813320: return bem_emitPathSetDirect_1(bevd_0);
case -429306832: return bem_startTimeSetDirect_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case -696186848: return bem_printAstElementsSetDirect_1(bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case 867713505: return bem_emitPathSet_1(bevd_0);
case -1563457004: return bem_buildMessageSetDirect_1(bevd_0);
case 917312504: return bem_linkLibArgsSet_1(bevd_0);
case 1050781695: return bem_emitDataSet_1(bevd_0);
case 1502748173: return bem_usedLibrarysSet_1(bevd_0);
case -65125920: return bem_ccObjArgsSet_1(bevd_0);
case 1709906978: return bem_platformSetDirect_1(bevd_0);
case -1999756337: return bem_deployFilesFromSetDirect_1(bevd_0);
case 548465202: return bem_saveIdsSet_1(bevd_0);
case -107186260: return bem_compilerSet_1(bevd_0);
case 1495154266: return bem_emitLibrarySet_1(bevd_0);
case -226086502: return bem_mainNameSetDirect_1(bevd_0);
case 2039168622: return bem_closeLibrariesStrSet_1(bevd_0);
case 1255837807: return bem_emitFileHeaderSet_1(bevd_0);
case -1657297531: return bem_runSetDirect_1(bevd_0);
case -61063297: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 1088117380: return bem_twtokSet_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case -494530191: return bem_emitDebugSet_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case 1978874515: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case 1535526549: return bem_makeArgsSet_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -467488964: return bem_parseEmitTimeSet_1(bevd_0);
case -356128980: return bem_ccObjArgsSetDirect_1(bevd_0);
case 1506571482: return bem_usedLibrarysStrSetDirect_1(bevd_0);
case 1972687595: return bem_fromFileSet_1(bevd_0);
case -1668226304: return bem_emitFlagsSetDirect_1(bevd_0);
case 1078689546: return bem_printStepsSetDirect_1(bevd_0);
case 111038744: return bem_emitChecksSet_1(bevd_0);
case 1866182938: return bem_compilerSetDirect_1(bevd_0);
case -52239134: return bem_sharedEmitterSetDirect_1(bevd_0);
case 877601075: return bem_printStepsSet_1(bevd_0);
case -1214541120: return bem_argsSet_1(bevd_0);
case 311899970: return bem_outputPlatformSet_1(bevd_0);
case 586283359: return bem_nlSetDirect_1(bevd_0);
case -334724974: return bem_newlineSetDirect_1(bevd_0);
case 80595314: return bem_includePathSetDirect_1(bevd_0);
case -1297440630: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case 55567749: return bem_printAstSet_1(bevd_0);
case -369750415: return bem_makeNameSetDirect_1(bevd_0);
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1532281234: return bem_singleCCSet_1(bevd_0);
case -1038378925: return bem_saveIdsSetDirect_1(bevd_0);
case -1819563968: return bem_mainNameSet_1(bevd_0);
case -1458431940: return bem_ntypesSetDirect_1(bevd_0);
case 1025508811: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case 1827485140: return bem_argsSetDirect_1(bevd_0);
case 1089971679: return bem_linkLibArgsSetDirect_1(bevd_0);
case 1151278052: return bem_toBuildSetDirect_1(bevd_0);
case -849876454: return bem_getSynNp_1(bevd_0);
case 956637682: return bem_buildPathSet_1(bevd_0);
case 1155231730: return bem_prepMakeSetDirect_1(bevd_0);
case 262952440: return bem_builtSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -555436713: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1573360483: return bem_buildLiteral_2(bevd_0, bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 344109207: return bem_getSyn_2(bevd_0, bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
}
