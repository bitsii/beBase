namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_12, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_60, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_63, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_68, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x63,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_70, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x73,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_71, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_105, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_106, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_107 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_107, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_108 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_108, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_109 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_109, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_110 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_110, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_111 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_111, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_112 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_112, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_113 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_52 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_113, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_114 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_115 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_116 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static new BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static new BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_singleCC = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_saveSyns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_saveIds = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 99 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 99 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 99 */
 else  /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 99 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 100 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 118 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 118 */
 else  /* Line: 118 */ {
break;
} /* Line: 118 */
} /* Line: 118 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 127 */ {
bem_config_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 131 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1169011989);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 136 */
if (bevp_printSteps.bevi_bool) /* Line: 138 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 138 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 138 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 139 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(-1955516717);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-1663786357, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 145 */ {
} /* Line: 145 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_120_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_126_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_129_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpany_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_5_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_6_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 156 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 156 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(871811179);
bevt_9_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 157 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpany_phold);
} /* Line: 159 */
} /* Line: 157 */
 else  /* Line: 156 */ {
break;
} /* Line: 156 */
} /* Line: 156 */
} /* Line: 156 */
bevt_13_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_nameGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_equals_1(bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 164 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 165 */
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_15_tmpany_phold = bevp_params.bem_get_1(bevt_16_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_17_tmpany_phold = bevp_params.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 168 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_19_tmpany_phold = bevp_params.bem_get_1(bevt_20_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_firstGet_0();
} /* Line: 169 */
 else  /* Line: 170 */ {
bevp_exeName = bevp_libName;
} /* Line: 171 */
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_23_tmpany_phold = bevp_params.bem_get_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_firstGet_0();
bevt_21_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpany_phold);
bevp_buildPath = bevt_21_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_29_tmpany_phold = bevp_params.bem_get_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_firstGet_0();
bevt_27_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpany_phold);
bevp_includePath = bevt_27_tmpany_phold.bem_pathGet_0();
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_36_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_nameGet_0();
bevt_33_tmpany_phold = bevp_params.bem_get_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpany_phold );
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_40_tmpany_phold = bevp_platform.bemd_0(-1955516717);
bevt_38_tmpany_phold = bevp_params.bem_get_2(bevt_39_tmpany_phold, (BEC_2_4_6_TextString) bevt_40_tmpany_phold );
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpany_phold );
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_42_tmpany_phold = bevp_params.bem_get_2(bevt_43_tmpany_phold, bevt_44_tmpany_phold);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_26));
bevt_46_tmpany_phold = bevp_params.bem_get_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpany_phold);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_28));
bevt_50_tmpany_phold = bevp_params.bem_get_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_29));
bevp_loadSyns = bevp_params.bem_get_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_30));
bevp_initLibs = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_31));
bevt_55_tmpany_phold = bevp_params.bem_get_1(bevt_56_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_55_tmpany_phold.bem_firstGet_0();
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_32));
bevt_57_tmpany_phold = bevp_params.bem_get_1(bevt_58_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_57_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_59_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 188 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 189 */
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_61_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193 */
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_63_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 196 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_65_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_67_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 204 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_69_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_71_tmpany_phold);
if (bevp_extLibs == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_73_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_74_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_75_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221 */
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_77_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-2119065265);
} /* Line: 225 */
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_79_tmpany_phold);
if (bevp_runArgs == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-2119065265);
} /* Line: 229 */
 else  /* Line: 230 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 231 */
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_44));
bevt_82_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevt_84_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_86_tmpany_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_87_tmpany_phold);
if (bevl_pacm == null) {
bevt_88_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_90_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_90_tmpany_phold.bevi_bool) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 239 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 240 */ {
bevt_91_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_91_tmpany_phold).bevi_bool) /* Line: 240 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 241 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 240 */
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_53));
bevt_97_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevp_emitLangs = bevp_params.bem_get_1(bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_55));
bevp_emitFlags = bevp_params.bem_get_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_100_tmpany_phold = bevp_params.bem_get_2(bevt_101_tmpany_phold, bevt_102_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_100_tmpany_phold.bem_firstGet_0();
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_59));
bevt_103_tmpany_phold = bevp_params.bem_get_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_103_tmpany_phold.bem_firstGet_0();
bevt_108_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bem_add_1(bevp_makeName);
bevt_109_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_106_tmpany_phold = bevp_params.bem_get_2(bevt_107_tmpany_phold, bevt_109_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_106_tmpany_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_110_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_110_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_110_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 262 */
 else  /* Line: 263 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_62));
} /* Line: 264 */
bevt_113_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_112_tmpany_phold = bevl_outLang.bem_add_1(bevt_113_tmpany_phold);
bevt_114_tmpany_phold = bevp_platform.bemd_0(-1955516717);
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bem_add_1(bevt_114_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_111_tmpany_phold);
if (bevl_platformSources == null) {
bevt_115_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_115_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_116_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_116_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 273 */
bevt_118_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_117_tmpany_phold = bevl_outLang.bem_add_1(bevt_118_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_117_tmpany_phold);
if (bevl_langSources == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_120_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_120_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 278 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_121_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpany_loop = bevt_121_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 282 */ {
bevt_122_tmpany_phold = bevt_2_tmpany_loop.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_122_tmpany_phold).bevi_bool) /* Line: 282 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(871811179);
bevt_123_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_123_tmpany_phold);
} /* Line: 283 */
 else  /* Line: 282 */ {
break;
} /* Line: 282 */
} /* Line: 282 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(-1542140304);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_126_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_125_tmpany_phold = bevt_126_tmpany_phold.bem_existsGet_0();
if (bevt_125_tmpany_phold.bevi_bool) {
bevt_124_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_124_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_124_tmpany_phold.bevi_bool) /* Line: 290 */ {
bevt_127_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_127_tmpany_phold.bem_makeDirs_0();
} /* Line: 291 */
if (bevp_emitFileHeader == null) {
bevt_128_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_128_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_128_tmpany_phold.bevi_bool) /* Line: 293 */ {
bevt_129_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_129_tmpany_phold.bem_readerGet_0();
bevt_130_tmpany_phold = bevl_emr.bemd_0(344054741);
bevp_emitFileHeader = bevt_130_tmpany_phold.bemd_0(1994301631);
bevl_emr.bemd_0(-191741087);
} /* Line: 296 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(1833892349, bevp_nl);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1833892349, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(1833892349, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(1833892349, bevp_nl);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(1833892349, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(1833892349, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 310 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 310 */ {
bevl_clnode = bevl_ci.bemd_0(871811179);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(1615220181);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(1409384079);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(1615220181);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1481995669);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1169011989);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(1615220181);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1481995669);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(1169011989);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 315 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 316 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 316 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 317 */
 else  /* Line: 316 */ {
break;
} /* Line: 316 */
} /* Line: 316 */
} /* Line: 316 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(1615220181);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(1481995669);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1169011989);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 322 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 323 */
 else  /* Line: 322 */ {
break;
} /* Line: 322 */
} /* Line: 322 */
} /* Line: 322 */
} /* Line: 321 */
} /* Line: 312 */
 else  /* Line: 310 */ {
break;
} /* Line: 310 */
} /* Line: 310 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 328 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 328 */ {
bevl_clnode = bevl_ci.bemd_0(871811179);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(1615220181);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(1615220181);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(1481995669);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(1169011989);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(-1511219994, bevt_26_tmpany_phold);
} /* Line: 330 */
 else  /* Line: 328 */ {
break;
} /* Line: 328 */
} /* Line: 328 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 341 */ {
return bevp_emitCommon;
} /* Line: 342 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 347 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 350 */
 else  /* Line: 349 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 351 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 352 */
 else  /* Line: 349 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 353 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 354 */
 else  /* Line: 349 */ {
bevt_9_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_8_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 355 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 356 */
 else  /* Line: 349 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_10_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_11_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildSWEmitter()).bem_new_1(this);
} /* Line: 358 */
 else  /* Line: 359 */ {
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_12_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_13_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_12_tmpany_phold);
} /* Line: 360 */
} /* Line: 349 */
} /* Line: 349 */
} /* Line: 349 */
} /* Line: 349 */
return bevp_emitCommon;
} /* Line: 362 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = (BEC_2_4_8_TimeInterval) bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(344054741);
bevt_5_tmpany_phold = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 385 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 386 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 386 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 387 */
 else  /* Line: 386 */ {
break;
} /* Line: 386 */
} /* Line: 386 */
} /* Line: 386 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 391 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 394 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 395 */
} /* Line: 394 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(-1847620794);
while (true)
 /* Line: 400 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 400 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(871811179);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 401 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 404 */
} /* Line: 401 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(-1847620794);
while (true)
 /* Line: 407 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 407 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(871811179);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 408 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(945902136);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 412 */
} /* Line: 408 */
 else  /* Line: 407 */ {
break;
} /* Line: 407 */
} /* Line: 407 */
if (bevp_parse.bevi_bool) /* Line: 415 */ {
bevl_built = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 418 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 418 */ {
bevl_tb = bevl_i.bemd_0(871811179);
bevt_20_tmpany_phold = bevl_tb.bemd_0(1169011989);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 421 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(1169011989);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 423 */
} /* Line: 421 */
 else  /* Line: 418 */ {
break;
} /* Line: 418 */
} /* Line: 418 */
bem_buildSyns_1(bevl_em);
} /* Line: 426 */
bevt_23_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 432 */ {
bevt_26_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 441 */
if (bevp_doEmit.bevi_bool) /* Line: 443 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(-689744713);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 447 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 447 */ {
bevl_clnode = bevl_ci.bemd_0(871811179);
bevl_em.bemd_1(-948872871, bevl_clnode);
} /* Line: 449 */
 else  /* Line: 447 */ {
break;
} /* Line: 447 */
} /* Line: 447 */
bevl_em.bemd_0(817325037);
bevl_em.bemd_0(-1272194809);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 453 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 453 */ {
bevl_clnode = bevl_ci.bemd_0(871811179);
bevl_em.bemd_1(-827469129, bevl_clnode);
} /* Line: 455 */
 else  /* Line: 453 */ {
break;
} /* Line: 453 */
} /* Line: 453 */
} /* Line: 453 */
bevt_44_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 460 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 461 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 464 */ {
bevl_em.bemd_1(-1756037107, bevp_deployLibrary);
} /* Line: 466 */
if (bevp_make.bevi_bool) /* Line: 469 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 470 */ {
bevl_em.bemd_1(1583679370, bevp_deployLibrary);
bevl_em.bemd_1(1392573096, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 473 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 474 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 474 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(-689744713);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(-416782711);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(863441180);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(-82951644);
bevl_cpTo.bemd_1(1461532393, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(-299058493);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(801396020);
if (((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 478 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(-299058493);
bevt_58_tmpany_phold.bemd_0(-1773812551);
} /* Line: 479 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(-299058493);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(801396020);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(-31622470);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 481 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(-299058493);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(-299058493);
bevl_em.bemd_2(-1015003483, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 482 */
} /* Line: 481 */
 else  /* Line: 474 */ {
break;
} /* Line: 474 */
} /* Line: 474 */
} /* Line: 474 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 489 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 489 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 489 */
 else  /* Line: 489 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 489 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(871811179);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(871811179);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(-299058493);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(801396020);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 493 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(-299058493);
bevt_76_tmpany_phold.bemd_0(-1773812551);
} /* Line: 494 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(-299058493);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(801396020);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(-31622470);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 496 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(-299058493);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(-299058493);
bevl_em.bemd_2(-1015003483, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 497 */
} /* Line: 496 */
 else  /* Line: 489 */ {
break;
} /* Line: 489 */
} /* Line: 489 */
} /* Line: 489 */
} /* Line: 470 */
bevt_83_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 504 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 505 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 507 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 508 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 510 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 511 */
if (bevp_run.bevi_bool) /* Line: 514 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(-335025264, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 518 */
bevt_98_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 524 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 524 */ {
bevl_kls = bevl_ci.bemd_0(871811179);
bevt_2_tmpany_phold = bevl_kls.bemd_0(1615220181);
bevt_2_tmpany_phold.bemd_1(902288600, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(902288600, bevp_libName);
} /* Line: 528 */
 else  /* Line: 524 */ {
break;
} /* Line: 524 */
} /* Line: 524 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 530 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 530 */ {
bevl_kls = bevl_ci.bemd_0(871811179);
bevt_5_tmpany_phold = bevl_kls.bemd_0(1615220181);
bevl_syn = bevt_5_tmpany_phold.bemd_0(-1321303863);
bevl_syn.bemd_2(711952271, this, bevl_kls);
bevl_syn.bemd_1(1196049639, this);
} /* Line: 534 */
 else  /* Line: 530 */ {
break;
} /* Line: 530 */
} /* Line: 530 */
bevt_6_tmpany_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(1615220181);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-1321303863);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 540 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(1615220181);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-1321303863);
return bevt_3_tmpany_phold;
} /* Line: 541 */
bevt_5_tmpany_phold = beva_klass.bemd_0(1615220181);
bevt_5_tmpany_phold.bemd_1(902288600, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(1615220181);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1472933833);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 544 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 545 */
 else  /* Line: 546 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(1615220181);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1472933833);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1169011989);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 549 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(1615220181);
bevt_14_tmpany_phold.bemd_1(902288600, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 551 */
 else  /* Line: 552 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(1615220181);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1472933833);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 555 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 557 */
bevt_17_tmpany_phold = beva_klass.bemd_0(1615220181);
bevt_17_tmpany_phold.bemd_1(-1964101410, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(1615220181);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(1481995669);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1169011989);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(1169011989);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 567 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 568 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(-589620867, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 583 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 584 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 597 */ {
if (bevp_printSteps.bevi_bool) /* Line: 598 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 598 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 598 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 598 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 598 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 598 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_5_tmpany_phold = beva_toParse.bemd_0(1169011989);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 599 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(-299058493);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-1690988625);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(344054741);
bevl_src = bevt_6_tmpany_phold.bemd_1(1553290012, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(-299058493);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-1690988625);
bevt_9_tmpany_phold.bemd_0(-191741087);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 610 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 611 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(785007423);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 614 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_14_tmpany_phold);
} /* Line: 616 */
if (bevp_printSteps.bevi_bool) /* Line: 619 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 620 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-1761507357, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 623 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_18_tmpany_phold);
} /* Line: 625 */
if (bevp_printSteps.bevi_bool) /* Line: 627 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 628 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-1761507357, bevt_20_tmpany_phold);
bevl_trans.bemd_0(-334335818);
if (bevp_printAllAst.bevi_bool) /* Line: 633 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_22_tmpany_phold);
} /* Line: 635 */
if (bevp_printSteps.bevi_bool) /* Line: 638 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 639 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-1761507357, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 642 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_26_tmpany_phold);
} /* Line: 644 */
if (bevp_printSteps.bevi_bool) /* Line: 647 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 648 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-1761507357, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 651 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_30_tmpany_phold);
} /* Line: 653 */
if (bevp_printSteps.bevi_bool) /* Line: 656 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 657 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-1761507357, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 660 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_34_tmpany_phold);
} /* Line: 662 */
if (bevp_printSteps.bevi_bool) /* Line: 665 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 666 */
bevt_36_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-1761507357, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 669 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_38_tmpany_phold);
} /* Line: 671 */
if (bevp_printSteps.bevi_bool) /* Line: 674 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 675 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-1761507357, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 678 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_42_tmpany_phold);
} /* Line: 680 */
if (bevp_printSteps.bevi_bool) /* Line: 683 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 684 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-1761507357, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 687 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_46_tmpany_phold);
} /* Line: 689 */
if (bevp_printSteps.bevi_bool) /* Line: 692 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 693 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-1761507357, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 696 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_50_tmpany_phold);
} /* Line: 698 */
if (bevp_printSteps.bevi_bool) /* Line: 700 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 701 */
bevt_52_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-1761507357, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 704 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_54_tmpany_phold);
} /* Line: 706 */
if (bevp_printSteps.bevi_bool) /* Line: 709 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_51;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 711 */
bevt_57_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-1761507357, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 714 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 714 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 714 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 714 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 714 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 714 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_52;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-1761507357, bevt_59_tmpany_phold);
} /* Line: 716 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 718 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(1070651373);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 718 */ {
bevl_clnode = bevl_ci.bemd_0(871811179);
bevl_tunode = bevl_clnode.bemd_0(-929115817);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(327880571, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(1615220181);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(2009049308);
bevl_ntt.bemd_1(367119705, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(1957208028, bevl_ntt);
bevl_clnode.bemd_0(-1773812551);
bevl_ntunode.bemd_1(-381950064, bevl_clnode);
bevl_ntunode.bemd_1(1690862786, bevl_clnode);
} /* Line: 729 */
 else  /* Line: 718 */ {
break;
} /* Line: 718 */
} /* Line: 718 */
} /* Line: 718 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(-866455115);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(1807475315);
bevl_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 739 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 739 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(1957208028, bevt_2_tmpany_phold);
bevl_node.bemd_1(1190394275, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(1615220181);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-1663786357, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 743 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 744 */
bevt_6_tmpany_phold = bevl_node.bemd_0(1615220181);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(1449183263, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 746 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(-1746040880, beva_parnode);
} /* Line: 748 */
} /* Line: 746 */
 else  /* Line: 739 */ {
break;
} /* Line: 739 */
} /* Line: 739 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(1092282631, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(327880571, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(1957208028, bevl_nlnp);
bevl_nlnpn.bemd_1(1690862786, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_114));
bevl_nlc.bemd_1(-930181740, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-869554885, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-1208656391, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-2091271519, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1890948745, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(1615220181);
bevl_nlc.bemd_1(102628971, bevt_11_tmpany_phold);
beva_node.bemd_1(-381950064, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(327880571, bevt_12_tmpany_phold);
beva_node.bemd_1(1957208028, bevl_nlc);
bevl_nlnpn.bemd_0(1444826858);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_115));
bevt_13_tmpany_phold = beva_tName.bemd_1(-1663786357, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 778 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 778 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_116));
bevt_15_tmpany_phold = beva_tName.bemd_1(-1663786357, bevt_16_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 778 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 778 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 778 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 778 */ {
bevl_pn = beva_node.bemd_0(780371090);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 780 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-1480018445);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(-1663786357, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 780 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-1480018445);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(-1663786357, bevt_23_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 780 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 780 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 780 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 780 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 780 */
 else  /* Line: 780 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 780 */ {
bevl_pn2 = bevl_pn.bemd_0(780371090);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 782 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 782 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-1480018445);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(1449183263, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 782 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-1480018445);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(1449183263, bevt_30_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 782 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 782 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 782 */
 else  /* Line: 782 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 782 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-1480018445);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(1449183263, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 782 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 782 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 782 */
 else  /* Line: 782 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 782 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-1480018445);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(1449183263, bevt_36_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 782 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 782 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 782 */
 else  /* Line: 782 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 782 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 782 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 782 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 782 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(1615220181);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(1719827258);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(1833892349, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(102628971, bevt_37_tmpany_phold);
bevl_pn.bemd_0(-1773812551);
} /* Line: 789 */
} /* Line: 782 */
} /* Line: 780 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGetDirect_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGetDirect_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGetDirect_0() {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGetDirect_0() {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGetDirect_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGetDirect_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGetDirect_0() {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGetDirect_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGetDirect_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGetDirect_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGetDirect_0() {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGetDirect_0() {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGetDirect_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGetDirect_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGetDirect_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGetDirect_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGetDirect_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGetDirect_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGetDirect_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGetDirect_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {52, 54, 55, 56, 57, 59, 60, 61, 62, 63, 64, 65, 69, 71, 72, 73, 74, 74, 77, 80, 81, 82, 88, 89, 90, 91, 92, 92, 99, 99, 99, 99, 0, 99, 99, 0, 0, 0, 0, 0, 100, 100, 102, 102, 106, 106, 106, 106, 110, 110, 111, 111, 111, 115, 116, 117, 117, 117, 117, 117, 118, 118, 118, 119, 118, 121, 125, 126, 128, 129, 130, 131, 133, 134, 135, 135, 136, 0, 0, 0, 139, 141, 145, 145, 145, 147, 152, 154, 155, 155, 155, 156, 156, 0, 156, 156, 157, 157, 157, 158, 159, 159, 164, 164, 164, 164, 165, 167, 167, 167, 168, 168, 169, 169, 169, 171, 173, 173, 173, 173, 173, 173, 174, 175, 175, 176, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 183, 183, 185, 185, 185, 186, 186, 186, 187, 187, 188, 188, 189, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 233, 233, 233, 234, 234, 234, 235, 235, 236, 236, 237, 238, 238, 239, 239, 239, 239, 239, 0, 0, 0, 240, 0, 240, 240, 241, 244, 244, 245, 245, 246, 246, 247, 247, 248, 248, 248, 249, 249, 250, 250, 251, 251, 251, 251, 252, 252, 252, 252, 253, 253, 253, 253, 253, 254, 255, 256, 257, 258, 261, 261, 262, 264, 271, 271, 271, 271, 271, 272, 272, 273, 273, 276, 276, 276, 277, 277, 278, 278, 281, 282, 282, 0, 282, 282, 283, 283, 285, 286, 287, 289, 290, 290, 290, 290, 291, 291, 293, 293, 294, 294, 295, 295, 296, 302, 303, 303, 303, 303, 303, 304, 304, 304, 304, 304, 305, 309, 310, 310, 310, 311, 312, 312, 312, 312, 313, 313, 313, 313, 314, 314, 314, 314, 314, 315, 315, 316, 0, 316, 316, 317, 320, 320, 320, 320, 320, 321, 321, 322, 0, 322, 322, 323, 328, 328, 328, 329, 330, 330, 330, 330, 330, 330, 337, 337, 341, 341, 342, 347, 347, 348, 349, 349, 350, 351, 351, 352, 353, 353, 354, 355, 355, 356, 357, 357, 358, 360, 360, 360, 362, 364, 368, 370, 370, 370, 371, 371, 372, 372, 372, 373, 373, 374, 375, 375, 376, 376, 376, 377, 377, 377, 383, 383, 384, 385, 385, 386, 0, 386, 386, 387, 390, 391, 391, 392, 393, 395, 395, 395, 398, 400, 0, 400, 400, 401, 401, 401, 402, 403, 404, 407, 0, 407, 407, 408, 408, 408, 409, 410, 411, 412, 412, 417, 418, 418, 419, 421, 421, 422, 422, 423, 426, 429, 429, 429, 432, 432, 432, 434, 434, 435, 435, 436, 436, 436, 437, 437, 437, 438, 438, 438, 439, 439, 439, 440, 440, 440, 441, 441, 444, 445, 447, 447, 447, 448, 449, 451, 452, 453, 453, 453, 454, 455, 459, 459, 459, 460, 460, 461, 461, 461, 463, 463, 463, 466, 470, 470, 471, 472, 474, 0, 474, 474, 475, 475, 476, 476, 477, 477, 477, 478, 478, 479, 479, 481, 481, 481, 482, 482, 482, 486, 487, 489, 489, 0, 0, 0, 490, 490, 491, 491, 491, 491, 491, 491, 491, 491, 493, 493, 494, 494, 496, 496, 496, 497, 497, 497, 502, 502, 502, 504, 504, 505, 505, 505, 507, 507, 508, 508, 508, 510, 510, 511, 511, 511, 515, 515, 516, 517, 517, 517, 517, 517, 518, 520, 520, 524, 524, 524, 525, 526, 526, 527, 528, 530, 530, 530, 531, 532, 532, 533, 534, 536, 536, 540, 540, 540, 540, 541, 541, 541, 543, 543, 544, 544, 544, 544, 545, 547, 547, 547, 547, 547, 549, 549, 550, 550, 551, 555, 555, 555, 557, 559, 559, 560, 560, 560, 560, 561, 565, 566, 566, 567, 567, 568, 574, 574, 575, 576, 583, 583, 584, 586, 591, 592, 593, 594, 595, 596, 596, 0, 0, 0, 599, 599, 599, 599, 601, 603, 603, 603, 603, 604, 604, 604, 607, 611, 611, 613, 613, 615, 615, 616, 616, 620, 620, 622, 622, 624, 624, 625, 625, 628, 628, 631, 631, 632, 634, 634, 635, 635, 639, 639, 641, 641, 643, 643, 644, 644, 648, 648, 650, 650, 652, 652, 653, 653, 657, 657, 659, 659, 661, 661, 662, 662, 666, 666, 668, 668, 670, 670, 671, 671, 675, 675, 677, 677, 679, 679, 680, 680, 684, 684, 686, 686, 688, 688, 689, 689, 693, 693, 695, 695, 697, 697, 698, 698, 701, 701, 703, 703, 705, 705, 706, 706, 710, 710, 711, 711, 713, 713, 0, 0, 0, 715, 715, 716, 716, 718, 718, 718, 719, 721, 722, 723, 723, 724, 725, 725, 725, 726, 727, 728, 729, 735, 736, 737, 738, 738, 739, 739, 740, 741, 741, 742, 743, 743, 744, 746, 746, 747, 748, 755, 756, 758, 759, 759, 760, 761, 763, 764, 764, 765, 765, 766, 766, 767, 767, 768, 768, 769, 769, 771, 773, 773, 774, 776, 778, 778, 0, 778, 778, 0, 0, 779, 780, 780, 780, 780, 780, 0, 780, 780, 780, 0, 0, 0, 0, 0, 781, 782, 782, 0, 782, 782, 782, 782, 782, 782, 0, 0, 0, 782, 782, 782, 0, 0, 0, 782, 782, 782, 0, 0, 0, 0, 0, 788, 788, 788, 788, 789, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 297, 302, 303, 304, 306, 309, 310, 312, 315, 319, 322, 326, 329, 330, 332, 333, 339, 340, 341, 342, 349, 350, 351, 352, 353, 365, 366, 367, 368, 369, 370, 371, 372, 375, 380, 381, 382, 388, 396, 397, 399, 400, 401, 402, 406, 407, 408, 409, 410, 413, 417, 420, 424, 426, 432, 433, 434, 437, 580, 581, 582, 583, 588, 589, 590, 590, 593, 595, 596, 597, 602, 603, 604, 605, 613, 614, 615, 616, 618, 620, 621, 622, 623, 624, 626, 627, 628, 631, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 691, 692, 694, 695, 696, 701, 702, 704, 705, 706, 711, 712, 714, 715, 716, 721, 722, 724, 725, 726, 731, 732, 734, 735, 736, 741, 742, 744, 745, 746, 751, 752, 754, 755, 756, 761, 762, 764, 765, 766, 771, 772, 774, 775, 776, 781, 782, 784, 785, 786, 791, 792, 795, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 815, 816, 817, 822, 823, 826, 830, 833, 833, 836, 838, 839, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 884, 885, 888, 890, 891, 892, 893, 894, 895, 900, 901, 902, 904, 905, 906, 907, 912, 913, 914, 916, 917, 918, 918, 921, 923, 924, 925, 931, 932, 933, 934, 935, 936, 937, 942, 943, 944, 946, 951, 952, 953, 954, 955, 956, 970, 971, 972, 973, 974, 975, 976, 977, 978, 979, 980, 981, 1021, 1022, 1023, 1026, 1028, 1029, 1030, 1031, 1032, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1048, 1049, 1049, 1052, 1054, 1055, 1062, 1063, 1064, 1065, 1066, 1067, 1072, 1073, 1073, 1076, 1078, 1079, 1092, 1093, 1096, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1114, 1115, 1133, 1138, 1139, 1141, 1146, 1147, 1148, 1149, 1151, 1154, 1155, 1157, 1160, 1161, 1163, 1166, 1167, 1169, 1172, 1173, 1175, 1178, 1179, 1180, 1186, 1188, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1347, 1348, 1349, 1350, 1355, 1356, 1356, 1359, 1361, 1362, 1369, 1370, 1375, 1376, 1377, 1379, 1380, 1381, 1384, 1385, 1385, 1388, 1390, 1391, 1392, 1397, 1398, 1399, 1400, 1407, 1407, 1410, 1412, 1413, 1414, 1419, 1420, 1421, 1422, 1423, 1424, 1432, 1433, 1436, 1438, 1439, 1440, 1442, 1443, 1444, 1451, 1453, 1454, 1455, 1456, 1457, 1462, 1463, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1473, 1474, 1475, 1476, 1477, 1478, 1479, 1480, 1481, 1482, 1483, 1486, 1487, 1488, 1489, 1492, 1494, 1495, 1501, 1502, 1503, 1504, 1507, 1509, 1510, 1517, 1518, 1519, 1520, 1525, 1526, 1527, 1528, 1530, 1531, 1532, 1534, 1537, 1542, 1543, 1544, 1546, 1546, 1549, 1551, 1552, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1562, 1563, 1565, 1566, 1567, 1569, 1570, 1571, 1579, 1580, 1583, 1585, 1587, 1590, 1594, 1597, 1598, 1599, 1600, 1601, 1602, 1603, 1604, 1605, 1606, 1607, 1608, 1610, 1611, 1613, 1614, 1615, 1617, 1618, 1619, 1628, 1629, 1630, 1631, 1636, 1637, 1638, 1639, 1641, 1646, 1647, 1648, 1649, 1651, 1656, 1657, 1658, 1659, 1662, 1663, 1664, 1665, 1666, 1667, 1668, 1669, 1670, 1672, 1673, 1686, 1687, 1690, 1692, 1693, 1694, 1695, 1696, 1702, 1703, 1706, 1708, 1709, 1710, 1711, 1712, 1718, 1719, 1747, 1748, 1749, 1754, 1755, 1756, 1757, 1759, 1760, 1761, 1762, 1763, 1768, 1769, 1772, 1773, 1774, 1775, 1776, 1777, 1782, 1783, 1784, 1785, 1788, 1789, 1790, 1792, 1794, 1795, 1796, 1797, 1798, 1799, 1800, 1808, 1809, 1810, 1811, 1816, 1817, 1819, 1820, 1821, 1822, 1826, 1831, 1832, 1834, 1913, 1914, 1915, 1916, 1917, 1918, 1919, 1922, 1926, 1929, 1933, 1934, 1935, 1936, 1938, 1939, 1940, 1941, 1942, 1943, 1944, 1945, 1946, 1948, 1949, 1951, 1952, 1954, 1955, 1956, 1957, 1960, 1961, 1963, 1964, 1966, 1967, 1968, 1969, 1972, 1973, 1975, 1976, 1977, 1979, 1980, 1981, 1982, 1985, 1986, 1988, 1989, 1991, 1992, 1993, 1994, 1997, 1998, 2000, 2001, 2003, 2004, 2005, 2006, 2009, 2010, 2012, 2013, 2015, 2016, 2017, 2018, 2021, 2022, 2024, 2025, 2027, 2028, 2029, 2030, 2033, 2034, 2036, 2037, 2039, 2040, 2041, 2042, 2045, 2046, 2048, 2049, 2051, 2052, 2053, 2054, 2057, 2058, 2060, 2061, 2063, 2064, 2065, 2066, 2069, 2070, 2072, 2073, 2075, 2076, 2077, 2078, 2081, 2082, 2083, 2084, 2086, 2087, 2089, 2093, 2096, 2100, 2101, 2102, 2103, 2105, 2106, 2109, 2111, 2112, 2113, 2114, 2115, 2116, 2117, 2118, 2119, 2120, 2121, 2122, 2123, 2145, 2146, 2147, 2148, 2149, 2150, 2153, 2155, 2156, 2157, 2158, 2159, 2160, 2162, 2164, 2165, 2167, 2168, 2223, 2224, 2225, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2233, 2234, 2235, 2236, 2237, 2238, 2239, 2240, 2241, 2242, 2243, 2244, 2245, 2246, 2247, 2248, 2249, 2251, 2254, 2255, 2257, 2260, 2264, 2265, 2270, 2271, 2272, 2273, 2275, 2278, 2279, 2280, 2282, 2285, 2289, 2292, 2296, 2299, 2300, 2305, 2306, 2309, 2310, 2311, 2313, 2314, 2315, 2317, 2320, 2324, 2327, 2328, 2329, 2331, 2334, 2338, 2341, 2342, 2343, 2345, 2348, 2352, 2355, 2358, 2362, 2363, 2364, 2365, 2366, 2373, 2376, 2379, 2383, 2387, 2390, 2393, 2397, 2401, 2404, 2407, 2411, 2415, 2418, 2421, 2425, 2429, 2432, 2435, 2439, 2443, 2446, 2449, 2453, 2457, 2460, 2463, 2467, 2471, 2474, 2477, 2481, 2485, 2488, 2491, 2495, 2499, 2502, 2505, 2509, 2513, 2516, 2519, 2523, 2527, 2530, 2533, 2537, 2541, 2544, 2547, 2551, 2555, 2558, 2561, 2565, 2569, 2572, 2575, 2579, 2583, 2586, 2589, 2593, 2597, 2600, 2603, 2607, 2611, 2614, 2617, 2621, 2625, 2628, 2631, 2635, 2639, 2642, 2645, 2649, 2653, 2656, 2659, 2663, 2667, 2670, 2673, 2677, 2681, 2684, 2687, 2691, 2695, 2698, 2701, 2705, 2709, 2712, 2715, 2719, 2723, 2726, 2729, 2733, 2737, 2740, 2743, 2747, 2751, 2754, 2757, 2761, 2765, 2768, 2771, 2775, 2779, 2782, 2785, 2789, 2793, 2796, 2799, 2803, 2807, 2810, 2813, 2817, 2821, 2824, 2827, 2831, 2835, 2838, 2841, 2845, 2849, 2852, 2855, 2859, 2863, 2866, 2869, 2873, 2877, 2880, 2883, 2887, 2891, 2894, 2897, 2901, 2905, 2908, 2911, 2915, 2919, 2922, 2925, 2929, 2933, 2936, 2939, 2943, 2947, 2950, 2953, 2957, 2961, 2964, 2967, 2971, 2975, 2978, 2981, 2985, 2989, 2992, 2995, 2999, 3003, 3006, 3009, 3013, 3017, 3020, 3023, 3027, 3031, 3034, 3037, 3041, 3045, 3048, 3051, 3055, 3059, 3062, 3065, 3069, 3073, 3076, 3079, 3083, 3087, 3090, 3093, 3097, 3101, 3104, 3107, 3111, 3115, 3118, 3121, 3125, 3129, 3132, 3135, 3139, 3143, 3146, 3149, 3153, 3157, 3160, 3163, 3167, 3171, 3174, 3177, 3181, 3185, 3188, 3191, 3195, 3199, 3202, 3205, 3209, 3213, 3216, 3219, 3223, 3227, 3230, 3233, 3237, 3241, 3244, 3247, 3251, 3255, 3258, 3261, 3265, 3269, 3272, 3275, 3279, 3283, 3286, 3289, 3293, 3297, 3300, 3303, 3307, 3311, 3314, 3317, 3321, 3325, 3328, 3331, 3335, 3339, 3342, 3345, 3349, 3353, 3356, 3359, 3363, 3367, 3370, 3373, 3377, 3381, 3384, 3388};
/* BEGIN LINEINFO 
assign 1 52 258
new 0 52 258
assign 1 54 259
new 0 54 259
assign 1 55 260
new 0 55 260
assign 1 56 261
new 0 56 261
assign 1 57 262
new 0 57 262
assign 1 59 263
new 0 59 263
assign 1 60 264
new 0 60 264
assign 1 61 265
new 0 61 265
assign 1 62 266
new 0 62 266
assign 1 63 267
new 0 63 267
assign 1 64 268
new 0 64 268
assign 1 65 269
new 0 65 269
assign 1 69 270
new 0 69 270
assign 1 71 271
new 1 71 271
assign 1 72 272
ntypesGet 0 72 272
assign 1 73 273
twtokGet 0 73 273
assign 1 74 274
new 0 74 274
assign 1 74 275
new 1 74 275
assign 1 77 276
new 0 77 276
assign 1 80 277
new 0 80 277
assign 1 81 278
new 0 81 278
assign 1 82 279
new 0 82 279
assign 1 88 280
new 0 88 280
assign 1 89 281
new 0 89 281
assign 1 90 282
new 0 90 282
assign 1 91 283
new 0 91 283
assign 1 92 284
new 0 92 284
assign 1 92 285
new 1 92 285
assign 1 99 297
def 1 99 302
assign 1 99 303
new 0 99 303
assign 1 99 304
equals 1 99 304
assign 1 0 306
assign 1 99 309
new 0 99 309
assign 1 99 310
ends 1 99 310
assign 1 0 312
assign 1 0 315
assign 1 0 319
assign 1 0 322
assign 1 0 326
assign 1 100 329
new 0 100 329
return 1 100 330
assign 1 102 332
new 0 102 332
return 1 102 333
assign 1 106 339
new 0 106 339
assign 1 106 340
new 0 106 340
assign 1 106 341
swap 2 106 341
return 1 106 342
assign 1 110 349
new 0 110 349
assign 1 110 350
argsGet 0 110 350
assign 1 111 351
new 0 111 351
assign 1 111 352
main 1 111 352
exit 1 111 353
assign 1 115 365
assign 1 116 366
new 1 116 366
assign 1 117 367
new 0 117 367
assign 1 117 368
new 0 117 368
assign 1 117 369
get 2 117 369
assign 1 117 370
firstGet 0 117 370
assign 1 117 371
new 1 117 371
assign 1 118 372
new 0 118 372
assign 1 118 375
lesser 1 118 380
assign 1 119 381
go 0 119 381
incrementValue 0 118 382
return 1 121 388
assign 1 125 396
new 0 125 396
assign 1 126 397
new 0 126 397
config 0 128 399
assign 1 129 400
new 0 129 400
assign 1 130 401
doWhat 0 130 401
assign 1 131 402
new 0 131 402
assign 1 133 406
toString 0 133 406
assign 1 134 407
new 0 134 407
assign 1 135 408
new 0 135 408
assign 1 135 409
add 1 135 409
assign 1 136 410
new 0 136 410
assign 1 0 413
assign 1 0 417
assign 1 0 420
print 0 139 424
return 1 141 426
assign 1 145 432
nameGet 0 145 432
assign 1 145 433
new 0 145 433
assign 1 145 434
equals 1 145 434
return 1 147 437
assign 1 152 580
new 0 152 580
assign 1 154 581
new 0 154 581
assign 1 155 582
get 1 155 582
assign 1 155 583
def 1 155 588
assign 1 156 589
get 1 156 589
assign 1 156 590
iteratorGet 0 0 590
assign 1 156 593
hasNextGet 0 156 593
assign 1 156 595
nextGet 0 156 595
assign 1 157 596
has 1 157 596
assign 1 157 597
not 0 157 602
put 1 158 603
assign 1 159 604
new 1 159 604
addFile 1 159 605
assign 1 164 613
new 0 164 613
assign 1 164 614
nameGet 0 164 614
assign 1 164 615
new 0 164 615
assign 1 164 616
equals 1 164 616
preProcessorSet 1 165 618
assign 1 167 620
new 0 167 620
assign 1 167 621
get 1 167 621
assign 1 167 622
firstGet 0 167 622
assign 1 168 623
new 0 168 623
assign 1 168 624
has 1 168 624
assign 1 169 626
new 0 169 626
assign 1 169 627
get 1 169 627
assign 1 169 628
firstGet 0 169 628
assign 1 171 631
assign 1 173 633
new 0 173 633
assign 1 173 634
new 0 173 634
assign 1 173 635
get 2 173 635
assign 1 173 636
firstGet 0 173 636
assign 1 173 637
new 1 173 637
assign 1 173 638
pathGet 0 173 638
addStep 1 174 639
assign 1 175 640
new 0 175 640
addStep 1 175 641
assign 1 176 642
new 0 176 642
assign 1 176 643
new 0 176 643
assign 1 176 644
get 2 176 644
assign 1 176 645
firstGet 0 176 645
assign 1 176 646
new 1 176 646
assign 1 176 647
pathGet 0 176 647
assign 1 177 648
new 0 177 648
assign 1 177 649
new 0 177 649
assign 1 177 650
nameGet 0 177 650
assign 1 177 651
get 2 177 651
assign 1 177 652
firstGet 0 177 652
assign 1 177 653
new 1 177 653
assign 1 178 654
new 0 178 654
assign 1 178 655
nameGet 0 178 655
assign 1 178 656
get 2 178 656
assign 1 178 657
firstGet 0 178 657
assign 1 178 658
new 1 178 658
assign 1 179 659
new 0 179 659
assign 1 179 660
new 0 179 660
assign 1 179 661
get 2 179 661
assign 1 179 662
firstGet 0 179 662
assign 1 179 663
new 1 179 663
assign 1 180 664
new 0 180 664
assign 1 180 665
new 0 180 665
assign 1 180 666
get 2 180 666
assign 1 180 667
firstGet 0 180 667
assign 1 180 668
new 1 180 668
assign 1 181 669
new 0 181 669
assign 1 181 670
new 0 181 670
assign 1 181 671
get 2 181 671
assign 1 181 672
firstGet 0 181 672
assign 1 181 673
new 1 181 673
assign 1 182 674
new 0 182 674
assign 1 182 675
get 1 182 675
assign 1 183 676
new 0 183 676
assign 1 183 677
get 1 183 677
assign 1 185 678
new 0 185 678
assign 1 185 679
get 1 185 679
assign 1 185 680
firstGet 0 185 680
assign 1 186 681
new 0 186 681
assign 1 186 682
get 1 186 682
assign 1 186 683
firstGet 0 186 683
assign 1 187 684
new 0 187 684
assign 1 187 685
get 1 187 685
assign 1 188 686
undef 1 188 691
assign 1 189 692
new 0 189 692
assign 1 191 694
new 0 191 694
assign 1 191 695
get 1 191 695
assign 1 192 696
undef 1 192 701
assign 1 193 702
new 0 193 702
assign 1 195 704
new 0 195 704
assign 1 195 705
get 1 195 705
assign 1 196 706
undef 1 196 711
assign 1 197 712
new 0 197 712
assign 1 199 714
new 0 199 714
assign 1 199 715
get 1 199 715
assign 1 200 716
undef 1 200 721
assign 1 201 722
new 0 201 722
assign 1 203 724
new 0 203 724
assign 1 203 725
get 1 203 725
assign 1 204 726
undef 1 204 731
assign 1 205 732
new 0 205 732
assign 1 207 734
new 0 207 734
assign 1 207 735
get 1 207 735
assign 1 208 736
undef 1 208 741
assign 1 209 742
new 0 209 742
assign 1 211 744
new 0 211 744
assign 1 211 745
get 1 211 745
assign 1 212 746
undef 1 212 751
assign 1 213 752
new 0 213 752
assign 1 215 754
new 0 215 754
assign 1 215 755
get 1 215 755
assign 1 216 756
undef 1 216 761
assign 1 217 762
new 0 217 762
assign 1 219 764
new 0 219 764
assign 1 219 765
get 1 219 765
assign 1 220 766
undef 1 220 771
assign 1 221 772
new 0 221 772
assign 1 223 774
new 0 223 774
assign 1 223 775
get 1 223 775
assign 1 224 776
def 1 224 781
assign 1 225 782
firstGet 0 225 782
assign 1 227 784
new 0 227 784
assign 1 227 785
get 1 227 785
assign 1 228 786
def 1 228 791
assign 1 229 792
firstGet 0 229 792
assign 1 231 795
new 0 231 795
assign 1 233 797
new 0 233 797
assign 1 233 798
new 0 233 798
assign 1 233 799
isTrue 2 233 799
assign 1 234 800
new 0 234 800
assign 1 234 801
new 0 234 801
assign 1 234 802
isTrue 2 234 802
assign 1 235 803
new 0 235 803
assign 1 235 804
isTrue 1 235 804
assign 1 236 805
new 0 236 805
assign 1 236 806
isTrue 1 236 806
assign 1 237 807
new 0 237 807
assign 1 238 808
new 0 238 808
assign 1 238 809
get 1 238 809
assign 1 239 810
def 1 239 815
assign 1 239 816
isEmptyGet 0 239 816
assign 1 239 817
not 0 239 822
assign 1 0 823
assign 1 0 826
assign 1 0 830
assign 1 240 833
linkedListIteratorGet 0 0 833
assign 1 240 836
hasNextGet 0 240 836
assign 1 240 838
nextGet 0 240 838
put 1 241 839
assign 1 244 846
new 0 244 846
assign 1 244 847
isTrue 1 244 847
assign 1 245 848
new 0 245 848
assign 1 245 849
isTrue 1 245 849
assign 1 246 850
new 0 246 850
assign 1 246 851
isTrue 1 246 851
assign 1 247 852
new 0 247 852
assign 1 247 853
isTrue 1 247 853
assign 1 248 854
new 0 248 854
assign 1 248 855
new 0 248 855
assign 1 248 856
isTrue 2 248 856
assign 1 249 857
new 0 249 857
assign 1 249 858
get 1 249 858
assign 1 250 859
new 0 250 859
assign 1 250 860
get 1 250 860
assign 1 251 861
new 0 251 861
assign 1 251 862
new 0 251 862
assign 1 251 863
get 2 251 863
assign 1 251 864
firstGet 0 251 864
assign 1 252 865
new 0 252 865
assign 1 252 866
new 0 252 866
assign 1 252 867
get 2 252 867
assign 1 252 868
firstGet 0 252 868
assign 1 253 869
new 0 253 869
assign 1 253 870
add 1 253 870
assign 1 253 871
new 0 253 871
assign 1 253 872
get 2 253 872
assign 1 253 873
firstGet 0 253 873
assign 1 254 874
new 0 254 874
assign 1 255 875
new 0 255 875
assign 1 256 876
new 0 256 876
assign 1 257 877
new 0 257 877
assign 1 258 878
new 0 258 878
assign 1 261 879
def 1 261 884
assign 1 262 885
firstGet 0 262 885
assign 1 264 888
new 0 264 888
assign 1 271 890
new 0 271 890
assign 1 271 891
add 1 271 891
assign 1 271 892
nameGet 0 271 892
assign 1 271 893
add 1 271 893
assign 1 271 894
get 1 271 894
assign 1 272 895
def 1 272 900
assign 1 273 901
orderedGet 0 273 901
addAll 1 273 902
assign 1 276 904
new 0 276 904
assign 1 276 905
add 1 276 905
assign 1 276 906
get 1 276 906
assign 1 277 907
def 1 277 912
assign 1 278 913
orderedGet 0 278 913
addAll 1 278 914
assign 1 281 916
new 0 281 916
assign 1 282 917
orderedGet 0 282 917
assign 1 282 918
iteratorGet 0 0 918
assign 1 282 921
hasNextGet 0 282 921
assign 1 282 923
nextGet 0 282 923
assign 1 283 924
new 1 283 924
addValue 1 283 925
assign 1 285 931
newlineGet 0 285 931
assign 1 286 932
assign 1 287 933
new 1 287 933
assign 1 289 934
copy 0 289 934
assign 1 290 935
fileGet 0 290 935
assign 1 290 936
existsGet 0 290 936
assign 1 290 937
not 0 290 942
assign 1 291 943
fileGet 0 291 943
makeDirs 0 291 944
assign 1 293 946
def 1 293 951
assign 1 294 952
new 1 294 952
assign 1 294 953
readerGet 0 294 953
assign 1 295 954
open 0 295 954
assign 1 295 955
readString 0 295 955
close 0 296 956
assign 1 302 970
classNameGet 0 302 970
assign 1 303 971
add 1 303 971
assign 1 303 972
new 0 303 972
assign 1 303 973
add 1 303 973
assign 1 303 974
toString 0 303 974
assign 1 303 975
add 1 303 975
assign 1 304 976
add 1 304 976
assign 1 304 977
new 0 304 977
assign 1 304 978
add 1 304 978
assign 1 304 979
toString 0 304 979
assign 1 304 980
add 1 304 980
return 1 305 981
assign 1 309 1021
new 0 309 1021
assign 1 310 1022
classesGet 0 310 1022
assign 1 310 1023
valueIteratorGet 0 310 1023
assign 1 310 1026
hasNextGet 0 310 1026
assign 1 311 1028
nextGet 0 311 1028
assign 1 312 1029
shouldEmitGet 0 312 1029
assign 1 312 1030
heldGet 0 312 1030
assign 1 312 1031
fromFileGet 0 312 1031
assign 1 312 1032
has 1 312 1032
assign 1 313 1034
heldGet 0 313 1034
assign 1 313 1035
namepathGet 0 313 1035
assign 1 313 1036
toString 0 313 1036
put 1 313 1037
assign 1 314 1038
usedByGet 0 314 1038
assign 1 314 1039
heldGet 0 314 1039
assign 1 314 1040
namepathGet 0 314 1040
assign 1 314 1041
toString 0 314 1041
assign 1 314 1042
get 1 314 1042
assign 1 315 1043
def 1 315 1048
assign 1 316 1049
setIteratorGet 0 0 1049
assign 1 316 1052
hasNextGet 0 316 1052
assign 1 316 1054
nextGet 0 316 1054
put 1 317 1055
assign 1 320 1062
subClassesGet 0 320 1062
assign 1 320 1063
heldGet 0 320 1063
assign 1 320 1064
namepathGet 0 320 1064
assign 1 320 1065
toString 0 320 1065
assign 1 320 1066
get 1 320 1066
assign 1 321 1067
def 1 321 1072
assign 1 322 1073
setIteratorGet 0 0 1073
assign 1 322 1076
hasNextGet 0 322 1076
assign 1 322 1078
nextGet 0 322 1078
put 1 323 1079
assign 1 328 1092
classesGet 0 328 1092
assign 1 328 1093
valueIteratorGet 0 328 1093
assign 1 328 1096
hasNextGet 0 328 1096
assign 1 329 1098
nextGet 0 329 1098
assign 1 330 1099
heldGet 0 330 1099
assign 1 330 1100
heldGet 0 330 1100
assign 1 330 1101
namepathGet 0 330 1101
assign 1 330 1102
toString 0 330 1102
assign 1 330 1103
has 1 330 1103
shouldWriteSet 1 330 1104
assign 1 337 1114
new 0 337 1114
return 1 337 1115
assign 1 341 1133
def 1 341 1138
return 1 342 1139
assign 1 347 1141
def 1 347 1146
assign 1 348 1147
firstGet 0 348 1147
assign 1 349 1148
new 0 349 1148
assign 1 349 1149
equals 1 349 1149
assign 1 350 1151
new 1 350 1151
assign 1 351 1154
new 0 351 1154
assign 1 351 1155
equals 1 351 1155
assign 1 352 1157
new 1 352 1157
assign 1 353 1160
new 0 353 1160
assign 1 353 1161
equals 1 353 1161
assign 1 354 1163
new 1 354 1163
assign 1 355 1166
new 0 355 1166
assign 1 355 1167
equals 1 355 1167
assign 1 356 1169
new 1 356 1169
assign 1 357 1172
new 0 357 1172
assign 1 357 1173
equals 1 357 1173
assign 1 358 1175
new 1 358 1175
assign 1 360 1178
new 0 360 1178
assign 1 360 1179
new 1 360 1179
throw 1 360 1180
return 1 362 1186
return 1 364 1188
assign 1 368 1207
apNew 1 368 1207
assign 1 370 1208
new 0 370 1208
assign 1 370 1209
add 1 370 1209
print 0 370 1210
assign 1 371 1211
new 0 371 1211
assign 1 371 1212
now 0 371 1212
assign 1 372 1213
fileGet 0 372 1213
assign 1 372 1214
readerGet 0 372 1214
assign 1 372 1215
open 0 372 1215
assign 1 373 1216
new 0 373 1216
assign 1 373 1217
deserialize 1 373 1217
close 0 374 1218
assign 1 375 1219
synClassesGet 0 375 1219
addValue 1 375 1220
assign 1 376 1221
new 0 376 1221
assign 1 376 1222
now 0 376 1222
assign 1 376 1223
subtract 1 376 1223
assign 1 377 1224
new 0 377 1224
assign 1 377 1225
add 1 377 1225
print 0 377 1226
assign 1 383 1347
new 0 383 1347
assign 1 383 1348
now 0 383 1348
assign 1 384 1349
new 0 384 1349
assign 1 385 1350
def 1 385 1355
assign 1 386 1356
linkedListIteratorGet 0 0 1356
assign 1 386 1359
hasNextGet 0 386 1359
assign 1 386 1361
nextGet 0 386 1361
loadSyns 1 387 1362
assign 1 390 1369
emitterGet 0 390 1369
assign 1 391 1370
def 1 391 1375
assign 1 392 1376
new 4 392 1376
put 1 393 1377
assign 1 395 1379
new 0 395 1379
assign 1 395 1380
add 1 395 1380
print 0 395 1381
assign 1 398 1384
new 0 398 1384
assign 1 400 1385
iteratorGet 0 0 1385
assign 1 400 1388
hasNextGet 0 400 1388
assign 1 400 1390
nextGet 0 400 1390
assign 1 401 1391
has 1 401 1391
assign 1 401 1392
not 0 401 1397
put 1 402 1398
assign 1 403 1399
new 2 403 1399
addValue 1 404 1400
assign 1 407 1407
iteratorGet 0 0 1407
assign 1 407 1410
hasNextGet 0 407 1410
assign 1 407 1412
nextGet 0 407 1412
assign 1 408 1413
has 1 408 1413
assign 1 408 1414
not 0 408 1419
put 1 409 1420
assign 1 410 1421
new 2 410 1421
addValue 1 411 1422
assign 1 412 1423
libNameGet 0 412 1423
put 1 412 1424
assign 1 417 1432
new 0 417 1432
assign 1 418 1433
iteratorGet 0 418 1433
assign 1 418 1436
hasNextGet 0 418 1436
assign 1 419 1438
nextGet 0 419 1438
assign 1 421 1439
toString 0 421 1439
assign 1 421 1440
has 1 421 1440
assign 1 422 1442
toString 0 422 1442
put 1 422 1443
doParse 1 423 1444
buildSyns 1 426 1451
assign 1 429 1453
new 0 429 1453
assign 1 429 1454
now 0 429 1454
assign 1 429 1455
subtract 1 429 1455
assign 1 432 1456
emitCommonGet 0 432 1456
assign 1 432 1457
def 1 432 1462
assign 1 434 1463
new 0 434 1463
assign 1 434 1464
now 0 434 1464
assign 1 435 1465
emitCommonGet 0 435 1465
doEmit 0 435 1466
assign 1 436 1467
new 0 436 1467
assign 1 436 1468
now 0 436 1468
assign 1 436 1469
subtract 1 436 1469
assign 1 437 1470
new 0 437 1470
assign 1 437 1471
now 0 437 1471
assign 1 437 1472
subtract 1 437 1472
assign 1 438 1473
new 0 438 1473
assign 1 438 1474
add 1 438 1474
print 0 438 1475
assign 1 439 1476
new 0 439 1476
assign 1 439 1477
add 1 439 1477
print 0 439 1478
assign 1 440 1479
new 0 440 1479
assign 1 440 1480
add 1 440 1480
print 0 440 1481
assign 1 441 1482
new 0 441 1482
return 1 441 1483
setClassesToWrite 0 444 1486
libnameInfoGet 0 445 1487
assign 1 447 1488
classesGet 0 447 1488
assign 1 447 1489
valueIteratorGet 0 447 1489
assign 1 447 1492
hasNextGet 0 447 1492
assign 1 448 1494
nextGet 0 448 1494
doEmit 1 449 1495
emitMain 0 451 1501
emitCUInit 0 452 1502
assign 1 453 1503
classesGet 0 453 1503
assign 1 453 1504
valueIteratorGet 0 453 1504
assign 1 453 1507
hasNextGet 0 453 1507
assign 1 454 1509
nextGet 0 454 1509
emitSyn 1 455 1510
assign 1 459 1517
new 0 459 1517
assign 1 459 1518
now 0 459 1518
assign 1 459 1519
subtract 1 459 1519
assign 1 460 1520
def 1 460 1525
assign 1 461 1526
new 0 461 1526
assign 1 461 1527
add 1 461 1527
print 0 461 1528
assign 1 463 1530
new 0 463 1530
assign 1 463 1531
add 1 463 1531
print 0 463 1532
prepMake 1 466 1534
assign 1 470 1537
not 0 470 1542
make 1 471 1543
deployLibrary 1 472 1544
assign 1 474 1546
linkedListIteratorGet 0 0 1546
assign 1 474 1549
hasNextGet 0 474 1549
assign 1 474 1551
nextGet 0 474 1551
assign 1 475 1552
libnameInfoGet 0 475 1552
assign 1 475 1553
unitShlibGet 0 475 1553
assign 1 476 1554
emitPathGet 0 476 1554
assign 1 476 1555
copy 0 476 1555
assign 1 477 1556
stepsGet 0 477 1556
assign 1 477 1557
lastGet 0 477 1557
addStep 1 477 1558
assign 1 478 1559
fileGet 0 478 1559
assign 1 478 1560
existsGet 0 478 1560
assign 1 479 1562
fileGet 0 479 1562
delete 0 479 1563
assign 1 481 1565
fileGet 0 481 1565
assign 1 481 1566
existsGet 0 481 1566
assign 1 481 1567
not 0 481 1567
assign 1 482 1569
fileGet 0 482 1569
assign 1 482 1570
fileGet 0 482 1570
deployFile 2 482 1571
assign 1 486 1579
iteratorGet 0 486 1579
assign 1 487 1580
iteratorGet 0 487 1580
assign 1 489 1583
hasNextGet 0 489 1583
assign 1 489 1585
hasNextGet 0 489 1585
assign 1 0 1587
assign 1 0 1590
assign 1 0 1594
assign 1 490 1597
nextGet 0 490 1597
assign 1 490 1598
apNew 1 490 1598
assign 1 491 1599
emitPathGet 0 491 1599
assign 1 491 1600
copy 0 491 1600
assign 1 491 1601
toString 0 491 1601
assign 1 491 1602
new 0 491 1602
assign 1 491 1603
add 1 491 1603
assign 1 491 1604
nextGet 0 491 1604
assign 1 491 1605
add 1 491 1605
assign 1 491 1606
apNew 1 491 1606
assign 1 493 1607
fileGet 0 493 1607
assign 1 493 1608
existsGet 0 493 1608
assign 1 494 1610
fileGet 0 494 1610
delete 0 494 1611
assign 1 496 1613
fileGet 0 496 1613
assign 1 496 1614
existsGet 0 496 1614
assign 1 496 1615
not 0 496 1615
assign 1 497 1617
fileGet 0 497 1617
assign 1 497 1618
fileGet 0 497 1618
deployFile 2 497 1619
assign 1 502 1628
new 0 502 1628
assign 1 502 1629
now 0 502 1629
assign 1 502 1630
subtract 1 502 1630
assign 1 504 1631
def 1 504 1636
assign 1 505 1637
new 0 505 1637
assign 1 505 1638
add 1 505 1638
print 0 505 1639
assign 1 507 1641
def 1 507 1646
assign 1 508 1647
new 0 508 1647
assign 1 508 1648
add 1 508 1648
print 0 508 1649
assign 1 510 1651
def 1 510 1656
assign 1 511 1657
new 0 511 1657
assign 1 511 1658
add 1 511 1658
print 0 511 1659
assign 1 515 1662
new 0 515 1662
print 0 515 1663
assign 1 516 1664
run 2 516 1664
assign 1 517 1665
new 0 517 1665
assign 1 517 1666
add 1 517 1666
assign 1 517 1667
new 0 517 1667
assign 1 517 1668
add 1 517 1668
print 0 517 1669
return 1 518 1670
assign 1 520 1672
new 0 520 1672
return 1 520 1673
assign 1 524 1686
justParsedGet 0 524 1686
assign 1 524 1687
valueIteratorGet 0 524 1687
assign 1 524 1690
hasNextGet 0 524 1690
assign 1 525 1692
nextGet 0 525 1692
assign 1 526 1693
heldGet 0 526 1693
libNameSet 1 526 1694
assign 1 527 1695
getSyn 2 527 1695
libNameSet 1 528 1696
assign 1 530 1702
justParsedGet 0 530 1702
assign 1 530 1703
valueIteratorGet 0 530 1703
assign 1 530 1706
hasNextGet 0 530 1706
assign 1 531 1708
nextGet 0 531 1708
assign 1 532 1709
heldGet 0 532 1709
assign 1 532 1710
synGet 0 532 1710
checkInheritance 2 533 1711
integrate 1 534 1712
assign 1 536 1718
new 0 536 1718
justParsedSet 1 536 1719
assign 1 540 1747
heldGet 0 540 1747
assign 1 540 1748
synGet 0 540 1748
assign 1 540 1749
def 1 540 1754
assign 1 541 1755
heldGet 0 541 1755
assign 1 541 1756
synGet 0 541 1756
return 1 541 1757
assign 1 543 1759
heldGet 0 543 1759
libNameSet 1 543 1760
assign 1 544 1761
heldGet 0 544 1761
assign 1 544 1762
extendsGet 0 544 1762
assign 1 544 1763
undef 1 544 1768
assign 1 545 1769
new 1 545 1769
assign 1 547 1772
classesGet 0 547 1772
assign 1 547 1773
heldGet 0 547 1773
assign 1 547 1774
extendsGet 0 547 1774
assign 1 547 1775
toString 0 547 1775
assign 1 547 1776
get 1 547 1776
assign 1 549 1777
def 1 549 1782
assign 1 550 1783
heldGet 0 550 1783
libNameSet 1 550 1784
assign 1 551 1785
getSyn 2 551 1785
assign 1 555 1788
heldGet 0 555 1788
assign 1 555 1789
extendsGet 0 555 1789
assign 1 555 1790
getSynNp 1 555 1790
assign 1 557 1792
new 2 557 1792
assign 1 559 1794
heldGet 0 559 1794
synSet 1 559 1795
assign 1 560 1796
heldGet 0 560 1796
assign 1 560 1797
namepathGet 0 560 1797
assign 1 560 1798
toString 0 560 1798
addSynClass 2 560 1799
return 1 561 1800
assign 1 565 1808
toString 0 565 1808
assign 1 566 1809
synClassesGet 0 566 1809
assign 1 566 1810
get 1 566 1810
assign 1 567 1811
def 1 567 1816
return 1 568 1817
assign 1 574 1819
emitterGet 0 574 1819
assign 1 574 1820
loadSyn 1 574 1820
addSynClass 2 575 1821
return 1 576 1822
assign 1 583 1826
undef 1 583 1831
assign 1 584 1832
new 1 584 1832
return 1 586 1834
assign 1 591 1913
new 1 591 1913
assign 1 592 1914
new 0 592 1914
assign 1 593 1915
emitterGet 0 593 1915
assign 1 594 1916
assign 1 595 1917
new 0 595 1917
assign 1 596 1918
shouldEmitGet 0 596 1918
put 1 596 1919
assign 1 0 1922
assign 1 0 1926
assign 1 0 1929
assign 1 599 1933
new 0 599 1933
assign 1 599 1934
toString 0 599 1934
assign 1 599 1935
add 1 599 1935
print 0 599 1936
assign 1 601 1938
assign 1 603 1939
fileGet 0 603 1939
assign 1 603 1940
readerGet 0 603 1940
assign 1 603 1941
open 0 603 1941
assign 1 603 1942
readBuffer 1 603 1942
assign 1 604 1943
fileGet 0 604 1943
assign 1 604 1944
readerGet 0 604 1944
close 0 604 1945
assign 1 607 1946
tokenize 1 607 1946
assign 1 611 1948
new 0 611 1948
echo 0 611 1949
assign 1 613 1951
outermostGet 0 613 1951
nodify 2 613 1952
assign 1 615 1954
new 0 615 1954
print 0 615 1955
assign 1 616 1956
new 2 616 1956
traverse 1 616 1957
assign 1 620 1960
new 0 620 1960
echo 0 620 1961
assign 1 622 1963
new 0 622 1963
traverse 1 622 1964
assign 1 624 1966
new 0 624 1966
print 0 624 1967
assign 1 625 1968
new 2 625 1968
traverse 1 625 1969
assign 1 628 1972
new 0 628 1972
echo 0 628 1973
assign 1 631 1975
new 0 631 1975
traverse 1 631 1976
contain 0 632 1977
assign 1 634 1979
new 0 634 1979
print 0 634 1980
assign 1 635 1981
new 2 635 1981
traverse 1 635 1982
assign 1 639 1985
new 0 639 1985
echo 0 639 1986
assign 1 641 1988
new 0 641 1988
traverse 1 641 1989
assign 1 643 1991
new 0 643 1991
print 0 643 1992
assign 1 644 1993
new 2 644 1993
traverse 1 644 1994
assign 1 648 1997
new 0 648 1997
echo 0 648 1998
assign 1 650 2000
new 0 650 2000
traverse 1 650 2001
assign 1 652 2003
new 0 652 2003
print 0 652 2004
assign 1 653 2005
new 2 653 2005
traverse 1 653 2006
assign 1 657 2009
new 0 657 2009
echo 0 657 2010
assign 1 659 2012
new 0 659 2012
traverse 1 659 2013
assign 1 661 2015
new 0 661 2015
print 0 661 2016
assign 1 662 2017
new 2 662 2017
traverse 1 662 2018
assign 1 666 2021
new 0 666 2021
echo 0 666 2022
assign 1 668 2024
new 0 668 2024
traverse 1 668 2025
assign 1 670 2027
new 0 670 2027
print 0 670 2028
assign 1 671 2029
new 2 671 2029
traverse 1 671 2030
assign 1 675 2033
new 0 675 2033
echo 0 675 2034
assign 1 677 2036
new 0 677 2036
traverse 1 677 2037
assign 1 679 2039
new 0 679 2039
print 0 679 2040
assign 1 680 2041
new 2 680 2041
traverse 1 680 2042
assign 1 684 2045
new 0 684 2045
echo 0 684 2046
assign 1 686 2048
new 0 686 2048
traverse 1 686 2049
assign 1 688 2051
new 0 688 2051
print 0 688 2052
assign 1 689 2053
new 2 689 2053
traverse 1 689 2054
assign 1 693 2057
new 0 693 2057
echo 0 693 2058
assign 1 695 2060
new 0 695 2060
traverse 1 695 2061
assign 1 697 2063
new 0 697 2063
print 0 697 2064
assign 1 698 2065
new 2 698 2065
traverse 1 698 2066
assign 1 701 2069
new 0 701 2069
echo 0 701 2070
assign 1 703 2072
new 0 703 2072
traverse 1 703 2073
assign 1 705 2075
new 0 705 2075
print 0 705 2076
assign 1 706 2077
new 2 706 2077
traverse 1 706 2078
assign 1 710 2081
new 0 710 2081
echo 0 710 2082
assign 1 711 2083
new 0 711 2083
print 0 711 2084
assign 1 713 2086
new 0 713 2086
traverse 1 713 2087
assign 1 0 2089
assign 1 0 2093
assign 1 0 2096
assign 1 715 2100
new 0 715 2100
print 0 715 2101
assign 1 716 2102
new 2 716 2102
traverse 1 716 2103
assign 1 718 2105
classesGet 0 718 2105
assign 1 718 2106
valueIteratorGet 0 718 2106
assign 1 718 2109
hasNextGet 0 718 2109
assign 1 719 2111
nextGet 0 719 2111
assign 1 721 2112
transUnitGet 0 721 2112
assign 1 722 2113
new 1 722 2113
assign 1 723 2114
TRANSUNITGet 0 723 2114
typenameSet 1 723 2115
assign 1 724 2116
new 0 724 2116
assign 1 725 2117
heldGet 0 725 2117
assign 1 725 2118
emitsGet 0 725 2118
emitsSet 1 725 2119
heldSet 1 726 2120
delete 0 727 2121
addValue 1 728 2122
copyLoc 1 729 2123
reInitContained 0 735 2145
assign 1 736 2146
containedGet 0 736 2146
assign 1 737 2147
new 0 737 2147
assign 1 738 2148
new 0 738 2148
assign 1 738 2149
crGet 0 738 2149
assign 1 739 2150
linkedListIteratorGet 0 739 2150
assign 1 739 2153
hasNextGet 0 739 2153
assign 1 740 2155
new 1 740 2155
assign 1 741 2156
nextGet 0 741 2156
heldSet 1 741 2157
nlcSet 1 742 2158
assign 1 743 2159
heldGet 0 743 2159
assign 1 743 2160
equals 1 743 2160
assign 1 744 2162
increment 0 744 2162
assign 1 746 2164
heldGet 0 746 2164
assign 1 746 2165
notEquals 1 746 2165
addValue 1 747 2167
containerSet 1 748 2168
assign 1 755 2223
new 0 755 2223
fromString 1 756 2224
assign 1 758 2225
new 1 758 2225
assign 1 759 2226
NAMEPATHGet 0 759 2226
typenameSet 1 759 2227
heldSet 1 760 2228
copyLoc 1 761 2229
assign 1 763 2230
new 0 763 2230
assign 1 764 2231
new 0 764 2231
nameSet 1 764 2232
assign 1 765 2233
new 0 765 2233
wasBoundSet 1 765 2234
assign 1 766 2235
new 0 766 2235
boundSet 1 766 2236
assign 1 767 2237
new 0 767 2237
isConstructSet 1 767 2238
assign 1 768 2239
new 0 768 2239
isLiteralSet 1 768 2240
assign 1 769 2241
heldGet 0 769 2241
literalValueSet 1 769 2242
addValue 1 771 2243
assign 1 773 2244
CALLGet 0 773 2244
typenameSet 1 773 2245
heldSet 1 774 2246
resolveNp 0 776 2247
assign 1 778 2248
new 0 778 2248
assign 1 778 2249
equals 1 778 2249
assign 1 0 2251
assign 1 778 2254
new 0 778 2254
assign 1 778 2255
equals 1 778 2255
assign 1 0 2257
assign 1 0 2260
assign 1 779 2264
priorPeerGet 0 779 2264
assign 1 780 2265
def 1 780 2270
assign 1 780 2271
typenameGet 0 780 2271
assign 1 780 2272
SUBTRACTGet 0 780 2272
assign 1 780 2273
equals 1 780 2273
assign 1 0 2275
assign 1 780 2278
typenameGet 0 780 2278
assign 1 780 2279
ADDGet 0 780 2279
assign 1 780 2280
equals 1 780 2280
assign 1 0 2282
assign 1 0 2285
assign 1 0 2289
assign 1 0 2292
assign 1 0 2296
assign 1 781 2299
priorPeerGet 0 781 2299
assign 1 782 2300
undef 1 782 2305
assign 1 0 2306
assign 1 782 2309
typenameGet 0 782 2309
assign 1 782 2310
CALLGet 0 782 2310
assign 1 782 2311
notEquals 1 782 2311
assign 1 782 2313
typenameGet 0 782 2313
assign 1 782 2314
IDGet 0 782 2314
assign 1 782 2315
notEquals 1 782 2315
assign 1 0 2317
assign 1 0 2320
assign 1 0 2324
assign 1 782 2327
typenameGet 0 782 2327
assign 1 782 2328
VARGet 0 782 2328
assign 1 782 2329
notEquals 1 782 2329
assign 1 0 2331
assign 1 0 2334
assign 1 0 2338
assign 1 782 2341
typenameGet 0 782 2341
assign 1 782 2342
ACCESSORGet 0 782 2342
assign 1 782 2343
notEquals 1 782 2343
assign 1 0 2345
assign 1 0 2348
assign 1 0 2352
assign 1 0 2355
assign 1 0 2358
assign 1 788 2362
heldGet 0 788 2362
assign 1 788 2363
literalValueGet 0 788 2363
assign 1 788 2364
add 1 788 2364
literalValueSet 1 788 2365
delete 0 789 2366
return 1 0 2373
return 1 0 2376
assign 1 0 2379
assign 1 0 2383
return 1 0 2387
return 1 0 2390
assign 1 0 2393
assign 1 0 2397
return 1 0 2401
return 1 0 2404
assign 1 0 2407
assign 1 0 2411
return 1 0 2415
return 1 0 2418
assign 1 0 2421
assign 1 0 2425
return 1 0 2429
return 1 0 2432
assign 1 0 2435
assign 1 0 2439
return 1 0 2443
return 1 0 2446
assign 1 0 2449
assign 1 0 2453
return 1 0 2457
return 1 0 2460
assign 1 0 2463
assign 1 0 2467
return 1 0 2471
return 1 0 2474
assign 1 0 2477
assign 1 0 2481
return 1 0 2485
return 1 0 2488
assign 1 0 2491
assign 1 0 2495
return 1 0 2499
return 1 0 2502
assign 1 0 2505
assign 1 0 2509
return 1 0 2513
return 1 0 2516
assign 1 0 2519
assign 1 0 2523
return 1 0 2527
return 1 0 2530
assign 1 0 2533
assign 1 0 2537
return 1 0 2541
return 1 0 2544
assign 1 0 2547
assign 1 0 2551
return 1 0 2555
return 1 0 2558
assign 1 0 2561
assign 1 0 2565
return 1 0 2569
return 1 0 2572
assign 1 0 2575
assign 1 0 2579
return 1 0 2583
return 1 0 2586
assign 1 0 2589
assign 1 0 2593
return 1 0 2597
return 1 0 2600
assign 1 0 2603
assign 1 0 2607
return 1 0 2611
return 1 0 2614
assign 1 0 2617
assign 1 0 2621
return 1 0 2625
return 1 0 2628
assign 1 0 2631
assign 1 0 2635
return 1 0 2639
return 1 0 2642
assign 1 0 2645
assign 1 0 2649
return 1 0 2653
return 1 0 2656
assign 1 0 2659
assign 1 0 2663
return 1 0 2667
return 1 0 2670
assign 1 0 2673
assign 1 0 2677
return 1 0 2681
return 1 0 2684
assign 1 0 2687
assign 1 0 2691
return 1 0 2695
return 1 0 2698
assign 1 0 2701
assign 1 0 2705
return 1 0 2709
return 1 0 2712
assign 1 0 2715
assign 1 0 2719
return 1 0 2723
return 1 0 2726
assign 1 0 2729
assign 1 0 2733
return 1 0 2737
return 1 0 2740
assign 1 0 2743
assign 1 0 2747
return 1 0 2751
return 1 0 2754
assign 1 0 2757
assign 1 0 2761
return 1 0 2765
return 1 0 2768
assign 1 0 2771
assign 1 0 2775
return 1 0 2779
return 1 0 2782
assign 1 0 2785
assign 1 0 2789
return 1 0 2793
return 1 0 2796
assign 1 0 2799
assign 1 0 2803
return 1 0 2807
return 1 0 2810
assign 1 0 2813
assign 1 0 2817
return 1 0 2821
return 1 0 2824
assign 1 0 2827
assign 1 0 2831
return 1 0 2835
return 1 0 2838
assign 1 0 2841
assign 1 0 2845
return 1 0 2849
return 1 0 2852
assign 1 0 2855
assign 1 0 2859
return 1 0 2863
return 1 0 2866
assign 1 0 2869
assign 1 0 2873
return 1 0 2877
return 1 0 2880
assign 1 0 2883
assign 1 0 2887
return 1 0 2891
return 1 0 2894
assign 1 0 2897
assign 1 0 2901
return 1 0 2905
return 1 0 2908
assign 1 0 2911
assign 1 0 2915
return 1 0 2919
return 1 0 2922
assign 1 0 2925
assign 1 0 2929
return 1 0 2933
return 1 0 2936
assign 1 0 2939
assign 1 0 2943
return 1 0 2947
return 1 0 2950
assign 1 0 2953
assign 1 0 2957
return 1 0 2961
return 1 0 2964
assign 1 0 2967
assign 1 0 2971
return 1 0 2975
return 1 0 2978
assign 1 0 2981
assign 1 0 2985
return 1 0 2989
return 1 0 2992
assign 1 0 2995
assign 1 0 2999
return 1 0 3003
return 1 0 3006
assign 1 0 3009
assign 1 0 3013
return 1 0 3017
return 1 0 3020
assign 1 0 3023
assign 1 0 3027
return 1 0 3031
return 1 0 3034
assign 1 0 3037
assign 1 0 3041
return 1 0 3045
return 1 0 3048
assign 1 0 3051
assign 1 0 3055
return 1 0 3059
return 1 0 3062
assign 1 0 3065
assign 1 0 3069
return 1 0 3073
return 1 0 3076
assign 1 0 3079
assign 1 0 3083
return 1 0 3087
return 1 0 3090
assign 1 0 3093
assign 1 0 3097
return 1 0 3101
return 1 0 3104
assign 1 0 3107
assign 1 0 3111
return 1 0 3115
return 1 0 3118
assign 1 0 3121
assign 1 0 3125
return 1 0 3129
return 1 0 3132
assign 1 0 3135
assign 1 0 3139
return 1 0 3143
return 1 0 3146
assign 1 0 3149
assign 1 0 3153
return 1 0 3157
return 1 0 3160
assign 1 0 3163
assign 1 0 3167
return 1 0 3171
return 1 0 3174
assign 1 0 3177
assign 1 0 3181
return 1 0 3185
return 1 0 3188
assign 1 0 3191
assign 1 0 3195
return 1 0 3199
return 1 0 3202
assign 1 0 3205
assign 1 0 3209
return 1 0 3213
return 1 0 3216
assign 1 0 3219
assign 1 0 3223
return 1 0 3227
return 1 0 3230
assign 1 0 3233
assign 1 0 3237
return 1 0 3241
return 1 0 3244
assign 1 0 3247
assign 1 0 3251
return 1 0 3255
return 1 0 3258
assign 1 0 3261
assign 1 0 3265
return 1 0 3269
return 1 0 3272
assign 1 0 3275
assign 1 0 3279
return 1 0 3283
return 1 0 3286
assign 1 0 3289
assign 1 0 3293
return 1 0 3297
return 1 0 3300
assign 1 0 3303
assign 1 0 3307
return 1 0 3311
return 1 0 3314
assign 1 0 3317
assign 1 0 3321
return 1 0 3325
return 1 0 3328
assign 1 0 3331
assign 1 0 3335
return 1 0 3339
return 1 0 3342
assign 1 0 3345
assign 1 0 3349
return 1 0 3353
return 1 0 3356
assign 1 0 3359
assign 1 0 3363
return 1 0 3367
return 1 0 3370
assign 1 0 3373
assign 1 0 3377
return 1 0 3381
assign 1 0 3384
assign 1 0 3388
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1207446140: return bem_linkLibArgsGetDirect_0();
case -699810601: return bem_emitFileHeaderGet_0();
case -380148684: return bem_emitDataGetDirect_0();
case -830733381: return bem_echo_0();
case 996107059: return bem_emitFlagsGetDirect_0();
case -1620221308: return bem_ntypesGet_0();
case 1647936444: return bem_codeGetDirect_0();
case 1083444557: return bem_closeLibrariesStrGet_0();
case 983663465: return bem_saveSynsGetDirect_0();
case 805188562: return bem_makeNameGet_0();
case -1436446118: return bem_emitDebugGetDirect_0();
case -2013770690: return bem_parseTimeGet_0();
case -1999832913: return bem_genOnlyGet_0();
case 825445536: return bem_initLibsGetDirect_0();
case -1320013810: return bem_deployPathGet_0();
case -1923269180: return bem_outputPlatformGetDirect_0();
case -705722437: return bem_makeArgsGet_0();
case 795921495: return bem_emitCommonGet_0();
case 702601495: return bem_lctokGet_0();
case -1369640458: return bem_doEmitGet_0();
case -838994431: return bem_makeGetDirect_0();
case 1717418808: return bem_saveIdsGetDirect_0();
case 1039850150: return bem_extIncludesGetDirect_0();
case -1381719973: return bem_buildSucceededGetDirect_0();
case -1553770839: return bem_printAstGetDirect_0();
case 602169173: return bem_usedLibrarysGetDirect_0();
case -115417192: return bem_emitDataGet_0();
case -432430484: return bem_initLibsGet_0();
case -2102333880: return bem_saveSynsGet_0();
case 1676423601: return bem_extIncludesGet_0();
case -1898644391: return bem_twtokGetDirect_0();
case 1425790109: return bem_fieldIteratorGet_0();
case -1627553374: return bem_emitPathGetDirect_0();
case -1450961549: return bem_emitPathGet_0();
case 399927605: return bem_outputPlatformGet_0();
case 987244848: return bem_deployLibraryGet_0();
case 115636637: return bem_extLinkObjectsGet_0();
case 740534965: return bem_ccObjArgsGet_0();
case 760214601: return bem_deployLibraryGetDirect_0();
case -1844078838: return bem_printAllAstGet_0();
case -1923652438: return bem_compilerGetDirect_0();
case -979431779: return bem_argsGet_0();
case -450962079: return bem_loadSynsGet_0();
case 1546544584: return bem_serializationIteratorGet_0();
case -1872994857: return bem_parseTimeGetDirect_0();
case -1636033660: return bem_deployFilesFromGetDirect_0();
case -2084016052: return bem_serializeToString_0();
case -824350270: return bem_deployUsedLibrariesGet_0();
case 1024603971: return bem_includePathGetDirect_0();
case -1367190019: return bem_builtGetDirect_0();
case -1005995611: return bem_genOnlyGetDirect_0();
case -1761934005: return bem_parseGet_0();
case -408522205: return bem_serializeContents_0();
case 199038398: return bem_printStepsGet_0();
case -853037873: return bem_exeNameGetDirect_0();
case -576816204: return bem_sourceFileNameGet_0();
case 167399763: return bem_deserializeClassNameGet_0();
case 586744029: return bem_printPlacesGet_0();
case -914447610: return bem_lctokGetDirect_0();
case -1892088178: return bem_go_0();
case -1397334730: return bem_fromFileGetDirect_0();
case 1683348411: return bem_estrGet_0();
case -1614946685: return bem_printStepsGetDirect_0();
case -800963447: return bem_makeNameGetDirect_0();
case 1202329015: return bem_parseEmitCompileTimeGet_0();
case -803729432: return bem_prepMakeGetDirect_0();
case -278383791: return bem_runArgsGetDirect_0();
case -1343040730: return bem_doEmitGetDirect_0();
case 261504109: return bem_runGet_0();
case -1540167297: return bem_runArgsGet_0();
case 1185153042: return bem_mainNameGetDirect_0();
case -2132349618: return bem_putLineNumbersInTraceGet_0();
case 778397597: return bem_deployUsedLibrariesGetDirect_0();
case 32884017: return bem_includePathGet_0();
case 2034825137: return bem_tagGet_0();
case 1368656713: return bem_argsGetDirect_0();
case 1402005589: return bem_emitCs_0();
case -1127142206: return bem_main_0();
case 1808986418: return bem_toBuildGet_0();
case -1038252041: return bem_saveIdsGet_0();
case 389130038: return bem_printAllAstGetDirect_0();
case -695733973: return bem_hashGet_0();
case -991462404: return bem_exeNameGet_0();
case 2142382488: return bem_emitCommonGetDirect_0();
case -224207136: return bem_usedLibrarysGet_0();
case 834497784: return bem_sharedEmitterGet_0();
case -1058391750: return bem_buildPathGet_0();
case 1606642997: return bem_new_0();
case 677381912: return bem_emitFileHeaderGetDirect_0();
case -1566956546: return bem_codeGet_0();
case -1712971648: return bem_nlGet_0();
case 120101259: return bem_usedLibrarysStrGetDirect_0();
case 2041564323: return bem_sharedEmitterGetDirect_0();
case -1228217034: return bem_readBufferGetDirect_0();
case -102786359: return bem_usedLibrarysStrGet_0();
case 745299126: return bem_extLibsGet_0();
case -1389219549: return bem_estrGetDirect_0();
case 1065133948: return bem_printAstGet_0();
case 992308556: return bem_emitLibraryGetDirect_0();
case -1542140304: return bem_newlineGet_0();
case -1391818849: return bem_prepMakeGet_0();
case -1981911257: return bem_parseEmitTimeGet_0();
case -1432459229: return bem_constantsGet_0();
case 607936968: return bem_singleCCGetDirect_0();
case 1010768873: return bem_emitFlagsGet_0();
case -2000865484: return bem_putLineNumbersInTraceGetDirect_0();
case -630280728: return bem_copy_0();
case -1540001109: return bem_emitLangsGet_0();
case 2144769147: return bem_buildPathGetDirect_0();
case -1448690808: return bem_startTimeGetDirect_0();
case 1066489349: return bem_many_0();
case -449796292: return bem_buildSucceededGet_0();
case 2003653179: return bem_mainNameGet_0();
case 1409384079: return bem_fromFileGet_0();
case 67894277: return bem_doWhat_0();
case -615481773: return bem_singleCCGet_0();
case 1738591028: return bem_fieldNamesGet_0();
case -1643474387: return bem_ccObjArgsGetDirect_0();
case -1847620794: return bem_iteratorGet_0();
case 2086474367: return bem_create_0();
case -449262321: return bem_printPlacesGetDirect_0();
case -699300073: return bem_deployPathGetDirect_0();
case 1287997158: return bem_newlineGetDirect_0();
case -1787245321: return bem_ntypesGetDirect_0();
case -476857094: return bem_buildMessageGet_0();
case -297385093: return bem_makeArgsGetDirect_0();
case 247579449: return bem_emitterGet_0();
case -1592909494: return bem_extLibsGetDirect_0();
case -261721054: return bem_loadSynsGetDirect_0();
case -208464134: return bem_config_0();
case 945902136: return bem_libNameGet_0();
case -1848917552: return bem_runGetDirect_0();
case 1169011989: return bem_toString_0();
case 224300512: return bem_closeLibrariesGet_0();
case 1100335547: return bem_parseEmitCompileTimeGetDirect_0();
case 20820918: return bem_deployFilesToGet_0();
case -1944305935: return bem_platformGet_0();
case 128443025: return bem_paramsGet_0();
case 573693411: return bem_deployFilesToGetDirect_0();
case -1767572158: return bem_compilerProfileGet_0();
case 1172802970: return bem_deployFilesFromGet_0();
case 1325334730: return bem_toBuildGetDirect_0();
case -1004722006: return bem_readBufferGet_0();
case -1421405295: return bem_compilerProfileGetDirect_0();
case 1678194304: return bem_parseGetDirect_0();
case -2041265648: return bem_makeGet_0();
case -1532645360: return bem_emitLangsGetDirect_0();
case -121265899: return bem_constantsGetDirect_0();
case 884934186: return bem_linkLibArgsGet_0();
case 1945803401: return bem_print_0();
case -1309597400: return bem_libNameGetDirect_0();
case 66465588: return bem_paramsGetDirect_0();
case 847164814: return bem_printAstElementsGet_0();
case -537748632: return bem_ownProcessGet_0();
case 1019654086: return bem_buildMessageGetDirect_0();
case -844346492: return bem_closeLibrariesGetDirect_0();
case 1120349008: return bem_extLinkObjectsGetDirect_0();
case 537455500: return bem_emitLibraryGet_0();
case -373483362: return bem_classNameGet_0();
case -2089466413: return bem_emitDebugGet_0();
case 619597578: return bem_setClassesToWrite_0();
case 1723740320: return bem_parseEmitTimeGetDirect_0();
case -2061272930: return bem_printAstElementsGetDirect_0();
case -1409233752: return bem_toAny_0();
case -603131654: return bem_nlGetDirect_0();
case 2049953014: return bem_platformGetDirect_0();
case 1438915338: return bem_once_0();
case -460515412: return bem_twtokGet_0();
case -1162252275: return bem_startTimeGet_0();
case -1296203382: return bem_builtGet_0();
case -723941496: return bem_ownProcessGetDirect_0();
case -1851712194: return bem_closeLibrariesStrGetDirect_0();
case 1166657510: return bem_compilerGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 936031603: return bem_readBufferSet_1(bevd_0);
case -1414828144: return bem_exeNameSet_1(bevd_0);
case -703624502: return bem_makeArgsSetDirect_1(bevd_0);
case -694104421: return bem_parseEmitTimeSet_1(bevd_0);
case -1940749296: return bem_emitFlagsSet_1(bevd_0);
case -474669253: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case -841831872: return bem_printAllAstSet_1(bevd_0);
case -301959301: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1625268565: return bem_codeSetDirect_1(bevd_0);
case 542523031: return bem_defined_1(bevd_0);
case 1460573933: return bem_emitLangsSet_1(bevd_0);
case 1748034892: return bem_makeSet_1(bevd_0);
case -653478298: return bem_argsSetDirect_1(bevd_0);
case 1094919197: return bem_emitFileHeaderSetDirect_1(bevd_0);
case -132790256: return bem_extLinkObjectsSetDirect_1(bevd_0);
case -1554912011: return bem_newlineSetDirect_1(bevd_0);
case -405648614: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 491873122: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -726390043: return bem_undef_1(bevd_0);
case -576638886: return bem_platformSetDirect_1(bevd_0);
case -1975359624: return bem_nlSetDirect_1(bevd_0);
case 936421900: return bem_linkLibArgsSetDirect_1(bevd_0);
case 776502676: return bem_deployLibrarySetDirect_1(bevd_0);
case 575763691: return bem_undefined_1(bevd_0);
case -716040830: return bem_emitFlagsSetDirect_1(bevd_0);
case -1176884308: return bem_buildPathSetDirect_1(bevd_0);
case 1930612127: return bem_genOnlySetDirect_1(bevd_0);
case 1642039472: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1678866955: return bem_emitLibrarySetDirect_1(bevd_0);
case 2031396259: return bem_printPlacesSetDirect_1(bevd_0);
case 1175508563: return bem_exeNameSetDirect_1(bevd_0);
case -1192334578: return bem_extLibsSet_1(bevd_0);
case -695919757: return bem_emitCommonSetDirect_1(bevd_0);
case -784220229: return bem_constantsSetDirect_1(bevd_0);
case 1969362174: return bem_mainNameSet_1(bevd_0);
case -520412168: return bem_printAstElementsSet_1(bevd_0);
case 1845284598: return bem_usedLibrarysStrSetDirect_1(bevd_0);
case 692996285: return bem_printAstSet_1(bevd_0);
case -199118084: return bem_runSetDirect_1(bevd_0);
case -822012092: return bem_ownProcessSet_1(bevd_0);
case -1371116116: return bem_otherClass_1(bevd_0);
case -1157819835: return bem_extIncludesSetDirect_1(bevd_0);
case 235828867: return bem_parseTimeSetDirect_1(bevd_0);
case -35734794: return bem_emitFileHeaderSet_1(bevd_0);
case 274185723: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case -1974309812: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -188028884: return bem_buildMessageSet_1(bevd_0);
case 1396522688: return bem_singleCCSetDirect_1(bevd_0);
case -1422595489: return bem_doParse_1(bevd_0);
case -1884535395: return bem_prepMakeSetDirect_1(bevd_0);
case 658177643: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case 90429623: return bem_platformSet_1(bevd_0);
case -1914714180: return bem_runArgsSetDirect_1(bevd_0);
case 32753185: return bem_usedLibrarysSetDirect_1(bevd_0);
case -1446239310: return bem_includePathSetDirect_1(bevd_0);
case 374653817: return bem_getSynNp_1(bevd_0);
case -930160876: return bem_printStepsSetDirect_1(bevd_0);
case 323948554: return bem_lctokSet_1(bevd_0);
case -1508187586: return bem_emitDebugSetDirect_1(bevd_0);
case -1685092572: return bem_deployPathSet_1(bevd_0);
case -1363396109: return bem_loadSynsSet_1(bevd_0);
case 620650245: return bem_parseEmitTimeSetDirect_1(bevd_0);
case 902288600: return bem_libNameSet_1(bevd_0);
case 1790575350: return bem_sameClass_1(bevd_0);
case -1540227438: return bem_saveIdsSetDirect_1(bevd_0);
case 1259270862: return bem_libNameSetDirect_1(bevd_0);
case 1305486368: return bem_buildSucceededSet_1(bevd_0);
case -1849830339: return bem_paramsSet_1(bevd_0);
case 71595437: return bem_saveIdsSet_1(bevd_0);
case -1289443526: return bem_ccObjArgsSet_1(bevd_0);
case -85967812: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1664271443: return bem_usedLibrarysSet_1(bevd_0);
case -886270454: return bem_emitPathSet_1(bevd_0);
case -1536020352: return bem_closeLibrariesSet_1(bevd_0);
case 232552830: return bem_otherType_1(bevd_0);
case -492473062: return bem_deployFilesFromSetDirect_1(bevd_0);
case -913031165: return bem_emitPathSetDirect_1(bevd_0);
case -807631376: return bem_saveSynsSet_1(bevd_0);
case -2105128913: return bem_ccObjArgsSetDirect_1(bevd_0);
case -327108985: return bem_outputPlatformSetDirect_1(bevd_0);
case -931626134: return bem_nlSet_1(bevd_0);
case 127463293: return bem_linkLibArgsSet_1(bevd_0);
case -1305999468: return bem_paramsSetDirect_1(bevd_0);
case 1630312425: return bem_makeSetDirect_1(bevd_0);
case -797905621: return bem_startTimeSet_1(bevd_0);
case -1663786357: return bem_equals_1(bevd_0);
case 1744504531: return bem_runArgsSet_1(bevd_0);
case 784516074: return bem_lctokSetDirect_1(bevd_0);
case 425212148: return bem_extLibsSetDirect_1(bevd_0);
case 58313651: return bem_buildSyns_1(bevd_0);
case -2063857846: return bem_sharedEmitterSetDirect_1(bevd_0);
case -1544708380: return bem_deployFilesToSetDirect_1(bevd_0);
case -799324484: return bem_genOnlySet_1(bevd_0);
case 1535526125: return bem_closeLibrariesStrSet_1(bevd_0);
case 1499807355: return bem_builtSet_1(bevd_0);
case -1715898276: return bem_ownProcessSetDirect_1(bevd_0);
case 1781049550: return bem_twtokSet_1(bevd_0);
case 1512036095: return bem_singleCCSet_1(bevd_0);
case -643287057: return bem_startTimeSetDirect_1(bevd_0);
case -275921765: return bem_compilerSet_1(bevd_0);
case 2099165274: return bem_compilerProfileSetDirect_1(bevd_0);
case -1025881487: return bem_parseSetDirect_1(bevd_0);
case 269908803: return bem_printStepsSet_1(bevd_0);
case 1266908958: return bem_twtokSetDirect_1(bevd_0);
case -125854362: return bem_sharedEmitterSet_1(bevd_0);
case -297560131: return bem_initLibsSetDirect_1(bevd_0);
case 1214781851: return bem_argsSet_1(bevd_0);
case -1061818418: return bem_printAllAstSetDirect_1(bevd_0);
case 161459569: return bem_constantsSet_1(bevd_0);
case 1911769899: return bem_putLineNumbersInTraceSet_1(bevd_0);
case -1712809135: return bem_makeArgsSet_1(bevd_0);
case 1551286866: return bem_emitDataSet_1(bevd_0);
case -2045883718: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1487784766: return bem_makeNameSetDirect_1(bevd_0);
case 1065939950: return bem_builtSetDirect_1(bevd_0);
case -1711212361: return bem_printPlacesSet_1(bevd_0);
case -1613585312: return bem_deployUsedLibrariesSet_1(bevd_0);
case 1288784144: return bem_includePathSet_1(bevd_0);
case -452332833: return bem_buildMessageSetDirect_1(bevd_0);
case -523838042: return bem_extLinkObjectsSet_1(bevd_0);
case 1543106022: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case -396772357: return bem_extIncludesSet_1(bevd_0);
case 80852473: return bem_ntypesSetDirect_1(bevd_0);
case -319539812: return bem_doEmitSetDirect_1(bevd_0);
case -1617580903: return bem_loadSynsSetDirect_1(bevd_0);
case -371372176: return bem_printAstElementsSetDirect_1(bevd_0);
case 1501773499: return bem_emitCommonSet_1(bevd_0);
case 566939607: return bem_newlineSet_1(bevd_0);
case -349009165: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case 354165388: return bem_printAstSetDirect_1(bevd_0);
case -1453036751: return bem_codeSet_1(bevd_0);
case -236119268: return bem_runSet_1(bevd_0);
case -1563024666: return bem_estrSet_1(bevd_0);
case 1636639619: return bem_deployLibrarySet_1(bevd_0);
case 591900781: return bem_emitLangsSetDirect_1(bevd_0);
case 1151430868: return bem_parseTimeSet_1(bevd_0);
case 1638463838: return bem_mainNameSetDirect_1(bevd_0);
case 246751162: return bem_deployFilesToSet_1(bevd_0);
case -1022031282: return bem_ntypesSet_1(bevd_0);
case -1566928033: return bem_doEmitSet_1(bevd_0);
case 997140842: return bem_estrSetDirect_1(bevd_0);
case 1569142232: return bem_emitDataSetDirect_1(bevd_0);
case -1810501348: return bem_deployPathSetDirect_1(bevd_0);
case 577998518: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case -497197457: return bem_compilerSetDirect_1(bevd_0);
case -2073425080: return bem_sameType_1(bevd_0);
case 1691930201: return bem_deployFilesFromSet_1(bevd_0);
case -776996394: return bem_buildSucceededSetDirect_1(bevd_0);
case 433796843: return bem_usedLibrarysStrSet_1(bevd_0);
case -463115686: return bem_def_1(bevd_0);
case 703043726: return bem_emitLibrarySet_1(bevd_0);
case -1207228230: return bem_buildPathSet_1(bevd_0);
case -1159974757: return bem_makeNameSet_1(bevd_0);
case 973254923: return bem_readBufferSetDirect_1(bevd_0);
case -1761657404: return bem_emitDebugSet_1(bevd_0);
case -1032749444: return bem_toBuildSet_1(bevd_0);
case 876386412: return bem_sameObject_1(bevd_0);
case -4323779: return bem_fromFileSet_1(bevd_0);
case 1754370013: return bem_parseSet_1(bevd_0);
case -656653357: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case 1449183263: return bem_notEquals_1(bevd_0);
case 605444454: return bem_initLibsSet_1(bevd_0);
case 280243987: return bem_compilerProfileSet_1(bevd_0);
case -1942140220: return bem_fromFileSetDirect_1(bevd_0);
case 33003940: return bem_saveSynsSetDirect_1(bevd_0);
case -1854318841: return bem_copyTo_1(bevd_0);
case 801549346: return bem_toBuildSetDirect_1(bevd_0);
case -1540920238: return bem_closeLibrariesSetDirect_1(bevd_0);
case -1994445534: return bem_prepMakeSet_1(bevd_0);
case 456006618: return bem_outputPlatformSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -897682046: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 116337276: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1198735764: return bem_getSyn_2(bevd_0, bevd_1);
case -2028666619: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1558133875: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1600497328: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1471832670: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 990151340: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1527645791: return bem_buildLiteral_2(bevd_0, bevd_1);
case -690837206: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
}
