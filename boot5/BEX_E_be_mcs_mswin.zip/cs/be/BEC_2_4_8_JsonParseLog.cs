namespace be {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_8_JsonParseLog : BEC_2_6_6_SystemObject {
public BEC_2_4_8_JsonParseLog() { }
static BEC_2_4_8_JsonParseLog() { }
private static byte[] becc_BEC_2_4_8_JsonParseLog_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_4_8_JsonParseLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_0 = {0x47,0x6F,0x74,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x7C};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_1 = {0x7C};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_2 = {0x62,0x65,0x67,0x69,0x6E,0x4D,0x61,0x70};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_3 = {0x65,0x6E,0x64,0x4D,0x61,0x70};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_4 = {0x6B,0x76,0x4D,0x69,0x64};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_5 = {0x62,0x65,0x67,0x69,0x6E,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_6 = {0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_7 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_8 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_9 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x4E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_10 = {0x47,0x6F,0x74,0x20,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x20,0x7C};
public static new BEC_2_4_8_JsonParseLog bece_BEC_2_4_8_JsonParseLog_bevs_inst;

public static new BET_2_4_8_JsonParseLog bece_BEC_2_4_8_JsonParseLog_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleString_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_4_8_JsonParseLog_bels_0));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_str);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_8_JsonParseLog_bels_1));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_beginMap_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_8_JsonParseLog_bels_2));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_endMap_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_8_JsonParseLog_bels_3));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_kvMid_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_8_JsonParseLog_bels_4));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_beginList_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_4_8_JsonParseLog_bels_5));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_endList_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_4_8_JsonParseLog_bels_6));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleTrue_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_4_8_JsonParseLog_bels_7));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleFalse_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_4_8_JsonParseLog_bels_8));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleNull_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_4_8_JsonParseLog_bels_9));
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_4_8_JsonParseLog_bels_10));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_int);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_8_JsonParseLog_bels_1));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {580, 580, 580, 580, 580, 584, 584, 588, 588, 592, 592, 596, 596, 600, 600, 604, 604, 608, 608, 612, 612, 616, 616, 616, 616, 616};
public static new int[] bevs_smnlec
 = new int[] {31, 32, 33, 34, 35, 40, 41, 46, 47, 52, 53, 58, 59, 64, 65, 70, 71, 76, 77, 82, 83, 91, 92, 93, 94, 95};
/* BEGIN LINEINFO 
assign 1 580 31
new 0 580 31
assign 1 580 32
add 1 580 32
assign 1 580 33
new 0 580 33
assign 1 580 34
add 1 580 34
print 0 580 35
assign 1 584 40
new 0 584 40
print 0 584 41
assign 1 588 46
new 0 588 46
print 0 588 47
assign 1 592 52
new 0 592 52
print 0 592 53
assign 1 596 58
new 0 596 58
print 0 596 59
assign 1 600 64
new 0 600 64
print 0 600 65
assign 1 604 70
new 0 604 70
print 0 604 71
assign 1 608 76
new 0 608 76
print 0 608 77
assign 1 612 82
new 0 612 82
print 0 612 83
assign 1 616 91
new 0 616 91
assign 1 616 92
add 1 616 92
assign 1 616 93
new 0 616 93
assign 1 616 94
add 1 616 94
print 0 616 95
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -652053502: return bem_fieldNamesGet_0();
case 1474173432: return bem_handleNull_0();
case 944073339: return bem_fieldIteratorGet_0();
case -1785724794: return bem_once_0();
case -1381475953: return bem_handleFalse_0();
case -1815008835: return bem_handleTrue_0();
case -1480556491: return bem_toAny_0();
case 168135582: return bem_create_0();
case 2132420479: return bem_many_0();
case 1774726669: return bem_beginMap_0();
case -1359614197: return bem_classNameGet_0();
case 62664982: return bem_endList_0();
case -1044758745: return bem_serializeToString_0();
case -2077737637: return bem_beginList_0();
case 759496930: return bem_tagGet_0();
case 350691792: return bem_toString_0();
case 814334258: return bem_serializeContents_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -1642361296: return bem_print_0();
case -202912463: return bem_copy_0();
case 35574049: return bem_endMap_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 1365897346: return bem_serializationIteratorGet_0();
case -88952667: return bem_kvMid_0();
case 1161638424: return bem_new_0();
case -71162589: return bem_iteratorGet_0();
case -1711670377: return bem_hashGet_0();
case 2064925791: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case 1253708956: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -89657737: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_JsonParseLog_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_8_JsonParseLog_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_8_JsonParseLog();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_inst = (BEC_2_4_8_JsonParseLog) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_type;
}
}
}
