namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_3_BuildVar : BEC_2_6_6_SystemObject {
public BEC_2_5_3_BuildVar() { }
static BEC_2_5_3_BuildVar() { }
private static byte[] becc_BEC_2_5_3_BuildVar_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72};
private static byte[] becc_BEC_2_5_3_BuildVar_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_5_3_BuildVar_bevo_0 = (new BEC_2_4_3_MathInt(-1));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_0 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_0, 7));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_1 = {0x20,0x69,0x73,0x41,0x72,0x67};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_1, 6));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_2 = {0x20,0x69,0x73,0x54,0x6D,0x70,0x56,0x61,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_2, 9));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_3 = {0x20,0x6E,0x6F,0x74,0x44,0x65,0x63,0x6C,0x61,0x72,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_3, 12));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_4 = {0x20,0x69,0x73,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_4, 11));
public static new BEC_2_5_3_BuildVar bece_BEC_2_5_3_BuildVar_bevs_inst;

public static new BET_2_5_3_BuildVar bece_BEC_2_5_3_BuildVar_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_6_6_SystemObject bevp_refs;
public BEC_2_9_3_ContainerSet bevp_allCalls;
public BEC_2_4_6_TextString bevp_suffix;
public BEC_2_5_4_LogicBool bevp_isArg;
public BEC_2_5_4_LogicBool bevp_isAdded;
public BEC_2_5_4_LogicBool bevp_isTmpVar;
public BEC_2_5_4_LogicBool bevp_autoType;
public BEC_2_5_4_LogicBool bevp_isDeclared;
public BEC_2_5_4_LogicBool bevp_isProperty;
public BEC_2_4_3_MathInt bevp_numAssigns;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_4_3_MathInt bevp_vpos;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_5_4_LogicBool bevp_isThis;
public BEC_2_5_4_LogicBool bevp_implied;
public BEC_2_4_3_MathInt bevp_maxCpos;
public BEC_2_4_3_MathInt bevp_minCpos;
public BEC_2_4_6_TextString bevp_nativeName;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_4_MathInts bevt_0_tmpany_phold = null;
bevp_isArg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isTmpVar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_autoType = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isDeclared = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_isProperty = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_numAssigns = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isTyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_vpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_isSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_implied = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_maxCpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevt_0_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevp_minCpos = bevt_0_tmpany_phold.bem_maxGet_0();
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_synNew_1(BEC_2_5_3_BuildVar beva_full) {
bevp_isArg = beva_full.bem_isArgGet_0();
bevp_name = beva_full.bem_nameGet_0();
bevp_isAdded = beva_full.bem_isAddedGet_0();
bevp_isTmpVar = beva_full.bem_isTmpVarGet_0();
bevp_isProperty = beva_full.bem_isPropertyGet_0();
bevp_numAssigns = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_vpos = beva_full.bem_vposGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
bevp_isThis = beva_full.bem_isThisGet_0();
bevp_implied = beva_full.bem_impliedGet_0();
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_addCall_1(BEC_2_5_4_BuildNode beva_call) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_allCalls == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevp_allCalls = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
} /* Line: 239 */
bevp_allCalls.bem_addValue_1(beva_call);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxCposGet_0() {
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_0;
if (bevp_maxCpos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 245 */ {
return bevp_maxCpos;
} /* Line: 245 */
bevt_0_tmpany_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
 /* Line: 246 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 246 */ {
bevl_n = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_6_tmpany_phold = bevl_n.bemd_0(1203209953);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-1994281889);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(1561208327, bevp_maxCpos);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 247 */ {
bevt_7_tmpany_phold = bevl_n.bemd_0(1203209953);
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bemd_0(-1994281889);
} /* Line: 248 */
} /* Line: 247 */
 else  /* Line: 246 */ {
break;
} /* Line: 246 */
} /* Line: 246 */
return bevp_maxCpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_minCposGet_0() {
BEC_2_4_3_MathInt bevl_bigun = null;
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_4_4_MathInts bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevl_bigun = bevt_1_tmpany_phold.bem_maxGet_0();
if (bevp_minCpos.bevi_int < bevl_bigun.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 257 */ {
return bevp_minCpos;
} /* Line: 257 */
bevt_0_tmpany_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
 /* Line: 258 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 258 */ {
bevl_n = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_6_tmpany_phold = bevl_n.bemd_0(1203209953);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-1994281889);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(727421466, bevp_minCpos);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 259 */ {
bevt_7_tmpany_phold = bevl_n.bemd_0(1203209953);
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bemd_0(-1994281889);
} /* Line: 260 */
} /* Line: 259 */
 else  /* Line: 258 */ {
break;
} /* Line: 258 */
} /* Line: 258 */
return bevp_minCpos;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_ret = bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_1;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 269 */
if (bevp_isArg.bevi_bool) /* Line: 271 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_2;
bevl_ret = bevl_ret.bem_add_1(bevt_4_tmpany_phold);
} /* Line: 272 */
if (bevp_isTmpVar.bevi_bool) /* Line: 274 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_3;
bevl_ret = bevl_ret.bem_add_1(bevt_5_tmpany_phold);
} /* Line: 275 */
if (bevp_isDeclared.bevi_bool) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_4;
bevl_ret = bevl_ret.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 278 */
if (bevp_isProperty.bevi_bool) /* Line: 280 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_3_BuildVar_bevo_5;
bevl_ret = bevl_ret.bem_add_1(bevt_8_tmpany_phold);
} /* Line: 281 */
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_3_BuildVar bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_refsGet_0() {
return bevp_refs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_refsGetDirect_0() {
return bevp_refs;
} /*method end*/
public BEC_2_5_3_BuildVar bem_refsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_refs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_refsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_refs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_allCallsGet_0() {
return bevp_allCalls;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_allCallsGetDirect_0() {
return bevp_allCalls;
} /*method end*/
public BEC_2_5_3_BuildVar bem_allCallsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allCalls = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_allCallsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allCalls = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_suffixGet_0() {
return bevp_suffix;
} /*method end*/
public BEC_2_4_6_TextString bem_suffixGetDirect_0() {
return bevp_suffix;
} /*method end*/
public BEC_2_5_3_BuildVar bem_suffixSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_suffix = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_suffixSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_suffix = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isArgGet_0() {
return bevp_isArg;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isArgGetDirect_0() {
return bevp_isArg;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isArgSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isArg = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isArgSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isArg = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAddedGet_0() {
return bevp_isAdded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAddedGetDirect_0() {
return bevp_isAdded;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isAddedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTmpVarGet_0() {
return bevp_isTmpVar;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTmpVarGetDirect_0() {
return bevp_isTmpVar;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTmpVarSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isTmpVar = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTmpVarSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isTmpVar = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_autoTypeGet_0() {
return bevp_autoType;
} /*method end*/
public BEC_2_5_4_LogicBool bem_autoTypeGetDirect_0() {
return bevp_autoType;
} /*method end*/
public BEC_2_5_3_BuildVar bem_autoTypeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_autoType = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_autoTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_autoType = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDeclaredGet_0() {
return bevp_isDeclared;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDeclaredGetDirect_0() {
return bevp_isDeclared;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isDeclaredSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isDeclared = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isDeclaredSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isDeclared = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isPropertyGet_0() {
return bevp_isProperty;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isPropertyGetDirect_0() {
return bevp_isProperty;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isPropertySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isProperty = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isPropertySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isProperty = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numAssignsGet_0() {
return bevp_numAssigns;
} /*method end*/
public BEC_2_4_3_MathInt bem_numAssignsGetDirect_0() {
return bevp_numAssigns;
} /*method end*/
public BEC_2_5_3_BuildVar bem_numAssignsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numAssigns = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_numAssignsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numAssigns = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGetDirect_0() {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTypedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vposGet_0() {
return bevp_vpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_vposGetDirect_0() {
return bevp_vpos;
} /*method end*/
public BEC_2_5_3_BuildVar bem_vposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_vposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGetDirect_0() {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isSelfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGet_0() {
return bevp_isThis;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGetDirect_0() {
return bevp_isThis;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isThisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isThisSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_impliedGet_0() {
return bevp_implied;
} /*method end*/
public BEC_2_5_4_LogicBool bem_impliedGetDirect_0() {
return bevp_implied;
} /*method end*/
public BEC_2_5_3_BuildVar bem_impliedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_implied = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_impliedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_implied = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxCposGetDirect_0() {
return bevp_maxCpos;
} /*method end*/
public BEC_2_5_3_BuildVar bem_maxCposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_maxCposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_minCposGetDirect_0() {
return bevp_minCpos;
} /*method end*/
public BEC_2_5_3_BuildVar bem_minCposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_minCposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nativeNameGet_0() {
return bevp_nativeName;
} /*method end*/
public BEC_2_4_6_TextString bem_nativeNameGetDirect_0() {
return bevp_nativeName;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nativeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nativeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nativeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nativeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 216, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 238, 238, 239, 241, 245, 245, 245, 245, 246, 0, 246, 246, 247, 247, 247, 248, 248, 251, 255, 255, 257, 257, 257, 258, 0, 258, 258, 259, 259, 259, 260, 260, 263, 267, 268, 268, 269, 269, 269, 269, 272, 272, 275, 275, 277, 277, 278, 278, 281, 281, 283, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 79, 84, 85, 87, 100, 101, 106, 107, 109, 109, 112, 114, 115, 116, 117, 119, 120, 127, 140, 141, 142, 147, 148, 150, 150, 153, 155, 156, 157, 158, 160, 161, 168, 181, 182, 187, 188, 189, 190, 191, 194, 195, 198, 199, 201, 206, 207, 208, 211, 212, 214, 217, 220, 223, 227, 231, 234, 237, 241, 245, 248, 251, 255, 259, 262, 265, 269, 273, 276, 279, 283, 287, 290, 293, 297, 301, 304, 307, 311, 315, 318, 321, 325, 329, 332, 335, 339, 343, 346, 349, 353, 357, 360, 363, 367, 371, 374, 377, 381, 385, 388, 391, 395, 399, 402, 405, 409, 413, 416, 419, 423, 427, 430, 433, 437, 441, 444, 447, 451, 455, 458, 462, 466, 469, 473, 477, 480, 483, 487};
/* BEGIN LINEINFO 
assign 1 203 45
new 0 203 45
assign 1 204 46
new 0 204 46
assign 1 205 47
new 0 205 47
assign 1 206 48
new 0 206 48
assign 1 207 49
new 0 207 49
assign 1 208 50
new 0 208 50
assign 1 209 51
new 0 209 51
assign 1 210 52
new 0 210 52
assign 1 211 53
new 0 211 53
assign 1 212 54
new 0 212 54
assign 1 213 55
new 0 213 55
assign 1 214 56
new 0 214 56
assign 1 215 57
new 0 215 57
assign 1 216 58
new 0 216 58
assign 1 216 59
maxGet 0 216 59
assign 1 223 63
isArgGet 0 223 63
assign 1 224 64
nameGet 0 224 64
assign 1 225 65
isAddedGet 0 225 65
assign 1 226 66
isTmpVarGet 0 226 66
assign 1 227 67
isPropertyGet 0 227 67
assign 1 228 68
new 0 228 68
assign 1 229 69
namepathGet 0 229 69
assign 1 230 70
isTypedGet 0 230 70
assign 1 231 71
vposGet 0 231 71
assign 1 232 72
isSelfGet 0 232 72
assign 1 233 73
isThisGet 0 233 73
assign 1 234 74
impliedGet 0 234 74
assign 1 238 79
undef 1 238 84
assign 1 239 85
new 0 239 85
addValue 1 241 87
assign 1 245 100
new 0 245 100
assign 1 245 101
greater 1 245 106
return 1 245 107
assign 1 246 109
setIteratorGet 0 0 109
assign 1 246 112
hasNextGet 0 246 112
assign 1 246 114
nextGet 0 246 114
assign 1 247 115
heldGet 0 247 115
assign 1 247 116
cposGet 0 247 116
assign 1 247 117
greater 1 247 117
assign 1 248 119
heldGet 0 248 119
assign 1 248 120
cposGet 0 248 120
return 1 251 127
assign 1 255 140
new 0 255 140
assign 1 255 141
maxGet 0 255 141
assign 1 257 142
lesser 1 257 147
return 1 257 148
assign 1 258 150
setIteratorGet 0 0 150
assign 1 258 153
hasNextGet 0 258 153
assign 1 258 155
nextGet 0 258 155
assign 1 259 156
heldGet 0 259 156
assign 1 259 157
cposGet 0 259 157
assign 1 259 158
lesser 1 259 158
assign 1 260 160
heldGet 0 260 160
assign 1 260 161
cposGet 0 260 161
return 1 263 168
assign 1 267 181
classNameGet 0 267 181
assign 1 268 182
def 1 268 187
assign 1 269 188
new 0 269 188
assign 1 269 189
add 1 269 189
assign 1 269 190
toString 0 269 190
assign 1 269 191
add 1 269 191
assign 1 272 194
new 0 272 194
assign 1 272 195
add 1 272 195
assign 1 275 198
new 0 275 198
assign 1 275 199
add 1 275 199
assign 1 277 201
not 0 277 206
assign 1 278 207
new 0 278 207
assign 1 278 208
add 1 278 208
assign 1 281 211
new 0 281 211
assign 1 281 212
add 1 281 212
return 1 283 214
return 1 0 217
return 1 0 220
assign 1 0 223
assign 1 0 227
return 1 0 231
return 1 0 234
assign 1 0 237
assign 1 0 241
return 1 0 245
return 1 0 248
assign 1 0 251
assign 1 0 255
return 1 0 259
return 1 0 262
assign 1 0 265
assign 1 0 269
return 1 0 273
return 1 0 276
assign 1 0 279
assign 1 0 283
return 1 0 287
return 1 0 290
assign 1 0 293
assign 1 0 297
return 1 0 301
return 1 0 304
assign 1 0 307
assign 1 0 311
return 1 0 315
return 1 0 318
assign 1 0 321
assign 1 0 325
return 1 0 329
return 1 0 332
assign 1 0 335
assign 1 0 339
return 1 0 343
return 1 0 346
assign 1 0 349
assign 1 0 353
return 1 0 357
return 1 0 360
assign 1 0 363
assign 1 0 367
return 1 0 371
return 1 0 374
assign 1 0 377
assign 1 0 381
return 1 0 385
return 1 0 388
assign 1 0 391
assign 1 0 395
return 1 0 399
return 1 0 402
assign 1 0 405
assign 1 0 409
return 1 0 413
return 1 0 416
assign 1 0 419
assign 1 0 423
return 1 0 427
return 1 0 430
assign 1 0 433
assign 1 0 437
return 1 0 441
return 1 0 444
assign 1 0 447
assign 1 0 451
return 1 0 455
assign 1 0 458
assign 1 0 462
return 1 0 466
assign 1 0 469
assign 1 0 473
return 1 0 477
return 1 0 480
assign 1 0 483
assign 1 0 487
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1855411436: return bem_allCallsGetDirect_0();
case 1196099876: return bem_echo_0();
case -888502976: return bem_print_0();
case -170941956: return bem_serializeToString_0();
case 500067047: return bem_namepathGetDirect_0();
case 1525892333: return bem_vposGetDirect_0();
case 888454474: return bem_isThisGetDirect_0();
case -124728564: return bem_isPropertyGet_0();
case 1989485633: return bem_many_0();
case -1674383195: return bem_isPropertyGetDirect_0();
case 440928116: return bem_minCposGet_0();
case -1222154604: return bem_tagGet_0();
case -1093907847: return bem_isDeclaredGetDirect_0();
case -494057832: return bem_serializationIteratorGet_0();
case 545794769: return bem_maxCposGet_0();
case 1434201475: return bem_namepathGet_0();
case 1505163707: return bem_minCposGetDirect_0();
case -279588908: return bem_nameGetDirect_0();
case -1309803768: return bem_isArgGet_0();
case -294806467: return bem_create_0();
case 213564239: return bem_copy_0();
case 1581774791: return bem_maxCposGetDirect_0();
case -1916548323: return bem_once_0();
case -242463884: return bem_fieldIteratorGet_0();
case -800988760: return bem_refsGet_0();
case -764659804: return bem_nativeNameGetDirect_0();
case 964182225: return bem_autoTypeGetDirect_0();
case -1627887364: return bem_isTypedGetDirect_0();
case -1230714712: return bem_classNameGet_0();
case -1187488547: return bem_isAddedGetDirect_0();
case -224135739: return bem_isTypedGet_0();
case -671191297: return bem_serializeContents_0();
case 1483979384: return bem_vposGet_0();
case -1342633655: return bem_hashGet_0();
case -1297985879: return bem_fieldNamesGet_0();
case 1418348540: return bem_iteratorGet_0();
case -1388117637: return bem_refsGetDirect_0();
case 385546604: return bem_isArgGetDirect_0();
case -1925247459: return bem_sourceFileNameGet_0();
case 1071443469: return bem_impliedGetDirect_0();
case 971367304: return bem_autoTypeGet_0();
case -1957459239: return bem_isSelfGetDirect_0();
case 1832806152: return bem_toString_0();
case -928625522: return bem_impliedGet_0();
case -1995305521: return bem_isThisGet_0();
case -1652530811: return bem_suffixGetDirect_0();
case -785325871: return bem_nativeNameGet_0();
case -104788482: return bem_isAddedGet_0();
case -302817860: return bem_deserializeClassNameGet_0();
case 1797020795: return bem_toAny_0();
case 1166664450: return bem_nameGet_0();
case -731347949: return bem_numAssignsGetDirect_0();
case 1152694335: return bem_isDeclaredGet_0();
case -1736756100: return bem_isSelfGet_0();
case -1680218958: return bem_isTmpVarGetDirect_0();
case -438918553: return bem_numAssignsGet_0();
case -1628841870: return bem_new_0();
case -102555909: return bem_suffixGet_0();
case -1324491976: return bem_allCallsGet_0();
case -915520293: return bem_isTmpVarGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -152296894: return bem_equals_1(bevd_0);
case 1602348302: return bem_sameObject_1(bevd_0);
case 428764681: return bem_isAddedSetDirect_1(bevd_0);
case 151338251: return bem_isArgSet_1(bevd_0);
case -395616432: return bem_otherClass_1(bevd_0);
case 333840068: return bem_allCallsSetDirect_1(bevd_0);
case -207995463: return bem_suffixSetDirect_1(bevd_0);
case 1958873070: return bem_synNew_1((BEC_2_5_3_BuildVar) bevd_0);
case 79810732: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1412070496: return bem_isTmpVarSetDirect_1(bevd_0);
case 356429816: return bem_namepathSetDirect_1(bevd_0);
case -118558475: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 93271673: return bem_nameSet_1(bevd_0);
case 1958723357: return bem_refsSet_1(bevd_0);
case -1434169623: return bem_numAssignsSet_1(bevd_0);
case 388897131: return bem_isTypedSetDirect_1(bevd_0);
case -1882811997: return bem_namepathSet_1(bevd_0);
case 945449374: return bem_notEquals_1(bevd_0);
case 1188087922: return bem_refsSetDirect_1(bevd_0);
case -1229364216: return bem_nameSetDirect_1(bevd_0);
case 1387278567: return bem_isTmpVarSet_1(bevd_0);
case -451712980: return bem_minCposSetDirect_1(bevd_0);
case 936942966: return bem_undefined_1(bevd_0);
case -2046043947: return bem_copyTo_1(bevd_0);
case -1611953665: return bem_isPropertySetDirect_1(bevd_0);
case -2137670210: return bem_isAddedSet_1(bevd_0);
case -1138133299: return bem_isThisSet_1(bevd_0);
case -3488147: return bem_isDeclaredSet_1(bevd_0);
case 245812631: return bem_isPropertySet_1(bevd_0);
case -451883493: return bem_vposSetDirect_1(bevd_0);
case -1949013650: return bem_allCallsSet_1(bevd_0);
case 1506287098: return bem_isSelfSetDirect_1(bevd_0);
case 346995129: return bem_def_1(bevd_0);
case 1884264461: return bem_numAssignsSetDirect_1(bevd_0);
case -1492350909: return bem_isTypedSet_1(bevd_0);
case -258458975: return bem_isArgSetDirect_1(bevd_0);
case 562477482: return bem_nativeNameSetDirect_1(bevd_0);
case -1811224480: return bem_sameType_1(bevd_0);
case -1204293584: return bem_vposSet_1(bevd_0);
case 1962234128: return bem_isThisSetDirect_1(bevd_0);
case -810647371: return bem_sameClass_1(bevd_0);
case -743007276: return bem_minCposSet_1(bevd_0);
case -1126847197: return bem_autoTypeSetDirect_1(bevd_0);
case -788622974: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1345095935: return bem_defined_1(bevd_0);
case -148550319: return bem_suffixSet_1(bevd_0);
case 193832409: return bem_autoTypeSet_1(bevd_0);
case 1170894522: return bem_addCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 983695615: return bem_maxCposSetDirect_1(bevd_0);
case 211598652: return bem_isDeclaredSetDirect_1(bevd_0);
case 83181817: return bem_undef_1(bevd_0);
case -614976168: return bem_isSelfSet_1(bevd_0);
case 55802682: return bem_nativeNameSet_1(bevd_0);
case -1796596677: return bem_otherType_1(bevd_0);
case 1495593147: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1464619171: return bem_impliedSet_1(bevd_0);
case 851871649: return bem_impliedSetDirect_1(bevd_0);
case 1674699657: return bem_maxCposSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -174395426: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1117645207: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1434652185: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2038467728: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 6185266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 34704188: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1515774718: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_5_3_BuildVar_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_3_BuildVar_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_3_BuildVar();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_inst = (BEC_2_5_3_BuildVar) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_type;
}
}
}
