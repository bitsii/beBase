namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_3_BuildVar : BEC_2_6_6_SystemObject {
public BEC_2_5_3_BuildVar() { }
static BEC_2_5_3_BuildVar() { }
private static byte[] becc_BEC_2_5_3_BuildVar_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72};
private static byte[] becc_BEC_2_5_3_BuildVar_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_5_3_BuildVar_bevo_0 = (new BEC_2_4_3_MathInt(-1));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_0 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_0, 7));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_1 = {0x20,0x69,0x73,0x41,0x72,0x67};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_1, 6));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_2 = {0x20,0x69,0x73,0x54,0x6D,0x70,0x56,0x61,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_2, 9));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_3 = {0x20,0x6E,0x6F,0x74,0x44,0x65,0x63,0x6C,0x61,0x72,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_3, 12));
private static byte[] bece_BEC_2_5_3_BuildVar_bels_4 = {0x20,0x69,0x73,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_3_BuildVar_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_3_BuildVar_bels_4, 11));
public static new BEC_2_5_3_BuildVar bece_BEC_2_5_3_BuildVar_bevs_inst;

public static new BET_2_5_3_BuildVar bece_BEC_2_5_3_BuildVar_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_6_6_SystemObject bevp_refs;
public BEC_2_9_3_ContainerSet bevp_allCalls;
public BEC_2_4_6_TextString bevp_suffix;
public BEC_2_5_4_LogicBool bevp_isArg;
public BEC_2_5_4_LogicBool bevp_isAdded;
public BEC_2_5_4_LogicBool bevp_isTmpVar;
public BEC_2_5_4_LogicBool bevp_autoType;
public BEC_2_5_4_LogicBool bevp_isDeclared;
public BEC_2_5_4_LogicBool bevp_isProperty;
public BEC_2_4_3_MathInt bevp_numAssigns;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_4_3_MathInt bevp_vpos;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_5_4_LogicBool bevp_isThis;
public BEC_2_5_4_LogicBool bevp_implied;
public BEC_2_4_3_MathInt bevp_maxCpos;
public BEC_2_4_3_MathInt bevp_minCpos;
public BEC_2_4_6_TextString bevp_nativeName;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_4_MathInts bevt_0_ta_ph = null;
bevp_isArg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isTmpVar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_autoType = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isDeclared = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_isProperty = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_numAssigns = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isTyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_vpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_isSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_implied = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_maxCpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevt_0_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevp_minCpos = bevt_0_ta_ph.bem_maxGet_0();
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_synNew_1(BEC_2_5_3_BuildVar beva_full) {
bevp_isArg = beva_full.bem_isArgGet_0();
bevp_name = beva_full.bem_nameGet_0();
bevp_isAdded = beva_full.bem_isAddedGet_0();
bevp_isTmpVar = beva_full.bem_isTmpVarGet_0();
bevp_isProperty = beva_full.bem_isPropertyGet_0();
bevp_numAssigns = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_vpos = beva_full.bem_vposGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
bevp_isThis = beva_full.bem_isThisGet_0();
bevp_implied = beva_full.bem_impliedGet_0();
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_addCall_1(BEC_2_5_4_BuildNode beva_call) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_allCalls == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 237*/ {
bevp_allCalls = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
} /* Line: 238*/
bevp_allCalls.bem_addValue_1(beva_call);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxCposGet_0() {
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_5_3_BuildVar_bevo_0;
if (bevp_maxCpos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 244*/ {
return bevp_maxCpos;
} /* Line: 244*/
bevt_0_ta_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
/* Line: 245*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 245*/ {
bevl_n = bevt_0_ta_loop.bem_nextGet_0();
bevt_6_ta_ph = bevl_n.bemd_0(1712678790);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(-1145906688);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(-802567181, bevp_maxCpos);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 246*/ {
bevt_7_ta_ph = bevl_n.bemd_0(1712678790);
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_7_ta_ph.bemd_0(-1145906688);
} /* Line: 247*/
} /* Line: 246*/
 else /* Line: 245*/ {
break;
} /* Line: 245*/
} /* Line: 245*/
return bevp_maxCpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_minCposGet_0() {
BEC_2_4_3_MathInt bevl_bigun = null;
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_4_4_MathInts bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevl_bigun = bevt_1_ta_ph.bem_maxGet_0();
if (bevp_minCpos.bevi_int < bevl_bigun.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 256*/ {
return bevp_minCpos;
} /* Line: 256*/
bevt_0_ta_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
/* Line: 257*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 257*/ {
bevl_n = bevt_0_ta_loop.bem_nextGet_0();
bevt_6_ta_ph = bevl_n.bemd_0(1712678790);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(-1145906688);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(1839800686, bevp_minCpos);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 258*/ {
bevt_7_ta_ph = bevl_n.bemd_0(1712678790);
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_7_ta_ph.bemd_0(-1145906688);
} /* Line: 259*/
} /* Line: 258*/
 else /* Line: 257*/ {
break;
} /* Line: 257*/
} /* Line: 257*/
return bevp_minCpos;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevl_ret = bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 267*/ {
bevt_2_ta_ph = bece_BEC_2_5_3_BuildVar_bevo_1;
bevt_1_ta_ph = bevl_ret.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = bevp_name.bem_toString_0();
bevl_ret = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
} /* Line: 268*/
if (bevp_isArg.bevi_bool)/* Line: 270*/ {
bevt_4_ta_ph = bece_BEC_2_5_3_BuildVar_bevo_2;
bevl_ret = bevl_ret.bem_add_1(bevt_4_ta_ph);
} /* Line: 271*/
if (bevp_isTmpVar.bevi_bool)/* Line: 273*/ {
bevt_5_ta_ph = bece_BEC_2_5_3_BuildVar_bevo_3;
bevl_ret = bevl_ret.bem_add_1(bevt_5_ta_ph);
} /* Line: 274*/
if (bevp_isDeclared.bevi_bool) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 276*/ {
bevt_7_ta_ph = bece_BEC_2_5_3_BuildVar_bevo_4;
bevl_ret = bevl_ret.bem_add_1(bevt_7_ta_ph);
} /* Line: 277*/
if (bevp_isProperty.bevi_bool)/* Line: 279*/ {
bevt_8_ta_ph = bece_BEC_2_5_3_BuildVar_bevo_5;
bevl_ret = bevl_ret.bem_add_1(bevt_8_ta_ph);
} /* Line: 280*/
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_3_BuildVar bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_refsGet_0() {
return bevp_refs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_refsGetDirect_0() {
return bevp_refs;
} /*method end*/
public BEC_2_5_3_BuildVar bem_refsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_refs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_refsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_refs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_allCallsGet_0() {
return bevp_allCalls;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_allCallsGetDirect_0() {
return bevp_allCalls;
} /*method end*/
public BEC_2_5_3_BuildVar bem_allCallsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allCalls = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_allCallsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allCalls = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_suffixGet_0() {
return bevp_suffix;
} /*method end*/
public BEC_2_4_6_TextString bem_suffixGetDirect_0() {
return bevp_suffix;
} /*method end*/
public BEC_2_5_3_BuildVar bem_suffixSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_suffix = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_suffixSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_suffix = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isArgGet_0() {
return bevp_isArg;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isArgGetDirect_0() {
return bevp_isArg;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isArgSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isArg = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isArgSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isArg = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAddedGet_0() {
return bevp_isAdded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAddedGetDirect_0() {
return bevp_isAdded;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isAddedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isAdded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isAddedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isAdded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTmpVarGet_0() {
return bevp_isTmpVar;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTmpVarGetDirect_0() {
return bevp_isTmpVar;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTmpVarSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isTmpVar = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTmpVarSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isTmpVar = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_autoTypeGet_0() {
return bevp_autoType;
} /*method end*/
public BEC_2_5_4_LogicBool bem_autoTypeGetDirect_0() {
return bevp_autoType;
} /*method end*/
public BEC_2_5_3_BuildVar bem_autoTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_autoType = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_autoTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_autoType = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDeclaredGet_0() {
return bevp_isDeclared;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDeclaredGetDirect_0() {
return bevp_isDeclared;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isDeclaredSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isDeclared = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isDeclaredSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isDeclared = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isPropertyGet_0() {
return bevp_isProperty;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isPropertyGetDirect_0() {
return bevp_isProperty;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isPropertySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isProperty = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isPropertySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isProperty = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numAssignsGet_0() {
return bevp_numAssigns;
} /*method end*/
public BEC_2_4_3_MathInt bem_numAssignsGetDirect_0() {
return bevp_numAssigns;
} /*method end*/
public BEC_2_5_3_BuildVar bem_numAssignsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_numAssigns = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_numAssignsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_numAssigns = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGetDirect_0() {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTypedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vposGet_0() {
return bevp_vpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_vposGetDirect_0() {
return bevp_vpos;
} /*method end*/
public BEC_2_5_3_BuildVar bem_vposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_vposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGetDirect_0() {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isSelfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGet_0() {
return bevp_isThis;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGetDirect_0() {
return bevp_isThis;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isThisSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isThisSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_impliedGet_0() {
return bevp_implied;
} /*method end*/
public BEC_2_5_4_LogicBool bem_impliedGetDirect_0() {
return bevp_implied;
} /*method end*/
public BEC_2_5_3_BuildVar bem_impliedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_implied = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_impliedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_implied = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxCposGetDirect_0() {
return bevp_maxCpos;
} /*method end*/
public BEC_2_5_3_BuildVar bem_maxCposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_maxCposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_minCposGetDirect_0() {
return bevp_minCpos;
} /*method end*/
public BEC_2_5_3_BuildVar bem_minCposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_minCposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nativeNameGet_0() {
return bevp_nativeName;
} /*method end*/
public BEC_2_4_6_TextString bem_nativeNameGetDirect_0() {
return bevp_nativeName;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nativeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nativeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nativeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nativeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 215, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 237, 237, 238, 240, 244, 244, 244, 244, 245, 0, 245, 245, 246, 246, 246, 247, 247, 250, 254, 254, 256, 256, 256, 257, 0, 257, 257, 258, 258, 258, 259, 259, 262, 266, 267, 267, 268, 268, 268, 268, 271, 271, 274, 274, 276, 276, 277, 277, 280, 280, 282, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 79, 84, 85, 87, 100, 101, 106, 107, 109, 109, 112, 114, 115, 116, 117, 119, 120, 127, 140, 141, 142, 147, 148, 150, 150, 153, 155, 156, 157, 158, 160, 161, 168, 181, 182, 187, 188, 189, 190, 191, 194, 195, 198, 199, 201, 206, 207, 208, 211, 212, 214, 217, 220, 223, 227, 231, 234, 237, 241, 245, 248, 251, 255, 259, 262, 265, 269, 273, 276, 279, 283, 287, 290, 293, 297, 301, 304, 307, 311, 315, 318, 321, 325, 329, 332, 335, 339, 343, 346, 349, 353, 357, 360, 363, 367, 371, 374, 377, 381, 385, 388, 391, 395, 399, 402, 405, 409, 413, 416, 419, 423, 427, 430, 433, 437, 441, 444, 447, 451, 455, 458, 462, 466, 469, 473, 477, 480, 483, 487};
/* BEGIN LINEINFO 
assign 1 202 45
new 0 202 45
assign 1 203 46
new 0 203 46
assign 1 204 47
new 0 204 47
assign 1 205 48
new 0 205 48
assign 1 206 49
new 0 206 49
assign 1 207 50
new 0 207 50
assign 1 208 51
new 0 208 51
assign 1 209 52
new 0 209 52
assign 1 210 53
new 0 210 53
assign 1 211 54
new 0 211 54
assign 1 212 55
new 0 212 55
assign 1 213 56
new 0 213 56
assign 1 214 57
new 0 214 57
assign 1 215 58
new 0 215 58
assign 1 215 59
maxGet 0 215 59
assign 1 222 63
isArgGet 0 222 63
assign 1 223 64
nameGet 0 223 64
assign 1 224 65
isAddedGet 0 224 65
assign 1 225 66
isTmpVarGet 0 225 66
assign 1 226 67
isPropertyGet 0 226 67
assign 1 227 68
new 0 227 68
assign 1 228 69
namepathGet 0 228 69
assign 1 229 70
isTypedGet 0 229 70
assign 1 230 71
vposGet 0 230 71
assign 1 231 72
isSelfGet 0 231 72
assign 1 232 73
isThisGet 0 232 73
assign 1 233 74
impliedGet 0 233 74
assign 1 237 79
undef 1 237 84
assign 1 238 85
new 0 238 85
addValue 1 240 87
assign 1 244 100
new 0 244 100
assign 1 244 101
greater 1 244 106
return 1 244 107
assign 1 245 109
setIteratorGet 0 0 109
assign 1 245 112
hasNextGet 0 245 112
assign 1 245 114
nextGet 0 245 114
assign 1 246 115
heldGet 0 246 115
assign 1 246 116
cposGet 0 246 116
assign 1 246 117
greater 1 246 117
assign 1 247 119
heldGet 0 247 119
assign 1 247 120
cposGet 0 247 120
return 1 250 127
assign 1 254 140
new 0 254 140
assign 1 254 141
maxGet 0 254 141
assign 1 256 142
lesser 1 256 147
return 1 256 148
assign 1 257 150
setIteratorGet 0 0 150
assign 1 257 153
hasNextGet 0 257 153
assign 1 257 155
nextGet 0 257 155
assign 1 258 156
heldGet 0 258 156
assign 1 258 157
cposGet 0 258 157
assign 1 258 158
lesser 1 258 158
assign 1 259 160
heldGet 0 259 160
assign 1 259 161
cposGet 0 259 161
return 1 262 168
assign 1 266 181
classNameGet 0 266 181
assign 1 267 182
def 1 267 187
assign 1 268 188
new 0 268 188
assign 1 268 189
add 1 268 189
assign 1 268 190
toString 0 268 190
assign 1 268 191
add 1 268 191
assign 1 271 194
new 0 271 194
assign 1 271 195
add 1 271 195
assign 1 274 198
new 0 274 198
assign 1 274 199
add 1 274 199
assign 1 276 201
not 0 276 206
assign 1 277 207
new 0 277 207
assign 1 277 208
add 1 277 208
assign 1 280 211
new 0 280 211
assign 1 280 212
add 1 280 212
return 1 282 214
return 1 0 217
return 1 0 220
assign 1 0 223
assign 1 0 227
return 1 0 231
return 1 0 234
assign 1 0 237
assign 1 0 241
return 1 0 245
return 1 0 248
assign 1 0 251
assign 1 0 255
return 1 0 259
return 1 0 262
assign 1 0 265
assign 1 0 269
return 1 0 273
return 1 0 276
assign 1 0 279
assign 1 0 283
return 1 0 287
return 1 0 290
assign 1 0 293
assign 1 0 297
return 1 0 301
return 1 0 304
assign 1 0 307
assign 1 0 311
return 1 0 315
return 1 0 318
assign 1 0 321
assign 1 0 325
return 1 0 329
return 1 0 332
assign 1 0 335
assign 1 0 339
return 1 0 343
return 1 0 346
assign 1 0 349
assign 1 0 353
return 1 0 357
return 1 0 360
assign 1 0 363
assign 1 0 367
return 1 0 371
return 1 0 374
assign 1 0 377
assign 1 0 381
return 1 0 385
return 1 0 388
assign 1 0 391
assign 1 0 395
return 1 0 399
return 1 0 402
assign 1 0 405
assign 1 0 409
return 1 0 413
return 1 0 416
assign 1 0 419
assign 1 0 423
return 1 0 427
return 1 0 430
assign 1 0 433
assign 1 0 437
return 1 0 441
return 1 0 444
assign 1 0 447
assign 1 0 451
return 1 0 455
assign 1 0 458
assign 1 0 462
return 1 0 466
assign 1 0 469
assign 1 0 473
return 1 0 477
return 1 0 480
assign 1 0 483
assign 1 0 487
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1623171331: return bem_isAddedGetDirect_0();
case -932925423: return bem_namepathGet_0();
case 531037237: return bem_nativeNameGet_0();
case -1552162755: return bem_isTypedGetDirect_0();
case -318274408: return bem_autoTypeGet_0();
case 1724132559: return bem_vposGetDirect_0();
case 1321300955: return bem_isArgGet_0();
case 48684490: return bem_echo_0();
case 872708376: return bem_toAny_0();
case -729615281: return bem_suffixGet_0();
case 1865983825: return bem_fieldNamesGet_0();
case -601703951: return bem_maxCposGet_0();
case -51065454: return bem_isAddedGet_0();
case -1533701006: return bem_serializeContents_0();
case -762026195: return bem_numAssignsGetDirect_0();
case 1914219791: return bem_isPropertyGet_0();
case 1271244678: return bem_allCallsGet_0();
case -1823446933: return bem_nameGetDirect_0();
case -1419115955: return bem_create_0();
case -166013833: return bem_tagGet_0();
case -274045520: return bem_isTmpVarGet_0();
case -504463013: return bem_minCposGet_0();
case 1092567697: return bem_impliedGet_0();
case -160735352: return bem_once_0();
case -804793948: return bem_vposGet_0();
case 1208354139: return bem_sourceFileNameGet_0();
case -1731662552: return bem_refsGetDirect_0();
case -2014542803: return bem_iteratorGet_0();
case -916206427: return bem_nameGet_0();
case -879159090: return bem_isThisGetDirect_0();
case -206043242: return bem_many_0();
case 200482591: return bem_autoTypeGetDirect_0();
case -1229803830: return bem_deserializeClassNameGet_0();
case 1953265694: return bem_isThisGet_0();
case -390338197: return bem_refsGet_0();
case 1882778775: return bem_fieldIteratorGet_0();
case 377176253: return bem_isSelfGet_0();
case 1713175313: return bem_numAssignsGet_0();
case 1200056076: return bem_serializationIteratorGet_0();
case -513819206: return bem_isArgGetDirect_0();
case 1371851164: return bem_maxCposGetDirect_0();
case 441197166: return bem_minCposGetDirect_0();
case 907276784: return bem_serializeToString_0();
case 2105848316: return bem_isTmpVarGetDirect_0();
case -144529205: return bem_impliedGetDirect_0();
case -1990292643: return bem_toString_0();
case 437089080: return bem_print_0();
case 1125571456: return bem_isSelfGetDirect_0();
case -1451048410: return bem_new_0();
case -2091041121: return bem_allCallsGetDirect_0();
case 2017345633: return bem_copy_0();
case -1658949122: return bem_isDeclaredGetDirect_0();
case -268410679: return bem_namepathGetDirect_0();
case -1895551764: return bem_nativeNameGetDirect_0();
case 1330976730: return bem_hashGet_0();
case 492426514: return bem_isPropertyGetDirect_0();
case -354285051: return bem_suffixGetDirect_0();
case -778417959: return bem_isDeclaredGet_0();
case 1463424675: return bem_isTypedGet_0();
case 1674575712: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1034402954: return bem_isSelfSetDirect_1(bevd_0);
case 19006386: return bem_impliedSet_1(bevd_0);
case 625481528: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2083238907: return bem_isThisSet_1(bevd_0);
case 1561328648: return bem_otherType_1(bevd_0);
case 29856816: return bem_isAddedSetDirect_1(bevd_0);
case 679718595: return bem_maxCposSetDirect_1(bevd_0);
case 1920998617: return bem_sameObject_1(bevd_0);
case 1596863802: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1533426746: return bem_isTmpVarSetDirect_1(bevd_0);
case 1484567824: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1517637963: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -363031228: return bem_synNew_1((BEC_2_5_3_BuildVar) bevd_0);
case 170216407: return bem_copyTo_1(bevd_0);
case 1501860300: return bem_suffixSet_1(bevd_0);
case -185383596: return bem_sameType_1(bevd_0);
case -993646510: return bem_isPropertySetDirect_1(bevd_0);
case -1688796873: return bem_minCposSet_1(bevd_0);
case -914398837: return bem_allCallsSet_1(bevd_0);
case -937124935: return bem_isDeclaredSet_1(bevd_0);
case 584123032: return bem_def_1(bevd_0);
case -139894740: return bem_nativeNameSet_1(bevd_0);
case 354557818: return bem_equals_1(bevd_0);
case -2118958006: return bem_nativeNameSetDirect_1(bevd_0);
case -996715537: return bem_maxCposSet_1(bevd_0);
case -1049665686: return bem_numAssignsSet_1(bevd_0);
case 140222233: return bem_vposSet_1(bevd_0);
case 1845933417: return bem_isTypedSetDirect_1(bevd_0);
case -817740045: return bem_refsSet_1(bevd_0);
case -1271261458: return bem_impliedSetDirect_1(bevd_0);
case 2122176784: return bem_undef_1(bevd_0);
case -1492564620: return bem_suffixSetDirect_1(bevd_0);
case -450019087: return bem_isAddedSet_1(bevd_0);
case -696659980: return bem_minCposSetDirect_1(bevd_0);
case -840953319: return bem_notEquals_1(bevd_0);
case 1740735993: return bem_namepathSetDirect_1(bevd_0);
case -439646315: return bem_isArgSet_1(bevd_0);
case 161134859: return bem_defined_1(bevd_0);
case -1911036200: return bem_refsSetDirect_1(bevd_0);
case -703518785: return bem_isThisSetDirect_1(bevd_0);
case 662840365: return bem_isTypedSet_1(bevd_0);
case 1344624799: return bem_nameSetDirect_1(bevd_0);
case -1822027791: return bem_otherClass_1(bevd_0);
case -429748502: return bem_autoTypeSetDirect_1(bevd_0);
case 1199058017: return bem_isSelfSet_1(bevd_0);
case 64937568: return bem_addCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1909668950: return bem_autoTypeSet_1(bevd_0);
case 313213503: return bem_isArgSetDirect_1(bevd_0);
case 1082109373: return bem_namepathSet_1(bevd_0);
case -67707835: return bem_isTmpVarSet_1(bevd_0);
case 208371481: return bem_allCallsSetDirect_1(bevd_0);
case -279352105: return bem_undefined_1(bevd_0);
case -768610100: return bem_vposSetDirect_1(bevd_0);
case 909810346: return bem_sameClass_1(bevd_0);
case 1258888420: return bem_nameSet_1(bevd_0);
case -1032083864: return bem_isDeclaredSetDirect_1(bevd_0);
case 1690610622: return bem_isPropertySet_1(bevd_0);
case 415562651: return bem_numAssignsSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1467883232: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 465709808: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 936076332: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -758649425: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 105253121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -29810702: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 175222937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_5_3_BuildVar_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_3_BuildVar_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_3_BuildVar();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_inst = (BEC_2_5_3_BuildVar) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_type;
}
}
}
