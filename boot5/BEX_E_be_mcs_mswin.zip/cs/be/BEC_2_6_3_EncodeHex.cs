namespace be {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeHex : BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeHex() { }
static BEC_2_6_3_EncodeHex() { }
private static byte[] becc_BEC_2_6_3_EncodeHex_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x65,0x78};
private static byte[] becc_BEC_2_6_3_EncodeHex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_3_EncodeHex_bels_0 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x68,0x65,0x78,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeHex_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeHex_bels_0, 26));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_6 = (new BEC_2_4_3_MathInt(2));
public static new BEC_2_6_3_EncodeHex bece_BEC_2_6_3_EncodeHex_bevs_inst;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_3_EncodeHex bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl_ac = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_cur = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_2_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_0;
bevt_1_tmpany_phold = bevl_ssz.bem_multiply_1(bevt_2_tmpany_phold);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
bevl_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 21 */ {
if (bevl_pos.bevi_int < bevl_ssz.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 21 */ {
beva_str.bem_getCode_2(bevl_pos, bevl_ac);
bevt_4_tmpany_phold = bevl_ac.bem_toHexString_1(bevl_cur);
bevl_r.bem_addValue_1(bevt_4_tmpany_phold);
bevl_pos.bevi_int++;
} /* Line: 21 */
 else  /* Line: 21 */ {
break;
} /* Line: 21 */
} /* Line: 21 */
return bevl_r;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pta = null;
BEC_2_4_6_TextString bevl_ptb = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_1;
if (bevl_ssz.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 30 */ {
return beva_str;
} /* Line: 31 */
bevt_4_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_2;
bevt_3_tmpany_phold = bevl_ssz.bem_modulus_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_3;
if (bevt_3_tmpany_phold.bevi_int != bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 33 */ {
bevt_8_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_4;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevl_ssz);
bevt_6_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 34 */
bevt_9_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_cur = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_5;
bevt_10_tmpany_phold = bevl_ssz.bem_divide_1(bevt_11_tmpany_phold);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_6;
bevt_12_tmpany_phold = bevl_ssz.bem_divide_1(bevt_13_tmpany_phold);
bevl_r.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_tb = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_14_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_pta = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ptb = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_15_tmpany_phold);
bevl_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 43 */ {
bevt_16_tmpany_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevl_tb.bem_next_1(bevl_pta);
bevl_tb.bem_next_1(bevl_ptb);
bevt_18_tmpany_phold = bevl_pta.bem_add_1(bevl_ptb);
bevt_17_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_tmpany_phold);
bevl_r.bem_setCodeUnchecked_2(bevl_pos, bevt_17_tmpany_phold);
bevl_pos.bevi_int++;
} /* Line: 47 */
 else  /* Line: 43 */ {
break;
} /* Line: 43 */
} /* Line: 43 */
return bevl_r;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 18, 19, 20, 20, 20, 21, 21, 21, 22, 23, 23, 21, 25, 29, 30, 30, 30, 31, 33, 33, 33, 33, 33, 34, 34, 34, 34, 36, 36, 37, 37, 37, 38, 38, 38, 39, 40, 40, 41, 41, 42, 43, 44, 45, 46, 46, 46, 47, 49};
public static new int[] bevs_smnlec
 = new int[] {36, 37, 38, 39, 40, 41, 42, 43, 46, 51, 52, 53, 54, 55, 61, 90, 91, 92, 97, 98, 100, 101, 102, 103, 108, 109, 110, 111, 112, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130, 132, 133, 134, 135, 136, 137, 143};
/* BEGIN LINEINFO 
assign 1 17 36
new 0 17 36
assign 1 18 37
new 0 18 37
assign 1 18 38
new 1 18 38
assign 1 19 39
sizeGet 0 19 39
assign 1 20 40
new 0 20 40
assign 1 20 41
multiply 1 20 41
assign 1 20 42
new 1 20 42
assign 1 21 43
new 0 21 43
assign 1 21 46
lesser 1 21 51
getCode 2 22 52
assign 1 23 53
toHexString 1 23 53
addValue 1 23 54
incrementValue 0 21 55
return 1 25 61
assign 1 29 90
sizeGet 0 29 90
assign 1 30 91
new 0 30 91
assign 1 30 92
lesser 1 30 97
return 1 31 98
assign 1 33 100
new 0 33 100
assign 1 33 101
modulus 1 33 101
assign 1 33 102
new 0 33 102
assign 1 33 103
notEquals 1 33 108
assign 1 34 109
new 0 34 109
assign 1 34 110
add 1 34 110
assign 1 34 111
new 1 34 111
throw 1 34 112
assign 1 36 114
new 0 36 114
assign 1 36 115
new 1 36 115
assign 1 37 116
new 0 37 116
assign 1 37 117
divide 1 37 117
assign 1 37 118
new 1 37 118
assign 1 38 119
new 0 38 119
assign 1 38 120
divide 1 38 120
sizeSet 1 38 121
assign 1 39 122
new 1 39 122
assign 1 40 123
new 0 40 123
assign 1 40 124
new 1 40 124
assign 1 41 125
new 0 41 125
assign 1 41 126
new 1 41 126
assign 1 42 127
new 0 42 127
assign 1 43 130
hasNextGet 0 43 130
next 1 44 132
next 1 45 133
assign 1 46 134
add 1 46 134
assign 1 46 135
hexNew 1 46 135
setCodeUnchecked 2 46 136
incrementValue 0 47 137
return 1 49 143
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 747222940: return bem_serializationIteratorGet_0();
case 774868823: return bem_many_0();
case 138118576: return bem_classNameGet_0();
case 173912112: return bem_iteratorGet_0();
case 1826655669: return bem_echo_0();
case 591133328: return bem_once_0();
case 169016919: return bem_deserializeClassNameGet_0();
case 156988171: return bem_toAny_0();
case 1030306077: return bem_hashGet_0();
case -751534347: return bem_tagGet_0();
case 441873246: return bem_fieldIteratorGet_0();
case 1804394239: return bem_create_0();
case 86234609: return bem_print_0();
case 605463834: return bem_sourceFileNameGet_0();
case 1651099395: return bem_copy_0();
case 364146106: return bem_toString_0();
case -814108194: return bem_default_0();
case -1694865880: return bem_serializeToString_0();
case 1232567589: return bem_new_0();
case 1335363828: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -293276429: return bem_undefined_1(bevd_0);
case 143426895: return bem_undef_1(bevd_0);
case 93062119: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case 478852787: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case 233607642: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 280312858: return bem_sameObject_1(bevd_0);
case -66688367: return bem_sameClass_1(bevd_0);
case -2077086955: return bem_sameType_1(bevd_0);
case -548232463: return bem_copyTo_1(bevd_0);
case -1790149278: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1049342566: return bem_equals_1(bevd_0);
case 1022281941: return bem_defined_1(bevd_0);
case 818668120: return bem_def_1(bevd_0);
case 1388122193: return bem_otherClass_1(bevd_0);
case -956577031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1209387497: return bem_otherType_1(bevd_0);
case -729372880: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2078921482: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -936134816: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -265807180: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1675250987: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1991243589: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2096067718: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2037027110: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 808469705: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeHex_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_3_EncodeHex_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_3_EncodeHex();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst = (BEC_2_6_3_EncodeHex) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
}
}
}
