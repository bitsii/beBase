namespace be {
/* IO:File: source/build/Pass10.be */
public sealed class BEC_3_5_5_6_BuildVisitPass10 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass10() { }
static BEC_3_5_5_6_BuildVisitPass10() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x30};
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x30,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitPass10_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_1 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_2 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_3 = {0x61,0x6E,0x63,0x68,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
public static new BEC_3_5_5_6_BuildVisitPass10 bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;

public static new BET_3_5_5_6_BuildVisitPass10 bece_BEC_3_5_5_6_BuildVisitPass10_bevs_type;

public BEC_2_6_6_SystemObject bem_condCall_2(BEC_2_6_6_SystemObject beva_condany, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_acc = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_5_4_BuildCall bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl_cnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = (BEC_2_5_4_BuildCall) (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_cnode.bemd_1(-718928743, bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_cnode.bemd_1(-333229926, bevt_1_tmpany_phold);
bevl_acc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_acc.bemd_1(-333229926, bevt_2_tmpany_phold);
bevl_acc.bemd_1(-718928743, beva_condany);
bevl_cnode.bemd_1(-1940917614, bevl_acc);
bevt_3_tmpany_phold = bevl_cnode.bemd_0(551897597);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_0));
bevt_3_tmpany_phold.bemd_1(1970413721, bevt_4_tmpany_phold);
bevl_nnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nnode.bemd_1(-333229926, beva_value);
bevl_cnode.bemd_1(-1940917614, bevl_nnode);
return bevl_cnode;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_anchor = null;
BEC_2_6_6_SystemObject bevl_condany = null;
BEC_2_6_6_SystemObject bevl_cvnp = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_rinode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_77_tmpany_phold = null;
bevt_4_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_5_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_4_tmpany_phold.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 31 */ {
bevt_8_tmpany_phold = beva_node.bem_containedGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_lengthGet_0();
bevt_9_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitPass10_bevo_0;
if (bevt_7_tmpany_phold.bevi_int == bevt_9_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 31 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 31 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 31 */
 else  /* Line: 31 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 31 */ {
bevt_13_tmpany_phold = beva_node.bem_containedGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_firstGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-2064042825);
bevt_14_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(-886218051, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 31 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 31 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 31 */
 else  /* Line: 31 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 31 */ {
bevt_16_tmpany_phold = beva_node.bem_containedGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_firstGet_0();
beva_node.bem_takeContents_1((BEC_2_5_4_BuildNode) bevt_15_tmpany_phold );
return beva_node;
} /* Line: 33 */
bevt_18_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_18_tmpany_phold.bevi_int == bevt_19_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 36 */ {
bevt_20_tmpany_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_20_tmpany_phold);
beva_node.bem_syncVariable_1(this);
} /* Line: 38 */
bevt_22_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_23_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_22_tmpany_phold.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 41 */ {
bevt_26_tmpany_phold = beva_node.bem_heldGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(1956316046);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_1(-886218051, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 41 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 41 */ {
bevt_30_tmpany_phold = beva_node.bem_heldGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(1956316046);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_2));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(-886218051, bevt_31_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 41 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 41 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 41 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 41 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 41 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 41 */
 else  /* Line: 41 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 41 */ {
bevl_anchor = beva_node.bem_anchorGet_0();
bevl_condany = bevl_anchor.bemd_0(-213805904);
if (bevl_condany == null) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_3));
bevl_condany = bevl_anchor.bemd_2(-1679100316, bevt_33_tmpany_phold, bevp_build);
bevt_34_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_condany.bemd_1(332875154, bevt_34_tmpany_phold);
bevl_cvnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_4));
bevl_cvnp.bemd_1(-1424005749, bevt_35_tmpany_phold);
bevl_condany.bemd_1(1274994571, bevl_cvnp);
bevl_anchor.bemd_1(-393298415, bevl_condany);
} /* Line: 52 */
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_36_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-333229926, bevt_36_tmpany_phold);
bevl_inode.bemd_1(845344653, beva_node);
bevl_rinode = bevl_inode;
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(845344653, beva_node);
bevt_37_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-333229926, bevt_37_tmpany_phold);
bevl_inode.bemd_1(-1940917614, bevl_pnode);
bevt_39_tmpany_phold = beva_node.bem_containedGet_0();
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_firstGet_0();
bevl_pnode.bemd_1(-1940917614, bevt_38_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(845344653, beva_node);
bevt_40_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-333229926, bevt_40_tmpany_phold);
bevl_inode.bemd_1(-1940917614, bevl_bnode);
bevt_43_tmpany_phold = beva_node.bem_heldGet_0();
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_0(1956316046);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_1(-886218051, bevt_44_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_41_tmpany_phold).bevi_bool) /* Line: 73 */ {
bevt_46_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_45_tmpany_phold = bem_condCall_2(bevl_condany, bevt_46_tmpany_phold);
bevl_bnode.bemd_1(-1940917614, bevt_45_tmpany_phold);
} /* Line: 74 */
 else  /* Line: 76 */ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(845344653, beva_node);
bevt_47_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-333229926, bevt_47_tmpany_phold);
bevl_inode.bemd_1(-393298415, bevl_condany);
bevl_bnode.bemd_1(-1940917614, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(845344653, beva_node);
bevt_48_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-333229926, bevt_48_tmpany_phold);
bevl_inode.bemd_1(-1940917614, bevl_pnode);
bevt_49_tmpany_phold = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(-1940917614, bevt_49_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(845344653, beva_node);
bevt_50_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-333229926, bevt_50_tmpany_phold);
bevl_inode.bemd_1(-1940917614, bevl_bnode);
bevt_52_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_51_tmpany_phold = bem_condCall_2(bevl_condany, bevt_52_tmpany_phold);
bevl_bnode.bemd_1(-1940917614, bevt_51_tmpany_phold);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(845344653, beva_node);
bevt_53_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-333229926, bevt_53_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(845344653, beva_node);
bevt_54_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-333229926, bevt_54_tmpany_phold);
bevt_56_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_55_tmpany_phold = bem_condCall_2(bevl_condany, bevt_56_tmpany_phold);
bevl_bnode.bemd_1(-1940917614, bevt_55_tmpany_phold);
bevl_enode.bemd_1(-1940917614, bevl_bnode);
bevl_inode.bemd_1(-1940917614, bevl_enode);
} /* Line: 103 */
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(845344653, beva_node);
bevt_57_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-333229926, bevt_57_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(845344653, beva_node);
bevt_58_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-333229926, bevt_58_tmpany_phold);
bevl_rinode.bemd_1(-1940917614, bevl_enode);
bevl_enode.bemd_1(-1940917614, bevl_bnode);
bevt_61_tmpany_phold = beva_node.bem_heldGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(1956316046);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_1(-886218051, bevt_62_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 115 */ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(845344653, beva_node);
bevt_63_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-333229926, bevt_63_tmpany_phold);
bevl_inode.bemd_1(-393298415, bevl_condany);
bevl_bnode.bemd_1(-1940917614, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(845344653, beva_node);
bevt_64_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-333229926, bevt_64_tmpany_phold);
bevl_inode.bemd_1(-1940917614, bevl_pnode);
bevt_65_tmpany_phold = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(-1940917614, bevt_65_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(845344653, beva_node);
bevt_66_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-333229926, bevt_66_tmpany_phold);
bevl_inode.bemd_1(-1940917614, bevl_bnode);
bevt_68_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_67_tmpany_phold = bem_condCall_2(bevl_condany, bevt_68_tmpany_phold);
bevl_bnode.bemd_1(-1940917614, bevt_67_tmpany_phold);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(845344653, beva_node);
bevt_69_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-333229926, bevt_69_tmpany_phold);
bevl_inode.bemd_1(-1940917614, bevl_enode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(845344653, beva_node);
bevt_70_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-333229926, bevt_70_tmpany_phold);
bevt_72_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_71_tmpany_phold = bem_condCall_2(bevl_condany, bevt_72_tmpany_phold);
bevl_bnode.bemd_1(-1940917614, bevt_71_tmpany_phold);
bevl_enode.bemd_1(-1940917614, bevl_bnode);
} /* Line: 141 */
 else  /* Line: 142 */ {
bevt_74_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_73_tmpany_phold = bem_condCall_2(bevl_condany, bevt_74_tmpany_phold);
bevl_bnode.bemd_1(-1940917614, bevt_73_tmpany_phold);
} /* Line: 143 */
bevl_anchor.bemd_1(1341860494, bevl_rinode);
beva_node.bem_containedSet_1(null);
bevt_75_tmpany_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_75_tmpany_phold);
beva_node.bem_heldSet_1(bevl_condany);
beva_node.bem_syncAddVariable_0();
bevt_76_tmpany_phold = bevl_rinode.bemd_0(-1739483137);
return (BEC_2_5_4_BuildNode) bevt_76_tmpany_phold;
} /* Line: 152 */
bevt_77_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_77_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 17, 17, 18, 18, 19, 20, 20, 21, 22, 23, 23, 23, 24, 25, 26, 27, 31, 31, 31, 31, 31, 31, 31, 31, 31, 0, 0, 0, 31, 31, 31, 31, 31, 0, 0, 0, 32, 32, 32, 33, 36, 36, 36, 36, 37, 37, 38, 41, 41, 41, 41, 41, 41, 41, 41, 0, 41, 41, 41, 41, 0, 0, 0, 0, 0, 43, 44, 46, 46, 47, 47, 48, 48, 49, 50, 50, 51, 52, 55, 56, 56, 57, 59, 61, 62, 63, 63, 64, 66, 66, 66, 68, 69, 70, 70, 71, 73, 73, 73, 73, 74, 74, 74, 78, 79, 80, 80, 81, 82, 84, 85, 86, 86, 87, 88, 88, 89, 90, 91, 91, 92, 93, 93, 93, 95, 96, 97, 97, 98, 99, 100, 100, 101, 101, 101, 102, 103, 106, 107, 108, 108, 109, 110, 111, 111, 112, 113, 115, 115, 115, 115, 116, 117, 118, 118, 119, 120, 122, 123, 124, 124, 125, 126, 126, 127, 128, 129, 129, 130, 131, 131, 131, 133, 134, 135, 135, 136, 137, 138, 139, 139, 140, 140, 140, 141, 143, 143, 143, 147, 148, 149, 149, 150, 151, 152, 152, 155, 155};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 132, 133, 134, 139, 140, 141, 142, 143, 148, 149, 152, 156, 159, 160, 161, 162, 163, 165, 168, 172, 175, 176, 177, 178, 180, 181, 182, 187, 188, 189, 190, 192, 193, 194, 199, 200, 201, 202, 203, 205, 208, 209, 210, 211, 213, 216, 220, 223, 227, 230, 231, 232, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 271, 272, 273, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 362, 363, 364, 366, 367, 368, 369, 370, 371, 372, 373, 375, 376};
/* BEGIN LINEINFO 
assign 1 16 27
new 1 16 27
assign 1 17 28
new 0 17 28
heldSet 1 17 29
assign 1 18 30
CALLGet 0 18 30
typenameSet 1 18 31
assign 1 19 32
new 1 19 32
assign 1 20 33
VARGet 0 20 33
typenameSet 1 20 34
heldSet 1 21 35
addValue 1 22 36
assign 1 23 37
heldGet 0 23 37
assign 1 23 38
new 0 23 38
nameSet 1 23 39
assign 1 24 40
new 1 24 40
typenameSet 1 25 41
addValue 1 26 42
return 1 27 43
assign 1 31 132
typenameGet 0 31 132
assign 1 31 133
PARENSGet 0 31 133
assign 1 31 134
equals 1 31 139
assign 1 31 140
containedGet 0 31 140
assign 1 31 141
lengthGet 0 31 141
assign 1 31 142
new 0 31 142
assign 1 31 143
equals 1 31 148
assign 1 0 149
assign 1 0 152
assign 1 0 156
assign 1 31 159
containedGet 0 31 159
assign 1 31 160
firstGet 0 31 160
assign 1 31 161
typenameGet 0 31 161
assign 1 31 162
PARENSGet 0 31 162
assign 1 31 163
equals 1 31 163
assign 1 0 165
assign 1 0 168
assign 1 0 172
assign 1 32 175
containedGet 0 32 175
assign 1 32 176
firstGet 0 32 176
takeContents 1 32 177
return 1 33 178
assign 1 36 180
typenameGet 0 36 180
assign 1 36 181
IDGet 0 36 181
assign 1 36 182
equals 1 36 187
assign 1 37 188
VARGet 0 37 188
typenameSet 1 37 189
syncVariable 1 38 190
assign 1 41 192
typenameGet 0 41 192
assign 1 41 193
CALLGet 0 41 193
assign 1 41 194
equals 1 41 199
assign 1 41 200
heldGet 0 41 200
assign 1 41 201
nameGet 0 41 201
assign 1 41 202
new 0 41 202
assign 1 41 203
equals 1 41 203
assign 1 0 205
assign 1 41 208
heldGet 0 41 208
assign 1 41 209
nameGet 0 41 209
assign 1 41 210
new 0 41 210
assign 1 41 211
equals 1 41 211
assign 1 0 213
assign 1 0 216
assign 1 0 220
assign 1 0 223
assign 1 0 227
assign 1 43 230
anchorGet 0 43 230
assign 1 44 231
condanyGet 0 44 231
assign 1 46 232
undef 1 46 237
assign 1 47 238
new 0 47 238
assign 1 47 239
tmpVar 2 47 239
assign 1 48 240
new 0 48 240
isTypedSet 1 48 241
assign 1 49 242
new 0 49 242
assign 1 50 243
new 0 50 243
fromString 1 50 244
namepathSet 1 51 245
condanySet 1 52 246
assign 1 55 248
new 1 55 248
assign 1 56 249
IFGet 0 56 249
typenameSet 1 56 250
copyLoc 1 57 251
assign 1 59 252
assign 1 61 253
new 1 61 253
copyLoc 1 62 254
assign 1 63 255
PARENSGet 0 63 255
typenameSet 1 63 256
addValue 1 64 257
assign 1 66 258
containedGet 0 66 258
assign 1 66 259
firstGet 0 66 259
addValue 1 66 260
assign 1 68 261
new 1 68 261
copyLoc 1 69 262
assign 1 70 263
BRACESGet 0 70 263
typenameSet 1 70 264
addValue 1 71 265
assign 1 73 266
heldGet 0 73 266
assign 1 73 267
nameGet 0 73 267
assign 1 73 268
new 0 73 268
assign 1 73 269
equals 1 73 269
assign 1 74 271
TRUEGet 0 74 271
assign 1 74 272
condCall 2 74 272
addValue 1 74 273
assign 1 78 276
new 1 78 276
copyLoc 1 79 277
assign 1 80 278
IFGet 0 80 278
typenameSet 1 80 279
condanySet 1 81 280
addValue 1 82 281
assign 1 84 282
new 1 84 282
copyLoc 1 85 283
assign 1 86 284
PARENSGet 0 86 284
typenameSet 1 86 285
addValue 1 87 286
assign 1 88 287
secondGet 0 88 287
addValue 1 88 288
assign 1 89 289
new 1 89 289
copyLoc 1 90 290
assign 1 91 291
BRACESGet 0 91 291
typenameSet 1 91 292
addValue 1 92 293
assign 1 93 294
TRUEGet 0 93 294
assign 1 93 295
condCall 2 93 295
addValue 1 93 296
assign 1 95 297
new 1 95 297
copyLoc 1 96 298
assign 1 97 299
ELSEGet 0 97 299
typenameSet 1 97 300
assign 1 98 301
new 1 98 301
copyLoc 1 99 302
assign 1 100 303
BRACESGet 0 100 303
typenameSet 1 100 304
assign 1 101 305
FALSEGet 0 101 305
assign 1 101 306
condCall 2 101 306
addValue 1 101 307
addValue 1 102 308
addValue 1 103 309
assign 1 106 311
new 1 106 311
copyLoc 1 107 312
assign 1 108 313
ELSEGet 0 108 313
typenameSet 1 108 314
assign 1 109 315
new 1 109 315
copyLoc 1 110 316
assign 1 111 317
BRACESGet 0 111 317
typenameSet 1 111 318
addValue 1 112 319
addValue 1 113 320
assign 1 115 321
heldGet 0 115 321
assign 1 115 322
nameGet 0 115 322
assign 1 115 323
new 0 115 323
assign 1 115 324
equals 1 115 324
assign 1 116 326
new 1 116 326
copyLoc 1 117 327
assign 1 118 328
IFGet 0 118 328
typenameSet 1 118 329
condanySet 1 119 330
addValue 1 120 331
assign 1 122 332
new 1 122 332
copyLoc 1 123 333
assign 1 124 334
PARENSGet 0 124 334
typenameSet 1 124 335
addValue 1 125 336
assign 1 126 337
secondGet 0 126 337
addValue 1 126 338
assign 1 127 339
new 1 127 339
copyLoc 1 128 340
assign 1 129 341
BRACESGet 0 129 341
typenameSet 1 129 342
addValue 1 130 343
assign 1 131 344
TRUEGet 0 131 344
assign 1 131 345
condCall 2 131 345
addValue 1 131 346
assign 1 133 347
new 1 133 347
copyLoc 1 134 348
assign 1 135 349
ELSEGet 0 135 349
typenameSet 1 135 350
addValue 1 136 351
assign 1 137 352
new 1 137 352
copyLoc 1 138 353
assign 1 139 354
BRACESGet 0 139 354
typenameSet 1 139 355
assign 1 140 356
FALSEGet 0 140 356
assign 1 140 357
condCall 2 140 357
addValue 1 140 358
addValue 1 141 359
assign 1 143 362
FALSEGet 0 143 362
assign 1 143 363
condCall 2 143 363
addValue 1 143 364
beforeInsert 1 147 366
containedSet 1 148 367
assign 1 149 368
VARGet 0 149 368
typenameSet 1 149 369
heldSet 1 150 370
syncAddVariable 0 151 371
assign 1 152 372
nextDescendGet 0 152 372
return 1 152 373
assign 1 155 375
nextDescendGet 0 155 375
return 1 155 376
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 605655591: return bem_sourceFileNameGet_0();
case 1267812147: return bem_classNameGet_0();
case 860976645: return bem_constGetDirect_0();
case 702246847: return bem_print_0();
case -364249863: return bem_serializeToString_0();
case -1353172126: return bem_toString_0();
case 1966713191: return bem_deserializeClassNameGet_0();
case -1655660203: return bem_hashGet_0();
case -500248069: return bem_serializationIteratorGet_0();
case 1581692921: return bem_toAny_0();
case 1739341242: return bem_transGet_0();
case -1572010998: return bem_copy_0();
case -496016490: return bem_buildGetDirect_0();
case -1973330053: return bem_transGetDirect_0();
case 1530555194: return bem_serializeContents_0();
case 812685421: return bem_iteratorGet_0();
case -1229344212: return bem_ntypesGetDirect_0();
case 1916900255: return bem_buildGet_0();
case -300440210: return bem_ntypesGet_0();
case -1000018882: return bem_create_0();
case -65082849: return bem_once_0();
case -1907635971: return bem_tagGet_0();
case -106257945: return bem_fieldNamesGet_0();
case -1577817259: return bem_echo_0();
case 1550760607: return bem_fieldIteratorGet_0();
case -927090833: return bem_new_0();
case -1007878556: return bem_many_0();
case 678066298: return bem_constGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -363976204: return bem_end_1(bevd_0);
case 1711941852: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1244819809: return bem_undefined_1(bevd_0);
case -960947678: return bem_ntypesSet_1(bevd_0);
case 1953776597: return bem_sameType_1(bevd_0);
case -759946269: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1471550820: return bem_transSetDirect_1(bevd_0);
case 140166424: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1071293979: return bem_buildSetDirect_1(bevd_0);
case -58459221: return bem_sameClass_1(bevd_0);
case 129545103: return bem_buildSet_1(bevd_0);
case -1556952447: return bem_defined_1(bevd_0);
case -1862075337: return bem_copyTo_1(bevd_0);
case 726015407: return bem_otherType_1(bevd_0);
case 150021405: return bem_otherClass_1(bevd_0);
case -1399562150: return bem_constSet_1(bevd_0);
case -1471457238: return bem_sameObject_1(bevd_0);
case 297381803: return bem_def_1(bevd_0);
case 1673385175: return bem_notEquals_1(bevd_0);
case 1140777632: return bem_constSetDirect_1(bevd_0);
case -227529285: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 691174875: return bem_begin_1(bevd_0);
case -886218051: return bem_equals_1(bevd_0);
case 2141774895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -481756547: return bem_undef_1(bevd_0);
case 1100414449: return bem_ntypesSetDirect_1(bevd_0);
case 1447874828: return bem_transSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1722905349: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -549877285: return bem_condCall_2(bevd_0, bevd_1);
case -967702518: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -427898914: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 414161005: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 611344245: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -157052200: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1970963739: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitPass10_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitPass10_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitPass10();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst = (BEC_3_5_5_6_BuildVisitPass10) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_type;
}
}
}
