namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_3_6_NetSocket : BEC_2_6_6_SystemObject {
public BEC_2_3_6_NetSocket() { }
static BEC_2_3_6_NetSocket() { }

  public Socket bevi_socket;
  private static byte[] becc_BEC_2_3_6_NetSocket_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74};
private static byte[] becc_BEC_2_3_6_NetSocket_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_2_3_6_NetSocket bece_BEC_2_3_6_NetSocket_bevs_inst;
public virtual BEC_3_3_6_6_NetSocketReader bem_readerGet_0() {
BEC_3_3_6_6_NetSocketReader bevl_sr = null;
bevl_sr = (BEC_3_3_6_6_NetSocketReader) (new BEC_3_3_6_6_NetSocketReader()).bem_new_0();

    bevl_sr.bevi_is = new NetworkStream(bevi_socket);
    bevl_sr.bem_extOpen_0();
return bevl_sr;
} /*method end*/
public virtual BEC_3_3_6_6_NetSocketWriter bem_writerGet_0() {
BEC_3_3_6_6_NetSocketWriter bevl_sw = null;
bevl_sw = (BEC_3_3_6_6_NetSocketWriter) (new BEC_3_3_6_6_NetSocketWriter()).bem_new_0();

    bevl_sw.bevi_os = new NetworkStream(bevi_socket);
    bevl_sw.bem_extOpen_0();
return bevl_sw;
} /*method end*/
public virtual BEC_2_3_6_NetSocket bem_new_2(BEC_2_4_6_TextString beva_host, BEC_2_4_3_MathInt beva_port) {

    IPHostEntry ipHostInfo = Dns.Resolve(beva_host.bems_toCsString());
    IPAddress ipAddress = ipHostInfo.AddressList[0];
    IPEndPoint remoteEP = new IPEndPoint(ipAddress,beva_port.bevi_int);

    bevi_socket = new Socket(AddressFamily.InterNetwork, 
        SocketType.Stream, ProtocolType.Tcp );
    bevi_socket.Connect(remoteEP);
    return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {675, 686, 687, 691, 702, 703};
public static new int[] bevs_smnlec
 = new int[] {21, 24, 25, 29, 32, 33};
/* BEGIN LINEINFO 
assign 1 675 21
new 0 675 21
extOpen 0 686 24
return 1 687 25
assign 1 691 29
new 0 691 29
extOpen 0 702 32
return 1 703 33
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1193265838: return bem_new_0();
case 752911959: return bem_hashGet_0();
case 142206752: return bem_many_0();
case 2141550628: return bem_deserializeClassNameGet_0();
case -1896601781: return bem_toAny_0();
case 918723651: return bem_readerGet_0();
case -326646035: return bem_toString_0();
case 2085674875: return bem_echo_0();
case 588726056: return bem_writerGet_0();
case 2098501683: return bem_create_0();
case -2052611744: return bem_once_0();
case -364515046: return bem_fieldIteratorGet_0();
case -1888508563: return bem_serializationIteratorGet_0();
case 444169984: return bem_sourceFileNameGet_0();
case 1310164435: return bem_serializeContents_0();
case -1152001976: return bem_copy_0();
case 1278477757: return bem_serializeToString_0();
case 1211836779: return bem_iteratorGet_0();
case -2091198124: return bem_tagGet_0();
case -1976290782: return bem_print_0();
case 880152096: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1948085050: return bem_undef_1(bevd_0);
case 1990827367: return bem_notEquals_1(bevd_0);
case -1191000829: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -785327205: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 136677527: return bem_def_1(bevd_0);
case 1048239710: return bem_sameClass_1(bevd_0);
case 607370643: return bem_undefined_1(bevd_0);
case -1321282362: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1866601742: return bem_otherType_1(bevd_0);
case 986477958: return bem_defined_1(bevd_0);
case 930180418: return bem_copyTo_1(bevd_0);
case 45057151: return bem_equals_1(bevd_0);
case 496808651: return bem_sameObject_1(bevd_0);
case 1579053823: return bem_sameType_1(bevd_0);
case 1268433926: return bem_otherClass_1(bevd_0);
case 275457317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1768228505: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 627553561: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1848289028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 253281852: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1400688487: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 686788947: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 893523384: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1481064275: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_3_6_NetSocket_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_3_6_NetSocket_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_6_NetSocket();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_6_NetSocket.bece_BEC_2_3_6_NetSocket_bevs_inst = (BEC_2_3_6_NetSocket) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_6_NetSocket.bece_BEC_2_3_6_NetSocket_bevs_inst;
}
}
}
