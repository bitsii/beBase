namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketReader : BEC_2_2_6_IOReader {
public BEC_3_3_6_6_NetSocketReader() { }
static BEC_3_3_6_6_NetSocketReader() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;

public static new BET_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -692171246: return bem_readStringClose_0();
case -1218700960: return bem_readBuffer_0();
case 1334927002: return bem_create_0();
case -914943787: return bem_toString_0();
case -1620303979: return bem_once_0();
case 93356535: return bem_deserializeClassNameGet_0();
case -541227487: return bem_new_0();
case -252807869: return bem_byteReaderGet_0();
case 1280569362: return bem_fieldIteratorGet_0();
case 536683643: return bem_isClosedGet_0();
case 1624944174: return bem_serializationIteratorGet_0();
case -1942605555: return bem_toAny_0();
case 1099128486: return bem_echo_0();
case 342664202: return bem_serializeContents_0();
case 948654667: return bem_readString_0();
case 1116834406: return bem_readBufferLine_0();
case -1117992648: return bem_hashGet_0();
case -1248348608: return bem_many_0();
case -152803575: return bem_tagGet_0();
case -1618533783: return bem_serializeToString_0();
case -1920078604: return bem_sourceFileNameGet_0();
case 1754519730: return bem_classNameGet_0();
case 38289726: return bem_print_0();
case 339989397: return bem_extOpen_0();
case 385489744: return bem_iteratorGet_0();
case -312714331: return bem_vfileGet_0();
case -1613122886: return bem_blockSizeGet_0();
case -1749035302: return bem_copy_0();
case -770443915: return bem_close_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1842878592: return bem_vfileSet_1(bevd_0);
case 1090204707: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 1669123607: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2067491930: return bem_isClosedSet_1(bevd_0);
case -704648297: return bem_blockSizeSet_1(bevd_0);
case -1553866014: return bem_sameClass_1(bevd_0);
case -1729747983: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -935672373: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -1001167064: return bem_def_1(bevd_0);
case -900790842: return bem_defined_1(bevd_0);
case -1792057966: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -1394362735: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -929975460: return bem_equals_1(bevd_0);
case -1975825183: return bem_sameObject_1(bevd_0);
case 589015080: return bem_otherType_1(bevd_0);
case -147916244: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2057956567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1356842566: return bem_otherClass_1(bevd_0);
case 408844820: return bem_undefined_1(bevd_0);
case 960625295: return bem_notEquals_1(bevd_0);
case -406377870: return bem_copyTo_1(bevd_0);
case 1417404860: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1687133927: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 327551615: return bem_undef_1(bevd_0);
case 32553456: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1615755198: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 914119897: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1722418125: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1566536063: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1183458920: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -294037420: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1794036335: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1344222461: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -974430238: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1648852774: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketReader_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketReader_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_3_6_6_NetSocketReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst = (BEC_3_3_6_6_NetSocketReader) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_type;
}
}
}
