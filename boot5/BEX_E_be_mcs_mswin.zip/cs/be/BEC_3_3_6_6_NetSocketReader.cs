namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketReader : BEC_2_2_6_IOReader {
public BEC_3_3_6_6_NetSocketReader() { }
static BEC_3_3_6_6_NetSocketReader() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;

public static new BET_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1945110751: return bem_blockSizeGet_0();
case 464610233: return bem_once_0();
case -461205434: return bem_iteratorGet_0();
case 26136785: return bem_close_0();
case 1375519361: return bem_sourceFileNameGet_0();
case -1771198546: return bem_extOpen_0();
case 1781963949: return bem_isClosedGet_0();
case 1969869774: return bem_echo_0();
case 1947173801: return bem_print_0();
case -1069594303: return bem_vfileGet_0();
case -1581666253: return bem_new_0();
case -1747498826: return bem_classNameGet_0();
case 1881939406: return bem_fieldNamesGet_0();
case 1123184191: return bem_readBufferLine_0();
case -1327508009: return bem_vfileGetDirect_0();
case -654415539: return bem_tagGet_0();
case -1431960617: return bem_many_0();
case -182215192: return bem_serializationIteratorGet_0();
case -1919376645: return bem_blockSizeGetDirect_0();
case 322540171: return bem_toAny_0();
case 49134257: return bem_hashGet_0();
case 1205179000: return bem_deserializeClassNameGet_0();
case 1512772474: return bem_copy_0();
case 941172865: return bem_serializeContents_0();
case 1916894973: return bem_byteReaderGet_0();
case 1437125214: return bem_readStringClose_0();
case -1748667265: return bem_readString_0();
case -1051263431: return bem_create_0();
case -1558141823: return bem_readBuffer_0();
case 1156921009: return bem_toString_0();
case -539277844: return bem_fieldIteratorGet_0();
case 874503493: return bem_serializeToString_0();
case -208782634: return bem_isClosedGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -653588721: return bem_otherType_1(bevd_0);
case 574685433: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 778331504: return bem_def_1(bevd_0);
case -1295446558: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1940703752: return bem_copyTo_1(bevd_0);
case 1531361618: return bem_blockSizeSet_1(bevd_0);
case 1779380050: return bem_undefined_1(bevd_0);
case -1829438163: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -1405212164: return bem_sameClass_1(bevd_0);
case 1817351105: return bem_defined_1(bevd_0);
case 723669318: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -963385516: return bem_vfileSetDirect_1(bevd_0);
case 447923928: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 136734836: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -1499911921: return bem_notEquals_1(bevd_0);
case -373658986: return bem_equals_1(bevd_0);
case -2119957364: return bem_blockSizeSetDirect_1(bevd_0);
case -439257088: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -1264044693: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 372746140: return bem_sameType_1(bevd_0);
case 1642612137: return bem_vfileSet_1(bevd_0);
case 243162876: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1089354598: return bem_undef_1(bevd_0);
case -498298486: return bem_sameObject_1(bevd_0);
case 1966156517: return bem_otherClass_1(bevd_0);
case 542790358: return bem_isClosedSet_1(bevd_0);
case -385985013: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -1949411516: return bem_isClosedSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 414389553: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1714613573: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -292360250: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1129259785: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 614290015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 888716978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 193506539: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1142639583: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 58579951: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -859158088: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketReader_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketReader_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_3_6_6_NetSocketReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst = (BEC_3_3_6_6_NetSocketReader) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_type;
}
}
}
