namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketReader : BEC_2_2_6_IOReader {
public BEC_3_3_6_6_NetSocketReader() { }
static BEC_3_3_6_6_NetSocketReader() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;

public static new BET_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1034659716: return bem_once_0();
case 987048722: return bem_serializeContents_0();
case 1599241336: return bem_iteratorGet_0();
case 1791745403: return bem_readStringClose_0();
case -2044460281: return bem_new_0();
case -427081409: return bem_create_0();
case 1808269843: return bem_isClosedGetDirect_0();
case -647519736: return bem_print_0();
case -1999703144: return bem_sourceFileNameGet_0();
case -31877142: return bem_many_0();
case -619959430: return bem_isClosedGet_0();
case 288186844: return bem_blockSizeGetDirect_0();
case -709677651: return bem_fieldNamesGet_0();
case -141904644: return bem_toString_0();
case -1897832985: return bem_readBuffer_0();
case -747859575: return bem_echo_0();
case 1561881831: return bem_tagGet_0();
case -1503949943: return bem_hashGet_0();
case -335942583: return bem_fieldIteratorGet_0();
case -1474345157: return bem_serializeToString_0();
case 247818182: return bem_copy_0();
case 1035232271: return bem_toAny_0();
case 754811482: return bem_blockSizeGet_0();
case 1111290363: return bem_readBufferLine_0();
case 1374872636: return bem_deserializeClassNameGet_0();
case 375012741: return bem_vfileGet_0();
case 1992583192: return bem_classNameGet_0();
case 421047878: return bem_serializationIteratorGet_0();
case 1392373579: return bem_vfileGetDirect_0();
case -877818365: return bem_byteReaderGet_0();
case 452123003: return bem_extOpen_0();
case 1092690343: return bem_close_0();
case 1196721294: return bem_readString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1051165080: return bem_sameObject_1(bevd_0);
case 1482027850: return bem_sameClass_1(bevd_0);
case -1867042275: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -947620695: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -1617324535: return bem_defined_1(bevd_0);
case -616387973: return bem_vfileSetDirect_1(bevd_0);
case 1118935191: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -317049327: return bem_def_1(bevd_0);
case 467730220: return bem_otherType_1(bevd_0);
case 1653589099: return bem_isClosedSet_1(bevd_0);
case -1259048964: return bem_notEquals_1(bevd_0);
case -1103337674: return bem_undefined_1(bevd_0);
case -1374971125: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -308629992: return bem_isClosedSetDirect_1(bevd_0);
case 2141740909: return bem_otherClass_1(bevd_0);
case 820225095: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -1045313494: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 544063329: return bem_equals_1(bevd_0);
case -2136985639: return bem_sameType_1(bevd_0);
case 1056498349: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1037648926: return bem_copyTo_1(bevd_0);
case -1732439949: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -642869018: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -767876115: return bem_undef_1(bevd_0);
case -313713052: return bem_vfileSet_1(bevd_0);
case 897968565: return bem_blockSizeSet_1(bevd_0);
case 737998917: return bem_blockSizeSetDirect_1(bevd_0);
case 1402363485: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1477075576: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2067866135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 930768377: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1135810204: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 747569055: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -78432632: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -657633999: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1155749415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -754204478: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1794941949: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketReader_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketReader_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_3_6_6_NetSocketReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst = (BEC_3_3_6_6_NetSocketReader) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_type;
}
}
}
