namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_10_IOByteReader : BEC_2_6_6_SystemObject {
public BEC_2_2_10_IOByteReader() { }
static BEC_2_2_10_IOByteReader() { }
private static byte[] becc_BEC_2_2_10_IOByteReader_clname = {0x49,0x4F,0x3A,0x42,0x79,0x74,0x65,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_10_IOByteReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_inst;

public static new BET_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_type;

public BEC_2_2_6_IOReader bevp_reader;
public BEC_2_4_6_TextString bevp_buf;
public BEC_2_4_12_TextByteIterator bevp_iter;
public virtual BEC_2_2_10_IOByteReader bem_readerBufferNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_6_TextString beva__buf) {
bevp_reader = beva__reader;
bevp_buf = beva__buf;
bevp_iter = bevp_buf.bem_biterGet_0();
return this;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_readerNew_1(BEC_2_2_6_IOReader beva__reader) {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(256));
bevt_0_tmpany_phold = (BEC_2_2_10_IOByteReader) bem_readerBlockNew_2(beva__reader, bevt_1_tmpany_phold);
return (BEC_2_2_10_IOByteReader) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_readerBlockNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_3_MathInt beva__blockSize) {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva__blockSize);
bevt_0_tmpany_phold = (BEC_2_2_10_IOByteReader) bem_readerBufferNew_2(beva__reader, bevt_1_tmpany_phold);
return (BEC_2_2_10_IOByteReader) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_tmpany_phold);
} /* Line: 42 */
bevt_3_tmpany_phold = bevp_iter.bem_hasNextGet_0();
return bevt_3_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nextGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_dest) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_tmpany_phold);
} /* Line: 54 */
bevt_3_tmpany_phold = bevp_iter.bem_next_1(beva_dest);
return bevt_3_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_readerGet_0() {
return bevp_reader;
} /*method end*/
public BEC_2_2_6_IOReader bem_readerGetDirect_0() {
return bevp_reader;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_bufGet_0() {
return bevp_buf;
} /*method end*/
public BEC_2_4_6_TextString bem_bufGetDirect_0() {
return bevp_buf;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_bufSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_bufSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_iterGet_0() {
return bevp_iter;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_iterGetDirect_0() {
return bevp_iter;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_iterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {25, 26, 27, 32, 32, 32, 36, 36, 36, 40, 40, 40, 41, 42, 42, 44, 44, 48, 48, 48, 48, 52, 52, 52, 53, 54, 54, 56, 56, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 20, 21, 27, 28, 29, 34, 35, 36, 43, 44, 49, 50, 51, 52, 54, 55, 61, 62, 63, 64, 71, 72, 77, 78, 79, 80, 82, 83, 86, 89, 92, 96, 100, 103, 106, 110, 114, 117, 120, 124};
/* BEGIN LINEINFO 
assign 1 25 19
assign 1 26 20
assign 1 27 21
biterGet 0 27 21
assign 1 32 27
new 0 32 27
assign 1 32 28
readerBlockNew 2 32 28
return 1 32 29
assign 1 36 34
new 1 36 34
assign 1 36 35
readerBufferNew 2 36 35
return 1 36 36
assign 1 40 43
hasNextGet 0 40 43
assign 1 40 44
not 0 40 49
readIntoBuffer 1 41 50
assign 1 42 51
new 0 42 51
posSet 1 42 52
assign 1 44 54
hasNextGet 0 44 54
return 1 44 55
assign 1 48 61
new 0 48 61
assign 1 48 62
new 1 48 62
assign 1 48 63
next 1 48 63
return 1 48 64
assign 1 52 71
hasNextGet 0 52 71
assign 1 52 72
not 0 52 77
readIntoBuffer 1 53 78
assign 1 54 79
new 0 54 79
posSet 1 54 80
assign 1 56 82
next 1 56 82
return 1 56 83
return 1 0 86
return 1 0 89
assign 1 0 92
assign 1 0 96
return 1 0 100
return 1 0 103
assign 1 0 106
assign 1 0 110
return 1 0 114
return 1 0 117
assign 1 0 120
assign 1 0 124
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1957957442: return bem_bufGet_0();
case 934505477: return bem_readerGet_0();
case -604312045: return bem_serializationIteratorGet_0();
case -787859152: return bem_nextGet_0();
case 55812595: return bem_serializeToString_0();
case -434919379: return bem_deserializeClassNameGet_0();
case 1678261270: return bem_print_0();
case 1860492410: return bem_fieldIteratorGet_0();
case 808044123: return bem_hashGet_0();
case 9957435: return bem_iteratorGet_0();
case 2066929947: return bem_iterGetDirect_0();
case -1854726950: return bem_echo_0();
case 1370058570: return bem_readerGetDirect_0();
case 682604587: return bem_serializeContents_0();
case -656937356: return bem_many_0();
case -368347729: return bem_fieldNamesGet_0();
case 1342765490: return bem_toAny_0();
case -636994806: return bem_sourceFileNameGet_0();
case -1795002401: return bem_toString_0();
case -1975455714: return bem_copy_0();
case 1970659078: return bem_hasNextGet_0();
case -772967023: return bem_classNameGet_0();
case 402201008: return bem_new_0();
case 966149554: return bem_create_0();
case 833313209: return bem_iterGet_0();
case -449782556: return bem_bufGetDirect_0();
case 367195678: return bem_once_0();
case 748315678: return bem_tagGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -514895261: return bem_readerSetDirect_1(bevd_0);
case -1936320007: return bem_bufSet_1(bevd_0);
case 267174377: return bem_def_1(bevd_0);
case 1272631429: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -714900612: return bem_copyTo_1(bevd_0);
case -1007540340: return bem_notEquals_1(bevd_0);
case -1539112334: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 1621186357: return bem_sameType_1(bevd_0);
case 1647993291: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1194473609: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -836657034: return bem_bufSetDirect_1(bevd_0);
case 195308005: return bem_sameObject_1(bevd_0);
case -1903838197: return bem_iterSet_1(bevd_0);
case 543061021: return bem_otherClass_1(bevd_0);
case 1448933357: return bem_otherType_1(bevd_0);
case -2094311863: return bem_iterSetDirect_1(bevd_0);
case 1614496109: return bem_undef_1(bevd_0);
case 350775730: return bem_equals_1(bevd_0);
case -2144202949: return bem_sameClass_1(bevd_0);
case -2043665980: return bem_readerNew_1((BEC_2_2_6_IOReader) bevd_0);
case 1163078007: return bem_undefined_1(bevd_0);
case -700310720: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -991365338: return bem_defined_1(bevd_0);
case 1791583870: return bem_readerSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 325307565: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1385197575: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1881297190: return bem_readerBufferNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1280867989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 373423198: return bem_readerBlockNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1833007700: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1584099228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -187061774: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -961973758: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_2_10_IOByteReader_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_10_IOByteReader_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_10_IOByteReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst = (BEC_2_2_10_IOByteReader) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_type;
}
}
}
