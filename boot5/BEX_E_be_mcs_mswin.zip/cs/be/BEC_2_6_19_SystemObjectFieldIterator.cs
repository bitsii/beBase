namespace be {

using System;
    /* IO:File: source/base/OpiFc.be */
public sealed class BEC_2_6_19_SystemObjectFieldIterator : BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemObjectFieldIterator() { }
static BEC_2_6_19_SystemObjectFieldIterator() { }

public System.Reflection.FieldInfo[] fields;
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x46,0x69,0x65,0x6C,0x64,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
public static new BEC_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;

public static new BET_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_6_6_SystemObject bevp_instance;
public BEC_2_5_4_LogicBool bevp_advanced;
public BEC_2_5_4_LogicBool bevp_done;
public BEC_2_5_4_LogicBool bevp_tval;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_1(BEC_2_6_6_SystemObject beva__instance) {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_new_2(beva__instance, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_2(BEC_2_6_6_SystemObject beva__instance, BEC_2_5_4_LogicBool beva_forceFirstSlot) {
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_instance = beva__instance;
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_done = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_tval = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;

    fields = bevp_instance.GetType().GetFields();
    return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advance_0() {

    string prefix = "bevp_";
    int i = bevp_pos.bevi_int;
    i++;
    while (i < fields.Length) {
      if (fields[i].Name.StartsWith(prefix)) {
        bevp_advanced = bevp_tval;
        bevp_pos.bevi_int = i;
        return this;
      }
      i++;
    }
    bevp_done = bevp_tval;
    return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
if (bevp_done.bevi_bool) /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 106 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 106 */ {
bem_advance_0();
} /* Line: 107 */
if (!(bevp_done.bevi_bool)) /* Line: 109 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 110 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextNameGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
if (bevp_done.bevi_bool) /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 116 */ {
bem_advance_0();
} /* Line: 117 */
if (bevp_done.bevi_bool) /* Line: 119 */ {
return null;
} /* Line: 120 */
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = bem_currentNameGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_currentNameGet_0() {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;

    bevl_res = new BEC_2_4_6_TextString(fields[bevp_pos.bevi_int].Name);
    bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevt_0_tmpany_phold = bevl_res.bem_substring_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 147 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 147 */ {
if (bevp_done.bevi_bool) /* Line: 147 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 147 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 147 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 147 */ {
bem_advance_0();
} /* Line: 148 */
if (bevp_done.bevi_bool) /* Line: 150 */ {
return null;
} /* Line: 151 */
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = bem_currentGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() {
BEC_2_6_6_SystemObject bevl_res = null;

    bevl_res = (BEC_2_6_6_SystemObject) (fields[bevp_pos.bevi_int].GetValue(bevp_instance));
    return bevl_res;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 178 */ {
if (bevp_done.bevi_bool) /* Line: 178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 178 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 178 */ {
bem_advance_0();
} /* Line: 179 */
if (bevp_done.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 181 */ {
bem_currentSet_1(beva_value);
} /* Line: 182 */
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_currentSet_1(BEC_2_6_6_SystemObject beva_value) {

    fields[bevp_pos.bevi_int].SetValue(bevp_instance, beva_value);
    return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 206 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 206 */ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 206 */
 else  /* Line: 206 */ {
break;
} /* Line: 206 */
} /* Line: 206 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceGet_0() {
return bevp_instance;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instanceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_instance = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_advancedGet_0() {
return bevp_advanced;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advancedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_advanced = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doneGet_0() {
return bevp_done;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_doneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_done = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_tvalGet_0() {
return bevp_tval;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_tvalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tval = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {35, 35, 35, 40, 41, 42, 43, 44, 0, 0, 0, 107, 110, 110, 112, 112, 0, 0, 0, 117, 120, 122, 123, 123, 143, 143, 143, 0, 0, 0, 148, 151, 153, 154, 154, 174, 0, 0, 0, 179, 181, 181, 182, 184, 206, 206, 206, 207, 206, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 29, 32, 33, 34, 35, 36, 62, 66, 69, 73, 76, 77, 79, 80, 86, 90, 93, 97, 100, 102, 103, 104, 112, 113, 114, 120, 124, 127, 131, 134, 136, 137, 138, 144, 150, 154, 157, 161, 163, 168, 169, 171, 182, 185, 190, 191, 192, 201, 204, 208, 211, 215, 218, 222, 225, 229, 232};
/* BEGIN LINEINFO 
assign 1 35 27
new 0 35 27
assign 1 35 28
new 2 35 28
return 1 35 29
assign 1 40 32
new 0 40 32
assign 1 41 33
assign 1 42 34
new 0 42 34
assign 1 43 35
new 0 43 35
assign 1 44 36
new 0 44 36
assign 1 0 62
assign 1 0 66
assign 1 0 69
advance 0 107 73
assign 1 110 76
new 0 110 76
return 1 110 77
assign 1 112 79
new 0 112 79
return 1 112 80
assign 1 0 86
assign 1 0 90
assign 1 0 93
advance 0 117 97
return 1 120 100
assign 1 122 102
new 0 122 102
assign 1 123 103
currentNameGet 0 123 103
return 1 123 104
assign 1 143 112
new 0 143 112
assign 1 143 113
substring 1 143 113
return 1 143 114
assign 1 0 120
assign 1 0 124
assign 1 0 127
advance 0 148 131
return 1 151 134
assign 1 153 136
new 0 153 136
assign 1 154 137
currentGet 0 154 137
return 1 154 138
return 1 174 144
assign 1 0 150
assign 1 0 154
assign 1 0 157
advance 0 179 161
assign 1 181 163
not 0 181 168
currentSet 1 182 169
assign 1 184 171
new 0 184 171
assign 1 206 182
new 0 206 182
assign 1 206 185
lesser 1 206 190
nextSet 1 207 191
incrementValue 0 206 192
return 1 0 201
assign 1 0 204
return 1 0 208
assign 1 0 211
return 1 0 215
assign 1 0 218
return 1 0 222
assign 1 0 225
return 1 0 229
assign 1 0 232
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 2131414475: return bem_advance_0();
case 1624944174: return bem_serializationIteratorGet_0();
case 1754519730: return bem_classNameGet_0();
case -2046678680: return bem_nextNameGet_0();
case -2060874566: return bem_nextGet_0();
case -1154766941: return bem_doneGet_0();
case 1936112802: return bem_currentGet_0();
case -825403494: return bem_tvalGet_0();
case 545651144: return bem_currentNameGet_0();
case 1099128486: return bem_echo_0();
case 342664202: return bem_serializeContents_0();
case 66190951: return bem_instanceGet_0();
case -1920078604: return bem_sourceFileNameGet_0();
case -1248348608: return bem_many_0();
case 1334927002: return bem_create_0();
case -914943787: return bem_toString_0();
case 1644386157: return bem_advancedGet_0();
case 1280569362: return bem_fieldIteratorGet_0();
case 1423814014: return bem_posGet_0();
case -1117992648: return bem_hashGet_0();
case 93356535: return bem_deserializeClassNameGet_0();
case -1942605555: return bem_toAny_0();
case -152803575: return bem_tagGet_0();
case -541227487: return bem_new_0();
case 38289726: return bem_print_0();
case -26359499: return bem_hasNextGet_0();
case -1618533783: return bem_serializeToString_0();
case -1749035302: return bem_copy_0();
case -1620303979: return bem_once_0();
case 385489744: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -147916244: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1855038129: return bem_tvalSet_1(bevd_0);
case 1417404860: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1669123607: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1864044798: return bem_advancedSet_1(bevd_0);
case 960625295: return bem_notEquals_1(bevd_0);
case 1356842566: return bem_otherClass_1(bevd_0);
case -1553866014: return bem_sameClass_1(bevd_0);
case -929975460: return bem_equals_1(bevd_0);
case 671150149: return bem_nextSet_1(bevd_0);
case 1195893385: return bem_posSet_1(bevd_0);
case -1676972351: return bem_currentSet_1(bevd_0);
case -2031825197: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -1001167064: return bem_def_1(bevd_0);
case 408844820: return bem_undefined_1(bevd_0);
case -2057956567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 327551615: return bem_undef_1(bevd_0);
case 589015080: return bem_otherType_1(bevd_0);
case -406377870: return bem_copyTo_1(bevd_0);
case -1975825183: return bem_sameObject_1(bevd_0);
case -1052704201: return bem_new_1(bevd_0);
case -900790842: return bem_defined_1(bevd_0);
case 483335195: return bem_doneSet_1(bevd_0);
case 1771981412: return bem_instanceSet_1(bevd_0);
case 32553456: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1615755198: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1430698213: return bem_new_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 914119897: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1722418125: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1183458920: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -294037420: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1794036335: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1344222461: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemObjectFieldIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_19_SystemObjectFieldIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst = (BEC_2_6_19_SystemObjectFieldIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;
}
}
}
