namespace be {

using System;
    /* IO:File: source/base/OpiFc.be */
public sealed class BEC_2_6_19_SystemObjectFieldIterator : BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemObjectFieldIterator() { }
static BEC_2_6_19_SystemObjectFieldIterator() { }

public System.Reflection.FieldInfo[] fields;
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x46,0x69,0x65,0x6C,0x64,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
public static new BEC_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_6_6_SystemObject bevp_instance;
public BEC_2_5_4_LogicBool bevp_advanced;
public BEC_2_5_4_LogicBool bevp_done;
public BEC_2_5_4_LogicBool bevp_tval;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_1(BEC_2_6_6_SystemObject beva__instance) {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_new_2(beva__instance, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_2(BEC_2_6_6_SystemObject beva__instance, BEC_2_5_4_LogicBool beva_forceFirstSlot) {
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_instance = beva__instance;
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_done = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_tval = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;

    fields = bevp_instance.GetType().GetFields();
    return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advance_0() {

    string prefix = "bevp_";
    int i = bevp_pos.bevi_int;
    i++;
    while (i < fields.Length) {
      if (fields[i].Name.StartsWith(prefix)) {
        bevp_advanced = bevp_tval;
        bevp_pos.bevi_int = i;
        return this;
      }
      i++;
    }
    bevp_done = bevp_tval;
    return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
if (bevp_done.bevi_bool) /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 106 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 106 */ {
bem_advance_0();
} /* Line: 107 */
if (!(bevp_done.bevi_bool)) /* Line: 109 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 110 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextNameGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
if (bevp_done.bevi_bool) /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 116 */ {
bem_advance_0();
} /* Line: 117 */
if (bevp_done.bevi_bool) /* Line: 119 */ {
return null;
} /* Line: 120 */
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = bem_currentNameGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_currentNameGet_0() {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;

    bevl_res = new BEC_2_4_6_TextString(fields[bevp_pos.bevi_int].Name);
    bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevt_0_tmpany_phold = bevl_res.bem_substring_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 147 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 147 */ {
if (bevp_done.bevi_bool) /* Line: 147 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 147 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 147 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 147 */ {
bem_advance_0();
} /* Line: 148 */
if (bevp_done.bevi_bool) /* Line: 150 */ {
return null;
} /* Line: 151 */
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = bem_currentGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() {
BEC_2_6_6_SystemObject bevl_res = null;

    bevl_res = (BEC_2_6_6_SystemObject) (fields[bevp_pos.bevi_int].GetValue(bevp_instance));
    return bevl_res;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 178 */ {
if (bevp_done.bevi_bool) /* Line: 178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 178 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 178 */ {
bem_advance_0();
} /* Line: 179 */
if (bevp_done.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 181 */ {
bem_currentSet_1(beva_value);
} /* Line: 182 */
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_currentSet_1(BEC_2_6_6_SystemObject beva_value) {

    fields[bevp_pos.bevi_int].SetValue(bevp_instance, beva_value);
    return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 206 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 206 */ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 206 */
 else  /* Line: 206 */ {
break;
} /* Line: 206 */
} /* Line: 206 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceGet_0() {
return bevp_instance;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instanceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_instance = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_advancedGet_0() {
return bevp_advanced;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advancedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_advanced = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doneGet_0() {
return bevp_done;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_doneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_done = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_tvalGet_0() {
return bevp_tval;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_tvalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tval = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {35, 35, 35, 40, 41, 42, 43, 44, 0, 0, 0, 107, 110, 110, 112, 112, 0, 0, 0, 117, 120, 122, 123, 123, 143, 143, 143, 0, 0, 0, 148, 151, 153, 154, 154, 174, 0, 0, 0, 179, 181, 181, 182, 184, 206, 206, 206, 207, 206, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 26, 29, 30, 31, 32, 33, 59, 63, 66, 70, 73, 74, 76, 77, 83, 87, 90, 94, 97, 99, 100, 101, 109, 110, 111, 117, 121, 124, 128, 131, 133, 134, 135, 141, 147, 151, 154, 158, 160, 165, 166, 168, 179, 182, 187, 188, 189, 198, 201, 205, 208, 212, 215, 219, 222, 226, 229};
/* BEGIN LINEINFO 
assign 1 35 24
new 0 35 24
assign 1 35 25
new 2 35 25
return 1 35 26
assign 1 40 29
new 0 40 29
assign 1 41 30
assign 1 42 31
new 0 42 31
assign 1 43 32
new 0 43 32
assign 1 44 33
new 0 44 33
assign 1 0 59
assign 1 0 63
assign 1 0 66
advance 0 107 70
assign 1 110 73
new 0 110 73
return 1 110 74
assign 1 112 76
new 0 112 76
return 1 112 77
assign 1 0 83
assign 1 0 87
assign 1 0 90
advance 0 117 94
return 1 120 97
assign 1 122 99
new 0 122 99
assign 1 123 100
currentNameGet 0 123 100
return 1 123 101
assign 1 143 109
new 0 143 109
assign 1 143 110
substring 1 143 110
return 1 143 111
assign 1 0 117
assign 1 0 121
assign 1 0 124
advance 0 148 128
return 1 151 131
assign 1 153 133
new 0 153 133
assign 1 154 134
currentGet 0 154 134
return 1 154 135
return 1 174 141
assign 1 0 147
assign 1 0 151
assign 1 0 154
advance 0 179 158
assign 1 181 160
not 0 181 165
currentSet 1 182 166
assign 1 184 168
new 0 184 168
assign 1 206 179
new 0 206 179
assign 1 206 182
lesser 1 206 187
nextSet 1 207 188
incrementValue 0 206 189
return 1 0 198
assign 1 0 201
return 1 0 205
assign 1 0 208
return 1 0 212
assign 1 0 215
return 1 0 219
assign 1 0 222
return 1 0 226
assign 1 0 229
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 1704272071: return bem_copy_0();
case -522948307: return bem_currentNameGet_0();
case 16424274: return bem_iteratorGet_0();
case 1277077124: return bem_once_0();
case 1155378903: return bem_advance_0();
case -146459624: return bem_tagGet_0();
case 1818190775: return bem_toString_0();
case 371037351: return bem_hashGet_0();
case 1190997837: return bem_print_0();
case -1613660155: return bem_serializationIteratorGet_0();
case -2076341414: return bem_hasNextGet_0();
case -1181834336: return bem_serializeToString_0();
case 308705107: return bem_serializeContents_0();
case 1065142995: return bem_nextNameGet_0();
case -124707028: return bem_doneGet_0();
case -1641663327: return bem_nextGet_0();
case 1142594603: return bem_posGet_0();
case -286713957: return bem_advancedGet_0();
case -1971603557: return bem_tvalGet_0();
case 1133560869: return bem_new_0();
case -457378134: return bem_sourceFileNameGet_0();
case 437585929: return bem_currentGet_0();
case 1985246514: return bem_classNameGet_0();
case -1751704975: return bem_many_0();
case -67432972: return bem_fieldIteratorGet_0();
case -1132496695: return bem_instanceGet_0();
case 1567284243: return bem_create_0();
case -1538220610: return bem_echo_0();
case 642325680: return bem_deserializeClassNameGet_0();
case -563585217: return bem_toAny_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case -1508704559: return bem_copyTo_1(bevd_0);
case 1569101675: return bem_posSet_1(bevd_0);
case 1024493267: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2112413547: return bem_currentSet_1(bevd_0);
case 2101700701: return bem_undefined_1(bevd_0);
case -470059044: return bem_advancedSet_1(bevd_0);
case -2040876363: return bem_instanceSet_1(bevd_0);
case -1682170766: return bem_otherType_1(bevd_0);
case -503068138: return bem_sameType_1(bevd_0);
case 2077566448: return bem_sameClass_1(bevd_0);
case 1758579140: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 1398941771: return bem_def_1(bevd_0);
case -240186291: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 11116001: return bem_new_1(bevd_0);
case -1936197463: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -122042490: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -998345036: return bem_tvalSet_1(bevd_0);
case 1270721790: return bem_sameObject_1(bevd_0);
case -625783607: return bem_nextSet_1(bevd_0);
case 1933685650: return bem_equals_1(bevd_0);
case 579081683: return bem_defined_1(bevd_0);
case 1069670174: return bem_undef_1(bevd_0);
case -1210345122: return bem_notEquals_1(bevd_0);
case 1170591864: return bem_otherClass_1(bevd_0);
case -1836129771: return bem_doneSet_1(bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1408482482: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1097908484: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1722402091: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1055053136: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -153418843: return bem_new_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2112228411: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -483654719: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1372560242: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemObjectFieldIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_19_SystemObjectFieldIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst = (BEC_2_6_19_SystemObjectFieldIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;
}
}
}
