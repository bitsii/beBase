namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList : BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
static BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_1 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_10_4_ContainerLinkedListNode) (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
bevl_iter = bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 137 */ {
return (BEC_2_6_6_SystemObject) bevl_other;
} /* Line: 138 */
while (true)
 /* Line: 142 */ {
if (bevl_f == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 144 */ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 145 */
if (bevl_fnode == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevl_fnode = bevl_f;
} /* Line: 149 */
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 152 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(1546002946, null);
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 161 */ {
beva_node.bemd_1(525071084, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 164 */
 else  /* Line: 165 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 167 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(1546002946, null);
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 173 */ {
beva_node.bemd_1(1546002946, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 176 */
 else  /* Line: 177 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 179 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) {
beva_node.bemd_0(927318721);
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) {
beva_node.bemd_1(-2112810488, beva_toIns);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_0;
if (beva_pos.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_2_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_2_tmpany_phold;
} /* Line: 193 */
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 196 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 196 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 198 */
 else  /* Line: 199 */ {
break;
} /* Line: 200 */
bevl_i.bevi_int++;
} /* Line: 202 */
 else  /* Line: 196 */ {
break;
} /* Line: 196 */
} /* Line: 196 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 204 */ {
return null;
} /* Line: 205 */
bevt_6_tmpany_phold = bevl_iter.bem_nextGet_0();
return bevt_6_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_1;
beva_pos = beva_pos.bem_add_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 213 */ {
bevt_1_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 213 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 215 */
 else  /* Line: 216 */ {
break;
} /* Line: 217 */
bevl_i.bevi_int++;
} /* Line: 219 */
 else  /* Line: 213 */ {
break;
} /* Line: 213 */
} /* Line: 213 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 222 */
bevt_5_tmpany_phold = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 228 */ {
return null;
} /* Line: 228 */
bevt_1_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_secondGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_3_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 233 */
 else  /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 233 */ {
bevt_5_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_heldGet_0();
return bevt_4_tmpany_phold;
} /* Line: 234 */
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_thirdGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_4_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
 else  /* Line: 240 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 240 */ {
bevt_7_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_nextGet_0();
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
 else  /* Line: 240 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 240 */ {
bevt_10_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_nextGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_heldGet_0();
return bevt_8_tmpany_phold;
} /* Line: 241 */
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 247 */ {
return null;
} /* Line: 247 */
bevt_1_tmpany_phold = bevp_lastNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = beva_pos.bemd_1(45057151, bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 252 */ {
return bevp_firstNode;
} /* Line: 253 */
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 256 */ {
bevt_2_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 256 */ {
bevt_3_tmpany_phold = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos );
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 257 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 258 */
 else  /* Line: 259 */ {
break;
} /* Line: 260 */
bevl_i.bevi_int++;
} /* Line: 262 */
 else  /* Line: 256 */ {
break;
} /* Line: 256 */
} /* Line: 256 */
bevt_4_tmpany_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 264 */ {
return null;
} /* Line: 265 */
bevt_5_tmpany_phold = bevl_iter.bem_nextNodeGet_0();
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_addValue_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_held == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_2_tmpany_phold = beva_held.bemd_1(1579053823, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 276 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 276 */
 else  /* Line: 276 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 276 */ {
bem_addAll_1(beva_held);
} /* Line: 277 */
 else  /* Line: 278 */ {
bem_addValueWhole_1(beva_held);
} /* Line: 279 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 284 */ {
while (true)
 /* Line: 285 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(452370668);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 285 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(-939463792);
bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 286 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
} /* Line: 285 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 292 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(1211836779);
bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 293 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_prepend_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lengthGet_0() {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 304 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 304 */ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 306 */
 else  /* Line: 304 */ {
break;
} /* Line: 304 */
} /* Line: 304 */
return bevl_cnt;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_lengthGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 316 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 317 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_toNodeList_0() {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 326 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 326 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_2_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 328 */
bevl_cnt.bevi_int++;
} /* Line: 330 */
 else  /* Line: 326 */ {
break;
} /* Line: 326 */
} /* Line: 326 */
return bevl_toret;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_toList_0() {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 339 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 339 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 340 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-704432874);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 341 */
bevl_cnt.bevi_int++;
} /* Line: 343 */
 else  /* Line: 339 */ {
break;
} /* Line: 339 */
} /* Line: 339 */
return bevl_toret;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_maxGet_0();
bevt_0_tmpany_phold = bem_subList_2(beva_start, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 366 */ {
return bevl_res;
} /* Line: 367 */
bevl_iter = bem_linkedListIteratorGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 370 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 370 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-1871237475);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 371 */ {
return bevl_res;
} /* Line: 372 */
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 375 */ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 376 */
bevl_i.bevi_int++;
} /* Line: 370 */
 else  /* Line: 370 */ {
break;
} /* Line: 370 */
} /* Line: 370 */
return bevl_res;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_reverse_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_tmpany_phold = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
 /* Line: 419 */ {
if (bevl_current == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_tmpany_phold = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_tmpany_phold);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 424 */
 else  /* Line: 419 */ {
break;
} /* Line: 419 */
} /* Line: 419 */
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() {
return bevp_firstNode;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() {
return bevp_lastNode;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {129, 129, 134, 135, 136, 137, 137, 138, 142, 142, 143, 144, 144, 145, 148, 148, 149, 151, 152, 154, 155, 156, 160, 161, 161, 162, 163, 164, 166, 167, 172, 173, 173, 174, 175, 176, 178, 179, 184, 188, 192, 192, 192, 193, 193, 195, 196, 196, 197, 197, 198, 202, 204, 204, 205, 207, 207, 211, 211, 212, 213, 213, 214, 214, 215, 219, 221, 221, 222, 222, 224, 224, 228, 228, 228, 229, 229, 233, 233, 233, 233, 233, 0, 0, 0, 234, 234, 234, 236, 240, 240, 240, 240, 240, 0, 0, 0, 240, 240, 240, 240, 0, 0, 0, 241, 241, 241, 241, 243, 247, 247, 247, 248, 248, 252, 252, 253, 255, 256, 256, 257, 258, 262, 264, 265, 267, 267, 271, 272, 276, 276, 276, 0, 0, 0, 277, 279, 284, 284, 285, 286, 286, 292, 292, 293, 293, 298, 299, 303, 304, 304, 305, 306, 308, 312, 312, 316, 316, 317, 317, 319, 319, 323, 324, 325, 326, 326, 327, 327, 328, 328, 330, 332, 336, 337, 338, 339, 339, 340, 340, 341, 341, 341, 343, 345, 349, 349, 353, 353, 357, 357, 361, 361, 361, 361, 365, 366, 366, 367, 369, 370, 370, 370, 371, 371, 372, 374, 375, 375, 376, 370, 379, 417, 418, 419, 419, 420, 421, 421, 422, 423, 424, 426, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 31, 32, 33, 34, 39, 40, 44, 49, 50, 51, 56, 57, 59, 64, 65, 67, 68, 74, 75, 76, 80, 81, 86, 87, 88, 89, 92, 93, 99, 100, 105, 106, 107, 108, 111, 112, 117, 121, 134, 135, 140, 141, 142, 144, 145, 148, 150, 155, 156, 161, 167, 172, 173, 175, 176, 187, 188, 189, 190, 193, 195, 200, 201, 206, 212, 217, 218, 219, 221, 222, 227, 232, 233, 235, 236, 245, 250, 251, 252, 257, 258, 261, 265, 268, 269, 270, 272, 286, 291, 292, 293, 298, 299, 302, 306, 309, 310, 311, 316, 317, 320, 324, 327, 328, 329, 330, 332, 337, 342, 343, 345, 346, 357, 358, 360, 362, 363, 366, 368, 370, 375, 381, 383, 385, 386, 390, 391, 398, 403, 404, 406, 409, 413, 416, 419, 427, 432, 435, 437, 438, 450, 455, 456, 457, 463, 464, 471, 472, 475, 477, 478, 484, 488, 489, 495, 500, 501, 502, 504, 505, 515, 516, 517, 518, 521, 523, 528, 529, 530, 532, 538, 549, 550, 551, 552, 555, 557, 562, 563, 564, 565, 567, 573, 577, 578, 582, 583, 587, 588, 594, 595, 596, 597, 609, 610, 615, 616, 618, 619, 622, 627, 628, 629, 631, 633, 634, 639, 640, 642, 648, 656, 657, 660, 665, 666, 667, 668, 669, 670, 671, 677, 681, 684, 688, 691};
/* BEGIN LINEINFO 
assign 1 129 18
new 2 129 18
return 1 129 19
assign 1 134 31
create 0 134 31
assign 1 135 32
linkedListIteratorGet 0 135 32
assign 1 136 33
nextNodeGet 0 136 33
assign 1 137 34
undef 1 137 39
return 1 138 40
assign 1 142 44
def 1 142 49
assign 1 143 50
copy 0 143 50
assign 1 144 51
def 1 144 56
nextSet 1 145 57
assign 1 148 59
undef 1 148 64
assign 1 149 65
assign 1 151 67
assign 1 152 68
nextNodeGet 0 152 68
firstNodeSet 1 154 74
lastNodeSet 1 155 75
return 1 156 76
nextSet 1 160 80
assign 1 161 81
def 1 161 86
priorSet 1 162 87
nextSet 1 163 88
assign 1 164 89
assign 1 166 92
assign 1 167 93
nextSet 1 172 99
assign 1 173 100
def 1 173 105
nextSet 1 174 106
priorSet 1 175 107
assign 1 176 108
assign 1 178 111
assign 1 179 112
delete 0 184 117
insertBefore 1 188 121
assign 1 192 134
new 0 192 134
assign 1 192 135
equals 1 192 140
assign 1 193 141
heldGet 0 193 141
return 1 193 142
assign 1 195 144
new 0 195 144
assign 1 196 145
linkedListIteratorGet 0 196 145
assign 1 196 148
hasNextGet 0 196 148
assign 1 197 150
lesser 1 197 155
nextGet 0 198 156
incrementValue 0 202 161
assign 1 204 167
notEquals 1 204 172
return 1 205 173
assign 1 207 175
nextGet 0 207 175
return 1 207 176
assign 1 211 187
new 0 211 187
assign 1 211 188
add 1 211 188
assign 1 212 189
new 0 212 189
assign 1 213 190
linkedListIteratorGet 0 213 190
assign 1 213 193
hasNextGet 0 213 193
assign 1 214 195
lesser 1 214 200
nextGet 0 215 201
incrementValue 0 219 206
assign 1 221 212
notEquals 1 221 217
assign 1 222 218
new 0 222 218
return 1 222 219
assign 1 224 221
currentSet 1 224 221
return 1 224 222
assign 1 228 227
undef 1 228 232
return 1 228 233
assign 1 229 235
heldGet 0 229 235
return 1 229 236
assign 1 233 245
def 1 233 250
assign 1 233 251
nextGet 0 233 251
assign 1 233 252
def 1 233 257
assign 1 0 258
assign 1 0 261
assign 1 0 265
assign 1 234 268
nextGet 0 234 268
assign 1 234 269
heldGet 0 234 269
return 1 234 270
return 1 236 272
assign 1 240 286
def 1 240 291
assign 1 240 292
nextGet 0 240 292
assign 1 240 293
def 1 240 298
assign 1 0 299
assign 1 0 302
assign 1 0 306
assign 1 240 309
nextGet 0 240 309
assign 1 240 310
nextGet 0 240 310
assign 1 240 311
def 1 240 316
assign 1 0 317
assign 1 0 320
assign 1 0 324
assign 1 241 327
nextGet 0 241 327
assign 1 241 328
nextGet 0 241 328
assign 1 241 329
heldGet 0 241 329
return 1 241 330
return 1 243 332
assign 1 247 337
undef 1 247 342
return 1 247 343
assign 1 248 345
heldGet 0 248 345
return 1 248 346
assign 1 252 357
new 0 252 357
assign 1 252 358
equals 1 252 358
return 1 253 360
assign 1 255 362
new 0 255 362
assign 1 256 363
linkedListIteratorGet 0 256 363
assign 1 256 366
hasNextGet 0 256 366
assign 1 257 368
lesser 1 257 368
nextGet 0 258 370
incrementValue 0 262 375
assign 1 264 381
notEquals 1 264 381
return 1 265 383
assign 1 267 385
nextNodeGet 0 267 385
return 1 267 386
assign 1 271 390
newNode 1 271 390
appendNode 1 272 391
assign 1 276 398
def 1 276 403
assign 1 276 404
sameType 1 276 404
assign 1 0 406
assign 1 0 409
assign 1 0 413
addAll 1 277 416
addValueWhole 1 279 419
assign 1 284 427
def 1 284 432
assign 1 285 435
hasNextGet 0 285 435
assign 1 286 437
nextGet 0 286 437
addValueWhole 1 286 438
assign 1 292 450
def 1 292 455
assign 1 293 456
iteratorGet 0 293 456
iterateAdd 1 293 457
assign 1 298 463
newNode 1 298 463
prependNode 1 299 464
assign 1 303 471
new 0 303 471
assign 1 304 472
linkedListIteratorGet 0 304 472
assign 1 304 475
hasNextGet 0 304 475
nextGet 0 305 477
incrementValue 0 306 478
return 1 308 484
assign 1 312 488
lengthGet 0 312 488
return 1 312 489
assign 1 316 495
undef 1 316 500
assign 1 317 501
new 0 317 501
return 1 317 502
assign 1 319 504
new 0 319 504
return 1 319 505
assign 1 323 515
lengthGet 0 323 515
assign 1 324 516
new 1 324 516
assign 1 325 517
new 0 325 517
assign 1 326 518
linkedListIteratorGet 0 326 518
assign 1 326 521
hasNextGet 0 326 521
assign 1 327 523
lesser 1 327 528
assign 1 328 529
nextNodeGet 0 328 529
put 2 328 530
incrementValue 0 330 532
return 1 332 538
assign 1 336 549
lengthGet 0 336 549
assign 1 337 550
new 1 337 550
assign 1 338 551
new 0 338 551
assign 1 339 552
linkedListIteratorGet 0 339 552
assign 1 339 555
hasNextGet 0 339 555
assign 1 340 557
lesser 1 340 562
assign 1 341 563
nextNodeGet 0 341 563
assign 1 341 564
heldGet 0 341 564
put 2 341 565
incrementValue 0 343 567
return 1 345 573
assign 1 349 577
new 1 349 577
return 1 349 578
assign 1 353 582
new 1 353 582
return 1 353 583
assign 1 357 587
iteratorGet 0 357 587
return 1 357 588
assign 1 361 594
new 0 361 594
assign 1 361 595
maxGet 0 361 595
assign 1 361 596
subList 2 361 596
return 1 361 597
assign 1 365 609
create 0 365 609
assign 1 366 610
lesserEquals 1 366 615
return 1 367 616
assign 1 369 618
linkedListIteratorGet 0 369 618
assign 1 370 619
new 0 370 619
assign 1 370 622
lesser 1 370 627
assign 1 371 628
hasNextGet 0 371 628
assign 1 371 629
not 0 371 629
return 1 372 631
assign 1 374 633
nextGet 0 374 633
assign 1 375 634
greaterEquals 1 375 639
addValue 1 376 640
incrementValue 0 370 642
return 1 379 648
assign 1 417 656
assign 1 418 657
assign 1 419 660
def 1 419 665
assign 1 420 666
nextGet 0 420 666
assign 1 421 667
priorGet 0 421 667
nextSet 1 421 668
priorSet 1 422 669
assign 1 423 670
assign 1 424 671
assign 1 426 677
return 1 0 681
assign 1 0 684
return 1 0 688
assign 1 0 691
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 750836929: return bem_toList_0();
case 1065987271: return bem_isEmptyGet_0();
case -1888508563: return bem_serializationIteratorGet_0();
case 1310164435: return bem_serializeContents_0();
case -1976290782: return bem_print_0();
case 142206752: return bem_many_0();
case -2052611744: return bem_once_0();
case -1787509094: return bem_lastGet_0();
case -1193265838: return bem_new_0();
case 2098501683: return bem_create_0();
case -1896601781: return bem_toAny_0();
case -1152001976: return bem_copy_0();
case 1278477757: return bem_serializeToString_0();
case 444169984: return bem_sourceFileNameGet_0();
case -1676573633: return bem_firstNodeGet_0();
case -934156869: return bem_lengthGet_0();
case 1460361100: return bem_reverse_0();
case -2123403535: return bem_secondGet_0();
case 839655824: return bem_firstGet_0();
case -326646035: return bem_toString_0();
case 752911959: return bem_hashGet_0();
case 880152096: return bem_classNameGet_0();
case 2141550628: return bem_deserializeClassNameGet_0();
case 1886181223: return bem_linkedListIteratorGet_0();
case -144770218: return bem_lastNodeGet_0();
case 1121781060: return bem_thirdGet_0();
case -364515046: return bem_fieldIteratorGet_0();
case 1211836779: return bem_iteratorGet_0();
case -2091198124: return bem_tagGet_0();
case 671682800: return bem_toNodeList_0();
case -1635570417: return bem_sizeGet_0();
case 2085674875: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 607370643: return bem_undefined_1(bevd_0);
case -420783891: return bem_deleteNode_1(bevd_0);
case 1048239710: return bem_sameClass_1(bevd_0);
case -15835243: return bem_appendNode_1(bevd_0);
case 986477958: return bem_defined_1(bevd_0);
case 227196235: return bem_addValue_1(bevd_0);
case 136677527: return bem_def_1(bevd_0);
case 1948085050: return bem_undef_1(bevd_0);
case -912779684: return bem_firstNodeSet_1(bevd_0);
case 45057151: return bem_equals_1(bevd_0);
case 1268433926: return bem_otherClass_1(bevd_0);
case 704393933: return bem_addAll_1(bevd_0);
case 496808651: return bem_sameObject_1(bevd_0);
case -1191000829: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -22493199: return bem_newNode_1(bevd_0);
case 1579053823: return bem_sameType_1(bevd_0);
case 1531010263: return bem_iterateAdd_1(bevd_0);
case 930180418: return bem_copyTo_1(bevd_0);
case -1838383521: return bem_prepend_1(bevd_0);
case -356756608: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -1321282362: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -785327205: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 476449076: return bem_addValueWhole_1(bevd_0);
case 1732923676: return bem_lastNodeSet_1(bevd_0);
case 275457317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1990827367: return bem_notEquals_1(bevd_0);
case 1540562821: return bem_getNode_1(bevd_0);
case 340047415: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1866601742: return bem_otherType_1(bevd_0);
case -1308806297: return bem_prependNode_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 686788947: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1768228505: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1127271797: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -1400688487: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 253281852: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1848289028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -563012599: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 893523384: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1867154600: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1481064275: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_10_ContainerLinkedList_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_10_ContainerLinkedList_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_10_ContainerLinkedList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst = (BEC_2_9_10_ContainerLinkedList) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;
}
}
}
