namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerQueue : BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerQueue() { }
static BEC_2_9_5_ContainerQueue() { }
private static byte[] becc_BEC_2_9_5_ContainerQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_5_ContainerQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_2_9_5_ContainerQueue bece_BEC_2_9_5_ContainerQueue_bevs_inst;

public static new BET_2_9_5_ContainerQueue bece_BEC_2_9_5_ContainerQueue_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_bottom;
public BEC_3_9_5_4_ContainerStackNode bevp_end;
public BEC_2_4_3_MathInt bevp_size;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_addValue_1(BEC_2_6_6_SystemObject beva_item) {
bem_enqueue_1(beva_item);
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_end = bevp_top;
bevp_bottom = bevp_top;
} /* Line: 128 */
 else  /* Line: 125 */ {
if (bevp_bottom == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevt_3_tmpany_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevt_4_tmpany_phold = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpany_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
bevp_end = bevp_top;
} /* Line: 134 */
 else  /* Line: 135 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 136 */
} /* Line: 130 */
 else  /* Line: 138 */ {
bevp_bottom = bevp_top;
} /* Line: 139 */
} /* Line: 125 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_dequeue_0() {
BEC_2_6_6_SystemObject bevl_item = null;
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 146 */ {
return null;
} /* Line: 147 */
bevl_item = bevp_bottom.bem_heldGet_0();
bevp_bottom.bem_heldSet_1(null);
bevt_1_tmpany_phold = bevp_bottom.bem_equals_1(bevp_top);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 151 */ {
bevp_bottom = null;
} /* Line: 152 */
 else  /* Line: 153 */ {
bevl_last = bevp_bottom;
bevp_bottom = bevp_bottom.bem_nextGet_0();
bevl_last.bem_nextSet_1(null);
bevl_last.bem_priorSet_1(bevp_end);
bevp_end.bem_nextSet_1(bevl_last);
bevp_end = bevl_last;
} /* Line: 160 */
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_dequeue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_9_5_ContainerQueue bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_5_ContainerQueue) bem_enqueue_1(beva_item);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_topGet_0() {
return bevp_top;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGetDirect_0() {
return bevp_top;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_topSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_bottomGet_0() {
return bevp_bottom;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_bottomGetDirect_0() {
return bevp_bottom;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_bottomSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bottom = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_bottomSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bottom = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_endGet_0() {
return bevp_end;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_endGetDirect_0() {
return bevp_end;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_endSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_end = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_endSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_end = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {115, 121, 125, 125, 126, 127, 128, 129, 129, 130, 130, 130, 131, 131, 132, 132, 133, 134, 136, 139, 141, 142, 146, 146, 147, 149, 150, 151, 152, 155, 156, 157, 158, 159, 160, 162, 163, 167, 167, 171, 171, 175, 175, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 21, 31, 36, 37, 38, 39, 42, 47, 48, 49, 54, 55, 56, 57, 58, 59, 60, 63, 67, 70, 71, 79, 84, 85, 87, 88, 89, 91, 94, 95, 96, 97, 98, 99, 101, 102, 106, 111, 115, 116, 120, 121, 124, 127, 130, 134, 138, 141, 144, 148, 152, 155, 158, 162, 166, 169, 172, 176};
/* BEGIN LINEINFO 
assign 1 115 17
new 0 115 17
enqueue 1 121 21
assign 1 125 31
undef 1 125 36
assign 1 126 37
new 0 126 37
assign 1 127 38
assign 1 128 39
assign 1 129 42
def 1 129 47
assign 1 130 48
nextGet 0 130 48
assign 1 130 49
undef 1 130 54
assign 1 131 55
new 0 131 55
nextSet 1 131 56
assign 1 132 57
nextGet 0 132 57
priorSet 1 132 58
assign 1 133 59
nextGet 0 133 59
assign 1 134 60
assign 1 136 63
nextGet 0 136 63
assign 1 139 67
heldSet 1 141 70
assign 1 142 71
increment 0 142 71
assign 1 146 79
undef 1 146 84
return 1 147 85
assign 1 149 87
heldGet 0 149 87
heldSet 1 150 88
assign 1 151 89
equals 1 151 89
assign 1 152 91
assign 1 155 94
assign 1 156 95
nextGet 0 156 95
nextSet 1 157 96
priorSet 1 158 97
nextSet 1 159 98
assign 1 160 99
assign 1 162 101
decrement 0 162 101
return 1 163 102
assign 1 167 106
undef 1 167 111
return 1 167 111
assign 1 171 115
dequeue 0 171 115
return 1 171 116
assign 1 175 120
enqueue 1 175 120
return 1 175 121
return 1 0 124
return 1 0 127
assign 1 0 130
assign 1 0 134
return 1 0 138
return 1 0 141
assign 1 0 144
assign 1 0 148
return 1 0 152
return 1 0 155
assign 1 0 158
assign 1 0 162
return 1 0 166
return 1 0 169
assign 1 0 172
assign 1 0 176
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1514587988: return bem_sizeGetDirect_0();
case -675377167: return bem_sourceFileNameGet_0();
case -853943837: return bem_fieldNamesGet_0();
case -1939888280: return bem_classNameGet_0();
case 427020448: return bem_tagGet_0();
case 705904898: return bem_echo_0();
case -211405898: return bem_sizeGet_0();
case -307999784: return bem_bottomGet_0();
case 740377946: return bem_fieldIteratorGet_0();
case -1014054591: return bem_bottomGetDirect_0();
case 4057483: return bem_toString_0();
case -1043866834: return bem_deserializeClassNameGet_0();
case 1323651102: return bem_endGet_0();
case 653878290: return bem_topGetDirect_0();
case 1277127917: return bem_hashGet_0();
case 485739285: return bem_many_0();
case -363455556: return bem_print_0();
case -769908714: return bem_serializeContents_0();
case 2143199287: return bem_once_0();
case 1830393821: return bem_serializationIteratorGet_0();
case -749374888: return bem_toAny_0();
case 1177769174: return bem_endGetDirect_0();
case -712991493: return bem_isEmptyGet_0();
case 781809181: return bem_topGet_0();
case -996999342: return bem_get_0();
case -2047177330: return bem_copy_0();
case 1113652033: return bem_serializeToString_0();
case -481509271: return bem_new_0();
case 402987838: return bem_dequeue_0();
case 905957116: return bem_create_0();
case -143076951: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2021680719: return bem_sameObject_1(bevd_0);
case 46966099: return bem_enqueue_1(bevd_0);
case -2125260308: return bem_put_1(bevd_0);
case 1869171490: return bem_addValue_1(bevd_0);
case -1071341413: return bem_otherType_1(bevd_0);
case -383438063: return bem_def_1(bevd_0);
case -559809649: return bem_sizeSet_1(bevd_0);
case 1353862901: return bem_sameType_1(bevd_0);
case 1474173561: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1709376459: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1755877526: return bem_notEquals_1(bevd_0);
case 1188348759: return bem_bottomSetDirect_1(bevd_0);
case -577185499: return bem_endSetDirect_1(bevd_0);
case 387045406: return bem_topSet_1(bevd_0);
case -988024628: return bem_undef_1(bevd_0);
case -2137592378: return bem_undefined_1(bevd_0);
case -271328767: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2122304776: return bem_equals_1(bevd_0);
case -136446475: return bem_otherClass_1(bevd_0);
case -1020635283: return bem_endSet_1(bevd_0);
case -1520063387: return bem_defined_1(bevd_0);
case -1146330011: return bem_topSetDirect_1(bevd_0);
case -73636763: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -578389793: return bem_sameClass_1(bevd_0);
case 1026205031: return bem_sizeSetDirect_1(bevd_0);
case 1120611818: return bem_bottomSet_1(bevd_0);
case -1924831101: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 503438982: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 837534085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 851139439: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 129124545: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1276325839: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 440463842: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -929921852: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerQueue_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerQueue_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_5_ContainerQueue();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_inst = (BEC_2_9_5_ContainerQueue) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_type;
}
}
}
