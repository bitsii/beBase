namespace be {

using System.IO;
using System;
    /* IO:File: source/base/Int.be */
public sealed class BEC_2_4_4_MathInts : BEC_2_6_6_SystemObject {
public BEC_2_4_4_MathInts() { }
static BEC_2_4_4_MathInts() { }
private static byte[] becc_BEC_2_4_4_MathInts_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_4_4_MathInts_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
public static new BEC_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_inst;

public static new BET_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public BEC_2_4_3_MathInt bevp_min;
public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_default_0() {
BEC_2_4_3_MathInt bevl__max = null;
BEC_2_4_3_MathInt bevl__min = null;
bevl__max = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl__min = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl__max.bevi_int = int.MaxValue;
      bevl__min.bevi_int = int.MinValue;
      //Stream stdout = Console.OpenStandardOutput();
      //Console.WriteLine(bevl__max.bevi_int.ToString());
      //Console.WriteLine(bevl__min.bevi_int.ToString());
      bevp_max = bevl__max;
bevp_min = bevl__min;
bevp_zero = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_one = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_min_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 945*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 945*/ {
if (beva_a.bevi_int < beva_b.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 945*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 945*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 945*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 945*/ {
return beva_a;
} /* Line: 946*/
return beva_b;
} /*method end*/
public BEC_2_6_6_SystemObject bem_max_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 952*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 952*/ {
if (beva_a.bevi_int > beva_b.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 952*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 952*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 952*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 952*/ {
return beva_a;
} /* Line: 953*/
return beva_b;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() {
return bevp_max;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGetDirect_0() {
return bevp_max;
} /*method end*/
public BEC_2_4_4_MathInts bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_maxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_minGet_0() {
return bevp_min;
} /*method end*/
public BEC_2_4_3_MathInt bem_minGetDirect_0() {
return bevp_min;
} /*method end*/
public BEC_2_4_4_MathInts bem_minSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_minSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() {
return bevp_zero;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGetDirect_0() {
return bevp_zero;
} /*method end*/
public BEC_2_4_4_MathInts bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_zeroSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGet_0() {
return bevp_one;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGetDirect_0() {
return bevp_one;
} /*method end*/
public BEC_2_4_4_MathInts bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_oneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {891, 892, 937, 938, 939, 940, 945, 945, 0, 945, 945, 0, 0, 946, 948, 952, 952, 0, 952, 952, 0, 0, 953, 955, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 33, 34, 35, 36, 43, 48, 49, 52, 57, 58, 61, 65, 67, 73, 78, 79, 82, 87, 88, 91, 95, 97, 100, 103, 106, 110, 114, 117, 120, 124, 128, 131, 134, 138, 142, 145, 148, 152};
/* BEGIN LINEINFO 
assign 1 891 25
new 0 891 25
assign 1 892 26
new 0 892 26
assign 1 937 33
assign 1 938 34
assign 1 939 35
new 0 939 35
assign 1 940 36
new 0 940 36
assign 1 945 43
undef 1 945 48
assign 1 0 49
assign 1 945 52
lesser 1 945 57
assign 1 0 58
assign 1 0 61
return 1 946 65
return 1 948 67
assign 1 952 73
undef 1 952 78
assign 1 0 79
assign 1 952 82
greater 1 952 87
assign 1 0 88
assign 1 0 91
return 1 953 95
return 1 955 97
return 1 0 100
return 1 0 103
assign 1 0 106
assign 1 0 110
return 1 0 114
return 1 0 117
assign 1 0 120
assign 1 0 124
return 1 0 128
return 1 0 131
assign 1 0 134
assign 1 0 138
return 1 0 142
return 1 0 145
assign 1 0 148
assign 1 0 152
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1597530459: return bem_print_0();
case 721123821: return bem_tagGet_0();
case 216633460: return bem_serializeContents_0();
case 532225599: return bem_minGetDirect_0();
case 19210432: return bem_iteratorGet_0();
case 804571648: return bem_oneGetDirect_0();
case -390286916: return bem_serializeToString_0();
case -1981760132: return bem_zeroGet_0();
case -827080774: return bem_copy_0();
case 1291824271: return bem_echo_0();
case 1562356496: return bem_hashGet_0();
case -745407841: return bem_minGet_0();
case -247222759: return bem_maxGet_0();
case 559255035: return bem_fieldNamesGet_0();
case 1210301124: return bem_default_0();
case 270781002: return bem_new_0();
case 595935693: return bem_create_0();
case -1123266766: return bem_classNameGet_0();
case 1151085267: return bem_deserializeClassNameGet_0();
case 1721043418: return bem_zeroGetDirect_0();
case -1022690463: return bem_oneGet_0();
case -1869924457: return bem_sourceFileNameGet_0();
case -860520942: return bem_toString_0();
case -1156903676: return bem_serializationIteratorGet_0();
case -601453628: return bem_fieldIteratorGet_0();
case 572381564: return bem_maxGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1975186613: return bem_zeroSet_1(bevd_0);
case -637072093: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -499138365: return bem_otherClass_1(bevd_0);
case -323113819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1788911287: return bem_sameType_1(bevd_0);
case 1039929772: return bem_minSet_1(bevd_0);
case -2138090541: return bem_sameClass_1(bevd_0);
case 1686511848: return bem_maxSet_1(bevd_0);
case -89866327: return bem_copyTo_1(bevd_0);
case -1583768782: return bem_oneSetDirect_1(bevd_0);
case 2010280787: return bem_maxSetDirect_1(bevd_0);
case -696336738: return bem_equals_1(bevd_0);
case 1720726298: return bem_def_1(bevd_0);
case -690535851: return bem_sameObject_1(bevd_0);
case -478520463: return bem_undef_1(bevd_0);
case -327732297: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1582378113: return bem_notEquals_1(bevd_0);
case 1469114272: return bem_minSetDirect_1(bevd_0);
case 850066440: return bem_zeroSetDirect_1(bevd_0);
case 119358172: return bem_oneSet_1(bevd_0);
case 2140620274: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -77252171: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 350317076: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1828646701: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -979599058: return bem_min_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -104691827: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -733779503: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1478601479: return bem_max_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_MathInts_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_4_MathInts_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_4_MathInts();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst = (BEC_2_4_4_MathInts) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_type;
}
}
}
