namespace be {

using System.IO;
using System;
    /* IO:File: source/base/Int.be */
public sealed class BEC_2_4_4_MathInts : BEC_2_6_6_SystemObject {
public BEC_2_4_4_MathInts() { }
static BEC_2_4_4_MathInts() { }
private static byte[] becc_BEC_2_4_4_MathInts_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_4_4_MathInts_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
public static new BEC_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_inst;
public BEC_2_4_3_MathInt bevp_max;
public BEC_2_4_3_MathInt bevp_min;
public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_default_0() {
BEC_2_4_3_MathInt bevl__max = null;
BEC_2_4_3_MathInt bevl__min = null;
bevl__max = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl__min = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl__max.bevi_int = int.MaxValue;
      bevl__min.bevi_int = int.MinValue;
      //Stream stdout = Console.OpenStandardOutput();
      //Console.WriteLine(bevl__max.bevi_int.ToString());
      //Console.WriteLine(bevl__min.bevi_int.ToString());
      bevp_max = bevl__max;
bevp_min = bevl__min;
bevp_zero = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_one = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_min_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 815 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 815 */ {
if (beva_a.bevi_int < beva_b.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 815 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 815 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 815 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 815 */ {
return beva_a;
} /* Line: 816 */
return beva_b;
} /*method end*/
public BEC_2_6_6_SystemObject bem_max_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 822 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 822 */ {
if (beva_a.bevi_int > beva_b.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 822 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 822 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 822 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 822 */ {
return beva_a;
} /* Line: 823 */
return beva_b;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() {
return bevp_max;
} /*method end*/
public BEC_2_4_4_MathInts bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_minGet_0() {
return bevp_min;
} /*method end*/
public BEC_2_4_4_MathInts bem_minSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() {
return bevp_zero;
} /*method end*/
public BEC_2_4_4_MathInts bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGet_0() {
return bevp_one;
} /*method end*/
public BEC_2_4_4_MathInts bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {767, 768, 807, 808, 809, 810, 815, 815, 0, 815, 815, 0, 0, 816, 818, 822, 822, 0, 822, 822, 0, 0, 823, 825, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 30, 31, 32, 33, 40, 45, 46, 49, 54, 55, 58, 62, 64, 70, 75, 76, 79, 84, 85, 88, 92, 94, 97, 100, 104, 107, 111, 114, 118, 121};
/* BEGIN LINEINFO 
assign 1 767 22
new 0 767 22
assign 1 768 23
new 0 768 23
assign 1 807 30
assign 1 808 31
assign 1 809 32
new 0 809 32
assign 1 810 33
new 0 810 33
assign 1 815 40
undef 1 815 45
assign 1 0 46
assign 1 815 49
lesser 1 815 54
assign 1 0 55
assign 1 0 58
return 1 816 62
return 1 818 64
assign 1 822 70
undef 1 822 75
assign 1 0 76
assign 1 822 79
greater 1 822 84
assign 1 0 85
assign 1 0 88
return 1 823 92
return 1 825 94
return 1 0 97
assign 1 0 100
return 1 0 104
assign 1 0 107
return 1 0 111
assign 1 0 114
return 1 0 118
assign 1 0 121
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 747222940: return bem_serializationIteratorGet_0();
case 774868823: return bem_many_0();
case 138118576: return bem_classNameGet_0();
case 173912112: return bem_iteratorGet_0();
case 1826655669: return bem_echo_0();
case 591133328: return bem_once_0();
case 169016919: return bem_deserializeClassNameGet_0();
case 156988171: return bem_toAny_0();
case -59113406: return bem_oneGet_0();
case 1030306077: return bem_hashGet_0();
case -751534347: return bem_tagGet_0();
case 441873246: return bem_fieldIteratorGet_0();
case 1090740031: return bem_minGet_0();
case 1804394239: return bem_create_0();
case 86234609: return bem_print_0();
case 605463834: return bem_sourceFileNameGet_0();
case -1688305827: return bem_maxGet_0();
case 1651099395: return bem_copy_0();
case 364146106: return bem_toString_0();
case -814108194: return bem_default_0();
case -1694865880: return bem_serializeToString_0();
case -571230888: return bem_zeroGet_0();
case 1232567589: return bem_new_0();
case 1335363828: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2078921482: return bem_notEquals_1(bevd_0);
case -548232463: return bem_copyTo_1(bevd_0);
case 719181640: return bem_zeroSet_1(bevd_0);
case -788518917: return bem_maxSet_1(bevd_0);
case -749747613: return bem_minSet_1(bevd_0);
case 818668120: return bem_def_1(bevd_0);
case -2077086955: return bem_sameType_1(bevd_0);
case 1049342566: return bem_equals_1(bevd_0);
case -729372880: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -293276429: return bem_undefined_1(bevd_0);
case 1022281941: return bem_defined_1(bevd_0);
case 1388122193: return bem_otherClass_1(bevd_0);
case -1790149278: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 280312858: return bem_sameObject_1(bevd_0);
case -1209387497: return bem_otherType_1(bevd_0);
case 143426895: return bem_undef_1(bevd_0);
case 233607642: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -66688367: return bem_sameClass_1(bevd_0);
case -956577031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -320623004: return bem_oneSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -936134816: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -265807180: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1675250987: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1997096203: return bem_min_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1991243589: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 521456062: return bem_max_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2096067718: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2037027110: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 808469705: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_MathInts_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_4_MathInts_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_4_MathInts();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst = (BEC_2_4_4_MathInts) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
}
}
}
