namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList : BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
static BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static new BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public override BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_10_9_ContainerLinkedListAwareNode) (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {111, 111};
public static new int[] bevs_smnlec
 = new int[] {14, 15};
/* BEGIN LINEINFO 
assign 1 111 14
new 2 111 14
return 1 111 15
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2047177330: return bem_copy_0();
case 740377946: return bem_fieldIteratorGet_0();
case 427020448: return bem_tagGet_0();
case 485739285: return bem_many_0();
case -1179103628: return bem_secondGet_0();
case 1824601363: return bem_lastGet_0();
case -1837190195: return bem_firstNodeGetDirect_0();
case -143076951: return bem_iteratorGet_0();
case 651401246: return bem_firstGet_0();
case 1019493946: return bem_linkedListIteratorGet_0();
case -211405898: return bem_sizeGet_0();
case -769908714: return bem_serializeContents_0();
case -675377167: return bem_sourceFileNameGet_0();
case 4057483: return bem_toString_0();
case 1830393821: return bem_serializationIteratorGet_0();
case -853943837: return bem_fieldNamesGet_0();
case 2143199287: return bem_once_0();
case 267241416: return bem_thirdGet_0();
case -2016941066: return bem_firstNodeGet_0();
case -712991493: return bem_isEmptyGet_0();
case -1939888280: return bem_classNameGet_0();
case -481509271: return bem_new_0();
case 905957116: return bem_create_0();
case -749374888: return bem_toAny_0();
case 1277127917: return bem_hashGet_0();
case -773604361: return bem_lastNodeGetDirect_0();
case 1678057088: return bem_lengthGet_0();
case 705904898: return bem_echo_0();
case -1875479728: return bem_toList_0();
case -1067175555: return bem_lastNodeGet_0();
case 5591028: return bem_reverse_0();
case -1043866834: return bem_deserializeClassNameGet_0();
case -363455556: return bem_print_0();
case 1113652033: return bem_serializeToString_0();
case -246277619: return bem_toNodeList_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1520063387: return bem_defined_1(bevd_0);
case 1755877526: return bem_notEquals_1(bevd_0);
case -160731296: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1766312441: return bem_iterateAdd_1(bevd_0);
case -383438063: return bem_def_1(bevd_0);
case -2137592378: return bem_undefined_1(bevd_0);
case -1389753655: return bem_appendNode_1(bevd_0);
case 1869171490: return bem_addValue_1(bevd_0);
case 1474173561: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2122304776: return bem_equals_1(bevd_0);
case -1071341413: return bem_otherType_1(bevd_0);
case 2110480176: return bem_firstNodeSet_1(bevd_0);
case 1353862901: return bem_sameType_1(bevd_0);
case -136446475: return bem_otherClass_1(bevd_0);
case -271328767: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2060026201: return bem_lastNodeSetDirect_1(bevd_0);
case 334859395: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -739429115: return bem_getNode_1(bevd_0);
case -1019655342: return bem_addAll_1(bevd_0);
case -312664831: return bem_lastNodeSet_1(bevd_0);
case -930916936: return bem_firstNodeSetDirect_1(bevd_0);
case -1924831101: return bem_copyTo_1(bevd_0);
case -73636763: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2021680719: return bem_sameObject_1(bevd_0);
case -988024628: return bem_undef_1(bevd_0);
case -578389793: return bem_sameClass_1(bevd_0);
case 386675455: return bem_prepend_1(bevd_0);
case -1026789060: return bem_newNode_1(bevd_0);
case 420983667: return bem_prependNode_1(bevd_0);
case -1709376459: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1196535922: return bem_addValueWhole_1(bevd_0);
case -1895363095: return bem_deleteNode_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -730007859: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 503438982: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 837534085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 851139439: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 129124545: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1276325839: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 440463842: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -929921852: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1759637330: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -2050378147: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_8_ContainerNodeList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
}
