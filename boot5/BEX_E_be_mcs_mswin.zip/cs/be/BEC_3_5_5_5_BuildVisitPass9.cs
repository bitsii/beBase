namespace be {
/* IO:File: source/build/Pass9.be */
public sealed class BEC_3_5_5_5_BuildVisitPass9 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass9() { }
static BEC_3_5_5_5_BuildVisitPass9() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass9_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x39};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass9_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x39,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x66,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x74,0x6F,0x6F,0x20,0x67,0x72,0x65,0x61,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass9_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass9_bels_0, 44));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_2 = {0x53,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_3 = {0x47,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_4 = {0x53,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_5 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_6 = {0x70,0x75,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_7 = {0x67,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_8 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_9 = {0x69,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_11 = {0x68,0x61,0x73,0x4E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_12 = {0x6E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_13 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_14 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_15 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_16 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x66,0x6F,0x72,0x20,0x6C,0x6F,0x6F,0x70,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x74,0x77,0x6F,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64};
public static new BEC_3_5_5_5_BuildVisitPass9 bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass9 bece_BEC_3_5_5_5_BuildVisitPass9_bevs_type;

public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_lbrnode = null;
BEC_2_6_6_SystemObject bevl_loopif = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_6_6_SystemObject bevl_cond = null;
BEC_2_6_6_SystemObject bevl_atStep = null;
BEC_2_6_6_SystemObject bevl_estr = null;
BEC_2_6_6_SystemObject bevl_ac = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevl_ntarg = null;
BEC_2_6_6_SystemObject bevl_isPut = null;
BEC_2_5_4_BuildNode bevl_narg2 = null;
BEC_2_5_4_BuildNode bevl_narg3 = null;
BEC_2_5_4_BuildNode bevl_linn = null;
BEC_2_6_6_SystemObject bevl_lin = null;
BEC_2_6_6_SystemObject bevl_lany = null;
BEC_2_6_6_SystemObject bevl_toit = null;
BEC_2_6_6_SystemObject bevl_tmpn = null;
BEC_2_6_6_SystemObject bevl_tmpv = null;
BEC_2_6_6_SystemObject bevl_gin = null;
BEC_2_6_6_SystemObject bevl_gic = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_asc = null;
BEC_2_6_6_SystemObject bevl_tmpnt = null;
BEC_2_6_6_SystemObject bevl_tcn = null;
BEC_2_6_6_SystemObject bevl_tcc = null;
BEC_2_6_6_SystemObject bevl_tmpng = null;
BEC_2_6_6_SystemObject bevl_iagn = null;
BEC_2_6_6_SystemObject bevl_iagc = null;
BEC_2_6_6_SystemObject bevl_iasn = null;
BEC_2_6_6_SystemObject bevl_iasc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_23_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_45_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_50_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_68_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_73_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_74_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_75_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_126_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_131_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_145_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_146_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_153_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_154_tmpany_phold = null;
bevt_7_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_8_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_7_tmpany_phold.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 31 */ {
beva_node.bem_initContained_0();
bevt_9_tmpany_phold = beva_node.bem_containedGet_0();
bevl_it = bevt_9_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 36 */ {
bevt_10_tmpany_phold = bevl_it.bemd_0(969322174);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 36 */ {
bevl_i = bevl_it.bemd_0(-84763849);
bevt_12_tmpany_phold = bevl_i.bemd_0(-1919296295);
bevt_13_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(-152296894, bevt_13_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 39 */ {
bevt_16_tmpany_phold = bevl_i.bemd_0(-729020735);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-1214267933);
if (bevt_15_tmpany_phold == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(-729020735);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(-1282051158);
bevl_i.bemd_1(1303408474, bevt_17_tmpany_phold);
bevl_i.bemd_0(-7597844);
} /* Line: 42 */
 else  /* Line: 43 */ {
bevt_19_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass9_bevo_0;
bevt_22_tmpany_phold = bevl_i.bemd_0(-729020735);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(-52353640);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(1832806152);
bevl_estr = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevl_estr, beva_node);
throw new be.BECS_ThrowBack(bevt_23_tmpany_phold);
} /* Line: 45 */
} /* Line: 40 */
} /* Line: 39 */
 else  /* Line: 36 */ {
break;
} /* Line: 36 */
} /* Line: 36 */
bevt_24_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_24_tmpany_phold;
} /* Line: 49 */
 else  /* Line: 31 */ {
bevt_26_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_27_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
if (bevt_26_tmpany_phold.bevi_int == bevt_27_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_28_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_c.bemd_1(-328081146, bevt_28_tmpany_phold);
bevt_31_tmpany_phold = beva_node.bem_containerGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_typenameGet_0();
bevt_32_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_30_tmpany_phold.bevi_int == bevt_32_tmpany_phold.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_36_tmpany_phold = beva_node.bem_containerGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_heldGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(1166664450);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_1(-152296894, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 57 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 57 */ {
bevt_38_tmpany_phold = beva_node.bem_isFirstGet_0();
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 57 */ {
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_2));
bevl_c.bemd_1(-1434327754, bevt_39_tmpany_phold);
} /* Line: 58 */
 else  /* Line: 59 */ {
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_3));
bevl_c.bemd_1(-1434327754, bevt_40_tmpany_phold);
} /* Line: 60 */
bevt_41_tmpany_phold = bevl_ac.bemd_0(1166664450);
bevl_c.bemd_1(93271673, bevt_41_tmpany_phold);
bevl_c.bemd_0(1814153284);
bevt_43_tmpany_phold = bevl_c.bemd_0(698663174);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_4));
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_1(-152296894, bevt_44_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 64 */ {
bevt_45_tmpany_phold = beva_node.bem_containerGet_0();
bevt_45_tmpany_phold.bem_heldSet_1(bevl_c);
bevt_46_tmpany_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_46_tmpany_phold.bem_firstGet_0();
bevt_47_tmpany_phold = bevl_ntarg.bemd_0(-1919296295);
beva_node.bem_typenameSet_1(bevt_47_tmpany_phold);
bevt_48_tmpany_phold = bevl_ntarg.bemd_0(1203209953);
beva_node.bem_heldSet_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bevl_ntarg.bemd_0(-729020735);
beva_node.bem_containedSet_1(bevt_49_tmpany_phold);
bevt_51_tmpany_phold = beva_node.bem_containerGet_0();
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_nextDescendGet_0();
return bevt_50_tmpany_phold;
} /* Line: 71 */
 else  /* Line: 72 */ {
bevt_52_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_52_tmpany_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 74 */
bevt_53_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_53_tmpany_phold;
} /* Line: 76 */
 else  /* Line: 31 */ {
bevt_55_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_56_tmpany_phold = bevp_ntypes.bem_IDXACCGet_0();
if (bevt_55_tmpany_phold.bevi_int == bevt_56_tmpany_phold.bevi_int) {
bevt_54_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_59_tmpany_phold = beva_node.bem_containerGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bem_typenameGet_0();
bevt_60_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_58_tmpany_phold.bevi_int == bevt_60_tmpany_phold.bevi_int) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_64_tmpany_phold = beva_node.bem_containerGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bem_heldGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(1166664450);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_5));
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_1(-152296894, bevt_65_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 81 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevt_66_tmpany_phold = beva_node.bem_isFirstGet_0();
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevl_isPut = be.BECS_Runtime.boolTrue;
} /* Line: 83 */
 else  /* Line: 84 */ {
bevl_isPut = be.BECS_Runtime.boolFalse;
} /* Line: 86 */
if (((BEC_2_5_4_LogicBool) bevl_isPut).bevi_bool) /* Line: 88 */ {
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_6));
bevl_c.bemd_1(93271673, bevt_67_tmpany_phold);
bevt_68_tmpany_phold = beva_node.bem_containerGet_0();
bevt_68_tmpany_phold.bem_heldSet_1(bevl_c);
bevt_69_tmpany_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_69_tmpany_phold.bem_firstGet_0();
bevl_narg2 = (BEC_2_5_4_BuildNode) bevl_ntarg.bemd_0(589417792);
bevl_narg3 = beva_node.bem_nextPeerGet_0();
bevl_narg2.bem_delete_0();
bevl_narg3.bem_delete_0();
bevt_70_tmpany_phold = bevl_ntarg.bemd_0(-1919296295);
beva_node.bem_typenameSet_1(bevt_70_tmpany_phold);
bevt_71_tmpany_phold = bevl_ntarg.bemd_0(1203209953);
beva_node.bem_heldSet_1(bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevl_ntarg.bemd_0(-729020735);
beva_node.bem_containedSet_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = beva_node.bem_containerGet_0();
bevt_73_tmpany_phold.bem_addValue_1(bevl_narg2);
bevt_74_tmpany_phold = beva_node.bem_containerGet_0();
bevt_74_tmpany_phold.bem_addValue_1(bevl_narg3);
bevt_76_tmpany_phold = beva_node.bem_containerGet_0();
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bem_nextDescendGet_0();
return bevt_75_tmpany_phold;
} /* Line: 106 */
 else  /* Line: 107 */ {
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_7));
bevl_c.bemd_1(93271673, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_78_tmpany_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 114 */
bevt_79_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_79_tmpany_phold;
} /* Line: 116 */
} /* Line: 31 */
} /* Line: 31 */
bevt_81_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_82_tmpany_phold = bevp_ntypes.bem_FORGet_0();
if (bevt_81_tmpany_phold.bevi_int == bevt_82_tmpany_phold.bevi_int) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_85_tmpany_phold = beva_node.bem_containedGet_0();
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bem_firstGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_0(-729020735);
bevl_linn = (BEC_2_5_4_BuildNode) bevt_83_tmpany_phold.bemd_0(-1282051158);
bevt_87_tmpany_phold = bevl_linn.bem_typenameGet_0();
bevt_88_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_87_tmpany_phold.bevi_int == bevt_88_tmpany_phold.bevi_int) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 121 */ {
bevt_90_tmpany_phold = bevl_linn.bem_heldGet_0();
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_0(-1425812204);
if (((BEC_2_5_4_LogicBool) bevt_89_tmpany_phold).bevi_bool) /* Line: 121 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 121 */
 else  /* Line: 121 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 121 */ {
bevt_91_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
beva_node.bem_typenameSet_1(bevt_91_tmpany_phold);
} /* Line: 123 */
} /* Line: 121 */
bevt_93_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_94_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
if (bevt_93_tmpany_phold.bevi_int == bevt_94_tmpany_phold.bevi_int) {
bevt_92_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_92_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_92_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_95_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
beva_node.bem_typenameSet_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_96_tmpany_phold.bem_firstGet_0();
bevl_brnode = beva_node.bem_secondGet_0();
bevt_97_tmpany_phold = bevl_pnode.bemd_0(-729020735);
bevl_lin = bevt_97_tmpany_phold.bemd_0(-1282051158);
bevt_98_tmpany_phold = bevl_lin.bemd_0(-729020735);
bevl_lany = bevt_98_tmpany_phold.bemd_0(-1282051158);
bevl_toit = bevl_lin.bemd_0(-218649504);
bevl_pnode.bemd_1(475189550, null);
bevl_tmpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpn.bemd_1(1376598300, beva_node);
bevt_99_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpn.bemd_1(950668366, bevt_99_tmpany_phold);
bevt_100_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass9_bels_8));
bevl_tmpv = beva_node.bem_tmpVar_2(bevt_100_tmpany_phold, bevp_build);
bevl_tmpn.bemd_1(1641957604, bevl_tmpv);
bevl_gin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_101_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_gin.bemd_1(950668366, bevt_101_tmpany_phold);
bevl_gic = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_gin.bemd_1(1641957604, bevl_gic);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass9_bels_9));
bevl_gic.bemd_1(93271673, bevt_102_tmpany_phold);
bevt_103_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gic.bemd_1(-1458258167, bevt_103_tmpany_phold);
bevl_gin.bemd_1(-1665881561, bevl_toit);
bevl_asn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1376598300, beva_node);
bevt_104_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asn.bemd_1(950668366, bevt_104_tmpany_phold);
bevl_asc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_asn.bemd_1(1641957604, bevl_asc);
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_10));
bevl_asc.bemd_1(93271673, bevt_105_tmpany_phold);
bevl_asn.bemd_1(-1665881561, bevl_tmpn);
bevl_asn.bemd_1(-1665881561, bevl_gin);
beva_node.bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevl_asn );
bevl_tmpn.bemd_0(-671577025);
bevl_tmpnt = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1376598300, beva_node);
bevt_106_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpnt.bemd_1(950668366, bevt_106_tmpany_phold);
bevl_tmpnt.bemd_1(1641957604, bevl_tmpv);
bevl_tcn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tcn.bemd_1(1376598300, beva_node);
bevt_107_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_tcn.bemd_1(950668366, bevt_107_tmpany_phold);
bevl_tcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_tcn.bemd_1(1641957604, bevl_tcc);
bevt_108_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass9_bels_11));
bevl_tcc.bemd_1(93271673, bevt_108_tmpany_phold);
bevl_tcn.bemd_1(-1665881561, bevl_tmpnt);
bevl_pnode.bemd_1(-1665881561, bevl_tcn);
bevl_tmpng = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpng.bemd_1(1376598300, beva_node);
bevt_109_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpng.bemd_1(950668366, bevt_109_tmpany_phold);
bevl_tmpng.bemd_1(1641957604, bevl_tmpv);
bevl_iagn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iagn.bemd_1(1376598300, beva_node);
bevt_110_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iagn.bemd_1(950668366, bevt_110_tmpany_phold);
bevl_iagc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iagn.bemd_1(1641957604, bevl_iagc);
bevt_111_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass9_bels_12));
bevl_iagc.bemd_1(93271673, bevt_111_tmpany_phold);
bevl_iagn.bemd_1(-1665881561, bevl_tmpng);
bevl_iasn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iasn.bemd_1(1376598300, beva_node);
bevt_112_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iasn.bemd_1(950668366, bevt_112_tmpany_phold);
bevl_iasc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iasn.bemd_1(1641957604, bevl_iasc);
bevt_113_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_13));
bevl_iasc.bemd_1(93271673, bevt_113_tmpany_phold);
bevl_iasn.bemd_1(-1665881561, bevl_lany);
bevl_iasn.bemd_1(-1665881561, bevl_iagn);
bevl_brnode.bemd_1(-1681756319, bevl_iasn);
return (BEC_2_5_4_BuildNode) bevl_toit;
} /* Line: 216 */
bevt_115_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_116_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
if (bevt_115_tmpany_phold.bevi_int == bevt_116_tmpany_phold.bevi_int) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1376598300, beva_node);
bevt_117_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(950668366, bevt_117_tmpany_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1376598300, beva_node);
bevt_118_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(950668366, bevt_118_tmpany_phold);
bevl_lnode.bemd_1(-1665881561, bevl_lbrnode);
bevl_loopif = beva_node;
bevt_119_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(950668366, bevt_119_tmpany_phold);
bevl_lbrnode.bemd_1(-1665881561, bevl_loopif);
bevt_121_tmpany_phold = beva_node.bem_heldGet_0();
if (bevt_121_tmpany_phold == null) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 230 */ {
bevt_123_tmpany_phold = beva_node.bem_heldGet_0();
bevt_124_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass9_bels_14));
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bemd_1(-152296894, bevt_124_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_122_tmpany_phold).bevi_bool) /* Line: 230 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 230 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 230 */
 else  /* Line: 230 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 230 */ {
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_15));
bevl_loopif.bemd_1(1641957604, bevt_125_tmpany_phold);
} /* Line: 231 */
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1376598300, beva_node);
bevt_126_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(950668366, bevt_126_tmpany_phold);
bevl_loopif.bemd_1(-1665881561, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1376598300, beva_node);
bevt_127_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(950668366, bevt_127_tmpany_phold);
bevl_enode.bemd_1(-1665881561, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1376598300, beva_node);
bevt_128_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(950668366, bevt_128_tmpany_phold);
bevl_brnode.bemd_1(-1665881561, bevl_bnode);
bevt_129_tmpany_phold = bevl_lnode.bemd_0(748197428);
return (BEC_2_5_4_BuildNode) bevt_129_tmpany_phold;
} /* Line: 245 */
 else  /* Line: 218 */ {
bevt_131_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_132_tmpany_phold = bevp_ntypes.bem_FORGet_0();
if (bevt_131_tmpany_phold.bevi_int == bevt_132_tmpany_phold.bevi_int) {
bevt_130_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_130_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_130_tmpany_phold.bevi_bool) /* Line: 246 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1376598300, beva_node);
bevt_133_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(950668366, bevt_133_tmpany_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevt_134_tmpany_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_134_tmpany_phold.bem_firstGet_0();
bevl_pnode.bemd_0(-7597844);
bevt_137_tmpany_phold = bevl_pnode.bemd_0(-729020735);
bevt_136_tmpany_phold = bevt_137_tmpany_phold.bemd_0(-52353640);
bevt_138_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bemd_1(727421466, bevt_138_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_135_tmpany_phold).bevi_bool) /* Line: 253 */ {
bevt_140_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bece_BEC_3_5_5_5_BuildVisitPass9_bels_16));
bevt_139_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_140_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_139_tmpany_phold);
} /* Line: 254 */
bevt_141_tmpany_phold = bevl_pnode.bemd_0(-729020735);
bevl_init = bevt_141_tmpany_phold.bemd_0(-1282051158);
bevl_cond = bevl_pnode.bemd_0(-218649504);
bevl_atStep = null;
bevt_144_tmpany_phold = bevl_pnode.bemd_0(-729020735);
bevt_143_tmpany_phold = bevt_144_tmpany_phold.bemd_0(-52353640);
bevt_145_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_142_tmpany_phold = bevt_143_tmpany_phold.bemd_1(1561208327, bevt_145_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_142_tmpany_phold).bevi_bool) /* Line: 259 */ {
bevl_atStep = bevl_pnode.bemd_0(52071217);
bevl_atStep.bemd_0(-7597844);
} /* Line: 261 */
bevl_init.bemd_0(-7597844);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevl_lnode.bemd_1(1303408474, bevl_init);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1376598300, beva_node);
bevt_146_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(950668366, bevt_146_tmpany_phold);
bevl_lnode.bemd_1(-1665881561, bevl_lbrnode);
bevl_loopif = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_loopif.bemd_1(1376598300, beva_node);
bevt_147_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(950668366, bevt_147_tmpany_phold);
bevl_loopif.bemd_1(-1046198181, beva_node);
if (bevl_atStep == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_150_tmpany_phold = bevl_loopif.bemd_0(-729020735);
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_0(-1282051158);
bevt_149_tmpany_phold.bemd_1(-1665881561, bevl_atStep);
} /* Line: 277 */
bevl_loopif.bemd_1(-1681756319, bevl_pnode);
bevl_lbrnode.bemd_1(-1665881561, bevl_loopif);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1376598300, beva_node);
bevt_151_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(950668366, bevt_151_tmpany_phold);
bevl_loopif.bemd_1(-1665881561, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1376598300, beva_node);
bevt_152_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(950668366, bevt_152_tmpany_phold);
bevl_enode.bemd_1(-1665881561, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1376598300, beva_node);
bevt_153_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(950668366, bevt_153_tmpany_phold);
bevl_brnode.bemd_1(-1665881561, bevl_bnode);
return (BEC_2_5_4_BuildNode) bevl_init;
} /* Line: 294 */
} /* Line: 218 */
bevt_154_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_154_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {31, 31, 31, 31, 35, 36, 36, 36, 38, 39, 39, 39, 40, 40, 40, 40, 41, 41, 41, 42, 44, 44, 44, 44, 44, 45, 45, 49, 49, 50, 50, 50, 50, 54, 55, 56, 56, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 0, 0, 0, 57, 0, 0, 0, 58, 58, 60, 60, 62, 62, 63, 64, 64, 64, 65, 65, 66, 66, 68, 68, 69, 69, 70, 70, 71, 71, 71, 73, 73, 74, 76, 76, 77, 77, 77, 77, 79, 80, 81, 81, 81, 81, 81, 81, 81, 81, 81, 81, 0, 0, 0, 81, 0, 0, 0, 83, 86, 89, 89, 90, 90, 91, 91, 94, 95, 97, 98, 100, 100, 101, 101, 102, 102, 104, 104, 105, 105, 106, 106, 106, 112, 112, 113, 113, 114, 116, 116, 118, 118, 118, 118, 120, 120, 120, 120, 121, 121, 121, 121, 121, 121, 0, 0, 0, 123, 123, 126, 126, 126, 126, 127, 127, 128, 128, 129, 130, 130, 131, 131, 132, 133, 152, 153, 154, 154, 155, 155, 156, 158, 159, 159, 160, 161, 162, 162, 163, 163, 164, 166, 167, 168, 168, 169, 170, 171, 171, 172, 173, 175, 176, 178, 179, 180, 180, 181, 183, 184, 185, 185, 186, 187, 188, 188, 189, 191, 193, 194, 195, 195, 196, 198, 199, 200, 200, 201, 202, 203, 203, 204, 206, 207, 208, 208, 209, 210, 211, 211, 212, 213, 215, 216, 218, 218, 218, 218, 219, 220, 221, 221, 222, 223, 224, 225, 225, 226, 227, 228, 228, 229, 230, 230, 230, 230, 230, 230, 0, 0, 0, 231, 231, 233, 234, 235, 235, 236, 237, 238, 239, 239, 240, 241, 242, 243, 243, 244, 245, 245, 246, 246, 246, 246, 247, 248, 249, 249, 250, 251, 251, 252, 253, 253, 253, 253, 254, 254, 254, 256, 256, 257, 258, 259, 259, 259, 259, 260, 261, 263, 265, 266, 268, 269, 270, 270, 271, 272, 273, 274, 274, 275, 276, 276, 277, 277, 277, 279, 280, 281, 282, 283, 283, 284, 285, 286, 287, 287, 288, 289, 290, 291, 291, 292, 294, 296, 296};
public static new int[] bevs_smnlec
 = new int[] {224, 225, 226, 231, 232, 233, 234, 237, 239, 240, 241, 242, 244, 245, 246, 251, 252, 253, 254, 255, 258, 259, 260, 261, 262, 263, 264, 272, 273, 276, 277, 278, 283, 284, 285, 286, 287, 288, 289, 290, 291, 296, 297, 298, 299, 300, 301, 303, 306, 310, 313, 315, 318, 322, 325, 326, 329, 330, 332, 333, 334, 335, 336, 337, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 354, 355, 356, 358, 359, 362, 363, 364, 369, 370, 371, 372, 373, 374, 375, 380, 381, 382, 383, 384, 385, 387, 390, 394, 397, 399, 402, 406, 409, 412, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 440, 441, 442, 443, 444, 446, 447, 451, 452, 453, 458, 459, 460, 461, 462, 463, 464, 465, 470, 471, 472, 474, 477, 481, 484, 485, 488, 489, 490, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 578, 579, 580, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 606, 607, 608, 609, 611, 614, 618, 621, 622, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 643, 644, 645, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 664, 665, 666, 668, 669, 670, 671, 672, 673, 674, 675, 677, 678, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 698, 699, 700, 701, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 723, 724};
/* BEGIN LINEINFO 
assign 1 31 224
typenameGet 0 31 224
assign 1 31 225
CALLGet 0 31 225
assign 1 31 226
equals 1 31 231
initContained 0 35 232
assign 1 36 233
containedGet 0 36 233
assign 1 36 234
iteratorGet 0 36 234
assign 1 36 237
hasNextGet 0 36 237
assign 1 38 239
nextGet 0 38 239
assign 1 39 240
typenameGet 0 39 240
assign 1 39 241
PARENSGet 0 39 241
assign 1 39 242
equals 1 39 242
assign 1 40 244
containedGet 0 40 244
assign 1 40 245
firstNodeGet 0 40 245
assign 1 40 246
def 1 40 251
assign 1 41 252
containedGet 0 41 252
assign 1 41 253
firstGet 0 41 253
beforeInsert 1 41 254
delete 0 42 255
assign 1 44 258
new 0 44 258
assign 1 44 259
containedGet 0 44 259
assign 1 44 260
lengthGet 0 44 260
assign 1 44 261
toString 0 44 261
assign 1 44 262
add 1 44 262
assign 1 45 263
new 2 45 263
throw 1 45 264
assign 1 49 272
nextDescendGet 0 49 272
return 1 49 273
assign 1 50 276
typenameGet 0 50 276
assign 1 50 277
ACCESSORGet 0 50 277
assign 1 50 278
equals 1 50 283
assign 1 54 284
heldGet 0 54 284
assign 1 55 285
new 0 55 285
assign 1 56 286
new 0 56 286
wasAccessorSet 1 56 287
assign 1 57 288
containerGet 0 57 288
assign 1 57 289
typenameGet 0 57 289
assign 1 57 290
CALLGet 0 57 290
assign 1 57 291
equals 1 57 296
assign 1 57 297
containerGet 0 57 297
assign 1 57 298
heldGet 0 57 298
assign 1 57 299
nameGet 0 57 299
assign 1 57 300
new 0 57 300
assign 1 57 301
equals 1 57 301
assign 1 0 303
assign 1 0 306
assign 1 0 310
assign 1 57 313
isFirstGet 0 57 313
assign 1 0 315
assign 1 0 318
assign 1 0 322
assign 1 58 325
new 0 58 325
accessorTypeSet 1 58 326
assign 1 60 329
new 0 60 329
accessorTypeSet 1 60 330
assign 1 62 332
nameGet 0 62 332
nameSet 1 62 333
toAccessorName 0 63 334
assign 1 64 335
accessorTypeGet 0 64 335
assign 1 64 336
new 0 64 336
assign 1 64 337
equals 1 64 337
assign 1 65 339
containerGet 0 65 339
heldSet 1 65 340
assign 1 66 341
containedGet 0 66 341
assign 1 66 342
firstGet 0 66 342
assign 1 68 343
typenameGet 0 68 343
typenameSet 1 68 344
assign 1 69 345
heldGet 0 69 345
heldSet 1 69 346
assign 1 70 347
containedGet 0 70 347
containedSet 1 70 348
assign 1 71 349
containerGet 0 71 349
assign 1 71 350
nextDescendGet 0 71 350
return 1 71 351
assign 1 73 354
CALLGet 0 73 354
typenameSet 1 73 355
heldSet 1 74 356
assign 1 76 358
nextDescendGet 0 76 358
return 1 76 359
assign 1 77 362
typenameGet 0 77 362
assign 1 77 363
IDXACCGet 0 77 363
assign 1 77 364
equals 1 77 369
assign 1 79 370
heldGet 0 79 370
assign 1 80 371
new 0 80 371
assign 1 81 372
containerGet 0 81 372
assign 1 81 373
typenameGet 0 81 373
assign 1 81 374
CALLGet 0 81 374
assign 1 81 375
equals 1 81 380
assign 1 81 381
containerGet 0 81 381
assign 1 81 382
heldGet 0 81 382
assign 1 81 383
nameGet 0 81 383
assign 1 81 384
new 0 81 384
assign 1 81 385
equals 1 81 385
assign 1 0 387
assign 1 0 390
assign 1 0 394
assign 1 81 397
isFirstGet 0 81 397
assign 1 0 399
assign 1 0 402
assign 1 0 406
assign 1 83 409
new 0 83 409
assign 1 86 412
new 0 86 412
assign 1 89 415
new 0 89 415
nameSet 1 89 416
assign 1 90 417
containerGet 0 90 417
heldSet 1 90 418
assign 1 91 419
containedGet 0 91 419
assign 1 91 420
firstGet 0 91 420
assign 1 94 421
nextPeerGet 0 94 421
assign 1 95 422
nextPeerGet 0 95 422
delete 0 97 423
delete 0 98 424
assign 1 100 425
typenameGet 0 100 425
typenameSet 1 100 426
assign 1 101 427
heldGet 0 101 427
heldSet 1 101 428
assign 1 102 429
containedGet 0 102 429
containedSet 1 102 430
assign 1 104 431
containerGet 0 104 431
addValue 1 104 432
assign 1 105 433
containerGet 0 105 433
addValue 1 105 434
assign 1 106 435
containerGet 0 106 435
assign 1 106 436
nextDescendGet 0 106 436
return 1 106 437
assign 1 112 440
new 0 112 440
nameSet 1 112 441
assign 1 113 442
CALLGet 0 113 442
typenameSet 1 113 443
heldSet 1 114 444
assign 1 116 446
nextDescendGet 0 116 446
return 1 116 447
assign 1 118 451
typenameGet 0 118 451
assign 1 118 452
FORGet 0 118 452
assign 1 118 453
equals 1 118 458
assign 1 120 459
containedGet 0 120 459
assign 1 120 460
firstGet 0 120 460
assign 1 120 461
containedGet 0 120 461
assign 1 120 462
firstGet 0 120 462
assign 1 121 463
typenameGet 0 121 463
assign 1 121 464
CALLGet 0 121 464
assign 1 121 465
equals 1 121 470
assign 1 121 471
heldGet 0 121 471
assign 1 121 472
wasOperGet 0 121 472
assign 1 0 474
assign 1 0 477
assign 1 0 481
assign 1 123 484
FOREACHGet 0 123 484
typenameSet 1 123 485
assign 1 126 488
typenameGet 0 126 488
assign 1 126 489
FOREACHGet 0 126 489
assign 1 126 490
equals 1 126 495
assign 1 127 496
WHILEGet 0 127 496
typenameSet 1 127 497
assign 1 128 498
containedGet 0 128 498
assign 1 128 499
firstGet 0 128 499
assign 1 129 500
secondGet 0 129 500
assign 1 130 501
containedGet 0 130 501
assign 1 130 502
firstGet 0 130 502
assign 1 131 503
containedGet 0 131 503
assign 1 131 504
firstGet 0 131 504
assign 1 132 505
secondGet 0 132 505
containedSet 1 133 506
assign 1 152 507
new 1 152 507
copyLoc 1 153 508
assign 1 154 509
VARGet 0 154 509
typenameSet 1 154 510
assign 1 155 511
new 0 155 511
assign 1 155 512
tmpVar 2 155 512
heldSet 1 156 513
assign 1 158 514
new 1 158 514
assign 1 159 515
CALLGet 0 159 515
typenameSet 1 159 516
assign 1 160 517
new 0 160 517
heldSet 1 161 518
assign 1 162 519
new 0 162 519
nameSet 1 162 520
assign 1 163 521
new 0 163 521
wasForeachGennedSet 1 163 522
addValue 1 164 523
assign 1 166 524
new 1 166 524
copyLoc 1 167 525
assign 1 168 526
CALLGet 0 168 526
typenameSet 1 168 527
assign 1 169 528
new 0 169 528
heldSet 1 170 529
assign 1 171 530
new 0 171 530
nameSet 1 171 531
addValue 1 172 532
addValue 1 173 533
beforeInsert 1 175 534
addVariable 0 176 535
assign 1 178 536
new 1 178 536
copyLoc 1 179 537
assign 1 180 538
VARGet 0 180 538
typenameSet 1 180 539
heldSet 1 181 540
assign 1 183 541
new 1 183 541
copyLoc 1 184 542
assign 1 185 543
CALLGet 0 185 543
typenameSet 1 185 544
assign 1 186 545
new 0 186 545
heldSet 1 187 546
assign 1 188 547
new 0 188 547
nameSet 1 188 548
addValue 1 189 549
addValue 1 191 550
assign 1 193 551
new 1 193 551
copyLoc 1 194 552
assign 1 195 553
VARGet 0 195 553
typenameSet 1 195 554
heldSet 1 196 555
assign 1 198 556
new 1 198 556
copyLoc 1 199 557
assign 1 200 558
CALLGet 0 200 558
typenameSet 1 200 559
assign 1 201 560
new 0 201 560
heldSet 1 202 561
assign 1 203 562
new 0 203 562
nameSet 1 203 563
addValue 1 204 564
assign 1 206 565
new 1 206 565
copyLoc 1 207 566
assign 1 208 567
CALLGet 0 208 567
typenameSet 1 208 568
assign 1 209 569
new 0 209 569
heldSet 1 210 570
assign 1 211 571
new 0 211 571
nameSet 1 211 572
addValue 1 212 573
addValue 1 213 574
prepend 1 215 575
return 1 216 576
assign 1 218 578
typenameGet 0 218 578
assign 1 218 579
WHILEGet 0 218 579
assign 1 218 580
equals 1 218 585
assign 1 219 586
new 1 219 586
copyLoc 1 220 587
assign 1 221 588
LOOPGet 0 221 588
typenameSet 1 221 589
replaceWith 1 222 590
assign 1 223 591
new 1 223 591
copyLoc 1 224 592
assign 1 225 593
BRACESGet 0 225 593
typenameSet 1 225 594
addValue 1 226 595
assign 1 227 596
assign 1 228 597
IFGet 0 228 597
typenameSet 1 228 598
addValue 1 229 599
assign 1 230 600
heldGet 0 230 600
assign 1 230 601
def 1 230 606
assign 1 230 607
heldGet 0 230 607
assign 1 230 608
new 0 230 608
assign 1 230 609
equals 1 230 609
assign 1 0 611
assign 1 0 614
assign 1 0 618
assign 1 231 621
new 0 231 621
heldSet 1 231 622
assign 1 233 624
new 1 233 624
copyLoc 1 234 625
assign 1 235 626
ELSEGet 0 235 626
typenameSet 1 235 627
addValue 1 236 628
assign 1 237 629
new 1 237 629
copyLoc 1 238 630
assign 1 239 631
BRACESGet 0 239 631
typenameSet 1 239 632
addValue 1 240 633
assign 1 241 634
new 1 241 634
copyLoc 1 242 635
assign 1 243 636
BREAKGet 0 243 636
typenameSet 1 243 637
addValue 1 244 638
assign 1 245 639
nextDescendGet 0 245 639
return 1 245 640
assign 1 246 643
typenameGet 0 246 643
assign 1 246 644
FORGet 0 246 644
assign 1 246 645
equals 1 246 650
assign 1 247 651
new 1 247 651
copyLoc 1 248 652
assign 1 249 653
LOOPGet 0 249 653
typenameSet 1 249 654
replaceWith 1 250 655
assign 1 251 656
containedGet 0 251 656
assign 1 251 657
firstGet 0 251 657
delete 0 252 658
assign 1 253 659
containedGet 0 253 659
assign 1 253 660
lengthGet 0 253 660
assign 1 253 661
new 0 253 661
assign 1 253 662
lesser 1 253 662
assign 1 254 664
new 0 254 664
assign 1 254 665
new 2 254 665
throw 1 254 666
assign 1 256 668
containedGet 0 256 668
assign 1 256 669
firstGet 0 256 669
assign 1 257 670
secondGet 0 257 670
assign 1 258 671
assign 1 259 672
containedGet 0 259 672
assign 1 259 673
lengthGet 0 259 673
assign 1 259 674
new 0 259 674
assign 1 259 675
greater 1 259 675
assign 1 260 677
thirdGet 0 260 677
delete 0 261 678
delete 0 263 680
replaceWith 1 265 681
beforeInsert 1 266 682
assign 1 268 683
new 1 268 683
copyLoc 1 269 684
assign 1 270 685
BRACESGet 0 270 685
typenameSet 1 270 686
addValue 1 271 687
assign 1 272 688
new 1 272 688
copyLoc 1 273 689
assign 1 274 690
IFGet 0 274 690
typenameSet 1 274 691
takeContents 1 275 692
assign 1 276 693
def 1 276 698
assign 1 277 699
containedGet 0 277 699
assign 1 277 700
firstGet 0 277 700
addValue 1 277 701
prepend 1 279 703
addValue 1 280 704
assign 1 281 705
new 1 281 705
copyLoc 1 282 706
assign 1 283 707
ELSEGet 0 283 707
typenameSet 1 283 708
addValue 1 284 709
assign 1 285 710
new 1 285 710
copyLoc 1 286 711
assign 1 287 712
BRACESGet 0 287 712
typenameSet 1 287 713
addValue 1 288 714
assign 1 289 715
new 1 289 715
copyLoc 1 290 716
assign 1 291 717
BREAKGet 0 291 717
typenameSet 1 291 718
addValue 1 292 719
return 1 294 720
assign 1 296 723
nextDescendGet 0 296 723
return 1 296 724
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1196099876: return bem_echo_0();
case -170941956: return bem_serializeToString_0();
case 1989485633: return bem_many_0();
case 1278457769: return bem_buildGet_0();
case -1297985879: return bem_fieldNamesGet_0();
case -1562351500: return bem_constGet_0();
case -1222154604: return bem_tagGet_0();
case 1832806152: return bem_toString_0();
case 1797020795: return bem_toAny_0();
case 180642345: return bem_transGetDirect_0();
case -242463884: return bem_fieldIteratorGet_0();
case -302817860: return bem_deserializeClassNameGet_0();
case -671191297: return bem_serializeContents_0();
case 159449192: return bem_buildGetDirect_0();
case 213564239: return bem_copy_0();
case 1418348540: return bem_iteratorGet_0();
case 384026730: return bem_ntypesGet_0();
case -1230714712: return bem_classNameGet_0();
case -1925247459: return bem_sourceFileNameGet_0();
case -494057832: return bem_serializationIteratorGet_0();
case -982032274: return bem_transGet_0();
case -1342633655: return bem_hashGet_0();
case -1916548323: return bem_once_0();
case -1628841870: return bem_new_0();
case -888502976: return bem_print_0();
case -576159222: return bem_constGetDirect_0();
case -294806467: return bem_create_0();
case 1352428264: return bem_ntypesGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -118558475: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1447630066: return bem_ntypesSetDirect_1(bevd_0);
case -810647371: return bem_sameClass_1(bevd_0);
case -788622974: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1345095935: return bem_defined_1(bevd_0);
case -218654526: return bem_transSet_1(bevd_0);
case 1602348302: return bem_sameObject_1(bevd_0);
case -395616432: return bem_otherClass_1(bevd_0);
case 79810732: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2084177915: return bem_buildSetDirect_1(bevd_0);
case -120099514: return bem_transSetDirect_1(bevd_0);
case 1932567662: return bem_constSet_1(bevd_0);
case 1672498055: return bem_constSetDirect_1(bevd_0);
case 878699000: return bem_ntypesSet_1(bevd_0);
case -1796596677: return bem_otherType_1(bevd_0);
case -1258204936: return bem_begin_1(bevd_0);
case 346995129: return bem_def_1(bevd_0);
case 1893921321: return bem_buildSet_1(bevd_0);
case 936942966: return bem_undefined_1(bevd_0);
case 1495593147: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1811224480: return bem_sameType_1(bevd_0);
case 945449374: return bem_notEquals_1(bevd_0);
case -1190390262: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1398777398: return bem_end_1(bevd_0);
case 83181817: return bem_undef_1(bevd_0);
case -152296894: return bem_equals_1(bevd_0);
case -2046043947: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -174395426: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1117645207: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1434652185: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2038467728: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 6185266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 34704188: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1515774718: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass9_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass9_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass9();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst = (BEC_3_5_5_5_BuildVisitPass9) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_type;
}
}
}
