namespace be {
/* IO:File: source/build/EmitData.be */
public sealed class BEC_2_5_11_BuildMethodIndex : BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildMethodIndex() { }
static BEC_2_5_11_BuildMethodIndex() { }
private static byte[] becc_BEC_2_5_11_BuildMethodIndex_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x49,0x6E,0x64,0x65,0x78};
private static byte[] becc_BEC_2_5_11_BuildMethodIndex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static new BEC_2_5_11_BuildMethodIndex bece_BEC_2_5_11_BuildMethodIndex_bevs_inst;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_5_6_BuildMtdSyn bevp_msyn;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_11_BuildMethodIndex bem_new_2(BEC_2_5_8_BuildClassSyn beva__syn, BEC_2_5_6_BuildMtdSyn beva__msyn) {
bevp_syn = beva__syn;
bevp_msyn = beva__msyn;
bevp_declaration = bevp_msyn.bem_declarationGet_0();
bevp_name = bevp_msyn.bem_nameGet_0();
return this;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_declaration.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_name);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 112 */ {
bevt_4_tmpany_phold = bem_sameClass_1(beva_x);
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 112 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 112 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 112 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 112 */
bevt_7_tmpany_phold = beva_x.bemd_0(919508015);
bevt_6_tmpany_phold = bevp_declaration.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevt_9_tmpany_phold = beva_x.bemd_0(-1610747658);
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 113 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 113 */
 else  /* Line: 113 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 113 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 114 */
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_msynGet_0() {
return bevp_msyn;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_msynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() {
return bevp_declaration;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {100, 101, 102, 103, 108, 108, 108, 108, 112, 112, 0, 112, 112, 112, 0, 0, 112, 112, 113, 113, 113, 113, 0, 0, 0, 114, 114, 116, 116, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 16, 17, 24, 25, 26, 27, 42, 47, 48, 51, 52, 57, 58, 61, 65, 66, 68, 69, 71, 72, 74, 77, 81, 84, 85, 87, 88, 91, 94, 98, 101, 105, 108, 112, 115};
/* BEGIN LINEINFO 
assign 1 100 14
assign 1 101 15
assign 1 102 16
declarationGet 0 102 16
assign 1 103 17
nameGet 0 103 17
assign 1 108 24
toString 0 108 24
assign 1 108 25
add 1 108 25
assign 1 108 26
hashGet 0 108 26
return 1 108 27
assign 1 112 42
undef 1 112 47
assign 1 0 48
assign 1 112 51
sameClass 1 112 51
assign 1 112 52
not 0 112 57
assign 1 0 58
assign 1 0 61
assign 1 112 65
new 0 112 65
return 1 112 66
assign 1 113 68
declarationGet 0 113 68
assign 1 113 69
equals 1 113 69
assign 1 113 71
nameGet 0 113 71
assign 1 113 72
equals 1 113 72
assign 1 0 74
assign 1 0 77
assign 1 0 81
assign 1 114 84
new 0 114 84
return 1 114 85
assign 1 116 87
new 0 116 87
return 1 116 88
return 1 0 91
assign 1 0 94
return 1 0 98
assign 1 0 101
return 1 0 105
assign 1 0 108
return 1 0 112
assign 1 0 115
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 1704272071: return bem_copy_0();
case 16424274: return bem_iteratorGet_0();
case 1277077124: return bem_once_0();
case -146459624: return bem_tagGet_0();
case 1818190775: return bem_toString_0();
case 371037351: return bem_hashGet_0();
case 1190997837: return bem_print_0();
case -1613660155: return bem_serializationIteratorGet_0();
case 733860028: return bem_msynGet_0();
case -1181834336: return bem_serializeToString_0();
case 308705107: return bem_serializeContents_0();
case -1610747658: return bem_nameGet_0();
case 1133560869: return bem_new_0();
case -457378134: return bem_sourceFileNameGet_0();
case 1985246514: return bem_classNameGet_0();
case -1751704975: return bem_many_0();
case 919508015: return bem_declarationGet_0();
case -67432972: return bem_fieldIteratorGet_0();
case 1584953476: return bem_synGet_0();
case 1567284243: return bem_create_0();
case -1538220610: return bem_echo_0();
case 642325680: return bem_deserializeClassNameGet_0();
case -563585217: return bem_toAny_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case -1508704559: return bem_copyTo_1(bevd_0);
case 1024493267: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -572577741: return bem_nameSet_1(bevd_0);
case 2101700701: return bem_undefined_1(bevd_0);
case -932776110: return bem_declarationSet_1(bevd_0);
case -1682170766: return bem_otherType_1(bevd_0);
case -503068138: return bem_sameType_1(bevd_0);
case 2077566448: return bem_sameClass_1(bevd_0);
case 1398941771: return bem_def_1(bevd_0);
case -240186291: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1936197463: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -122042490: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -663159180: return bem_synSet_1(bevd_0);
case 1270721790: return bem_sameObject_1(bevd_0);
case -1895093761: return bem_msynSet_1(bevd_0);
case 1933685650: return bem_equals_1(bevd_0);
case 579081683: return bem_defined_1(bevd_0);
case 1069670174: return bem_undef_1(bevd_0);
case -1210345122: return bem_notEquals_1(bevd_0);
case 1170591864: return bem_otherClass_1(bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1408482482: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1097908484: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1722402091: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1055053136: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -153418843: return bem_new_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_6_BuildMtdSyn) bevd_1);
case 2112228411: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -483654719: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1372560242: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildMethodIndex_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_11_BuildMethodIndex_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_11_BuildMethodIndex();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_inst = (BEC_2_5_11_BuildMethodIndex) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_inst;
}
}
}
