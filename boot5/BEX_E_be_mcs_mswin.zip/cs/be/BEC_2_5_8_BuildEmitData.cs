namespace be {
/* IO:File: source/build/EmitData.be */
public sealed class BEC_2_5_8_BuildEmitData : BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildEmitData() { }
static BEC_2_5_8_BuildEmitData() { }
private static byte[] becc_BEC_2_5_8_BuildEmitData_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61};
private static byte[] becc_BEC_2_5_8_BuildEmitData_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static new BEC_2_5_8_BuildEmitData bece_BEC_2_5_8_BuildEmitData_bevs_inst;
public BEC_2_9_3_ContainerMap bevp_ptsp;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_9_3_ContainerMap bevp_nameEntries;
public BEC_2_9_3_ContainerMap bevp_classes;
public BEC_2_9_10_ContainerLinkedList bevp_parseOrderClassNames;
public BEC_2_9_3_ContainerMap bevp_justParsed;
public BEC_2_9_3_ContainerMap bevp_synClasses;
public BEC_2_9_3_ContainerMap bevp_midNames;
public BEC_2_9_3_ContainerMap bevp_usedBy;
public BEC_2_9_3_ContainerMap bevp_subClasses;
public BEC_2_9_3_ContainerSet bevp_propertyIndexes;
public BEC_2_9_3_ContainerSet bevp_methodIndexes;
public BEC_2_9_3_ContainerSet bevp_shouldEmit;
public BEC_2_9_3_ContainerMap bevp_aliased;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_ptsp = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_nameEntries = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_justParsed = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_synClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_midNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_usedBy = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_subClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_aliased = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addSynClass_2(BEC_2_4_6_TextString beva_npstr, BEC_2_5_8_BuildClassSyn beva_syn) {
BEC_2_4_6_TextString bevl_myname = null;
BEC_2_4_6_TextString bevl_s = null;
BEC_2_9_3_ContainerSet bevl_ub = null;
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_8_BuildNamePath bevt_1_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevp_synClasses.bem_put_2(beva_npstr, beva_syn);
bevt_1_tmpany_phold = beva_syn.bem_namepathGet_0();
bevl_myname = bevt_1_tmpany_phold.bem_toString_0();
bevt_2_tmpany_phold = beva_syn.bem_usesGet_0();
bevt_0_tmpany_loop = bevt_2_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 41 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-2076341414);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 41 */ {
bevl_s = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-1641663327);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_usedBy.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevl_ub = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_usedBy.bem_put_2(bevl_s, bevl_ub);
} /* Line: 45 */
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 47 */
 else  /* Line: 41 */ {
break;
} /* Line: 41 */
} /* Line: 41 */
bevt_5_tmpany_phold = beva_syn.bem_superListGet_0();
bevl_iu = bevt_5_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 49 */ {
bevt_6_tmpany_phold = bevl_iu.bemd_0(-2076341414);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 49 */ {
bevt_7_tmpany_phold = bevl_iu.bemd_0(-1641663327);
bevl_s = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bemd_0(1818190775);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_subClasses.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevl_ub = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_subClasses.bem_put_2(bevl_s, bevl_ub);
} /* Line: 54 */
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 56 */
 else  /* Line: 49 */ {
break;
} /* Line: 49 */
} /* Line: 49 */
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addParsedClass_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = beva_node.bemd_0(34479995);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-1610747658);
bevt_1_tmpany_phold = bevp_classes.bem_has_1(bevt_2_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_5_tmpany_phold = beva_node.bemd_0(34479995);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-1610747658);
bevp_parseOrderClassNames.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 62 */
bevt_7_tmpany_phold = beva_node.bemd_0(34479995);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1610747658);
bevp_classes.bem_put_2(bevt_6_tmpany_phold, beva_node);
bevt_9_tmpany_phold = beva_node.bemd_0(34479995);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1610747658);
bevp_justParsed.bem_put_2(bevt_8_tmpany_phold, beva_node);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptspGet_0() {
return bevp_ptsp;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_ptspSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptsp = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_nameEntriesGet_0() {
return bevp_nameEntries;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_nameEntriesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameEntries = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classesGet_0() {
return bevp_classes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_classesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_parseOrderClassNamesGet_0() {
return bevp_parseOrderClassNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_parseOrderClassNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_justParsedGet_0() {
return bevp_justParsed;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_justParsedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_justParsed = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_synClassesGet_0() {
return bevp_synClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_synClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_midNamesGet_0() {
return bevp_midNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_midNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_midNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_usedByGet_0() {
return bevp_usedBy;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_usedBySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedBy = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_subClassesGet_0() {
return bevp_subClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_subClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_subClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_propertyIndexesGet_0() {
return bevp_propertyIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_propertyIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_methodIndexesGet_0() {
return bevp_methodIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_methodIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_shouldEmitGet_0() {
return bevp_shouldEmit;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_shouldEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGet_0() {
return bevp_aliased;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_aliasedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 30, 31, 32, 33, 34, 39, 40, 40, 41, 41, 0, 41, 41, 42, 43, 43, 44, 45, 47, 49, 49, 49, 50, 50, 51, 52, 52, 53, 54, 56, 61, 61, 61, 61, 61, 62, 62, 62, 64, 64, 64, 65, 65, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 56, 57, 58, 59, 60, 60, 63, 65, 66, 67, 72, 73, 74, 76, 82, 83, 86, 88, 89, 90, 91, 96, 97, 98, 100, 119, 120, 121, 122, 127, 128, 129, 130, 132, 133, 134, 135, 136, 137, 141, 144, 148, 151, 155, 158, 162, 165, 169, 172, 176, 179, 183, 186, 190, 193, 197, 200, 204, 207, 211, 214, 218, 221, 225, 228, 232, 235, 239, 242};
/* BEGIN LINEINFO 
assign 1 18 25
new 0 18 25
assign 1 19 26
new 0 19 26
assign 1 20 27
new 0 20 27
assign 1 21 28
new 0 21 28
assign 1 22 29
new 0 22 29
assign 1 23 30
new 0 23 30
assign 1 24 31
new 0 24 31
assign 1 25 32
new 0 25 32
assign 1 26 33
new 0 26 33
assign 1 28 34
new 0 28 34
assign 1 30 35
new 0 30 35
assign 1 31 36
new 0 31 36
assign 1 32 37
new 0 32 37
assign 1 33 38
new 0 33 38
assign 1 34 39
new 0 34 39
put 2 39 56
assign 1 40 57
namepathGet 0 40 57
assign 1 40 58
toString 0 40 58
assign 1 41 59
usesGet 0 41 59
assign 1 41 60
iteratorGet 0 0 60
assign 1 41 63
hasNextGet 0 41 63
assign 1 41 65
nextGet 0 41 65
assign 1 42 66
get 1 42 66
assign 1 43 67
undef 1 43 72
assign 1 44 73
new 0 44 73
put 2 45 74
put 1 47 76
assign 1 49 82
superListGet 0 49 82
assign 1 49 83
iteratorGet 0 49 83
assign 1 49 86
hasNextGet 0 49 86
assign 1 50 88
nextGet 0 50 88
assign 1 50 89
toString 0 50 89
assign 1 51 90
get 1 51 90
assign 1 52 91
undef 1 52 96
assign 1 53 97
new 0 53 97
put 2 54 98
put 1 56 100
assign 1 61 119
heldGet 0 61 119
assign 1 61 120
nameGet 0 61 120
assign 1 61 121
has 1 61 121
assign 1 61 122
not 0 61 127
assign 1 62 128
heldGet 0 62 128
assign 1 62 129
nameGet 0 62 129
addValue 1 62 130
assign 1 64 132
heldGet 0 64 132
assign 1 64 133
nameGet 0 64 133
put 2 64 134
assign 1 65 135
heldGet 0 65 135
assign 1 65 136
nameGet 0 65 136
put 2 65 137
return 1 0 141
assign 1 0 144
return 1 0 148
assign 1 0 151
return 1 0 155
assign 1 0 158
return 1 0 162
assign 1 0 165
return 1 0 169
assign 1 0 172
return 1 0 176
assign 1 0 179
return 1 0 183
assign 1 0 186
return 1 0 190
assign 1 0 193
return 1 0 197
assign 1 0 200
return 1 0 204
assign 1 0 207
return 1 0 211
assign 1 0 214
return 1 0 218
assign 1 0 221
return 1 0 225
assign 1 0 228
return 1 0 232
assign 1 0 235
return 1 0 239
assign 1 0 242
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 1704272071: return bem_copy_0();
case 358953040: return bem_justParsedGet_0();
case 16424274: return bem_iteratorGet_0();
case 308705107: return bem_serializeContents_0();
case 35823387: return bem_midNamesGet_0();
case 899114908: return bem_parseOrderClassNamesGet_0();
case 1646945500: return bem_aliasedGet_0();
case -1181834336: return bem_serializeToString_0();
case 371037351: return bem_hashGet_0();
case 642325680: return bem_deserializeClassNameGet_0();
case 1277077124: return bem_once_0();
case -67432972: return bem_fieldIteratorGet_0();
case -1751704975: return bem_many_0();
case 1298147034: return bem_synClassesGet_0();
case -1434884071: return bem_classesGet_0();
case -146459624: return bem_tagGet_0();
case 1255957166: return bem_methodIndexesGet_0();
case 1985246514: return bem_classNameGet_0();
case 1818190775: return bem_toString_0();
case 2121647929: return bem_foreignClassesGet_0();
case -563585217: return bem_toAny_0();
case -1538220610: return bem_echo_0();
case 1190997837: return bem_print_0();
case 1567284243: return bem_create_0();
case -817162132: return bem_propertyIndexesGet_0();
case -457378134: return bem_sourceFileNameGet_0();
case 1757384219: return bem_shouldEmitGet_0();
case -783968412: return bem_nameEntriesGet_0();
case -1563664482: return bem_usedByGet_0();
case 1133560869: return bem_new_0();
case 1355216037: return bem_subClassesGet_0();
case 1866990316: return bem_ptspGet_0();
case 1586891128: return bem_allNamesGet_0();
case -1613660155: return bem_serializationIteratorGet_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case -178013343: return bem_methodIndexesSet_1(bevd_0);
case 2143322364: return bem_allNamesSet_1(bevd_0);
case -2016681345: return bem_subClassesSet_1(bevd_0);
case 842180137: return bem_classesSet_1(bevd_0);
case 1024493267: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2025217150: return bem_ptspSet_1(bevd_0);
case -2073921006: return bem_aliasedSet_1(bevd_0);
case -1262843139: return bem_addParsedClass_1(bevd_0);
case -659240360: return bem_shouldEmitSet_1(bevd_0);
case 1170591864: return bem_otherClass_1(bevd_0);
case -805657525: return bem_foreignClassesSet_1(bevd_0);
case 2077566448: return bem_sameClass_1(bevd_0);
case 2076214171: return bem_justParsedSet_1(bevd_0);
case 579081683: return bem_defined_1(bevd_0);
case 224620460: return bem_usedBySet_1(bevd_0);
case -470551107: return bem_propertyIndexesSet_1(bevd_0);
case 1069670174: return bem_undef_1(bevd_0);
case -1210345122: return bem_notEquals_1(bevd_0);
case 940695143: return bem_midNamesSet_1(bevd_0);
case 1398941771: return bem_def_1(bevd_0);
case -1936197463: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2101700701: return bem_undefined_1(bevd_0);
case -503068138: return bem_sameType_1(bevd_0);
case 1933685650: return bem_equals_1(bevd_0);
case -1681809753: return bem_parseOrderClassNamesSet_1(bevd_0);
case 1270721790: return bem_sameObject_1(bevd_0);
case -1508704559: return bem_copyTo_1(bevd_0);
case -1682170766: return bem_otherType_1(bevd_0);
case -2055038488: return bem_nameEntriesSet_1(bevd_0);
case -240186291: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -122042490: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -240111636: return bem_synClassesSet_1(bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -483654719: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1372560242: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1722402091: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1097908484: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1055053136: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -155048445: return bem_addSynClass_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_8_BuildClassSyn) bevd_1);
case -1408482482: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2112228411: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildEmitData_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_8_BuildEmitData_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildEmitData();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst = (BEC_2_5_8_BuildEmitData) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst;
}
}
}
