namespace be {
/* IO:File: source/build/EmitData.be */
public sealed class BEC_2_5_8_BuildEmitData : BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildEmitData() { }
static BEC_2_5_8_BuildEmitData() { }
private static byte[] becc_BEC_2_5_8_BuildEmitData_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61};
private static byte[] becc_BEC_2_5_8_BuildEmitData_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static new BEC_2_5_8_BuildEmitData bece_BEC_2_5_8_BuildEmitData_bevs_inst;

public static new BET_2_5_8_BuildEmitData bece_BEC_2_5_8_BuildEmitData_bevs_type;

public BEC_2_9_3_ContainerMap bevp_ptsp;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_9_3_ContainerMap bevp_nameEntries;
public BEC_2_9_3_ContainerMap bevp_classes;
public BEC_2_9_10_ContainerLinkedList bevp_parseOrderClassNames;
public BEC_2_9_3_ContainerMap bevp_justParsed;
public BEC_2_9_3_ContainerMap bevp_synClasses;
public BEC_2_9_3_ContainerMap bevp_midNames;
public BEC_2_9_3_ContainerMap bevp_usedBy;
public BEC_2_9_3_ContainerMap bevp_subClasses;
public BEC_2_9_3_ContainerSet bevp_propertyIndexes;
public BEC_2_9_3_ContainerSet bevp_methodIndexes;
public BEC_2_9_3_ContainerSet bevp_shouldEmit;
public BEC_2_9_3_ContainerMap bevp_aliased;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_ptsp = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_nameEntries = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_justParsed = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_synClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_midNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_usedBy = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_subClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_aliased = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addSynClass_2(BEC_2_4_6_TextString beva_npstr, BEC_2_5_8_BuildClassSyn beva_syn) {
BEC_2_4_6_TextString bevl_myname = null;
BEC_2_4_6_TextString bevl_s = null;
BEC_2_9_3_ContainerSet bevl_ub = null;
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_8_BuildNamePath bevt_1_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevp_synClasses.bem_put_2(beva_npstr, beva_syn);
bevt_1_tmpany_phold = beva_syn.bem_namepathGet_0();
bevl_myname = bevt_1_tmpany_phold.bem_toString_0();
bevt_2_tmpany_phold = beva_syn.bem_usesGet_0();
bevt_0_tmpany_loop = bevt_2_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 41 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1517477859);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 41 */ {
bevl_s = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-2088960152);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_usedBy.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevl_ub = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_usedBy.bem_put_2(bevl_s, bevl_ub);
} /* Line: 45 */
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 47 */
 else  /* Line: 41 */ {
break;
} /* Line: 41 */
} /* Line: 41 */
bevt_5_tmpany_phold = beva_syn.bem_superListGet_0();
bevl_iu = bevt_5_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 49 */ {
bevt_6_tmpany_phold = bevl_iu.bemd_0(1517477859);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 49 */ {
bevt_7_tmpany_phold = bevl_iu.bemd_0(-2088960152);
bevl_s = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bemd_0(-90627019);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_subClasses.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevl_ub = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_subClasses.bem_put_2(bevl_s, bevl_ub);
} /* Line: 54 */
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 56 */
 else  /* Line: 49 */ {
break;
} /* Line: 49 */
} /* Line: 49 */
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addParsedClass_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = beva_node.bemd_0(-1966919751);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-1453774479);
bevt_1_tmpany_phold = bevp_classes.bem_has_1(bevt_2_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_5_tmpany_phold = beva_node.bemd_0(-1966919751);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-1453774479);
bevp_parseOrderClassNames.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 62 */
bevt_7_tmpany_phold = beva_node.bemd_0(-1966919751);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1453774479);
bevp_classes.bem_put_2(bevt_6_tmpany_phold, beva_node);
bevt_9_tmpany_phold = beva_node.bemd_0(-1966919751);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1453774479);
bevp_justParsed.bem_put_2(bevt_8_tmpany_phold, beva_node);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptspGet_0() {
return bevp_ptsp;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_ptspSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptsp = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_nameEntriesGet_0() {
return bevp_nameEntries;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_nameEntriesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameEntries = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classesGet_0() {
return bevp_classes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_classesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_parseOrderClassNamesGet_0() {
return bevp_parseOrderClassNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_parseOrderClassNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_justParsedGet_0() {
return bevp_justParsed;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_justParsedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_justParsed = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_synClassesGet_0() {
return bevp_synClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_synClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_midNamesGet_0() {
return bevp_midNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_midNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_midNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_usedByGet_0() {
return bevp_usedBy;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_usedBySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedBy = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_subClassesGet_0() {
return bevp_subClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_subClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_subClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_propertyIndexesGet_0() {
return bevp_propertyIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_propertyIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_methodIndexesGet_0() {
return bevp_methodIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_methodIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_shouldEmitGet_0() {
return bevp_shouldEmit;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_shouldEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGet_0() {
return bevp_aliased;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_aliasedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 30, 31, 32, 33, 34, 39, 40, 40, 41, 41, 0, 41, 41, 42, 43, 43, 44, 45, 47, 49, 49, 49, 50, 50, 51, 52, 52, 53, 54, 56, 61, 61, 61, 61, 61, 62, 62, 62, 64, 64, 64, 65, 65, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 59, 60, 61, 62, 63, 63, 66, 68, 69, 70, 75, 76, 77, 79, 85, 86, 89, 91, 92, 93, 94, 99, 100, 101, 103, 122, 123, 124, 125, 130, 131, 132, 133, 135, 136, 137, 138, 139, 140, 144, 147, 151, 154, 158, 161, 165, 168, 172, 175, 179, 182, 186, 189, 193, 196, 200, 203, 207, 210, 214, 217, 221, 224, 228, 231, 235, 238, 242, 245};
/* BEGIN LINEINFO 
assign 1 18 28
new 0 18 28
assign 1 19 29
new 0 19 29
assign 1 20 30
new 0 20 30
assign 1 21 31
new 0 21 31
assign 1 22 32
new 0 22 32
assign 1 23 33
new 0 23 33
assign 1 24 34
new 0 24 34
assign 1 25 35
new 0 25 35
assign 1 26 36
new 0 26 36
assign 1 28 37
new 0 28 37
assign 1 30 38
new 0 30 38
assign 1 31 39
new 0 31 39
assign 1 32 40
new 0 32 40
assign 1 33 41
new 0 33 41
assign 1 34 42
new 0 34 42
put 2 39 59
assign 1 40 60
namepathGet 0 40 60
assign 1 40 61
toString 0 40 61
assign 1 41 62
usesGet 0 41 62
assign 1 41 63
iteratorGet 0 0 63
assign 1 41 66
hasNextGet 0 41 66
assign 1 41 68
nextGet 0 41 68
assign 1 42 69
get 1 42 69
assign 1 43 70
undef 1 43 75
assign 1 44 76
new 0 44 76
put 2 45 77
put 1 47 79
assign 1 49 85
superListGet 0 49 85
assign 1 49 86
iteratorGet 0 49 86
assign 1 49 89
hasNextGet 0 49 89
assign 1 50 91
nextGet 0 50 91
assign 1 50 92
toString 0 50 92
assign 1 51 93
get 1 51 93
assign 1 52 94
undef 1 52 99
assign 1 53 100
new 0 53 100
put 2 54 101
put 1 56 103
assign 1 61 122
heldGet 0 61 122
assign 1 61 123
nameGet 0 61 123
assign 1 61 124
has 1 61 124
assign 1 61 125
not 0 61 130
assign 1 62 131
heldGet 0 62 131
assign 1 62 132
nameGet 0 62 132
addValue 1 62 133
assign 1 64 135
heldGet 0 64 135
assign 1 64 136
nameGet 0 64 136
put 2 64 137
assign 1 65 138
heldGet 0 65 138
assign 1 65 139
nameGet 0 65 139
put 2 65 140
return 1 0 144
assign 1 0 147
return 1 0 151
assign 1 0 154
return 1 0 158
assign 1 0 161
return 1 0 165
assign 1 0 168
return 1 0 172
assign 1 0 175
return 1 0 179
assign 1 0 182
return 1 0 186
assign 1 0 189
return 1 0 193
assign 1 0 196
return 1 0 200
assign 1 0 203
return 1 0 207
assign 1 0 210
return 1 0 214
assign 1 0 217
return 1 0 221
assign 1 0 224
return 1 0 228
assign 1 0 231
return 1 0 235
assign 1 0 238
return 1 0 242
assign 1 0 245
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1230030647: return bem_iteratorGet_0();
case 1332984380: return bem_shouldEmitGet_0();
case 899070981: return bem_justParsedGet_0();
case -1380773853: return bem_print_0();
case -83744974: return bem_propertyIndexesGet_0();
case -439739851: return bem_synClassesGet_0();
case -1416054527: return bem_parseOrderClassNamesGet_0();
case 1067432581: return bem_midNamesGet_0();
case 2114615984: return bem_methodIndexesGet_0();
case -1546212617: return bem_hashGet_0();
case -1812592029: return bem_copy_0();
case -1100277709: return bem_subClassesGet_0();
case -2109957485: return bem_usedByGet_0();
case 1765847529: return bem_toAny_0();
case 111705563: return bem_new_0();
case -908765693: return bem_ptspGet_0();
case 1814659174: return bem_echo_0();
case -140254392: return bem_classNameGet_0();
case 1138959219: return bem_create_0();
case 1136611843: return bem_many_0();
case -1346342591: return bem_tagGet_0();
case -154821822: return bem_serializationIteratorGet_0();
case 1018585219: return bem_classesGet_0();
case 2031852918: return bem_deserializeClassNameGet_0();
case 1342679332: return bem_nameEntriesGet_0();
case -108571624: return bem_serializeContents_0();
case -110239012: return bem_sourceFileNameGet_0();
case -90627019: return bem_toString_0();
case 1843946637: return bem_fieldIteratorGet_0();
case 68178928: return bem_aliasedGet_0();
case 773765340: return bem_foreignClassesGet_0();
case 573326416: return bem_allNamesGet_0();
case -375963306: return bem_serializeToString_0();
case 1826454756: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 605988866: return bem_foreignClassesSet_1(bevd_0);
case 443340578: return bem_justParsedSet_1(bevd_0);
case -2018573962: return bem_defined_1(bevd_0);
case 2063142157: return bem_usedBySet_1(bevd_0);
case -1745069966: return bem_def_1(bevd_0);
case 1340212539: return bem_propertyIndexesSet_1(bevd_0);
case 1340954430: return bem_undefined_1(bevd_0);
case 1121973730: return bem_ptspSet_1(bevd_0);
case -1921729762: return bem_aliasedSet_1(bevd_0);
case -1157481258: return bem_sameObject_1(bevd_0);
case -2106584206: return bem_allNamesSet_1(bevd_0);
case 1955134607: return bem_otherClass_1(bevd_0);
case -1198247472: return bem_undef_1(bevd_0);
case 179370193: return bem_midNamesSet_1(bevd_0);
case -2050905939: return bem_notEquals_1(bevd_0);
case -604934649: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -326862297: return bem_methodIndexesSet_1(bevd_0);
case -101626619: return bem_parseOrderClassNamesSet_1(bevd_0);
case -1352048316: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2066445660: return bem_subClassesSet_1(bevd_0);
case -231386564: return bem_sameClass_1(bevd_0);
case -1115570085: return bem_classesSet_1(bevd_0);
case -219212999: return bem_shouldEmitSet_1(bevd_0);
case 1526501544: return bem_copyTo_1(bevd_0);
case 2033783017: return bem_sameType_1(bevd_0);
case -898454377: return bem_equals_1(bevd_0);
case -661253840: return bem_synClassesSet_1(bevd_0);
case 709707251: return bem_nameEntriesSet_1(bevd_0);
case 2047832635: return bem_addParsedClass_1(bevd_0);
case -166605595: return bem_otherType_1(bevd_0);
case 748668477: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 452045758: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1477024989: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1086183440: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -13817058: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1749882081: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -826896459: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 416141599: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 647643475: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 260265794: return bem_addSynClass_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_8_BuildClassSyn) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildEmitData_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_8_BuildEmitData_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildEmitData();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst = (BEC_2_5_8_BuildEmitData) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_type;
}
}
}
