namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerMap : BEC_2_9_3_ContainerSet {
public BEC_2_9_3_ContainerMap() { }
static BEC_2_9_3_ContainerMap() { }
private static byte[] becc_BEC_2_9_3_ContainerMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_3_ContainerMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_inst;

public static new BET_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_3_9_3_21_ContainerMapSerializationIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_3_21_ContainerMapSerializationIterator) (new BEC_3_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva__other) {
BEC_2_9_3_ContainerMap bevl_other = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
bevl_other = (BEC_2_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_6_tmpany_phold = bevl_other.bem_sizeGet_0();
bevt_7_tmpany_phold = bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int != bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 126 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 127 */
bevt_0_tmpany_loop = bem_mapIteratorGet_0();
while (true)
 /* Line: 129 */ {
bevt_9_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevl_i = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_i.bemd_0(1366514121);
bevl_v = bevl_other.bem_get_1(bevt_10_tmpany_phold);
if (bevl_v == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_13_tmpany_phold = bevl_i.bemd_0(-571067985);
if (bevt_13_tmpany_phold == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 131 */ {
if (bevl_v == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
 else  /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 131 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_16_tmpany_phold = bevl_i.bemd_0(-571067985);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-1007540340, bevl_v);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 131 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 131 */ {
bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_17_tmpany_phold;
} /* Line: 131 */
} /* Line: 131 */
 else  /* Line: 129 */ {
break;
} /* Line: 129 */
} /* Line: 129 */
bevt_18_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_18_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_put_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_innerPut_4(beva_k, beva_v, null, bevp_slots);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-290803610);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 137 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
 /* Line: 140 */ {
bevt_3_tmpany_phold = bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-290803610);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 141 */
 else  /* Line: 140 */ {
break;
} /* Line: 140 */
} /* Line: 140 */
bevp_slots = bevl_slt;
} /* Line: 143 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 145 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 146 */
return this;
} /*method end*/
public virtual BEC_3_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_3_9_3_13_ContainerMapValueIterator) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_13_ContainerMapValueIterator bem_valuesGet_0() {
BEC_3_9_3_13_ContainerMapValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_valueIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() {
BEC_3_9_3_16_ContainerMapKeyValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_3_16_ContainerMapKeyValueIterator) (new BEC_3_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_mapIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_3_ContainerMap bevl_otherMap = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_2_tmpany_phold = beva_other.bemd_1(1621186357, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 172 */ {
bevl_otherMap = (BEC_2_9_3_ContainerMap) beva_other;
bevt_0_tmpany_loop = bevl_otherMap.bem_mapIteratorGet_0();
while (true)
 /* Line: 174 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 174 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_4_tmpany_phold = bevl_x.bemd_0(1366514121);
bevt_5_tmpany_phold = bevl_x.bemd_0(-571067985);
bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 175 */
 else  /* Line: 174 */ {
break;
} /* Line: 174 */
} /* Line: 174 */
} /* Line: 174 */
 else  /* Line: 172 */ {
bevt_6_tmpany_phold = beva_other.bemd_1(1621186357, bevp_baseNode);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 177 */ {
bevt_7_tmpany_phold = beva_other.bemd_0(1366514121);
bevt_8_tmpany_phold = beva_other.bemd_0(-571067985);
bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
} /* Line: 178 */
 else  /* Line: 179 */ {
bem_put_2(beva_other, beva_other);
} /* Line: 180 */
} /* Line: 172 */
} /* Line: 172 */
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_toRet = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_loop = bem_mapIteratorGet_0();
while (true)
 /* Line: 187 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = bevl_x.bemd_0(1366514121);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(117705837, beva_prefix);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 188 */ {
bevt_4_tmpany_phold = bevl_x.bemd_0(1366514121);
bevt_5_tmpany_phold = bevl_x.bemd_0(-571067985);
bevl_toRet.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 189 */
} /* Line: 188 */
 else  /* Line: 187 */ {
break;
} /* Line: 187 */
} /* Line: 187 */
return bevl_toRet;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {108, 108, 112, 113, 114, 115, 116, 117, 121, 121, 125, 126, 126, 0, 126, 126, 126, 126, 0, 0, 127, 127, 129, 0, 129, 129, 130, 130, 131, 131, 0, 131, 131, 131, 131, 131, 0, 0, 0, 0, 0, 0, 131, 131, 0, 0, 131, 131, 133, 133, 137, 137, 138, 139, 140, 140, 141, 143, 146, 151, 151, 155, 155, 159, 159, 163, 163, 167, 167, 171, 171, 172, 173, 174, 0, 174, 174, 175, 175, 175, 177, 178, 178, 178, 180, 186, 187, 0, 187, 187, 188, 188, 189, 189, 189, 192};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24, 29, 30, 55, 56, 61, 62, 65, 66, 67, 72, 73, 76, 80, 81, 83, 83, 86, 88, 89, 90, 91, 96, 97, 100, 101, 106, 107, 112, 113, 116, 120, 123, 126, 130, 133, 134, 136, 139, 143, 144, 151, 152, 160, 161, 163, 164, 167, 168, 170, 176, 179, 185, 186, 190, 191, 195, 196, 200, 201, 205, 206, 220, 225, 226, 228, 229, 229, 232, 234, 235, 236, 237, 245, 247, 248, 249, 252, 267, 268, 268, 271, 273, 274, 275, 277, 278, 279, 286};
/* BEGIN LINEINFO 
assign 1 108 14
new 0 108 14
new 1 108 15
assign 1 112 19
new 1 112 19
assign 1 113 20
assign 1 114 21
new 0 114 21
assign 1 115 22
new 0 115 22
assign 1 116 23
new 0 116 23
assign 1 117 24
new 0 117 24
assign 1 121 29
new 1 121 29
return 1 121 30
assign 1 125 55
assign 1 126 56
undef 1 126 61
assign 1 0 62
assign 1 126 65
sizeGet 0 126 65
assign 1 126 66
sizeGet 0 126 66
assign 1 126 67
notEquals 1 126 72
assign 1 0 73
assign 1 0 76
assign 1 127 80
new 0 127 80
return 1 127 81
assign 1 129 83
mapIteratorGet 0 0 83
assign 1 129 86
hasNextGet 0 129 86
assign 1 129 88
nextGet 0 129 88
assign 1 130 89
keyGet 0 130 89
assign 1 130 90
get 1 130 90
assign 1 131 91
undef 1 131 96
assign 1 0 97
assign 1 131 100
valueGet 0 131 100
assign 1 131 101
undef 1 131 106
assign 1 131 107
def 1 131 112
assign 1 0 113
assign 1 0 116
assign 1 0 120
assign 1 0 123
assign 1 0 126
assign 1 0 130
assign 1 131 133
valueGet 0 131 133
assign 1 131 134
notEquals 1 131 134
assign 1 0 136
assign 1 0 139
assign 1 131 143
new 0 131 143
return 1 131 144
assign 1 133 151
new 0 133 151
return 1 133 152
assign 1 137 160
innerPut 4 137 160
assign 1 137 161
not 0 137 161
assign 1 138 163
assign 1 139 164
rehash 1 139 164
assign 1 140 167
innerPut 4 140 167
assign 1 140 168
not 0 140 168
assign 1 141 170
rehash 1 141 170
assign 1 143 176
assign 1 146 179
increment 0 146 179
assign 1 151 185
new 1 151 185
return 1 151 186
assign 1 155 190
valueIteratorGet 0 155 190
return 1 155 191
assign 1 159 195
new 1 159 195
return 1 159 196
assign 1 163 200
new 1 163 200
return 1 163 201
assign 1 167 205
new 1 167 205
return 1 167 206
assign 1 171 220
def 1 171 225
assign 1 172 226
sameType 1 172 226
assign 1 173 228
assign 1 174 229
mapIteratorGet 0 0 229
assign 1 174 232
hasNextGet 0 174 232
assign 1 174 234
nextGet 0 174 234
assign 1 175 235
keyGet 0 175 235
assign 1 175 236
valueGet 0 175 236
put 2 175 237
assign 1 177 245
sameType 1 177 245
assign 1 178 247
keyGet 0 178 247
assign 1 178 248
valueGet 0 178 248
put 2 178 249
put 2 180 252
assign 1 186 267
new 0 186 267
assign 1 187 268
mapIteratorGet 0 0 268
assign 1 187 271
hasNextGet 0 187 271
assign 1 187 273
nextGet 0 187 273
assign 1 188 274
keyGet 0 188 274
assign 1 188 275
begins 1 188 275
assign 1 189 277
keyGet 0 189 277
assign 1 189 278
valueGet 0 189 278
put 2 189 279
return 1 192 286
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 367195678: return bem_once_0();
case -356304724: return bem_sizeGetDirect_0();
case -2088938944: return bem_relGetDirect_0();
case -1500273643: return bem_baseNodeGet_0();
case -1821813757: return bem_multiGet_0();
case 402201008: return bem_new_0();
case -1854726950: return bem_echo_0();
case -1795002401: return bem_toString_0();
case 454564447: return bem_slotsGetDirect_0();
case 682604587: return bem_serializeContents_0();
case 1149056494: return bem_valuesGet_0();
case 166448791: return bem_moduGet_0();
case 748315678: return bem_tagGet_0();
case 1298518609: return bem_relGet_0();
case 1342765490: return bem_toAny_0();
case 1346473734: return bem_nodesGet_0();
case 808044123: return bem_hashGet_0();
case 2005686061: return bem_innerPutAddedGet_0();
case -95777594: return bem_isEmptyGet_0();
case 264797911: return bem_mapIteratorGet_0();
case 95470320: return bem_keyIteratorGet_0();
case -1434470583: return bem_sizeGet_0();
case -636994806: return bem_sourceFileNameGet_0();
case 2020690092: return bem_slotsGet_0();
case 1678261270: return bem_print_0();
case -41478833: return bem_setIteratorGet_0();
case 966149554: return bem_create_0();
case -2048417894: return bem_keyValueIteratorGet_0();
case -656937356: return bem_many_0();
case 55812595: return bem_serializeToString_0();
case -141267252: return bem_nodeIteratorGet_0();
case -182027643: return bem_valueIteratorGet_0();
case -434919379: return bem_deserializeClassNameGet_0();
case -1704973659: return bem_notEmptyGet_0();
case -1975455714: return bem_copy_0();
case -1863033766: return bem_keysGet_0();
case 2121970055: return bem_moduGetDirect_0();
case 9957435: return bem_iteratorGet_0();
case -772967023: return bem_classNameGet_0();
case -604312045: return bem_serializationIteratorGet_0();
case -758114746: return bem_clear_0();
case 825510823: return bem_innerPutAddedGetDirect_0();
case -368347729: return bem_fieldNamesGet_0();
case 1860492410: return bem_fieldIteratorGet_0();
case 396105702: return bem_baseNodeGetDirect_0();
case -683371164: return bem_multiGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1052747643: return bem_innerPutAddedSet_1(bevd_0);
case 363620695: return bem_relSet_1(bevd_0);
case 171615032: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1880329535: return bem_addValue_1(bevd_0);
case 4720227: return bem_put_1(bevd_0);
case 1775600418: return bem_delete_1(bevd_0);
case 318986187: return bem_moduSet_1(bevd_0);
case 267174377: return bem_def_1(bevd_0);
case -1522412411: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1272631429: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -714900612: return bem_copyTo_1(bevd_0);
case -1007540340: return bem_notEquals_1(bevd_0);
case 1621186357: return bem_sameType_1(bevd_0);
case 1647993291: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 11370082: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1240263812: return bem_relSetDirect_1(bevd_0);
case -1194473609: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1184618836: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1508002693: return bem_sizeSetDirect_1(bevd_0);
case -1182555093: return bem_moduSetDirect_1(bevd_0);
case 1595889109: return bem_baseNodeSet_1(bevd_0);
case -959756092: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 779415354: return bem_slotsSet_1(bevd_0);
case -1767718563: return bem_get_1(bevd_0);
case 210091801: return bem_baseNodeSetDirect_1(bevd_0);
case 195308005: return bem_sameObject_1(bevd_0);
case 1299261839: return bem_multiSet_1(bevd_0);
case -1728665032: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 543061021: return bem_otherClass_1(bevd_0);
case -1757838534: return bem_sizeSet_1(bevd_0);
case 2108290256: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1448933357: return bem_otherType_1(bevd_0);
case 1485494702: return bem_has_1(bevd_0);
case 1614496109: return bem_undef_1(bevd_0);
case -78078309: return bem_multiSetDirect_1(bevd_0);
case 350775730: return bem_equals_1(bevd_0);
case -2144202949: return bem_sameClass_1(bevd_0);
case 726728152: return bem_slotsSetDirect_1(bevd_0);
case 1163078007: return bem_undefined_1(bevd_0);
case -700310720: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -991365338: return bem_defined_1(bevd_0);
case -1286410426: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 325307565: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -551175220: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1385197575: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1718302699: return bem_put_2(bevd_0, bevd_1);
case 1280867989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1833007700: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1584099228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -187061774: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -961973758: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 630698773: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_3_ContainerMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst = (BEC_2_9_3_ContainerMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_type;
}
}
}
