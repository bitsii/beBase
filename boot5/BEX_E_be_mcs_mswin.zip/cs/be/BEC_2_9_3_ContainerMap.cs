namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerMap : BEC_2_9_3_ContainerSet {
public BEC_2_9_3_ContainerMap() { }
static BEC_2_9_3_ContainerMap() { }
private static byte[] becc_BEC_2_9_3_ContainerMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_3_ContainerMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_inst;

public static new BET_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_3_9_3_21_ContainerMapSerializationIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_3_21_ContainerMapSerializationIterator) (new BEC_3_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva__other) {
BEC_2_9_3_ContainerMap bevl_other = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
bevl_other = (BEC_2_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 125 */ {
bevt_6_tmpany_phold = bevl_other.bem_sizeGet_0();
bevt_7_tmpany_phold = bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int != bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 125 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 125 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 125 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 126 */
bevt_0_tmpany_loop = bem_mapIteratorGet_0();
while (true)
 /* Line: 128 */ {
bevt_9_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 128 */ {
bevl_i = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_i.bemd_0(-966518794);
bevl_v = bevl_other.bem_get_1(bevt_10_tmpany_phold);
if (bevl_v == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 130 */ {
bevt_13_tmpany_phold = bevl_i.bemd_0(-1256413088);
if (bevt_13_tmpany_phold == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 130 */ {
if (bevl_v == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 130 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 130 */
 else  /* Line: 130 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 130 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 130 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 130 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 130 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 130 */ {
bevt_16_tmpany_phold = bevl_i.bemd_0(-1256413088);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(1673385175, bevl_v);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 130 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 130 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 130 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 130 */ {
bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_17_tmpany_phold;
} /* Line: 130 */
} /* Line: 130 */
 else  /* Line: 128 */ {
break;
} /* Line: 128 */
} /* Line: 128 */
bevt_18_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_18_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_put_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_innerPut_4(beva_k, beva_v, null, bevp_slots);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1168890224);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 136 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
 /* Line: 139 */ {
bevt_3_tmpany_phold = bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(1168890224);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 139 */ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 140 */
 else  /* Line: 139 */ {
break;
} /* Line: 139 */
} /* Line: 139 */
bevp_slots = bevl_slt;
} /* Line: 142 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 144 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 145 */
return this;
} /*method end*/
public virtual BEC_3_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_3_9_3_13_ContainerMapValueIterator) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_13_ContainerMapValueIterator bem_valuesGet_0() {
BEC_3_9_3_13_ContainerMapValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_valueIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() {
BEC_3_9_3_16_ContainerMapKeyValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_3_16_ContainerMapKeyValueIterator) (new BEC_3_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_mapIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_3_ContainerMap bevl_otherMap = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 170 */ {
bevt_2_tmpany_phold = beva_other.bemd_1(1953776597, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 171 */ {
bevl_otherMap = (BEC_2_9_3_ContainerMap) beva_other;
bevt_0_tmpany_loop = bevl_otherMap.bem_mapIteratorGet_0();
while (true)
 /* Line: 173 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 173 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_4_tmpany_phold = bevl_x.bemd_0(-966518794);
bevt_5_tmpany_phold = bevl_x.bemd_0(-1256413088);
bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 174 */
 else  /* Line: 173 */ {
break;
} /* Line: 173 */
} /* Line: 173 */
} /* Line: 173 */
 else  /* Line: 171 */ {
bevt_6_tmpany_phold = beva_other.bemd_1(1953776597, bevp_baseNode);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 176 */ {
bevt_7_tmpany_phold = beva_other.bemd_0(-966518794);
bevt_8_tmpany_phold = beva_other.bemd_0(-1256413088);
bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
} /* Line: 177 */
 else  /* Line: 178 */ {
bem_put_2(beva_other, beva_other);
} /* Line: 179 */
} /* Line: 171 */
} /* Line: 171 */
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_toRet = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_loop = bem_mapIteratorGet_0();
while (true)
 /* Line: 186 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = bevl_x.bemd_0(-966518794);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(291846996, beva_prefix);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 187 */ {
bevt_4_tmpany_phold = bevl_x.bemd_0(-966518794);
bevt_5_tmpany_phold = bevl_x.bemd_0(-1256413088);
bevl_toRet.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 188 */
} /* Line: 187 */
 else  /* Line: 186 */ {
break;
} /* Line: 186 */
} /* Line: 186 */
return bevl_toRet;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {107, 107, 111, 112, 113, 114, 115, 116, 120, 120, 124, 125, 125, 0, 125, 125, 125, 125, 0, 0, 126, 126, 128, 0, 128, 128, 129, 129, 130, 130, 0, 130, 130, 130, 130, 130, 0, 0, 0, 0, 0, 0, 130, 130, 0, 0, 130, 130, 132, 132, 136, 136, 137, 138, 139, 139, 140, 142, 145, 150, 150, 154, 154, 158, 158, 162, 162, 166, 166, 170, 170, 171, 172, 173, 0, 173, 173, 174, 174, 174, 176, 177, 177, 177, 179, 185, 186, 0, 186, 186, 187, 187, 188, 188, 188, 191};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24, 29, 30, 55, 56, 61, 62, 65, 66, 67, 72, 73, 76, 80, 81, 83, 83, 86, 88, 89, 90, 91, 96, 97, 100, 101, 106, 107, 112, 113, 116, 120, 123, 126, 130, 133, 134, 136, 139, 143, 144, 151, 152, 160, 161, 163, 164, 167, 168, 170, 176, 179, 185, 186, 190, 191, 195, 196, 200, 201, 205, 206, 220, 225, 226, 228, 229, 229, 232, 234, 235, 236, 237, 245, 247, 248, 249, 252, 267, 268, 268, 271, 273, 274, 275, 277, 278, 279, 286};
/* BEGIN LINEINFO 
assign 1 107 14
new 0 107 14
new 1 107 15
assign 1 111 19
new 1 111 19
assign 1 112 20
assign 1 113 21
new 0 113 21
assign 1 114 22
new 0 114 22
assign 1 115 23
new 0 115 23
assign 1 116 24
new 0 116 24
assign 1 120 29
new 1 120 29
return 1 120 30
assign 1 124 55
assign 1 125 56
undef 1 125 61
assign 1 0 62
assign 1 125 65
sizeGet 0 125 65
assign 1 125 66
sizeGet 0 125 66
assign 1 125 67
notEquals 1 125 72
assign 1 0 73
assign 1 0 76
assign 1 126 80
new 0 126 80
return 1 126 81
assign 1 128 83
mapIteratorGet 0 0 83
assign 1 128 86
hasNextGet 0 128 86
assign 1 128 88
nextGet 0 128 88
assign 1 129 89
keyGet 0 129 89
assign 1 129 90
get 1 129 90
assign 1 130 91
undef 1 130 96
assign 1 0 97
assign 1 130 100
valueGet 0 130 100
assign 1 130 101
undef 1 130 106
assign 1 130 107
def 1 130 112
assign 1 0 113
assign 1 0 116
assign 1 0 120
assign 1 0 123
assign 1 0 126
assign 1 0 130
assign 1 130 133
valueGet 0 130 133
assign 1 130 134
notEquals 1 130 134
assign 1 0 136
assign 1 0 139
assign 1 130 143
new 0 130 143
return 1 130 144
assign 1 132 151
new 0 132 151
return 1 132 152
assign 1 136 160
innerPut 4 136 160
assign 1 136 161
not 0 136 161
assign 1 137 163
assign 1 138 164
rehash 1 138 164
assign 1 139 167
innerPut 4 139 167
assign 1 139 168
not 0 139 168
assign 1 140 170
rehash 1 140 170
assign 1 142 176
assign 1 145 179
increment 0 145 179
assign 1 150 185
new 1 150 185
return 1 150 186
assign 1 154 190
valueIteratorGet 0 154 190
return 1 154 191
assign 1 158 195
new 1 158 195
return 1 158 196
assign 1 162 200
new 1 162 200
return 1 162 201
assign 1 166 205
new 1 166 205
return 1 166 206
assign 1 170 220
def 1 170 225
assign 1 171 226
sameType 1 171 226
assign 1 172 228
assign 1 173 229
mapIteratorGet 0 0 229
assign 1 173 232
hasNextGet 0 173 232
assign 1 173 234
nextGet 0 173 234
assign 1 174 235
keyGet 0 174 235
assign 1 174 236
valueGet 0 174 236
put 2 174 237
assign 1 176 245
sameType 1 176 245
assign 1 177 247
keyGet 0 177 247
assign 1 177 248
valueGet 0 177 248
put 2 177 249
put 2 179 252
assign 1 185 267
new 0 185 267
assign 1 186 268
mapIteratorGet 0 0 268
assign 1 186 271
hasNextGet 0 186 271
assign 1 186 273
nextGet 0 186 273
assign 1 187 274
keyGet 0 187 274
assign 1 187 275
begins 1 187 275
assign 1 188 277
keyGet 0 188 277
assign 1 188 278
valueGet 0 188 278
put 2 188 279
return 1 191 286
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1907635971: return bem_tagGet_0();
case -927090833: return bem_new_0();
case -41389076: return bem_multiGet_0();
case -1002607895: return bem_sizeGetDirect_0();
case 1644159961: return bem_relGetDirect_0();
case 1109704349: return bem_slotsGet_0();
case -444269598: return bem_setIteratorGet_0();
case 1550760607: return bem_fieldIteratorGet_0();
case -65082849: return bem_once_0();
case 1926333158: return bem_relGet_0();
case 605655591: return bem_sourceFileNameGet_0();
case -1655660203: return bem_hashGet_0();
case -1577817259: return bem_echo_0();
case -50560558: return bem_mapIteratorGet_0();
case -209245103: return bem_valuesGet_0();
case 1267812147: return bem_classNameGet_0();
case -1271382771: return bem_clear_0();
case -1572010998: return bem_copy_0();
case -1879356356: return bem_notEmptyGet_0();
case -112905867: return bem_keyIteratorGet_0();
case -1233682651: return bem_multiGetDirect_0();
case -1007878556: return bem_many_0();
case -1353172126: return bem_toString_0();
case 1242173088: return bem_moduGetDirect_0();
case 1840593132: return bem_sizeGet_0();
case 812685421: return bem_iteratorGet_0();
case 399659833: return bem_slotsGetDirect_0();
case 1530555194: return bem_serializeContents_0();
case -1310746877: return bem_valueIteratorGet_0();
case 702246847: return bem_print_0();
case -1000018882: return bem_create_0();
case -500248069: return bem_serializationIteratorGet_0();
case -364249863: return bem_serializeToString_0();
case 513882387: return bem_baseNodeGetDirect_0();
case -1959825752: return bem_nodesGet_0();
case 2036694681: return bem_keysGet_0();
case -106257945: return bem_fieldNamesGet_0();
case 841108956: return bem_innerPutAddedGetDirect_0();
case 1524391071: return bem_baseNodeGet_0();
case 1472054563: return bem_isEmptyGet_0();
case 1966713191: return bem_deserializeClassNameGet_0();
case -209457000: return bem_keyValueIteratorGet_0();
case -474773744: return bem_nodeIteratorGet_0();
case 1581692921: return bem_toAny_0();
case 2020633149: return bem_moduGet_0();
case 308207615: return bem_innerPutAddedGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1543095159: return bem_multiSetDirect_1(bevd_0);
case -886218051: return bem_equals_1(bevd_0);
case -481756547: return bem_undef_1(bevd_0);
case -926431997: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -227529285: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1330834253: return bem_sizeSet_1(bevd_0);
case -1096288675: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1385994869: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 860351095: return bem_moduSet_1(bevd_0);
case 1258464331: return bem_has_1(bevd_0);
case -509638081: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 150021405: return bem_otherClass_1(bevd_0);
case -78405692: return bem_slotsSet_1(bevd_0);
case -1809912257: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -759946269: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1471457238: return bem_sameObject_1(bevd_0);
case -380623615: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1862075337: return bem_copyTo_1(bevd_0);
case 439602846: return bem_get_1(bevd_0);
case 1529065971: return bem_sizeSetDirect_1(bevd_0);
case 726015407: return bem_otherType_1(bevd_0);
case -1556952447: return bem_defined_1(bevd_0);
case -10869515: return bem_delete_1(bevd_0);
case -1633669948: return bem_innerPutAddedSet_1(bevd_0);
case 1673385175: return bem_notEquals_1(bevd_0);
case 1698158300: return bem_put_1(bevd_0);
case -1784728675: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -684720356: return bem_slotsSetDirect_1(bevd_0);
case -1805171749: return bem_relSetDirect_1(bevd_0);
case 999858551: return bem_baseNodeSetDirect_1(bevd_0);
case -1940917614: return bem_addValue_1(bevd_0);
case 1953776597: return bem_sameType_1(bevd_0);
case 1829434833: return bem_moduSetDirect_1(bevd_0);
case -277595620: return bem_relSet_1(bevd_0);
case 140166424: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2141774895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 297381803: return bem_def_1(bevd_0);
case 1244819809: return bem_undefined_1(bevd_0);
case -58459221: return bem_sameClass_1(bevd_0);
case 69557453: return bem_multiSet_1(bevd_0);
case -1404821193: return bem_baseNodeSet_1(bevd_0);
case 1702481018: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1970963739: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 904162443: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -967702518: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -845452519: return bem_put_2(bevd_0, bevd_1);
case -427898914: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 414161005: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -157052200: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1722905349: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 611344245: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 938028004: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_3_ContainerMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst = (BEC_2_9_3_ContainerMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_type;
}
}
}
