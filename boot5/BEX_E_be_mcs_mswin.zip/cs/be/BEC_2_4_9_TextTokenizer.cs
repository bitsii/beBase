namespace be {
/* IO:File: source/base/Tokenize.be */
public sealed class BEC_2_4_9_TextTokenizer : BEC_2_6_6_SystemObject {
public BEC_2_4_9_TextTokenizer() { }
static BEC_2_4_9_TextTokenizer() { }
private static byte[] becc_BEC_2_4_9_TextTokenizer_clname = {0x54,0x65,0x78,0x74,0x3A,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_4_9_TextTokenizer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
public static new BEC_2_4_9_TextTokenizer bece_BEC_2_4_9_TextTokenizer_bevs_inst;

public static new BET_2_4_9_TextTokenizer bece_BEC_2_4_9_TextTokenizer_bevs_type;

public BEC_2_9_3_ContainerMap bevp_tmap;
public BEC_2_5_4_LogicBool bevp_includeTokens;
public BEC_2_4_9_TextTokenizer bem_new_1(BEC_2_4_6_TextString beva_delims) {
bevp_includeTokens = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_new_2(BEC_2_4_6_TextString beva_delims, BEC_2_5_4_LogicBool beva__includeTokens) {
bevp_includeTokens = beva__includeTokens;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokensStringSet_1(BEC_2_4_6_TextString beva_delims) {
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevp_tmap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_ta_loop = beva_delims.bem_stringIteratorGet_0();
while (true)
/* Line: 23*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 23*/ {
bevl_chi = bevt_0_ta_loop.bem_nextGet_0();
bevt_2_ta_ph = bevl_chi.bem_toString_0();
bevp_tmap.bem_put_2(bevl_chi, bevt_2_ta_ph);
} /* Line: 24*/
 else /* Line: 23*/ {
break;
} /* Line: 23*/
} /* Line: 23*/
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_addToken_1(BEC_2_4_6_TextString beva__delim) {
BEC_2_4_6_TextString bevl_delim = null;
bevl_delim = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_delim.bem_addValue_1(beva__delim);
bevp_tmap.bem_put_2(bevl_delim, beva__delim);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_ta_ph = bem_tokenizeIterator_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_2(BEC_2_6_6_SystemObject beva_str, BEC_2_6_6_SystemObject beva_tokenAcceptor) {
BEC_2_4_9_TextTokenizer bevt_0_ta_ph = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_ta_ph = (BEC_2_4_9_TextTokenizer) bem_tokenizeIterator_2(bevt_1_ta_ph, beva_tokenAcceptor);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokenizeIterator_2(BEC_2_6_6_SystemObject beva_i, BEC_2_6_6_SystemObject beva_acceptor) {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
/* Line: 45*/ {
bevt_0_ta_ph = beva_i.bemd_0(1102233);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 45*/ {
beva_i.bemd_1(-876913346, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_3_ta_ph = bevl_accum.bem_sizeGet_0();
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevt_3_ta_ph.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_5_ta_ph = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(-1910418131, bevt_5_ta_ph);
} /* Line: 50*/
if (bevp_includeTokens.bevi_bool)/* Line: 52*/ {
beva_acceptor.bemd_1(-1910418131, bevl_cc);
} /* Line: 53*/
} /* Line: 52*/
 else /* Line: 55*/ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 56*/
} /* Line: 48*/
 else /* Line: 45*/ {
break;
} /* Line: 45*/
} /* Line: 45*/
bevt_7_ta_ph = bevl_accum.bem_sizeGet_0();
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevt_7_ta_ph.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 59*/ {
bevt_9_ta_ph = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(-1910418131, bevt_9_ta_ph);
} /* Line: 60*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenizeIterator_1(BEC_2_6_6_SystemObject beva_i) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
/* Line: 68*/ {
bevt_0_ta_ph = beva_i.bemd_0(1102233);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 68*/ {
beva_i.bemd_1(-876913346, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_3_ta_ph = bevl_accum.bem_sizeGet_0();
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevt_3_ta_ph.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 72*/ {
bevt_5_ta_ph = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 73*/
if (bevp_includeTokens.bevi_bool)/* Line: 75*/ {
bevl_splits.bem_addValue_1(bevl_cc);
} /* Line: 76*/
} /* Line: 75*/
 else /* Line: 78*/ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 79*/
} /* Line: 71*/
 else /* Line: 68*/ {
break;
} /* Line: 68*/
} /* Line: 68*/
bevt_7_ta_ph = bevl_accum.bem_sizeGet_0();
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevt_7_ta_ph.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 82*/ {
bevt_9_ta_ph = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_9_ta_ph);
} /* Line: 83*/
return bevl_splits;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_tmapGet_0() {
return bevp_tmap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_tmapGetDirect_0() {
return bevp_tmap;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tmap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tmap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_includeTokensGet_0() {
return bevp_includeTokens;
} /*method end*/
public BEC_2_5_4_LogicBool bem_includeTokensGetDirect_0() {
return bevp_includeTokens;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_includeTokensSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_includeTokens = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_includeTokensSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_includeTokens = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {12, 13, 17, 18, 22, 23, 0, 23, 23, 24, 24, 29, 30, 31, 35, 35, 35, 39, 39, 39, 43, 44, 45, 46, 47, 48, 48, 49, 49, 49, 49, 50, 50, 53, 56, 59, 59, 59, 59, 60, 60, 65, 66, 67, 68, 69, 70, 71, 71, 72, 72, 72, 72, 73, 73, 76, 79, 82, 82, 82, 82, 83, 83, 85, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {15, 16, 20, 21, 29, 30, 30, 33, 35, 36, 37, 47, 48, 49, 55, 56, 57, 62, 63, 64, 80, 81, 84, 86, 87, 88, 93, 94, 95, 96, 101, 102, 103, 106, 110, 117, 118, 119, 124, 125, 126, 145, 146, 147, 150, 152, 153, 154, 159, 160, 161, 162, 167, 168, 169, 172, 176, 183, 184, 185, 190, 191, 192, 194, 197, 200, 203, 207, 211, 214, 217, 221};
/* BEGIN LINEINFO 
assign 1 12 15
new 0 12 15
tokensStringSet 1 13 16
assign 1 17 20
tokensStringSet 1 18 21
assign 1 22 29
new 0 22 29
assign 1 23 30
stringIteratorGet 0 0 30
assign 1 23 33
hasNextGet 0 23 33
assign 1 23 35
nextGet 0 23 35
assign 1 24 36
toString 0 24 36
put 2 24 37
assign 1 29 47
new 0 29 47
addValue 1 30 48
put 2 31 49
assign 1 35 55
new 1 35 55
assign 1 35 56
tokenizeIterator 1 35 56
return 1 35 57
assign 1 39 62
new 1 39 62
assign 1 39 63
tokenizeIterator 2 39 63
return 1 39 64
assign 1 43 80
new 0 43 80
assign 1 44 81
new 0 44 81
assign 1 45 84
hasNextGet 0 45 84
next 1 46 86
assign 1 47 87
get 1 47 87
assign 1 48 88
def 1 48 93
assign 1 49 94
sizeGet 0 49 94
assign 1 49 95
new 0 49 95
assign 1 49 96
greater 1 49 101
assign 1 50 102
extractString 0 50 102
acceptToken 1 50 103
acceptToken 1 53 106
addValue 1 56 110
assign 1 59 117
sizeGet 0 59 117
assign 1 59 118
new 0 59 118
assign 1 59 119
greater 1 59 124
assign 1 60 125
extractString 0 60 125
acceptToken 1 60 126
assign 1 65 145
new 0 65 145
assign 1 66 146
new 0 66 146
assign 1 67 147
new 0 67 147
assign 1 68 150
hasNextGet 0 68 150
next 1 69 152
assign 1 70 153
get 1 70 153
assign 1 71 154
def 1 71 159
assign 1 72 160
sizeGet 0 72 160
assign 1 72 161
new 0 72 161
assign 1 72 162
greater 1 72 167
assign 1 73 168
extractString 0 73 168
addValue 1 73 169
addValue 1 76 172
addValue 1 79 176
assign 1 82 183
sizeGet 0 82 183
assign 1 82 184
new 0 82 184
assign 1 82 185
greater 1 82 190
assign 1 83 191
extractString 0 83 191
addValue 1 83 192
return 1 85 194
return 1 0 197
return 1 0 200
assign 1 0 203
assign 1 0 207
return 1 0 211
return 1 0 214
assign 1 0 217
assign 1 0 221
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1151085267: return bem_deserializeClassNameGet_0();
case 721123821: return bem_tagGet_0();
case 19210432: return bem_iteratorGet_0();
case 1597530459: return bem_print_0();
case 559255035: return bem_fieldNamesGet_0();
case -860520942: return bem_toString_0();
case 1403473208: return bem_tmapGet_0();
case 216633460: return bem_serializeContents_0();
case 1291824271: return bem_echo_0();
case 595935693: return bem_create_0();
case -390286916: return bem_serializeToString_0();
case -1869924457: return bem_sourceFileNameGet_0();
case 270781002: return bem_new_0();
case -35110227: return bem_includeTokensGetDirect_0();
case -827080774: return bem_copy_0();
case -1156903676: return bem_serializationIteratorGet_0();
case 796975868: return bem_tmapGetDirect_0();
case -1123266766: return bem_classNameGet_0();
case -601453628: return bem_fieldIteratorGet_0();
case 348062600: return bem_includeTokensGet_0();
case 1562356496: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1284837261: return bem_tmapSetDirect_1(bevd_0);
case 610886167: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -323113819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2138090541: return bem_sameClass_1(bevd_0);
case -690535851: return bem_sameObject_1(bevd_0);
case 1803675158: return bem_tokenizeIterator_1(bevd_0);
case -499138365: return bem_otherClass_1(bevd_0);
case 2140620274: return bem_otherType_1(bevd_0);
case -696336738: return bem_equals_1(bevd_0);
case 1788911287: return bem_sameType_1(bevd_0);
case 1576777353: return bem_includeTokensSetDirect_1(bevd_0);
case -898978041: return bem_tokenize_1(bevd_0);
case -637072093: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1582378113: return bem_notEquals_1(bevd_0);
case -478520463: return bem_undef_1(bevd_0);
case -1930188924: return bem_addToken_1((BEC_2_4_6_TextString) bevd_0);
case 1265726567: return bem_includeTokensSet_1(bevd_0);
case -89866327: return bem_copyTo_1(bevd_0);
case -327732297: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -504986836: return bem_tokensStringSet_1((BEC_2_4_6_TextString) bevd_0);
case 1720726298: return bem_def_1(bevd_0);
case 2009082114: return bem_tmapSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -77252171: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 350317076: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1828646701: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1467842440: return bem_tokenizeIterator_2(bevd_0, bevd_1);
case -104691827: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -733779503: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1327820471: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 230846097: return bem_tokenize_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_4_9_TextTokenizer_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_9_TextTokenizer_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_9_TextTokenizer();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst = (BEC_2_4_9_TextTokenizer) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_type;
}
}
}
