namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_8_BuildNamePath : BEC_2_6_8_SystemBasePath {
public BEC_2_5_8_BuildNamePath() { }
static BEC_2_5_8_BuildNamePath() { }
private static byte[] becc_BEC_2_5_8_BuildNamePath_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_5_8_BuildNamePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_1 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_2 = {0x3A};
public static new BEC_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_inst;

public static new BET_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_type;

public BEC_2_4_6_TextString bevp_label;
public override BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_separator = bevt_0_ta_ph.bem_colonGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_2_ta_ph = null;
if (bevp_label == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 19*/ {
bevt_2_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_1_ta_ph = bevt_2_ta_ph.bem_lastGet_0();
return bevt_1_ta_ph;
} /* Line: 20*/
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_resolve_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_4_6_TextString bevl_oldpath = null;
BEC_2_4_6_TextString bevl_fstep = null;
BEC_2_5_4_BuildNode bevl_tunode = null;
BEC_2_6_8_SystemBasePath bevl_par = null;
BEC_2_6_8_SystemBasePath bevl_np2 = null;
BEC_2_6_8_SystemBasePath bevl_np = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
bevl_oldpath = bem_pathGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_8_BuildNamePath_bels_0));
bevt_1_ta_ph = bevl_oldpath.bem_equals_1(bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 28*/ {
return this;
} /* Line: 28*/
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_8_BuildNamePath_bels_1));
bevt_3_ta_ph = bevl_oldpath.bem_equals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 29*/ {
return this;
} /* Line: 29*/
bevl_fstep = bem_firstStepGet_0();
bevl_tunode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(1074329694);
bevt_6_ta_ph = bevl_tunode.bem_heldGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(-1787294269);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_5_ta_ph.bemd_1(-1267929220, bevl_fstep);
if (bevl_par == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 33*/ {
bevt_10_ta_ph = beva_node.bemd_0(-1251441948);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1443625619);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1787294269);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_8_ta_ph.bemd_1(-1267929220, bevl_fstep);
} /* Line: 34*/
if (bevl_par == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_14_ta_ph = bem_pathGet_0();
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_8_BuildNamePath_bels_2));
bevt_13_ta_ph = bevt_14_ta_ph.bem_has_1(bevt_15_ta_ph);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 36*/
 else /* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 36*/ {
bevl_np2 = (BEC_2_6_8_SystemBasePath) bem_deleteFirstStep_0();
bevl_np = (BEC_2_6_8_SystemBasePath) bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 39*/
bevl_clnode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(-928021507);
if (bevl_clnode == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_17_ta_ph = bevl_clnode.bem_heldGet_0();
bevt_17_ta_ph.bemd_1(960803922, this);
} /* Line: 43*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_labelGetDirect_0() {
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_label = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_label = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {14, 14, 15, 19, 19, 20, 20, 20, 23, 27, 28, 28, 28, 29, 29, 29, 30, 31, 32, 32, 32, 33, 33, 34, 34, 34, 34, 36, 36, 36, 36, 36, 36, 36, 0, 0, 0, 37, 38, 39, 41, 42, 42, 43, 43, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 20, 27, 32, 33, 34, 35, 37, 65, 66, 67, 69, 71, 72, 74, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 92, 97, 98, 99, 100, 101, 106, 107, 110, 114, 117, 118, 119, 121, 122, 127, 128, 129, 134, 137, 141};
/* BEGIN LINEINFO 
assign 1 14 18
new 0 14 18
assign 1 14 19
colonGet 0 14 19
fromString 1 15 20
assign 1 19 27
undef 1 19 32
assign 1 20 33
split 1 20 33
assign 1 20 34
lastGet 0 20 34
return 1 20 35
return 1 23 37
assign 1 27 65
pathGet 0 27 65
assign 1 28 66
new 0 28 66
assign 1 28 67
equals 1 28 67
return 1 28 69
assign 1 29 71
new 0 29 71
assign 1 29 72
equals 1 29 72
return 1 29 74
assign 1 30 76
firstStepGet 0 30 76
assign 1 31 77
transUnitGet 0 31 77
assign 1 32 78
heldGet 0 32 78
assign 1 32 79
aliasedGet 0 32 79
assign 1 32 80
get 1 32 80
assign 1 33 81
undef 1 33 86
assign 1 34 87
buildGet 0 34 87
assign 1 34 88
emitDataGet 0 34 88
assign 1 34 89
aliasedGet 0 34 89
assign 1 34 90
get 1 34 90
assign 1 36 92
def 1 36 97
assign 1 36 98
pathGet 0 36 98
assign 1 36 99
new 0 36 99
assign 1 36 100
has 1 36 100
assign 1 36 101
not 0 36 106
assign 1 0 107
assign 1 0 110
assign 1 0 114
assign 1 37 117
deleteFirstStep 0 37 117
assign 1 38 118
add 1 38 118
assign 1 39 119
pathGet 0 39 119
assign 1 41 121
classGet 0 41 121
assign 1 42 122
def 1 42 127
assign 1 43 128
heldGet 0 43 128
addUsed 1 43 129
return 1 0 134
assign 1 0 137
assign 1 0 141
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 597753697: return bem_pathGet_0();
case -1044758745: return bem_serializeToString_0();
case -1711670377: return bem_hashGet_0();
case 1003630403: return bem_labelGet_0();
case -1785724794: return bem_once_0();
case 2044767051: return bem_separatorGetDirect_0();
case -1480556491: return bem_toAny_0();
case 759496930: return bem_tagGet_0();
case 1365897346: return bem_serializationIteratorGet_0();
case -1894759916: return bem_makeNonAbsolute_0();
case -202912463: return bem_copy_0();
case -1349636521: return bem_firstStepGet_0();
case 965011138: return bem_pathGetDirect_0();
case 1359019369: return bem_stepListGet_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -1359614197: return bem_classNameGet_0();
case -652053502: return bem_fieldNamesGet_0();
case 2132420479: return bem_many_0();
case -1642361296: return bem_print_0();
case 944073339: return bem_fieldIteratorGet_0();
case 2064925791: return bem_echo_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 664337001: return bem_lastStepGet_0();
case 1161638424: return bem_new_0();
case 383112607: return bem_stepsGet_0();
case 350691792: return bem_toString_0();
case 168135582: return bem_create_0();
case 1869067527: return bem_labelGetDirect_0();
case -71162589: return bem_iteratorGet_0();
case 1932570604: return bem_isAbsoluteGet_0();
case 814334258: return bem_serializeContents_0();
case 360721884: return bem_makeAbsolute_0();
case -1760832906: return bem_separatorGet_0();
case -1281953360: return bem_deleteFirstStep_0();
case 730287248: return bem_parentGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1272019896: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -951966168: return bem_def_1(bevd_0);
case -1409612680: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -313885040: return bem_separatorSetDirect_1(bevd_0);
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1698647653: return bem_resolve_1(bevd_0);
case 370651212: return bem_labelSetDirect_1(bevd_0);
case -293837700: return bem_addSteps_1(bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case -1612594342: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -982552957: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case 1704964450: return bem_separatorSet_1(bevd_0);
case 1472627856: return bem_pathSetDirect_1(bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case 1847502032: return bem_addStep_1(bevd_0);
case -1134273475: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 130133381: return bem_pathSet_1(bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case -1236598895: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case 1688096367: return bem_add_1(bevd_0);
case -917821454: return bem_labelSet_1(bevd_0);
case -1829001662: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 668178337: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 816229455: return bem_addSteps_2(bevd_0, bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildNamePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_8_BuildNamePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildNamePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst = (BEC_2_5_8_BuildNamePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_type;
}
}
}
