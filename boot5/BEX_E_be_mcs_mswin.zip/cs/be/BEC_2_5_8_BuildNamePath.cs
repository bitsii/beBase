namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_8_BuildNamePath : BEC_2_6_8_SystemBasePath {
public BEC_2_5_8_BuildNamePath() { }
static BEC_2_5_8_BuildNamePath() { }
private static byte[] becc_BEC_2_5_8_BuildNamePath_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_5_8_BuildNamePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_0 = {0x73,0x65,0x6C,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_0, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_1 = {0x74,0x68,0x69,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_1, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_2 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_2, 1));
public static new BEC_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_inst;
public BEC_2_4_6_TextString bevp_label;
public override BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_separator = bevt_0_tmpany_phold.bem_colonGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
if (bevp_label == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 20 */ {
bevt_2_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_lastGet_0();
return bevt_1_tmpany_phold;
} /* Line: 21 */
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_resolve_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_4_6_TextString bevl_oldpath = null;
BEC_2_4_6_TextString bevl_fstep = null;
BEC_2_5_4_BuildNode bevl_tunode = null;
BEC_2_6_8_SystemBasePath bevl_par = null;
BEC_2_6_8_SystemBasePath bevl_np2 = null;
BEC_2_6_8_SystemBasePath bevl_np = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
bevl_oldpath = bem_pathGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_0;
bevt_1_tmpany_phold = bevl_oldpath.bem_equals_1(bevt_2_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 29 */ {
return this;
} /* Line: 29 */
bevt_4_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_1;
bevt_3_tmpany_phold = bevl_oldpath.bem_equals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 30 */ {
return this;
} /* Line: 30 */
bevl_fstep = bem_firstStepGet_0();
bevl_tunode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(102061193);
bevt_6_tmpany_phold = bevl_tunode.bem_heldGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(1464330518);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_5_tmpany_phold.bemd_1(340047415, bevl_fstep);
if (bevl_par == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevt_10_tmpany_phold = beva_node.bemd_0(-58429592);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-1875508755);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1464330518);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_8_tmpany_phold.bemd_1(340047415, bevl_fstep);
} /* Line: 35 */
if (bevl_par == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_14_tmpany_phold = bem_pathGet_0();
bevt_15_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_2;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_has_1(bevt_15_tmpany_phold);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 37 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 37 */ {
bevl_np2 = (BEC_2_6_8_SystemBasePath) bem_deleteFirstStep_0();
bevl_np = (BEC_2_6_8_SystemBasePath) bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 40 */
bevl_clnode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(1622972242);
if (bevl_clnode == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_17_tmpany_phold = bevl_clnode.bem_heldGet_0();
bevt_17_tmpany_phold.bemd_1(1813783372, this);
} /* Line: 44 */
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_label = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15, 15, 16, 20, 20, 21, 21, 21, 24, 28, 29, 29, 29, 30, 30, 30, 31, 32, 33, 33, 33, 34, 34, 35, 35, 35, 35, 37, 37, 37, 37, 37, 37, 37, 0, 0, 0, 38, 39, 40, 42, 43, 43, 44, 44, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 20, 27, 32, 33, 34, 35, 37, 65, 66, 67, 69, 71, 72, 74, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 92, 97, 98, 99, 100, 101, 106, 107, 110, 114, 117, 118, 119, 121, 122, 127, 128, 129, 134};
/* BEGIN LINEINFO 
assign 1 15 18
new 0 15 18
assign 1 15 19
colonGet 0 15 19
fromString 1 16 20
assign 1 20 27
undef 1 20 32
assign 1 21 33
split 1 21 33
assign 1 21 34
lastGet 0 21 34
return 1 21 35
return 1 24 37
assign 1 28 65
pathGet 0 28 65
assign 1 29 66
new 0 29 66
assign 1 29 67
equals 1 29 67
return 1 29 69
assign 1 30 71
new 0 30 71
assign 1 30 72
equals 1 30 72
return 1 30 74
assign 1 31 76
firstStepGet 0 31 76
assign 1 32 77
transUnitGet 0 32 77
assign 1 33 78
heldGet 0 33 78
assign 1 33 79
aliasedGet 0 33 79
assign 1 33 80
get 1 33 80
assign 1 34 81
undef 1 34 86
assign 1 35 87
buildGet 0 35 87
assign 1 35 88
emitDataGet 0 35 88
assign 1 35 89
aliasedGet 0 35 89
assign 1 35 90
get 1 35 90
assign 1 37 92
def 1 37 97
assign 1 37 98
pathGet 0 37 98
assign 1 37 99
new 0 37 99
assign 1 37 100
has 1 37 100
assign 1 37 101
not 0 37 106
assign 1 0 107
assign 1 0 110
assign 1 0 114
assign 1 38 117
deleteFirstStep 0 38 117
assign 1 39 118
add 1 39 118
assign 1 40 119
pathGet 0 40 119
assign 1 42 121
classGet 0 42 121
assign 1 43 122
def 1 43 127
assign 1 44 128
heldGet 0 44 128
addUsed 1 44 129
assign 1 0 134
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 2141550628: return bem_deserializeClassNameGet_0();
case 142206752: return bem_many_0();
case -833996675: return bem_makeAbsolute_0();
case 1278477757: return bem_serializeToString_0();
case -1152001976: return bem_copy_0();
case -827309928: return bem_labelGet_0();
case -1976290782: return bem_print_0();
case -80523520: return bem_separatorGet_0();
case 880152096: return bem_classNameGet_0();
case 2085674875: return bem_echo_0();
case -2091198124: return bem_tagGet_0();
case -2118736216: return bem_isAbsoluteGet_0();
case -2094276328: return bem_stepsGet_0();
case -364515046: return bem_fieldIteratorGet_0();
case 101584786: return bem_parentGet_0();
case -386323881: return bem_stepListGet_0();
case 752911959: return bem_hashGet_0();
case -2052611744: return bem_once_0();
case -1193265838: return bem_new_0();
case 1572979329: return bem_pathGet_0();
case 2098501683: return bem_create_0();
case -1519154062: return bem_deleteFirstStep_0();
case 1211836779: return bem_iteratorGet_0();
case -1639898262: return bem_lastStepGet_0();
case -326646035: return bem_toString_0();
case 444169984: return bem_sourceFileNameGet_0();
case -1888508563: return bem_serializationIteratorGet_0();
case 148127495: return bem_makeNonAbsolute_0();
case 1310164435: return bem_serializeContents_0();
case -1896601781: return bem_toAny_0();
case 1472585168: return bem_firstStepGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 607370643: return bem_undefined_1(bevd_0);
case 1048239710: return bem_sameClass_1(bevd_0);
case 1301000324: return bem_labelSet_1(bevd_0);
case 581673700: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 986477958: return bem_defined_1(bevd_0);
case 870656520: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 136677527: return bem_def_1(bevd_0);
case -1455609312: return bem_separatorSet_1(bevd_0);
case 619377888: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1948085050: return bem_undef_1(bevd_0);
case 1511550176: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1773439641: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 45057151: return bem_equals_1(bevd_0);
case 1268433926: return bem_otherClass_1(bevd_0);
case -763894058: return bem_addStep_1(bevd_0);
case 496808651: return bem_sameObject_1(bevd_0);
case -1191000829: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1996679709: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 1579053823: return bem_sameType_1(bevd_0);
case 675464916: return bem_addSteps_1(bevd_0);
case 930180418: return bem_copyTo_1(bevd_0);
case -1123057014: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -1321282362: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -785327205: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2139724842: return bem_pathSet_1(bevd_0);
case 1609880147: return bem_resolve_1(bevd_0);
case -933769754: return bem_add_1(bevd_0);
case 275457317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1990827367: return bem_notEquals_1(bevd_0);
case -1866601742: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 686788947: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -473486005: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1768228505: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 659934822: return bem_addSteps_2(bevd_0, bevd_1);
case -1400688487: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 253281852: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1848289028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 893523384: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1481064275: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildNamePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_8_BuildNamePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildNamePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst = (BEC_2_5_8_BuildNamePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst;
}
}
}
