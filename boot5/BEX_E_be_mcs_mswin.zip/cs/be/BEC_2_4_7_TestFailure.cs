namespace be {
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure : BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
static BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static new BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
base.bem_new_1(beva_descr);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15};
public static new int[] bevs_smnlec
 = new int[] {13};
/* BEGIN LINEINFO 
new 1 15 13
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2035483001: return bem_lineNumberGet_0();
case -1780409598: return bem_framesGetDirect_0();
case 2047894513: return bem_lineNumberGetDirect_0();
case 885190018: return bem_serializationIteratorGet_0();
case -1460138897: return bem_print_0();
case 1242687598: return bem_langGet_0();
case -1344851318: return bem_getFrameText_0();
case 411622802: return bem_descriptionGet_0();
case 1743657368: return bem_once_0();
case -521133624: return bem_emitLangGetDirect_0();
case 333832460: return bem_vvGet_0();
case 1443037619: return bem_new_0();
case -357847357: return bem_langGetDirect_0();
case -167133301: return bem_fieldIteratorGet_0();
case 375625109: return bem_copy_0();
case 928308283: return bem_fileNameGetDirect_0();
case 932329411: return bem_descriptionGetDirect_0();
case 1649770762: return bem_serializeContents_0();
case 641617863: return bem_serializeToString_0();
case -575216772: return bem_hashGet_0();
case -1415527217: return bem_translateEmittedException_0();
case 1357107465: return bem_many_0();
case -408640158: return bem_translatedGetDirect_0();
case -1111980982: return bem_toString_0();
case -1062508492: return bem_toAny_0();
case 581459734: return bem_framesTextGetDirect_0();
case -1885971140: return bem_methodNameGet_0();
case 699029632: return bem_klassNameGetDirect_0();
case -974870063: return bem_framesTextGet_0();
case -954029510: return bem_tagGet_0();
case -1824151510: return bem_sourceFileNameGet_0();
case -322766620: return bem_framesGet_0();
case 48499556: return bem_translateEmittedExceptionInner_0();
case 439809510: return bem_klassNameGet_0();
case -1477321659: return bem_create_0();
case -2061644084: return bem_echo_0();
case 434043839: return bem_fileNameGet_0();
case 1303816937: return bem_classNameGet_0();
case 700847419: return bem_iteratorGet_0();
case -1820908324: return bem_methodNameGetDirect_0();
case -82374043: return bem_emitLangGet_0();
case 1142981090: return bem_translatedGet_0();
case -646910688: return bem_vvGetDirect_0();
case -2071582224: return bem_fieldNamesGet_0();
case -1381809993: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2072486003: return bem_translatedSet_1(bevd_0);
case 1214940220: return bem_fileNameSet_1(bevd_0);
case -2131382488: return bem_framesSetDirect_1(bevd_0);
case -961773673: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 997965949: return bem_sameClass_1(bevd_0);
case -929117450: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -2012960734: return bem_otherType_1(bevd_0);
case -635085791: return bem_emitLangSet_1(bevd_0);
case -446295564: return bem_new_1(bevd_0);
case -124594925: return bem_equals_1(bevd_0);
case 2107583021: return bem_descriptionSet_1(bevd_0);
case -240276616: return bem_def_1(bevd_0);
case 648405638: return bem_vvSetDirect_1(bevd_0);
case 1108385516: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1171201188: return bem_sameType_1(bevd_0);
case 2092977139: return bem_vvSet_1(bevd_0);
case 1843091865: return bem_notEquals_1(bevd_0);
case -536053857: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 714291304: return bem_langSetDirect_1(bevd_0);
case -1888476599: return bem_descriptionSetDirect_1(bevd_0);
case 912665444: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 746855111: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -158486422: return bem_undef_1(bevd_0);
case 611988319: return bem_klassNameSetDirect_1(bevd_0);
case -618518858: return bem_lineNumberSetDirect_1(bevd_0);
case -2012223833: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1484251034: return bem_methodNameSet_1(bevd_0);
case 101857685: return bem_fileNameSetDirect_1(bevd_0);
case 514133408: return bem_klassNameSet_1(bevd_0);
case 754249569: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 445868724: return bem_langSet_1(bevd_0);
case 1650435450: return bem_undefined_1(bevd_0);
case -746507210: return bem_emitLangSetDirect_1(bevd_0);
case 60503604: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 829192566: return bem_otherClass_1(bevd_0);
case -860634984: return bem_sameObject_1(bevd_0);
case 1671706278: return bem_translatedSetDirect_1(bevd_0);
case 1434062431: return bem_defined_1(bevd_0);
case -2104043277: return bem_framesTextSetDirect_1(bevd_0);
case 1163259141: return bem_framesSet_1(bevd_0);
case 2049758437: return bem_lineNumberSet_1(bevd_0);
case 133815301: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1435943877: return bem_framesTextSet_1(bevd_0);
case -9685782: return bem_methodNameSetDirect_1(bevd_0);
case 1081114988: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1783314567: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -749136313: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1365145554: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1346654676: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1957573480: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039992278: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1347676005: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 701178023: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TestFailure();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
}
