namespace be {
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure : BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
static BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static new BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
base.bem_new_1(beva_descr);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15};
public static new int[] bevs_smnlec
 = new int[] {13};
/* BEGIN LINEINFO 
new 1 15 13
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1624944174: return bem_serializationIteratorGet_0();
case 1754519730: return bem_classNameGet_0();
case 441576374: return bem_vvGet_0();
case 889323737: return bem_translateEmittedException_0();
case 20258652: return bem_framesGet_0();
case -1515030964: return bem_framesTextGet_0();
case -2038987715: return bem_translatedGet_0();
case 1099128486: return bem_echo_0();
case 342664202: return bem_serializeContents_0();
case -1808414632: return bem_methodNameGet_0();
case -1847076103: return bem_translateEmittedExceptionInner_0();
case -1920078604: return bem_sourceFileNameGet_0();
case -1248348608: return bem_many_0();
case 1334927002: return bem_create_0();
case -914943787: return bem_toString_0();
case 1596390344: return bem_emitLangGet_0();
case 1280569362: return bem_fieldIteratorGet_0();
case -1117992648: return bem_hashGet_0();
case 93356535: return bem_deserializeClassNameGet_0();
case 2123119272: return bem_getFrameText_0();
case -1942605555: return bem_toAny_0();
case -152803575: return bem_tagGet_0();
case 105646630: return bem_lineNumberGet_0();
case 277625329: return bem_klassNameGet_0();
case -541227487: return bem_new_0();
case 38289726: return bem_print_0();
case -1367316623: return bem_fileNameGet_0();
case -1618533783: return bem_serializeToString_0();
case -929672993: return bem_descriptionGet_0();
case -1749035302: return bem_copy_0();
case -1620303979: return bem_once_0();
case 385489744: return bem_iteratorGet_0();
case -365467610: return bem_langGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1766919230: return bem_translatedSet_1(bevd_0);
case 1669123607: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1553866014: return bem_sameClass_1(bevd_0);
case -579664236: return bem_klassNameSet_1(bevd_0);
case 51761249: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1052704201: return bem_new_1(bevd_0);
case -1001167064: return bem_def_1(bevd_0);
case -340769287: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -900790842: return bem_defined_1(bevd_0);
case -929975460: return bem_equals_1(bevd_0);
case -1975825183: return bem_sameObject_1(bevd_0);
case -575269362: return bem_langSet_1(bevd_0);
case 400272871: return bem_vvSet_1(bevd_0);
case 880660795: return bem_descriptionSet_1(bevd_0);
case 589015080: return bem_otherType_1(bevd_0);
case -147916244: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -991162341: return bem_lineNumberSet_1(bevd_0);
case -655089260: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -2057956567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -610417430: return bem_methodNameSet_1(bevd_0);
case 1356842566: return bem_otherClass_1(bevd_0);
case 408844820: return bem_undefined_1(bevd_0);
case -1667048917: return bem_emitLangSet_1(bevd_0);
case 960625295: return bem_notEquals_1(bevd_0);
case 537379230: return bem_framesTextSet_1(bevd_0);
case -406377870: return bem_copyTo_1(bevd_0);
case -689030370: return bem_fileNameSet_1(bevd_0);
case 1417404860: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2087765200: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 805905187: return bem_framesSet_1(bevd_0);
case -445350097: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 327551615: return bem_undef_1(bevd_0);
case 32553456: return bem_sameType_1(bevd_0);
case 240793126: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1615755198: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 914119897: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1722418125: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1183458920: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -294037420: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1794036335: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1344222461: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1453170069: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TestFailure();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
}
