namespace be {
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure : BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
static BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static new BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
base.bem_new_1(beva_descr);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {14};
public static new int[] bevs_smnlec
 = new int[] {13};
/* BEGIN LINEINFO 
new 1 14 13
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1882778775: return bem_fieldIteratorGet_0();
case 459169784: return bem_getFrameText_0();
case 48684490: return bem_echo_0();
case 1865983825: return bem_fieldNamesGet_0();
case 2017345633: return bem_copy_0();
case -160735352: return bem_once_0();
case -1180313498: return bem_fileNameGet_0();
case 179975357: return bem_lineNumberGetDirect_0();
case -126382709: return bem_langGetDirect_0();
case -622712732: return bem_emitLangGet_0();
case 876495198: return bem_descriptionGetDirect_0();
case -1451048410: return bem_new_0();
case -1664773818: return bem_emitLangGetDirect_0();
case 1543164749: return bem_langGet_0();
case 872708376: return bem_toAny_0();
case 1200056076: return bem_serializationIteratorGet_0();
case 1934519472: return bem_lineNumberGet_0();
case -1504673330: return bem_methodNameGet_0();
case 343696165: return bem_translatedGetDirect_0();
case -1229803830: return bem_deserializeClassNameGet_0();
case -166013833: return bem_tagGet_0();
case 1239608753: return bem_translateEmittedException_0();
case -1077005588: return bem_vvGetDirect_0();
case 260040038: return bem_translatedGet_0();
case -206043242: return bem_many_0();
case -1533701006: return bem_serializeContents_0();
case 1330976730: return bem_hashGet_0();
case -1268263069: return bem_framesGetDirect_0();
case 907276784: return bem_serializeToString_0();
case -23156146: return bem_klassNameGet_0();
case -1990292643: return bem_toString_0();
case -1390639259: return bem_translateEmittedExceptionInner_0();
case -1109387075: return bem_fileNameGetDirect_0();
case 1463127894: return bem_framesGet_0();
case -1472459399: return bem_framesTextGet_0();
case 1674575712: return bem_classNameGet_0();
case 112050384: return bem_vvGet_0();
case -1442438979: return bem_framesTextGetDirect_0();
case 437089080: return bem_print_0();
case -1419115955: return bem_create_0();
case 1208354139: return bem_sourceFileNameGet_0();
case 350795724: return bem_klassNameGetDirect_0();
case 633864588: return bem_descriptionGet_0();
case 1376770497: return bem_methodNameGetDirect_0();
case -2014542803: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 161134859: return bem_defined_1(bevd_0);
case 1755787384: return bem_descriptionSet_1(bevd_0);
case -1709624410: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1228864806: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 2122176784: return bem_undef_1(bevd_0);
case -1299097813: return bem_framesTextSetDirect_1(bevd_0);
case -1980439329: return bem_translatedSet_1(bevd_0);
case -15299157: return bem_vvSetDirect_1(bevd_0);
case -1352364484: return bem_methodNameSet_1(bevd_0);
case 170216407: return bem_copyTo_1(bevd_0);
case 1920998617: return bem_sameObject_1(bevd_0);
case 625481528: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1484567824: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 356373991: return bem_framesSetDirect_1(bevd_0);
case 1293492955: return bem_lineNumberSetDirect_1(bevd_0);
case 189662700: return bem_framesSet_1(bevd_0);
case 511281680: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -279352105: return bem_undefined_1(bevd_0);
case 1596863802: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1517637963: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1822027791: return bem_otherClass_1(bevd_0);
case -1304242074: return bem_framesTextSet_1(bevd_0);
case 1561328648: return bem_otherType_1(bevd_0);
case 285580831: return bem_emitLangSet_1(bevd_0);
case 1020764092: return bem_translatedSetDirect_1(bevd_0);
case 354557818: return bem_equals_1(bevd_0);
case -400840176: return bem_langSetDirect_1(bevd_0);
case -733439371: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1290734211: return bem_descriptionSetDirect_1(bevd_0);
case -185383596: return bem_sameType_1(bevd_0);
case 1917605954: return bem_fileNameSetDirect_1(bevd_0);
case 584123032: return bem_def_1(bevd_0);
case 604889129: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 476153223: return bem_klassNameSetDirect_1(bevd_0);
case -434040592: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -970017727: return bem_emitLangSetDirect_1(bevd_0);
case 251986081: return bem_lineNumberSet_1(bevd_0);
case 1501365601: return bem_fileNameSet_1(bevd_0);
case 1590457361: return bem_vvSet_1(bevd_0);
case -298642428: return bem_langSet_1(bevd_0);
case -1364570455: return bem_methodNameSetDirect_1(bevd_0);
case 909810346: return bem_sameClass_1(bevd_0);
case -840953319: return bem_notEquals_1(bevd_0);
case 228067749: return bem_new_1(bevd_0);
case -487784775: return bem_klassNameSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1467883232: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 465709808: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 936076332: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -758649425: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 105253121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -29810702: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 175222937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 138973418: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TestFailure();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
}
