namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_3_6_6_4_SystemThreadLock : BEC_2_6_6_SystemObject {
public BEC_3_6_6_4_SystemThreadLock() { }
static BEC_3_6_6_4_SystemThreadLock() { }
private static byte[] becc_BEC_3_6_6_4_SystemThreadLock_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4C,0x6F,0x63,0x6B};
private static byte[] becc_BEC_3_6_6_4_SystemThreadLock_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_4_SystemThreadLock bece_BEC_3_6_6_4_SystemThreadLock_bevs_inst;

public static new BET_3_6_6_4_SystemThreadLock bece_BEC_3_6_6_4_SystemThreadLock_bevs_type;

public BEC_2_5_4_LogicBool bem_lock_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

    Monitor.Enter(this); //yes, monitor is reentrant
    bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_unlock_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

    Monitor.Exit(this);
    bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {849, 849, 868, 868};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 28, 29};
/* BEGIN LINEINFO 
assign 1 849 21
new 0 849 21
return 1 849 22
assign 1 868 28
new 0 868 28
return 1 868 29
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 605655591: return bem_sourceFileNameGet_0();
case 1267812147: return bem_classNameGet_0();
case 702246847: return bem_print_0();
case -364249863: return bem_serializeToString_0();
case -1353172126: return bem_toString_0();
case 1966713191: return bem_deserializeClassNameGet_0();
case -1655660203: return bem_hashGet_0();
case -500248069: return bem_serializationIteratorGet_0();
case 1581692921: return bem_toAny_0();
case -1572010998: return bem_copy_0();
case 1530555194: return bem_serializeContents_0();
case 812685421: return bem_iteratorGet_0();
case 1627251340: return bem_unlock_0();
case -1000018882: return bem_create_0();
case -65082849: return bem_once_0();
case -1907635971: return bem_tagGet_0();
case 67229566: return bem_lock_0();
case -106257945: return bem_fieldNamesGet_0();
case -1577817259: return bem_echo_0();
case 1550760607: return bem_fieldIteratorGet_0();
case -927090833: return bem_new_0();
case -1007878556: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -481756547: return bem_undef_1(bevd_0);
case 140166424: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -58459221: return bem_sameClass_1(bevd_0);
case 150021405: return bem_otherClass_1(bevd_0);
case 297381803: return bem_def_1(bevd_0);
case -1862075337: return bem_copyTo_1(bevd_0);
case -759946269: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1471457238: return bem_sameObject_1(bevd_0);
case -886218051: return bem_equals_1(bevd_0);
case -1556952447: return bem_defined_1(bevd_0);
case 2141774895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1953776597: return bem_sameType_1(bevd_0);
case -227529285: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1673385175: return bem_notEquals_1(bevd_0);
case 1244819809: return bem_undefined_1(bevd_0);
case 726015407: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1722905349: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -967702518: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -427898914: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 414161005: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 611344245: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -157052200: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1970963739: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_6_6_4_SystemThreadLock_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_4_SystemThreadLock_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_4_SystemThreadLock();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_4_SystemThreadLock.bece_BEC_3_6_6_4_SystemThreadLock_bevs_inst = (BEC_3_6_6_4_SystemThreadLock) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_4_SystemThreadLock.bece_BEC_3_6_6_4_SystemThreadLock_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_4_SystemThreadLock.bece_BEC_3_6_6_4_SystemThreadLock_bevs_type;
}
}
}
