namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_3_2_4_12_IOFileNamedReaders : BEC_2_6_6_SystemObject {
public BEC_3_2_4_12_IOFileNamedReaders() { }
static BEC_3_2_4_12_IOFileNamedReaders() { }
private static byte[] becc_BEC_3_2_4_12_IOFileNamedReaders_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x52,0x65,0x61,0x64,0x65,0x72,0x73};
private static byte[] becc_BEC_3_2_4_12_IOFileNamedReaders_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_3_2_4_12_IOFileNamedReaders bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst;
public BEC_3_2_4_6_IOFileReader bevp_input;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedReaders bem_default_0() {
BEC_4_2_4_6_5_IOFileReaderStdin bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_4_2_4_6_5_IOFileReaderStdin) BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst.bem_new_0();
bem_inputSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedReaders bem_inputSet_1(BEC_3_2_4_6_IOFileReader beva__input) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_input = beva__input;
bevt_0_tmpany_phold = bevp_input.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 553 */ {
bevp_input.bem_open_0();
} /* Line: 554 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_inputGet_0() {
return bevp_input;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {548, 548, 552, 553, 554, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 24, 25, 27, 32};
/* BEGIN LINEINFO 
assign 1 548 18
new 0 548 18
inputSet 1 548 19
assign 1 552 24
assign 1 553 25
isClosedGet 0 553 25
open 0 554 27
return 1 0 32
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 747222940: return bem_serializationIteratorGet_0();
case 774868823: return bem_many_0();
case 138118576: return bem_classNameGet_0();
case 173912112: return bem_iteratorGet_0();
case 1826655669: return bem_echo_0();
case 591133328: return bem_once_0();
case 169016919: return bem_deserializeClassNameGet_0();
case 156988171: return bem_toAny_0();
case 1030306077: return bem_hashGet_0();
case -751534347: return bem_tagGet_0();
case 441873246: return bem_fieldIteratorGet_0();
case 1116610611: return bem_inputGet_0();
case 1804394239: return bem_create_0();
case 86234609: return bem_print_0();
case 605463834: return bem_sourceFileNameGet_0();
case 1651099395: return bem_copy_0();
case 364146106: return bem_toString_0();
case -814108194: return bem_default_0();
case -1694865880: return bem_serializeToString_0();
case 1232567589: return bem_new_0();
case 1335363828: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -293276429: return bem_undefined_1(bevd_0);
case 143426895: return bem_undef_1(bevd_0);
case 233607642: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 280312858: return bem_sameObject_1(bevd_0);
case -66688367: return bem_sameClass_1(bevd_0);
case -2077086955: return bem_sameType_1(bevd_0);
case -548232463: return bem_copyTo_1(bevd_0);
case -1790149278: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1049342566: return bem_equals_1(bevd_0);
case 1022281941: return bem_defined_1(bevd_0);
case 818668120: return bem_def_1(bevd_0);
case 1388122193: return bem_otherClass_1(bevd_0);
case -956577031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1209387497: return bem_otherType_1(bevd_0);
case 1175927163: return bem_inputSet_1((BEC_3_2_4_6_IOFileReader) bevd_0);
case -729372880: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2078921482: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -936134816: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -265807180: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1675250987: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1991243589: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2096067718: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2037027110: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 808469705: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(20, becc_BEC_3_2_4_12_IOFileNamedReaders_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_12_IOFileNamedReaders_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_12_IOFileNamedReaders();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst = (BEC_3_2_4_12_IOFileNamedReaders) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst;
}
}
}
