namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_2_4_IOFile : BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOFile() { }
static BEC_2_2_4_IOFile() { }
private static byte[] becc_BEC_2_2_4_IOFile_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_2_4_IOFile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_inst;

public static new BET_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_2_6_6_SystemObject bevp_reader;
public BEC_2_6_6_SystemObject bevp_writer;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_new_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_apNew_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__path) {
bem_pathSet_1(beva__path);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_readerGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_reader == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 58*/ {
bevt_1_ta_ph = bevp_path.bem_toString_0();
bevp_reader = (new BEC_3_2_4_6_IOFileReader()).bem_new_1(bevt_1_ta_ph);
} /* Line: 59*/
return bevp_reader;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_writerGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_writer == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 65*/ {
bevt_1_ta_ph = bevp_path.bem_toString_0();
bevp_writer = (new BEC_3_2_4_6_IOFileWriter()).bem_new_1(bevt_1_ta_ph);
} /* Line: 66*/
return bevp_writer;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_delete_0() {
BEC_2_6_6_SystemObject bevl_llpath = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = bem_existsGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 82*/ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          File.Delete(bevls_path);
          } /* Line: 108*/
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_copyFile_1(BEC_2_6_6_SystemObject beva_other) {
BEC_3_2_4_6_IOFileWriter bevl_outw = null;
BEC_3_2_4_6_IOFileReader bevl_inr = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_other.bemd_0(-438348331);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(1043033657);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(2033713911);
bevt_0_ta_ph.bemd_0(114382068);
bevt_3_ta_ph = beva_other.bemd_0(2105096063);
bevl_outw = (BEC_3_2_4_6_IOFileWriter) bevt_3_ta_ph.bemd_0(-1086290012);
bevt_4_ta_ph = bem_readerGet_0();
bevl_inr = (BEC_3_2_4_6_IOFileReader) bevt_4_ta_ph.bemd_0(-1086290012);
bevl_inr.bem_copyData_1(bevl_outw);
bevl_inr.bem_close_0();
bevl_outw.bem_close_0();
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_mkdirs_0() {
bem_makeDirs_0();
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_mkdir_0() {
bem_makeDirs_0();
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_makeDirs_0() {
BEC_2_4_6_TextString bevl_frs = null;
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_5_4_LogicBool bevl_t = null;
BEC_2_6_6_SystemObject bevl_strn = null;
BEC_2_6_6_SystemObject bevl_parentpath = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevl_frs = bevp_path.bem_toString_0();
bevl_r = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_t = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_strn = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevp_path.bem_toString_0();
bevt_3_ta_ph = bevl_strn.bemd_0(-1783936683);
bevt_1_ta_ph = bevt_2_ta_ph.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 150*/ {
bevt_5_ta_ph = bem_existsGet_0();
if (bevt_5_ta_ph.bevi_bool) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 150*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 150*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 150*/
 else /* Line: 150*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 150*/ {
bevl_parentpath = bevp_path.bem_parentGet_0();
bevt_6_ta_ph = bevp_path.bem_equals_1(bevl_parentpath);
if (bevt_6_ta_ph.bevi_bool)/* Line: 152*/ {
return this;
} /* Line: 154*/
bevt_7_ta_ph = bevl_parentpath.bemd_0(2033713911);
bevt_7_ta_ph.bemd_0(114382068);

         Directory.CreateDirectory(
         System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int)
         );
         /* Line: 185*/ {
} /* Line: 186*/
} /* Line: 195*/
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isDirectoryGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isDirGet_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_lastUpdatedGet_0() {
BEC_2_4_8_TimeInterval bevl_lu = null;
bevl_lu = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();

        string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
        long ctm = (long) (File.GetLastWriteTimeUtc(bevls_path) - BEC_2_4_8_TimeInterval.epochStart).TotalMilliseconds;
        bevl_lu.bevp_secs.bevi_int = (int) (ctm / 1000);
        bevl_lu.bevp_millis.bevi_int = (int) (ctm % 1000);
        return bevl_lu;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_lastUpdatedSet_1(BEC_2_4_8_TimeInterval beva_lu) {

        string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
        DateTime ts = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        ts = ts.AddSeconds(beva_lu.bevp_secs.bevi_int);
        ts = ts.AddMilliseconds(beva_lu.bevp_millis.bevi_int);
        File.SetLastWriteTimeUtc(bevls_path, ts);
        return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isDirGet_0() {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_ta_ph = bem_existsGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 274*/ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          if (Directory.Exists(bevls_path)) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 307*/
return bevl_result;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isFileGet_0() {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_ta_ph = bem_existsGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 331*/ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          if (File.Exists(bevls_path)) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 364*/
return bevl_result;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_makeFile_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_0_ta_ph = bem_writerGet_0();
bevt_0_ta_ph.bemd_0(-1086290012);
bevt_1_ta_ph = bem_writerGet_0();
bevt_1_ta_ph.bemd_0(-910720573);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_contentsGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_existsGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 383*/ {
return null;
} /* Line: 384*/
bevt_2_ta_ph = bem_contentsNoCheckGet_0();
return bevt_2_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_contentsNoCheckGet_0() {
BEC_2_4_6_TextString bevl_ps = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
/* Line: 400*/ {
bevl_r = bem_readerGet_0();
bevl_r.bemd_0(-1086290012);
bevl_res = (BEC_2_4_6_TextString) bevl_r.bemd_0(-195620474);
bevl_r.bemd_0(-910720573);
} /* Line: 404*/
return bevl_res;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_contentsSet_1(BEC_2_4_6_TextString beva_contents) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_2_4_IOFile bevt_2_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_3_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
bevt_4_ta_ph = bem_pathGet_0();
bevt_3_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_4_ta_ph.bem_parentGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_fileGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_existsGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 410*/ {
bevt_7_ta_ph = bem_pathGet_0();
bevt_6_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_7_ta_ph.bem_parentGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_fileGet_0();
bevt_5_ta_ph.bem_makeDirs_0();
} /* Line: 411*/
bem_contentsNoCheckSet_1(beva_contents);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_contentsNoCheckSet_1(BEC_2_4_6_TextString beva_contents) {
BEC_2_4_6_TextString bevl_ps = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_6_6_SystemObject bevl_w = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
/* Line: 426*/ {
bevl_w = bem_writerGet_0();
bevl_w.bemd_0(-1086290012);
bevl_w.bemd_1(-1179440907, beva_contents);
bevl_w.bemd_0(-910720573);
} /* Line: 430*/
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_sz = null;
bevl_sz = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return bevl_sz;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_existsGet_0() {
BEC_2_5_4_LogicBool bevl_tvala = null;
BEC_2_6_6_SystemObject bevl_mpath = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevl_tvala = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_mpath = bevp_path.bem_toString_0();

      string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
      if (File.Exists(bevls_path) || Directory.Exists(bevls_path)) {
        bevl_tvala = be.BECS_Runtime.boolTrue;
      }
      /* Line: 482*/ {
} /* Line: 483*/
return bevl_tvala;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_absPathGet_0() {
BEC_3_2_4_4_IOFilePath bevl_absp = null;
BEC_2_4_6_TextString bevl_abstr = null;
/* Line: 522*/ {
} /* Line: 523*/
/* Line: 531*/ {
bevl_abstr = bevp_path.bem_pathGet_0();
} /* Line: 532*/
bevl_absp = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_abstr);
return bevl_absp;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_close_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (bevp_reader == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 539*/ {
bevp_reader.bemd_0(-910720573);
} /* Line: 540*/
if (bevp_writer == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 542*/ {
bevp_writer.bemd_0(-910720573);
} /* Line: 543*/
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_2_4_17_IOFileDirectoryIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_3_2_4_17_IOFileDirectoryIterator) (new BEC_3_2_4_17_IOFileDirectoryIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readerGetDirect_0() {
return bevp_reader;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_reader = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_readerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_reader = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writerGetDirect_0() {
return bevp_writer;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_writerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_writer = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_writerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_writer = bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {46, 46, 50, 50, 54, 58, 58, 59, 59, 61, 65, 65, 66, 66, 68, 82, 121, 121, 121, 121, 122, 122, 123, 123, 124, 125, 126, 127, 127, 132, 135, 146, 147, 148, 149, 150, 150, 150, 150, 150, 150, 0, 0, 0, 151, 152, 154, 156, 156, 212, 212, 217, 236, 272, 273, 274, 317, 329, 330, 331, 374, 378, 378, 379, 379, 383, 383, 383, 384, 386, 386, 401, 402, 403, 404, 406, 410, 410, 410, 410, 410, 410, 411, 411, 411, 411, 413, 427, 428, 429, 430, 436, 443, 455, 456, 514, 532, 534, 535, 539, 539, 540, 542, 542, 543, 548, 548, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {28, 29, 34, 35, 39, 45, 50, 51, 52, 54, 59, 64, 65, 66, 68, 76, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 108, 112, 132, 133, 134, 135, 136, 137, 138, 140, 141, 146, 147, 150, 154, 157, 158, 160, 162, 163, 175, 176, 180, 186, 201, 202, 203, 211, 217, 218, 219, 227, 232, 233, 234, 235, 242, 243, 248, 249, 251, 252, 261, 262, 263, 264, 266, 277, 278, 279, 280, 281, 286, 287, 288, 289, 290, 292, 304, 305, 306, 307, 313, 314, 322, 323, 331, 339, 341, 342, 347, 352, 353, 355, 360, 361, 367, 368, 371, 374, 377, 381, 385, 388, 392, 396, 399, 403};
/* BEGIN LINEINFO 
assign 1 46 28
new 1 46 28
pathSet 1 46 29
assign 1 50 34
apNew 1 50 34
pathSet 1 50 35
pathSet 1 54 39
assign 1 58 45
undef 1 58 50
assign 1 59 51
toString 0 59 51
assign 1 59 52
new 1 59 52
return 1 61 54
assign 1 65 59
undef 1 65 64
assign 1 66 65
toString 0 66 65
assign 1 66 66
new 1 66 66
return 1 68 68
assign 1 82 76
existsGet 0 82 76
assign 1 121 93
pathGet 0 121 93
assign 1 121 94
parentGet 0 121 94
assign 1 121 95
fileGet 0 121 95
makeDirs 0 121 96
assign 1 122 97
writerGet 0 122 97
assign 1 122 98
open 0 122 98
assign 1 123 99
readerGet 0 123 99
assign 1 123 100
open 0 123 100
copyData 1 124 101
close 0 125 102
close 0 126 103
assign 1 127 104
new 0 127 104
return 1 127 105
makeDirs 0 132 108
makeDirs 0 135 112
assign 1 146 132
toString 0 146 132
assign 1 147 133
new 0 147 133
assign 1 148 134
new 0 148 134
assign 1 149 135
new 0 149 135
assign 1 150 136
toString 0 150 136
assign 1 150 137
emptyGet 0 150 137
assign 1 150 138
notEquals 1 150 138
assign 1 150 140
existsGet 0 150 140
assign 1 150 141
not 0 150 146
assign 1 0 147
assign 1 0 150
assign 1 0 154
assign 1 151 157
parentGet 0 151 157
assign 1 152 158
equals 1 152 158
return 1 154 160
assign 1 156 162
fileGet 0 156 162
makeDirs 0 156 163
assign 1 212 175
isDirGet 0 212 175
return 1 212 176
assign 1 217 180
new 0 217 180
return 1 236 186
assign 1 272 201
new 0 272 201
assign 1 273 202
toString 0 273 202
assign 1 274 203
existsGet 0 274 203
return 1 317 211
assign 1 329 217
new 0 329 217
assign 1 330 218
toString 0 330 218
assign 1 331 219
existsGet 0 331 219
return 1 374 227
assign 1 378 232
writerGet 0 378 232
open 0 378 233
assign 1 379 234
writerGet 0 379 234
close 0 379 235
assign 1 383 242
existsGet 0 383 242
assign 1 383 243
not 0 383 248
return 1 384 249
assign 1 386 251
contentsNoCheckGet 0 386 251
return 1 386 252
assign 1 401 261
readerGet 0 401 261
open 0 402 262
assign 1 403 263
readString 0 403 263
close 0 404 264
return 1 406 266
assign 1 410 277
pathGet 0 410 277
assign 1 410 278
parentGet 0 410 278
assign 1 410 279
fileGet 0 410 279
assign 1 410 280
existsGet 0 410 280
assign 1 410 281
not 0 410 286
assign 1 411 287
pathGet 0 411 287
assign 1 411 288
parentGet 0 411 288
assign 1 411 289
fileGet 0 411 289
makeDirs 0 411 290
contentsNoCheckSet 1 413 292
assign 1 427 304
writerGet 0 427 304
open 0 428 305
write 1 429 306
close 0 430 307
assign 1 436 313
new 0 436 313
return 1 443 314
assign 1 455 322
new 0 455 322
assign 1 456 323
toString 0 456 323
return 1 514 331
assign 1 532 339
pathGet 0 532 339
assign 1 534 341
apNew 1 534 341
return 1 535 342
assign 1 539 347
def 1 539 352
close 0 540 353
assign 1 542 355
def 1 542 360
close 0 543 361
assign 1 548 367
new 1 548 367
return 1 548 368
return 1 0 371
return 1 0 374
assign 1 0 377
assign 1 0 381
return 1 0 385
assign 1 0 388
assign 1 0 392
return 1 0 396
assign 1 0 399
assign 1 0 403
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1123266766: return bem_classNameGet_0();
case -438348331: return bem_pathGet_0();
case -1860917564: return bem_contentsNoCheckGet_0();
case 1803937974: return bem_mkdir_0();
case -601453628: return bem_fieldIteratorGet_0();
case 19210432: return bem_iteratorGet_0();
case -390286916: return bem_serializeToString_0();
case 865391546: return bem_mkdirs_0();
case -817345474: return bem_readerGetDirect_0();
case 270781002: return bem_new_0();
case 114382068: return bem_makeDirs_0();
case 216633460: return bem_serializeContents_0();
case -860520942: return bem_toString_0();
case 1500987730: return bem_existsGet_0();
case 1039261475: return bem_absPathGet_0();
case 559255035: return bem_fieldNamesGet_0();
case 1476015508: return bem_isDirGet_0();
case -1156903676: return bem_serializationIteratorGet_0();
case 2007660129: return bem_lastUpdatedGet_0();
case -1869924457: return bem_sourceFileNameGet_0();
case -1514270321: return bem_contentsGet_0();
case -1068304037: return bem_readerGet_0();
case -1100078479: return bem_pathGetDirect_0();
case 29108198: return bem_writerGetDirect_0();
case 1291824271: return bem_echo_0();
case -827080774: return bem_copy_0();
case 1597530459: return bem_print_0();
case 1579814689: return bem_isFileGet_0();
case -146761928: return bem_isDirectoryGet_0();
case 1562356496: return bem_hashGet_0();
case 1151085267: return bem_deserializeClassNameGet_0();
case 693824622: return bem_makeFile_0();
case 721123821: return bem_tagGet_0();
case 595935693: return bem_create_0();
case -699034862: return bem_sizeGet_0();
case -910720573: return bem_close_0();
case 2105096063: return bem_writerGet_0();
case 2015982044: return bem_delete_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -374449594: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -1716509299: return bem_contentsSet_1((BEC_2_4_6_TextString) bevd_0);
case 874030253: return bem_readerSetDirect_1(bevd_0);
case 2140620274: return bem_otherType_1(bevd_0);
case -696336738: return bem_equals_1(bevd_0);
case -323113819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -690535851: return bem_sameObject_1(bevd_0);
case -283147978: return bem_pathSet_1(bevd_0);
case -499138365: return bem_otherClass_1(bevd_0);
case 1720726298: return bem_def_1(bevd_0);
case -1088395910: return bem_lastUpdatedSet_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1788911287: return bem_sameType_1(bevd_0);
case -1582378113: return bem_notEquals_1(bevd_0);
case 362456741: return bem_copyFile_1(bevd_0);
case -327732297: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 130483477: return bem_pathSetDirect_1(bevd_0);
case -2138090541: return bem_sameClass_1(bevd_0);
case 610886167: return bem_new_1(bevd_0);
case -637072093: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1716626227: return bem_readerSet_1(bevd_0);
case -478520463: return bem_undef_1(bevd_0);
case 1336620212: return bem_apNew_1(bevd_0);
case 1712929677: return bem_contentsNoCheckSet_1((BEC_2_4_6_TextString) bevd_0);
case 683055267: return bem_writerSet_1(bevd_0);
case -89866327: return bem_copyTo_1(bevd_0);
case 900247881: return bem_writerSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1828646701: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -733779503: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -77252171: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -104691827: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 350317076: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOFile_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_2_4_IOFile_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_4_IOFile();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst = (BEC_2_2_4_IOFile) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_type;
}
}
}
