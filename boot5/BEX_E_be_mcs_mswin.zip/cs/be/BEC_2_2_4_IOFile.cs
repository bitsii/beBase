namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_2_4_IOFile : BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOFile() { }
static BEC_2_2_4_IOFile() { }
private static byte[] becc_BEC_2_2_4_IOFile_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_2_4_IOFile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_inst;

public static new BET_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_2_6_6_SystemObject bevp_reader;
public BEC_2_6_6_SystemObject bevp_writer;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_new_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_apNew_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__path) {
bem_pathSet_1(beva__path);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_readerGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_reader = (new BEC_3_2_4_6_IOFileReader()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 60 */
return bevp_reader;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_writerGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_writer == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_writer = (new BEC_3_2_4_6_IOFileWriter()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 67 */
return bevp_writer;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_delete_0() {
BEC_2_6_6_SystemObject bevl_llpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 83 */ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          File.Delete(bevls_path);
          } /* Line: 96 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_copyFile_1(BEC_2_6_6_SystemObject beva_other) {
BEC_3_2_4_6_IOFileWriter bevl_outw = null;
BEC_3_2_4_6_IOFileReader bevl_inr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bemd_0(-1994433128);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-1593468961);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-785880643);
bevt_0_tmpany_phold.bemd_0(-1758977596);
bevt_3_tmpany_phold = beva_other.bemd_0(1838865248);
bevl_outw = (BEC_3_2_4_6_IOFileWriter) bevt_3_tmpany_phold.bemd_0(1425445107);
bevt_4_tmpany_phold = bem_readerGet_0();
bevl_inr = (BEC_3_2_4_6_IOFileReader) bevt_4_tmpany_phold.bemd_0(1425445107);
bevl_inr.bem_copyData_1(bevl_outw);
bevl_inr.bem_close_0();
bevl_outw.bem_close_0();
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_mkdirs_0() {
bem_makeDirs_0();
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_mkdir_0() {
bem_makeDirs_0();
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_makeDirs_0() {
BEC_2_4_6_TextString bevl_frs = null;
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_5_4_LogicBool bevl_t = null;
BEC_2_6_6_SystemObject bevl_strn = null;
BEC_2_6_6_SystemObject bevl_parentpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevl_frs = bevp_path.bem_toString_0();
bevl_r = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_t = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_strn = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevl_strn.bemd_0(-1237621363);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_5_tmpany_phold = bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevl_parentpath = bevp_path.bem_parentGet_0();
bevt_6_tmpany_phold = bevp_path.bem_equals_1(bevl_parentpath);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 137 */ {
return this;
} /* Line: 139 */
bevt_7_tmpany_phold = bevl_parentpath.bemd_0(-785880643);
bevt_7_tmpany_phold.bemd_0(-1758977596);

         Directory.CreateDirectory(
         System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int)
         );
         } /* Line: 164 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isDirectoryGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isDirGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_lastUpdatedGet_0() {
BEC_2_4_8_TimeInterval bevl_lu = null;
bevl_lu = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();

        string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
        long ctm = (long) (File.GetLastWriteTimeUtc(bevls_path) - BEC_2_4_8_TimeInterval.epochStart).TotalMilliseconds;
        bevl_lu.bevp_secs.bevi_int = (int) (ctm / 1000);
        bevl_lu.bevp_millis.bevi_int = (int) (ctm % 1000);
        return bevl_lu;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_lastUpdatedSet_1(BEC_2_4_8_TimeInterval beva_lu) {

        string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
        DateTime ts = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        ts = ts.AddSeconds(beva_lu.bevp_secs.bevi_int);
        ts = ts.AddMilliseconds(beva_lu.bevp_millis.bevi_int);
        File.SetLastWriteTimeUtc(bevls_path, ts);
        return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isDirGet_0() {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 239 */ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          if (Directory.Exists(bevls_path)) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 272 */
return bevl_result;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isFileGet_0() {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 296 */ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          if (File.Exists(bevls_path)) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 329 */
return bevl_result;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_makeFile_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_writerGet_0();
bevt_0_tmpany_phold.bemd_0(1425445107);
bevt_1_tmpany_phold = bem_writerGet_0();
bevt_1_tmpany_phold.bemd_0(41658150);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_contentsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 348 */ {
return null;
} /* Line: 349 */
bevt_2_tmpany_phold = bem_contentsNoCheckGet_0();
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_contentsNoCheckGet_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_4_6_TextString bevl_res = null;
bevl_r = bem_readerGet_0();
bevl_r.bemd_0(1425445107);
bevl_res = (BEC_2_4_6_TextString) bevl_r.bemd_0(-550393525);
bevl_r.bemd_0(41658150);
return bevl_res;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_contentsSet_1(BEC_2_4_6_TextString beva_contents) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
bevt_4_tmpany_phold = bem_pathGet_0();
bevt_3_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_4_tmpany_phold.bem_parentGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_fileGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 363 */ {
bevt_7_tmpany_phold = bem_pathGet_0();
bevt_6_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_7_tmpany_phold.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_5_tmpany_phold.bem_makeDirs_0();
} /* Line: 364 */
bem_contentsNoCheckSet_1(beva_contents);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_contentsNoCheckSet_1(BEC_2_4_6_TextString beva_contents) {
BEC_2_6_6_SystemObject bevl_w = null;
bevl_w = bem_writerGet_0();
bevl_w.bemd_0(1425445107);
bevl_w.bemd_1(93155046, beva_contents);
bevl_w.bemd_0(41658150);
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_sz = null;
bevl_sz = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return bevl_sz;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_existsGet_0() {
BEC_2_5_4_LogicBool bevl_tvala = null;
BEC_2_6_6_SystemObject bevl_mpath = null;
bevl_tvala = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_mpath = bevp_path.bem_toString_0();

      string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
      if (File.Exists(bevls_path) || Directory.Exists(bevls_path)) {
        bevl_tvala = be.BECS_Runtime.boolTrue;
      }
      return bevl_tvala;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_absPathGet_0() {
BEC_3_2_4_4_IOFilePath bevl_absp = null;
BEC_2_4_6_TextString bevl_abstr = null;
 /* Line: 449 */ {
} /* Line: 450 */
 /* Line: 458 */ {
bevl_abstr = bevp_path.bem_pathGet_0();
} /* Line: 459 */
bevl_absp = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_abstr);
return bevl_absp;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_close_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 466 */ {
bevp_reader.bemd_0(41658150);
} /* Line: 467 */
if (bevp_writer == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 469 */ {
bevp_writer.bemd_0(41658150);
} /* Line: 470 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_2_4_17_IOFileDirectoryIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_17_IOFileDirectoryIterator) (new BEC_3_2_4_17_IOFileDirectoryIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readerGetDirect_0() {
return bevp_reader;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_reader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_readerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_reader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writerGetDirect_0() {
return bevp_writer;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_writerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_writer = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_writerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_writer = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {47, 47, 51, 51, 55, 59, 59, 60, 60, 62, 66, 66, 67, 67, 69, 83, 106, 106, 106, 106, 107, 107, 108, 108, 109, 110, 111, 112, 112, 117, 120, 131, 132, 133, 134, 135, 135, 135, 135, 135, 135, 0, 0, 0, 136, 137, 139, 141, 141, 177, 177, 182, 201, 237, 238, 239, 282, 294, 295, 296, 339, 343, 343, 344, 344, 348, 348, 348, 349, 351, 351, 355, 356, 357, 358, 359, 363, 363, 363, 363, 363, 363, 364, 364, 364, 364, 366, 370, 371, 372, 373, 378, 385, 397, 398, 441, 459, 461, 462, 466, 466, 467, 469, 469, 470, 475, 475, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {28, 29, 34, 35, 39, 45, 50, 51, 52, 54, 59, 64, 65, 66, 68, 73, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 105, 109, 126, 127, 128, 129, 130, 131, 132, 134, 135, 140, 141, 144, 148, 151, 152, 154, 156, 157, 167, 168, 172, 178, 193, 194, 195, 203, 209, 210, 211, 219, 224, 225, 226, 227, 234, 235, 240, 241, 243, 244, 249, 250, 251, 252, 253, 264, 265, 266, 267, 268, 273, 274, 275, 276, 277, 279, 284, 285, 286, 287, 292, 293, 298, 299, 305, 313, 315, 316, 321, 326, 327, 329, 334, 335, 341, 342, 345, 348, 351, 355, 359, 362, 366, 370, 373, 377};
/* BEGIN LINEINFO 
assign 1 47 28
new 1 47 28
pathSet 1 47 29
assign 1 51 34
apNew 1 51 34
pathSet 1 51 35
pathSet 1 55 39
assign 1 59 45
undef 1 59 50
assign 1 60 51
toString 0 60 51
assign 1 60 52
new 1 60 52
return 1 62 54
assign 1 66 59
undef 1 66 64
assign 1 67 65
toString 0 67 65
assign 1 67 66
new 1 67 66
return 1 69 68
assign 1 83 73
existsGet 0 83 73
assign 1 106 90
pathGet 0 106 90
assign 1 106 91
parentGet 0 106 91
assign 1 106 92
fileGet 0 106 92
makeDirs 0 106 93
assign 1 107 94
writerGet 0 107 94
assign 1 107 95
open 0 107 95
assign 1 108 96
readerGet 0 108 96
assign 1 108 97
open 0 108 97
copyData 1 109 98
close 0 110 99
close 0 111 100
assign 1 112 101
new 0 112 101
return 1 112 102
makeDirs 0 117 105
makeDirs 0 120 109
assign 1 131 126
toString 0 131 126
assign 1 132 127
new 0 132 127
assign 1 133 128
new 0 133 128
assign 1 134 129
new 0 134 129
assign 1 135 130
toString 0 135 130
assign 1 135 131
emptyGet 0 135 131
assign 1 135 132
notEquals 1 135 132
assign 1 135 134
existsGet 0 135 134
assign 1 135 135
not 0 135 140
assign 1 0 141
assign 1 0 144
assign 1 0 148
assign 1 136 151
parentGet 0 136 151
assign 1 137 152
equals 1 137 152
return 1 139 154
assign 1 141 156
fileGet 0 141 156
makeDirs 0 141 157
assign 1 177 167
isDirGet 0 177 167
return 1 177 168
assign 1 182 172
new 0 182 172
return 1 201 178
assign 1 237 193
new 0 237 193
assign 1 238 194
toString 0 238 194
assign 1 239 195
existsGet 0 239 195
return 1 282 203
assign 1 294 209
new 0 294 209
assign 1 295 210
toString 0 295 210
assign 1 296 211
existsGet 0 296 211
return 1 339 219
assign 1 343 224
writerGet 0 343 224
open 0 343 225
assign 1 344 226
writerGet 0 344 226
close 0 344 227
assign 1 348 234
existsGet 0 348 234
assign 1 348 235
not 0 348 240
return 1 349 241
assign 1 351 243
contentsNoCheckGet 0 351 243
return 1 351 244
assign 1 355 249
readerGet 0 355 249
open 0 356 250
assign 1 357 251
readString 0 357 251
close 0 358 252
return 1 359 253
assign 1 363 264
pathGet 0 363 264
assign 1 363 265
parentGet 0 363 265
assign 1 363 266
fileGet 0 363 266
assign 1 363 267
existsGet 0 363 267
assign 1 363 268
not 0 363 273
assign 1 364 274
pathGet 0 364 274
assign 1 364 275
parentGet 0 364 275
assign 1 364 276
fileGet 0 364 276
makeDirs 0 364 277
contentsNoCheckSet 1 366 279
assign 1 370 284
writerGet 0 370 284
open 0 371 285
write 1 372 286
close 0 373 287
assign 1 378 292
new 0 378 292
return 1 385 293
assign 1 397 298
new 0 397 298
assign 1 398 299
toString 0 398 299
return 1 441 305
assign 1 459 313
pathGet 0 459 313
assign 1 461 315
apNew 1 461 315
return 1 462 316
assign 1 466 321
def 1 466 326
close 0 467 327
assign 1 469 329
def 1 469 334
close 0 470 335
assign 1 475 341
new 1 475 341
return 1 475 342
return 1 0 345
return 1 0 348
assign 1 0 351
assign 1 0 355
return 1 0 359
assign 1 0 362
assign 1 0 366
return 1 0 370
assign 1 0 373
assign 1 0 377
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1278716630: return bem_contentsGet_0();
case 1796476985: return bem_writerGetDirect_0();
case 536871512: return bem_isFileGet_0();
case -1773981273: return bem_contentsNoCheckGet_0();
case 67401559: return bem_delete_0();
case -144129925: return bem_serializationIteratorGet_0();
case -206816913: return bem_pathGetDirect_0();
case -1541048309: return bem_create_0();
case -160406851: return bem_new_0();
case 1985057509: return bem_fieldIteratorGet_0();
case 834511275: return bem_makeFile_0();
case 201818212: return bem_tagGet_0();
case -1989311424: return bem_iteratorGet_0();
case -912666450: return bem_absPathGet_0();
case -1335607781: return bem_sourceFileNameGet_0();
case 1838865248: return bem_writerGet_0();
case -117109951: return bem_lastUpdatedGet_0();
case 1746910008: return bem_isDirectoryGet_0();
case 450989839: return bem_toString_0();
case -259094594: return bem_echo_0();
case 129688921: return bem_mkdir_0();
case 696694712: return bem_readerGetDirect_0();
case -1758977596: return bem_makeDirs_0();
case 64036809: return bem_serializeToString_0();
case 2077438310: return bem_fieldNamesGet_0();
case 137938641: return bem_copy_0();
case -1307912568: return bem_classNameGet_0();
case 1188391548: return bem_existsGet_0();
case 739503159: return bem_mkdirs_0();
case 2087546700: return bem_isDirGet_0();
case -1005843071: return bem_serializeContents_0();
case -1192359710: return bem_toAny_0();
case 41658150: return bem_close_0();
case -1128253997: return bem_print_0();
case 681415323: return bem_hashGet_0();
case 1562408751: return bem_once_0();
case -388813808: return bem_readerGet_0();
case -1994433128: return bem_pathGet_0();
case 1875317286: return bem_many_0();
case 1165362622: return bem_sizeGet_0();
case 272950674: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 423417375: return bem_apNew_1(bevd_0);
case -1139812471: return bem_defined_1(bevd_0);
case 87713512: return bem_otherType_1(bevd_0);
case 1151483997: return bem_undef_1(bevd_0);
case 1197951918: return bem_pathSet_1(bevd_0);
case 371940317: return bem_otherClass_1(bevd_0);
case -1769267387: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -951670509: return bem_pathSetDirect_1(bevd_0);
case -1797797415: return bem_writerSetDirect_1(bevd_0);
case -658977126: return bem_new_1(bevd_0);
case 246780391: return bem_readerSetDirect_1(bevd_0);
case 895282598: return bem_readerSet_1(bevd_0);
case 1496797900: return bem_undefined_1(bevd_0);
case 893750442: return bem_copyFile_1(bevd_0);
case 959879294: return bem_notEquals_1(bevd_0);
case -2045198723: return bem_sameType_1(bevd_0);
case -1272788021: return bem_lastUpdatedSet_1((BEC_2_4_8_TimeInterval) bevd_0);
case -185820917: return bem_contentsNoCheckSet_1((BEC_2_4_6_TextString) bevd_0);
case 1113733988: return bem_copyTo_1(bevd_0);
case -45977026: return bem_writerSet_1(bevd_0);
case 1694438022: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case 1917243902: return bem_sameObject_1(bevd_0);
case -1943396073: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 531329378: return bem_contentsSet_1((BEC_2_4_6_TextString) bevd_0);
case 1645054849: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 294100036: return bem_def_1(bevd_0);
case 1634136691: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1742674668: return bem_equals_1(bevd_0);
case 1349958545: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -285325789: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1136827327: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 517362903: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -491501198: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -534690974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -496063349: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1244895026: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOFile_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_2_4_IOFile_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_4_IOFile();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst = (BEC_2_2_4_IOFile) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_type;
}
}
}
