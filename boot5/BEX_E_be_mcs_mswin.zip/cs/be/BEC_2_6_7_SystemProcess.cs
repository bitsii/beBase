namespace be {

using System;
using System.Reflection;
    /* IO:File: source/base/EcProcess.be */
public sealed class BEC_2_6_7_SystemProcess : BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemProcess() { }
static BEC_2_6_7_SystemProcess() { }
private static byte[] becc_BEC_2_6_7_SystemProcess_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] becc_BEC_2_6_7_SystemProcess_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x63,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_7_SystemProcess bece_BEC_2_6_7_SystemProcess_bevs_inst;

public static new BET_2_6_7_SystemProcess bece_BEC_2_6_7_SystemProcess_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_4_3_MathInt bevp_numArgs;
public BEC_2_6_6_SystemObject bevp_execName;
public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_6_6_SystemObject bevp_result;
public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_15_SystemCurrentPlatform bevp_platform;
public BEC_2_6_6_SystemObject bevp_fullExecName;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_default_0() {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bem_prepArgs_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_execNameGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_1_tmpany_phold = bem_fullExecNameGet_0();
return bevt_1_tmpany_phold;
} /* Line: 39 */
if (bevp_execName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 40 */ {

            bevp_execName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(Environment.GetCommandLineArgs()[0]));
            //bevp_execName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(Assembly.GetEntryAssembly().Location));
            } /* Line: 41 */
return bevp_execName;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_execPathGet_0() {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_execNameGet_0();
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_1_tmpany_phold );
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fullExecNameGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_fullExecName == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 59 */ {

            //bevp_execName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(Environment.GetCommandLineArgs()[0]));
            bevp_fullExecName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(System.Reflection.Assembly.GetEntryAssembly().Location));
            } /* Line: 60 */
return bevp_fullExecName;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_prepArgs_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 72 */ {
if (bevp_args == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevp_args = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();

            for (int i = 0;i < be.BECS_Runtime.args.Length;i++) {
                bevp_args.bem_addValue_1(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.args[i])));
            }
          bevp_numArgs = bevp_args.bem_sizeGet_0();
} /* Line: 105 */
} /* Line: 73 */
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exit_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_exit_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exit_1(BEC_2_4_3_MathInt beva_code) {

     Environment.Exit(beva_code.bevi_int);
     return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_start_1(BEC_2_6_6_SystemObject beva__target) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevp_target = beva__target;
try  /* Line: 135 */ {
bevp_result = bevp_target.bemd_0(26617766);
} /* Line: 136 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_except = bevl_e;
bevl_e.bemd_0(455481848);
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_0_tmpany_phold;
} /* Line: 140 */
return bevp_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startByName_1(BEC_2_6_6_SystemObject beva__name) {
BEC_2_6_6_SystemObject bevl_t = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_createInstance_1((BEC_2_4_6_TextString) beva__name );
bevl_t = bevt_0_tmpany_phold.bemd_0(144506434);
bevt_1_tmpany_phold = bem_start_1(bevl_t);
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numArgsGet_0() {
return bevp_numArgs;
} /*method end*/
public BEC_2_4_3_MathInt bem_numArgsGetDirect_0() {
return bevp_numArgs;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_numArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numArgs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_numArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numArgs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_execNameGetDirect_0() {
return bevp_execName;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_execNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_execName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_execNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_execName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGet_0() {
return bevp_target;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGetDirect_0() {
return bevp_target;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_targetSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_resultGet_0() {
return bevp_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_resultGetDirect_0() {
return bevp_result;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_resultSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_result = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_resultSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_result = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() {
return bevp_except;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGetDirect_0() {
return bevp_except;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exceptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_platformGetDirect_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fullExecNameGetDirect_0() {
return bevp_fullExecName;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_fullExecNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullExecName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_fullExecNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullExecName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {32, 35, 39, 39, 39, 40, 40, 48, 52, 52, 52, 59, 59, 67, 73, 73, 74, 105, 112, 112, 134, 136, 138, 139, 140, 140, 142, 146, 146, 147, 147, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 35, 37, 38, 40, 45, 50, 55, 56, 57, 61, 66, 71, 76, 81, 82, 87, 94, 95, 106, 108, 112, 113, 114, 115, 117, 123, 124, 125, 126, 129, 132, 135, 139, 143, 146, 149, 153, 157, 160, 164, 168, 171, 174, 178, 182, 185, 188, 192, 196, 199, 202, 206, 210, 213, 216, 220, 224, 227, 231};
/* BEGIN LINEINFO 
assign 1 32 27
new 0 32 27
prepArgs 0 35 28
assign 1 39 35
new 0 39 35
assign 1 39 37
fullExecNameGet 0 39 37
return 1 39 38
assign 1 40 40
undef 1 40 45
return 1 48 50
assign 1 52 55
execNameGet 0 52 55
assign 1 52 56
apNew 1 52 56
return 1 52 57
assign 1 59 61
undef 1 59 66
return 1 67 71
assign 1 73 76
undef 1 73 81
assign 1 74 82
new 0 74 82
assign 1 105 87
sizeGet 0 105 87
assign 1 112 94
new 0 112 94
exit 1 112 95
assign 1 134 106
assign 1 136 108
main 0 136 108
assign 1 138 112
print 0 139 113
assign 1 140 114
new 0 140 114
return 1 140 115
return 1 142 117
assign 1 146 123
createInstance 1 146 123
assign 1 146 124
new 0 146 124
assign 1 147 125
start 1 147 125
return 1 147 126
return 1 0 129
return 1 0 132
assign 1 0 135
assign 1 0 139
return 1 0 143
return 1 0 146
assign 1 0 149
assign 1 0 153
return 1 0 157
assign 1 0 160
assign 1 0 164
return 1 0 168
return 1 0 171
assign 1 0 174
assign 1 0 178
return 1 0 182
return 1 0 185
assign 1 0 188
assign 1 0 192
return 1 0 196
return 1 0 199
assign 1 0 202
assign 1 0 206
return 1 0 210
return 1 0 213
assign 1 0 216
assign 1 0 220
return 1 0 224
assign 1 0 227
assign 1 0 231
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 144506434: return bem_new_0();
case -1434960598: return bem_serializeContents_0();
case 1782620959: return bem_echo_0();
case -1714811768: return bem_fieldIteratorGet_0();
case 386987987: return bem_numArgsGet_0();
case 537871143: return bem_execNameGet_0();
case 2132306504: return bem_classNameGet_0();
case -2003507382: return bem_execPathGet_0();
case -144273157: return bem_argsGet_0();
case -1054400757: return bem_deserializeClassNameGet_0();
case 934813140: return bem_platformGetDirect_0();
case 1932949509: return bem_resultGet_0();
case 1014452284: return bem_targetGet_0();
case -1050275987: return bem_default_0();
case 952056940: return bem_toString_0();
case -1506574892: return bem_prepArgs_0();
case -677109338: return bem_targetGetDirect_0();
case -1313867098: return bem_tagGet_0();
case 455481848: return bem_print_0();
case -377355642: return bem_hashGet_0();
case -464553043: return bem_argsGetDirect_0();
case -1665576026: return bem_sourceFileNameGet_0();
case 244196073: return bem_exceptGetDirect_0();
case -1095332831: return bem_fullExecNameGet_0();
case -1830560348: return bem_fieldNamesGet_0();
case -1427827058: return bem_once_0();
case 432223055: return bem_execNameGetDirect_0();
case 669958336: return bem_fullExecNameGetDirect_0();
case 1667331006: return bem_toAny_0();
case -1236478007: return bem_numArgsGetDirect_0();
case -1664573433: return bem_exit_0();
case -157733273: return bem_many_0();
case -181500453: return bem_copy_0();
case 1794518227: return bem_iteratorGet_0();
case 2005192015: return bem_serializeToString_0();
case -469287980: return bem_resultGetDirect_0();
case 985753857: return bem_platformGet_0();
case -664467345: return bem_create_0();
case -655092564: return bem_serializationIteratorGet_0();
case -263598241: return bem_exceptGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1272963269: return bem_sameObject_1(bevd_0);
case -459360005: return bem_otherClass_1(bevd_0);
case -1003079054: return bem_targetSetDirect_1(bevd_0);
case 902692629: return bem_resultSet_1(bevd_0);
case 1175579360: return bem_platformSetDirect_1(bevd_0);
case -26559400: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 736951914: return bem_resultSetDirect_1(bevd_0);
case 1879967302: return bem_argsSetDirect_1(bevd_0);
case 1532532742: return bem_undefined_1(bevd_0);
case 440742411: return bem_numArgsSetDirect_1(bevd_0);
case 677836685: return bem_exceptSetDirect_1(bevd_0);
case 2102889872: return bem_sameClass_1(bevd_0);
case 1198427025: return bem_notEquals_1(bevd_0);
case 1135973654: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -557880279: return bem_argsSet_1(bevd_0);
case -730691992: return bem_numArgsSet_1(bevd_0);
case -969316698: return bem_execNameSet_1(bevd_0);
case 435597788: return bem_exit_1((BEC_2_4_3_MathInt) bevd_0);
case 1911701664: return bem_equals_1(bevd_0);
case -2123337515: return bem_undef_1(bevd_0);
case -585494508: return bem_copyTo_1(bevd_0);
case 772596976: return bem_platformSet_1(bevd_0);
case -1267848498: return bem_exceptSet_1(bevd_0);
case 241299765: return bem_sameType_1(bevd_0);
case -1455344000: return bem_startByName_1(bevd_0);
case -98791052: return bem_defined_1(bevd_0);
case 1377625485: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2069326800: return bem_otherType_1(bevd_0);
case 1481610007: return bem_targetSet_1(bevd_0);
case -825812507: return bem_fullExecNameSetDirect_1(bevd_0);
case -1432196319: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -101046121: return bem_start_1(bevd_0);
case 1003716077: return bem_def_1(bevd_0);
case -569554160: return bem_fullExecNameSet_1(bevd_0);
case 499169085: return bem_execNameSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1234965347: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -720811311: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 674286989: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1973929830: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -389946827: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2041425680: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1411035525: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemProcess_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_7_SystemProcess_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_7_SystemProcess();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst = (BEC_2_6_7_SystemProcess) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_type;
}
}
}
