namespace be {
/* IO:File: source/base/Test.be */
public class BEC_2_4_10_TestAssertions : BEC_2_6_6_SystemObject {
public BEC_2_4_10_TestAssertions() { }
static BEC_2_4_10_TestAssertions() { }
private static byte[] becc_BEC_2_4_10_TestAssertions_clname = {0x54,0x65,0x73,0x74,0x3A,0x41,0x73,0x73,0x65,0x72,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_2_4_10_TestAssertions_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_0 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_1 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_2 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_3 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_4 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_5 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_6 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x2E};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_7 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_8 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_9 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_10_TestAssertions_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_10_TestAssertions_bels_9, 36));
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_10 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_10_TestAssertions_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_10_TestAssertions_bels_10, 1));
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_11 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x55,0x4E,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_12 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_13 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_14 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x4F,0x54,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_15 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x54,0x52,0x55,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_16 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x46,0x41,0x4C,0x53,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
public static new BEC_2_4_10_TestAssertions bece_BEC_2_4_10_TestAssertions_bevs_inst;

public static new BET_2_4_10_TestAssertions bece_BEC_2_4_10_TestAssertions_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_10_tmpany_phold = null;
bevt_2_tmpany_phold = beva_v1.bemd_1(1485494702, beva_v2);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-290803610);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 27 */ {
bevl_msg = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_0));
if (beva_v1 == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 29 */ {
if (beva_v2 == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 29 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 29 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 29 */
 else  /* Line: 29 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 29 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_1));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevl_msg.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(beva_v1);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_2));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(beva_v2);
} /* Line: 30 */
bevt_10_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 32 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNotHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v1.bemd_1(1485494702, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 36 */ {
bevl_msg = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_3));
if (beva_v1 == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 38 */ {
if (beva_v2 == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 38 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 38 */ {
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_4));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_msg.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(beva_v1);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_5));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(beva_v2);
} /* Line: 39 */
bevt_9_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_9_tmpany_phold);
} /* Line: 41 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_assertEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_10_TestAssertions bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_10_TestAssertions) bem_assertEqual_2(beva_v1, beva_v2);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_assertNotEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_10_TestAssertions bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_10_TestAssertions) bem_assertNotEqual_2(beva_v1, beva_v2);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_6_TextString bevl_v1v = null;
BEC_2_4_6_TextString bevl_v2v = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
if (beva_v1 == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(56, bece_BEC_2_4_10_TestAssertions_bels_6));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 52 */
bevt_3_tmpany_phold = beva_v1.bemd_1(-1007540340, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 54 */ {
if (beva_v1 == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevl_v1v = (BEC_2_4_6_TextString) beva_v1.bemd_0(-1795002401);
} /* Line: 56 */
 else  /* Line: 57 */ {
bevl_v1v = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_7));
} /* Line: 58 */
if (beva_v2 == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevl_v2v = (BEC_2_4_6_TextString) beva_v2.bemd_0(-1795002401);
} /* Line: 61 */
 else  /* Line: 62 */ {
bevl_v2v = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_8));
} /* Line: 63 */
bevt_10_tmpany_phold = bece_BEC_2_4_10_TestAssertions_bevo_0;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_v1v);
bevt_11_tmpany_phold = bece_BEC_2_4_10_TestAssertions_bevo_1;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevl_v2v);
bevt_6_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 65 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNotEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v1.bemd_1(350775730, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 69 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_4_10_TestAssertions_bels_11));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 70 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNull_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_12));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 75 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertIsNull_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_13));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 80 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNotNull_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_4_10_TestAssertions_bels_14));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 85 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertTrue_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bemd_0(-290803610);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 89 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_15));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 90 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertFalse_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_4_7_TestFailure bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (((BEC_2_5_4_LogicBool) beva_v).bevi_bool) /* Line: 94 */ {
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_4_10_TestAssertions_bels_16));
bevt_0_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_1_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_0_tmpany_phold);
} /* Line: 95 */
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {27, 27, 28, 29, 29, 29, 29, 0, 0, 0, 30, 30, 30, 30, 30, 30, 32, 32, 36, 37, 38, 38, 38, 38, 0, 0, 0, 39, 39, 39, 39, 39, 39, 41, 41, 45, 45, 48, 48, 51, 51, 52, 52, 52, 54, 55, 55, 56, 58, 60, 60, 61, 63, 65, 65, 65, 65, 65, 65, 65, 69, 70, 70, 70, 74, 74, 75, 75, 75, 79, 79, 80, 80, 80, 84, 84, 85, 85, 85, 89, 90, 90, 90, 95, 95, 95};
public static new int[] bevs_smnlec
 = new int[] {50, 51, 53, 54, 59, 60, 65, 66, 69, 73, 76, 77, 78, 79, 80, 81, 83, 84, 100, 102, 103, 108, 109, 114, 115, 118, 122, 125, 126, 127, 128, 129, 130, 132, 133, 139, 140, 144, 145, 162, 167, 168, 169, 170, 172, 174, 179, 180, 183, 185, 190, 191, 194, 196, 197, 198, 199, 200, 201, 202, 210, 212, 213, 214, 222, 227, 228, 229, 230, 238, 243, 244, 245, 246, 254, 259, 260, 261, 262, 270, 272, 273, 274, 282, 283, 284};
/* BEGIN LINEINFO 
assign 1 27 50
has 1 27 50
assign 1 27 51
not 0 27 51
assign 1 28 53
new 0 28 53
assign 1 29 54
def 1 29 59
assign 1 29 60
def 1 29 65
assign 1 0 66
assign 1 0 69
assign 1 0 73
assign 1 30 76
new 0 30 76
assign 1 30 77
addValue 1 30 77
assign 1 30 78
addValue 1 30 78
assign 1 30 79
new 0 30 79
assign 1 30 80
addValue 1 30 80
addValue 1 30 81
assign 1 32 83
new 1 32 83
throw 1 32 84
assign 1 36 100
has 1 36 100
assign 1 37 102
new 0 37 102
assign 1 38 103
def 1 38 108
assign 1 38 109
def 1 38 114
assign 1 0 115
assign 1 0 118
assign 1 0 122
assign 1 39 125
new 0 39 125
assign 1 39 126
addValue 1 39 126
assign 1 39 127
addValue 1 39 127
assign 1 39 128
new 0 39 128
assign 1 39 129
addValue 1 39 129
addValue 1 39 130
assign 1 41 132
new 1 41 132
throw 1 41 133
assign 1 45 139
assertEqual 2 45 139
return 1 45 140
assign 1 48 144
assertNotEqual 2 48 144
return 1 48 145
assign 1 51 162
undef 1 51 167
assign 1 52 168
new 0 52 168
assign 1 52 169
new 1 52 169
throw 1 52 170
assign 1 54 172
notEquals 1 54 172
assign 1 55 174
def 1 55 179
assign 1 56 180
toString 0 56 180
assign 1 58 183
new 0 58 183
assign 1 60 185
def 1 60 190
assign 1 61 191
toString 0 61 191
assign 1 63 194
new 0 63 194
assign 1 65 196
new 0 65 196
assign 1 65 197
add 1 65 197
assign 1 65 198
new 0 65 198
assign 1 65 199
add 1 65 199
assign 1 65 200
add 1 65 200
assign 1 65 201
new 1 65 201
throw 1 65 202
assign 1 69 210
equals 1 69 210
assign 1 70 212
new 0 70 212
assign 1 70 213
new 1 70 213
throw 1 70 214
assign 1 74 222
def 1 74 227
assign 1 75 228
new 0 75 228
assign 1 75 229
new 1 75 229
throw 1 75 230
assign 1 79 238
def 1 79 243
assign 1 80 244
new 0 80 244
assign 1 80 245
new 1 80 245
throw 1 80 246
assign 1 84 254
undef 1 84 259
assign 1 85 260
new 0 85 260
assign 1 85 261
new 1 85 261
throw 1 85 262
assign 1 89 270
not 0 89 270
assign 1 90 272
new 0 90 272
assign 1 90 273
new 1 90 273
throw 1 90 274
assign 1 95 282
new 0 95 282
assign 1 95 283
new 1 95 283
throw 1 95 284
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 367195678: return bem_once_0();
case 55812595: return bem_serializeToString_0();
case -604312045: return bem_serializationIteratorGet_0();
case 808044123: return bem_hashGet_0();
case 748315678: return bem_tagGet_0();
case 402201008: return bem_new_0();
case 879229436: return bem_default_0();
case 9957435: return bem_iteratorGet_0();
case -1795002401: return bem_toString_0();
case 966149554: return bem_create_0();
case 1342765490: return bem_toAny_0();
case -1854726950: return bem_echo_0();
case -656937356: return bem_many_0();
case 1678261270: return bem_print_0();
case -1975455714: return bem_copy_0();
case -368347729: return bem_fieldNamesGet_0();
case -434919379: return bem_deserializeClassNameGet_0();
case 682604587: return bem_serializeContents_0();
case -772967023: return bem_classNameGet_0();
case 1860492410: return bem_fieldIteratorGet_0();
case -636994806: return bem_sourceFileNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1005610947: return bem_assertTrue_1(bevd_0);
case -991365338: return bem_defined_1(bevd_0);
case -700310720: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -714900612: return bem_copyTo_1(bevd_0);
case -2144202949: return bem_sameClass_1(bevd_0);
case 1272631429: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 195308005: return bem_sameObject_1(bevd_0);
case -1194473609: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 267174377: return bem_def_1(bevd_0);
case -1564268207: return bem_assertNotNull_1(bevd_0);
case 543061021: return bem_otherClass_1(bevd_0);
case -1468342529: return bem_assertNull_1(bevd_0);
case 728145577: return bem_assertFalse_1(bevd_0);
case 1647993291: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1614496109: return bem_undef_1(bevd_0);
case 1448933357: return bem_otherType_1(bevd_0);
case 1732171281: return bem_assertIsNull_1(bevd_0);
case 350775730: return bem_equals_1(bevd_0);
case -1007540340: return bem_notEquals_1(bevd_0);
case 1621186357: return bem_sameType_1(bevd_0);
case 1163078007: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1002081558: return bem_assertHas_2(bevd_0, bevd_1);
case 1342872029: return bem_assertNotHas_2(bevd_0, bevd_1);
case 1280867989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 325307565: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 163729837: return bem_assertEquals_2(bevd_0, bevd_1);
case -187061774: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -961973758: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2117874838: return bem_assertNotEqual_2(bevd_0, bevd_1);
case -1385197575: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1833007700: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1363721867: return bem_assertEqual_2(bevd_0, bevd_1);
case 1584099228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1982684657: return bem_assertNotEquals_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_TestAssertions_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_10_TestAssertions_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_10_TestAssertions();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst = (BEC_2_4_10_TestAssertions) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_type;
}
}
}
