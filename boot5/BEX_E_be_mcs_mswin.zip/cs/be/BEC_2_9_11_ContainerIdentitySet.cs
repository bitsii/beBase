namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentitySet : BEC_2_9_3_ContainerSet {
public BEC_2_9_11_ContainerIdentitySet() { }
static BEC_2_9_11_ContainerIdentitySet() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;

public static new BET_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {199, 199, 203, 204, 205, 206, 207, 208};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 199 14
new 0 199 14
new 1 199 15
assign 1 203 19
new 1 203 19
assign 1 204 20
assign 1 205 21
new 0 205 21
assign 1 206 22
new 0 206 22
assign 1 207 23
new 0 207 23
assign 1 208 24
new 0 208 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 632394323: return bem_slotsGet_0();
case 1928853239: return bem_nodesGet_0();
case 1624944174: return bem_serializationIteratorGet_0();
case 357310027: return bem_setIteratorGet_0();
case 1754519730: return bem_classNameGet_0();
case -2009708529: return bem_keyIteratorGet_0();
case 1625518333: return bem_isEmptyGet_0();
case -996105536: return bem_notEmptyGet_0();
case -976794306: return bem_nodeIteratorGet_0();
case -1560668901: return bem_moduGet_0();
case 1099128486: return bem_echo_0();
case 342664202: return bem_serializeContents_0();
case -129240999: return bem_innerPutAddedGet_0();
case 778335598: return bem_relGet_0();
case 1052827619: return bem_baseNodeGet_0();
case -1920078604: return bem_sourceFileNameGet_0();
case 1906100653: return bem_clear_0();
case -1248348608: return bem_many_0();
case 1334927002: return bem_create_0();
case -914943787: return bem_toString_0();
case 1280569362: return bem_fieldIteratorGet_0();
case -1117992648: return bem_hashGet_0();
case 93356535: return bem_deserializeClassNameGet_0();
case -1942605555: return bem_toAny_0();
case -152803575: return bem_tagGet_0();
case -541227487: return bem_new_0();
case 38289726: return bem_print_0();
case -1618533783: return bem_serializeToString_0();
case 1878351659: return bem_keysGet_0();
case -1749035302: return bem_copy_0();
case -1620303979: return bem_once_0();
case 385489744: return bem_iteratorGet_0();
case 138188488: return bem_multiGet_0();
case 356757239: return bem_sizeGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1952247489: return bem_moduSet_1(bevd_0);
case 578214499: return bem_multiSet_1(bevd_0);
case 1669123607: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1717363153: return bem_slotsSet_1(bevd_0);
case -1553866014: return bem_sameClass_1(bevd_0);
case -71218402: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1052704201: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 2144748804: return bem_delete_1(bevd_0);
case 853086098: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1001167064: return bem_def_1(bevd_0);
case -832787583: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -900790842: return bem_defined_1(bevd_0);
case -168753549: return bem_put_1(bevd_0);
case 387196816: return bem_relSet_1(bevd_0);
case -929975460: return bem_equals_1(bevd_0);
case -1975825183: return bem_sameObject_1(bevd_0);
case 1312733734: return bem_has_1(bevd_0);
case -1136932191: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 589015080: return bem_otherType_1(bevd_0);
case -147916244: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -201699569: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -2057956567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1823517629: return bem_baseNodeSet_1(bevd_0);
case -329198955: return bem_innerPutAddedSet_1(bevd_0);
case 1356842566: return bem_otherClass_1(bevd_0);
case 408844820: return bem_undefined_1(bevd_0);
case 960625295: return bem_notEquals_1(bevd_0);
case -406377870: return bem_copyTo_1(bevd_0);
case 1417404860: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2111237002: return bem_get_1(bevd_0);
case 327551615: return bem_undef_1(bevd_0);
case 32553456: return bem_sameType_1(bevd_0);
case -1164482106: return bem_sizeSet_1(bevd_0);
case -647434226: return bem_addValue_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1615755198: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 914119897: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1087635510: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1722418125: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1183458920: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -294037420: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1794036335: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1344222461: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 107199919: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentitySet_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentitySet_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentitySet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst = (BEC_2_9_11_ContainerIdentitySet) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;
}
}
}
