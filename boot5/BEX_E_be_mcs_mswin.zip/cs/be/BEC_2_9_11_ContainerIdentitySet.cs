namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentitySet : BEC_2_9_3_ContainerSet {
public BEC_2_9_11_ContainerIdentitySet() { }
static BEC_2_9_11_ContainerIdentitySet() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;

public static new BET_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {199, 199, 203, 204, 205, 206, 207, 208};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 199 14
new 0 199 14
new 1 199 15
assign 1 203 19
new 1 203 19
assign 1 204 20
assign 1 205 21
new 0 205 21
assign 1 206 22
new 0 206 22
assign 1 207 23
new 0 207 23
assign 1 208 24
new 0 208 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 393968063: return bem_isEmptyGet_0();
case -1730575753: return bem_relGet_0();
case 2121039924: return bem_new_0();
case -1856486979: return bem_deserializeClassNameGet_0();
case -811418832: return bem_many_0();
case -1293773104: return bem_keyIteratorGet_0();
case 934579274: return bem_baseNodeGet_0();
case -992120130: return bem_fieldIteratorGet_0();
case 893274194: return bem_tagGet_0();
case -163837554: return bem_relGetDirect_0();
case 1057323332: return bem_toAny_0();
case -195266806: return bem_toString_0();
case -1472731354: return bem_clear_0();
case -1939283808: return bem_multiGetDirect_0();
case 538632487: return bem_serializationIteratorGet_0();
case 608316566: return bem_multiGet_0();
case -189856578: return bem_copy_0();
case -46347220: return bem_notEmptyGet_0();
case -166515831: return bem_fieldNamesGet_0();
case -1970047848: return bem_innerPutAddedGetDirect_0();
case -265928475: return bem_classNameGet_0();
case -280765738: return bem_nodesGet_0();
case -1338888359: return bem_innerPutAddedGet_0();
case -1232978478: return bem_hashGet_0();
case -2059116318: return bem_keysGet_0();
case 1236464998: return bem_serializeContents_0();
case 803060031: return bem_create_0();
case -361981443: return bem_slotsGetDirect_0();
case 470714498: return bem_moduGetDirect_0();
case -1105589145: return bem_moduGet_0();
case -1004741527: return bem_sizeGet_0();
case 2111391138: return bem_serializeToString_0();
case -299023655: return bem_echo_0();
case 1870744321: return bem_once_0();
case 869814362: return bem_slotsGet_0();
case -1735879417: return bem_print_0();
case -1438038411: return bem_sourceFileNameGet_0();
case 1490639815: return bem_setIteratorGet_0();
case 24125772: return bem_iteratorGet_0();
case 1353404980: return bem_sizeGetDirect_0();
case -2126566108: return bem_nodeIteratorGet_0();
case -1670304357: return bem_baseNodeGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1301982069: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 2089390654: return bem_has_1(bevd_0);
case -1105696537: return bem_multiSetDirect_1(bevd_0);
case -1439597201: return bem_baseNodeSetDirect_1(bevd_0);
case -1739335990: return bem_moduSet_1(bevd_0);
case 1644002544: return bem_sizeSetDirect_1(bevd_0);
case 1669121148: return bem_copyTo_1(bevd_0);
case 712489064: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -490313093: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -882129351: return bem_baseNodeSet_1(bevd_0);
case 1628306760: return bem_notEquals_1(bevd_0);
case -564148923: return bem_sameObject_1(bevd_0);
case 1025270681: return bem_sameClass_1(bevd_0);
case -611817948: return bem_relSetDirect_1(bevd_0);
case -1233382567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 208579137: return bem_put_1(bevd_0);
case -1780562999: return bem_slotsSet_1(bevd_0);
case -1108496649: return bem_otherClass_1(bevd_0);
case 603416823: return bem_slotsSetDirect_1(bevd_0);
case 2034892494: return bem_addValue_1(bevd_0);
case -1822782606: return bem_sizeSet_1(bevd_0);
case 146723804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -905872983: return bem_equals_1(bevd_0);
case -1694149083: return bem_innerPutAddedSet_1(bevd_0);
case 819301669: return bem_relSet_1(bevd_0);
case 525545408: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1548459664: return bem_multiSet_1(bevd_0);
case 1438454934: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -132983687: return bem_undefined_1(bevd_0);
case -807739702: return bem_delete_1(bevd_0);
case -272106945: return bem_moduSetDirect_1(bevd_0);
case 1423708419: return bem_get_1(bevd_0);
case 1681419755: return bem_defined_1(bevd_0);
case -1374125024: return bem_undef_1(bevd_0);
case -908579141: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 925735910: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1433803932: return bem_def_1(bevd_0);
case 2147373825: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -267062499: return bem_sameType_1(bevd_0);
case -1171661229: return bem_otherType_1(bevd_0);
case -1510982280: return bem_innerPutAddedSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1931375919: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -83745497: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68692131: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383175850: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -110664853: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1765848815: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1365987158: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -381061425: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1484540959: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentitySet_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentitySet_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentitySet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst = (BEC_2_9_11_ContainerIdentitySet) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;
}
}
}
