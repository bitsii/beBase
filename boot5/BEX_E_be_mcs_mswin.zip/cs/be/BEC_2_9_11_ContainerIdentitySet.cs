namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentitySet : BEC_2_9_3_ContainerSet {
public BEC_2_9_11_ContainerIdentitySet() { }
static BEC_2_9_11_ContainerIdentitySet() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;

public static new BET_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {198, 198, 202, 203, 204, 205, 206, 207};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 198 14
new 0 198 14
new 1 198 15
assign 1 202 19
new 1 202 19
assign 1 203 20
assign 1 204 21
new 0 204 21
assign 1 205 22
new 0 205 22
assign 1 206 23
new 0 206 23
assign 1 207 24
new 0 207 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 505982208: return bem_multiGet_0();
case 1212325635: return bem_isEmptyGet_0();
case -983786309: return bem_sizeGetDirect_0();
case 625257614: return bem_slotsGet_0();
case -1642361296: return bem_print_0();
case 1161638424: return bem_new_0();
case -635094168: return bem_relGet_0();
case 1625005468: return bem_multiGetDirect_0();
case 168135582: return bem_create_0();
case 1031117601: return bem_nodesGet_0();
case 759496930: return bem_tagGet_0();
case -2122954985: return bem_setIteratorGet_0();
case 814334258: return bem_serializeContents_0();
case 1810853236: return bem_keysGet_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case -1611734276: return bem_slotsGetDirect_0();
case 216339718: return bem_baseNodeGetDirect_0();
case -1091873166: return bem_nodeIteratorGet_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -71162589: return bem_iteratorGet_0();
case 972592223: return bem_clear_0();
case -2140213935: return bem_moduGet_0();
case -1161934195: return bem_innerPutAddedGet_0();
case 1650972794: return bem_baseNodeGet_0();
case 944073339: return bem_fieldIteratorGet_0();
case 2132420479: return bem_many_0();
case 1365897346: return bem_serializationIteratorGet_0();
case -1480556491: return bem_toAny_0();
case -202912463: return bem_copy_0();
case 350691792: return bem_toString_0();
case -826245265: return bem_keyIteratorGet_0();
case -1044758745: return bem_serializeToString_0();
case 2064925791: return bem_echo_0();
case -499583203: return bem_sizeGet_0();
case -1711670377: return bem_hashGet_0();
case -285131884: return bem_notEmptyGet_0();
case -1359614197: return bem_classNameGet_0();
case -1785724794: return bem_once_0();
case -675326203: return bem_innerPutAddedGetDirect_0();
case -2058250940: return bem_relGetDirect_0();
case -652053502: return bem_fieldNamesGet_0();
case 1133292670: return bem_moduGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -902605361: return bem_relSet_1(bevd_0);
case -1829001662: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1883110435: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -243652784: return bem_slotsSet_1(bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case 1317004400: return bem_relSetDirect_1(bevd_0);
case 354321713: return bem_moduSet_1(bevd_0);
case -535214159: return bem_baseNodeSetDirect_1(bevd_0);
case -314259740: return bem_multiSet_1(bevd_0);
case -2058237157: return bem_put_1(bevd_0);
case -1130400467: return bem_baseNodeSet_1(bevd_0);
case -1267929220: return bem_get_1(bevd_0);
case -979624172: return bem_slotsSetDirect_1(bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case 1688096367: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1700641878: return bem_delete_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -175180716: return bem_sizeSetDirect_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2012233536: return bem_moduSetDirect_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1351340008: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case -1031140802: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -844245022: return bem_has_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case 102779814: return bem_innerPutAddedSetDirect_1(bevd_0);
case 678289630: return bem_multiSetDirect_1(bevd_0);
case 176174164: return bem_innerPutAddedSet_1(bevd_0);
case -1872347201: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case 1628522769: return bem_addValue_1(bevd_0);
case -1221289884: return bem_sizeSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1703758135: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1736793343: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentitySet_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentitySet_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentitySet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst = (BEC_2_9_11_ContainerIdentitySet) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;
}
}
}
