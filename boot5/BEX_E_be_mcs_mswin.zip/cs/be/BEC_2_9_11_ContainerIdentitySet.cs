namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentitySet : BEC_2_9_3_ContainerSet {
public BEC_2_9_11_ContainerIdentitySet() { }
static BEC_2_9_11_ContainerIdentitySet() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;

public static new BET_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {199, 199, 203, 204, 205, 206, 207, 208};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 199 14
new 0 199 14
new 1 199 15
assign 1 203 19
new 1 203 19
assign 1 204 20
assign 1 205 21
new 0 205 21
assign 1 206 22
new 0 206 22
assign 1 207 23
new 0 207 23
assign 1 208 24
new 0 208 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1774653393: return bem_baseNodeGetDirect_0();
case 1317152431: return bem_nodeIteratorGet_0();
case -1989311424: return bem_iteratorGet_0();
case -1005843071: return bem_serializeContents_0();
case 1875317286: return bem_many_0();
case 272950674: return bem_deserializeClassNameGet_0();
case 680088758: return bem_baseNodeGet_0();
case -56072853: return bem_relGet_0();
case 1504373906: return bem_multiGetDirect_0();
case -259094594: return bem_echo_0();
case -1085467178: return bem_setIteratorGet_0();
case 1985057509: return bem_fieldIteratorGet_0();
case 64036809: return bem_serializeToString_0();
case 1279325121: return bem_relGetDirect_0();
case 450989839: return bem_toString_0();
case 2077438310: return bem_fieldNamesGet_0();
case -1711168690: return bem_slotsGet_0();
case -845146243: return bem_slotsGetDirect_0();
case -160406851: return bem_new_0();
case 681415323: return bem_hashGet_0();
case 580717641: return bem_moduGetDirect_0();
case -1613383022: return bem_isEmptyGet_0();
case -1827758939: return bem_clear_0();
case 1562408751: return bem_once_0();
case -52088481: return bem_keyIteratorGet_0();
case -1727152012: return bem_innerPutAddedGet_0();
case 966385456: return bem_keysGet_0();
case -1541048309: return bem_create_0();
case -1307912568: return bem_classNameGet_0();
case 1387569891: return bem_sizeGetDirect_0();
case 137938641: return bem_copy_0();
case 201818212: return bem_tagGet_0();
case -900102183: return bem_notEmptyGet_0();
case 1523625695: return bem_innerPutAddedGetDirect_0();
case -1335607781: return bem_sourceFileNameGet_0();
case -686680699: return bem_multiGet_0();
case -144129925: return bem_serializationIteratorGet_0();
case -763476840: return bem_nodesGet_0();
case -759124721: return bem_moduGet_0();
case 1165362622: return bem_sizeGet_0();
case -1128253997: return bem_print_0();
case -1192359710: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1113733988: return bem_copyTo_1(bevd_0);
case -658977126: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1151483997: return bem_undef_1(bevd_0);
case -1769267387: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 959879294: return bem_notEquals_1(bevd_0);
case 87713512: return bem_otherType_1(bevd_0);
case 140141691: return bem_sizeSet_1(bevd_0);
case -238362870: return bem_has_1(bevd_0);
case 1742674668: return bem_equals_1(bevd_0);
case -1713111310: return bem_multiSet_1(bevd_0);
case 1917243902: return bem_sameObject_1(bevd_0);
case -1823686374: return bem_get_1(bevd_0);
case -138334655: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1496797900: return bem_undefined_1(bevd_0);
case 409784817: return bem_sizeSetDirect_1(bevd_0);
case -245929742: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 939713751: return bem_relSet_1(bevd_0);
case -2146888570: return bem_put_1(bevd_0);
case -147067396: return bem_baseNodeSetDirect_1(bevd_0);
case -187538580: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1634136691: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 371940317: return bem_otherClass_1(bevd_0);
case -1322546940: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1943396073: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1139812471: return bem_defined_1(bevd_0);
case 550257934: return bem_slotsSetDirect_1(bevd_0);
case 1645054849: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1646637480: return bem_slotsSet_1(bevd_0);
case -325638505: return bem_innerPutAddedSet_1(bevd_0);
case -834529170: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1299132470: return bem_moduSetDirect_1(bevd_0);
case 1675429981: return bem_delete_1(bevd_0);
case -2045198723: return bem_sameType_1(bevd_0);
case 294100036: return bem_def_1(bevd_0);
case 1948203779: return bem_relSetDirect_1(bevd_0);
case 1349958545: return bem_sameClass_1(bevd_0);
case -160162251: return bem_moduSet_1(bevd_0);
case -258176959: return bem_addValue_1(bevd_0);
case 1717503869: return bem_baseNodeSet_1(bevd_0);
case 818409767: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1722512679: return bem_multiSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -285325789: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1136827327: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 517362903: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -491501198: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2077401160: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -534690974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -496063349: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1244895026: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1077733575: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentitySet_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentitySet_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentitySet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst = (BEC_2_9_11_ContainerIdentitySet) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;
}
}
}
