namespace be {
/* IO:File: source/build/Pass6.be */
public sealed class BEC_3_5_5_5_BuildVisitPass6 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass6() { }
static BEC_3_5_5_5_BuildVisitPass6() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_0 = {0x2C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_1 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_2 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_3 = {0x5F};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_4 = {0x74,0x68,0x69,0x73};
public static new BEC_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;

public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_9_3_ContainerSet bevl_langs = null;
BEC_2_5_4_BuildNode bevl_lang = null;
BEC_2_6_6_SystemObject bevl_doit = null;
BEC_2_6_6_SystemObject bevl_si = null;
BEC_2_6_6_SystemObject bevl_snode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_nxnode = null;
BEC_2_6_6_SystemObject bevl_parens = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_numargs = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vid = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_38_ta_ph = null;
BEC_2_5_4_BuildNode bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_3_MathInt bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_5_4_BuildEmit bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_5_6_BuildIfEmit bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_5_4_LogicBool bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_4_3_MathInt bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_5_4_LogicBool bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
BEC_2_4_3_MathInt bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_6_6_SystemObject bevt_80_ta_ph = null;
BEC_2_5_4_LogicBool bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
BEC_2_5_4_BuildNode bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_89_ta_ph = null;
BEC_2_4_3_MathInt bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_6_6_SystemObject bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_4_3_MathInt bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
BEC_2_5_4_LogicBool bevt_102_ta_ph = null;
BEC_2_4_3_MathInt bevt_103_ta_ph = null;
BEC_2_6_6_SystemObject bevt_104_ta_ph = null;
BEC_2_6_6_SystemObject bevt_105_ta_ph = null;
BEC_2_4_3_MathInt bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_6_6_SystemObject bevt_108_ta_ph = null;
BEC_2_4_3_MathInt bevt_109_ta_ph = null;
BEC_2_4_3_MathInt bevt_110_ta_ph = null;
BEC_2_6_6_SystemObject bevt_111_ta_ph = null;
BEC_2_6_6_SystemObject bevt_112_ta_ph = null;
BEC_2_6_6_SystemObject bevt_113_ta_ph = null;
BEC_2_5_4_LogicBool bevt_114_ta_ph = null;
BEC_2_4_3_MathInt bevt_115_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_6_6_SystemObject bevt_118_ta_ph = null;
BEC_2_6_6_SystemObject bevt_119_ta_ph = null;
BEC_2_4_3_MathInt bevt_120_ta_ph = null;
BEC_2_6_6_SystemObject bevt_121_ta_ph = null;
BEC_2_6_6_SystemObject bevt_122_ta_ph = null;
BEC_2_6_6_SystemObject bevt_123_ta_ph = null;
BEC_2_6_6_SystemObject bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_6_6_SystemObject bevt_126_ta_ph = null;
BEC_2_6_6_SystemObject bevt_127_ta_ph = null;
BEC_2_6_6_SystemObject bevt_128_ta_ph = null;
BEC_2_6_6_SystemObject bevt_129_ta_ph = null;
BEC_2_4_3_MathInt bevt_130_ta_ph = null;
BEC_2_6_6_SystemObject bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_6_6_SystemObject bevt_133_ta_ph = null;
BEC_2_6_6_SystemObject bevt_134_ta_ph = null;
BEC_2_6_6_SystemObject bevt_135_ta_ph = null;
BEC_2_6_6_SystemObject bevt_136_ta_ph = null;
BEC_2_6_6_SystemObject bevt_137_ta_ph = null;
BEC_2_6_6_SystemObject bevt_138_ta_ph = null;
BEC_2_4_6_TextString bevt_139_ta_ph = null;
BEC_2_6_6_SystemObject bevt_140_ta_ph = null;
BEC_2_5_4_LogicBool bevt_141_ta_ph = null;
BEC_2_6_6_SystemObject bevt_142_ta_ph = null;
BEC_2_5_4_LogicBool bevt_143_ta_ph = null;
BEC_2_6_6_SystemObject bevt_144_ta_ph = null;
BEC_2_5_4_LogicBool bevt_145_ta_ph = null;
BEC_2_6_6_SystemObject bevt_146_ta_ph = null;
BEC_2_6_6_SystemObject bevt_147_ta_ph = null;
BEC_2_4_6_TextString bevt_148_ta_ph = null;
BEC_2_6_6_SystemObject bevt_149_ta_ph = null;
BEC_2_6_6_SystemObject bevt_150_ta_ph = null;
BEC_2_6_6_SystemObject bevt_151_ta_ph = null;
BEC_2_6_6_SystemObject bevt_152_ta_ph = null;
BEC_2_4_6_TextString bevt_153_ta_ph = null;
BEC_2_6_6_SystemObject bevt_154_ta_ph = null;
BEC_2_5_4_LogicBool bevt_155_ta_ph = null;
BEC_2_6_6_SystemObject bevt_156_ta_ph = null;
BEC_2_5_4_LogicBool bevt_157_ta_ph = null;
BEC_2_5_3_BuildVar bevt_158_ta_ph = null;
BEC_2_6_6_SystemObject bevt_159_ta_ph = null;
BEC_2_5_4_LogicBool bevt_160_ta_ph = null;
BEC_2_6_6_SystemObject bevt_161_ta_ph = null;
BEC_2_5_4_LogicBool bevt_162_ta_ph = null;
BEC_2_6_6_SystemObject bevt_163_ta_ph = null;
BEC_2_5_4_LogicBool bevt_164_ta_ph = null;
BEC_2_6_6_SystemObject bevt_165_ta_ph = null;
BEC_2_5_4_LogicBool bevt_166_ta_ph = null;
BEC_2_6_6_SystemObject bevt_167_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_168_ta_ph = null;
BEC_2_4_6_TextString bevt_169_ta_ph = null;
BEC_2_6_6_SystemObject bevt_170_ta_ph = null;
BEC_2_6_6_SystemObject bevt_171_ta_ph = null;
BEC_2_6_6_SystemObject bevt_172_ta_ph = null;
BEC_2_6_6_SystemObject bevt_173_ta_ph = null;
BEC_2_6_6_SystemObject bevt_174_ta_ph = null;
BEC_2_5_4_BuildNode bevt_175_ta_ph = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_ta_ph = beva_node.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_EMITGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 21*/ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_12_ta_ph = beva_node.bem_containedGet_0();
if (bevt_12_ta_ph == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_15_ta_ph = beva_node.bem_containedGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_lengthGet_0();
bevt_16_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_14_ta_ph.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_20_ta_ph = beva_node.bem_containedGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_firstGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(1427477189);
if (bevt_18_ta_ph == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_25_ta_ph = beva_node.bem_containedGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bem_firstGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_0(1427477189);
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(372427837);
bevt_26_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(1144419489, bevt_26_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 23*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 23*/ {
bevt_30_ta_ph = beva_node.bem_secondGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bem_containedGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bem_lengthGet_0();
bevt_31_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevt_28_ta_ph.bevi_int > bevt_31_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 23*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 23*/
 else /* Line: 23*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 23*/ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_34_ta_ph = beva_node.bem_containedGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(1427477189);
bevt_0_ta_loop = bevt_32_ta_ph.bemd_0(-71162589);
while (true)
/* Line: 26*/ {
bevt_35_ta_ph = bevt_0_ta_loop.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_35_ta_ph).bevi_bool)/* Line: 26*/ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_0_ta_loop.bemd_0(-641452021);
bevt_36_ta_ph = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_36_ta_ph);
} /* Line: 28*/
 else /* Line: 26*/ {
break;
} /* Line: 26*/
} /* Line: 26*/
bevt_37_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_37_ta_ph);
bevl_doit = be.BECS_Runtime.boolTrue;
if (((BEC_2_5_4_LogicBool) bevl_doit).bevi_bool)/* Line: 32*/ {
bevl_doit = be.BECS_Runtime.boolFalse;
bevt_39_ta_ph = beva_node.bem_secondGet_0();
bevt_38_ta_ph = bevt_39_ta_ph.bem_containedGet_0();
bevl_i = bevt_38_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 34*/ {
bevt_40_ta_ph = bevl_i.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 34*/ {
bevl_si = bevl_i.bemd_0(-641452021);
bevt_42_ta_ph = bevl_si.bemd_0(822998896);
bevt_43_ta_ph = bevp_ntypes.bem_STRINGLGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bemd_1(1408797910, bevt_43_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_41_ta_ph).bevi_bool)/* Line: 36*/ {
bevt_44_ta_ph = bevl_si.bemd_0(1211029271);
beva_node.bem_heldSet_1(bevt_44_ta_ph);
bevl_doit = be.BECS_Runtime.boolTrue;
} /* Line: 40*/
} /* Line: 36*/
 else /* Line: 34*/ {
break;
} /* Line: 34*/
} /* Line: 34*/
} /* Line: 34*/
bevt_45_ta_ph = bevl_doit.bemd_0(1203131605);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 44*/ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 46*/
beva_node.bem_containedSet_1(null);
bevt_47_ta_ph = beva_node.bem_heldGet_0();
bevt_46_ta_ph = (BEC_2_5_4_BuildEmit) (new BEC_2_5_4_BuildEmit()).bem_new_2((BEC_2_4_6_TextString) bevt_47_ta_ph , bevl_langs);
beva_node.bem_heldSet_1(bevt_46_ta_ph);
} /* Line: 49*/
 else /* Line: 50*/ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 52*/
bevl_snode = beva_node.bem_scopeGet_0();
bevt_49_ta_ph = bevl_snode.bemd_0(822998896);
bevt_50_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_48_ta_ph = bevt_49_ta_ph.bemd_1(1408797910, bevt_50_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 56*/ {
bevl_snode = null;
} /* Line: 57*/
if (bevl_snode == null) {
bevt_51_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_51_ta_ph.bevi_bool)/* Line: 60*/ {
beva_node.bem_delete_0();
bevt_52_ta_ph = bevl_snode.bemd_0(1211029271);
bevt_52_ta_ph.bemd_1(1523229808, beva_node);
} /* Line: 62*/
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 65*/
 else /* Line: 21*/ {
bevt_54_ta_ph = beva_node.bem_typenameGet_0();
bevt_55_ta_ph = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_54_ta_ph.bevi_int == bevt_55_ta_ph.bevi_int) {
bevt_53_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_53_ta_ph.bevi_bool)/* Line: 66*/ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_58_ta_ph = beva_node.bem_containedGet_0();
bevt_57_ta_ph = bevt_58_ta_ph.bem_firstGet_0();
bevt_56_ta_ph = bevt_57_ta_ph.bemd_0(1427477189);
bevt_1_ta_loop = bevt_56_ta_ph.bemd_0(-71162589);
while (true)
/* Line: 69*/ {
bevt_59_ta_ph = bevt_1_ta_loop.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 69*/ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_1_ta_loop.bemd_0(-641452021);
bevt_60_ta_ph = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_60_ta_ph);
bevl_toremove.bemd_1(1628522769, bevl_lang);
} /* Line: 72*/
 else /* Line: 69*/ {
break;
} /* Line: 69*/
} /* Line: 69*/
bevt_61_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_61_ta_ph);
bevt_63_ta_ph = beva_node.bem_heldGet_0();
bevt_62_ta_ph = (BEC_2_5_6_BuildIfEmit) (new BEC_2_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_2_4_6_TextString) bevt_63_ta_ph );
beva_node.bem_heldSet_1(bevt_62_ta_ph);
bevl_ii = bevl_toremove.bemd_0(-71162589);
while (true)
/* Line: 76*/ {
bevt_64_ta_ph = bevl_ii.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 76*/ {
bevl_i = bevl_ii.bemd_0(-641452021);
bevl_i.bemd_0(1547390618);
} /* Line: 78*/
 else /* Line: 76*/ {
break;
} /* Line: 76*/
} /* Line: 76*/
} /* Line: 76*/
 else /* Line: 21*/ {
bevt_66_ta_ph = beva_node.bem_typenameGet_0();
bevt_67_ta_ph = bevp_ntypes.bem_IFGet_0();
if (bevt_66_ta_ph.bevi_int == bevt_67_ta_ph.bevi_int) {
bevt_65_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_65_ta_ph.bevi_bool)/* Line: 80*/ {
if (bevl_nnode == null) {
bevt_68_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_68_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_68_ta_ph.bevi_bool)/* Line: 81*/ {
bevl_lnode = beva_node;
while (true)
/* Line: 83*/ {
if (bevl_nnode == null) {
bevt_69_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_69_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_69_ta_ph.bevi_bool)/* Line: 83*/ {
bevt_71_ta_ph = bevl_nnode.bemd_0(822998896);
bevt_72_ta_ph = bevp_ntypes.bem_ELIFGet_0();
bevt_70_ta_ph = bevt_71_ta_ph.bemd_1(1408797910, bevt_72_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_70_ta_ph).bevi_bool)/* Line: 83*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 83*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 83*/
 else /* Line: 83*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 83*/ {
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_73_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(27083027, bevt_73_ta_ph);
bevl_enode.bemd_1(-1226564681, beva_node);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(-1226564681, beva_node);
bevt_74_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(27083027, bevt_74_ta_ph);
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(-1226564681, beva_node);
bevt_75_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(27083027, bevt_75_ta_ph);
bevl_brnode.bemd_1(1628522769, bevl_inode);
bevl_enode.bemd_1(1628522769, bevl_brnode);
bevt_77_ta_ph = bevl_nnode.bemd_0(1427477189);
if (bevt_77_ta_ph == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 95*/ {
bevt_78_ta_ph = bevl_nnode.bemd_0(1427477189);
bevl_i = bevt_78_ta_ph.bemd_0(-71162589);
while (true)
/* Line: 96*/ {
bevt_79_ta_ph = bevl_i.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_79_ta_ph).bevi_bool)/* Line: 96*/ {
bevt_80_ta_ph = bevl_i.bemd_0(-641452021);
bevl_inode.bemd_1(1628522769, bevt_80_ta_ph);
} /* Line: 97*/
 else /* Line: 96*/ {
break;
} /* Line: 96*/
} /* Line: 96*/
} /* Line: 96*/
bevl_lnode.bemd_1(1628522769, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(345274613);
bevl_nnode.bemd_0(1547390618);
bevl_nnode = bevl_nxnode;
} /* Line: 108*/
 else /* Line: 83*/ {
break;
} /* Line: 83*/
} /* Line: 83*/
if (bevl_nnode == null) {
bevt_81_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_81_ta_ph.bevi_bool)/* Line: 110*/ {
bevt_83_ta_ph = bevl_nnode.bemd_0(822998896);
bevt_84_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevt_82_ta_ph = bevt_83_ta_ph.bemd_1(1408797910, bevt_84_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_82_ta_ph).bevi_bool)/* Line: 110*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 110*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 110*/
 else /* Line: 110*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 110*/ {
bevl_nnode.bemd_0(1547390618);
bevl_lnode.bemd_1(1628522769, bevl_nnode);
} /* Line: 112*/
} /* Line: 110*/
bevt_85_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_85_ta_ph;
} /* Line: 115*/
 else /* Line: 21*/ {
bevt_87_ta_ph = beva_node.bem_typenameGet_0();
bevt_88_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_87_ta_ph.bevi_int == bevt_88_ta_ph.bevi_int) {
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 116*/ {
bevt_89_ta_ph = beva_node.bem_containedGet_0();
bevl_parens = bevt_89_ta_ph.bem_firstGet_0();
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(-1226564681, beva_node);
bevt_90_ta_ph = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(27083027, bevt_90_ta_ph);
bevt_91_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevl_nd.bemd_1(1854508188, bevt_91_ta_ph);
bevl_parens.bemd_1(-445030395, bevl_nd);
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_2_4_3_MathInt(0));
bevt_92_ta_ph = bevl_parens.bemd_0(1427477189);
bevl_ii = bevt_92_ta_ph.bemd_0(-71162589);
while (true)
/* Line: 125*/ {
bevt_93_ta_ph = bevl_ii.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_93_ta_ph).bevi_bool)/* Line: 125*/ {
bevl_i = bevl_ii.bemd_0(-641452021);
bevl_ix = bevl_i.bemd_0(345274613);
bevt_95_ta_ph = bevl_i.bemd_0(822998896);
bevt_96_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_94_ta_ph = bevt_95_ta_ph.bemd_1(1408797910, bevt_96_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_94_ta_ph).bevi_bool)/* Line: 130*/ {
bevl_toremove.bemd_1(1628522769, bevl_i);
} /* Line: 131*/
 else /* Line: 130*/ {
bevt_98_ta_ph = bevl_i.bemd_0(822998896);
bevt_99_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_97_ta_ph = bevt_98_ta_ph.bemd_1(1408797910, bevt_99_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_97_ta_ph).bevi_bool)/* Line: 132*/ {
bevt_100_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(1688096367, bevt_100_ta_ph);
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_101_ta_ph = bevl_i.bemd_0(1211029271);
bevl_v.bemd_1(1432148458, bevt_101_ta_ph);
bevt_102_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1124391433, bevt_102_ta_ph);
bevl_i.bemd_1(1854508188, bevl_v);
bevt_103_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(27083027, bevt_103_ta_ph);
bevl_i.bemd_0(808862472);
} /* Line: 139*/
 else /* Line: 130*/ {
bevt_105_ta_ph = bevl_i.bemd_0(822998896);
bevt_106_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_104_ta_ph = bevt_105_ta_ph.bemd_1(1408797910, bevt_106_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_104_ta_ph).bevi_bool)/* Line: 140*/ {
bevt_108_ta_ph = bevl_ix.bemd_0(822998896);
bevt_109_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_107_ta_ph = bevt_108_ta_ph.bemd_1(1408797910, bevt_109_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_107_ta_ph).bevi_bool)/* Line: 141*/ {
bevt_110_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(1688096367, bevt_110_ta_ph);
bevt_111_ta_ph = bevl_i.bemd_0(1211029271);
bevt_112_ta_ph = bevl_ix.bemd_0(1211029271);
bevt_111_ta_ph.bemd_1(1432148458, bevt_112_ta_ph);
bevt_113_ta_ph = bevl_i.bemd_0(1211029271);
bevt_114_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_113_ta_ph.bemd_1(-1124391433, bevt_114_ta_ph);
bevl_i.bemd_0(808862472);
bevt_115_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(27083027, bevt_115_ta_ph);
} /* Line: 146*/
 else /* Line: 147*/ {
bevt_117_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bece_BEC_3_5_5_5_BuildVisitPass6_bels_2));
bevt_116_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_117_ta_ph, bevl_i);
throw new be.BECS_ThrowBack(bevt_116_ta_ph);
} /* Line: 148*/
} /* Line: 141*/
} /* Line: 130*/
} /* Line: 130*/
} /* Line: 130*/
 else /* Line: 125*/ {
break;
} /* Line: 125*/
} /* Line: 125*/
bevl_ii = bevl_toremove.bemd_0(-71162589);
while (true)
/* Line: 152*/ {
bevt_118_ta_ph = bevl_ii.bemd_0(1610238730);
if (((BEC_2_5_4_LogicBool) bevt_118_ta_ph).bevi_bool)/* Line: 152*/ {
bevl_i = bevl_ii.bemd_0(-641452021);
bevl_i.bemd_0(1547390618);
} /* Line: 154*/
 else /* Line: 152*/ {
break;
} /* Line: 152*/
} /* Line: 152*/
bevl_s = beva_node.bem_heldGet_0();
bevt_120_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_119_ta_ph = bevl_numargs.bemd_1(732494249, bevt_120_ta_ph);
bevl_s.bemd_1(-1401820039, bevt_119_ta_ph);
bevt_121_ta_ph = bevl_s.bemd_0(-2079457415);
bevl_s.bemd_1(1071153415, bevt_121_ta_ph);
bevt_124_ta_ph = bevl_s.bemd_0(-2079457415);
bevt_125_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_3));
bevt_123_ta_ph = bevt_124_ta_ph.bemd_1(1688096367, bevt_125_ta_ph);
bevt_127_ta_ph = bevl_s.bemd_0(13052882);
bevt_126_ta_ph = bevt_127_ta_ph.bemd_0(350691792);
bevt_122_ta_ph = bevt_123_ta_ph.bemd_1(1688096367, bevt_126_ta_ph);
bevl_s.bemd_1(1432148458, bevt_122_ta_ph);
bevl_i = beva_node.bem_secondGet_0();
bevt_129_ta_ph = bevl_i.bemd_0(822998896);
bevt_130_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_128_ta_ph = bevt_129_ta_ph.bemd_1(1408797910, bevt_130_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_128_ta_ph).bevi_bool)/* Line: 161*/ {
bevl_i.bemd_0(-133249146);
bevt_131_ta_ph = bevl_i.bemd_0(1211029271);
bevl_s.bemd_1(2116047345, bevt_131_ta_ph);
bevt_134_ta_ph = bevl_s.bemd_0(1687812743);
bevt_133_ta_ph = bevt_134_ta_ph.bemd_0(-507142367);
if (bevt_133_ta_ph == null) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 165*/ {
bevl_s.bemd_1(2116047345, null);
} /* Line: 167*/
 else /* Line: 165*/ {
bevt_138_ta_ph = bevl_s.bemd_0(1687812743);
bevt_137_ta_ph = bevt_138_ta_ph.bemd_0(-507142367);
bevt_136_ta_ph = bevt_137_ta_ph.bemd_0(350691792);
bevt_139_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_4));
bevt_135_ta_ph = bevt_136_ta_ph.bemd_1(1408797910, bevt_139_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_135_ta_ph).bevi_bool)/* Line: 168*/ {
bevt_140_ta_ph = bevl_s.bemd_0(1687812743);
bevt_141_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_140_ta_ph.bemd_1(26784630, bevt_141_ta_ph);
bevt_142_ta_ph = bevl_s.bemd_0(1687812743);
bevt_143_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_142_ta_ph.bemd_1(-1718945060, bevt_143_ta_ph);
bevt_144_ta_ph = bevl_s.bemd_0(1687812743);
bevt_145_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_144_ta_ph.bemd_1(604692883, bevt_145_ta_ph);
bevt_147_ta_ph = bevl_s.bemd_0(1687812743);
bevt_146_ta_ph = bevt_147_ta_ph.bemd_0(-507142367);
bevt_148_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_146_ta_ph.bemd_1(130133381, bevt_148_ta_ph);
} /* Line: 173*/
 else /* Line: 165*/ {
bevt_152_ta_ph = bevl_s.bemd_0(1687812743);
bevt_151_ta_ph = bevt_152_ta_ph.bemd_0(-507142367);
bevt_150_ta_ph = bevt_151_ta_ph.bemd_0(350691792);
bevt_153_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_149_ta_ph = bevt_150_ta_ph.bemd_1(1408797910, bevt_153_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_149_ta_ph).bevi_bool)/* Line: 174*/ {
bevt_154_ta_ph = bevl_s.bemd_0(1687812743);
bevt_155_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_154_ta_ph.bemd_1(26784630, bevt_155_ta_ph);
bevt_156_ta_ph = bevl_s.bemd_0(1687812743);
bevt_157_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_156_ta_ph.bemd_1(-1718945060, bevt_157_ta_ph);
} /* Line: 176*/
} /* Line: 165*/
} /* Line: 165*/
bevl_i.bemd_0(1547390618);
} /* Line: 178*/
 else /* Line: 179*/ {
bevt_158_ta_ph = (BEC_2_5_3_BuildVar) (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_s.bemd_1(2116047345, bevt_158_ta_ph);
bevt_159_ta_ph = bevl_s.bemd_0(1687812743);
bevt_160_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_159_ta_ph.bemd_1(26784630, bevt_160_ta_ph);
bevt_161_ta_ph = bevl_s.bemd_0(1687812743);
bevt_162_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_161_ta_ph.bemd_1(-1718945060, bevt_162_ta_ph);
bevt_163_ta_ph = bevl_s.bemd_0(1687812743);
bevt_164_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_163_ta_ph.bemd_1(604692883, bevt_164_ta_ph);
bevt_165_ta_ph = bevl_s.bemd_0(1687812743);
bevt_166_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_165_ta_ph.bemd_1(-122291698, bevt_166_ta_ph);
bevt_167_ta_ph = bevl_s.bemd_0(1687812743);
bevt_169_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_168_ta_ph = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_169_ta_ph);
bevt_167_ta_ph.bemd_1(-1542637157, bevt_168_ta_ph);
} /* Line: 185*/
bevl_clnode = beva_node.bem_classGet_0();
bevt_171_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_170_ta_ph = bevt_171_ta_ph.bemd_0(-1084736512);
bevt_172_ta_ph = bevl_s.bemd_0(-2079457415);
bevt_170_ta_ph.bemd_2(1920178007, bevt_172_ta_ph, beva_node);
bevt_174_ta_ph = bevl_clnode.bemd_0(1211029271);
bevt_173_ta_ph = bevt_174_ta_ph.bemd_0(-966549718);
bevt_173_ta_ph.bemd_1(1628522769, beva_node);
} /* Line: 189*/
} /* Line: 21*/
} /* Line: 21*/
} /* Line: 21*/
bevt_175_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_175_ta_ph;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 20, 21, 21, 21, 21, 22, 23, 23, 23, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 23, 0, 0, 0, 25, 26, 26, 26, 26, 0, 26, 26, 28, 28, 30, 30, 31, 33, 34, 34, 34, 34, 35, 36, 36, 36, 37, 37, 40, 44, 45, 46, 48, 49, 49, 49, 51, 52, 55, 56, 56, 56, 57, 60, 60, 61, 62, 62, 65, 66, 66, 66, 66, 67, 68, 69, 69, 69, 69, 0, 69, 69, 71, 71, 72, 74, 74, 75, 75, 75, 76, 76, 77, 78, 80, 80, 80, 80, 81, 81, 82, 83, 83, 83, 83, 83, 0, 0, 0, 84, 85, 85, 86, 87, 88, 89, 89, 90, 91, 92, 92, 93, 94, 95, 95, 95, 96, 96, 96, 97, 97, 104, 105, 106, 107, 108, 110, 110, 110, 110, 110, 0, 0, 0, 111, 112, 115, 115, 116, 116, 116, 116, 117, 117, 118, 119, 120, 120, 121, 121, 122, 123, 124, 125, 125, 125, 126, 127, 130, 130, 130, 131, 132, 132, 132, 133, 133, 134, 135, 135, 136, 136, 137, 138, 138, 139, 140, 140, 140, 141, 141, 141, 142, 142, 143, 143, 143, 144, 144, 144, 145, 146, 146, 148, 148, 148, 152, 152, 153, 154, 156, 157, 157, 157, 158, 158, 159, 159, 159, 159, 159, 159, 159, 160, 161, 161, 161, 162, 164, 164, 165, 165, 165, 165, 167, 168, 168, 168, 168, 168, 170, 170, 170, 171, 171, 171, 172, 172, 172, 173, 173, 173, 173, 174, 174, 174, 174, 174, 175, 175, 175, 176, 176, 176, 178, 180, 180, 181, 181, 181, 182, 182, 182, 183, 183, 183, 184, 184, 184, 185, 185, 185, 185, 187, 188, 188, 188, 188, 189, 189, 189, 191, 191};
public static new int[] bevs_smnlec
 = new int[] {218, 219, 220, 221, 222, 227, 228, 229, 230, 235, 236, 237, 238, 239, 244, 245, 248, 252, 255, 256, 257, 258, 263, 264, 267, 271, 274, 275, 276, 277, 278, 279, 281, 284, 288, 291, 292, 293, 294, 295, 300, 301, 304, 308, 311, 312, 313, 314, 315, 315, 318, 320, 321, 322, 328, 329, 330, 332, 333, 334, 335, 338, 340, 341, 342, 343, 345, 346, 347, 355, 357, 358, 360, 361, 362, 363, 366, 367, 369, 370, 371, 372, 374, 376, 381, 382, 383, 384, 386, 389, 390, 391, 396, 397, 398, 399, 400, 401, 402, 402, 405, 407, 408, 409, 410, 416, 417, 418, 419, 420, 421, 424, 426, 427, 435, 436, 437, 442, 443, 448, 449, 452, 457, 458, 459, 460, 462, 465, 469, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 492, 493, 494, 497, 499, 500, 507, 508, 509, 510, 511, 517, 522, 523, 524, 525, 527, 530, 534, 537, 538, 541, 542, 545, 546, 547, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 568, 570, 571, 572, 573, 574, 576, 579, 580, 581, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 596, 597, 598, 600, 601, 602, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 617, 618, 619, 629, 632, 634, 635, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 659, 660, 661, 662, 663, 664, 669, 670, 673, 674, 675, 676, 677, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 694, 695, 696, 697, 698, 700, 701, 702, 703, 704, 705, 709, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 731, 732, 733, 734, 735, 736, 737, 738, 743, 744};
/* BEGIN LINEINFO 
resolveNp 0 17 218
assign 1 20 219
nextPeerGet 0 20 219
assign 1 21 220
typenameGet 0 21 220
assign 1 21 221
EMITGet 0 21 221
assign 1 21 222
equals 1 21 227
assign 1 22 228
nextAscendGet 0 22 228
assign 1 23 229
containedGet 0 23 229
assign 1 23 230
def 1 23 235
assign 1 23 236
containedGet 0 23 236
assign 1 23 237
lengthGet 0 23 237
assign 1 23 238
new 0 23 238
assign 1 23 239
greater 1 23 244
assign 1 0 245
assign 1 0 248
assign 1 0 252
assign 1 23 255
containedGet 0 23 255
assign 1 23 256
firstGet 0 23 256
assign 1 23 257
containedGet 0 23 257
assign 1 23 258
def 1 23 263
assign 1 0 264
assign 1 0 267
assign 1 0 271
assign 1 23 274
containedGet 0 23 274
assign 1 23 275
firstGet 0 23 275
assign 1 23 276
containedGet 0 23 276
assign 1 23 277
lengthGet 0 23 277
assign 1 23 278
new 0 23 278
assign 1 23 279
greater 1 23 279
assign 1 0 281
assign 1 0 284
assign 1 0 288
assign 1 23 291
secondGet 0 23 291
assign 1 23 292
containedGet 0 23 292
assign 1 23 293
lengthGet 0 23 293
assign 1 23 294
new 0 23 294
assign 1 23 295
greater 1 23 300
assign 1 0 301
assign 1 0 304
assign 1 0 308
assign 1 25 311
new 0 25 311
assign 1 26 312
containedGet 0 26 312
assign 1 26 313
firstGet 0 26 313
assign 1 26 314
containedGet 0 26 314
assign 1 26 315
iteratorGet 0 0 315
assign 1 26 318
hasNextGet 0 26 318
assign 1 26 320
nextGet 0 26 320
assign 1 28 321
heldGet 0 28 321
addValue 1 28 322
assign 1 30 328
new 0 30 328
delete 1 30 329
assign 1 31 330
new 0 31 330
assign 1 33 332
new 0 33 332
assign 1 34 333
secondGet 0 34 333
assign 1 34 334
containedGet 0 34 334
assign 1 34 335
iteratorGet 0 34 335
assign 1 34 338
hasNextGet 0 34 338
assign 1 35 340
nextGet 0 35 340
assign 1 36 341
typenameGet 0 36 341
assign 1 36 342
STRINGLGet 0 36 342
assign 1 36 343
equals 1 36 343
assign 1 37 345
heldGet 0 37 345
heldSet 1 37 346
assign 1 40 347
new 0 40 347
assign 1 44 355
not 0 44 355
delete 0 45 357
return 1 46 358
containedSet 1 48 360
assign 1 49 361
heldGet 0 49 361
assign 1 49 362
new 2 49 362
heldSet 1 49 363
delete 0 51 366
return 1 52 367
assign 1 55 369
scopeGet 0 55 369
assign 1 56 370
typenameGet 0 56 370
assign 1 56 371
METHODGet 0 56 371
assign 1 56 372
equals 1 56 372
assign 1 57 374
assign 1 60 376
def 1 60 381
delete 0 61 382
assign 1 62 383
heldGet 0 62 383
addEmit 1 62 384
return 1 65 386
assign 1 66 389
typenameGet 0 66 389
assign 1 66 390
IFEMITGet 0 66 390
assign 1 66 391
equals 1 66 396
assign 1 67 397
new 0 67 397
assign 1 68 398
new 0 68 398
assign 1 69 399
containedGet 0 69 399
assign 1 69 400
firstGet 0 69 400
assign 1 69 401
containedGet 0 69 401
assign 1 69 402
iteratorGet 0 0 402
assign 1 69 405
hasNextGet 0 69 405
assign 1 69 407
nextGet 0 69 407
assign 1 71 408
heldGet 0 71 408
addValue 1 71 409
addValue 1 72 410
assign 1 74 416
new 0 74 416
delete 1 74 417
assign 1 75 418
heldGet 0 75 418
assign 1 75 419
new 2 75 419
heldSet 1 75 420
assign 1 76 421
iteratorGet 0 76 421
assign 1 76 424
hasNextGet 0 76 424
assign 1 77 426
nextGet 0 77 426
delete 0 78 427
assign 1 80 435
typenameGet 0 80 435
assign 1 80 436
IFGet 0 80 436
assign 1 80 437
equals 1 80 442
assign 1 81 443
def 1 81 448
assign 1 82 449
assign 1 83 452
def 1 83 457
assign 1 83 458
typenameGet 0 83 458
assign 1 83 459
ELIFGet 0 83 459
assign 1 83 460
equals 1 83 460
assign 1 0 462
assign 1 0 465
assign 1 0 469
assign 1 84 472
new 1 84 472
assign 1 85 473
ELSEGet 0 85 473
typenameSet 1 85 474
copyLoc 1 86 475
assign 1 87 476
new 1 87 476
copyLoc 1 88 477
assign 1 89 478
BRACESGet 0 89 478
typenameSet 1 89 479
assign 1 90 480
new 1 90 480
copyLoc 1 91 481
assign 1 92 482
IFGet 0 92 482
typenameSet 1 92 483
addValue 1 93 484
addValue 1 94 485
assign 1 95 486
containedGet 0 95 486
assign 1 95 487
def 1 95 492
assign 1 96 493
containedGet 0 96 493
assign 1 96 494
iteratorGet 0 96 494
assign 1 96 497
hasNextGet 0 96 497
assign 1 97 499
nextGet 0 97 499
addValue 1 97 500
addValue 1 104 507
assign 1 105 508
assign 1 106 509
nextPeerGet 0 106 509
delete 0 107 510
assign 1 108 511
assign 1 110 517
def 1 110 522
assign 1 110 523
typenameGet 0 110 523
assign 1 110 524
ELSEGet 0 110 524
assign 1 110 525
equals 1 110 525
assign 1 0 527
assign 1 0 530
assign 1 0 534
delete 0 111 537
addValue 1 112 538
assign 1 115 541
nextDescendGet 0 115 541
return 1 115 542
assign 1 116 545
typenameGet 0 116 545
assign 1 116 546
METHODGet 0 116 546
assign 1 116 547
equals 1 116 552
assign 1 117 553
containedGet 0 117 553
assign 1 117 554
firstGet 0 117 554
assign 1 118 555
new 1 118 555
copyLoc 1 119 556
assign 1 120 557
IDGet 0 120 557
typenameSet 1 120 558
assign 1 121 559
new 0 121 559
heldSet 1 121 560
prepend 1 122 561
assign 1 123 562
new 0 123 562
assign 1 124 563
new 0 124 563
assign 1 125 564
containedGet 0 125 564
assign 1 125 565
iteratorGet 0 125 565
assign 1 125 568
hasNextGet 0 125 568
assign 1 126 570
nextGet 0 126 570
assign 1 127 571
nextPeerGet 0 127 571
assign 1 130 572
typenameGet 0 130 572
assign 1 130 573
COMMAGet 0 130 573
assign 1 130 574
equals 1 130 574
addValue 1 131 576
assign 1 132 579
typenameGet 0 132 579
assign 1 132 580
IDGet 0 132 580
assign 1 132 581
equals 1 132 581
assign 1 133 583
new 0 133 583
assign 1 133 584
add 1 133 584
assign 1 134 585
new 0 134 585
assign 1 135 586
heldGet 0 135 586
nameSet 1 135 587
assign 1 136 588
new 0 136 588
isArgSet 1 136 589
heldSet 1 137 590
assign 1 138 591
VARGet 0 138 591
typenameSet 1 138 592
addVariable 0 139 593
assign 1 140 596
typenameGet 0 140 596
assign 1 140 597
VARGet 0 140 597
assign 1 140 598
equals 1 140 598
assign 1 141 600
typenameGet 0 141 600
assign 1 141 601
IDGet 0 141 601
assign 1 141 602
equals 1 141 602
assign 1 142 604
new 0 142 604
assign 1 142 605
add 1 142 605
assign 1 143 606
heldGet 0 143 606
assign 1 143 607
heldGet 0 143 607
nameSet 1 143 608
assign 1 144 609
heldGet 0 144 609
assign 1 144 610
new 0 144 610
isArgSet 1 144 611
addVariable 0 145 612
assign 1 146 613
COMMAGet 0 146 613
typenameSet 1 146 614
assign 1 148 617
new 0 148 617
assign 1 148 618
new 2 148 618
throw 1 148 619
assign 1 152 629
iteratorGet 0 152 629
assign 1 152 632
hasNextGet 0 152 632
assign 1 153 634
nextGet 0 153 634
delete 0 154 635
assign 1 156 641
heldGet 0 156 641
assign 1 157 642
new 0 157 642
assign 1 157 643
subtract 1 157 643
numargsSet 1 157 644
assign 1 158 645
nameGet 0 158 645
orgNameSet 1 158 646
assign 1 159 647
nameGet 0 159 647
assign 1 159 648
new 0 159 648
assign 1 159 649
add 1 159 649
assign 1 159 650
numargsGet 0 159 650
assign 1 159 651
toString 0 159 651
assign 1 159 652
add 1 159 652
nameSet 1 159 653
assign 1 160 654
secondGet 0 160 654
assign 1 161 655
typenameGet 0 161 655
assign 1 161 656
VARGet 0 161 656
assign 1 161 657
equals 1 161 657
resolveNp 0 162 659
assign 1 164 660
heldGet 0 164 660
rtypeSet 1 164 661
assign 1 165 662
rtypeGet 0 165 662
assign 1 165 663
namepathGet 0 165 663
assign 1 165 664
undef 1 165 669
rtypeSet 1 167 670
assign 1 168 673
rtypeGet 0 168 673
assign 1 168 674
namepathGet 0 168 674
assign 1 168 675
toString 0 168 675
assign 1 168 676
new 0 168 676
assign 1 168 677
equals 1 168 677
assign 1 170 679
rtypeGet 0 170 679
assign 1 170 680
new 0 170 680
isTypedSet 1 170 681
assign 1 171 682
rtypeGet 0 171 682
assign 1 171 683
new 0 171 683
isSelfSet 1 171 684
assign 1 172 685
rtypeGet 0 172 685
assign 1 172 686
new 0 172 686
isThisSet 1 172 687
assign 1 173 688
rtypeGet 0 173 688
assign 1 173 689
namepathGet 0 173 689
assign 1 173 690
new 0 173 690
pathSet 1 173 691
assign 1 174 694
rtypeGet 0 174 694
assign 1 174 695
namepathGet 0 174 695
assign 1 174 696
toString 0 174 696
assign 1 174 697
new 0 174 697
assign 1 174 698
equals 1 174 698
assign 1 175 700
rtypeGet 0 175 700
assign 1 175 701
new 0 175 701
isTypedSet 1 175 702
assign 1 176 703
rtypeGet 0 176 703
assign 1 176 704
new 0 176 704
isSelfSet 1 176 705
delete 0 178 709
assign 1 180 712
new 0 180 712
rtypeSet 1 180 713
assign 1 181 714
rtypeGet 0 181 714
assign 1 181 715
new 0 181 715
isTypedSet 1 181 716
assign 1 182 717
rtypeGet 0 182 717
assign 1 182 718
new 0 182 718
isSelfSet 1 182 719
assign 1 183 720
rtypeGet 0 183 720
assign 1 183 721
new 0 183 721
isThisSet 1 183 722
assign 1 184 723
rtypeGet 0 184 723
assign 1 184 724
new 0 184 724
impliedSet 1 184 725
assign 1 185 726
rtypeGet 0 185 726
assign 1 185 727
new 0 185 727
assign 1 185 728
new 1 185 728
namepathSet 1 185 729
assign 1 187 731
classGet 0 187 731
assign 1 188 732
heldGet 0 188 732
assign 1 188 733
methodsGet 0 188 733
assign 1 188 734
nameGet 0 188 734
put 2 188 735
assign 1 189 736
heldGet 0 189 736
assign 1 189 737
orderedMethodsGet 0 189 737
addValue 1 189 738
assign 1 191 743
nextDescendGet 0 191 743
return 1 191 744
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -652053502: return bem_fieldNamesGet_0();
case -1893075648: return bem_buildGetDirect_0();
case 944073339: return bem_fieldIteratorGet_0();
case -1785724794: return bem_once_0();
case -1251441948: return bem_buildGet_0();
case -1480556491: return bem_toAny_0();
case 168135582: return bem_create_0();
case -884149543: return bem_constGet_0();
case 2132420479: return bem_many_0();
case -1359614197: return bem_classNameGet_0();
case -417851647: return bem_transGetDirect_0();
case 1803787653: return bem_transGet_0();
case -1044758745: return bem_serializeToString_0();
case 759496930: return bem_tagGet_0();
case 350691792: return bem_toString_0();
case 814334258: return bem_serializeContents_0();
case 1043004008: return bem_constGetDirect_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -1642361296: return bem_print_0();
case 424617382: return bem_ntypesGetDirect_0();
case -202912463: return bem_copy_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 1365897346: return bem_serializationIteratorGet_0();
case 2096109526: return bem_ntypesGet_0();
case 1161638424: return bem_new_0();
case -71162589: return bem_iteratorGet_0();
case -1711670377: return bem_hashGet_0();
case 2064925791: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1142023380: return bem_begin_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case 819746231: return bem_buildSet_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -164810505: return bem_ntypesSet_1(bevd_0);
case -990686106: return bem_constSetDirect_1(bevd_0);
case 1623208395: return bem_end_1(bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case -1458431940: return bem_ntypesSetDirect_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case -1061601401: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case -1055205804: return bem_buildSetDirect_1(bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1880603529: return bem_transSetDirect_1(bevd_0);
case -548044674: return bem_transSet_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case -965959383: return bem_constSet_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass6_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass6_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass6();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst = (BEC_3_5_5_5_BuildVisitPass6) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;
}
}
}
