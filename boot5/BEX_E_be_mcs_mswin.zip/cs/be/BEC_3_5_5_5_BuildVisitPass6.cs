namespace be {
/* IO:File: source/build/Pass6.be */
public sealed class BEC_3_5_5_5_BuildVisitPass6 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass6() { }
static BEC_3_5_5_5_BuildVisitPass6() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_5_BuildVisitPass6_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_5_BuildVisitPass6_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_0 = {0x2C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_1 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_2 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_3 = {0x5F};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_4 = {0x74,0x68,0x69,0x73};
public static new BEC_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;

public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_9_3_ContainerSet bevl_langs = null;
BEC_2_5_4_BuildNode bevl_lang = null;
BEC_2_6_6_SystemObject bevl_doit = null;
BEC_2_6_6_SystemObject bevl_si = null;
BEC_2_6_6_SystemObject bevl_snode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_nxnode = null;
BEC_2_6_6_SystemObject bevl_parens = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_numargs = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vid = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_38_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_5_4_BuildEmit bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_6_BuildIfEmit bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_4_6_TextString bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpany_phold = null;
BEC_2_4_6_TextString bevt_153_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_155_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_5_3_BuildVar bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_164_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_166_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_168_tmpany_phold = null;
BEC_2_4_6_TextString bevt_169_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_175_tmpany_phold = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 21 */ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_12_tmpany_phold = beva_node.bem_containedGet_0();
if (bevt_12_tmpany_phold == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 23 */ {
bevt_15_tmpany_phold = beva_node.bem_containedGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_lengthGet_0();
bevt_16_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass6_bevo_0;
if (bevt_14_tmpany_phold.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 23 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 23 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 23 */
 else  /* Line: 23 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 23 */ {
bevt_20_tmpany_phold = beva_node.bem_containedGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1732440824);
if (bevt_18_tmpany_phold == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 23 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 23 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 23 */
 else  /* Line: 23 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 23 */ {
bevt_25_tmpany_phold = beva_node.bem_containedGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_firstGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(-1732440824);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(-430554763);
bevt_26_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(1163460144, bevt_26_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 23 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 23 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 23 */
 else  /* Line: 23 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 23 */ {
bevt_30_tmpany_phold = beva_node.bem_secondGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_containedGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_lengthGet_0();
bevt_31_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass6_bevo_1;
if (bevt_28_tmpany_phold.bevi_int > bevt_31_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 23 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 23 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 23 */
 else  /* Line: 23 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 23 */ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_34_tmpany_phold = beva_node.bem_containedGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(-1732440824);
bevt_0_tmpany_loop = bevt_32_tmpany_phold.bemd_0(812685421);
while (true)
 /* Line: 26 */ {
bevt_35_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-383924366);
if (((BEC_2_5_4_LogicBool) bevt_35_tmpany_phold).bevi_bool) /* Line: 26 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(-25303237);
bevt_36_tmpany_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_36_tmpany_phold);
} /* Line: 28 */
 else  /* Line: 26 */ {
break;
} /* Line: 26 */
} /* Line: 26 */
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_37_tmpany_phold);
bevl_doit = be.BECS_Runtime.boolTrue;
if (((BEC_2_5_4_LogicBool) bevl_doit).bevi_bool) /* Line: 32 */ {
bevl_doit = be.BECS_Runtime.boolFalse;
bevt_39_tmpany_phold = beva_node.bem_secondGet_0();
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_containedGet_0();
bevl_i = bevt_38_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 34 */ {
bevt_40_tmpany_phold = bevl_i.bemd_0(-383924366);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 34 */ {
bevl_si = bevl_i.bemd_0(-25303237);
bevt_42_tmpany_phold = bevl_si.bemd_0(-2064042825);
bevt_43_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_1(-886218051, bevt_43_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_41_tmpany_phold).bevi_bool) /* Line: 36 */ {
bevt_44_tmpany_phold = bevl_si.bemd_0(551897597);
beva_node.bem_heldSet_1(bevt_44_tmpany_phold);
bevl_doit = be.BECS_Runtime.boolTrue;
} /* Line: 40 */
} /* Line: 36 */
 else  /* Line: 34 */ {
break;
} /* Line: 34 */
} /* Line: 34 */
} /* Line: 34 */
bevt_45_tmpany_phold = bevl_doit.bemd_0(1168890224);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 44 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 46 */
beva_node.bem_containedSet_1(null);
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = (BEC_2_5_4_BuildEmit) (new BEC_2_5_4_BuildEmit()).bem_new_2((BEC_2_4_6_TextString) bevt_47_tmpany_phold , bevl_langs);
beva_node.bem_heldSet_1(bevt_46_tmpany_phold);
} /* Line: 49 */
 else  /* Line: 50 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 52 */
bevl_snode = beva_node.bem_scopeGet_0();
bevt_49_tmpany_phold = bevl_snode.bemd_0(-2064042825);
bevt_50_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_1(-886218051, bevt_50_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_48_tmpany_phold).bevi_bool) /* Line: 56 */ {
bevl_snode = null;
} /* Line: 57 */
if (bevl_snode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 60 */ {
beva_node.bem_delete_0();
bevt_52_tmpany_phold = bevl_snode.bemd_0(551897597);
bevt_52_tmpany_phold.bemd_1(-1281177462, beva_node);
} /* Line: 62 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 65 */
 else  /* Line: 21 */ {
bevt_54_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_54_tmpany_phold.bevi_int == bevt_55_tmpany_phold.bevi_int) {
bevt_53_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_53_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_58_tmpany_phold = beva_node.bem_containedGet_0();
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_firstGet_0();
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(-1732440824);
bevt_1_tmpany_loop = bevt_56_tmpany_phold.bemd_0(812685421);
while (true)
 /* Line: 69 */ {
bevt_59_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-383924366);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 69 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_1_tmpany_loop.bemd_0(-25303237);
bevt_60_tmpany_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_60_tmpany_phold);
bevl_toremove.bemd_1(-1940917614, bevl_lang);
} /* Line: 72 */
 else  /* Line: 69 */ {
break;
} /* Line: 69 */
} /* Line: 69 */
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_61_tmpany_phold);
bevt_63_tmpany_phold = beva_node.bem_heldGet_0();
bevt_62_tmpany_phold = (BEC_2_5_6_BuildIfEmit) (new BEC_2_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_2_4_6_TextString) bevt_63_tmpany_phold );
beva_node.bem_heldSet_1(bevt_62_tmpany_phold);
bevl_ii = bevl_toremove.bemd_0(812685421);
while (true)
 /* Line: 76 */ {
bevt_64_tmpany_phold = bevl_ii.bemd_0(-383924366);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 76 */ {
bevl_i = bevl_ii.bemd_0(-25303237);
bevl_i.bemd_0(-1845649817);
} /* Line: 78 */
 else  /* Line: 76 */ {
break;
} /* Line: 76 */
} /* Line: 76 */
} /* Line: 76 */
 else  /* Line: 21 */ {
bevt_66_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_67_tmpany_phold = bevp_ntypes.bem_IFGet_0();
if (bevt_66_tmpany_phold.bevi_int == bevt_67_tmpany_phold.bevi_int) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 80 */ {
if (bevl_nnode == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevl_lnode = beva_node;
while (true)
 /* Line: 83 */ {
if (bevl_nnode == null) {
bevt_69_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_69_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_69_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(-2064042825);
bevt_72_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_1(-886218051, bevt_72_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_70_tmpany_phold).bevi_bool) /* Line: 83 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 83 */ {
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_73_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-333229926, bevt_73_tmpany_phold);
bevl_enode.bemd_1(845344653, beva_node);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(845344653, beva_node);
bevt_74_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-333229926, bevt_74_tmpany_phold);
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(845344653, beva_node);
bevt_75_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-333229926, bevt_75_tmpany_phold);
bevl_brnode.bemd_1(-1940917614, bevl_inode);
bevl_enode.bemd_1(-1940917614, bevl_brnode);
bevt_77_tmpany_phold = bevl_nnode.bemd_0(-1732440824);
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_78_tmpany_phold = bevl_nnode.bemd_0(-1732440824);
bevl_i = bevt_78_tmpany_phold.bemd_0(812685421);
while (true)
 /* Line: 96 */ {
bevt_79_tmpany_phold = bevl_i.bemd_0(-383924366);
if (((BEC_2_5_4_LogicBool) bevt_79_tmpany_phold).bevi_bool) /* Line: 96 */ {
bevt_80_tmpany_phold = bevl_i.bemd_0(-25303237);
bevl_inode.bemd_1(-1940917614, bevt_80_tmpany_phold);
} /* Line: 97 */
 else  /* Line: 96 */ {
break;
} /* Line: 96 */
} /* Line: 96 */
} /* Line: 96 */
bevl_lnode.bemd_1(-1940917614, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(1613992872);
bevl_nnode.bemd_0(-1845649817);
bevl_nnode = bevl_nxnode;
} /* Line: 108 */
 else  /* Line: 83 */ {
break;
} /* Line: 83 */
} /* Line: 83 */
if (bevl_nnode == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_83_tmpany_phold = bevl_nnode.bemd_0(-2064042825);
bevt_84_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_1(-886218051, bevt_84_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_82_tmpany_phold).bevi_bool) /* Line: 110 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 110 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 110 */
 else  /* Line: 110 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 110 */ {
bevl_nnode.bemd_0(-1845649817);
bevl_lnode.bemd_1(-1940917614, bevl_nnode);
} /* Line: 112 */
} /* Line: 110 */
bevt_85_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpany_phold;
} /* Line: 115 */
 else  /* Line: 21 */ {
bevt_87_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_88_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_87_tmpany_phold.bevi_int == bevt_88_tmpany_phold.bevi_int) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevt_89_tmpany_phold = beva_node.bem_containedGet_0();
bevl_parens = bevt_89_tmpany_phold.bem_firstGet_0();
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(845344653, beva_node);
bevt_90_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(-333229926, bevt_90_tmpany_phold);
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevl_nd.bemd_1(-718928743, bevt_91_tmpany_phold);
bevl_parens.bemd_1(1256780621, bevl_nd);
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_2_4_3_MathInt(0));
bevt_92_tmpany_phold = bevl_parens.bemd_0(-1732440824);
bevl_ii = bevt_92_tmpany_phold.bemd_0(812685421);
while (true)
 /* Line: 125 */ {
bevt_93_tmpany_phold = bevl_ii.bemd_0(-383924366);
if (((BEC_2_5_4_LogicBool) bevt_93_tmpany_phold).bevi_bool) /* Line: 125 */ {
bevl_i = bevl_ii.bemd_0(-25303237);
bevl_ix = bevl_i.bemd_0(1613992872);
bevt_95_tmpany_phold = bevl_i.bemd_0(-2064042825);
bevt_96_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_1(-886218051, bevt_96_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_94_tmpany_phold).bevi_bool) /* Line: 130 */ {
bevl_toremove.bemd_1(-1940917614, bevl_i);
} /* Line: 131 */
 else  /* Line: 130 */ {
bevt_98_tmpany_phold = bevl_i.bemd_0(-2064042825);
bevt_99_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_1(-886218051, bevt_99_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_97_tmpany_phold).bevi_bool) /* Line: 132 */ {
bevt_100_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(1385994869, bevt_100_tmpany_phold);
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_101_tmpany_phold = bevl_i.bemd_0(551897597);
bevl_v.bemd_1(1970413721, bevt_101_tmpany_phold);
bevt_102_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1462043119, bevt_102_tmpany_phold);
bevl_i.bemd_1(-718928743, bevl_v);
bevt_103_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(-333229926, bevt_103_tmpany_phold);
bevl_i.bemd_0(555642193);
} /* Line: 139 */
 else  /* Line: 130 */ {
bevt_105_tmpany_phold = bevl_i.bemd_0(-2064042825);
bevt_106_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bemd_1(-886218051, bevt_106_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_104_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevt_108_tmpany_phold = bevl_ix.bemd_0(-2064042825);
bevt_109_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bemd_1(-886218051, bevt_109_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_107_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevt_110_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(1385994869, bevt_110_tmpany_phold);
bevt_111_tmpany_phold = bevl_i.bemd_0(551897597);
bevt_112_tmpany_phold = bevl_ix.bemd_0(551897597);
bevt_111_tmpany_phold.bemd_1(1970413721, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = bevl_i.bemd_0(551897597);
bevt_114_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_113_tmpany_phold.bemd_1(1462043119, bevt_114_tmpany_phold);
bevl_i.bemd_0(555642193);
bevt_115_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(-333229926, bevt_115_tmpany_phold);
} /* Line: 146 */
 else  /* Line: 147 */ {
bevt_117_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bece_BEC_3_5_5_5_BuildVisitPass6_bels_2));
bevt_116_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_117_tmpany_phold, bevl_i);
throw new be.BECS_ThrowBack(bevt_116_tmpany_phold);
} /* Line: 148 */
} /* Line: 141 */
} /* Line: 130 */
} /* Line: 130 */
} /* Line: 130 */
 else  /* Line: 125 */ {
break;
} /* Line: 125 */
} /* Line: 125 */
bevl_ii = bevl_toremove.bemd_0(812685421);
while (true)
 /* Line: 152 */ {
bevt_118_tmpany_phold = bevl_ii.bemd_0(-383924366);
if (((BEC_2_5_4_LogicBool) bevt_118_tmpany_phold).bevi_bool) /* Line: 152 */ {
bevl_i = bevl_ii.bemd_0(-25303237);
bevl_i.bemd_0(-1845649817);
} /* Line: 154 */
 else  /* Line: 152 */ {
break;
} /* Line: 152 */
} /* Line: 152 */
bevl_s = beva_node.bem_heldGet_0();
bevt_120_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_119_tmpany_phold = bevl_numargs.bemd_1(-411537492, bevt_120_tmpany_phold);
bevl_s.bemd_1(-1210818619, bevt_119_tmpany_phold);
bevt_121_tmpany_phold = bevl_s.bemd_0(1956316046);
bevl_s.bemd_1(534805539, bevt_121_tmpany_phold);
bevt_124_tmpany_phold = bevl_s.bemd_0(1956316046);
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_3));
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bemd_1(1385994869, bevt_125_tmpany_phold);
bevt_127_tmpany_phold = bevl_s.bemd_0(954700283);
bevt_126_tmpany_phold = bevt_127_tmpany_phold.bemd_0(-1353172126);
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bemd_1(1385994869, bevt_126_tmpany_phold);
bevl_s.bemd_1(1970413721, bevt_122_tmpany_phold);
bevl_i = beva_node.bem_secondGet_0();
bevt_129_tmpany_phold = bevl_i.bemd_0(-2064042825);
bevt_130_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_128_tmpany_phold = bevt_129_tmpany_phold.bemd_1(-886218051, bevt_130_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_128_tmpany_phold).bevi_bool) /* Line: 161 */ {
bevl_i.bemd_0(1726479912);
bevt_131_tmpany_phold = bevl_i.bemd_0(551897597);
bevl_s.bemd_1(-668788319, bevt_131_tmpany_phold);
bevt_134_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_133_tmpany_phold = bevt_134_tmpany_phold.bemd_0(1192523784);
if (bevt_133_tmpany_phold == null) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 165 */ {
bevl_s.bemd_1(-668788319, null);
} /* Line: 167 */
 else  /* Line: 165 */ {
bevt_138_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_137_tmpany_phold = bevt_138_tmpany_phold.bemd_0(1192523784);
bevt_136_tmpany_phold = bevt_137_tmpany_phold.bemd_0(-1353172126);
bevt_139_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_4));
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bemd_1(-886218051, bevt_139_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_135_tmpany_phold).bevi_bool) /* Line: 168 */ {
bevt_140_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_141_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_140_tmpany_phold.bemd_1(332875154, bevt_141_tmpany_phold);
bevt_142_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_143_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_142_tmpany_phold.bemd_1(-708812785, bevt_143_tmpany_phold);
bevt_144_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_145_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_144_tmpany_phold.bemd_1(948827785, bevt_145_tmpany_phold);
bevt_147_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_146_tmpany_phold = bevt_147_tmpany_phold.bemd_0(1192523784);
bevt_148_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_146_tmpany_phold.bemd_1(-1732260899, bevt_148_tmpany_phold);
} /* Line: 173 */
 else  /* Line: 165 */ {
bevt_152_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_151_tmpany_phold = bevt_152_tmpany_phold.bemd_0(1192523784);
bevt_150_tmpany_phold = bevt_151_tmpany_phold.bemd_0(-1353172126);
bevt_153_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(-886218051, bevt_153_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_149_tmpany_phold).bevi_bool) /* Line: 174 */ {
bevt_154_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_155_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_154_tmpany_phold.bemd_1(332875154, bevt_155_tmpany_phold);
bevt_156_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_157_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_156_tmpany_phold.bemd_1(-708812785, bevt_157_tmpany_phold);
} /* Line: 176 */
} /* Line: 165 */
} /* Line: 165 */
bevl_i.bemd_0(-1845649817);
} /* Line: 178 */
 else  /* Line: 179 */ {
bevt_158_tmpany_phold = (BEC_2_5_3_BuildVar) (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_s.bemd_1(-668788319, bevt_158_tmpany_phold);
bevt_159_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_160_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_159_tmpany_phold.bemd_1(332875154, bevt_160_tmpany_phold);
bevt_161_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_162_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_161_tmpany_phold.bemd_1(-708812785, bevt_162_tmpany_phold);
bevt_163_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_164_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_163_tmpany_phold.bemd_1(948827785, bevt_164_tmpany_phold);
bevt_165_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_166_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_165_tmpany_phold.bemd_1(2024835387, bevt_166_tmpany_phold);
bevt_167_tmpany_phold = bevl_s.bemd_0(-635366726);
bevt_169_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevt_168_tmpany_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_169_tmpany_phold);
bevt_167_tmpany_phold.bemd_1(1274994571, bevt_168_tmpany_phold);
} /* Line: 185 */
bevl_clnode = beva_node.bem_classGet_0();
bevt_171_tmpany_phold = bevl_clnode.bemd_0(551897597);
bevt_170_tmpany_phold = bevt_171_tmpany_phold.bemd_0(1234120513);
bevt_172_tmpany_phold = bevl_s.bemd_0(1956316046);
bevt_170_tmpany_phold.bemd_2(-845452519, bevt_172_tmpany_phold, beva_node);
bevt_174_tmpany_phold = bevl_clnode.bemd_0(551897597);
bevt_173_tmpany_phold = bevt_174_tmpany_phold.bemd_0(143331008);
bevt_173_tmpany_phold.bemd_1(-1940917614, beva_node);
} /* Line: 189 */
} /* Line: 21 */
} /* Line: 21 */
} /* Line: 21 */
bevt_175_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_175_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 20, 21, 21, 21, 21, 22, 23, 23, 23, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 23, 0, 0, 0, 23, 23, 23, 23, 23, 23, 0, 0, 0, 25, 26, 26, 26, 26, 0, 26, 26, 28, 28, 30, 30, 31, 33, 34, 34, 34, 34, 35, 36, 36, 36, 37, 37, 40, 44, 45, 46, 48, 49, 49, 49, 51, 52, 55, 56, 56, 56, 57, 60, 60, 61, 62, 62, 65, 66, 66, 66, 66, 67, 68, 69, 69, 69, 69, 0, 69, 69, 71, 71, 72, 74, 74, 75, 75, 75, 76, 76, 77, 78, 80, 80, 80, 80, 81, 81, 82, 83, 83, 83, 83, 83, 0, 0, 0, 84, 85, 85, 86, 87, 88, 89, 89, 90, 91, 92, 92, 93, 94, 95, 95, 95, 96, 96, 96, 97, 97, 104, 105, 106, 107, 108, 110, 110, 110, 110, 110, 0, 0, 0, 111, 112, 115, 115, 116, 116, 116, 116, 117, 117, 118, 119, 120, 120, 121, 121, 122, 123, 124, 125, 125, 125, 126, 127, 130, 130, 130, 131, 132, 132, 132, 133, 133, 134, 135, 135, 136, 136, 137, 138, 138, 139, 140, 140, 140, 141, 141, 141, 142, 142, 143, 143, 143, 144, 144, 144, 145, 146, 146, 148, 148, 148, 152, 152, 153, 154, 156, 157, 157, 157, 158, 158, 159, 159, 159, 159, 159, 159, 159, 160, 161, 161, 161, 162, 164, 164, 165, 165, 165, 165, 167, 168, 168, 168, 168, 168, 170, 170, 170, 171, 171, 171, 172, 172, 172, 173, 173, 173, 173, 174, 174, 174, 174, 174, 175, 175, 175, 176, 176, 176, 178, 180, 180, 181, 181, 181, 182, 182, 182, 183, 183, 183, 184, 184, 184, 185, 185, 185, 185, 187, 188, 188, 188, 188, 189, 189, 189, 191, 191};
public static new int[] bevs_smnlec
 = new int[] {220, 221, 222, 223, 224, 229, 230, 231, 232, 237, 238, 239, 240, 241, 246, 247, 250, 254, 257, 258, 259, 260, 265, 266, 269, 273, 276, 277, 278, 279, 280, 281, 283, 286, 290, 293, 294, 295, 296, 297, 302, 303, 306, 310, 313, 314, 315, 316, 317, 317, 320, 322, 323, 324, 330, 331, 332, 334, 335, 336, 337, 340, 342, 343, 344, 345, 347, 348, 349, 357, 359, 360, 362, 363, 364, 365, 368, 369, 371, 372, 373, 374, 376, 378, 383, 384, 385, 386, 388, 391, 392, 393, 398, 399, 400, 401, 402, 403, 404, 404, 407, 409, 410, 411, 412, 418, 419, 420, 421, 422, 423, 426, 428, 429, 437, 438, 439, 444, 445, 450, 451, 454, 459, 460, 461, 462, 464, 467, 471, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 494, 495, 496, 499, 501, 502, 509, 510, 511, 512, 513, 519, 524, 525, 526, 527, 529, 532, 536, 539, 540, 543, 544, 547, 548, 549, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 570, 572, 573, 574, 575, 576, 578, 581, 582, 583, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 598, 599, 600, 602, 603, 604, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 619, 620, 621, 631, 634, 636, 637, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 661, 662, 663, 664, 665, 666, 671, 672, 675, 676, 677, 678, 679, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 696, 697, 698, 699, 700, 702, 703, 704, 705, 706, 707, 711, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 733, 734, 735, 736, 737, 738, 739, 740, 745, 746};
/* BEGIN LINEINFO 
resolveNp 0 17 220
assign 1 20 221
nextPeerGet 0 20 221
assign 1 21 222
typenameGet 0 21 222
assign 1 21 223
EMITGet 0 21 223
assign 1 21 224
equals 1 21 229
assign 1 22 230
nextAscendGet 0 22 230
assign 1 23 231
containedGet 0 23 231
assign 1 23 232
def 1 23 237
assign 1 23 238
containedGet 0 23 238
assign 1 23 239
lengthGet 0 23 239
assign 1 23 240
new 0 23 240
assign 1 23 241
greater 1 23 246
assign 1 0 247
assign 1 0 250
assign 1 0 254
assign 1 23 257
containedGet 0 23 257
assign 1 23 258
firstGet 0 23 258
assign 1 23 259
containedGet 0 23 259
assign 1 23 260
def 1 23 265
assign 1 0 266
assign 1 0 269
assign 1 0 273
assign 1 23 276
containedGet 0 23 276
assign 1 23 277
firstGet 0 23 277
assign 1 23 278
containedGet 0 23 278
assign 1 23 279
lengthGet 0 23 279
assign 1 23 280
new 0 23 280
assign 1 23 281
greater 1 23 281
assign 1 0 283
assign 1 0 286
assign 1 0 290
assign 1 23 293
secondGet 0 23 293
assign 1 23 294
containedGet 0 23 294
assign 1 23 295
lengthGet 0 23 295
assign 1 23 296
new 0 23 296
assign 1 23 297
greater 1 23 302
assign 1 0 303
assign 1 0 306
assign 1 0 310
assign 1 25 313
new 0 25 313
assign 1 26 314
containedGet 0 26 314
assign 1 26 315
firstGet 0 26 315
assign 1 26 316
containedGet 0 26 316
assign 1 26 317
iteratorGet 0 0 317
assign 1 26 320
hasNextGet 0 26 320
assign 1 26 322
nextGet 0 26 322
assign 1 28 323
heldGet 0 28 323
addValue 1 28 324
assign 1 30 330
new 0 30 330
delete 1 30 331
assign 1 31 332
new 0 31 332
assign 1 33 334
new 0 33 334
assign 1 34 335
secondGet 0 34 335
assign 1 34 336
containedGet 0 34 336
assign 1 34 337
iteratorGet 0 34 337
assign 1 34 340
hasNextGet 0 34 340
assign 1 35 342
nextGet 0 35 342
assign 1 36 343
typenameGet 0 36 343
assign 1 36 344
STRINGLGet 0 36 344
assign 1 36 345
equals 1 36 345
assign 1 37 347
heldGet 0 37 347
heldSet 1 37 348
assign 1 40 349
new 0 40 349
assign 1 44 357
not 0 44 357
delete 0 45 359
return 1 46 360
containedSet 1 48 362
assign 1 49 363
heldGet 0 49 363
assign 1 49 364
new 2 49 364
heldSet 1 49 365
delete 0 51 368
return 1 52 369
assign 1 55 371
scopeGet 0 55 371
assign 1 56 372
typenameGet 0 56 372
assign 1 56 373
METHODGet 0 56 373
assign 1 56 374
equals 1 56 374
assign 1 57 376
assign 1 60 378
def 1 60 383
delete 0 61 384
assign 1 62 385
heldGet 0 62 385
addEmit 1 62 386
return 1 65 388
assign 1 66 391
typenameGet 0 66 391
assign 1 66 392
IFEMITGet 0 66 392
assign 1 66 393
equals 1 66 398
assign 1 67 399
new 0 67 399
assign 1 68 400
new 0 68 400
assign 1 69 401
containedGet 0 69 401
assign 1 69 402
firstGet 0 69 402
assign 1 69 403
containedGet 0 69 403
assign 1 69 404
iteratorGet 0 0 404
assign 1 69 407
hasNextGet 0 69 407
assign 1 69 409
nextGet 0 69 409
assign 1 71 410
heldGet 0 71 410
addValue 1 71 411
addValue 1 72 412
assign 1 74 418
new 0 74 418
delete 1 74 419
assign 1 75 420
heldGet 0 75 420
assign 1 75 421
new 2 75 421
heldSet 1 75 422
assign 1 76 423
iteratorGet 0 76 423
assign 1 76 426
hasNextGet 0 76 426
assign 1 77 428
nextGet 0 77 428
delete 0 78 429
assign 1 80 437
typenameGet 0 80 437
assign 1 80 438
IFGet 0 80 438
assign 1 80 439
equals 1 80 444
assign 1 81 445
def 1 81 450
assign 1 82 451
assign 1 83 454
def 1 83 459
assign 1 83 460
typenameGet 0 83 460
assign 1 83 461
ELIFGet 0 83 461
assign 1 83 462
equals 1 83 462
assign 1 0 464
assign 1 0 467
assign 1 0 471
assign 1 84 474
new 1 84 474
assign 1 85 475
ELSEGet 0 85 475
typenameSet 1 85 476
copyLoc 1 86 477
assign 1 87 478
new 1 87 478
copyLoc 1 88 479
assign 1 89 480
BRACESGet 0 89 480
typenameSet 1 89 481
assign 1 90 482
new 1 90 482
copyLoc 1 91 483
assign 1 92 484
IFGet 0 92 484
typenameSet 1 92 485
addValue 1 93 486
addValue 1 94 487
assign 1 95 488
containedGet 0 95 488
assign 1 95 489
def 1 95 494
assign 1 96 495
containedGet 0 96 495
assign 1 96 496
iteratorGet 0 96 496
assign 1 96 499
hasNextGet 0 96 499
assign 1 97 501
nextGet 0 97 501
addValue 1 97 502
addValue 1 104 509
assign 1 105 510
assign 1 106 511
nextPeerGet 0 106 511
delete 0 107 512
assign 1 108 513
assign 1 110 519
def 1 110 524
assign 1 110 525
typenameGet 0 110 525
assign 1 110 526
ELSEGet 0 110 526
assign 1 110 527
equals 1 110 527
assign 1 0 529
assign 1 0 532
assign 1 0 536
delete 0 111 539
addValue 1 112 540
assign 1 115 543
nextDescendGet 0 115 543
return 1 115 544
assign 1 116 547
typenameGet 0 116 547
assign 1 116 548
METHODGet 0 116 548
assign 1 116 549
equals 1 116 554
assign 1 117 555
containedGet 0 117 555
assign 1 117 556
firstGet 0 117 556
assign 1 118 557
new 1 118 557
copyLoc 1 119 558
assign 1 120 559
IDGet 0 120 559
typenameSet 1 120 560
assign 1 121 561
new 0 121 561
heldSet 1 121 562
prepend 1 122 563
assign 1 123 564
new 0 123 564
assign 1 124 565
new 0 124 565
assign 1 125 566
containedGet 0 125 566
assign 1 125 567
iteratorGet 0 125 567
assign 1 125 570
hasNextGet 0 125 570
assign 1 126 572
nextGet 0 126 572
assign 1 127 573
nextPeerGet 0 127 573
assign 1 130 574
typenameGet 0 130 574
assign 1 130 575
COMMAGet 0 130 575
assign 1 130 576
equals 1 130 576
addValue 1 131 578
assign 1 132 581
typenameGet 0 132 581
assign 1 132 582
IDGet 0 132 582
assign 1 132 583
equals 1 132 583
assign 1 133 585
new 0 133 585
assign 1 133 586
add 1 133 586
assign 1 134 587
new 0 134 587
assign 1 135 588
heldGet 0 135 588
nameSet 1 135 589
assign 1 136 590
new 0 136 590
isArgSet 1 136 591
heldSet 1 137 592
assign 1 138 593
VARGet 0 138 593
typenameSet 1 138 594
addVariable 0 139 595
assign 1 140 598
typenameGet 0 140 598
assign 1 140 599
VARGet 0 140 599
assign 1 140 600
equals 1 140 600
assign 1 141 602
typenameGet 0 141 602
assign 1 141 603
IDGet 0 141 603
assign 1 141 604
equals 1 141 604
assign 1 142 606
new 0 142 606
assign 1 142 607
add 1 142 607
assign 1 143 608
heldGet 0 143 608
assign 1 143 609
heldGet 0 143 609
nameSet 1 143 610
assign 1 144 611
heldGet 0 144 611
assign 1 144 612
new 0 144 612
isArgSet 1 144 613
addVariable 0 145 614
assign 1 146 615
COMMAGet 0 146 615
typenameSet 1 146 616
assign 1 148 619
new 0 148 619
assign 1 148 620
new 2 148 620
throw 1 148 621
assign 1 152 631
iteratorGet 0 152 631
assign 1 152 634
hasNextGet 0 152 634
assign 1 153 636
nextGet 0 153 636
delete 0 154 637
assign 1 156 643
heldGet 0 156 643
assign 1 157 644
new 0 157 644
assign 1 157 645
subtract 1 157 645
numargsSet 1 157 646
assign 1 158 647
nameGet 0 158 647
orgNameSet 1 158 648
assign 1 159 649
nameGet 0 159 649
assign 1 159 650
new 0 159 650
assign 1 159 651
add 1 159 651
assign 1 159 652
numargsGet 0 159 652
assign 1 159 653
toString 0 159 653
assign 1 159 654
add 1 159 654
nameSet 1 159 655
assign 1 160 656
secondGet 0 160 656
assign 1 161 657
typenameGet 0 161 657
assign 1 161 658
VARGet 0 161 658
assign 1 161 659
equals 1 161 659
resolveNp 0 162 661
assign 1 164 662
heldGet 0 164 662
rtypeSet 1 164 663
assign 1 165 664
rtypeGet 0 165 664
assign 1 165 665
namepathGet 0 165 665
assign 1 165 666
undef 1 165 671
rtypeSet 1 167 672
assign 1 168 675
rtypeGet 0 168 675
assign 1 168 676
namepathGet 0 168 676
assign 1 168 677
toString 0 168 677
assign 1 168 678
new 0 168 678
assign 1 168 679
equals 1 168 679
assign 1 170 681
rtypeGet 0 170 681
assign 1 170 682
new 0 170 682
isTypedSet 1 170 683
assign 1 171 684
rtypeGet 0 171 684
assign 1 171 685
new 0 171 685
isSelfSet 1 171 686
assign 1 172 687
rtypeGet 0 172 687
assign 1 172 688
new 0 172 688
isThisSet 1 172 689
assign 1 173 690
rtypeGet 0 173 690
assign 1 173 691
namepathGet 0 173 691
assign 1 173 692
new 0 173 692
pathSet 1 173 693
assign 1 174 696
rtypeGet 0 174 696
assign 1 174 697
namepathGet 0 174 697
assign 1 174 698
toString 0 174 698
assign 1 174 699
new 0 174 699
assign 1 174 700
equals 1 174 700
assign 1 175 702
rtypeGet 0 175 702
assign 1 175 703
new 0 175 703
isTypedSet 1 175 704
assign 1 176 705
rtypeGet 0 176 705
assign 1 176 706
new 0 176 706
isSelfSet 1 176 707
delete 0 178 711
assign 1 180 714
new 0 180 714
rtypeSet 1 180 715
assign 1 181 716
rtypeGet 0 181 716
assign 1 181 717
new 0 181 717
isTypedSet 1 181 718
assign 1 182 719
rtypeGet 0 182 719
assign 1 182 720
new 0 182 720
isSelfSet 1 182 721
assign 1 183 722
rtypeGet 0 183 722
assign 1 183 723
new 0 183 723
isThisSet 1 183 724
assign 1 184 725
rtypeGet 0 184 725
assign 1 184 726
new 0 184 726
impliedSet 1 184 727
assign 1 185 728
rtypeGet 0 185 728
assign 1 185 729
new 0 185 729
assign 1 185 730
new 1 185 730
namepathSet 1 185 731
assign 1 187 733
classGet 0 187 733
assign 1 188 734
heldGet 0 188 734
assign 1 188 735
methodsGet 0 188 735
assign 1 188 736
nameGet 0 188 736
put 2 188 737
assign 1 189 738
heldGet 0 189 738
assign 1 189 739
orderedMethodsGet 0 189 739
addValue 1 189 740
assign 1 191 745
nextDescendGet 0 191 745
return 1 191 746
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 605655591: return bem_sourceFileNameGet_0();
case 1267812147: return bem_classNameGet_0();
case 860976645: return bem_constGetDirect_0();
case 702246847: return bem_print_0();
case -364249863: return bem_serializeToString_0();
case -1353172126: return bem_toString_0();
case 1966713191: return bem_deserializeClassNameGet_0();
case -1655660203: return bem_hashGet_0();
case -500248069: return bem_serializationIteratorGet_0();
case 1581692921: return bem_toAny_0();
case 1739341242: return bem_transGet_0();
case -1572010998: return bem_copy_0();
case -496016490: return bem_buildGetDirect_0();
case -1973330053: return bem_transGetDirect_0();
case 1530555194: return bem_serializeContents_0();
case 812685421: return bem_iteratorGet_0();
case -1229344212: return bem_ntypesGetDirect_0();
case 1916900255: return bem_buildGet_0();
case -300440210: return bem_ntypesGet_0();
case -1000018882: return bem_create_0();
case -65082849: return bem_once_0();
case -1907635971: return bem_tagGet_0();
case -106257945: return bem_fieldNamesGet_0();
case -1577817259: return bem_echo_0();
case 1550760607: return bem_fieldIteratorGet_0();
case -927090833: return bem_new_0();
case -1007878556: return bem_many_0();
case 678066298: return bem_constGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -363976204: return bem_end_1(bevd_0);
case 1711941852: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1244819809: return bem_undefined_1(bevd_0);
case -960947678: return bem_ntypesSet_1(bevd_0);
case 1953776597: return bem_sameType_1(bevd_0);
case -759946269: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1471550820: return bem_transSetDirect_1(bevd_0);
case 140166424: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1071293979: return bem_buildSetDirect_1(bevd_0);
case -58459221: return bem_sameClass_1(bevd_0);
case 129545103: return bem_buildSet_1(bevd_0);
case -1556952447: return bem_defined_1(bevd_0);
case -1862075337: return bem_copyTo_1(bevd_0);
case 726015407: return bem_otherType_1(bevd_0);
case 150021405: return bem_otherClass_1(bevd_0);
case -1399562150: return bem_constSet_1(bevd_0);
case -1471457238: return bem_sameObject_1(bevd_0);
case 297381803: return bem_def_1(bevd_0);
case 1673385175: return bem_notEquals_1(bevd_0);
case 1140777632: return bem_constSetDirect_1(bevd_0);
case -227529285: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 691174875: return bem_begin_1(bevd_0);
case -886218051: return bem_equals_1(bevd_0);
case 2141774895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -481756547: return bem_undef_1(bevd_0);
case 1100414449: return bem_ntypesSetDirect_1(bevd_0);
case 1447874828: return bem_transSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1722905349: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -967702518: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -427898914: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 414161005: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 611344245: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -157052200: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1970963739: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass6_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass6_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass6();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst = (BEC_3_5_5_5_BuildVisitPass6) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;
}
}
}
