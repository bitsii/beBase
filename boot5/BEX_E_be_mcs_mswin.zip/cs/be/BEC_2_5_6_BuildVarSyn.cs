namespace be {
/* IO:File: source/build/Syns.be */
public sealed class BEC_2_5_6_BuildVarSyn : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildVarSyn() { }
static BEC_2_5_6_BuildVarSyn() { }
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_5_6_BuildVarSyn bece_BEC_2_5_6_BuildVarSyn_bevs_inst;

public static new BET_2_5_6_BuildVarSyn bece_BEC_2_5_6_BuildVarSyn_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_5_4_LogicBool bevp_isThis;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_isTyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_npNew_1(BEC_2_5_8_BuildNamePath beva_np) {
bevp_namepath = beva_np;
bevp_isTyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_anyNew_1(BEC_2_5_3_BuildVar beva_full) {
bevp_name = beva_full.bem_nameGet_0();
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
bevp_isThis = beva_full.bem_isThisGet_0();
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_5_6_BuildVarSyn beva_o) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
if (beva_o == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 39 */
if (bevp_name == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_7_tmpany_phold = beva_o.bem_nameGet_0();
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
 else  /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_9_tmpany_phold = beva_o.bem_nameGet_0();
bevt_8_tmpany_phold = bevp_name.bem_notEquals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /* Line: 41 */
bevt_12_tmpany_phold = beva_o.bem_isTypedGet_0();
bevt_11_tmpany_phold = bevp_isTyped.bem_notEquals_1(bevt_12_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_13_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_13_tmpany_phold;
} /* Line: 44 */
if (bevp_isTyped.bevi_bool) /* Line: 46 */ {
bevt_15_tmpany_phold = beva_o.bem_namepathGet_0();
bevt_14_tmpany_phold = bevp_namepath.bem_notEquals_1(bevt_15_tmpany_phold);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 46 */
 else  /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 46 */ {
bevt_16_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_16_tmpany_phold;
} /* Line: 47 */
bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGetDirect_0() {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isTypedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGetDirect_0() {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isSelfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGet_0() {
return bevp_isThis;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGetDirect_0() {
return bevp_isThis;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isThisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isThisSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {20, 24, 25, 30, 31, 32, 33, 34, 39, 39, 39, 39, 40, 40, 40, 40, 40, 0, 0, 0, 40, 40, 0, 0, 0, 41, 41, 43, 43, 44, 44, 46, 46, 0, 0, 0, 47, 47, 49, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 22, 23, 27, 28, 29, 30, 31, 53, 58, 59, 60, 62, 67, 68, 69, 74, 75, 78, 82, 85, 86, 88, 91, 95, 98, 99, 101, 102, 104, 105, 108, 109, 111, 114, 118, 121, 122, 124, 125, 128, 131, 134, 138, 142, 145, 148, 152, 156, 159, 162, 166, 170, 173, 176, 180, 184, 187, 190, 194};
/* BEGIN LINEINFO 
assign 1 20 18
new 0 20 18
assign 1 24 22
assign 1 25 23
new 0 25 23
assign 1 30 27
nameGet 0 30 27
assign 1 31 28
namepathGet 0 31 28
assign 1 32 29
isTypedGet 0 32 29
assign 1 33 30
isSelfGet 0 33 30
assign 1 34 31
isThisGet 0 34 31
assign 1 39 53
undef 1 39 58
assign 1 39 59
new 0 39 59
return 1 39 60
assign 1 40 62
def 1 40 67
assign 1 40 68
nameGet 0 40 68
assign 1 40 69
def 1 40 74
assign 1 0 75
assign 1 0 78
assign 1 0 82
assign 1 40 85
nameGet 0 40 85
assign 1 40 86
notEquals 1 40 86
assign 1 0 88
assign 1 0 91
assign 1 0 95
assign 1 41 98
new 0 41 98
return 1 41 99
assign 1 43 101
isTypedGet 0 43 101
assign 1 43 102
notEquals 1 43 102
assign 1 44 104
new 0 44 104
return 1 44 105
assign 1 46 108
namepathGet 0 46 108
assign 1 46 109
notEquals 1 46 109
assign 1 0 111
assign 1 0 114
assign 1 0 118
assign 1 47 121
new 0 47 121
return 1 47 122
assign 1 49 124
new 0 49 124
return 1 49 125
return 1 0 128
return 1 0 131
assign 1 0 134
assign 1 0 138
return 1 0 142
return 1 0 145
assign 1 0 148
assign 1 0 152
return 1 0 156
return 1 0 159
assign 1 0 162
assign 1 0 166
return 1 0 170
return 1 0 173
assign 1 0 176
assign 1 0 180
return 1 0 184
return 1 0 187
assign 1 0 190
assign 1 0 194
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2061644084: return bem_echo_0();
case 277586237: return bem_isSelfGetDirect_0();
case -598687422: return bem_nameGetDirect_0();
case -575216772: return bem_hashGet_0();
case 1598747765: return bem_namepathGet_0();
case 1743657368: return bem_once_0();
case 700847419: return bem_iteratorGet_0();
case -2071582224: return bem_fieldNamesGet_0();
case 1649770762: return bem_serializeContents_0();
case -1460138897: return bem_print_0();
case -1381809993: return bem_deserializeClassNameGet_0();
case 205524275: return bem_isSelfGet_0();
case 1371499062: return bem_isTypedGetDirect_0();
case 1523118874: return bem_nameGet_0();
case -1477321659: return bem_create_0();
case 906451704: return bem_isThisGet_0();
case -167133301: return bem_fieldIteratorGet_0();
case -1824151510: return bem_sourceFileNameGet_0();
case 1507268759: return bem_isThisGetDirect_0();
case -938512016: return bem_isTypedGet_0();
case 375625109: return bem_copy_0();
case 771095575: return bem_namepathGetDirect_0();
case 1357107465: return bem_many_0();
case 1303816937: return bem_classNameGet_0();
case -1062508492: return bem_toAny_0();
case 885190018: return bem_serializationIteratorGet_0();
case 1443037619: return bem_new_0();
case 641617863: return bem_serializeToString_0();
case -954029510: return bem_tagGet_0();
case -1111980982: return bem_toString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 997965949: return bem_sameClass_1(bevd_0);
case 2128146050: return bem_npNew_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1650435450: return bem_undefined_1(bevd_0);
case -1022365996: return bem_namepathSet_1(bevd_0);
case 1434062431: return bem_defined_1(bevd_0);
case -240276616: return bem_def_1(bevd_0);
case 1867255761: return bem_isSelfSetDirect_1(bevd_0);
case -2012223833: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -158486422: return bem_undef_1(bevd_0);
case -871630469: return bem_isTypedSetDirect_1(bevd_0);
case 1171201188: return bem_sameType_1(bevd_0);
case 829192566: return bem_otherClass_1(bevd_0);
case 912665444: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 132172085: return bem_nameSetDirect_1(bevd_0);
case -124594925: return bem_equals_1(bevd_0);
case 148007529: return bem_isTypedSet_1(bevd_0);
case -2105082623: return bem_isThisSet_1(bevd_0);
case -961773673: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 288844328: return bem_nameSet_1(bevd_0);
case -1077344300: return bem_namepathSetDirect_1(bevd_0);
case -536053857: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1312236601: return bem_isSelfSet_1(bevd_0);
case -106504977: return bem_isThisSetDirect_1(bevd_0);
case 287194048: return bem_contentsEqual_1((BEC_2_5_6_BuildVarSyn) bevd_0);
case 1081114988: return bem_copyTo_1(bevd_0);
case -860634984: return bem_sameObject_1(bevd_0);
case -2012960734: return bem_otherType_1(bevd_0);
case 258994372: return bem_anyNew_1((BEC_2_5_3_BuildVar) bevd_0);
case 1843091865: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1783314567: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -749136313: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1365145554: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1346654676: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1957573480: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2039992278: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1347676005: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildVarSyn_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildVarSyn_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildVarSyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst = (BEC_2_5_6_BuildVarSyn) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_type;
}
}
}
