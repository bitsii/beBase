namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator : BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
static BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_BEC_2_4_12_TextByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_12_TextByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_4 = (new BEC_2_4_3_MathInt(0));
public static new BEC_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_inst;

public static new BET_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_3_MathInt bevp_vcopy;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_emptyGet_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_containerGet_0() {
return bevp_str;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return bevp_str;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) {
bem_new_1(beva_str);
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) {
bevp_str = beva__str;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_vcopy = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1322 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 1323 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nextGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1333 */ {
bevt_3_tmpany_phold = beva_buf.bem_capacityGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1334 */ {
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_tmpany_phold);
} /* Line: 1335 */
bevt_7_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_8_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_1;
if (bevt_7_tmpany_phold.bevi_int != bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1337 */ {
bevt_9_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_11_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_2;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_9_tmpany_phold.bevi_int = bevt_10_tmpany_phold.bevi_int;
} /* Line: 1338 */
bevt_12_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_13_tmpany_phold = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
bevp_pos.bevi_int++;
} /* Line: 1344 */
return beva_buf;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1350 */ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1352 */
return beva_into;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_3;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1358 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1358 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1358 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1358 */
 else  /* Line: 1358 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1358 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1361 */
return beva_into;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_4;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1367 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1367 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1367 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1367 */
 else  /* Line: 1367 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1367 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1370 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_strGet_0() {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_strGetDirect_0() {
return bevp_str;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGetDirect_0() {
return bevp_pos;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_vcopyGet_0() {
return bevp_vcopy;
} /*method end*/
public BEC_2_4_3_MathInt bem_vcopyGetDirect_0() {
return bevp_vcopy;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_vcopySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_vcopySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1298, 1298, 1298, 1302, 1306, 1310, 1315, 1316, 1317, 1322, 1322, 1322, 1323, 1323, 1325, 1325, 1329, 1329, 1329, 1329, 1333, 1333, 1333, 1334, 1334, 1334, 1334, 1335, 1335, 1337, 1337, 1337, 1337, 1338, 1338, 1338, 1338, 1340, 1340, 1340, 1344, 1346, 1350, 1350, 1350, 1351, 1352, 1354, 1358, 1358, 1358, 1358, 1358, 1358, 0, 0, 0, 1359, 1360, 1361, 1363, 1367, 1367, 1367, 1367, 1367, 1367, 0, 0, 0, 1368, 1369, 1370, 1376, 1380, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 28, 32, 35, 38, 42, 43, 44, 52, 53, 58, 59, 60, 62, 63, 69, 70, 71, 72, 91, 92, 97, 98, 99, 100, 105, 106, 107, 109, 110, 111, 116, 117, 118, 119, 120, 122, 123, 124, 125, 127, 132, 133, 138, 139, 140, 142, 150, 151, 156, 157, 158, 163, 164, 167, 171, 174, 175, 176, 178, 186, 187, 192, 193, 194, 199, 200, 203, 207, 210, 211, 212, 217, 220, 223, 226, 229, 233, 237, 240, 243, 247, 251, 254, 257, 261};
/* BEGIN LINEINFO 
assign 1 1298 26
new 0 1298 26
assign 1 1298 27
emptyGet 0 1298 27
new 1 1298 28
return 1 1302 32
return 1 1306 35
new 1 1310 38
assign 1 1315 42
assign 1 1316 43
new 0 1316 43
assign 1 1317 44
new 0 1317 44
assign 1 1322 52
sizeGet 0 1322 52
assign 1 1322 53
greater 1 1322 58
assign 1 1323 59
new 0 1323 59
return 1 1323 60
assign 1 1325 62
new 0 1325 62
return 1 1325 63
assign 1 1329 69
new 0 1329 69
assign 1 1329 70
new 1 1329 70
assign 1 1329 71
next 1 1329 71
return 1 1329 72
assign 1 1333 91
sizeGet 0 1333 91
assign 1 1333 92
greater 1 1333 97
assign 1 1334 98
capacityGet 0 1334 98
assign 1 1334 99
new 0 1334 99
assign 1 1334 100
lesser 1 1334 105
assign 1 1335 106
new 0 1335 106
capacitySet 1 1335 107
assign 1 1337 109
sizeGet 0 1337 109
assign 1 1337 110
new 0 1337 110
assign 1 1337 111
notEquals 1 1337 116
assign 1 1338 117
sizeGet 0 1338 117
assign 1 1338 118
new 0 1338 118
assign 1 1338 119
once 0 1338 119
setValue 1 1338 120
assign 1 1340 122
new 0 1340 122
assign 1 1340 123
getInt 2 1340 123
setIntUnchecked 2 1340 124
incrementValue 0 1344 125
return 1 1346 127
assign 1 1350 132
sizeGet 0 1350 132
assign 1 1350 133
greater 1 1350 138
getInt 2 1351 139
incrementValue 0 1352 140
return 1 1354 142
assign 1 1358 150
new 0 1358 150
assign 1 1358 151
greater 1 1358 156
assign 1 1358 157
sizeGet 0 1358 157
assign 1 1358 158
greaterEquals 1 1358 163
assign 1 0 164
assign 1 0 167
assign 1 0 171
decrementValue 0 1359 174
getInt 2 1360 175
incrementValue 0 1361 176
return 1 1363 178
assign 1 1367 186
new 0 1367 186
assign 1 1367 187
greater 1 1367 192
assign 1 1367 193
sizeGet 0 1367 193
assign 1 1367 194
greaterEquals 1 1367 199
assign 1 0 200
assign 1 0 203
assign 1 0 207
decrementValue 0 1368 210
setIntUnchecked 2 1369 211
incrementValue 0 1370 212
return 1 1376 217
return 1 1380 220
return 1 0 223
return 1 0 226
assign 1 0 229
assign 1 0 233
return 1 0 237
return 1 0 240
assign 1 0 243
assign 1 0 247
return 1 0 251
return 1 0 254
assign 1 0 257
assign 1 0 261
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1317807556: return bem_vcopyGetDirect_0();
case -145020572: return bem_posGetDirect_0();
case -1989311424: return bem_iteratorGet_0();
case -1005843071: return bem_serializeContents_0();
case 1875317286: return bem_many_0();
case 272950674: return bem_deserializeClassNameGet_0();
case 1190770625: return bem_strGet_0();
case -259094594: return bem_echo_0();
case -1906719430: return bem_byteIteratorIteratorGet_0();
case 1985057509: return bem_fieldIteratorGet_0();
case 64036809: return bem_serializeToString_0();
case -450866260: return bem_hasNextGet_0();
case 450989839: return bem_toString_0();
case 2077438310: return bem_fieldNamesGet_0();
case -160406851: return bem_new_0();
case 681415323: return bem_hashGet_0();
case 1562408751: return bem_once_0();
case 329817388: return bem_containerGet_0();
case 1708657088: return bem_strGetDirect_0();
case -1541048309: return bem_create_0();
case -71903244: return bem_nextGet_0();
case -1307912568: return bem_classNameGet_0();
case 137938641: return bem_copy_0();
case 201818212: return bem_tagGet_0();
case -1335607781: return bem_sourceFileNameGet_0();
case -144129925: return bem_serializationIteratorGet_0();
case -576153975: return bem_posGet_0();
case -801289306: return bem_vcopyGet_0();
case -1128253997: return bem_print_0();
case -1192359710: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1139812471: return bem_defined_1(bevd_0);
case -1038310581: return bem_posSet_1(bevd_0);
case 1685385321: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 87713512: return bem_otherType_1(bevd_0);
case 1151483997: return bem_undef_1(bevd_0);
case -288772660: return bem_posSetDirect_1(bevd_0);
case 371940317: return bem_otherClass_1(bevd_0);
case -1769267387: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1823741815: return bem_strSetDirect_1(bevd_0);
case -658977126: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -209909181: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1496797900: return bem_undefined_1(bevd_0);
case 727276537: return bem_vcopySet_1(bevd_0);
case -2025296024: return bem_strSet_1(bevd_0);
case 1058613648: return bem_vcopySetDirect_1(bevd_0);
case 959879294: return bem_notEquals_1(bevd_0);
case -2045198723: return bem_sameType_1(bevd_0);
case 1113733988: return bem_copyTo_1(bevd_0);
case 1041146490: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1917243902: return bem_sameObject_1(bevd_0);
case -1943396073: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -710558084: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 1645054849: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 294100036: return bem_def_1(bevd_0);
case 1634136691: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1742674668: return bem_equals_1(bevd_0);
case 1349958545: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -285325789: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1136827327: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 517362903: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -491501198: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -534690974: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -496063349: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1244895026: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_TextByteIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_12_TextByteIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_12_TextByteIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst = (BEC_2_4_12_TextByteIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_type;
}
}
}
