namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_4_ContainerLinkedListNode : BEC_2_6_6_SystemObject {
public BEC_3_9_10_4_ContainerLinkedListNode() { }
static BEC_3_9_10_4_ContainerLinkedListNode() { }
private static byte[] becc_BEC_3_9_10_4_ContainerLinkedListNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_10_4_ContainerLinkedListNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_3_9_10_4_ContainerLinkedListNode bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst;

public static new BET_3_9_10_4_ContainerLinkedListNode bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_prior;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_next;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_2_9_10_ContainerLinkedList bevp_mylist;
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_new_2(BEC_2_6_6_SystemObject beva__held, BEC_2_9_10_ContainerLinkedList beva__mylist) {
bevp_held = beva__held;
bevp_mylist = beva__mylist;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_insertBefore_1(BEC_2_6_6_SystemObject beva_toIns) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
beva_toIns.bemd_1(139298845, null);
beva_toIns.bemd_1(-1535331289, this);
beva_toIns.bemd_1(-1608504765, bevp_mylist);
bevl_p = bevp_prior;
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) beva_toIns;
if (bevl_p == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 57*/ {
bevp_mylist.bem_firstNodeSet_1(beva_toIns);
} /* Line: 59*/
 else /* Line: 60*/ {
bevl_p.bem_nextSet_1(beva_toIns);
beva_toIns.bemd_1(139298845, bevl_p);
} /* Line: 62*/
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_delete_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
bevl_p = bevp_prior;
bevl_n = bevp_next;
bevp_next = null;
bevp_prior = null;
if (bevl_p == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 71*/ {
bevp_mylist.bem_firstNodeSet_1(bevl_n);
if (bevl_n == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 74*/ {
bevl_n.bem_priorSet_1(null);
} /* Line: 75*/
 else /* Line: 76*/ {
bevp_mylist.bem_lastNodeSet_1(bevl_n);
} /* Line: 78*/
} /* Line: 74*/
 else /* Line: 71*/ {
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 80*/ {
bevl_p.bem_nextSet_1(bevl_n);
bevp_mylist.bem_lastNodeSet_1(bevl_p);
} /* Line: 83*/
 else /* Line: 84*/ {
bevl_p.bem_nextSet_1(bevl_n);
bevl_n.bem_priorSet_1(bevl_p);
} /* Line: 87*/
} /* Line: 71*/
bevp_mylist = null;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_priorGet_0() {
return bevp_prior;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_priorGetDirect_0() {
return bevp_prior;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_priorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_priorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_prior = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_nextGet_0() {
return bevp_next;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_nextGetDirect_0() {
return bevp_next;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_nextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_next = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_nextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_next = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_heldGet_0() {
return bevp_held;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGetDirect_0() {
return bevp_held;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_heldSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_mylistGet_0() {
return bevp_mylist;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_mylistGetDirect_0() {
return bevp_mylist;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_mylistSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mylist = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_mylistSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mylist = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {44, 45, 52, 53, 54, 55, 56, 57, 57, 59, 61, 62, 67, 68, 69, 70, 71, 71, 73, 74, 74, 75, 78, 80, 80, 82, 83, 86, 87, 89, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 18, 24, 25, 26, 27, 28, 29, 34, 35, 38, 39, 49, 50, 51, 52, 53, 58, 59, 60, 65, 66, 69, 73, 78, 79, 80, 83, 84, 87, 91, 94, 97, 101, 105, 108, 111, 115, 119, 122, 125, 129, 133, 136, 139, 143};
/* BEGIN LINEINFO 
assign 1 44 17
assign 1 45 18
priorSet 1 52 24
nextSet 1 53 25
mylistSet 1 54 26
assign 1 55 27
assign 1 56 28
assign 1 57 29
undef 1 57 34
firstNodeSet 1 59 35
nextSet 1 61 38
priorSet 1 62 39
assign 1 67 49
assign 1 68 50
assign 1 69 51
assign 1 70 52
assign 1 71 53
undef 1 71 58
firstNodeSet 1 73 59
assign 1 74 60
def 1 74 65
priorSet 1 75 66
lastNodeSet 1 78 69
assign 1 80 73
undef 1 80 78
nextSet 1 82 79
lastNodeSet 1 83 80
nextSet 1 86 83
priorSet 1 87 84
assign 1 89 87
return 1 0 91
return 1 0 94
assign 1 0 97
assign 1 0 101
return 1 0 105
return 1 0 108
assign 1 0 111
assign 1 0 115
return 1 0 119
return 1 0 122
assign 1 0 125
assign 1 0 129
return 1 0 133
return 1 0 136
assign 1 0 139
assign 1 0 143
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1044758745: return bem_serializeToString_0();
case -1711670377: return bem_hashGet_0();
case 407552185: return bem_heldGetDirect_0();
case -641452021: return bem_nextGet_0();
case -1906920863: return bem_priorGet_0();
case -1785724794: return bem_once_0();
case -1480556491: return bem_toAny_0();
case 759496930: return bem_tagGet_0();
case 1365897346: return bem_serializationIteratorGet_0();
case -202912463: return bem_copy_0();
case 1547390618: return bem_delete_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -1359614197: return bem_classNameGet_0();
case -652053502: return bem_fieldNamesGet_0();
case 2132420479: return bem_many_0();
case -1642361296: return bem_print_0();
case 944073339: return bem_fieldIteratorGet_0();
case 1211029271: return bem_heldGet_0();
case 1245280421: return bem_mylistGetDirect_0();
case 2064925791: return bem_echo_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 1161638424: return bem_new_0();
case -414790800: return bem_priorGetDirect_0();
case 350691792: return bem_toString_0();
case 168135582: return bem_create_0();
case -1027059057: return bem_nextGetDirect_0();
case -71162589: return bem_iteratorGet_0();
case 814334258: return bem_serializeContents_0();
case -1961675471: return bem_mylistGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1055063645: return bem_nextSetDirect_1(bevd_0);
case -1608504765: return bem_mylistSet_1(bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case -1910488123: return bem_mylistSetDirect_1(bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -1916076811: return bem_insertBefore_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case 139298845: return bem_priorSet_1(bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1690158172: return bem_heldSetDirect_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case 1854508188: return bem_heldSet_1(bevd_0);
case 244360984: return bem_priorSetDirect_1(bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case -1535331289: return bem_nextSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1259587878: return bem_new_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_4_ContainerLinkedListNode_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_4_ContainerLinkedListNode_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_10_4_ContainerLinkedListNode();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_10_4_ContainerLinkedListNode.bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst = (BEC_3_9_10_4_ContainerLinkedListNode) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_10_4_ContainerLinkedListNode.bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_10_4_ContainerLinkedListNode.bece_BEC_3_9_10_4_ContainerLinkedListNode_bevs_type;
}
}
}
