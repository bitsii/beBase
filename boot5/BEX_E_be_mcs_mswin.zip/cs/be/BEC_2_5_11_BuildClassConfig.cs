namespace be {
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_11_BuildClassConfig : BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildClassConfig() { }
static BEC_2_5_11_BuildClassConfig() { }
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x43,0x6F,0x6E,0x66,0x69,0x67};
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_0 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_1 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_2 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_11_BuildClassConfig_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_11_BuildClassConfig_bels_2, 4));
public static new BEC_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_inst;

public static new BET_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_5_10_BuildEmitCommon bevp_emitter;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_nameSpace;
public BEC_2_4_6_TextString bevp_emitName;
public BEC_2_4_6_TextString bevp_typeEmitName;
public BEC_2_4_6_TextString bevp_fullEmitName;
public BEC_3_2_4_4_IOFilePath bevp_classPath;
public BEC_3_2_4_4_IOFilePath bevp_typePath;
public BEC_3_2_4_4_IOFilePath bevp_classDir;
public BEC_3_2_4_4_IOFilePath bevp_synPath;
public virtual BEC_2_5_11_BuildClassConfig bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_5_10_BuildEmitCommon beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevp_emitPath = beva__emitPath;
bevp_libName = beva__libName;
bevp_nameSpace = bevp_emitter.bem_getNameSpace_1(bevp_libName);
bevp_emitName = bevp_emitter.bem_getEmitName_1(bevp_np);
bevp_typeEmitName = bevp_emitter.bem_getTypeEmitName_1(bevp_np);
bevp_fullEmitName = (BEC_2_4_6_TextString) bevp_emitter.bem_getFullEmitName_2(bevp_nameSpace, bevp_emitName);
bevt_2_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_emitPath.bem_copy_0();
bevt_3_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_1_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_2_tmpany_phold.bem_addStep_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_1_tmpany_phold.bem_addStep_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_5_tmpany_phold = bevp_emitName.bem_add_1(bevt_6_tmpany_phold);
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bem_addStep_1(bevt_5_tmpany_phold);
bevt_9_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_emitPath.bem_copy_0();
bevt_10_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_9_tmpany_phold.bem_addStep_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_1));
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpany_phold.bem_addStep_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_12_tmpany_phold = bevp_typeEmitName.bem_add_1(bevt_13_tmpany_phold);
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_7_tmpany_phold.bem_addStep_1(bevt_12_tmpany_phold);
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevp_classPath.bem_parentGet_0();
bevt_14_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_classDir.bem_copy_0();
bevt_16_tmpany_phold = bece_BEC_2_5_11_BuildClassConfig_bevo_0;
bevt_15_tmpany_phold = bevp_emitName.bem_add_1(bevt_16_tmpany_phold);
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_14_tmpany_phold.bem_addStep_1(bevt_15_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_relEmitName_1(BEC_2_4_6_TextString beva_forLibName) {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_npGet_0() {
return bevp_np;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGetDirect_0() {
return bevp_np;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildEmitCommon bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitterGetDirect_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameSpaceGet_0() {
return bevp_nameSpace;
} /*method end*/
public BEC_2_4_6_TextString bem_nameSpaceGetDirect_0() {
return bevp_nameSpace;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_nameSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_nameSpaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitNameGet_0() {
return bevp_emitName;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameGetDirect_0() {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_typeEmitNameGet_0() {
return bevp_typeEmitName;
} /*method end*/
public BEC_2_4_6_TextString bem_typeEmitNameGetDirect_0() {
return bevp_typeEmitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_typeEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typeEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_fullEmitNameGet_0() {
return bevp_fullEmitName;
} /*method end*/
public BEC_2_4_6_TextString bem_fullEmitNameGetDirect_0() {
return bevp_fullEmitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_fullEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_fullEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classPathGet_0() {
return bevp_classPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classPathGetDirect_0() {
return bevp_classPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_classPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_typePathGet_0() {
return bevp_typePath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_typePathGetDirect_0() {
return bevp_typePath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_typePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classDirGet_0() {
return bevp_classDir;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classDirGetDirect_0() {
return bevp_classDir;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_classDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_synPathGet_0() {
return bevp_synPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synPathGetDirect_0() {
return bevp_synPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_synPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_synPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {2481, 2482, 2483, 2484, 2486, 2487, 2488, 2489, 2490, 2490, 2490, 2490, 2490, 2490, 2490, 2490, 2491, 2491, 2491, 2491, 2491, 2491, 2491, 2491, 2492, 2493, 2493, 2493, 2493, 2500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 78, 81, 84, 87, 91, 95, 98, 101, 105, 109, 112, 115, 119, 123, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189, 193, 196, 199, 203, 207, 210, 213, 217, 221, 224, 227, 231, 235, 238, 241, 245};
/* BEGIN LINEINFO 
assign 1 2481 46
assign 1 2482 47
assign 1 2483 48
assign 1 2484 49
assign 1 2486 50
getNameSpace 1 2486 50
assign 1 2487 51
getEmitName 1 2487 51
assign 1 2488 52
getTypeEmitName 1 2488 52
assign 1 2489 53
getFullEmitName 2 2489 53
assign 1 2490 54
copy 0 2490 54
assign 1 2490 55
emitLangGet 0 2490 55
assign 1 2490 56
addStep 1 2490 56
assign 1 2490 57
new 0 2490 57
assign 1 2490 58
addStep 1 2490 58
assign 1 2490 59
fileExtGet 0 2490 59
assign 1 2490 60
add 1 2490 60
assign 1 2490 61
addStep 1 2490 61
assign 1 2491 62
copy 0 2491 62
assign 1 2491 63
emitLangGet 0 2491 63
assign 1 2491 64
addStep 1 2491 64
assign 1 2491 65
new 0 2491 65
assign 1 2491 66
addStep 1 2491 66
assign 1 2491 67
fileExtGet 0 2491 67
assign 1 2491 68
add 1 2491 68
assign 1 2491 69
addStep 1 2491 69
assign 1 2492 70
parentGet 0 2492 70
assign 1 2493 71
copy 0 2493 71
assign 1 2493 72
new 0 2493 72
assign 1 2493 73
add 1 2493 73
assign 1 2493 74
addStep 1 2493 74
return 1 2500 78
return 1 0 81
return 1 0 84
assign 1 0 87
assign 1 0 91
return 1 0 95
return 1 0 98
assign 1 0 101
assign 1 0 105
return 1 0 109
return 1 0 112
assign 1 0 115
assign 1 0 119
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
return 1 0 193
return 1 0 196
assign 1 0 199
assign 1 0 203
return 1 0 207
return 1 0 210
assign 1 0 213
assign 1 0 217
return 1 0 221
return 1 0 224
assign 1 0 227
assign 1 0 231
return 1 0 235
return 1 0 238
assign 1 0 241
assign 1 0 245
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -195266806: return bem_toString_0();
case -811418832: return bem_many_0();
case -1933311241: return bem_fullEmitNameGetDirect_0();
case -1778020458: return bem_typePathGetDirect_0();
case -189856578: return bem_copy_0();
case -440715839: return bem_nameSpaceGetDirect_0();
case 496947523: return bem_fullEmitNameGet_0();
case -1047794594: return bem_libNameGet_0();
case 538632487: return bem_serializationIteratorGet_0();
case 1236464998: return bem_serializeContents_0();
case -166515831: return bem_fieldNamesGet_0();
case 289829207: return bem_typePathGet_0();
case -265928475: return bem_classNameGet_0();
case -1735879417: return bem_print_0();
case 2086745336: return bem_emitNameGetDirect_0();
case 2121039924: return bem_new_0();
case 2049585538: return bem_classPathGet_0();
case 1057323332: return bem_toAny_0();
case 1483562151: return bem_emitPathGet_0();
case -1438038411: return bem_sourceFileNameGet_0();
case -802937471: return bem_emitPathGetDirect_0();
case 803060031: return bem_create_0();
case -1856486979: return bem_deserializeClassNameGet_0();
case 860507381: return bem_synPathGetDirect_0();
case 24125772: return bem_iteratorGet_0();
case -96467196: return bem_nameSpaceGet_0();
case -538760581: return bem_classPathGetDirect_0();
case 2111391138: return bem_serializeToString_0();
case 893274194: return bem_tagGet_0();
case -299023655: return bem_echo_0();
case -1326668191: return bem_synPathGet_0();
case -825395499: return bem_libNameGetDirect_0();
case 8813092: return bem_typeEmitNameGet_0();
case 880406214: return bem_npGetDirect_0();
case 2088149236: return bem_emitterGetDirect_0();
case -1724445182: return bem_npGet_0();
case 361785955: return bem_emitNameGet_0();
case 1189378498: return bem_emitterGet_0();
case -290961611: return bem_typeEmitNameGetDirect_0();
case -662799463: return bem_classDirGetDirect_0();
case 1870744321: return bem_once_0();
case -1232978478: return bem_hashGet_0();
case -992120130: return bem_fieldIteratorGet_0();
case 80416975: return bem_classDirGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1157171635: return bem_emitPathSetDirect_1(bevd_0);
case -905872983: return bem_equals_1(bevd_0);
case 146723804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1171661229: return bem_otherType_1(bevd_0);
case 1628306760: return bem_notEquals_1(bevd_0);
case -267062499: return bem_sameType_1(bevd_0);
case -236571014: return bem_libNameSetDirect_1(bevd_0);
case -132983687: return bem_undefined_1(bevd_0);
case 1669121148: return bem_copyTo_1(bevd_0);
case -119475544: return bem_npSet_1(bevd_0);
case 1681419755: return bem_defined_1(bevd_0);
case -1549788421: return bem_synPathSetDirect_1(bevd_0);
case -1233382567: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1235591131: return bem_fullEmitNameSet_1(bevd_0);
case -1818008012: return bem_classDirSetDirect_1(bevd_0);
case -490313093: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 970003054: return bem_nameSpaceSet_1(bevd_0);
case 250525307: return bem_typeEmitNameSetDirect_1(bevd_0);
case 211363363: return bem_emitNameSet_1(bevd_0);
case -1850756230: return bem_typeEmitNameSet_1(bevd_0);
case -840987461: return bem_npSetDirect_1(bevd_0);
case -1741848426: return bem_typePathSetDirect_1(bevd_0);
case -453983493: return bem_emitPathSet_1(bevd_0);
case -1184425479: return bem_classDirSet_1(bevd_0);
case -1366946606: return bem_emitNameSetDirect_1(bevd_0);
case -640311463: return bem_emitterSetDirect_1(bevd_0);
case -1668817184: return bem_fullEmitNameSetDirect_1(bevd_0);
case -564148923: return bem_sameObject_1(bevd_0);
case -1174293741: return bem_emitterSet_1(bevd_0);
case 390408557: return bem_synPathSet_1(bevd_0);
case -1108496649: return bem_otherClass_1(bevd_0);
case 1277240969: return bem_relEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1142721352: return bem_libNameSet_1(bevd_0);
case 739346507: return bem_nameSpaceSetDirect_1(bevd_0);
case 672548399: return bem_classPathSetDirect_1(bevd_0);
case 1374565339: return bem_typePathSet_1(bevd_0);
case 525545408: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1374125024: return bem_undef_1(bevd_0);
case 1025270681: return bem_sameClass_1(bevd_0);
case -1433803932: return bem_def_1(bevd_0);
case -1876511629: return bem_classPathSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1931375919: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 68692131: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -383175850: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -110664853: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1765848815: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1365987158: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -381061425: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -756797151: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, (BEC_2_5_10_BuildEmitCommon) bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildClassConfig_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_11_BuildClassConfig_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_11_BuildClassConfig();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst = (BEC_2_5_11_BuildClassConfig) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_type;
}
}
}
