namespace be {
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_11_BuildClassConfig : BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildClassConfig() { }
static BEC_2_5_11_BuildClassConfig() { }
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x43,0x6F,0x6E,0x66,0x69,0x67};
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_0 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_1 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_2 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_11_BuildClassConfig_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_11_BuildClassConfig_bels_2, 4));
public static new BEC_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_inst;

public static new BET_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_5_10_BuildEmitCommon bevp_emitter;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_nameSpace;
public BEC_2_4_6_TextString bevp_emitName;
public BEC_2_4_6_TextString bevp_typeEmitName;
public BEC_2_4_6_TextString bevp_fullEmitName;
public BEC_3_2_4_4_IOFilePath bevp_classPath;
public BEC_3_2_4_4_IOFilePath bevp_typePath;
public BEC_3_2_4_4_IOFilePath bevp_classDir;
public BEC_3_2_4_4_IOFilePath bevp_synPath;
public virtual BEC_2_5_11_BuildClassConfig bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_5_10_BuildEmitCommon beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevp_emitPath = beva__emitPath;
bevp_libName = beva__libName;
bevp_nameSpace = bevp_emitter.bem_getNameSpace_1(bevp_libName);
bevp_emitName = bevp_emitter.bem_getEmitName_1(bevp_np);
bevp_typeEmitName = bevp_emitter.bem_getTypeEmitName_1(bevp_np);
bevp_fullEmitName = (BEC_2_4_6_TextString) bevp_emitter.bem_getFullEmitName_2(bevp_nameSpace, bevp_emitName);
bevt_2_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_emitPath.bem_copy_0();
bevt_3_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_1_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_2_tmpany_phold.bem_addStep_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_1_tmpany_phold.bem_addStep_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_5_tmpany_phold = bevp_emitName.bem_add_1(bevt_6_tmpany_phold);
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bem_addStep_1(bevt_5_tmpany_phold);
bevt_9_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_emitPath.bem_copy_0();
bevt_10_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_9_tmpany_phold.bem_addStep_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_1));
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpany_phold.bem_addStep_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_12_tmpany_phold = bevp_typeEmitName.bem_add_1(bevt_13_tmpany_phold);
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_7_tmpany_phold.bem_addStep_1(bevt_12_tmpany_phold);
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevp_classPath.bem_parentGet_0();
bevt_14_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_classDir.bem_copy_0();
bevt_16_tmpany_phold = bece_BEC_2_5_11_BuildClassConfig_bevo_0;
bevt_15_tmpany_phold = bevp_emitName.bem_add_1(bevt_16_tmpany_phold);
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_14_tmpany_phold.bem_addStep_1(bevt_15_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_relEmitName_1(BEC_2_4_6_TextString beva_forLibName) {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_npGet_0() {
return bevp_np;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGetDirect_0() {
return bevp_np;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildEmitCommon bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitterGetDirect_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameSpaceGet_0() {
return bevp_nameSpace;
} /*method end*/
public BEC_2_4_6_TextString bem_nameSpaceGetDirect_0() {
return bevp_nameSpace;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_nameSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_nameSpaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitNameGet_0() {
return bevp_emitName;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameGetDirect_0() {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_typeEmitNameGet_0() {
return bevp_typeEmitName;
} /*method end*/
public BEC_2_4_6_TextString bem_typeEmitNameGetDirect_0() {
return bevp_typeEmitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_typeEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typeEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_fullEmitNameGet_0() {
return bevp_fullEmitName;
} /*method end*/
public BEC_2_4_6_TextString bem_fullEmitNameGetDirect_0() {
return bevp_fullEmitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_fullEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_fullEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classPathGet_0() {
return bevp_classPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classPathGetDirect_0() {
return bevp_classPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_classPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_typePathGet_0() {
return bevp_typePath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_typePathGetDirect_0() {
return bevp_typePath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_typePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classDirGet_0() {
return bevp_classDir;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classDirGetDirect_0() {
return bevp_classDir;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_classDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_synPathGet_0() {
return bevp_synPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synPathGetDirect_0() {
return bevp_synPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_synPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_synPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {2196, 2197, 2198, 2199, 2201, 2202, 2203, 2204, 2205, 2205, 2205, 2205, 2205, 2205, 2205, 2205, 2206, 2206, 2206, 2206, 2206, 2206, 2206, 2206, 2207, 2208, 2208, 2208, 2208, 2215, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 78, 81, 84, 87, 91, 95, 98, 101, 105, 109, 112, 115, 119, 123, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189, 193, 196, 199, 203, 207, 210, 213, 217, 221, 224, 227, 231, 235, 238, 241, 245};
/* BEGIN LINEINFO 
assign 1 2196 46
assign 1 2197 47
assign 1 2198 48
assign 1 2199 49
assign 1 2201 50
getNameSpace 1 2201 50
assign 1 2202 51
getEmitName 1 2202 51
assign 1 2203 52
getTypeEmitName 1 2203 52
assign 1 2204 53
getFullEmitName 2 2204 53
assign 1 2205 54
copy 0 2205 54
assign 1 2205 55
emitLangGet 0 2205 55
assign 1 2205 56
addStep 1 2205 56
assign 1 2205 57
new 0 2205 57
assign 1 2205 58
addStep 1 2205 58
assign 1 2205 59
fileExtGet 0 2205 59
assign 1 2205 60
add 1 2205 60
assign 1 2205 61
addStep 1 2205 61
assign 1 2206 62
copy 0 2206 62
assign 1 2206 63
emitLangGet 0 2206 63
assign 1 2206 64
addStep 1 2206 64
assign 1 2206 65
new 0 2206 65
assign 1 2206 66
addStep 1 2206 66
assign 1 2206 67
fileExtGet 0 2206 67
assign 1 2206 68
add 1 2206 68
assign 1 2206 69
addStep 1 2206 69
assign 1 2207 70
parentGet 0 2207 70
assign 1 2208 71
copy 0 2208 71
assign 1 2208 72
new 0 2208 72
assign 1 2208 73
add 1 2208 73
assign 1 2208 74
addStep 1 2208 74
return 1 2215 78
return 1 0 81
return 1 0 84
assign 1 0 87
assign 1 0 91
return 1 0 95
return 1 0 98
assign 1 0 101
assign 1 0 105
return 1 0 109
return 1 0 112
assign 1 0 115
assign 1 0 119
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
return 1 0 193
return 1 0 196
assign 1 0 199
assign 1 0 203
return 1 0 207
return 1 0 210
assign 1 0 213
assign 1 0 217
return 1 0 221
return 1 0 224
assign 1 0 227
assign 1 0 231
return 1 0 235
return 1 0 238
assign 1 0 241
assign 1 0 245
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -315597353: return bem_typePathGetDirect_0();
case 367195678: return bem_once_0();
case 402201008: return bem_new_0();
case -1854726950: return bem_echo_0();
case -1795002401: return bem_toString_0();
case 593982346: return bem_classPathGet_0();
case 682604587: return bem_serializeContents_0();
case 612600565: return bem_npGetDirect_0();
case 444039622: return bem_nameSpaceGet_0();
case -1142420217: return bem_classDirGetDirect_0();
case 748315678: return bem_tagGet_0();
case 1342765490: return bem_toAny_0();
case 1788013639: return bem_synPathGet_0();
case 808044123: return bem_hashGet_0();
case -2058188416: return bem_emitNameGetDirect_0();
case -1823818123: return bem_emitNameGet_0();
case 1426273537: return bem_libNameGetDirect_0();
case 2034076774: return bem_emitterGetDirect_0();
case -636994806: return bem_sourceFileNameGet_0();
case 1678261270: return bem_print_0();
case 537145720: return bem_npGet_0();
case 966149554: return bem_create_0();
case 168640871: return bem_emitPathGetDirect_0();
case -656937356: return bem_many_0();
case 1556714681: return bem_typeEmitNameGet_0();
case 55812595: return bem_serializeToString_0();
case 582461173: return bem_emitterGet_0();
case -1451599319: return bem_typeEmitNameGetDirect_0();
case -1239766363: return bem_nameSpaceGetDirect_0();
case -434919379: return bem_deserializeClassNameGet_0();
case -1975455714: return bem_copy_0();
case -1009503337: return bem_typePathGet_0();
case 2144246944: return bem_classPathGetDirect_0();
case 1378470311: return bem_classDirGet_0();
case 9957435: return bem_iteratorGet_0();
case -772967023: return bem_classNameGet_0();
case -1661273666: return bem_libNameGet_0();
case -399678053: return bem_emitPathGet_0();
case -604312045: return bem_serializationIteratorGet_0();
case 2050314725: return bem_synPathGetDirect_0();
case -368347729: return bem_fieldNamesGet_0();
case 1860492410: return bem_fieldIteratorGet_0();
case 119149147: return bem_fullEmitNameGetDirect_0();
case -620284752: return bem_fullEmitNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 305375043: return bem_emitterSetDirect_1(bevd_0);
case 504977191: return bem_relEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1101399885: return bem_emitPathSetDirect_1(bevd_0);
case 507937242: return bem_emitNameSet_1(bevd_0);
case 267174377: return bem_def_1(bevd_0);
case 1816680860: return bem_emitNameSetDirect_1(bevd_0);
case -1274727212: return bem_typePathSet_1(bevd_0);
case 1272631429: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -714900612: return bem_copyTo_1(bevd_0);
case -1007540340: return bem_notEquals_1(bevd_0);
case -1467417659: return bem_typeEmitNameSetDirect_1(bevd_0);
case 1621186357: return bem_sameType_1(bevd_0);
case 1647993291: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1362165708: return bem_fullEmitNameSet_1(bevd_0);
case -1194473609: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1759462200: return bem_npSetDirect_1(bevd_0);
case -1626185860: return bem_nameSpaceSet_1(bevd_0);
case 1818721311: return bem_classDirSetDirect_1(bevd_0);
case -325228640: return bem_classPathSetDirect_1(bevd_0);
case 765679346: return bem_nameSpaceSetDirect_1(bevd_0);
case -1295895894: return bem_classDirSet_1(bevd_0);
case 1860004607: return bem_classPathSet_1(bevd_0);
case 195308005: return bem_sameObject_1(bevd_0);
case 940549526: return bem_typeEmitNameSet_1(bevd_0);
case 1387905583: return bem_libNameSetDirect_1(bevd_0);
case -1822209431: return bem_fullEmitNameSetDirect_1(bevd_0);
case 543061021: return bem_otherClass_1(bevd_0);
case -874148668: return bem_typePathSetDirect_1(bevd_0);
case 1448933357: return bem_otherType_1(bevd_0);
case 1614496109: return bem_undef_1(bevd_0);
case -1602510810: return bem_libNameSet_1(bevd_0);
case -1673981992: return bem_npSet_1(bevd_0);
case 350775730: return bem_equals_1(bevd_0);
case 757856735: return bem_emitPathSet_1(bevd_0);
case -2144202949: return bem_sameClass_1(bevd_0);
case 1453251956: return bem_synPathSetDirect_1(bevd_0);
case 1163078007: return bem_undefined_1(bevd_0);
case -700310720: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1733251353: return bem_synPathSet_1(bevd_0);
case -991365338: return bem_defined_1(bevd_0);
case -823326028: return bem_emitterSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 325307565: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1385197575: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1280867989: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1833007700: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1584099228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -187061774: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -961973758: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1775631621: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, (BEC_2_5_10_BuildEmitCommon) bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildClassConfig_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_11_BuildClassConfig_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_11_BuildClassConfig();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst = (BEC_2_5_11_BuildClassConfig) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_type;
}
}
}
