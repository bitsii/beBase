namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public sealed class BEC_3_2_4_17_IOFileDirectoryIterator : BEC_2_6_6_SystemObject {
public BEC_3_2_4_17_IOFileDirectoryIterator() { }
static BEC_3_2_4_17_IOFileDirectoryIterator() { }

   
    public IEnumerator<string> bevi_dir;
    
   private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static new BEC_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;

public static new BET_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;

public BEC_2_2_4_IOFile bevp_dir;
public BEC_2_5_4_LogicBool bevp_opened;
public BEC_2_5_4_LogicBool bevp_closed;
public BEC_2_2_4_IOFile bevp_current;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_current = null;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_2_4_IOFile beva__dir) {
bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_open_0() {
BEC_2_4_6_TextString bevl_path = null;
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (bevp_dir == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 555 */ {
bevt_1_tmpany_phold = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_tmpany_phold.bem_toString_0();
} /* Line: 556 */
 else  /* Line: 558 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0));
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 559 */
if (bevp_closed.bevi_bool) /* Line: 562 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(64, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1));
bevt_4_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 564 */
if (bevp_opened.bevi_bool) /* Line: 566 */ {
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2));
bevt_6_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 567 */

      bevi_dir = Directory.EnumerateFileSystemEntries(bevl_path.bems_toCsString(), "*", SearchOption.TopDirectoryOnly).GetEnumerator();
      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 588 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 591 */
 else  /* Line: 592 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 595 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 600 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 600 */
if (bevp_opened.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 601 */ {
bem_open_0();
} /* Line: 601 */
if (bevp_current == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_nextGet_0() {
BEC_2_2_4_IOFile bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 606 */ {
return null;
} /* Line: 606 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 607 */ {
bem_open_0();
} /* Line: 607 */
bevl_toRet = bevp_current;
bem_advance_0();
return bevl_toRet;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_advance_0() {
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 617 */ {
return this;
} /* Line: 617 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 618 */ {
return this;
} /* Line: 618 */
if (bevp_current == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 619 */ {
return this;
} /* Line: 619 */

      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 635 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 637 */
 else  /* Line: 638 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 641 */
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_close_0() {

      bevi_dir.Dispose();
      bevi_dir = null;
      return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGet_0() {
return bevp_dir;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGetDirect_0() {
return bevp_dir;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGet_0() {
return bevp_opened;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGetDirect_0() {
return bevp_opened;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGet_0() {
return bevp_closed;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGetDirect_0() {
return bevp_closed;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGetDirect_0() {
return bevp_current;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {538, 539, 540, 546, 547, 555, 555, 556, 556, 559, 559, 559, 564, 564, 564, 567, 567, 567, 588, 588, 590, 591, 594, 595, 600, 600, 601, 601, 601, 602, 602, 606, 607, 607, 607, 608, 609, 610, 617, 618, 618, 618, 619, 619, 619, 635, 635, 636, 637, 639, 640, 641, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {32, 33, 34, 38, 39, 54, 59, 60, 61, 64, 65, 66, 69, 70, 71, 74, 75, 76, 83, 88, 89, 90, 93, 94, 103, 104, 106, 111, 112, 114, 119, 125, 127, 132, 133, 135, 136, 137, 145, 147, 152, 153, 155, 160, 161, 167, 172, 173, 174, 177, 178, 179, 190, 193, 196, 200, 204, 207, 210, 214, 218, 221, 224, 228, 232, 235, 238, 242};
/* BEGIN LINEINFO 
assign 1 538 32
new 0 538 32
assign 1 539 33
new 0 539 33
assign 1 540 34
new 0 546 38
assign 1 547 39
assign 1 555 54
def 1 555 59
assign 1 556 60
pathGet 0 556 60
assign 1 556 61
toString 0 556 61
assign 1 559 64
new 0 559 64
assign 1 559 65
new 1 559 65
throw 1 559 66
assign 1 564 69
new 0 564 69
assign 1 564 70
new 1 564 70
throw 1 564 71
assign 1 567 74
new 0 567 74
assign 1 567 75
new 1 567 75
throw 1 567 76
assign 1 588 83
def 1 588 88
assign 1 590 89
new 0 590 89
assign 1 591 90
apNew 1 591 90
assign 1 594 93
new 0 594 93
assign 1 595 94
new 0 595 94
assign 1 600 103
new 0 600 103
return 1 600 104
assign 1 601 106
not 0 601 111
open 0 601 112
assign 1 602 114
def 1 602 119
return 1 602 119
return 1 606 125
assign 1 607 127
not 0 607 132
open 0 607 133
assign 1 608 135
advance 0 609 136
return 1 610 137
return 1 617 145
assign 1 618 147
not 0 618 152
return 1 618 153
assign 1 619 155
undef 1 619 160
return 1 619 161
assign 1 635 167
def 1 635 172
assign 1 636 173
new 0 636 173
assign 1 637 174
apNew 1 637 174
assign 1 639 177
new 0 639 177
assign 1 640 178
new 0 640 178
assign 1 641 179
return 1 0 190
return 1 0 193
assign 1 0 196
assign 1 0 200
return 1 0 204
return 1 0 207
assign 1 0 210
assign 1 0 214
return 1 0 218
return 1 0 221
assign 1 0 224
assign 1 0 228
return 1 0 232
return 1 0 235
assign 1 0 238
assign 1 0 242
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1945803401: return bem_print_0();
case -2084016052: return bem_serializeToString_0();
case 2086474367: return bem_create_0();
case 724406176: return bem_dirGet_0();
case 2054264246: return bem_dirGetDirect_0();
case 1738591028: return bem_fieldNamesGet_0();
case -1530291369: return bem_closedGetDirect_0();
case -289655305: return bem_currentGetDirect_0();
case -191741087: return bem_close_0();
case 1438915338: return bem_once_0();
case 1169011989: return bem_toString_0();
case -518976870: return bem_openedGet_0();
case -1304615187: return bem_advance_0();
case 1070651373: return bem_hasNextGet_0();
case -1409233752: return bem_toAny_0();
case -695733973: return bem_hashGet_0();
case -576816204: return bem_sourceFileNameGet_0();
case 1754842141: return bem_closedGet_0();
case 1606642997: return bem_new_0();
case 1066489349: return bem_many_0();
case 1546544584: return bem_serializationIteratorGet_0();
case -408522205: return bem_serializeContents_0();
case 167399763: return bem_deserializeClassNameGet_0();
case 871811179: return bem_nextGet_0();
case -373483362: return bem_classNameGet_0();
case 344054741: return bem_open_0();
case -830733381: return bem_echo_0();
case -1938009111: return bem_openedGetDirect_0();
case -1858717456: return bem_currentGet_0();
case -1847620794: return bem_iteratorGet_0();
case 1425790109: return bem_fieldIteratorGet_0();
case 2034825137: return bem_tagGet_0();
case -630280728: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1790575350: return bem_sameClass_1(bevd_0);
case -2045883718: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 232552830: return bem_otherType_1(bevd_0);
case 974269442: return bem_closedSet_1(bevd_0);
case -190641341: return bem_new_1((BEC_2_2_4_IOFile) bevd_0);
case -726390043: return bem_undef_1(bevd_0);
case -85967812: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -951592994: return bem_currentSet_1(bevd_0);
case 1642039472: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1663786357: return bem_equals_1(bevd_0);
case 2094992736: return bem_currentSetDirect_1(bevd_0);
case -972948345: return bem_dirSetDirect_1(bevd_0);
case -1371116116: return bem_otherClass_1(bevd_0);
case 469924257: return bem_openedSetDirect_1(bevd_0);
case -463115686: return bem_def_1(bevd_0);
case 876386412: return bem_sameObject_1(bevd_0);
case 307195148: return bem_closedSetDirect_1(bevd_0);
case 575763691: return bem_undefined_1(bevd_0);
case -1854318841: return bem_copyTo_1(bevd_0);
case -2073425080: return bem_sameType_1(bevd_0);
case 542523031: return bem_defined_1(bevd_0);
case 1250583166: return bem_dirSet_1(bevd_0);
case 1449183263: return bem_notEquals_1(bevd_0);
case 491873122: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1195182496: return bem_openedSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1558133875: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -897682046: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 990151340: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600497328: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 116337276: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2028666619: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1471832670: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst = (BEC_3_2_4_17_IOFileDirectoryIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;
}
}
}
