namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_7_XmlComment : BEC_2_3_3_XmlTag {
public BEC_2_3_7_XmlComment() { }
static BEC_2_3_7_XmlComment() { }
private static byte[] becc_BEC_2_3_7_XmlComment_clname = {0x58,0x6D,0x6C,0x3A,0x43,0x6F,0x6D,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_3_7_XmlComment_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static new BEC_2_3_7_XmlComment bece_BEC_2_3_7_XmlComment_bevs_inst;

public static new BET_2_3_7_XmlComment bece_BEC_2_3_7_XmlComment_bevs_type;

public BEC_2_4_6_TextString bevp_contents;
public virtual BEC_2_3_7_XmlComment bem_new_1(BEC_2_4_6_TextString beva__contents) {
bevp_contents = beva__contents;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return bevp_contents;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_contentsGet_0() {
return bevp_contents;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsGetDirect_0() {
return bevp_contents;
} /*method end*/
public virtual BEC_2_3_7_XmlComment bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_contents = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_7_XmlComment bem_contentsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_contents = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {97, 102, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 18, 21, 24, 27, 31};
/* BEGIN LINEINFO 
assign 1 97 14
return 1 102 18
return 1 0 21
return 1 0 24
assign 1 0 27
assign 1 0 31
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -652053502: return bem_fieldNamesGet_0();
case 944073339: return bem_fieldIteratorGet_0();
case -1785724794: return bem_once_0();
case -1480556491: return bem_toAny_0();
case 168135582: return bem_create_0();
case -2060942945: return bem_contentsGetDirect_0();
case 2132420479: return bem_many_0();
case -1359614197: return bem_classNameGet_0();
case -1044758745: return bem_serializeToString_0();
case 759496930: return bem_tagGet_0();
case 350691792: return bem_toString_0();
case 814334258: return bem_serializeContents_0();
case -1555833296: return bem_sourceFileNameGet_0();
case -1642361296: return bem_print_0();
case -202912463: return bem_copy_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case 1365897346: return bem_serializationIteratorGet_0();
case 1161638424: return bem_new_0();
case -71162589: return bem_iteratorGet_0();
case -1711670377: return bem_hashGet_0();
case 2064925791: return bem_echo_0();
case -1058616347: return bem_contentsGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1829001662: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case -1859795496: return bem_contentsSetDirect_1(bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case -1168364336: return bem_contentsSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_3_7_XmlComment_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_7_XmlComment_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_7_XmlComment();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_7_XmlComment.bece_BEC_2_3_7_XmlComment_bevs_inst = (BEC_2_3_7_XmlComment) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_7_XmlComment.bece_BEC_2_3_7_XmlComment_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_3_7_XmlComment.bece_BEC_2_3_7_XmlComment_bevs_type;
}
}
}
