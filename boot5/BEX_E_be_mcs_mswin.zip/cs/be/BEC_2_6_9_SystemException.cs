namespace be {
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException : BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
static BEC_2_6_9_SystemException() { }
private static byte[] becc_BEC_2_6_9_SystemException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_9_SystemException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_1 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_2 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_3 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_4 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_6 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_7 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_9 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_9, 28));
private static byte[] bece_BEC_2_6_9_SystemException_bels_10 = {0x67,0x65,0x74,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_6_9_SystemException_bels_11 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_11, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_12 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_12, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_13 = {0x0D,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_11, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_14 = {0x46,0x72,0x61,0x6D,0x65,0x20,0x6C,0x69,0x6E,0x65,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_14, 14));
private static byte[] bece_BEC_2_6_9_SystemException_bels_15 = {0x61,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_15, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_16 = {0x73,0x74,0x61,0x72,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_16, 9));
private static byte[] bece_BEC_2_6_9_SystemException_bels_17 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_17, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_9 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_18 = {0x65,0x6E,0x64,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_18, 7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_11 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_19 = {0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_19, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_13 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_17, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_20 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_17 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_21 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_21, 5));
private static byte[] bece_BEC_2_6_9_SystemException_bels_22 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_22, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_23 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_23, 15));
private static byte[] bece_BEC_2_6_9_SystemException_bels_24 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_24, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_22 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_25 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x65,0x6E,0x64,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_25, 13));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_24 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_25 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_26 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_27 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_22, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_29 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_30 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_31 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_26 = {0x2E};
private static byte[] bece_BEC_2_6_9_SystemException_bels_27 = {0x63,0x61,0x6C,0x6C,0x50,0x61,0x72,0x74,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_27, 10));
private static byte[] bece_BEC_2_6_9_SystemException_bels_28 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_28, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_34 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_35 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_29 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6D,0x74,0x64,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_29, 15));
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_28, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_30 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_30, 4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_39 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_31 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_31, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_41 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_42 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_32 = {0x70,0x72,0x65,0x20,0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_32, 21));
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_28, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_33 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_33, 17));
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_28, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_34 = {0x61,0x64,0x64,0x69,0x6E,0x67,0x20,0x66,0x72,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_34, 12));
private static byte[] bece_BEC_2_6_9_SystemException_bels_35 = {0x6E,0x6F,0x20,0x65,0x6E,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_35, 6));
private static byte[] bece_BEC_2_6_9_SystemException_bels_36 = {0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_37 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_37, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_38 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_38, 16));
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_30, 4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_52 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_53 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_39 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_39, 4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_55 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_56 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_38, 16));
private static byte[] bece_BEC_2_6_9_SystemException_bels_40 = {0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_58 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_40, 1));
public static new BEC_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_inst;

public static new BET_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_type;

public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_5_4_LogicBool bevp_vv;
public virtual BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
bevp_vv = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_description = beva_descr;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_0));
if (bevp_description == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_1));
bevt_1_tmpany_phold = bevl_toRet.bemd_1(594567717, bevt_2_tmpany_phold);
bevl_toRet = bevt_1_tmpany_phold.bemd_1(594567717, bevp_description);
} /* Line: 59 */
if (bevp_fileName == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_6_9_SystemException_bels_2));
bevt_4_tmpany_phold = bevl_toRet.bemd_1(594567717, bevt_5_tmpany_phold);
bevl_toRet = bevt_4_tmpany_phold.bemd_1(594567717, bevp_fileName);
} /* Line: 62 */
if (bevp_lineNumber == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 64 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_3));
bevt_7_tmpany_phold = bevl_toRet.bemd_1(594567717, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_lineNumber.bemd_0(2134647390);
bevl_toRet = bevt_7_tmpany_phold.bemd_1(594567717, bevt_9_tmpany_phold);
} /* Line: 65 */
if (bevp_lang == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 67 */ {
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_4));
bevt_11_tmpany_phold = bevl_toRet.bemd_1(594567717, bevt_12_tmpany_phold);
bevl_toRet = bevt_11_tmpany_phold.bemd_1(594567717, bevp_lang);
} /* Line: 68 */
if (bevp_emitLang == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 70 */ {
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_5));
bevt_14_tmpany_phold = bevl_toRet.bemd_1(594567717, bevt_15_tmpany_phold);
bevl_toRet = bevt_14_tmpany_phold.bemd_1(594567717, bevp_emitLang);
} /* Line: 71 */
if (bevp_methodName == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_6_9_SystemException_bels_6));
bevt_17_tmpany_phold = bevl_toRet.bemd_1(594567717, bevt_18_tmpany_phold);
bevl_toRet = bevt_17_tmpany_phold.bemd_1(594567717, bevp_methodName);
} /* Line: 74 */
if (bevp_klassName == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 76 */ {
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_6_9_SystemException_bels_7));
bevt_20_tmpany_phold = bevl_toRet.bemd_1(594567717, bevt_21_tmpany_phold);
bevl_toRet = bevt_20_tmpany_phold.bemd_1(594567717, bevp_klassName);
} /* Line: 77 */
if (bevp_framesText == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_8));
bevt_23_tmpany_phold = bevl_toRet.bemd_1(594567717, bevt_24_tmpany_phold);
bevl_toRet = bevt_23_tmpany_phold.bemd_1(594567717, bevp_framesText);
} /* Line: 80 */
if (bevp_frames == null) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_26_tmpany_phold = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(594567717, bevt_26_tmpany_phold);
} /* Line: 83 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_translateEmittedException_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
try  /* Line: 89 */ {
bem_translateEmittedExceptionInner_0();
} /* Line: 90 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_1_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_0;
bevt_1_tmpany_phold.bem_print_0();
if (bevl_e == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 93 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_10));
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = bevl_e.bemd_2(2000867040, bevt_4_tmpany_phold, bevt_5_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 93 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 93 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 93 */
 else  /* Line: 93 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 93 */ {
bevt_6_tmpany_phold = bevl_e.bemd_0(-819949273);
bevt_6_tmpany_phold.bemd_0(1686342789);
} /* Line: 94 */
} /* Line: 93 */
return this;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_translateEmittedExceptionInner_0() {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_121_tmpany_phold = null;
BEC_2_4_6_TextString bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_6_TextString bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_4_6_TextString bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_6_TextString bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_4_6_TextString bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_134_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_135_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_136_tmpany_phold = null;
BEC_2_4_6_TextString bevt_137_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_4_6_TextString bevt_141_tmpany_phold = null;
BEC_2_4_6_TextString bevt_142_tmpany_phold = null;
BEC_2_4_6_TextString bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_4_6_TextString bevt_145_tmpany_phold = null;
if (bevp_translated == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 101 */ {
if (bevp_translated.bevi_bool) /* Line: 101 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 101 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 101 */
 else  /* Line: 101 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 101 */ {
return this;
} /* Line: 102 */
if (bevp_vv == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevp_vv = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 105 */
bevp_translated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 108 */ {
if (bevp_lang == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 108 */
 else  /* Line: 108 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 108 */ {
bevt_17_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_1;
bevt_16_tmpany_phold = bevp_lang.bem_equals_1(bevt_17_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_2;
bevt_18_tmpany_phold = bevp_lang.bem_equals_1(bevt_19_tmpany_phold);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 108 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 108 */
 else  /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 108 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_13));
bevl_ltok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_20_tmpany_phold);
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_22_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_3;
bevt_21_tmpany_phold = bevp_lang.bem_equals_1(bevt_22_tmpany_phold);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevl_isCs = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 112 */
 else  /* Line: 113 */ {
bevl_isCs = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 114 */
bevt_0_tmpany_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 116 */ {
bevt_23_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 116 */ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
if (bevp_vv.bevi_bool) /* Line: 117 */ {
bevt_25_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_4;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevl_line);
bevt_24_tmpany_phold.bem_print_0();
} /* Line: 118 */
bevt_26_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_5;
bevl_start = bevl_line.bem_find_1(bevt_26_tmpany_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_29_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_6;
if (bevl_start.bevi_int >= bevt_29_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
 else  /* Line: 123 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 123 */ {
if (bevp_vv.bevi_bool) /* Line: 124 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_7;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevl_start);
bevt_30_tmpany_phold.bem_print_0();
} /* Line: 125 */
bevt_32_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_8;
bevt_34_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_9;
bevt_33_tmpany_phold = bevl_start.bem_add_1(bevt_34_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
if (bevl_end == null) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 128 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 128 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 128 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 128 */
 else  /* Line: 128 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 128 */ {
if (bevp_vv.bevi_bool) /* Line: 129 */ {
bevt_38_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_10;
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_add_1(bevl_end);
bevt_37_tmpany_phold.bem_print_0();
} /* Line: 130 */
bevt_40_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_11;
bevt_39_tmpany_phold = bevl_start.bem_add_1(bevt_40_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_39_tmpany_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 134 */ {
bevt_41_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_12;
bevl_start = bevl_line.bem_find_2(bevt_41_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 136 */ {
bevt_44_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_13;
bevt_43_tmpany_phold = bevl_start.bem_add_1(bevt_44_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_43_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_14;
bevt_45_tmpany_phold = bevl_inPart.bem_ends_1(bevt_46_tmpany_phold);
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 139 */ {
bevt_48_tmpany_phold = bevl_inPart.bem_sizeGet_0();
bevt_49_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_15;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_subtract_1(bevt_49_tmpany_phold);
bevl_inPart.bem_sizeSet_1(bevt_47_tmpany_phold);
} /* Line: 140 */
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_20));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_50_tmpany_phold);
if (bevl_pdelim == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 144 */ {
bevt_52_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_16;
bevl_efile = bevl_inPart.bem_substring_2(bevt_52_tmpany_phold, bevl_pdelim);
bevt_54_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_17;
bevt_53_tmpany_phold = bevl_pdelim.bem_add_1(bevt_54_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_53_tmpany_phold);
bevt_56_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_18;
bevt_55_tmpany_phold = bevl_iv.bem_begins_1(bevt_56_tmpany_phold);
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevt_57_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_57_tmpany_phold);
} /* Line: 149 */
bevt_58_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevl_eline = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 153 */
} /* Line: 152 */
} /* Line: 144 */
} /* Line: 136 */
 else  /* Line: 157 */ {
bevt_59_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_19;
bevl_start = bevl_line.bem_find_2(bevt_59_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 159 */ {
if (bevp_vv.bevi_bool) /* Line: 160 */ {
bevt_61_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_20;
bevt_61_tmpany_phold.bem_print_0();
} /* Line: 161 */
bevt_62_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_21;
bevt_64_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_22;
bevt_63_tmpany_phold = bevl_start.bem_add_1(bevt_64_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_62_tmpany_phold, bevt_63_tmpany_phold);
if (bevl_end == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 165 */ {
if (bevp_vv.bevi_bool) /* Line: 166 */ {
bevt_66_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_23;
bevt_66_tmpany_phold.bem_print_0();
} /* Line: 167 */
bevt_68_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_24;
bevt_67_tmpany_phold = bevl_start.bem_add_1(bevt_68_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_67_tmpany_phold, bevl_end);
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_20));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_69_tmpany_phold);
if (bevl_pdelim == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevt_71_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_25;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_71_tmpany_phold, bevl_pdelim);
bevt_72_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_20));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_72_tmpany_phold);
if (bevl_pdelim == null) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 176 */ {
bevt_74_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_26;
bevl_efile = bevl_inPart.bem_substring_2(bevt_74_tmpany_phold, bevl_pdelim);
} /* Line: 177 */
bevt_76_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_27;
bevt_75_tmpany_phold = bevl_pdelim.bem_add_1(bevt_76_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_75_tmpany_phold);
bevt_77_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_77_tmpany_phold.bevi_bool) /* Line: 181 */ {
bevl_eline = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 182 */
} /* Line: 181 */
} /* Line: 172 */
} /* Line: 165 */
} /* Line: 159 */
} /* Line: 134 */
 else  /* Line: 188 */ {
bevt_78_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_28;
bevt_80_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_29;
bevt_79_tmpany_phold = bevl_start.bem_add_1(bevt_80_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_78_tmpany_phold, bevt_79_tmpany_phold);
if (bevl_end == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 190 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_82_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_82_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 190 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 190 */
 else  /* Line: 190 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 190 */ {
bevt_84_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_30;
bevt_83_tmpany_phold = bevl_start.bem_add_1(bevt_84_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_83_tmpany_phold, bevl_end);
} /* Line: 191 */
 else  /* Line: 192 */ {
bevt_86_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_31;
bevt_85_tmpany_phold = bevl_start.bem_add_1(bevt_86_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_85_tmpany_phold);
} /* Line: 193 */
} /* Line: 190 */
if (bevl_callPart == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 196 */ {
if (bevl_isCs.bevi_bool) /* Line: 197 */ {
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_26));
bevl_parts = bevl_callPart.bem_split_1(bevt_88_tmpany_phold);
bevt_89_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpany_phold);
bevt_90_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_90_tmpany_phold);
bevl_klass = bem_extractKlass_1(bevl_klass);
bevl_mtd = bem_extractMethod_1(bevl_mtd);
bevl_fr = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_92_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_91_tmpany_phold = bem_getSourceFileName_1(bevt_92_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_91_tmpany_phold);
bem_addFrame_1(bevl_fr);
} /* Line: 210 */
 else  /* Line: 211 */ {
if (bevp_vv.bevi_bool) /* Line: 213 */ {
bevt_95_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_32;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevl_callPart);
bevt_96_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_33;
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bem_add_1(bevt_96_tmpany_phold);
bevt_93_tmpany_phold.bem_print_0();
} /* Line: 214 */
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_26));
bevl_parts = bevl_callPart.bem_split_1(bevt_97_tmpany_phold);
bevt_99_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_100_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_34;
if (bevt_99_tmpany_phold.bevi_int > bevt_100_tmpany_phold.bevi_int) {
bevt_98_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevt_102_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_103_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_35;
if (bevt_102_tmpany_phold.bevi_int > bevt_103_tmpany_phold.bevi_int) {
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_101_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_101_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_104_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_104_tmpany_phold);
bevt_105_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_105_tmpany_phold);
} /* Line: 220 */
 else  /* Line: 221 */ {
bevt_106_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_106_tmpany_phold);
bevt_107_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_107_tmpany_phold);
} /* Line: 223 */
bevl_mtd = bem_extractMethod_1(bevl_mtd);
if (bevp_vv.bevi_bool) /* Line: 226 */ {
bevt_110_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_36;
bevt_109_tmpany_phold = bevt_110_tmpany_phold.bem_add_1(bevl_mtd);
bevt_111_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_37;
bevt_108_tmpany_phold = bevt_109_tmpany_phold.bem_add_1(bevt_111_tmpany_phold);
bevt_108_tmpany_phold.bem_print_0();
} /* Line: 227 */
bevt_112_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_38;
bevl_start = bevl_klass.bem_find_1(bevt_112_tmpany_phold);
if (bevl_start == null) {
bevt_113_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_113_tmpany_phold.bevi_bool) /* Line: 230 */ {
bevt_115_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_39;
if (bevl_start.bevi_int > bevt_115_tmpany_phold.bevi_int) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 230 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 230 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 230 */
 else  /* Line: 230 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 230 */ {
bevt_116_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_40;
bevt_118_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_41;
bevt_117_tmpany_phold = bevl_start.bem_add_1(bevt_118_tmpany_phold);
bevl_end = bevl_klass.bem_find_2(bevt_116_tmpany_phold, bevt_117_tmpany_phold);
if (bevl_end == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 232 */ {
bevt_121_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_42;
if (bevl_end.bevi_int > bevt_121_tmpany_phold.bevi_int) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 232 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 232 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 232 */
 else  /* Line: 232 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 232 */ {
bevl_klass = bevl_klass.bem_substring_1(bevl_start);
if (bevp_vv.bevi_bool) /* Line: 237 */ {
bevt_124_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_43;
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bem_add_1(bevl_klass);
bevt_125_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_44;
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bem_add_1(bevt_125_tmpany_phold);
bevt_122_tmpany_phold.bem_print_0();
} /* Line: 238 */
bevl_klass = bem_extractKlass_1(bevl_klass);
if (bevp_vv.bevi_bool) /* Line: 241 */ {
bevt_128_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_45;
bevt_127_tmpany_phold = bevt_128_tmpany_phold.bem_add_1(bevl_klass);
bevt_129_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_46;
bevt_126_tmpany_phold = bevt_127_tmpany_phold.bem_add_1(bevt_129_tmpany_phold);
bevt_126_tmpany_phold.bem_print_0();
} /* Line: 242 */
bevl_fr = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_131_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_130_tmpany_phold = bem_getSourceFileName_1(bevt_131_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_130_tmpany_phold);
if (bevp_vv.bevi_bool) /* Line: 246 */ {
bevt_132_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_47;
bevt_132_tmpany_phold.bem_print_0();
} /* Line: 247 */
bem_addFrame_1(bevl_fr);
} /* Line: 249 */
 else  /* Line: 250 */ {
if (bevp_vv.bevi_bool) /* Line: 251 */ {
bevt_133_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_48;
bevt_133_tmpany_phold.bem_print_0();
} /* Line: 252 */
} /* Line: 251 */
} /* Line: 232 */
} /* Line: 230 */
} /* Line: 217 */
} /* Line: 197 */
} /* Line: 196 */
} /* Line: 123 */
 else  /* Line: 116 */ {
break;
} /* Line: 116 */
} /* Line: 116 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_36));
bevp_framesText = null;
} /* Line: 263 */
 else  /* Line: 108 */ {
if (bevp_frames == null) {
bevt_134_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_134_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_134_tmpany_phold.bevi_bool) /* Line: 264 */ {
if (bevp_lang == null) {
bevt_135_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_135_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_135_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 264 */ {
bevt_137_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_49;
bevt_136_tmpany_phold = bevp_lang.bem_equals_1(bevt_137_tmpany_phold);
if (bevt_136_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 264 */ {
bevt_1_tmpany_loop = bevp_frames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 265 */ {
bevt_138_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_138_tmpany_phold).bevi_bool) /* Line: 265 */ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_tmpany_loop.bem_nextGet_0();
bevt_140_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_139_tmpany_phold = bem_extractKlassLib_1(bevt_140_tmpany_phold);
bevl_fr.bem_klassNameSet_1(bevt_139_tmpany_phold);
bevt_142_tmpany_phold = bevl_fr.bem_methodNameGet_0();
bevt_141_tmpany_phold = bem_extractMethod_1(bevt_142_tmpany_phold);
bevl_fr.bem_methodNameSet_1(bevt_141_tmpany_phold);
bevt_144_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_143_tmpany_phold = bem_getSourceFileName_1(bevt_144_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_143_tmpany_phold);
} /* Line: 269 */
 else  /* Line: 265 */ {
break;
} /* Line: 265 */
} /* Line: 265 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_36));
} /* Line: 274 */
 else  /* Line: 275 */ {
} /* Line: 275 */
} /* Line: 108 */
if (bevp_vv.bevi_bool) /* Line: 278 */ {
bevt_145_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_50;
bevt_145_tmpany_phold.bem_print_0();
} /* Line: 279 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_i = bem_createInstance_2(beva_klassName, bevt_0_tmpany_phold);
if (bevl_i == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(1522098204);
return (BEC_2_4_6_TextString) bevt_2_tmpany_phold;
} /* Line: 288 */
return null;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) {
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_26));
bevl_parts = beva_callPart.bem_split_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_2_tmpany_phold = bevl_parts.bem_get_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_tmpany_phold );
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 302 */ {
bevt_0_tmpany_phold = bem_extractKlassInner_1(beva_klass);
return bevt_0_tmpany_phold;
} /* Line: 303 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 304 */
return beva_klass;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) {
BEC_2_9_10_ContainerLinkedList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_51;
bevt_3_tmpany_phold = beva_klass.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 311 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 311 */ {
return beva_klass;
} /* Line: 312 */
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_5_tmpany_phold = beva_klass.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_31));
bevl_kparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_52;
bevl_kps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 319 */ {
if (bevl_i.bevi_int < bevl_kps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 319 */ {
bevt_11_tmpany_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpany_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpany_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpany_phold);
bevt_16_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_53;
bevt_15_tmpany_phold = bevl_i.bem_add_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_int < bevl_kps.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_20));
bevl_bec.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 323 */
bevl_sofar.bevi_int += bevl_len.bevi_int;
bevl_i.bevi_int++;
} /* Line: 319 */
 else  /* Line: 319 */ {
break;
} /* Line: 319 */
} /* Line: 319 */
return bevl_bec;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) {
BEC_2_9_10_ContainerLinkedList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
if (beva_mtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 331 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_54;
bevt_3_tmpany_phold = beva_mtd.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 331 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 331 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 331 */ {
return beva_mtd;
} /* Line: 332 */
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevt_5_tmpany_phold = beva_mtd.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_31));
bevl_mparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_55;
bevl_mps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_bem = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 337 */ {
if (bevl_i.bevi_int < bevl_mps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 337 */ {
bevt_11_tmpany_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_56;
bevt_13_tmpany_phold = bevl_i.bem_add_1(bevt_14_tmpany_phold);
if (bevt_13_tmpany_phold.bevi_int < bevl_mps.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 339 */ {
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_31));
bevl_bem.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 339 */
bevl_i.bevi_int++;
} /* Line: 337 */
 else  /* Line: 337 */ {
break;
} /* Line: 337 */
} /* Line: 337 */
return bevl_bem;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_framesGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bem_translateEmittedException_0();
if (bevp_vv.bevi_bool) /* Line: 349 */ {
bevt_0_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_57;
bevt_0_tmpany_phold.bem_print_0();
} /* Line: 350 */
return bevp_frames;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFrameText_0() {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bem_translateEmittedException_0();
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 360 */ {
bevt_2_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_58;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 362 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 362 */ {
bevl_ft = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 363 */
 else  /* Line: 362 */ {
break;
} /* Line: 362 */
} /* Line: 362 */
} /* Line: 362 */
return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_klassNameGet_0() {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_frames == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 374 */ {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 375 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) {
BEC_2_9_5_ExceptionFrame bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
bem_addFrame_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNameGet_0() {
return bevp_methodName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGetDirect_0() {
return bevp_methodName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methodName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_methodNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methodName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_klassNameGetDirect_0() {
return bevp_klassName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_klassName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_klassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_klassName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_descriptionGet_0() {
return bevp_description;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGetDirect_0() {
return bevp_description;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_description = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_descriptionSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_description = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fileNameGet_0() {
return bevp_fileName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGetDirect_0() {
return bevp_fileName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_fileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lineNumberGet_0() {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGetDirect_0() {
return bevp_lineNumber;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineNumber = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_lineNumberSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineNumber = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_langGet_0() {
return bevp_lang;
} /*method end*/
public BEC_2_4_6_TextString bem_langGetDirect_0() {
return bevp_lang;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_langSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitLangGet_0() {
return bevp_emitLang;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGetDirect_0() {
return bevp_emitLang;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_emitLangSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_framesGetDirect_0() {
return bevp_frames;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_framesTextGet_0() {
return bevp_framesText;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGetDirect_0() {
return bevp_framesText;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesTextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_translatedGet_0() {
return bevp_translated;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGetDirect_0() {
return bevp_translated;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_translatedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_vvGet_0() {
return bevp_vv;
} /*method end*/
public BEC_2_5_4_LogicBool bem_vvGetDirect_0() {
return bevp_vv;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_vvSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_vvSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {47, 50, 54, 57, 58, 58, 59, 59, 59, 61, 61, 62, 62, 62, 64, 64, 65, 65, 65, 65, 67, 67, 68, 68, 68, 70, 70, 71, 71, 71, 73, 73, 74, 74, 74, 76, 76, 77, 77, 77, 79, 79, 80, 80, 80, 82, 82, 83, 83, 85, 90, 92, 92, 93, 93, 93, 93, 93, 0, 0, 0, 94, 94, 101, 101, 0, 0, 0, 102, 104, 104, 105, 107, 108, 108, 108, 108, 0, 0, 0, 108, 108, 0, 108, 108, 0, 0, 0, 0, 0, 109, 109, 110, 111, 111, 112, 114, 116, 0, 116, 116, 118, 118, 118, 120, 120, 121, 122, 123, 123, 123, 123, 123, 0, 0, 0, 125, 125, 125, 127, 127, 127, 127, 128, 128, 128, 128, 0, 0, 0, 130, 130, 130, 132, 132, 132, 135, 135, 136, 136, 138, 138, 138, 139, 139, 140, 140, 140, 140, 143, 143, 144, 144, 145, 145, 147, 147, 147, 148, 148, 149, 149, 152, 153, 158, 158, 159, 159, 161, 161, 164, 164, 164, 164, 165, 165, 167, 167, 169, 169, 169, 171, 171, 172, 172, 173, 173, 175, 175, 176, 176, 177, 177, 179, 179, 179, 181, 182, 189, 189, 189, 189, 190, 190, 190, 190, 0, 0, 0, 191, 191, 191, 193, 193, 193, 196, 196, 199, 199, 201, 201, 202, 202, 204, 206, 208, 209, 209, 209, 210, 214, 214, 214, 214, 214, 216, 216, 217, 217, 217, 217, 218, 218, 218, 218, 219, 219, 220, 220, 222, 222, 223, 223, 225, 227, 227, 227, 227, 227, 229, 229, 230, 230, 230, 230, 230, 0, 0, 0, 231, 231, 231, 231, 232, 232, 232, 232, 232, 0, 0, 0, 236, 238, 238, 238, 238, 238, 240, 242, 242, 242, 242, 242, 244, 245, 245, 245, 247, 247, 249, 252, 252, 261, 262, 263, 264, 264, 264, 264, 0, 0, 0, 264, 264, 0, 0, 0, 265, 0, 265, 265, 266, 266, 266, 267, 267, 267, 268, 268, 268, 273, 274, 279, 279, 285, 285, 286, 286, 288, 288, 291, 296, 296, 298, 298, 298, 298, 303, 303, 307, 311, 311, 0, 311, 311, 311, 311, 0, 0, 312, 314, 314, 314, 314, 315, 315, 315, 316, 317, 318, 319, 319, 319, 320, 320, 322, 322, 322, 323, 323, 323, 323, 323, 323, 324, 319, 327, 331, 331, 0, 331, 331, 331, 331, 0, 0, 332, 334, 334, 334, 334, 335, 335, 335, 336, 337, 337, 337, 338, 338, 339, 339, 339, 339, 339, 339, 337, 342, 348, 350, 350, 353, 357, 358, 359, 360, 360, 361, 361, 362, 0, 362, 362, 363, 366, 370, 374, 374, 375, 377, 381, 381, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {124, 125, 157, 158, 159, 164, 165, 166, 167, 169, 174, 175, 176, 177, 179, 184, 185, 186, 187, 188, 190, 195, 196, 197, 198, 200, 205, 206, 207, 208, 210, 215, 216, 217, 218, 220, 225, 226, 227, 228, 230, 235, 236, 237, 238, 240, 245, 246, 247, 249, 261, 265, 266, 267, 272, 273, 274, 275, 277, 280, 284, 287, 288, 456, 461, 463, 466, 470, 473, 475, 480, 481, 483, 484, 489, 490, 495, 496, 499, 503, 506, 507, 509, 512, 513, 515, 518, 522, 525, 529, 532, 533, 534, 535, 536, 538, 541, 543, 543, 546, 548, 550, 551, 552, 554, 555, 556, 557, 558, 563, 564, 565, 570, 571, 574, 578, 582, 583, 584, 586, 587, 588, 589, 590, 595, 596, 601, 602, 605, 609, 613, 614, 615, 617, 618, 619, 621, 622, 623, 628, 629, 630, 631, 632, 633, 635, 636, 637, 638, 640, 641, 642, 647, 648, 649, 650, 651, 652, 653, 654, 656, 657, 659, 661, 667, 668, 669, 674, 676, 677, 679, 680, 681, 682, 683, 688, 690, 691, 693, 694, 695, 696, 697, 698, 703, 704, 705, 706, 707, 708, 713, 714, 715, 717, 718, 719, 720, 722, 730, 731, 732, 733, 734, 739, 740, 745, 746, 749, 753, 756, 757, 758, 761, 762, 763, 766, 771, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 789, 790, 791, 792, 793, 795, 796, 797, 798, 799, 804, 805, 806, 807, 812, 813, 814, 815, 816, 819, 820, 821, 822, 824, 826, 827, 828, 829, 830, 832, 833, 834, 839, 840, 841, 846, 847, 850, 854, 857, 858, 859, 860, 861, 866, 867, 868, 873, 874, 877, 881, 884, 886, 887, 888, 889, 890, 892, 894, 895, 896, 897, 898, 900, 901, 902, 903, 905, 906, 908, 912, 913, 926, 927, 928, 931, 936, 937, 942, 943, 946, 950, 953, 954, 956, 959, 963, 966, 966, 969, 971, 972, 973, 974, 975, 976, 977, 978, 979, 980, 986, 987, 993, 994, 1003, 1004, 1005, 1010, 1011, 1012, 1014, 1022, 1023, 1024, 1025, 1026, 1027, 1033, 1034, 1039, 1067, 1072, 1073, 1076, 1077, 1078, 1083, 1084, 1087, 1091, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1106, 1111, 1112, 1113, 1114, 1115, 1116, 1117, 1118, 1119, 1124, 1125, 1126, 1128, 1129, 1135, 1158, 1163, 1164, 1167, 1168, 1169, 1174, 1175, 1178, 1182, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1195, 1200, 1201, 1202, 1203, 1204, 1205, 1210, 1211, 1212, 1214, 1220, 1224, 1226, 1227, 1229, 1239, 1240, 1241, 1242, 1247, 1248, 1249, 1250, 1250, 1253, 1255, 1256, 1263, 1266, 1270, 1275, 1276, 1278, 1283, 1284, 1288, 1291, 1294, 1298, 1302, 1305, 1309, 1313, 1316, 1319, 1323, 1327, 1330, 1333, 1337, 1341, 1344, 1347, 1351, 1355, 1358, 1361, 1365, 1369, 1372, 1375, 1379, 1383, 1386, 1390, 1394, 1397, 1400, 1404, 1408, 1411, 1414, 1418, 1422, 1425, 1428, 1432};
/* BEGIN LINEINFO 
assign 1 47 124
new 0 47 124
assign 1 50 125
translateEmittedException 0 54 157
assign 1 57 158
new 0 57 158
assign 1 58 159
def 1 58 164
assign 1 59 165
new 0 59 165
assign 1 59 166
add 1 59 166
assign 1 59 167
add 1 59 167
assign 1 61 169
def 1 61 174
assign 1 62 175
new 0 62 175
assign 1 62 176
add 1 62 176
assign 1 62 177
add 1 62 177
assign 1 64 179
def 1 64 184
assign 1 65 185
new 0 65 185
assign 1 65 186
add 1 65 186
assign 1 65 187
toString 0 65 187
assign 1 65 188
add 1 65 188
assign 1 67 190
def 1 67 195
assign 1 68 196
new 0 68 196
assign 1 68 197
add 1 68 197
assign 1 68 198
add 1 68 198
assign 1 70 200
def 1 70 205
assign 1 71 206
new 0 71 206
assign 1 71 207
add 1 71 207
assign 1 71 208
add 1 71 208
assign 1 73 210
def 1 73 215
assign 1 74 216
new 0 74 216
assign 1 74 217
add 1 74 217
assign 1 74 218
add 1 74 218
assign 1 76 220
def 1 76 225
assign 1 77 226
new 0 77 226
assign 1 77 227
add 1 77 227
assign 1 77 228
add 1 77 228
assign 1 79 230
def 1 79 235
assign 1 80 236
new 0 80 236
assign 1 80 237
add 1 80 237
assign 1 80 238
add 1 80 238
assign 1 82 240
def 1 82 245
assign 1 83 246
getFrameText 0 83 246
assign 1 83 247
add 1 83 247
return 1 85 249
translateEmittedExceptionInner 0 90 261
assign 1 92 265
new 0 92 265
print 0 92 266
assign 1 93 267
def 1 93 272
assign 1 93 273
new 0 93 273
assign 1 93 274
new 0 93 274
assign 1 93 275
can 2 93 275
assign 1 0 277
assign 1 0 280
assign 1 0 284
assign 1 94 287
descriptionGet 0 94 287
print 0 94 288
assign 1 101 456
def 1 101 461
assign 1 0 463
assign 1 0 466
assign 1 0 470
return 1 102 473
assign 1 104 475
undef 1 104 480
assign 1 105 481
new 0 105 481
assign 1 107 483
new 0 107 483
assign 1 108 484
def 1 108 489
assign 1 108 490
def 1 108 495
assign 1 0 496
assign 1 0 499
assign 1 0 503
assign 1 108 506
new 0 108 506
assign 1 108 507
equals 1 108 507
assign 1 0 509
assign 1 108 512
new 0 108 512
assign 1 108 513
equals 1 108 513
assign 1 0 515
assign 1 0 518
assign 1 0 522
assign 1 0 525
assign 1 0 529
assign 1 109 532
new 0 109 532
assign 1 109 533
new 1 109 533
assign 1 110 534
tokenize 1 110 534
assign 1 111 535
new 0 111 535
assign 1 111 536
equals 1 111 536
assign 1 112 538
new 0 112 538
assign 1 114 541
new 0 114 541
assign 1 116 543
linkedListIteratorGet 0 0 543
assign 1 116 546
hasNextGet 0 116 546
assign 1 116 548
nextGet 0 116 548
assign 1 118 550
new 0 118 550
assign 1 118 551
add 1 118 551
print 0 118 552
assign 1 120 554
new 0 120 554
assign 1 120 555
find 1 120 555
assign 1 121 556
assign 1 122 557
assign 1 123 558
def 1 123 563
assign 1 123 564
new 0 123 564
assign 1 123 565
greaterEquals 1 123 570
assign 1 0 571
assign 1 0 574
assign 1 0 578
assign 1 125 582
new 0 125 582
assign 1 125 583
add 1 125 583
print 0 125 584
assign 1 127 586
new 0 127 586
assign 1 127 587
new 0 127 587
assign 1 127 588
add 1 127 588
assign 1 127 589
find 2 127 589
assign 1 128 590
def 1 128 595
assign 1 128 596
greater 1 128 601
assign 1 0 602
assign 1 0 605
assign 1 0 609
assign 1 130 613
new 0 130 613
assign 1 130 614
add 1 130 614
print 0 130 615
assign 1 132 617
new 0 132 617
assign 1 132 618
add 1 132 618
assign 1 132 619
substring 2 132 619
assign 1 135 621
new 0 135 621
assign 1 135 622
find 2 135 622
assign 1 136 623
def 1 136 628
assign 1 138 629
new 0 138 629
assign 1 138 630
add 1 138 630
assign 1 138 631
substring 1 138 631
assign 1 139 632
new 0 139 632
assign 1 139 633
ends 1 139 633
assign 1 140 635
sizeGet 0 140 635
assign 1 140 636
new 0 140 636
assign 1 140 637
subtract 1 140 637
sizeSet 1 140 638
assign 1 143 640
new 0 143 640
assign 1 143 641
rfind 1 143 641
assign 1 144 642
def 1 144 647
assign 1 145 648
new 0 145 648
assign 1 145 649
substring 2 145 649
assign 1 147 650
new 0 147 650
assign 1 147 651
add 1 147 651
assign 1 147 652
substring 1 147 652
assign 1 148 653
new 0 148 653
assign 1 148 654
begins 1 148 654
assign 1 149 656
new 0 149 656
assign 1 149 657
substring 1 149 657
assign 1 152 659
isInteger 0 152 659
assign 1 153 661
new 1 153 661
assign 1 158 667
new 0 158 667
assign 1 158 668
find 2 158 668
assign 1 159 669
def 1 159 674
assign 1 161 676
new 0 161 676
print 0 161 677
assign 1 164 679
new 0 164 679
assign 1 164 680
new 0 164 680
assign 1 164 681
add 1 164 681
assign 1 164 682
find 2 164 682
assign 1 165 683
def 1 165 688
assign 1 167 690
new 0 167 690
print 0 167 691
assign 1 169 693
new 0 169 693
assign 1 169 694
add 1 169 694
assign 1 169 695
substring 2 169 695
assign 1 171 696
new 0 171 696
assign 1 171 697
rfind 1 171 697
assign 1 172 698
def 1 172 703
assign 1 173 704
new 0 173 704
assign 1 173 705
substring 2 173 705
assign 1 175 706
new 0 175 706
assign 1 175 707
rfind 1 175 707
assign 1 176 708
def 1 176 713
assign 1 177 714
new 0 177 714
assign 1 177 715
substring 2 177 715
assign 1 179 717
new 0 179 717
assign 1 179 718
add 1 179 718
assign 1 179 719
substring 1 179 719
assign 1 181 720
isInteger 0 181 720
assign 1 182 722
new 1 182 722
assign 1 189 730
new 0 189 730
assign 1 189 731
new 0 189 731
assign 1 189 732
add 1 189 732
assign 1 189 733
find 2 189 733
assign 1 190 734
def 1 190 739
assign 1 190 740
greater 1 190 745
assign 1 0 746
assign 1 0 749
assign 1 0 753
assign 1 191 756
new 0 191 756
assign 1 191 757
add 1 191 757
assign 1 191 758
substring 2 191 758
assign 1 193 761
new 0 193 761
assign 1 193 762
add 1 193 762
assign 1 193 763
substring 1 193 763
assign 1 196 766
def 1 196 771
assign 1 199 773
new 0 199 773
assign 1 199 774
split 1 199 774
assign 1 201 775
new 0 201 775
assign 1 201 776
get 1 201 776
assign 1 202 777
new 0 202 777
assign 1 202 778
get 1 202 778
assign 1 204 779
extractKlass 1 204 779
assign 1 206 780
extractMethod 1 206 780
assign 1 208 781
new 4 208 781
assign 1 209 782
klassNameGet 0 209 782
assign 1 209 783
getSourceFileName 1 209 783
fileNameSet 1 209 784
addFrame 1 210 785
assign 1 214 789
new 0 214 789
assign 1 214 790
add 1 214 790
assign 1 214 791
new 0 214 791
assign 1 214 792
add 1 214 792
print 0 214 793
assign 1 216 795
new 0 216 795
assign 1 216 796
split 1 216 796
assign 1 217 797
sizeGet 0 217 797
assign 1 217 798
new 0 217 798
assign 1 217 799
greater 1 217 804
assign 1 218 805
sizeGet 0 218 805
assign 1 218 806
new 0 218 806
assign 1 218 807
greater 1 218 812
assign 1 219 813
new 0 219 813
assign 1 219 814
get 1 219 814
assign 1 220 815
new 0 220 815
assign 1 220 816
get 1 220 816
assign 1 222 819
new 0 222 819
assign 1 222 820
get 1 222 820
assign 1 223 821
new 0 223 821
assign 1 223 822
get 1 223 822
assign 1 225 824
extractMethod 1 225 824
assign 1 227 826
new 0 227 826
assign 1 227 827
add 1 227 827
assign 1 227 828
new 0 227 828
assign 1 227 829
add 1 227 829
print 0 227 830
assign 1 229 832
new 0 229 832
assign 1 229 833
find 1 229 833
assign 1 230 834
def 1 230 839
assign 1 230 840
new 0 230 840
assign 1 230 841
greater 1 230 846
assign 1 0 847
assign 1 0 850
assign 1 0 854
assign 1 231 857
new 0 231 857
assign 1 231 858
new 0 231 858
assign 1 231 859
add 1 231 859
assign 1 231 860
find 2 231 860
assign 1 232 861
def 1 232 866
assign 1 232 867
new 0 232 867
assign 1 232 868
greater 1 232 873
assign 1 0 874
assign 1 0 877
assign 1 0 881
assign 1 236 884
substring 1 236 884
assign 1 238 886
new 0 238 886
assign 1 238 887
add 1 238 887
assign 1 238 888
new 0 238 888
assign 1 238 889
add 1 238 889
print 0 238 890
assign 1 240 892
extractKlass 1 240 892
assign 1 242 894
new 0 242 894
assign 1 242 895
add 1 242 895
assign 1 242 896
new 0 242 896
assign 1 242 897
add 1 242 897
print 0 242 898
assign 1 244 900
new 4 244 900
assign 1 245 901
klassNameGet 0 245 901
assign 1 245 902
getSourceFileName 1 245 902
fileNameSet 1 245 903
assign 1 247 905
new 0 247 905
print 0 247 906
addFrame 1 249 908
assign 1 252 912
new 0 252 912
print 0 252 913
assign 1 261 926
assign 1 262 927
new 0 262 927
assign 1 263 928
assign 1 264 931
def 1 264 936
assign 1 264 937
def 1 264 942
assign 1 0 943
assign 1 0 946
assign 1 0 950
assign 1 264 953
new 0 264 953
assign 1 264 954
equals 1 264 954
assign 1 0 956
assign 1 0 959
assign 1 0 963
assign 1 265 966
linkedListIteratorGet 0 0 966
assign 1 265 969
hasNextGet 0 265 969
assign 1 265 971
nextGet 0 265 971
assign 1 266 972
klassNameGet 0 266 972
assign 1 266 973
extractKlassLib 1 266 973
klassNameSet 1 266 974
assign 1 267 975
methodNameGet 0 267 975
assign 1 267 976
extractMethod 1 267 976
methodNameSet 1 267 977
assign 1 268 978
klassNameGet 0 268 978
assign 1 268 979
getSourceFileName 1 268 979
fileNameSet 1 268 980
assign 1 273 986
assign 1 274 987
new 0 274 987
assign 1 279 993
new 0 279 993
print 0 279 994
assign 1 285 1003
new 0 285 1003
assign 1 285 1004
createInstance 2 285 1004
assign 1 286 1005
def 1 286 1010
assign 1 288 1011
sourceFileNameGet 0 288 1011
return 1 288 1012
return 1 291 1014
assign 1 296 1022
new 0 296 1022
assign 1 296 1023
split 1 296 1023
assign 1 298 1024
new 0 298 1024
assign 1 298 1025
get 1 298 1025
assign 1 298 1026
extractKlass 1 298 1026
return 1 298 1027
assign 1 303 1033
extractKlassInner 1 303 1033
return 1 303 1034
return 1 307 1039
assign 1 311 1067
undef 1 311 1072
assign 1 0 1073
assign 1 311 1076
new 0 311 1076
assign 1 311 1077
begins 1 311 1077
assign 1 311 1078
not 0 311 1083
assign 1 0 1084
assign 1 0 1087
return 1 312 1091
assign 1 314 1093
new 0 314 1093
assign 1 314 1094
substring 1 314 1094
assign 1 314 1095
new 0 314 1095
assign 1 314 1096
split 1 314 1096
assign 1 315 1097
sizeGet 0 315 1097
assign 1 315 1098
new 0 315 1098
assign 1 315 1099
subtract 1 315 1099
assign 1 316 1100
get 1 316 1100
assign 1 317 1101
new 0 317 1101
assign 1 318 1102
new 0 318 1102
assign 1 319 1103
new 0 319 1103
assign 1 319 1106
lesser 1 319 1111
assign 1 320 1112
get 1 320 1112
assign 1 320 1113
new 1 320 1113
assign 1 322 1114
add 1 322 1114
assign 1 322 1115
substring 2 322 1115
addValue 1 322 1116
assign 1 323 1117
new 0 323 1117
assign 1 323 1118
add 1 323 1118
assign 1 323 1119
lesser 1 323 1124
assign 1 323 1125
new 0 323 1125
addValue 1 323 1126
addValue 1 324 1128
incrementValue 0 319 1129
return 1 327 1135
assign 1 331 1158
undef 1 331 1163
assign 1 0 1164
assign 1 331 1167
new 0 331 1167
assign 1 331 1168
begins 1 331 1168
assign 1 331 1169
not 0 331 1174
assign 1 0 1175
assign 1 0 1178
return 1 332 1182
assign 1 334 1184
new 0 334 1184
assign 1 334 1185
substring 1 334 1185
assign 1 334 1186
new 0 334 1186
assign 1 334 1187
split 1 334 1187
assign 1 335 1188
sizeGet 0 335 1188
assign 1 335 1189
new 0 335 1189
assign 1 335 1190
subtract 1 335 1190
assign 1 336 1191
new 0 336 1191
assign 1 337 1192
new 0 337 1192
assign 1 337 1195
lesser 1 337 1200
assign 1 338 1201
get 1 338 1201
addValue 1 338 1202
assign 1 339 1203
new 0 339 1203
assign 1 339 1204
add 1 339 1204
assign 1 339 1205
lesser 1 339 1210
assign 1 339 1211
new 0 339 1211
addValue 1 339 1212
incrementValue 0 337 1214
return 1 342 1220
translateEmittedException 0 348 1224
assign 1 350 1226
new 0 350 1226
print 0 350 1227
return 1 353 1229
translateEmittedException 0 357 1239
assign 1 358 1240
new 0 358 1240
assign 1 359 1241
framesGet 0 359 1241
assign 1 360 1242
def 1 360 1247
assign 1 361 1248
new 0 361 1248
assign 1 361 1249
add 1 361 1249
assign 1 362 1250
linkedListIteratorGet 0 0 1250
assign 1 362 1253
hasNextGet 0 362 1253
assign 1 362 1255
nextGet 0 362 1255
assign 1 363 1256
add 1 363 1256
return 1 366 1263
return 1 370 1266
assign 1 374 1270
undef 1 374 1275
assign 1 375 1276
new 0 375 1276
addValue 1 377 1278
assign 1 381 1283
new 4 381 1283
addFrame 1 381 1284
return 1 0 1288
return 1 0 1291
assign 1 0 1294
assign 1 0 1298
return 1 0 1302
assign 1 0 1305
assign 1 0 1309
return 1 0 1313
return 1 0 1316
assign 1 0 1319
assign 1 0 1323
return 1 0 1327
return 1 0 1330
assign 1 0 1333
assign 1 0 1337
return 1 0 1341
return 1 0 1344
assign 1 0 1347
assign 1 0 1351
return 1 0 1355
return 1 0 1358
assign 1 0 1361
assign 1 0 1365
return 1 0 1369
return 1 0 1372
assign 1 0 1375
assign 1 0 1379
return 1 0 1383
assign 1 0 1386
assign 1 0 1390
return 1 0 1394
return 1 0 1397
assign 1 0 1400
assign 1 0 1404
return 1 0 1408
return 1 0 1411
assign 1 0 1414
assign 1 0 1418
return 1 0 1422
return 1 0 1425
assign 1 0 1428
assign 1 0 1432
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -464576453: return bem_klassNameGet_0();
case -539305961: return bem_langGet_0();
case 1686342789: return bem_print_0();
case -1551114109: return bem_vvGet_0();
case -1201098152: return bem_toAny_0();
case 1294360431: return bem_klassNameGetDirect_0();
case 2089449732: return bem_fieldIteratorGet_0();
case -93996070: return bem_emitLangGetDirect_0();
case -126097638: return bem_translateEmittedException_0();
case 1929555702: return bem_getFrameText_0();
case -1931415843: return bem_serializeToString_0();
case 816581925: return bem_classNameGet_0();
case -1240781568: return bem_lineNumberGetDirect_0();
case 1759428119: return bem_hashGet_0();
case 1226113552: return bem_create_0();
case -983020838: return bem_langGetDirect_0();
case 1224800076: return bem_once_0();
case 956759073: return bem_vvGetDirect_0();
case 2134647390: return bem_toString_0();
case 1522098204: return bem_sourceFileNameGet_0();
case 1487300626: return bem_fileNameGetDirect_0();
case -680597241: return bem_emitLangGet_0();
case 1990705765: return bem_serializeContents_0();
case -1294759593: return bem_serializationIteratorGet_0();
case 480795217: return bem_framesTextGetDirect_0();
case -488471184: return bem_translateEmittedExceptionInner_0();
case -344908192: return bem_descriptionGetDirect_0();
case 1468891202: return bem_deserializeClassNameGet_0();
case -1449992977: return bem_methodNameGet_0();
case -1350845886: return bem_new_0();
case -819949273: return bem_descriptionGet_0();
case -863007361: return bem_copy_0();
case -2078569646: return bem_methodNameGetDirect_0();
case -350896467: return bem_framesGetDirect_0();
case -596782621: return bem_iteratorGet_0();
case 2024931306: return bem_framesGet_0();
case 1314392911: return bem_many_0();
case -1668639477: return bem_translatedGet_0();
case -765261987: return bem_echo_0();
case -768171916: return bem_tagGet_0();
case -2007766766: return bem_framesTextGet_0();
case -1399602189: return bem_fieldNamesGet_0();
case -400211333: return bem_lineNumberGet_0();
case 301563781: return bem_fileNameGet_0();
case -134710771: return bem_translatedGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 635699530: return bem_copyTo_1(bevd_0);
case -812024676: return bem_langSet_1(bevd_0);
case -1675203897: return bem_methodNameSetDirect_1(bevd_0);
case 1625276201: return bem_langSetDirect_1(bevd_0);
case 26178473: return bem_undefined_1(bevd_0);
case 1306623487: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 1286442708: return bem_sameClass_1(bevd_0);
case -10317005: return bem_methodNameSet_1(bevd_0);
case -930419978: return bem_lineNumberSet_1(bevd_0);
case 268367085: return bem_emitLangSetDirect_1(bevd_0);
case -434508008: return bem_framesSetDirect_1(bevd_0);
case -54010859: return bem_equals_1(bevd_0);
case -749039058: return bem_framesTextSet_1(bevd_0);
case -1193429739: return bem_vvSetDirect_1(bevd_0);
case 1426357851: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2003297856: return bem_undef_1(bevd_0);
case -1036408998: return bem_new_1(bevd_0);
case -2126702146: return bem_sameType_1(bevd_0);
case 688222489: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1211406823: return bem_sameObject_1(bevd_0);
case -1201991735: return bem_fileNameSet_1(bevd_0);
case 1809383718: return bem_translatedSet_1(bevd_0);
case 291996585: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 754534079: return bem_klassNameSetDirect_1(bevd_0);
case 2090827653: return bem_lineNumberSetDirect_1(bevd_0);
case 1658273096: return bem_otherType_1(bevd_0);
case -524550398: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2134954924: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1814770497: return bem_def_1(bevd_0);
case -295316346: return bem_descriptionSet_1(bevd_0);
case -390794160: return bem_descriptionSetDirect_1(bevd_0);
case -900890868: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -2141965116: return bem_fileNameSetDirect_1(bevd_0);
case 1343223494: return bem_framesSet_1(bevd_0);
case -1241115003: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -632334802: return bem_emitLangSet_1(bevd_0);
case -2037513602: return bem_vvSet_1(bevd_0);
case -2032446076: return bem_defined_1(bevd_0);
case -1447916414: return bem_otherClass_1(bevd_0);
case -1712553188: return bem_klassNameSet_1(bevd_0);
case 1502202029: return bem_framesTextSetDirect_1(bevd_0);
case 1957127175: return bem_translatedSetDirect_1(bevd_0);
case 1904381430: return bem_notEquals_1(bevd_0);
case 354319884: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2132874037: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1439296944: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 353482770: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2000867040: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1285224299: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1661650237: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 309149914: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1467313976: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 656280933: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemException_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_9_SystemException_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_9_SystemException();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst = (BEC_2_6_9_SystemException) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_type;
}
}
}
