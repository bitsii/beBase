namespace be {
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException : BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
static BEC_2_6_9_SystemException() { }
private static byte[] becc_BEC_2_6_9_SystemException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_9_SystemException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_1 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_2 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_3 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_4 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_6 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_7 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_9 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_9, 28));
private static byte[] bece_BEC_2_6_9_SystemException_bels_10 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_10, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_11 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_11, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_12 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_9_SystemException_bels_13 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_13, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_14 = {0x46,0x72,0x61,0x6D,0x65,0x20,0x6C,0x69,0x6E,0x65,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_14, 14));
private static byte[] bece_BEC_2_6_9_SystemException_bels_15 = {0x61,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_15, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_16 = {0x73,0x74,0x61,0x72,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_16, 9));
private static byte[] bece_BEC_2_6_9_SystemException_bels_17 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_17, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_9 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_18 = {0x65,0x6E,0x64,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_18, 7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_11 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_19 = {0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_19, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_13 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_20 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_20, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_21 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_17 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_22 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_22, 5));
private static byte[] bece_BEC_2_6_9_SystemException_bels_23 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_23, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_24 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_24, 15));
private static byte[] bece_BEC_2_6_9_SystemException_bels_25 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_25, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_22 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_26 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x65,0x6E,0x64,0x20,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_26, 13));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_24 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_27 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_25 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_28 = {0x3A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_26 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_27 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_29 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_29, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_29 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_30 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_31 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_9_SystemException_bels_30 = {0x2E};
private static byte[] bece_BEC_2_6_9_SystemException_bels_31 = {0x63,0x61,0x6C,0x6C,0x50,0x61,0x72,0x74,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_31, 10));
private static byte[] bece_BEC_2_6_9_SystemException_bels_32 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_32, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_33 = {0x2E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_34 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_35 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_34 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6D,0x74,0x64,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_34, 15));
private static byte[] bece_BEC_2_6_9_SystemException_bels_35 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_35, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_36 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_36, 4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_39 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_37 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_37, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_41 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_42 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_9_SystemException_bels_38 = {0x70,0x72,0x65,0x20,0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_38, 21));
private static byte[] bece_BEC_2_6_9_SystemException_bels_39 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_39, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_40 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_40, 17));
private static byte[] bece_BEC_2_6_9_SystemException_bels_41 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_41, 1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_42 = {0x61,0x64,0x64,0x69,0x6E,0x67,0x20,0x66,0x72,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_42, 12));
private static byte[] bece_BEC_2_6_9_SystemException_bels_43 = {0x6E,0x6F,0x20,0x65,0x6E,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_43, 6));
private static byte[] bece_BEC_2_6_9_SystemException_bels_44 = {0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_45 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_45, 2));
private static byte[] bece_BEC_2_6_9_SystemException_bels_46 = {0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_47 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_47, 16));
private static byte[] bece_BEC_2_6_9_SystemException_bels_48 = {0x2E};
private static byte[] bece_BEC_2_6_9_SystemException_bels_49 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_49, 4));
private static byte[] bece_BEC_2_6_9_SystemException_bels_50 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_52 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_53 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_51 = {0x3A};
private static byte[] bece_BEC_2_6_9_SystemException_bels_52 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_52, 4));
private static byte[] bece_BEC_2_6_9_SystemException_bels_53 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_55 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_9_SystemException_bevo_56 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_9_SystemException_bels_54 = {0x5F};
private static byte[] bece_BEC_2_6_9_SystemException_bels_55 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_55, 16));
private static byte[] bece_BEC_2_6_9_SystemException_bels_56 = {0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_6_9_SystemException_bevo_58 = (new BEC_2_4_6_TextString(bece_BEC_2_6_9_SystemException_bels_56, 1));
public static new BEC_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_inst;

public static new BET_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_type;

public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_5_4_LogicBool bevp_vv;
public virtual BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
bevp_vv = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_description = beva_descr;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_0));
if (bevp_description == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_1));
bevt_1_tmpany_phold = bevl_toRet.bemd_1(1633481692, bevt_2_tmpany_phold);
bevl_toRet = bevt_1_tmpany_phold.bemd_1(1633481692, bevp_description);
} /* Line: 35 */
if (bevp_fileName == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_6_9_SystemException_bels_2));
bevt_4_tmpany_phold = bevl_toRet.bemd_1(1633481692, bevt_5_tmpany_phold);
bevl_toRet = bevt_4_tmpany_phold.bemd_1(1633481692, bevp_fileName);
} /* Line: 38 */
if (bevp_lineNumber == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_3));
bevt_7_tmpany_phold = bevl_toRet.bemd_1(1633481692, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_lineNumber.bemd_0(1832806152);
bevl_toRet = bevt_7_tmpany_phold.bemd_1(1633481692, bevt_9_tmpany_phold);
} /* Line: 41 */
if (bevp_lang == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_4));
bevt_11_tmpany_phold = bevl_toRet.bemd_1(1633481692, bevt_12_tmpany_phold);
bevl_toRet = bevt_11_tmpany_phold.bemd_1(1633481692, bevp_lang);
} /* Line: 44 */
if (bevp_emitLang == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_5));
bevt_14_tmpany_phold = bevl_toRet.bemd_1(1633481692, bevt_15_tmpany_phold);
bevl_toRet = bevt_14_tmpany_phold.bemd_1(1633481692, bevp_emitLang);
} /* Line: 47 */
if (bevp_methodName == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_6_9_SystemException_bels_6));
bevt_17_tmpany_phold = bevl_toRet.bemd_1(1633481692, bevt_18_tmpany_phold);
bevl_toRet = bevt_17_tmpany_phold.bemd_1(1633481692, bevp_methodName);
} /* Line: 50 */
if (bevp_klassName == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_6_9_SystemException_bels_7));
bevt_20_tmpany_phold = bevl_toRet.bemd_1(1633481692, bevt_21_tmpany_phold);
bevl_toRet = bevt_20_tmpany_phold.bemd_1(1633481692, bevp_klassName);
} /* Line: 53 */
if (bevp_framesText == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 55 */ {
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_8));
bevt_23_tmpany_phold = bevl_toRet.bemd_1(1633481692, bevt_24_tmpany_phold);
bevl_toRet = bevt_23_tmpany_phold.bemd_1(1633481692, bevp_framesText);
} /* Line: 56 */
if (bevp_frames == null) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_26_tmpany_phold = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(1633481692, bevt_26_tmpany_phold);
} /* Line: 59 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_translateEmittedException_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 65 */ {
bem_translateEmittedExceptionInner_0();
} /* Line: 66 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_0_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_0;
bevt_0_tmpany_phold.bem_print_0();
} /* Line: 68 */
return this;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_translateEmittedExceptionInner_0() {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_121_tmpany_phold = null;
BEC_2_4_6_TextString bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_6_TextString bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_4_6_TextString bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_6_TextString bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_4_6_TextString bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_134_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_135_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_136_tmpany_phold = null;
BEC_2_4_6_TextString bevt_137_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_4_6_TextString bevt_141_tmpany_phold = null;
BEC_2_4_6_TextString bevt_142_tmpany_phold = null;
BEC_2_4_6_TextString bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_4_6_TextString bevt_145_tmpany_phold = null;
if (bevp_translated == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 76 */ {
if (bevp_translated.bevi_bool) /* Line: 76 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 76 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 76 */
 else  /* Line: 76 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 76 */ {
return this;
} /* Line: 77 */
if (bevp_vv == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevp_vv = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 80 */
bevp_translated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 83 */ {
if (bevp_lang == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 83 */ {
bevt_17_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_1;
bevt_16_tmpany_phold = bevp_lang.bem_equals_1(bevt_17_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_2;
bevt_18_tmpany_phold = bevp_lang.bem_equals_1(bevt_19_tmpany_phold);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 83 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_12));
bevl_ltok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_20_tmpany_phold);
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_22_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_3;
bevt_21_tmpany_phold = bevp_lang.bem_equals_1(bevt_22_tmpany_phold);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevl_isCs = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 87 */
 else  /* Line: 88 */ {
bevl_isCs = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 89 */
bevt_0_tmpany_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 91 */ {
bevt_23_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
if (bevp_vv.bevi_bool) /* Line: 92 */ {
bevt_25_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_4;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevl_line);
bevt_24_tmpany_phold.bem_print_0();
} /* Line: 93 */
bevt_26_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_5;
bevl_start = bevl_line.bem_find_1(bevt_26_tmpany_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_29_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_6;
if (bevl_start.bevi_int >= bevt_29_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 98 */ {
if (bevp_vv.bevi_bool) /* Line: 99 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_7;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevl_start);
bevt_30_tmpany_phold.bem_print_0();
} /* Line: 100 */
bevt_32_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_8;
bevt_34_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_9;
bevt_33_tmpany_phold = bevl_start.bem_add_1(bevt_34_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
if (bevl_end == null) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 103 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 103 */ {
if (bevp_vv.bevi_bool) /* Line: 104 */ {
bevt_38_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_10;
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_add_1(bevl_end);
bevt_37_tmpany_phold.bem_print_0();
} /* Line: 105 */
bevt_40_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_11;
bevt_39_tmpany_phold = bevl_start.bem_add_1(bevt_40_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_39_tmpany_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 109 */ {
bevt_41_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_12;
bevl_start = bevl_line.bem_find_2(bevt_41_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_44_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_13;
bevt_43_tmpany_phold = bevl_start.bem_add_1(bevt_44_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_43_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_14;
bevt_45_tmpany_phold = bevl_inPart.bem_ends_1(bevt_46_tmpany_phold);
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 114 */ {
bevt_48_tmpany_phold = bevl_inPart.bem_sizeGet_0();
bevt_49_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_15;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_subtract_1(bevt_49_tmpany_phold);
bevl_inPart.bem_sizeSet_1(bevt_47_tmpany_phold);
} /* Line: 115 */
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_21));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_50_tmpany_phold);
if (bevl_pdelim == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevt_52_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_16;
bevl_efile = bevl_inPart.bem_substring_2(bevt_52_tmpany_phold, bevl_pdelim);
bevt_54_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_17;
bevt_53_tmpany_phold = bevl_pdelim.bem_add_1(bevt_54_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_53_tmpany_phold);
bevt_56_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_18;
bevt_55_tmpany_phold = bevl_iv.bem_begins_1(bevt_56_tmpany_phold);
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_57_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_57_tmpany_phold);
} /* Line: 124 */
bevt_58_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 127 */ {
bevl_eline = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 128 */
} /* Line: 127 */
} /* Line: 119 */
} /* Line: 111 */
 else  /* Line: 132 */ {
bevt_59_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_19;
bevl_start = bevl_line.bem_find_2(bevt_59_tmpany_phold, bevl_end);
if (bevl_start == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 134 */ {
if (bevp_vv.bevi_bool) /* Line: 135 */ {
bevt_61_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_20;
bevt_61_tmpany_phold.bem_print_0();
} /* Line: 136 */
bevt_62_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_21;
bevt_64_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_22;
bevt_63_tmpany_phold = bevl_start.bem_add_1(bevt_64_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_62_tmpany_phold, bevt_63_tmpany_phold);
if (bevl_end == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 140 */ {
if (bevp_vv.bevi_bool) /* Line: 141 */ {
bevt_66_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_23;
bevt_66_tmpany_phold.bem_print_0();
} /* Line: 142 */
bevt_68_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_24;
bevt_67_tmpany_phold = bevl_start.bem_add_1(bevt_68_tmpany_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_67_tmpany_phold, bevl_end);
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_27));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_69_tmpany_phold);
if (bevl_pdelim == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 147 */ {
bevt_71_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_25;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_71_tmpany_phold, bevl_pdelim);
bevt_72_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_28));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_72_tmpany_phold);
if (bevl_pdelim == null) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 151 */ {
bevt_74_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_26;
bevl_efile = bevl_inPart.bem_substring_2(bevt_74_tmpany_phold, bevl_pdelim);
} /* Line: 152 */
bevt_76_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_27;
bevt_75_tmpany_phold = bevl_pdelim.bem_add_1(bevt_76_tmpany_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_75_tmpany_phold);
bevt_77_tmpany_phold = bevl_iv.bem_isInteger_0();
if (bevt_77_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevl_eline = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 157 */
} /* Line: 156 */
} /* Line: 147 */
} /* Line: 140 */
} /* Line: 134 */
} /* Line: 109 */
 else  /* Line: 163 */ {
bevt_78_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_28;
bevt_80_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_29;
bevt_79_tmpany_phold = bevl_start.bem_add_1(bevt_80_tmpany_phold);
bevl_end = bevl_line.bem_find_2(bevt_78_tmpany_phold, bevt_79_tmpany_phold);
if (bevl_end == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 165 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_82_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_82_tmpany_phold.bevi_bool) /* Line: 165 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 165 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 165 */
 else  /* Line: 165 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 165 */ {
bevt_84_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_30;
bevt_83_tmpany_phold = bevl_start.bem_add_1(bevt_84_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_83_tmpany_phold, bevl_end);
} /* Line: 166 */
 else  /* Line: 167 */ {
bevt_86_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_31;
bevt_85_tmpany_phold = bevl_start.bem_add_1(bevt_86_tmpany_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_85_tmpany_phold);
} /* Line: 168 */
} /* Line: 165 */
if (bevl_callPart == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 171 */ {
if (bevl_isCs.bevi_bool) /* Line: 172 */ {
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_30));
bevl_parts = bevl_callPart.bem_split_1(bevt_88_tmpany_phold);
bevt_89_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpany_phold);
bevt_90_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_90_tmpany_phold);
bevl_klass = bem_extractKlass_1(bevl_klass);
bevl_mtd = bem_extractMethod_1(bevl_mtd);
bevl_fr = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_92_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_91_tmpany_phold = bem_getSourceFileName_1(bevt_92_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_91_tmpany_phold);
bem_addFrame_1(bevl_fr);
} /* Line: 185 */
 else  /* Line: 186 */ {
if (bevp_vv.bevi_bool) /* Line: 188 */ {
bevt_95_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_32;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevl_callPart);
bevt_96_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_33;
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bem_add_1(bevt_96_tmpany_phold);
bevt_93_tmpany_phold.bem_print_0();
} /* Line: 189 */
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_33));
bevl_parts = bevl_callPart.bem_split_1(bevt_97_tmpany_phold);
bevt_99_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_100_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_34;
if (bevt_99_tmpany_phold.bevi_int > bevt_100_tmpany_phold.bevi_int) {
bevt_98_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_102_tmpany_phold = bevl_parts.bem_sizeGet_0();
bevt_103_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_35;
if (bevt_102_tmpany_phold.bevi_int > bevt_103_tmpany_phold.bevi_int) {
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_101_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_101_tmpany_phold.bevi_bool) /* Line: 193 */ {
bevt_104_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_104_tmpany_phold);
bevt_105_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_105_tmpany_phold);
} /* Line: 195 */
 else  /* Line: 196 */ {
bevt_106_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_106_tmpany_phold);
bevt_107_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_107_tmpany_phold);
} /* Line: 198 */
bevl_mtd = bem_extractMethod_1(bevl_mtd);
if (bevp_vv.bevi_bool) /* Line: 201 */ {
bevt_110_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_36;
bevt_109_tmpany_phold = bevt_110_tmpany_phold.bem_add_1(bevl_mtd);
bevt_111_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_37;
bevt_108_tmpany_phold = bevt_109_tmpany_phold.bem_add_1(bevt_111_tmpany_phold);
bevt_108_tmpany_phold.bem_print_0();
} /* Line: 202 */
bevt_112_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_38;
bevl_start = bevl_klass.bem_find_1(bevt_112_tmpany_phold);
if (bevl_start == null) {
bevt_113_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_113_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevt_115_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_39;
if (bevl_start.bevi_int > bevt_115_tmpany_phold.bevi_int) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 205 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 205 */
 else  /* Line: 205 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 205 */ {
bevt_116_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_40;
bevt_118_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_41;
bevt_117_tmpany_phold = bevl_start.bem_add_1(bevt_118_tmpany_phold);
bevl_end = bevl_klass.bem_find_2(bevt_116_tmpany_phold, bevt_117_tmpany_phold);
if (bevl_end == null) {
bevt_119_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_119_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_119_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_121_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_42;
if (bevl_end.bevi_int > bevt_121_tmpany_phold.bevi_int) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 207 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 207 */
 else  /* Line: 207 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 207 */ {
bevl_klass = bevl_klass.bem_substring_1(bevl_start);
if (bevp_vv.bevi_bool) /* Line: 212 */ {
bevt_124_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_43;
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bem_add_1(bevl_klass);
bevt_125_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_44;
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bem_add_1(bevt_125_tmpany_phold);
bevt_122_tmpany_phold.bem_print_0();
} /* Line: 213 */
bevl_klass = bem_extractKlass_1(bevl_klass);
if (bevp_vv.bevi_bool) /* Line: 216 */ {
bevt_128_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_45;
bevt_127_tmpany_phold = bevt_128_tmpany_phold.bem_add_1(bevl_klass);
bevt_129_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_46;
bevt_126_tmpany_phold = bevt_127_tmpany_phold.bem_add_1(bevt_129_tmpany_phold);
bevt_126_tmpany_phold.bem_print_0();
} /* Line: 217 */
bevl_fr = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_131_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_130_tmpany_phold = bem_getSourceFileName_1(bevt_131_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_130_tmpany_phold);
if (bevp_vv.bevi_bool) /* Line: 221 */ {
bevt_132_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_47;
bevt_132_tmpany_phold.bem_print_0();
} /* Line: 222 */
bem_addFrame_1(bevl_fr);
} /* Line: 224 */
 else  /* Line: 225 */ {
if (bevp_vv.bevi_bool) /* Line: 226 */ {
bevt_133_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_48;
bevt_133_tmpany_phold.bem_print_0();
} /* Line: 227 */
} /* Line: 226 */
} /* Line: 207 */
} /* Line: 205 */
} /* Line: 192 */
} /* Line: 172 */
} /* Line: 171 */
} /* Line: 98 */
 else  /* Line: 91 */ {
break;
} /* Line: 91 */
} /* Line: 91 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_44));
bevp_framesText = null;
} /* Line: 238 */
 else  /* Line: 83 */ {
if (bevp_frames == null) {
bevt_134_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_134_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_134_tmpany_phold.bevi_bool) /* Line: 239 */ {
if (bevp_lang == null) {
bevt_135_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_135_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_135_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 239 */ {
bevt_137_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_49;
bevt_136_tmpany_phold = bevp_lang.bem_equals_1(bevt_137_tmpany_phold);
if (bevt_136_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 239 */ {
bevt_1_tmpany_loop = bevp_frames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 240 */ {
bevt_138_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_138_tmpany_phold).bevi_bool) /* Line: 240 */ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_tmpany_loop.bem_nextGet_0();
bevt_140_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_139_tmpany_phold = bem_extractKlassLib_1(bevt_140_tmpany_phold);
bevl_fr.bem_klassNameSet_1(bevt_139_tmpany_phold);
bevt_142_tmpany_phold = bevl_fr.bem_methodNameGet_0();
bevt_141_tmpany_phold = bem_extractMethod_1(bevt_142_tmpany_phold);
bevl_fr.bem_methodNameSet_1(bevt_141_tmpany_phold);
bevt_144_tmpany_phold = bevl_fr.bem_klassNameGet_0();
bevt_143_tmpany_phold = bem_getSourceFileName_1(bevt_144_tmpany_phold);
bevl_fr.bem_fileNameSet_1(bevt_143_tmpany_phold);
} /* Line: 244 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_9_SystemException_bels_46));
} /* Line: 249 */
 else  /* Line: 250 */ {
} /* Line: 250 */
} /* Line: 83 */
if (bevp_vv.bevi_bool) /* Line: 253 */ {
bevt_145_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_50;
bevt_145_tmpany_phold.bem_print_0();
} /* Line: 254 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_i = bem_createInstance_2(beva_klassName, bevt_0_tmpany_phold);
if (bevl_i == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(-1925247459);
return (BEC_2_4_6_TextString) bevt_2_tmpany_phold;
} /* Line: 263 */
return null;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) {
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_48));
bevl_parts = beva_callPart.bem_split_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_2_tmpany_phold = bevl_parts.bem_get_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_tmpany_phold );
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
try  /* Line: 277 */ {
bevt_0_tmpany_phold = bem_extractKlassInner_1(beva_klass);
return bevt_0_tmpany_phold;
} /* Line: 278 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 279 */
return beva_klass;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) {
BEC_2_9_10_ContainerLinkedList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_51;
bevt_3_tmpany_phold = beva_klass.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 286 */ {
return beva_klass;
} /* Line: 287 */
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_5_tmpany_phold = beva_klass.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_50));
bevl_kparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_52;
bevl_kps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 294 */ {
if (bevl_i.bevi_int < bevl_kps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 294 */ {
bevt_11_tmpany_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpany_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpany_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpany_phold);
bevt_16_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_53;
bevt_15_tmpany_phold = bevl_i.bem_add_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_int < bevl_kps.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_51));
bevl_bec.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 298 */
bevl_sofar.bevi_int += bevl_len.bevi_int;
bevl_i.bevi_int++;
} /* Line: 294 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
return bevl_bec;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) {
BEC_2_9_10_ContainerLinkedList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
if (beva_mtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 306 */ {
bevt_4_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_54;
bevt_3_tmpany_phold = beva_mtd.bem_begins_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 306 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 306 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 306 */ {
return beva_mtd;
} /* Line: 307 */
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevt_5_tmpany_phold = beva_mtd.bem_substring_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_53));
bevl_mparts = bevt_5_tmpany_phold.bem_split_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_55;
bevl_mps = bevt_8_tmpany_phold.bem_subtract_1(bevt_9_tmpany_phold);
bevl_bem = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 312 */ {
if (bevl_i.bevi_int < bevl_mps.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_11_tmpany_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_56;
bevt_13_tmpany_phold = bevl_i.bem_add_1(bevt_14_tmpany_phold);
if (bevt_13_tmpany_phold.bevi_int < bevl_mps.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_54));
bevl_bem.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 314 */
bevl_i.bevi_int++;
} /* Line: 312 */
 else  /* Line: 312 */ {
break;
} /* Line: 312 */
} /* Line: 312 */
return bevl_bem;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_framesGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bem_translateEmittedException_0();
if (bevp_vv.bevi_bool) /* Line: 324 */ {
bevt_0_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_57;
bevt_0_tmpany_phold.bem_print_0();
} /* Line: 325 */
return bevp_frames;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFrameText_0() {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bem_translateEmittedException_0();
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 335 */ {
bevt_2_tmpany_phold = bece_BEC_2_6_9_SystemException_bevo_58;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 337 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 337 */ {
bevl_ft = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 338 */
 else  /* Line: 337 */ {
break;
} /* Line: 337 */
} /* Line: 337 */
} /* Line: 337 */
return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_klassNameGet_0() {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_frames == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 350 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) {
BEC_2_9_5_ExceptionFrame bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
bem_addFrame_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNameGet_0() {
return bevp_methodName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGetDirect_0() {
return bevp_methodName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methodName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_methodNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methodName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_klassNameGetDirect_0() {
return bevp_klassName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_klassName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_klassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_klassName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_descriptionGet_0() {
return bevp_description;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGetDirect_0() {
return bevp_description;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_description = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_descriptionSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_description = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fileNameGet_0() {
return bevp_fileName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGetDirect_0() {
return bevp_fileName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_fileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lineNumberGet_0() {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGetDirect_0() {
return bevp_lineNumber;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineNumber = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_lineNumberSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineNumber = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_langGet_0() {
return bevp_lang;
} /*method end*/
public BEC_2_4_6_TextString bem_langGetDirect_0() {
return bevp_lang;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_langSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitLangGet_0() {
return bevp_emitLang;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGetDirect_0() {
return bevp_emitLang;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_emitLangSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_framesGetDirect_0() {
return bevp_frames;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_framesTextGet_0() {
return bevp_framesText;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGetDirect_0() {
return bevp_framesText;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesTextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_translatedGet_0() {
return bevp_translated;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGetDirect_0() {
return bevp_translated;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_translatedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_vvGet_0() {
return bevp_vv;
} /*method end*/
public BEC_2_5_4_LogicBool bem_vvGetDirect_0() {
return bevp_vv;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_vvSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_vvSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {23, 26, 30, 33, 34, 34, 35, 35, 35, 37, 37, 38, 38, 38, 40, 40, 41, 41, 41, 41, 43, 43, 44, 44, 44, 46, 46, 47, 47, 47, 49, 49, 50, 50, 50, 52, 52, 53, 53, 53, 55, 55, 56, 56, 56, 58, 58, 59, 59, 61, 66, 68, 68, 76, 76, 0, 0, 0, 77, 79, 79, 80, 82, 83, 83, 83, 83, 0, 0, 0, 83, 83, 0, 83, 83, 0, 0, 0, 0, 0, 84, 84, 85, 86, 86, 87, 89, 91, 0, 91, 91, 93, 93, 93, 95, 95, 96, 97, 98, 98, 98, 98, 98, 0, 0, 0, 100, 100, 100, 102, 102, 102, 102, 103, 103, 103, 103, 0, 0, 0, 105, 105, 105, 107, 107, 107, 110, 110, 111, 111, 113, 113, 113, 114, 114, 115, 115, 115, 115, 118, 118, 119, 119, 120, 120, 122, 122, 122, 123, 123, 124, 124, 127, 128, 133, 133, 134, 134, 136, 136, 139, 139, 139, 139, 140, 140, 142, 142, 144, 144, 144, 146, 146, 147, 147, 148, 148, 150, 150, 151, 151, 152, 152, 154, 154, 154, 156, 157, 164, 164, 164, 164, 165, 165, 165, 165, 0, 0, 0, 166, 166, 166, 168, 168, 168, 171, 171, 174, 174, 176, 176, 177, 177, 179, 181, 183, 184, 184, 184, 185, 189, 189, 189, 189, 189, 191, 191, 192, 192, 192, 192, 193, 193, 193, 193, 194, 194, 195, 195, 197, 197, 198, 198, 200, 202, 202, 202, 202, 202, 204, 204, 205, 205, 205, 205, 205, 0, 0, 0, 206, 206, 206, 206, 207, 207, 207, 207, 207, 0, 0, 0, 211, 213, 213, 213, 213, 213, 215, 217, 217, 217, 217, 217, 219, 220, 220, 220, 222, 222, 224, 227, 227, 236, 237, 238, 239, 239, 239, 239, 0, 0, 0, 239, 239, 0, 0, 0, 240, 0, 240, 240, 241, 241, 241, 242, 242, 242, 243, 243, 243, 248, 249, 254, 254, 260, 260, 261, 261, 263, 263, 266, 271, 271, 273, 273, 273, 273, 278, 278, 282, 286, 286, 0, 286, 286, 286, 286, 0, 0, 287, 289, 289, 289, 289, 290, 290, 290, 291, 292, 293, 294, 294, 294, 295, 295, 297, 297, 297, 298, 298, 298, 298, 298, 298, 299, 294, 302, 306, 306, 0, 306, 306, 306, 306, 0, 0, 307, 309, 309, 309, 309, 310, 310, 310, 311, 312, 312, 312, 313, 313, 314, 314, 314, 314, 314, 314, 312, 317, 323, 325, 325, 328, 332, 333, 334, 335, 335, 336, 336, 337, 0, 337, 337, 338, 341, 345, 349, 349, 350, 352, 356, 356, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {140, 141, 173, 174, 175, 180, 181, 182, 183, 185, 190, 191, 192, 193, 195, 200, 201, 202, 203, 204, 206, 211, 212, 213, 214, 216, 221, 222, 223, 224, 226, 231, 232, 233, 234, 236, 241, 242, 243, 244, 246, 251, 252, 253, 254, 256, 261, 262, 263, 265, 271, 275, 276, 443, 448, 450, 453, 457, 460, 462, 467, 468, 470, 471, 476, 477, 482, 483, 486, 490, 493, 494, 496, 499, 500, 502, 505, 509, 512, 516, 519, 520, 521, 522, 523, 525, 528, 530, 530, 533, 535, 537, 538, 539, 541, 542, 543, 544, 545, 550, 551, 552, 557, 558, 561, 565, 569, 570, 571, 573, 574, 575, 576, 577, 582, 583, 588, 589, 592, 596, 600, 601, 602, 604, 605, 606, 608, 609, 610, 615, 616, 617, 618, 619, 620, 622, 623, 624, 625, 627, 628, 629, 634, 635, 636, 637, 638, 639, 640, 641, 643, 644, 646, 648, 654, 655, 656, 661, 663, 664, 666, 667, 668, 669, 670, 675, 677, 678, 680, 681, 682, 683, 684, 685, 690, 691, 692, 693, 694, 695, 700, 701, 702, 704, 705, 706, 707, 709, 717, 718, 719, 720, 721, 726, 727, 732, 733, 736, 740, 743, 744, 745, 748, 749, 750, 753, 758, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 776, 777, 778, 779, 780, 782, 783, 784, 785, 786, 791, 792, 793, 794, 799, 800, 801, 802, 803, 806, 807, 808, 809, 811, 813, 814, 815, 816, 817, 819, 820, 821, 826, 827, 828, 833, 834, 837, 841, 844, 845, 846, 847, 848, 853, 854, 855, 860, 861, 864, 868, 871, 873, 874, 875, 876, 877, 879, 881, 882, 883, 884, 885, 887, 888, 889, 890, 892, 893, 895, 899, 900, 913, 914, 915, 918, 923, 924, 929, 930, 933, 937, 940, 941, 943, 946, 950, 953, 953, 956, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 973, 974, 980, 981, 990, 991, 992, 997, 998, 999, 1001, 1009, 1010, 1011, 1012, 1013, 1014, 1020, 1021, 1026, 1054, 1059, 1060, 1063, 1064, 1065, 1070, 1071, 1074, 1078, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1090, 1093, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1111, 1112, 1113, 1115, 1116, 1122, 1145, 1150, 1151, 1154, 1155, 1156, 1161, 1162, 1165, 1169, 1171, 1172, 1173, 1174, 1175, 1176, 1177, 1178, 1179, 1182, 1187, 1188, 1189, 1190, 1191, 1192, 1197, 1198, 1199, 1201, 1207, 1211, 1213, 1214, 1216, 1226, 1227, 1228, 1229, 1234, 1235, 1236, 1237, 1237, 1240, 1242, 1243, 1250, 1253, 1257, 1262, 1263, 1265, 1270, 1271, 1275, 1278, 1281, 1285, 1289, 1292, 1296, 1300, 1303, 1306, 1310, 1314, 1317, 1320, 1324, 1328, 1331, 1334, 1338, 1342, 1345, 1348, 1352, 1356, 1359, 1362, 1366, 1370, 1373, 1377, 1381, 1384, 1387, 1391, 1395, 1398, 1401, 1405, 1409, 1412, 1415, 1419};
/* BEGIN LINEINFO 
assign 1 23 140
new 0 23 140
assign 1 26 141
translateEmittedException 0 30 173
assign 1 33 174
new 0 33 174
assign 1 34 175
def 1 34 180
assign 1 35 181
new 0 35 181
assign 1 35 182
add 1 35 182
assign 1 35 183
add 1 35 183
assign 1 37 185
def 1 37 190
assign 1 38 191
new 0 38 191
assign 1 38 192
add 1 38 192
assign 1 38 193
add 1 38 193
assign 1 40 195
def 1 40 200
assign 1 41 201
new 0 41 201
assign 1 41 202
add 1 41 202
assign 1 41 203
toString 0 41 203
assign 1 41 204
add 1 41 204
assign 1 43 206
def 1 43 211
assign 1 44 212
new 0 44 212
assign 1 44 213
add 1 44 213
assign 1 44 214
add 1 44 214
assign 1 46 216
def 1 46 221
assign 1 47 222
new 0 47 222
assign 1 47 223
add 1 47 223
assign 1 47 224
add 1 47 224
assign 1 49 226
def 1 49 231
assign 1 50 232
new 0 50 232
assign 1 50 233
add 1 50 233
assign 1 50 234
add 1 50 234
assign 1 52 236
def 1 52 241
assign 1 53 242
new 0 53 242
assign 1 53 243
add 1 53 243
assign 1 53 244
add 1 53 244
assign 1 55 246
def 1 55 251
assign 1 56 252
new 0 56 252
assign 1 56 253
add 1 56 253
assign 1 56 254
add 1 56 254
assign 1 58 256
def 1 58 261
assign 1 59 262
getFrameText 0 59 262
assign 1 59 263
add 1 59 263
return 1 61 265
translateEmittedExceptionInner 0 66 271
assign 1 68 275
new 0 68 275
print 0 68 276
assign 1 76 443
def 1 76 448
assign 1 0 450
assign 1 0 453
assign 1 0 457
return 1 77 460
assign 1 79 462
undef 1 79 467
assign 1 80 468
new 0 80 468
assign 1 82 470
new 0 82 470
assign 1 83 471
def 1 83 476
assign 1 83 477
def 1 83 482
assign 1 0 483
assign 1 0 486
assign 1 0 490
assign 1 83 493
new 0 83 493
assign 1 83 494
equals 1 83 494
assign 1 0 496
assign 1 83 499
new 0 83 499
assign 1 83 500
equals 1 83 500
assign 1 0 502
assign 1 0 505
assign 1 0 509
assign 1 0 512
assign 1 0 516
assign 1 84 519
new 0 84 519
assign 1 84 520
new 1 84 520
assign 1 85 521
tokenize 1 85 521
assign 1 86 522
new 0 86 522
assign 1 86 523
equals 1 86 523
assign 1 87 525
new 0 87 525
assign 1 89 528
new 0 89 528
assign 1 91 530
linkedListIteratorGet 0 0 530
assign 1 91 533
hasNextGet 0 91 533
assign 1 91 535
nextGet 0 91 535
assign 1 93 537
new 0 93 537
assign 1 93 538
add 1 93 538
print 0 93 539
assign 1 95 541
new 0 95 541
assign 1 95 542
find 1 95 542
assign 1 96 543
assign 1 97 544
assign 1 98 545
def 1 98 550
assign 1 98 551
new 0 98 551
assign 1 98 552
greaterEquals 1 98 557
assign 1 0 558
assign 1 0 561
assign 1 0 565
assign 1 100 569
new 0 100 569
assign 1 100 570
add 1 100 570
print 0 100 571
assign 1 102 573
new 0 102 573
assign 1 102 574
new 0 102 574
assign 1 102 575
add 1 102 575
assign 1 102 576
find 2 102 576
assign 1 103 577
def 1 103 582
assign 1 103 583
greater 1 103 588
assign 1 0 589
assign 1 0 592
assign 1 0 596
assign 1 105 600
new 0 105 600
assign 1 105 601
add 1 105 601
print 0 105 602
assign 1 107 604
new 0 107 604
assign 1 107 605
add 1 107 605
assign 1 107 606
substring 2 107 606
assign 1 110 608
new 0 110 608
assign 1 110 609
find 2 110 609
assign 1 111 610
def 1 111 615
assign 1 113 616
new 0 113 616
assign 1 113 617
add 1 113 617
assign 1 113 618
substring 1 113 618
assign 1 114 619
new 0 114 619
assign 1 114 620
ends 1 114 620
assign 1 115 622
sizeGet 0 115 622
assign 1 115 623
new 0 115 623
assign 1 115 624
subtract 1 115 624
sizeSet 1 115 625
assign 1 118 627
new 0 118 627
assign 1 118 628
rfind 1 118 628
assign 1 119 629
def 1 119 634
assign 1 120 635
new 0 120 635
assign 1 120 636
substring 2 120 636
assign 1 122 637
new 0 122 637
assign 1 122 638
add 1 122 638
assign 1 122 639
substring 1 122 639
assign 1 123 640
new 0 123 640
assign 1 123 641
begins 1 123 641
assign 1 124 643
new 0 124 643
assign 1 124 644
substring 1 124 644
assign 1 127 646
isInteger 0 127 646
assign 1 128 648
new 1 128 648
assign 1 133 654
new 0 133 654
assign 1 133 655
find 2 133 655
assign 1 134 656
def 1 134 661
assign 1 136 663
new 0 136 663
print 0 136 664
assign 1 139 666
new 0 139 666
assign 1 139 667
new 0 139 667
assign 1 139 668
add 1 139 668
assign 1 139 669
find 2 139 669
assign 1 140 670
def 1 140 675
assign 1 142 677
new 0 142 677
print 0 142 678
assign 1 144 680
new 0 144 680
assign 1 144 681
add 1 144 681
assign 1 144 682
substring 2 144 682
assign 1 146 683
new 0 146 683
assign 1 146 684
rfind 1 146 684
assign 1 147 685
def 1 147 690
assign 1 148 691
new 0 148 691
assign 1 148 692
substring 2 148 692
assign 1 150 693
new 0 150 693
assign 1 150 694
rfind 1 150 694
assign 1 151 695
def 1 151 700
assign 1 152 701
new 0 152 701
assign 1 152 702
substring 2 152 702
assign 1 154 704
new 0 154 704
assign 1 154 705
add 1 154 705
assign 1 154 706
substring 1 154 706
assign 1 156 707
isInteger 0 156 707
assign 1 157 709
new 1 157 709
assign 1 164 717
new 0 164 717
assign 1 164 718
new 0 164 718
assign 1 164 719
add 1 164 719
assign 1 164 720
find 2 164 720
assign 1 165 721
def 1 165 726
assign 1 165 727
greater 1 165 732
assign 1 0 733
assign 1 0 736
assign 1 0 740
assign 1 166 743
new 0 166 743
assign 1 166 744
add 1 166 744
assign 1 166 745
substring 2 166 745
assign 1 168 748
new 0 168 748
assign 1 168 749
add 1 168 749
assign 1 168 750
substring 1 168 750
assign 1 171 753
def 1 171 758
assign 1 174 760
new 0 174 760
assign 1 174 761
split 1 174 761
assign 1 176 762
new 0 176 762
assign 1 176 763
get 1 176 763
assign 1 177 764
new 0 177 764
assign 1 177 765
get 1 177 765
assign 1 179 766
extractKlass 1 179 766
assign 1 181 767
extractMethod 1 181 767
assign 1 183 768
new 4 183 768
assign 1 184 769
klassNameGet 0 184 769
assign 1 184 770
getSourceFileName 1 184 770
fileNameSet 1 184 771
addFrame 1 185 772
assign 1 189 776
new 0 189 776
assign 1 189 777
add 1 189 777
assign 1 189 778
new 0 189 778
assign 1 189 779
add 1 189 779
print 0 189 780
assign 1 191 782
new 0 191 782
assign 1 191 783
split 1 191 783
assign 1 192 784
sizeGet 0 192 784
assign 1 192 785
new 0 192 785
assign 1 192 786
greater 1 192 791
assign 1 193 792
sizeGet 0 193 792
assign 1 193 793
new 0 193 793
assign 1 193 794
greater 1 193 799
assign 1 194 800
new 0 194 800
assign 1 194 801
get 1 194 801
assign 1 195 802
new 0 195 802
assign 1 195 803
get 1 195 803
assign 1 197 806
new 0 197 806
assign 1 197 807
get 1 197 807
assign 1 198 808
new 0 198 808
assign 1 198 809
get 1 198 809
assign 1 200 811
extractMethod 1 200 811
assign 1 202 813
new 0 202 813
assign 1 202 814
add 1 202 814
assign 1 202 815
new 0 202 815
assign 1 202 816
add 1 202 816
print 0 202 817
assign 1 204 819
new 0 204 819
assign 1 204 820
find 1 204 820
assign 1 205 821
def 1 205 826
assign 1 205 827
new 0 205 827
assign 1 205 828
greater 1 205 833
assign 1 0 834
assign 1 0 837
assign 1 0 841
assign 1 206 844
new 0 206 844
assign 1 206 845
new 0 206 845
assign 1 206 846
add 1 206 846
assign 1 206 847
find 2 206 847
assign 1 207 848
def 1 207 853
assign 1 207 854
new 0 207 854
assign 1 207 855
greater 1 207 860
assign 1 0 861
assign 1 0 864
assign 1 0 868
assign 1 211 871
substring 1 211 871
assign 1 213 873
new 0 213 873
assign 1 213 874
add 1 213 874
assign 1 213 875
new 0 213 875
assign 1 213 876
add 1 213 876
print 0 213 877
assign 1 215 879
extractKlass 1 215 879
assign 1 217 881
new 0 217 881
assign 1 217 882
add 1 217 882
assign 1 217 883
new 0 217 883
assign 1 217 884
add 1 217 884
print 0 217 885
assign 1 219 887
new 4 219 887
assign 1 220 888
klassNameGet 0 220 888
assign 1 220 889
getSourceFileName 1 220 889
fileNameSet 1 220 890
assign 1 222 892
new 0 222 892
print 0 222 893
addFrame 1 224 895
assign 1 227 899
new 0 227 899
print 0 227 900
assign 1 236 913
assign 1 237 914
new 0 237 914
assign 1 238 915
assign 1 239 918
def 1 239 923
assign 1 239 924
def 1 239 929
assign 1 0 930
assign 1 0 933
assign 1 0 937
assign 1 239 940
new 0 239 940
assign 1 239 941
equals 1 239 941
assign 1 0 943
assign 1 0 946
assign 1 0 950
assign 1 240 953
linkedListIteratorGet 0 0 953
assign 1 240 956
hasNextGet 0 240 956
assign 1 240 958
nextGet 0 240 958
assign 1 241 959
klassNameGet 0 241 959
assign 1 241 960
extractKlassLib 1 241 960
klassNameSet 1 241 961
assign 1 242 962
methodNameGet 0 242 962
assign 1 242 963
extractMethod 1 242 963
methodNameSet 1 242 964
assign 1 243 965
klassNameGet 0 243 965
assign 1 243 966
getSourceFileName 1 243 966
fileNameSet 1 243 967
assign 1 248 973
assign 1 249 974
new 0 249 974
assign 1 254 980
new 0 254 980
print 0 254 981
assign 1 260 990
new 0 260 990
assign 1 260 991
createInstance 2 260 991
assign 1 261 992
def 1 261 997
assign 1 263 998
sourceFileNameGet 0 263 998
return 1 263 999
return 1 266 1001
assign 1 271 1009
new 0 271 1009
assign 1 271 1010
split 1 271 1010
assign 1 273 1011
new 0 273 1011
assign 1 273 1012
get 1 273 1012
assign 1 273 1013
extractKlass 1 273 1013
return 1 273 1014
assign 1 278 1020
extractKlassInner 1 278 1020
return 1 278 1021
return 1 282 1026
assign 1 286 1054
undef 1 286 1059
assign 1 0 1060
assign 1 286 1063
new 0 286 1063
assign 1 286 1064
begins 1 286 1064
assign 1 286 1065
not 0 286 1070
assign 1 0 1071
assign 1 0 1074
return 1 287 1078
assign 1 289 1080
new 0 289 1080
assign 1 289 1081
substring 1 289 1081
assign 1 289 1082
new 0 289 1082
assign 1 289 1083
split 1 289 1083
assign 1 290 1084
sizeGet 0 290 1084
assign 1 290 1085
new 0 290 1085
assign 1 290 1086
subtract 1 290 1086
assign 1 291 1087
get 1 291 1087
assign 1 292 1088
new 0 292 1088
assign 1 293 1089
new 0 293 1089
assign 1 294 1090
new 0 294 1090
assign 1 294 1093
lesser 1 294 1098
assign 1 295 1099
get 1 295 1099
assign 1 295 1100
new 1 295 1100
assign 1 297 1101
add 1 297 1101
assign 1 297 1102
substring 2 297 1102
addValue 1 297 1103
assign 1 298 1104
new 0 298 1104
assign 1 298 1105
add 1 298 1105
assign 1 298 1106
lesser 1 298 1111
assign 1 298 1112
new 0 298 1112
addValue 1 298 1113
addValue 1 299 1115
incrementValue 0 294 1116
return 1 302 1122
assign 1 306 1145
undef 1 306 1150
assign 1 0 1151
assign 1 306 1154
new 0 306 1154
assign 1 306 1155
begins 1 306 1155
assign 1 306 1156
not 0 306 1161
assign 1 0 1162
assign 1 0 1165
return 1 307 1169
assign 1 309 1171
new 0 309 1171
assign 1 309 1172
substring 1 309 1172
assign 1 309 1173
new 0 309 1173
assign 1 309 1174
split 1 309 1174
assign 1 310 1175
sizeGet 0 310 1175
assign 1 310 1176
new 0 310 1176
assign 1 310 1177
subtract 1 310 1177
assign 1 311 1178
new 0 311 1178
assign 1 312 1179
new 0 312 1179
assign 1 312 1182
lesser 1 312 1187
assign 1 313 1188
get 1 313 1188
addValue 1 313 1189
assign 1 314 1190
new 0 314 1190
assign 1 314 1191
add 1 314 1191
assign 1 314 1192
lesser 1 314 1197
assign 1 314 1198
new 0 314 1198
addValue 1 314 1199
incrementValue 0 312 1201
return 1 317 1207
translateEmittedException 0 323 1211
assign 1 325 1213
new 0 325 1213
print 0 325 1214
return 1 328 1216
translateEmittedException 0 332 1226
assign 1 333 1227
new 0 333 1227
assign 1 334 1228
framesGet 0 334 1228
assign 1 335 1229
def 1 335 1234
assign 1 336 1235
new 0 336 1235
assign 1 336 1236
add 1 336 1236
assign 1 337 1237
linkedListIteratorGet 0 0 1237
assign 1 337 1240
hasNextGet 0 337 1240
assign 1 337 1242
nextGet 0 337 1242
assign 1 338 1243
add 1 338 1243
return 1 341 1250
return 1 345 1253
assign 1 349 1257
undef 1 349 1262
assign 1 350 1263
new 0 350 1263
addValue 1 352 1265
assign 1 356 1270
new 4 356 1270
addFrame 1 356 1271
return 1 0 1275
return 1 0 1278
assign 1 0 1281
assign 1 0 1285
return 1 0 1289
assign 1 0 1292
assign 1 0 1296
return 1 0 1300
return 1 0 1303
assign 1 0 1306
assign 1 0 1310
return 1 0 1314
return 1 0 1317
assign 1 0 1320
assign 1 0 1324
return 1 0 1328
return 1 0 1331
assign 1 0 1334
assign 1 0 1338
return 1 0 1342
return 1 0 1345
assign 1 0 1348
assign 1 0 1352
return 1 0 1356
return 1 0 1359
assign 1 0 1362
assign 1 0 1366
return 1 0 1370
assign 1 0 1373
assign 1 0 1377
return 1 0 1381
return 1 0 1384
assign 1 0 1387
assign 1 0 1391
return 1 0 1395
return 1 0 1398
assign 1 0 1401
assign 1 0 1405
return 1 0 1409
return 1 0 1412
assign 1 0 1415
assign 1 0 1419
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1628841870: return bem_new_0();
case -1893116337: return bem_fileNameGet_0();
case -1251154989: return bem_descriptionGetDirect_0();
case -294806467: return bem_create_0();
case -1027681934: return bem_framesTextGetDirect_0();
case -302817860: return bem_deserializeClassNameGet_0();
case -494057832: return bem_serializationIteratorGet_0();
case -1342633655: return bem_hashGet_0();
case -1916548323: return bem_once_0();
case 1196099876: return bem_echo_0();
case -888502976: return bem_print_0();
case 1269571591: return bem_methodNameGetDirect_0();
case -1297985879: return bem_fieldNamesGet_0();
case -147298756: return bem_vvGet_0();
case -1122332955: return bem_lineNumberGetDirect_0();
case -434911523: return bem_emitLangGet_0();
case 374612292: return bem_fileNameGetDirect_0();
case -1543906095: return bem_getFrameText_0();
case -381924126: return bem_translateEmittedExceptionInner_0();
case -1230714712: return bem_classNameGet_0();
case -671191297: return bem_serializeContents_0();
case 787941758: return bem_emitLangGetDirect_0();
case 1339463094: return bem_translatedGetDirect_0();
case 1989485633: return bem_many_0();
case 1797020795: return bem_toAny_0();
case -1609183284: return bem_klassNameGet_0();
case 32265036: return bem_langGet_0();
case -946267519: return bem_framesGetDirect_0();
case -1643131533: return bem_vvGetDirect_0();
case 1740779891: return bem_lineNumberGet_0();
case 1756033276: return bem_framesGet_0();
case 1832806152: return bem_toString_0();
case -242463884: return bem_fieldIteratorGet_0();
case 1418348540: return bem_iteratorGet_0();
case -905424223: return bem_translateEmittedException_0();
case -170941956: return bem_serializeToString_0();
case 1426244864: return bem_framesTextGet_0();
case -1222154604: return bem_tagGet_0();
case 1259940094: return bem_klassNameGetDirect_0();
case 1328429379: return bem_methodNameGet_0();
case 1633476787: return bem_translatedGet_0();
case -942675959: return bem_descriptionGet_0();
case -901412127: return bem_langGetDirect_0();
case -1925247459: return bem_sourceFileNameGet_0();
case 213564239: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -152296894: return bem_equals_1(bevd_0);
case 1602348302: return bem_sameObject_1(bevd_0);
case 1236940655: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -395616432: return bem_otherClass_1(bevd_0);
case 301814767: return bem_framesSetDirect_1(bevd_0);
case 79810732: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1446216471: return bem_descriptionSetDirect_1(bevd_0);
case -118558475: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1514218528: return bem_emitLangSet_1(bevd_0);
case 1267378865: return bem_langSet_1(bevd_0);
case 945449374: return bem_notEquals_1(bevd_0);
case 924695759: return bem_translatedSet_1(bevd_0);
case 1649556969: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 223792752: return bem_klassNameSet_1(bevd_0);
case 936942966: return bem_undefined_1(bevd_0);
case 1892549801: return bem_framesSet_1(bevd_0);
case -2046043947: return bem_copyTo_1(bevd_0);
case 1569424591: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -523979366: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1436334009: return bem_new_1(bevd_0);
case -444625602: return bem_framesTextSet_1(bevd_0);
case 1962218301: return bem_fileNameSetDirect_1(bevd_0);
case 1810770914: return bem_vvSetDirect_1(bevd_0);
case -1737115805: return bem_emitLangSetDirect_1(bevd_0);
case 805733760: return bem_framesTextSetDirect_1(bevd_0);
case 483207545: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 346995129: return bem_def_1(bevd_0);
case -456462670: return bem_fileNameSet_1(bevd_0);
case -909700659: return bem_translatedSetDirect_1(bevd_0);
case -1811224480: return bem_sameType_1(bevd_0);
case -1109705603: return bem_lineNumberSet_1(bevd_0);
case 1791174458: return bem_descriptionSet_1(bevd_0);
case 1337089292: return bem_methodNameSet_1(bevd_0);
case -810647371: return bem_sameClass_1(bevd_0);
case -788622974: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1345095935: return bem_defined_1(bevd_0);
case 1955170897: return bem_vvSet_1(bevd_0);
case -274501031: return bem_lineNumberSetDirect_1(bevd_0);
case 2030985379: return bem_methodNameSetDirect_1(bevd_0);
case 88301375: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 83181817: return bem_undef_1(bevd_0);
case 1867065609: return bem_langSetDirect_1(bevd_0);
case -1796596677: return bem_otherType_1(bevd_0);
case 1495593147: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1962812172: return bem_klassNameSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -174395426: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1117645207: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1434652185: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2038467728: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 6185266: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 34704188: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1515774718: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -997529892: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemException_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_9_SystemException_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_9_SystemException();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst = (BEC_2_6_9_SystemException) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_type;
}
}
}
