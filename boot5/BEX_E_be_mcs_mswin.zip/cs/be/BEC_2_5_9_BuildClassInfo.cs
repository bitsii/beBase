namespace be {
/* IO:File: source/build/CEmitter.be */
public sealed class BEC_2_5_9_BuildClassInfo : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildClassInfo() { }
static BEC_2_5_9_BuildClassInfo() { }
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x49,0x6E,0x66,0x6F};
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_0 = {0x42,0x45,0x4B,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_0, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_1 = {0x42,0x45,0x4B,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_1, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_2 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_2, 1));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_3 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_4 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_4, 6));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_5 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_5, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_6 = {0x5F,0x73,0x68,0x43,0x6C,0x61,0x73,0x73,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_6, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_7 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_8 = {0x5F,0x73,0x68,0x46,0x69,0x6C,0x65,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_8, 11));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_9 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_9, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_10 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_10, 6));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_11 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_12 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_12, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_13 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_13, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_14 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_14, 16));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_15 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_15, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_16 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_16, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_17 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_17, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_18 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_18, 16));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_19 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_19, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_20 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x43,0x6C,0x65,0x61,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_20, 17));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_21 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_21, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_22 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_22, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_23 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_23, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_24 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_24, 16));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_25 = {0x42,0x45,0x58,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_25, 4));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_26 = {0x42,0x45,0x4B,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_26, 4));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_27 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_27, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_28 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_28, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_29 = {0x2E,0x6D,0x61,0x6B,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_29, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_30 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_31 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_31, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_32 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_32, 4));
public static new BEC_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_15_BuildCompilerProfile bevp_cpro;
public BEC_2_5_8_BuildNamePath bevp_npar;
public BEC_2_6_6_SystemObject bevp_nparSteps;
public BEC_2_4_6_TextString bevp_clName;
public BEC_2_4_6_TextString bevp_clBase;
public BEC_2_4_6_TextString bevp_midName;
public BEC_2_4_6_TextString bevp_incBlock;
public BEC_2_4_6_TextString bevp_mtdName;
public BEC_2_4_6_TextString bevp_cldefName;
public BEC_2_4_6_TextString bevp_shClassName;
public BEC_2_4_6_TextString bevp_shFileName;
public BEC_2_4_6_TextString bevp_cldefBuild;
public BEC_2_4_6_TextString bevp_libnameInit;
public BEC_2_4_6_TextString bevp_libnameInitDone;
public BEC_2_4_6_TextString bevp_libnameData;
public BEC_2_4_6_TextString bevp_libnameDataDone;
public BEC_2_4_6_TextString bevp_libnameDataClear;
public BEC_2_4_6_TextString bevp_libNotNullInit;
public BEC_2_4_6_TextString bevp_libNotNullInitDone;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_cuBase;
public BEC_3_2_4_4_IOFilePath bevp_nsDir;
public BEC_2_4_6_TextString bevp_xbase;
public BEC_2_4_6_TextString bevp_lbase;
public BEC_2_4_6_TextString bevp_nbase;
public BEC_2_4_6_TextString bevp_kbase;
public BEC_3_2_4_4_IOFilePath bevp_cuinitH;
public BEC_2_4_6_TextString bevp_namesIncH;
public BEC_3_2_4_4_IOFilePath bevp_cuinit;
public BEC_3_2_4_4_IOFilePath bevp_namesO;
public BEC_3_2_4_4_IOFilePath bevp_unitShlib;
public BEC_3_2_4_4_IOFilePath bevp_unitExeLink;
public BEC_3_2_4_4_IOFilePath bevp_unitExe;
public BEC_3_2_4_4_IOFilePath bevp_classExeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classExeO;
public BEC_3_2_4_4_IOFilePath bevp_makeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrcH;
public BEC_3_2_4_4_IOFilePath bevp_classIncH;
public BEC_3_2_4_4_IOFilePath bevp_classO;
public BEC_3_2_4_4_IOFilePath bevp_synSrc;
public BEC_2_5_9_BuildClassInfo bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) {
bem_new_5(beva__np, beva__emitter, beva__emitPath, beva__libName, beva__libName);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_new_5(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) {
BEC_2_4_6_TextString bevl_cext = null;
BEC_2_4_6_TextString bevl_oext = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevt_0_tmpany_phold = bevp_emitter.bemd_0(-58429592);
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_phold.bemd_0(-137863162);
bevp_npar = (BEC_2_5_8_BuildNamePath) bevp_np.bem_parentGet_0();
bevp_nparSteps = bevp_npar.bem_stepsGet_0();
bevp_clName = bevp_np.bem_toString_0();
bevt_1_tmpany_phold = bevp_np.bem_stepsGet_0();
bevp_clBase = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_lastGet_0();
bevp_midName = (BEC_2_4_6_TextString) bevp_emitter.bemd_2(-1559853491, beva__libName, beva__np);
bem_nsDirDo_1(beva__libName);
bevl_cext = bevp_cpro.bem_cextGet_0();
bevl_oext = bevp_cpro.bem_oextGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_0;
bevp_incBlock = bevt_2_tmpany_phold.bem_add_1(bevp_midName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevp_midName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_2;
bevp_mtdName = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_3;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevp_midName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_4;
bevp_cldefName = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_5;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_midName);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_6;
bevp_shClassName = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_7;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevp_midName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_8;
bevp_shFileName = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_9;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevp_midName);
bevt_17_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_10;
bevp_cldefBuild = bevt_15_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_11;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevp_midName);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_12;
bevp_libnameInit = bevt_18_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_13;
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevp_midName);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_14;
bevp_libnameInitDone = bevt_21_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_15;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevp_midName);
bevt_26_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_16;
bevp_libnameData = bevt_24_tmpany_phold.bem_add_1(bevt_26_tmpany_phold);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_17;
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(bevp_midName);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_18;
bevp_libnameDataDone = bevt_27_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_19;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevp_midName);
bevt_32_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_20;
bevp_libnameDataClear = bevt_30_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_21;
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevp_midName);
bevt_35_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_22;
bevp_libNotNullInit = bevt_33_tmpany_phold.bem_add_1(bevt_35_tmpany_phold);
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_23;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_midName);
bevt_38_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_24;
bevp_libNotNullInitDone = bevt_36_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevp_emitPath = beva__emitPath;
bevp_basePath = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_add_1(bevp_nsDir);
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_copy_0();
bevt_39_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_25;
bevp_xbase = bevt_39_tmpany_phold.bem_add_1(beva__libName);
bevp_lbase = beva__libName;
bevp_nbase = bevp_clBase;
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_26;
bevp_kbase = bevt_40_tmpany_phold.bem_add_1(bevp_clBase);
bevt_41_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_27;
bevt_42_tmpany_phold = bevp_nbase.bem_add_1(bevt_43_tmpany_phold);
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_41_tmpany_phold.bem_addStep_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_28;
bevp_namesIncH = bevp_nbase.bem_add_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_46_tmpany_phold = bevp_nbase.bem_add_1(bevl_cext);
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_45_tmpany_phold.bem_addStep_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_48_tmpany_phold = bevp_nbase.bem_add_1(bevl_oext);
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_47_tmpany_phold.bem_addStep_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_51_tmpany_phold = bevp_cpro.bem_libExtGet_0();
bevt_50_tmpany_phold = bevp_lbase.bem_add_1(bevt_51_tmpany_phold);
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_49_tmpany_phold.bem_addStep_1(bevt_50_tmpany_phold);
bevt_52_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_54_tmpany_phold = bevp_cpro.bem_exeLibExtGet_0();
bevt_53_tmpany_phold = bevp_lbase.bem_add_1(bevt_54_tmpany_phold);
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_52_tmpany_phold.bem_addStep_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_57_tmpany_phold = bevp_cpro.bem_exeExtGet_0();
bevt_56_tmpany_phold = beva__exeName.bem_add_1(bevt_57_tmpany_phold);
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_55_tmpany_phold.bem_addStep_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_59_tmpany_phold = bevp_xbase.bem_add_1(bevl_cext);
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_58_tmpany_phold.bem_addStep_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_61_tmpany_phold = bevp_xbase.bem_add_1(bevl_oext);
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_60_tmpany_phold.bem_addStep_1(bevt_61_tmpany_phold);
bevt_62_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_64_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_29;
bevt_63_tmpany_phold = bevp_xbase.bem_add_1(bevt_64_tmpany_phold);
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_62_tmpany_phold.bem_addStep_1(bevt_63_tmpany_phold);
bevt_65_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_66_tmpany_phold = bevp_kbase.bem_add_1(bevl_cext);
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_65_tmpany_phold.bem_addStep_1(bevt_66_tmpany_phold);
bevt_67_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_69_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_30;
bevt_68_tmpany_phold = bevp_kbase.bem_add_1(bevt_69_tmpany_phold);
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_67_tmpany_phold.bem_addStep_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_nsDir.bem_copy_0();
bevt_72_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_31;
bevt_71_tmpany_phold = bevp_kbase.bem_add_1(bevt_72_tmpany_phold);
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_70_tmpany_phold.bem_addStep_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_74_tmpany_phold = bevp_kbase.bem_add_1(bevl_oext);
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_73_tmpany_phold.bem_addStep_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_77_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_32;
bevt_76_tmpany_phold = bevp_kbase.bem_add_1(bevt_77_tmpany_phold);
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_75_tmpany_phold.bem_addStep_1(bevt_76_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirDo_1(BEC_2_4_6_TextString beva__libName) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_0();
bevp_nsDir.bem_addStep_1(beva__libName);
bevl_i = bevp_nparSteps.bemd_0(1211836779);
while (true)
 /* Line: 111 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(452370668);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 111 */ {
bevt_1_tmpany_phold = bevl_i.bemd_0(-939463792);
bevp_nsDir.bem_addStep_1(bevt_1_tmpany_phold);
} /* Line: 112 */
 else  /* Line: 111 */ {
break;
} /* Line: 111 */
} /* Line: 111 */
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() {
return bevp_np;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cproGet_0() {
return bevp_cpro;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cproSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_nparGet_0() {
return bevp_npar;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nparStepsGet_0() {
return bevp_nparSteps;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nparSteps = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clNameGet_0() {
return bevp_clName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clBaseGet_0() {
return bevp_clBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clBaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_midNameGet_0() {
return bevp_midName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_midNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_incBlockGet_0() {
return bevp_incBlock;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_incBlockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mtdNameGet_0() {
return bevp_mtdName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_mtdNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefNameGet_0() {
return bevp_cldefName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shClassNameGet_0() {
return bevp_shClassName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shClassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shFileNameGet_0() {
return bevp_shFileName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefBuildGet_0() {
return bevp_cldefBuild;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitGet_0() {
return bevp_libnameInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitDoneGet_0() {
return bevp_libnameInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataGet_0() {
return bevp_libnameData;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataDoneGet_0() {
return bevp_libnameDataDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataClearGet_0() {
return bevp_libnameDataClear;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataClearSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitGet_0() {
return bevp_libNotNullInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitDoneGet_0() {
return bevp_libNotNullInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() {
return bevp_basePath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuBaseGet_0() {
return bevp_cuBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuBaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_nsDirGet_0() {
return bevp_nsDir;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_xbaseGet_0() {
return bevp_xbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_xbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbaseGet_0() {
return bevp_lbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_lbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nbaseGet_0() {
return bevp_nbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_kbaseGet_0() {
return bevp_kbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_kbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitHGet_0() {
return bevp_cuinitH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_namesIncHGet_0() {
return bevp_namesIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesIncHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitGet_0() {
return bevp_cuinit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_namesOGet_0() {
return bevp_namesO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitShlibGet_0() {
return bevp_unitShlib;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitShlibSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeLinkGet_0() {
return bevp_unitExeLink;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeLinkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeGet_0() {
return bevp_unitExe;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeSrcGet_0() {
return bevp_classExeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeOGet_0() {
return bevp_classExeO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeSrcGet_0() {
return bevp_makeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_makeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcGet_0() {
return bevp_classSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcHGet_0() {
return bevp_classSrcH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classIncHGet_0() {
return bevp_classIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classIncHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classOGet_0() {
return bevp_classO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synSrcGet_0() {
return bevp_synSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_synSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {21, 28, 29, 30, 30, 31, 32, 33, 35, 35, 37, 39, 40, 41, 44, 44, 46, 46, 46, 46, 48, 48, 48, 48, 50, 50, 50, 50, 52, 52, 52, 52, 54, 54, 54, 54, 56, 56, 56, 56, 58, 58, 58, 58, 60, 60, 60, 60, 62, 62, 62, 62, 64, 64, 64, 64, 66, 66, 66, 66, 67, 67, 67, 67, 69, 71, 72, 75, 75, 76, 77, 78, 78, 80, 80, 80, 80, 81, 81, 82, 82, 82, 83, 83, 83, 87, 87, 87, 87, 88, 88, 88, 88, 89, 89, 89, 89, 91, 91, 91, 92, 92, 92, 93, 93, 93, 93, 95, 95, 95, 96, 96, 96, 96, 97, 97, 97, 97, 98, 98, 98, 99, 99, 99, 99, 109, 110, 111, 111, 112, 112, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {120, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 334, 335, 336, 339, 341, 342, 351, 354, 358, 361, 365, 368, 372, 375, 379, 382, 386, 389, 393, 396, 400, 403, 407, 410, 414, 417, 421, 424, 428, 431, 435, 438, 442, 445, 449, 452, 456, 459, 463, 466, 470, 473, 477, 480, 484, 487, 491, 494, 498, 501, 505, 508, 512, 515, 519, 522, 526, 529, 533, 536, 540, 543, 547, 550, 554, 557, 561, 564, 568, 571, 575, 578, 582, 585, 589, 592, 596, 599, 603, 606, 610, 613, 617, 620, 624, 627, 631, 634, 638, 641, 645, 648, 652, 655};
/* BEGIN LINEINFO 
new 5 21 120
assign 1 28 204
assign 1 29 205
assign 1 30 206
buildGet 0 30 206
assign 1 30 207
compilerProfileGet 0 30 207
assign 1 31 208
parentGet 0 31 208
assign 1 32 209
stepsGet 0 32 209
assign 1 33 210
toString 0 33 210
assign 1 35 211
stepsGet 0 35 211
assign 1 35 212
lastGet 0 35 212
assign 1 37 213
midNameDo 2 37 213
nsDirDo 1 39 214
assign 1 40 215
cextGet 0 40 215
assign 1 41 216
oextGet 0 41 216
assign 1 44 217
new 0 44 217
assign 1 44 218
add 1 44 218
assign 1 46 219
new 0 46 219
assign 1 46 220
add 1 46 220
assign 1 46 221
new 0 46 221
assign 1 46 222
add 1 46 222
assign 1 48 223
new 0 48 223
assign 1 48 224
add 1 48 224
assign 1 48 225
new 0 48 225
assign 1 48 226
add 1 48 226
assign 1 50 227
new 0 50 227
assign 1 50 228
add 1 50 228
assign 1 50 229
new 0 50 229
assign 1 50 230
add 1 50 230
assign 1 52 231
new 0 52 231
assign 1 52 232
add 1 52 232
assign 1 52 233
new 0 52 233
assign 1 52 234
add 1 52 234
assign 1 54 235
new 0 54 235
assign 1 54 236
add 1 54 236
assign 1 54 237
new 0 54 237
assign 1 54 238
add 1 54 238
assign 1 56 239
new 0 56 239
assign 1 56 240
add 1 56 240
assign 1 56 241
new 0 56 241
assign 1 56 242
add 1 56 242
assign 1 58 243
new 0 58 243
assign 1 58 244
add 1 58 244
assign 1 58 245
new 0 58 245
assign 1 58 246
add 1 58 246
assign 1 60 247
new 0 60 247
assign 1 60 248
add 1 60 248
assign 1 60 249
new 0 60 249
assign 1 60 250
add 1 60 250
assign 1 62 251
new 0 62 251
assign 1 62 252
add 1 62 252
assign 1 62 253
new 0 62 253
assign 1 62 254
add 1 62 254
assign 1 64 255
new 0 64 255
assign 1 64 256
add 1 64 256
assign 1 64 257
new 0 64 257
assign 1 64 258
add 1 64 258
assign 1 66 259
new 0 66 259
assign 1 66 260
add 1 66 260
assign 1 66 261
new 0 66 261
assign 1 66 262
add 1 66 262
assign 1 67 263
new 0 67 263
assign 1 67 264
add 1 67 264
assign 1 67 265
new 0 67 265
assign 1 67 266
add 1 67 266
assign 1 69 267
assign 1 71 268
add 1 71 268
assign 1 72 269
copy 0 72 269
assign 1 75 270
new 0 75 270
assign 1 75 271
add 1 75 271
assign 1 76 272
assign 1 77 273
assign 1 78 274
new 0 78 274
assign 1 78 275
add 1 78 275
assign 1 80 276
copy 0 80 276
assign 1 80 277
new 0 80 277
assign 1 80 278
add 1 80 278
assign 1 80 279
addStep 1 80 279
assign 1 81 280
new 0 81 280
assign 1 81 281
add 1 81 281
assign 1 82 282
copy 0 82 282
assign 1 82 283
add 1 82 283
assign 1 82 284
addStep 1 82 284
assign 1 83 285
copy 0 83 285
assign 1 83 286
add 1 83 286
assign 1 83 287
addStep 1 83 287
assign 1 87 288
copy 0 87 288
assign 1 87 289
libExtGet 0 87 289
assign 1 87 290
add 1 87 290
assign 1 87 291
addStep 1 87 291
assign 1 88 292
copy 0 88 292
assign 1 88 293
exeLibExtGet 0 88 293
assign 1 88 294
add 1 88 294
assign 1 88 295
addStep 1 88 295
assign 1 89 296
copy 0 89 296
assign 1 89 297
exeExtGet 0 89 297
assign 1 89 298
add 1 89 298
assign 1 89 299
addStep 1 89 299
assign 1 91 300
copy 0 91 300
assign 1 91 301
add 1 91 301
assign 1 91 302
addStep 1 91 302
assign 1 92 303
copy 0 92 303
assign 1 92 304
add 1 92 304
assign 1 92 305
addStep 1 92 305
assign 1 93 306
copy 0 93 306
assign 1 93 307
new 0 93 307
assign 1 93 308
add 1 93 308
assign 1 93 309
addStep 1 93 309
assign 1 95 310
copy 0 95 310
assign 1 95 311
add 1 95 311
assign 1 95 312
addStep 1 95 312
assign 1 96 313
copy 0 96 313
assign 1 96 314
new 0 96 314
assign 1 96 315
add 1 96 315
assign 1 96 316
addStep 1 96 316
assign 1 97 317
copy 0 97 317
assign 1 97 318
new 0 97 318
assign 1 97 319
add 1 97 319
assign 1 97 320
addStep 1 97 320
assign 1 98 321
copy 0 98 321
assign 1 98 322
add 1 98 322
assign 1 98 323
addStep 1 98 323
assign 1 99 324
copy 0 99 324
assign 1 99 325
new 0 99 325
assign 1 99 326
add 1 99 326
assign 1 99 327
addStep 1 99 327
assign 1 109 334
new 0 109 334
addStep 1 110 335
assign 1 111 336
iteratorGet 0 111 336
assign 1 111 339
hasNextGet 0 111 339
assign 1 112 341
nextGet 0 112 341
addStep 1 112 342
return 1 0 351
assign 1 0 354
return 1 0 358
assign 1 0 361
return 1 0 365
assign 1 0 368
return 1 0 372
assign 1 0 375
return 1 0 379
assign 1 0 382
return 1 0 386
assign 1 0 389
return 1 0 393
assign 1 0 396
return 1 0 400
assign 1 0 403
return 1 0 407
assign 1 0 410
return 1 0 414
assign 1 0 417
return 1 0 421
assign 1 0 424
return 1 0 428
assign 1 0 431
return 1 0 435
assign 1 0 438
return 1 0 442
assign 1 0 445
return 1 0 449
assign 1 0 452
return 1 0 456
assign 1 0 459
return 1 0 463
assign 1 0 466
return 1 0 470
assign 1 0 473
return 1 0 477
assign 1 0 480
return 1 0 484
assign 1 0 487
return 1 0 491
assign 1 0 494
return 1 0 498
assign 1 0 501
return 1 0 505
assign 1 0 508
return 1 0 512
assign 1 0 515
return 1 0 519
assign 1 0 522
return 1 0 526
assign 1 0 529
return 1 0 533
assign 1 0 536
return 1 0 540
assign 1 0 543
return 1 0 547
assign 1 0 550
return 1 0 554
assign 1 0 557
return 1 0 561
assign 1 0 564
return 1 0 568
assign 1 0 571
return 1 0 575
assign 1 0 578
return 1 0 582
assign 1 0 585
return 1 0 589
assign 1 0 592
return 1 0 596
assign 1 0 599
return 1 0 603
assign 1 0 606
return 1 0 610
assign 1 0 613
return 1 0 617
assign 1 0 620
return 1 0 624
assign 1 0 627
return 1 0 631
assign 1 0 634
return 1 0 638
assign 1 0 641
return 1 0 645
assign 1 0 648
return 1 0 652
assign 1 0 655
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1180774265: return bem_classSrcGet_0();
case 1787065525: return bem_libnameDataDoneGet_0();
case 1017907228: return bem_libnameDataClearGet_0();
case 1905931404: return bem_cuinitHGet_0();
case 1780770811: return bem_nparStepsGet_0();
case 1474352025: return bem_emitPathGet_0();
case -1015060926: return bem_makeSrcGet_0();
case -2052611744: return bem_once_0();
case 1212591077: return bem_midNameGet_0();
case -1637663255: return bem_cproGet_0();
case 2085674875: return bem_echo_0();
case -1152001976: return bem_copy_0();
case -1116236768: return bem_lbaseGet_0();
case -1067210899: return bem_xbaseGet_0();
case 47268889: return bem_libNotNullInitDoneGet_0();
case 752911959: return bem_hashGet_0();
case -1193265838: return bem_new_0();
case -1896601781: return bem_toAny_0();
case -1976290782: return bem_print_0();
case -2091198124: return bem_tagGet_0();
case -1632285157: return bem_unitShlibGet_0();
case 1376178489: return bem_nparGet_0();
case -1282793947: return bem_mtdNameGet_0();
case 748924379: return bem_cuBaseGet_0();
case -104489446: return bem_libNotNullInitGet_0();
case -181098176: return bem_classExeOGet_0();
case -1997351111: return bem_namesOGet_0();
case 444169984: return bem_sourceFileNameGet_0();
case -550483090: return bem_nbaseGet_0();
case 1205172080: return bem_libnameDataGet_0();
case 2046090945: return bem_unitExeLinkGet_0();
case 1591379604: return bem_clNameGet_0();
case 1310164435: return bem_serializeContents_0();
case 142206752: return bem_many_0();
case -1180605105: return bem_synSrcGet_0();
case -1888508563: return bem_serializationIteratorGet_0();
case 2027547274: return bem_clBaseGet_0();
case 880152096: return bem_classNameGet_0();
case 2098501683: return bem_create_0();
case 1296051716: return bem_cuinitGet_0();
case -931663842: return bem_kbaseGet_0();
case 176622920: return bem_cldefBuildGet_0();
case -714492412: return bem_classSrcHGet_0();
case 1524331682: return bem_incBlockGet_0();
case 826562666: return bem_emitterGet_0();
case -1453026023: return bem_unitExeGet_0();
case -1853436869: return bem_shFileNameGet_0();
case 1211836779: return bem_iteratorGet_0();
case -1253688909: return bem_libnameInitGet_0();
case -1316259244: return bem_namesIncHGet_0();
case -364515046: return bem_fieldIteratorGet_0();
case 739269736: return bem_npGet_0();
case 945526017: return bem_shClassNameGet_0();
case 639855850: return bem_classIncHGet_0();
case -326646035: return bem_toString_0();
case -388170175: return bem_cldefNameGet_0();
case -871449231: return bem_classExeSrcGet_0();
case -2079092268: return bem_libnameInitDoneGet_0();
case 2141550628: return bem_deserializeClassNameGet_0();
case 775794384: return bem_classOGet_0();
case 1278477757: return bem_serializeToString_0();
case 1557487820: return bem_basePathGet_0();
case 1559366210: return bem_nsDirGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2070306883: return bem_makeSrcSet_1(bevd_0);
case -1212717800: return bem_classOSet_1(bevd_0);
case -796712016: return bem_classIncHSet_1(bevd_0);
case 607370643: return bem_undefined_1(bevd_0);
case -360259051: return bem_cproSet_1(bevd_0);
case 370984592: return bem_unitExeLinkSet_1(bevd_0);
case -490370672: return bem_kbaseSet_1(bevd_0);
case 516311270: return bem_libnameInitDoneSet_1(bevd_0);
case 786057407: return bem_incBlockSet_1(bevd_0);
case -1749442969: return bem_libnameDataDoneSet_1(bevd_0);
case -1510392763: return bem_cldefBuildSet_1(bevd_0);
case 348861020: return bem_classSrcSet_1(bevd_0);
case 1048239710: return bem_sameClass_1(bevd_0);
case -447963428: return bem_emitterSet_1(bevd_0);
case 324151403: return bem_shClassNameSet_1(bevd_0);
case -263851894: return bem_namesOSet_1(bevd_0);
case 136677527: return bem_def_1(bevd_0);
case 1041485921: return bem_nbaseSet_1(bevd_0);
case -2018719997: return bem_basePathSet_1(bevd_0);
case -1321282362: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2006784960: return bem_shFileNameSet_1(bevd_0);
case 986477958: return bem_defined_1(bevd_0);
case 637646540: return bem_libnameDataSet_1(bevd_0);
case -1768783806: return bem_nsDirDo_1((BEC_2_4_6_TextString) bevd_0);
case -944625262: return bem_classExeSrcSet_1(bevd_0);
case 930180418: return bem_copyTo_1(bevd_0);
case 496808651: return bem_sameObject_1(bevd_0);
case -1262454386: return bem_emitPathSet_1(bevd_0);
case 704931292: return bem_xbaseSet_1(bevd_0);
case -785327205: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1990827367: return bem_notEquals_1(bevd_0);
case -1911529133: return bem_libNotNullInitSet_1(bevd_0);
case 1999035060: return bem_libnameInitSet_1(bevd_0);
case 45057151: return bem_equals_1(bevd_0);
case 275457317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 510702047: return bem_libNotNullInitDoneSet_1(bevd_0);
case -1972428828: return bem_npSet_1(bevd_0);
case -1191000829: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1685045942: return bem_libnameDataClearSet_1(bevd_0);
case 1918236641: return bem_cldefNameSet_1(bevd_0);
case 724839669: return bem_classSrcHSet_1(bevd_0);
case 369800589: return bem_cuinitHSet_1(bevd_0);
case -1866601742: return bem_otherType_1(bevd_0);
case -1824045085: return bem_cuBaseSet_1(bevd_0);
case -1799762120: return bem_mtdNameSet_1(bevd_0);
case -1427200024: return bem_namesIncHSet_1(bevd_0);
case -1913708075: return bem_clBaseSet_1(bevd_0);
case -375478580: return bem_synSrcSet_1(bevd_0);
case -387564148: return bem_nparSet_1(bevd_0);
case -37185795: return bem_unitShlibSet_1(bevd_0);
case 1471739492: return bem_nparStepsSet_1(bevd_0);
case -268062423: return bem_classExeOSet_1(bevd_0);
case 1268433926: return bem_otherClass_1(bevd_0);
case 1579053823: return bem_sameType_1(bevd_0);
case 1948085050: return bem_undef_1(bevd_0);
case 1506867906: return bem_nsDirSet_1(bevd_0);
case -1849094111: return bem_midNameSet_1(bevd_0);
case -1470692413: return bem_lbaseSet_1(bevd_0);
case -264971652: return bem_cuinitSet_1(bevd_0);
case 1124304156: return bem_clNameSet_1(bevd_0);
case -1405188316: return bem_unitExeSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 686788947: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1768228505: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1400688487: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 253281852: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1848289028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 893523384: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1481064275: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1536411490: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 1097869268: return bem_new_5((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildClassInfo_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildClassInfo_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildClassInfo();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst = (BEC_2_5_9_BuildClassInfo) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst;
}
}
}
