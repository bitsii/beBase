namespace be {
/* IO:File: source/extended/Log.be */
public class BEC_2_2_4_IOLogs : BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOLogs() { }
static BEC_2_2_4_IOLogs() { }
private static byte[] becc_BEC_2_2_4_IOLogs_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67,0x73};
private static byte[] becc_BEC_2_2_4_IOLogs_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
public static new BEC_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_inst;
public BEC_2_4_3_MathInt bevp_debug;
public BEC_2_4_3_MathInt bevp_info;
public BEC_2_4_3_MathInt bevp_warn;
public BEC_2_4_3_MathInt bevp_error;
public BEC_2_4_3_MathInt bevp_fatal;
public BEC_2_9_3_ContainerSet bevp_overrides;
public BEC_2_9_3_ContainerMap bevp_loggers;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_4_3_MathInt bevp_defaultOutputLevel;
public BEC_2_4_3_MathInt bevp_defaultLevel;
public virtual BEC_2_2_4_IOLogs bem_default_0() {
bevp_debug = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(400));
bevp_info = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(300));
bevp_warn = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(200));
bevp_error = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(100));
bevp_fatal = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_overrides = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_loggers = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_defaultOutputLevel = bevp_error;
bevp_defaultLevel = bevp_info;
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_setDefaultLevels_2(BEC_2_4_3_MathInt beva__defaultOutputLevel, BEC_2_4_3_MathInt beva__defaultLevel) {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
try  /* Line: 33 */ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = beva__defaultOutputLevel;
bevp_defaultLevel = beva__defaultLevel;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 37 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = bevl_kv.bemd_0(-396012193);
bevt_2_tmpany_phold = bevp_overrides.bem_has_1(bevt_3_tmpany_phold);
if (!(bevt_2_tmpany_phold.bevi_bool)) /* Line: 38 */ {
bevt_4_tmpany_phold = bevl_kv.bemd_0(1382145967);
bevt_4_tmpany_phold.bemd_2(1957944017, bevp_defaultOutputLevel, bevp_defaultLevel);
} /* Line: 39 */
} /* Line: 38 */
 else  /* Line: 37 */ {
break;
} /* Line: 37 */
} /* Line: 37 */
bevp_lock.bem_unlock_0();
} /* Line: 42 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 44 */
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_putKeyLevels_3(BEC_2_4_6_TextString beva_key, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 49 */ {
bevp_lock.bem_lock_0();
bevp_overrides.bem_put_1(beva_key);
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevl_log = (BEC_2_2_3_IOLog) (new BEC_2_2_3_IOLog()).bem_new_2(beva_level, beva_outputLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 59 */
 else  /* Line: 60 */ {
bevl_log.bem_levelSet_1(beva_level);
bevl_log.bem_outputLevelSet_1(beva_outputLevel);
} /* Line: 62 */
bevp_lock.bem_unlock_0();
} /* Line: 64 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 66 */
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_putLevels_3(BEC_2_6_6_SystemObject beva_inst, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_inst.bemd_0(1985246514);
bem_putKeyLevels_3((BEC_2_4_6_TextString) bevt_0_tmpany_phold , beva_level, beva_outputLevel);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_getKey_1(BEC_2_4_6_TextString beva_key) {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 77 */ {
bevp_lock.bem_lock_0();
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevl_log = (BEC_2_2_3_IOLog) (new BEC_2_2_3_IOLog()).bem_new_2(bevp_defaultOutputLevel, bevp_defaultLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 82 */
bevp_lock.bem_unlock_0();
} /* Line: 84 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 86 */
return bevl_log;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_get_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_2_3_IOLog bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = beva_inst.bemd_0(1985246514);
bevt_0_tmpany_phold = bem_getKey_1((BEC_2_4_6_TextString) bevt_1_tmpany_phold );
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_turnOn_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
try  /* Line: 96 */ {
bevp_lock.bem_lock_0();
bevl_log = bem_get_1(beva_inst);
bevt_0_tmpany_phold = bevl_log.bem_levelGet_0();
bevt_1_tmpany_phold = bevl_log.bem_levelGet_0();
bem_putLevels_3(beva_inst, bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevp_lock.bem_unlock_0();
} /* Line: 102 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 104 */
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_turnOnAll_0() {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
try  /* Line: 109 */ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = bevp_defaultLevel;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 113 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_kv.bemd_0(1382145967);
bevt_2_tmpany_phold.bemd_1(-263517284, bevp_defaultOutputLevel);
bevt_3_tmpany_phold = bevl_kv.bemd_0(1382145967);
bevt_3_tmpany_phold.bemd_1(1205676492, bevp_defaultLevel);
} /* Line: 115 */
 else  /* Line: 113 */ {
break;
} /* Line: 113 */
} /* Line: 113 */
bevp_lock.bem_unlock_0();
} /* Line: 118 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 120 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_debugGet_0() {
return bevp_debug;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_infoGet_0() {
return bevp_info;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_infoSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_warnGet_0() {
return bevp_warn;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_warnSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_errorGet_0() {
return bevp_error;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_errorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_fatalGet_0() {
return bevp_fatal;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_fatalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_overridesGet_0() {
return bevp_overrides;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_overridesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_overrides = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_loggersGet_0() {
return bevp_loggers;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_loggersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loggers = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_defaultOutputLevelGet_0() {
return bevp_defaultOutputLevel;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_defaultOutputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defaultOutputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_defaultLevelGet_0() {
return bevp_defaultLevel;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_defaultLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defaultLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 20, 21, 22, 23, 24, 26, 27, 34, 35, 36, 37, 0, 37, 37, 38, 38, 39, 39, 42, 44, 50, 51, 56, 57, 57, 58, 59, 61, 62, 64, 66, 72, 72, 78, 79, 80, 80, 81, 82, 84, 86, 88, 92, 92, 92, 97, 99, 100, 100, 100, 102, 104, 110, 112, 113, 0, 113, 113, 114, 114, 115, 115, 118, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 41, 42, 43, 44, 44, 47, 49, 50, 51, 53, 54, 61, 65, 74, 75, 76, 77, 82, 83, 84, 87, 88, 90, 94, 100, 101, 109, 110, 111, 116, 117, 118, 120, 124, 126, 131, 132, 133, 141, 142, 143, 144, 145, 146, 150, 162, 163, 164, 164, 167, 169, 170, 171, 172, 173, 179, 183, 188, 191, 195, 198, 202, 205, 209, 212, 216, 219, 223, 226, 230, 233, 237, 240, 244, 247, 251, 254};
/* BEGIN LINEINFO 
assign 1 17 20
new 0 17 20
assign 1 18 21
new 0 18 21
assign 1 19 22
new 0 19 22
assign 1 20 23
new 0 20 23
assign 1 21 24
new 0 21 24
assign 1 22 25
new 0 22 25
assign 1 23 26
new 0 23 26
assign 1 24 27
new 0 24 27
assign 1 26 28
assign 1 27 29
lock 0 34 41
assign 1 35 42
assign 1 36 43
assign 1 37 44
mapIteratorGet 0 0 44
assign 1 37 47
hasNextGet 0 37 47
assign 1 37 49
nextGet 0 37 49
assign 1 38 50
keyGet 0 38 50
assign 1 38 51
has 1 38 51
assign 1 39 53
valueGet 0 39 53
setLevels 2 39 54
unlock 0 42 61
unlock 0 44 65
lock 0 50 74
put 1 51 75
assign 1 56 76
get 1 56 76
assign 1 57 77
undef 1 57 82
assign 1 58 83
new 2 58 83
put 2 59 84
levelSet 1 61 87
outputLevelSet 1 62 88
unlock 0 64 90
unlock 0 66 94
assign 1 72 100
classNameGet 0 72 100
putKeyLevels 3 72 101
lock 0 78 109
assign 1 79 110
get 1 79 110
assign 1 80 111
undef 1 80 116
assign 1 81 117
new 2 81 117
put 2 82 118
unlock 0 84 120
unlock 0 86 124
return 1 88 126
assign 1 92 131
classNameGet 0 92 131
assign 1 92 132
getKey 1 92 132
return 1 92 133
lock 0 97 141
assign 1 99 142
get 1 99 142
assign 1 100 143
levelGet 0 100 143
assign 1 100 144
levelGet 0 100 144
putLevels 3 100 145
unlock 0 102 146
unlock 0 104 150
lock 0 110 162
assign 1 112 163
assign 1 113 164
mapIteratorGet 0 0 164
assign 1 113 167
hasNextGet 0 113 167
assign 1 113 169
nextGet 0 113 169
assign 1 114 170
valueGet 0 114 170
outputLevelSet 1 114 171
assign 1 115 172
valueGet 0 115 172
levelSet 1 115 173
unlock 0 118 179
unlock 0 120 183
return 1 0 188
assign 1 0 191
return 1 0 195
assign 1 0 198
return 1 0 202
assign 1 0 205
return 1 0 209
assign 1 0 212
return 1 0 216
assign 1 0 219
return 1 0 223
assign 1 0 226
return 1 0 230
assign 1 0 233
return 1 0 237
assign 1 0 240
return 1 0 244
assign 1 0 247
return 1 0 251
assign 1 0 254
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 1766164204: return bem_default_0();
case -1538220610: return bem_echo_0();
case -2086951396: return bem_lockGet_0();
case 308705107: return bem_serializeContents_0();
case -67432972: return bem_fieldIteratorGet_0();
case -945654220: return bem_fatalGet_0();
case -1751704975: return bem_many_0();
case -1212055307: return bem_defaultLevelGet_0();
case -146459624: return bem_tagGet_0();
case -1181834336: return bem_serializeToString_0();
case 1704272071: return bem_copy_0();
case 1818190775: return bem_toString_0();
case 711977607: return bem_errorGet_0();
case -1613660155: return bem_serializationIteratorGet_0();
case -805865209: return bem_loggersGet_0();
case -60555519: return bem_turnOnAll_0();
case 1336270310: return bem_overridesGet_0();
case -149161193: return bem_debugGet_0();
case 1133560869: return bem_new_0();
case 1277077124: return bem_once_0();
case 1567284243: return bem_create_0();
case 642325680: return bem_deserializeClassNameGet_0();
case 1190997837: return bem_print_0();
case 1985246514: return bem_classNameGet_0();
case -181286661: return bem_defaultOutputLevelGet_0();
case -1623618780: return bem_warnGet_0();
case -457378134: return bem_sourceFileNameGet_0();
case -1896245120: return bem_infoGet_0();
case 371037351: return bem_hashGet_0();
case -563585217: return bem_toAny_0();
case 16424274: return bem_iteratorGet_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 644287503: return bem_infoSet_1(bevd_0);
case 1024493267: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1002067961: return bem_lockSet_1(bevd_0);
case 1170591864: return bem_otherClass_1(bevd_0);
case 1277451971: return bem_debugSet_1(bevd_0);
case 2077566448: return bem_sameClass_1(bevd_0);
case 579081683: return bem_defined_1(bevd_0);
case -2130760528: return bem_get_1(bevd_0);
case 365995024: return bem_getKey_1((BEC_2_4_6_TextString) bevd_0);
case 1069670174: return bem_undef_1(bevd_0);
case -1210345122: return bem_notEquals_1(bevd_0);
case 1398941771: return bem_def_1(bevd_0);
case 2100039933: return bem_defaultLevelSet_1(bevd_0);
case -1936197463: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1876658189: return bem_defaultOutputLevelSet_1(bevd_0);
case 2101700701: return bem_undefined_1(bevd_0);
case -503068138: return bem_sameType_1(bevd_0);
case 286328794: return bem_fatalSet_1(bevd_0);
case 1933685650: return bem_equals_1(bevd_0);
case 1270721790: return bem_sameObject_1(bevd_0);
case 1214946741: return bem_loggersSet_1(bevd_0);
case -1563438470: return bem_turnOn_1(bevd_0);
case 640858049: return bem_overridesSet_1(bevd_0);
case -1508704559: return bem_copyTo_1(bevd_0);
case 460808658: return bem_errorSet_1(bevd_0);
case -1682170766: return bem_otherType_1(bevd_0);
case -240186291: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -122042490: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -457854885: return bem_warnSet_1(bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -483654719: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1372560242: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1722402091: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1097908484: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1055053136: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1408482482: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2112228411: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 236784492: return bem_setDefaultLevels_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callCase) {
case 475630190: return bem_putLevels_3(bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 782105509: return bem_putKeyLevels_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callCase, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOLogs_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_4_IOLogs_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_4_IOLogs();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst = (BEC_2_2_4_IOLogs) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst;
}
}
}
