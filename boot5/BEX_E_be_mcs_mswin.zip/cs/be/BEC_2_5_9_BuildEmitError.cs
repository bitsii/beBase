namespace be {
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError : BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
static BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_BEC_2_5_9_BuildEmitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_9_BuildEmitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_inst;
public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1460490288: return bem_msgGet_0();
case -28096874: return bem_framesGet_0();
case 1081637786: return bem_langGet_0();
case 835094032: return bem_framesTextGet_0();
case -1853763312: return bem_methodNameGet_0();
case 2039157846: return bem_nodeGet_0();
case -522718889: return bem_fileNameGet_0();
case -1193265838: return bem_new_0();
case -1976290782: return bem_print_0();
case 880152096: return bem_classNameGet_0();
case 1211836779: return bem_iteratorGet_0();
case -1896601781: return bem_toAny_0();
case -2091198124: return bem_tagGet_0();
case 444169984: return bem_sourceFileNameGet_0();
case -2052611744: return bem_once_0();
case -1768911804: return bem_lineNumberGet_0();
case -1888508563: return bem_serializationIteratorGet_0();
case 594317203: return bem_translatedGet_0();
case 752911959: return bem_hashGet_0();
case 1525522454: return bem_emitLangGet_0();
case 1310164435: return bem_serializeContents_0();
case -326646035: return bem_toString_0();
case 846412813: return bem_getFrameText_0();
case -364515046: return bem_fieldIteratorGet_0();
case 2085674875: return bem_echo_0();
case -48214081: return bem_vvGet_0();
case 2098501683: return bem_create_0();
case 1278477757: return bem_serializeToString_0();
case -758174675: return bem_descriptionGet_0();
case -2132005019: return bem_translateEmittedException_0();
case -479463470: return bem_translateEmittedExceptionInner_0();
case 2141550628: return bem_deserializeClassNameGet_0();
case -1152001976: return bem_copy_0();
case 2054006543: return bem_klassNameGet_0();
case 142206752: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1579053823: return bem_sameType_1(bevd_0);
case -107393504: return bem_msgSet_1(bevd_0);
case -978923030: return bem_lineNumberSet_1(bevd_0);
case 496808651: return bem_sameObject_1(bevd_0);
case -1679006993: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1665073559: return bem_emitLangSet_1(bevd_0);
case 607370643: return bem_undefined_1(bevd_0);
case -1985725891: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -931716628: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1886143131: return bem_descriptionSet_1(bevd_0);
case -1458433713: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1773439641: return bem_new_1(bevd_0);
case -405470893: return bem_methodNameSet_1(bevd_0);
case 1268433926: return bem_otherClass_1(bevd_0);
case 1785850138: return bem_framesSet_1(bevd_0);
case -1321282362: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1866601742: return bem_otherType_1(bevd_0);
case 240219118: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 930180418: return bem_copyTo_1(bevd_0);
case 1990827367: return bem_notEquals_1(bevd_0);
case 136677527: return bem_def_1(bevd_0);
case 45057151: return bem_equals_1(bevd_0);
case -1866955922: return bem_vvSet_1(bevd_0);
case -1191000829: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 986477958: return bem_defined_1(bevd_0);
case -1540243401: return bem_klassNameSet_1(bevd_0);
case 1268226306: return bem_framesTextSet_1(bevd_0);
case 698243464: return bem_langSet_1(bevd_0);
case -1096013377: return bem_translatedSet_1(bevd_0);
case -1923381410: return bem_fileNameSet_1(bevd_0);
case 1048239710: return bem_sameClass_1(bevd_0);
case 39663018: return bem_nodeSet_1(bevd_0);
case -785327205: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1948085050: return bem_undef_1(bevd_0);
case 221261757: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 275457317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1768228505: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 627553561: return bem_new_2(bevd_0, bevd_1);
case -1848289028: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 253281852: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1400688487: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 686788947: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 893523384: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1481064275: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -313502918: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildEmitError_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildEmitError_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildEmitError();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst = (BEC_2_5_9_BuildEmitError) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst;
}
}
}
