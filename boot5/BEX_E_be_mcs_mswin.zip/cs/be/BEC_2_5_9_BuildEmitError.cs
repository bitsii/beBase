namespace be {
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError : BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
static BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_BEC_2_5_9_BuildEmitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_9_BuildEmitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_inst;

public static new BET_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -977447054: return bem_framesTextGetDirect_0();
case -276275894: return bem_framesGet_0();
case -1785724794: return bem_once_0();
case 759496930: return bem_tagGet_0();
case 970295405: return bem_lineNumberGetDirect_0();
case -2075367149: return bem_methodNameGetDirect_0();
case 168135582: return bem_create_0();
case 944073339: return bem_fieldIteratorGet_0();
case -534102240: return bem_translatedGet_0();
case 1365897346: return bem_serializationIteratorGet_0();
case 1025192638: return bem_translatedGetDirect_0();
case 637109880: return bem_msgGetDirect_0();
case 1161638424: return bem_new_0();
case 2132420479: return bem_many_0();
case -497757168: return bem_klassNameGetDirect_0();
case 1940147659: return bem_lineNumberGet_0();
case -773220864: return bem_framesGetDirect_0();
case -1094330497: return bem_descriptionGetDirect_0();
case -652053502: return bem_fieldNamesGet_0();
case 2064925791: return bem_echo_0();
case -546671: return bem_msgGet_0();
case 1778449395: return bem_langGet_0();
case -1647155098: return bem_langGetDirect_0();
case -2079335425: return bem_vvGet_0();
case -1480556491: return bem_toAny_0();
case -203436331: return bem_descriptionGet_0();
case 379648082: return bem_klassNameGet_0();
case 1352041364: return bem_vvGetDirect_0();
case 1155431615: return bem_fileNameGet_0();
case -202912463: return bem_copy_0();
case 350691792: return bem_toString_0();
case -1348022280: return bem_emitLangGetDirect_0();
case 162486973: return bem_fileNameGetDirect_0();
case -345513359: return bem_translateEmittedExceptionInner_0();
case -71162589: return bem_iteratorGet_0();
case -227015919: return bem_emitLangGet_0();
case -1044758745: return bem_serializeToString_0();
case 1684316665: return bem_methodNameGet_0();
case 1696447740: return bem_framesTextGet_0();
case -1555833296: return bem_sourceFileNameGet_0();
case 502881871: return bem_translateEmittedException_0();
case -1642361296: return bem_print_0();
case -1350624179: return bem_nodeGet_0();
case 814334258: return bem_serializeContents_0();
case -1401818361: return bem_deserializeClassNameGet_0();
case -1359614197: return bem_classNameGet_0();
case -1707906970: return bem_getFrameText_0();
case -1711670377: return bem_hashGet_0();
case -1525305355: return bem_nodeGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 287749600: return bem_lineNumberSet_1(bevd_0);
case -13057535: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1613385431: return bem_copyTo_1(bevd_0);
case 1481686114: return bem_nodeSetDirect_1(bevd_0);
case -1945384913: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 588897249: return bem_undefined_1(bevd_0);
case -2027325699: return bem_sameObject_1(bevd_0);
case 183960248: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1486563996: return bem_framesTextSetDirect_1(bevd_0);
case -1646104505: return bem_lineNumberSetDirect_1(bevd_0);
case 1211515630: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1955621818: return bem_descriptionSet_1(bevd_0);
case -19860332: return bem_translatedSetDirect_1(bevd_0);
case -443198819: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 761814509: return bem_fileNameSet_1(bevd_0);
case -2002599580: return bem_framesSetDirect_1(bevd_0);
case -1614213074: return bem_msgSetDirect_1(bevd_0);
case 1497728782: return bem_klassNameSetDirect_1(bevd_0);
case 1021799604: return bem_vvSet_1(bevd_0);
case -1932121743: return bem_defined_1(bevd_0);
case -1017021693: return bem_translatedSet_1(bevd_0);
case -1550024831: return bem_fileNameSetDirect_1(bevd_0);
case -1452972945: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1146522865: return bem_langSetDirect_1(bevd_0);
case -2113521576: return bem_undef_1(bevd_0);
case 425786529: return bem_otherType_1(bevd_0);
case -167349890: return bem_methodNameSet_1(bevd_0);
case 627901733: return bem_sameType_1(bevd_0);
case 1037384817: return bem_emitLangSetDirect_1(bevd_0);
case 1580259785: return bem_langSet_1(bevd_0);
case 1469824899: return bem_msgSet_1(bevd_0);
case -148722121: return bem_emitLangSet_1(bevd_0);
case -701014677: return bem_klassNameSet_1(bevd_0);
case 731055616: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1693445076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2000629893: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1601695700: return bem_sameClass_1(bevd_0);
case -558793791: return bem_methodNameSetDirect_1(bevd_0);
case -1501377166: return bem_framesSet_1(bevd_0);
case -1206824876: return bem_vvSetDirect_1(bevd_0);
case 590337713: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 988397784: return bem_otherClass_1(bevd_0);
case -143491207: return bem_notEquals_1(bevd_0);
case -2061092587: return bem_framesTextSet_1(bevd_0);
case 1787339023: return bem_nodeSet_1(bevd_0);
case -951966168: return bem_def_1(bevd_0);
case -1829001662: return bem_new_1(bevd_0);
case 1408797910: return bem_equals_1(bevd_0);
case -2001556636: return bem_descriptionSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1979351618: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1627152181: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1200632642: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1259587878: return bem_new_2(bevd_0, bevd_1);
case -341866353: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1182713671: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1618012778: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643571511: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -2027851860: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildEmitError_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildEmitError_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildEmitError();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst = (BEC_2_5_9_BuildEmitError) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_type;
}
}
}
