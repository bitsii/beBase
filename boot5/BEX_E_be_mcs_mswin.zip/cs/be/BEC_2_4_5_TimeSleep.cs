namespace be {

using System;
using System.Threading;
/* IO:File: source/base/Time.be */
public class BEC_2_4_5_TimeSleep : BEC_2_6_6_SystemObject {
public BEC_2_4_5_TimeSleep() { }
static BEC_2_4_5_TimeSleep() { }
private static byte[] becc_BEC_2_4_5_TimeSleep_clname = {0x54,0x69,0x6D,0x65,0x3A,0x53,0x6C,0x65,0x65,0x70};
private static byte[] becc_BEC_2_4_5_TimeSleep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_TimeSleep_bevo_0 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_TimeSleep_bevo_1 = (new BEC_2_4_3_MathInt(1000));
public static new BEC_2_4_5_TimeSleep bece_BEC_2_4_5_TimeSleep_bevs_inst;

public static new BET_2_4_5_TimeSleep bece_BEC_2_4_5_TimeSleep_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_4_5_TimeSleep bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_5_TimeSleep bem_sleep_1(BEC_2_4_8_TimeInterval beva_interval) {
BEC_2_4_3_MathInt bevl_secs = null;
BEC_2_4_3_MathInt bevl_millis = null;
BEC_2_4_3_MathInt bevl_sleepMillis = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
if (beva_interval == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevl_secs = beva_interval.bem_secsGet_0();
bevl_millis = beva_interval.bem_millisGet_0();
if (bevl_secs == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 38 */ {
if (bevl_millis == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 38 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 38 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_5_TimeSleep_bevo_0;
bevt_4_tmpany_phold = bevl_secs.bem_multiply_1(bevt_5_tmpany_phold);
bevl_sleepMillis = bevt_4_tmpany_phold.bem_add_1(bevl_millis);
bem_sleepMilliseconds_1(bevl_sleepMillis);
} /* Line: 40 */
} /* Line: 38 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sleepSeconds_1(BEC_2_4_3_MathInt beva_secs) {
BEC_2_4_5_TimeSleep bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_5_TimeSleep_bevo_1;
bevt_1_tmpany_phold = beva_secs.bem_multiply_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_5_TimeSleep) bem_sleepMilliseconds_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_5_TimeSleep bem_sleepMilliseconds_1(BEC_2_4_3_MathInt beva_msecs) {

      Thread.Sleep(beva_msecs.bevi_int);
      return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {35, 35, 36, 37, 38, 38, 38, 38, 0, 0, 0, 39, 39, 39, 40, 46, 46, 46, 46};
public static new int[] bevs_smnlec
 = new int[] {33, 38, 39, 40, 41, 46, 47, 52, 53, 56, 60, 63, 64, 65, 66, 75, 76, 77, 78};
/* BEGIN LINEINFO 
assign 1 35 33
def 1 35 38
assign 1 36 39
secsGet 0 36 39
assign 1 37 40
millisGet 0 37 40
assign 1 38 41
def 1 38 46
assign 1 38 47
def 1 38 52
assign 1 0 53
assign 1 0 56
assign 1 0 60
assign 1 39 63
new 0 39 63
assign 1 39 64
multiply 1 39 64
assign 1 39 65
add 1 39 65
sleepMilliseconds 1 40 66
assign 1 46 75
new 0 46 75
assign 1 46 76
multiply 1 46 76
assign 1 46 77
sleepMilliseconds 1 46 77
return 1 46 78
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1034659716: return bem_once_0();
case 987048722: return bem_serializeContents_0();
case 1599241336: return bem_iteratorGet_0();
case 859534567: return bem_default_0();
case -2044460281: return bem_new_0();
case -427081409: return bem_create_0();
case -647519736: return bem_print_0();
case -1999703144: return bem_sourceFileNameGet_0();
case -31877142: return bem_many_0();
case -709677651: return bem_fieldNamesGet_0();
case -141904644: return bem_toString_0();
case -747859575: return bem_echo_0();
case 1561881831: return bem_tagGet_0();
case -1503949943: return bem_hashGet_0();
case -335942583: return bem_fieldIteratorGet_0();
case -1474345157: return bem_serializeToString_0();
case 247818182: return bem_copy_0();
case 1035232271: return bem_toAny_0();
case 1374872636: return bem_deserializeClassNameGet_0();
case 1992583192: return bem_classNameGet_0();
case 421047878: return bem_serializationIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1118935191: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -767876115: return bem_undef_1(bevd_0);
case 2141740909: return bem_otherClass_1(bevd_0);
case -1617324535: return bem_defined_1(bevd_0);
case 544063329: return bem_equals_1(bevd_0);
case 551811847: return bem_sleepSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1732439949: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1482027850: return bem_sameClass_1(bevd_0);
case -706639306: return bem_sleepMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1103337674: return bem_undefined_1(bevd_0);
case -317049327: return bem_def_1(bevd_0);
case 1051165080: return bem_sameObject_1(bevd_0);
case -1704918916: return bem_sleep_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1037648926: return bem_copyTo_1(bevd_0);
case 467730220: return bem_otherType_1(bevd_0);
case 1056498349: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1259048964: return bem_notEquals_1(bevd_0);
case -2136985639: return bem_sameType_1(bevd_0);
case 1402363485: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1477075576: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2067866135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 930768377: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1135810204: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -78432632: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -657633999: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1155749415: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_TimeSleep_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_5_TimeSleep_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_5_TimeSleep();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst = (BEC_2_4_5_TimeSleep) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_type;
}
}
}
