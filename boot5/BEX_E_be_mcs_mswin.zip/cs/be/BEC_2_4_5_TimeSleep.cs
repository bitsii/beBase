namespace be {

using System;
using System.Threading;
/* IO:File: source/base/Time.be */
public class BEC_2_4_5_TimeSleep : BEC_2_6_6_SystemObject {
public BEC_2_4_5_TimeSleep() { }
static BEC_2_4_5_TimeSleep() { }
private static byte[] becc_BEC_2_4_5_TimeSleep_clname = {0x54,0x69,0x6D,0x65,0x3A,0x53,0x6C,0x65,0x65,0x70};
private static byte[] becc_BEC_2_4_5_TimeSleep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_TimeSleep_bevo_0 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_TimeSleep_bevo_1 = (new BEC_2_4_3_MathInt(1000));
public static new BEC_2_4_5_TimeSleep bece_BEC_2_4_5_TimeSleep_bevs_inst;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_4_5_TimeSleep bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_5_TimeSleep bem_sleep_1(BEC_2_4_8_TimeInterval beva_interval) {
BEC_2_4_3_MathInt bevl_secs = null;
BEC_2_4_3_MathInt bevl_millis = null;
BEC_2_4_3_MathInt bevl_sleepMillis = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
if (beva_interval == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevl_secs = beva_interval.bem_secsGet_0();
bevl_millis = beva_interval.bem_millisGet_0();
if (bevl_secs == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 38 */ {
if (bevl_millis == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 38 */
 else  /* Line: 38 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 38 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_5_TimeSleep_bevo_0;
bevt_4_tmpany_phold = bevl_secs.bem_multiply_1(bevt_5_tmpany_phold);
bevl_sleepMillis = bevt_4_tmpany_phold.bem_add_1(bevl_millis);
bem_sleepMilliseconds_1(bevl_sleepMillis);
} /* Line: 40 */
} /* Line: 38 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sleepSeconds_1(BEC_2_4_3_MathInt beva_secs) {
BEC_2_4_5_TimeSleep bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_5_TimeSleep_bevo_1;
bevt_1_tmpany_phold = beva_secs.bem_multiply_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_5_TimeSleep) bem_sleepMilliseconds_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_5_TimeSleep bem_sleepMilliseconds_1(BEC_2_4_3_MathInt beva_msecs) {

      Thread.Sleep(beva_msecs.bevi_int);
      return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {35, 35, 36, 37, 38, 38, 38, 38, 0, 0, 0, 39, 39, 39, 40, 46, 46, 46, 46};
public static new int[] bevs_smnlec
 = new int[] {30, 35, 36, 37, 38, 43, 44, 49, 50, 53, 57, 60, 61, 62, 63, 72, 73, 74, 75};
/* BEGIN LINEINFO 
assign 1 35 30
def 1 35 35
assign 1 36 36
secsGet 0 36 36
assign 1 37 37
millisGet 0 37 37
assign 1 38 38
def 1 38 43
assign 1 38 44
def 1 38 49
assign 1 0 50
assign 1 0 53
assign 1 0 57
assign 1 39 60
new 0 39 60
assign 1 39 61
multiply 1 39 61
assign 1 39 62
add 1 39 62
sleepMilliseconds 1 40 63
assign 1 46 72
new 0 46 72
assign 1 46 73
multiply 1 46 73
assign 1 46 74
sleepMilliseconds 1 46 74
return 1 46 75
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 747222940: return bem_serializationIteratorGet_0();
case 774868823: return bem_many_0();
case 138118576: return bem_classNameGet_0();
case 173912112: return bem_iteratorGet_0();
case 1826655669: return bem_echo_0();
case 591133328: return bem_once_0();
case 169016919: return bem_deserializeClassNameGet_0();
case 156988171: return bem_toAny_0();
case 1030306077: return bem_hashGet_0();
case -751534347: return bem_tagGet_0();
case 441873246: return bem_fieldIteratorGet_0();
case 1804394239: return bem_create_0();
case 86234609: return bem_print_0();
case 605463834: return bem_sourceFileNameGet_0();
case 1651099395: return bem_copy_0();
case 364146106: return bem_toString_0();
case -814108194: return bem_default_0();
case -1694865880: return bem_serializeToString_0();
case 1232567589: return bem_new_0();
case 1335363828: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -293276429: return bem_undefined_1(bevd_0);
case 143426895: return bem_undef_1(bevd_0);
case -1994725082: return bem_sleepMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 2137457269: return bem_sleepSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 233607642: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 280312858: return bem_sameObject_1(bevd_0);
case -1094373587: return bem_sleep_1((BEC_2_4_8_TimeInterval) bevd_0);
case -66688367: return bem_sameClass_1(bevd_0);
case -2077086955: return bem_sameType_1(bevd_0);
case -548232463: return bem_copyTo_1(bevd_0);
case -1790149278: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1049342566: return bem_equals_1(bevd_0);
case 1022281941: return bem_defined_1(bevd_0);
case 818668120: return bem_def_1(bevd_0);
case 1388122193: return bem_otherClass_1(bevd_0);
case -956577031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1209387497: return bem_otherType_1(bevd_0);
case -729372880: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2078921482: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -936134816: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -265807180: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1675250987: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1991243589: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2096067718: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2037027110: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 808469705: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_TimeSleep_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_5_TimeSleep_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_5_TimeSleep();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst = (BEC_2_4_5_TimeSleep) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst;
}
}
}
