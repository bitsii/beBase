package be.BEL_4_Base;

import java.security.MessageDigest;
/* File: source/base/Encode.be */
public class BEC_6_3_EncodeUrl extends BEC_6_6_SystemObject {
public BEC_6_3_EncodeUrl() { }
private static byte[] becc_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x55,0x72,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(47));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(58));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(64));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(94));
private static BEC_4_3_MathInt bevo_5 = (new BEC_4_3_MathInt(94));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(123));
private static BEC_4_3_MathInt bevo_7 = (new BEC_4_3_MathInt(44));
private static BEC_4_3_MathInt bevo_8 = (new BEC_4_3_MathInt(47));
private static BEC_4_3_MathInt bevo_9 = (new BEC_4_3_MathInt(42));
private static BEC_4_3_MathInt bevo_10 = (new BEC_4_3_MathInt(32));
private static byte[] bels_0 = {0x2B};
private static byte[] bels_1 = {0x25};
private static byte[] bels_2 = {0x2B};
private static BEC_4_6_TextString bevo_11 = (new BEC_4_6_TextString(bels_2, 1));
private static byte[] bels_3 = {0x25};
private static BEC_4_6_TextString bevo_12 = (new BEC_4_6_TextString(bels_3, 1));
private static byte[] bels_4 = {0x20};
private static BEC_4_3_MathInt bevo_13 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_14 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_15 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_16 = (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_17 = (new BEC_4_3_MathInt(3));
private static byte[] bels_5 = {0x2B};
private static BEC_4_6_TextString bevo_18 = (new BEC_4_6_TextString(bels_5, 1));
private static byte[] bels_6 = {0x25};
private static BEC_4_6_TextString bevo_19 = (new BEC_4_6_TextString(bels_6, 1));
public static BEC_6_3_EncodeUrl bevs_inst;
public BEC_6_6_SystemObject bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_3_EncodeUrl bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_encode_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_6_TextString bevl_r = null;
BEC_4_12_TextByteIterator bevl_tb = null;
BEC_4_6_TextString bevl_pt = null;
BEC_4_3_MathInt bevl_ac = null;
BEC_4_6_TextString bevl_hcs = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
bevt_6_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_7_tmpvar_phold = bevo_0;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_multiply_1(bevt_7_tmpvar_phold);
bevl_r = (new BEC_4_6_TextString()).bem_new_1(bevt_5_tmpvar_phold);
bevl_tb = (new BEC_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_8_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevl_pt = (new BEC_4_6_TextString()).bem_new_1(bevt_8_tmpvar_phold);
while (true)
 /* Line: 140 */ {
bevt_9_tmpvar_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 140 */ {
bevl_tb.bem_next_1(bevl_pt);
bevt_10_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_10_tmpvar_phold);
bevt_12_tmpvar_phold = bevo_1;
bevt_11_tmpvar_phold = bevl_ac.bem_greater_1(bevt_12_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 143 */ {
bevt_14_tmpvar_phold = bevo_2;
bevt_13_tmpvar_phold = bevl_ac.bem_lesser_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 143 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 143 */
 else  /* Line: 143 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 143 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_16_tmpvar_phold = bevo_3;
bevt_15_tmpvar_phold = bevl_ac.bem_greater_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 143 */ {
bevt_18_tmpvar_phold = bevo_4;
bevt_17_tmpvar_phold = bevl_ac.bem_lesser_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 143 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 143 */
 else  /* Line: 143 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 143 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 143 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 143 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_20_tmpvar_phold = bevo_5;
bevt_19_tmpvar_phold = bevl_ac.bem_greater_1(bevt_20_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 143 */ {
bevt_22_tmpvar_phold = bevo_6;
bevt_21_tmpvar_phold = bevl_ac.bem_lesser_1(bevt_22_tmpvar_phold);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 143 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 143 */
 else  /* Line: 143 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 143 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 143 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 143 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_24_tmpvar_phold = bevo_7;
bevt_23_tmpvar_phold = bevl_ac.bem_greater_1(bevt_24_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 143 */ {
bevt_26_tmpvar_phold = bevo_8;
bevt_25_tmpvar_phold = bevl_ac.bem_lesser_1(bevt_26_tmpvar_phold);
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 143 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 143 */
 else  /* Line: 143 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 143 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 143 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 143 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_28_tmpvar_phold = bevo_9;
bevt_27_tmpvar_phold = bevl_ac.bem_equals_1(bevt_28_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 143 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 143 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 143 */ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 144 */
 else  /* Line: 143 */ {
bevt_30_tmpvar_phold = bevo_10;
bevt_29_tmpvar_phold = bevl_ac.bem_equals_1(bevt_30_tmpvar_phold);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_31_tmpvar_phold = (new BEC_4_6_TextString(1, bels_0));
bevl_r.bem_addValue_1(bevt_31_tmpvar_phold);
} /* Line: 146 */
 else  /* Line: 147 */ {
bevt_32_tmpvar_phold = (new BEC_4_6_TextString(1, bels_1));
bevl_r.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_33_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevl_hcs = bevl_pt.bem_getHex_1(bevt_33_tmpvar_phold);
bevl_r.bem_addValue_1(bevl_hcs);
} /* Line: 150 */
} /* Line: 143 */
} /* Line: 143 */
 else  /* Line: 140 */ {
break;
} /* Line: 140 */
} /* Line: 140 */
bevt_34_tmpvar_phold = bevl_r.bem_toString_0();
return bevt_34_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_decode_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_6_TextString bevl_r = null;
BEC_4_3_MathInt bevl_last = null;
BEC_4_3_MathInt bevl_npl = null;
BEC_4_3_MathInt bevl_npe = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevl_ispl = null;
BEC_4_3_MathInt bevl_len = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_r = (new BEC_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevl_last = (new BEC_4_3_MathInt(0));
bevt_3_tmpvar_phold = bevo_11;
bevl_npl = beva_str.bem_find_2(bevt_3_tmpvar_phold, bevl_last);
bevt_4_tmpvar_phold = bevo_12;
bevl_npe = beva_str.bem_find_2(bevt_4_tmpvar_phold, bevl_last);
if (bevl_npe == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 166 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
if (bevl_npl == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 166 */ {
bevt_7_tmpvar_phold = bevl_npl.bem_lesser_1(bevl_npe);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 166 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 166 */
 else  /* Line: 166 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 166 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 166 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 166 */ {
bevl_ispl = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 168 */
 else  /* Line: 169 */ {
bevl_ispl = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 171 */
bevl_len = beva_str.bem_sizeGet_0();
while (true)
 /* Line: 175 */ {
if (bevl_i == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 175 */ {
bevt_9_tmpvar_phold = bevl_i.bem_greater_1(bevl_last);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 176 */ {
bevt_10_tmpvar_phold = beva_str.bem_substring_2(bevl_last, bevl_i);
bevl_r.bem_addValue_1(bevt_10_tmpvar_phold);
bevl_last = bevl_i;
} /* Line: 178 */
if (bevl_ispl.bevi_bool) /* Line: 180 */ {
bevt_11_tmpvar_phold = (new BEC_4_6_TextString(1, bels_4));
bevl_r.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevo_13;
bevl_last = bevl_i.bem_add_1(bevt_12_tmpvar_phold);
} /* Line: 182 */
 else  /* Line: 183 */ {
bevt_15_tmpvar_phold = bevo_14;
bevt_14_tmpvar_phold = bevl_i.bem_add_1(bevt_15_tmpvar_phold);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_lesser_1(bevl_len);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 184 */ {
bevt_19_tmpvar_phold = bevo_15;
bevt_18_tmpvar_phold = bevl_i.bem_add_1(bevt_19_tmpvar_phold);
bevt_21_tmpvar_phold = bevo_16;
bevt_20_tmpvar_phold = bevl_i.bem_add_1(bevt_21_tmpvar_phold);
bevt_17_tmpvar_phold = beva_str.bem_substring_2(bevt_18_tmpvar_phold, bevt_20_tmpvar_phold);
bevt_16_tmpvar_phold = (new BEC_4_6_TextString()).bem_hexNew_1(bevt_17_tmpvar_phold);
bevl_r.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_22_tmpvar_phold = bevo_17;
bevl_last = bevl_i.bem_add_1(bevt_22_tmpvar_phold);
} /* Line: 186 */
} /* Line: 184 */
bevt_23_tmpvar_phold = bevo_18;
bevl_npl = beva_str.bem_find_2(bevt_23_tmpvar_phold, bevl_last);
bevt_24_tmpvar_phold = bevo_19;
bevl_npe = beva_str.bem_find_2(bevt_24_tmpvar_phold, bevl_last);
if (bevl_npe == null) {
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
if (bevl_npl == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevt_27_tmpvar_phold = bevl_npl.bem_lesser_1(bevl_npe);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
 else  /* Line: 191 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 191 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 191 */ {
bevl_ispl = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 193 */
 else  /* Line: 194 */ {
bevl_ispl = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 196 */
} /* Line: 191 */
 else  /* Line: 175 */ {
break;
} /* Line: 175 */
} /* Line: 175 */
bevt_28_tmpvar_phold = bevl_last.bem_lesser_1(bevl_len);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 199 */ {
bevt_29_tmpvar_phold = beva_str.bem_substring_2(bevl_last, bevl_len);
bevl_r.bem_addValue_1(bevt_29_tmpvar_phold);
} /* Line: 200 */
bevt_30_tmpvar_phold = bevl_r.bem_toString_0();
return bevt_30_tmpvar_phold;
} /*method end*/
//int[] bevs_nlcs = {137, 137, 137, 137, 138, 139, 139, 140, 141, 142, 142, 143, 143, 143, 143, 0, 0, 0, 0, 143, 143, 143, 143, 0, 0, 0, 0, 0, 0, 143, 143, 143, 143, 0, 0, 0, 0, 0, 0, 143, 143, 143, 143, 0, 0, 0, 0, 0, 0, 143, 143, 0, 0, 144, 145, 145, 146, 146, 148, 148, 149, 149, 150, 153, 153, 157, 157, 158, 164, 164, 165, 165, 166, 166, 0, 166, 166, 166, 0, 0, 0, 0, 0, 167, 168, 170, 171, 174, 175, 175, 176, 177, 177, 178, 181, 181, 182, 182, 184, 184, 184, 185, 185, 185, 185, 185, 185, 185, 186, 186, 189, 189, 190, 190, 191, 191, 0, 191, 191, 191, 0, 0, 0, 0, 0, 192, 193, 195, 196, 199, 200, 200, 202, 202};
//int[] bevs_nlecs = {84, 85, 86, 87, 88, 89, 90, 93, 95, 96, 97, 98, 99, 101, 102, 104, 107, 111, 114, 117, 118, 120, 121, 123, 126, 130, 133, 136, 140, 143, 144, 146, 147, 149, 152, 156, 159, 162, 166, 169, 170, 172, 173, 175, 178, 182, 185, 188, 192, 195, 196, 198, 201, 205, 208, 209, 211, 212, 215, 216, 217, 218, 219, 227, 228, 269, 270, 271, 272, 273, 274, 275, 276, 281, 282, 285, 290, 291, 293, 296, 300, 303, 306, 310, 311, 314, 315, 317, 320, 325, 326, 328, 329, 330, 333, 334, 335, 336, 339, 340, 341, 343, 344, 345, 346, 347, 348, 349, 350, 351, 354, 355, 356, 357, 358, 363, 364, 367, 372, 373, 375, 378, 382, 385, 388, 392, 393, 396, 397, 404, 406, 407, 409, 410};
/* BEGIN LINEINFO 
assign 1 137 84
sizeGet 0 137 84
assign 1 137 85
new 0 137 85
assign 1 137 86
multiply 1 137 86
assign 1 137 87
new 1 137 87
assign 1 138 88
new 1 138 88
assign 1 139 89
new 0 139 89
assign 1 139 90
new 1 139 90
assign 1 140 93
hasNextGet 0 140 93
next 1 141 95
assign 1 142 96
new 0 142 96
assign 1 142 97
getCode 1 142 97
assign 1 143 98
new 0 143 98
assign 1 143 99
greater 1 143 99
assign 1 143 101
new 0 143 101
assign 1 143 102
lesser 1 143 102
assign 1 0 104
assign 1 0 107
assign 1 0 111
assign 1 0 114
assign 1 143 117
new 0 143 117
assign 1 143 118
greater 1 143 118
assign 1 143 120
new 0 143 120
assign 1 143 121
lesser 1 143 121
assign 1 0 123
assign 1 0 126
assign 1 0 130
assign 1 0 133
assign 1 0 136
assign 1 0 140
assign 1 143 143
new 0 143 143
assign 1 143 144
greater 1 143 144
assign 1 143 146
new 0 143 146
assign 1 143 147
lesser 1 143 147
assign 1 0 149
assign 1 0 152
assign 1 0 156
assign 1 0 159
assign 1 0 162
assign 1 0 166
assign 1 143 169
new 0 143 169
assign 1 143 170
greater 1 143 170
assign 1 143 172
new 0 143 172
assign 1 143 173
lesser 1 143 173
assign 1 0 175
assign 1 0 178
assign 1 0 182
assign 1 0 185
assign 1 0 188
assign 1 0 192
assign 1 143 195
new 0 143 195
assign 1 143 196
equals 1 143 196
assign 1 0 198
assign 1 0 201
addValue 1 144 205
assign 1 145 208
new 0 145 208
assign 1 145 209
equals 1 145 209
assign 1 146 211
new 0 146 211
addValue 1 146 212
assign 1 148 215
new 0 148 215
addValue 1 148 216
assign 1 149 217
new 0 149 217
assign 1 149 218
getHex 1 149 218
addValue 1 150 219
assign 1 153 227
toString 0 153 227
return 1 153 228
assign 1 157 269
sizeGet 0 157 269
assign 1 157 270
new 1 157 270
assign 1 158 271
new 0 158 271
assign 1 164 272
new 0 164 272
assign 1 164 273
find 2 164 273
assign 1 165 274
new 0 165 274
assign 1 165 275
find 2 165 275
assign 1 166 276
undef 1 166 281
assign 1 0 282
assign 1 166 285
def 1 166 290
assign 1 166 291
lesser 1 166 291
assign 1 0 293
assign 1 0 296
assign 1 0 300
assign 1 0 303
assign 1 0 306
assign 1 167 310
new 0 167 310
assign 1 168 311
assign 1 170 314
new 0 170 314
assign 1 171 315
assign 1 174 317
sizeGet 0 174 317
assign 1 175 320
def 1 175 325
assign 1 176 326
greater 1 176 326
assign 1 177 328
substring 2 177 328
addValue 1 177 329
assign 1 178 330
assign 1 181 333
new 0 181 333
addValue 1 181 334
assign 1 182 335
new 0 182 335
assign 1 182 336
add 1 182 336
assign 1 184 339
new 0 184 339
assign 1 184 340
add 1 184 340
assign 1 184 341
lesser 1 184 341
assign 1 185 343
new 0 185 343
assign 1 185 344
add 1 185 344
assign 1 185 345
new 0 185 345
assign 1 185 346
add 1 185 346
assign 1 185 347
substring 2 185 347
assign 1 185 348
hexNew 1 185 348
addValue 1 185 349
assign 1 186 350
new 0 186 350
assign 1 186 351
add 1 186 351
assign 1 189 354
new 0 189 354
assign 1 189 355
find 2 189 355
assign 1 190 356
new 0 190 356
assign 1 190 357
find 2 190 357
assign 1 191 358
undef 1 191 363
assign 1 0 364
assign 1 191 367
def 1 191 372
assign 1 191 373
lesser 1 191 373
assign 1 0 375
assign 1 0 378
assign 1 0 382
assign 1 0 385
assign 1 0 388
assign 1 192 392
new 0 192 392
assign 1 193 393
assign 1 195 396
new 0 195 396
assign 1 196 397
assign 1 199 404
lesser 1 199 404
assign 1 200 406
substring 2 200 406
addValue 1 200 407
assign 1 202 409
toString 0 202 409
return 1 202 410
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1711217736: return bem_encode_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 570808864: return bem_decode_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_3_EncodeUrl();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_3_EncodeUrl.bevs_inst = (BEC_6_3_EncodeUrl)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_3_EncodeUrl.bevs_inst;
}
}
