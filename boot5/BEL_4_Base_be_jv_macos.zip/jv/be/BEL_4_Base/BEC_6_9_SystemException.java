package be.BEL_4_Base;
/* File: source/base/Exceptions.be */
public class BEC_6_9_SystemException extends BEC_6_6_SystemObject {
public BEC_6_9_SystemException() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bels_1 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_2 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_5 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bels_6 = {0x20,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_7 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bels_9 = {0x63,0x73};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_9, 2));
private static byte[] bels_10 = {0x6A,0x73};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_10, 2));
private static byte[] bels_11 = {0x0D,0x0A};
private static byte[] bels_12 = {0x63,0x73};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_12, 2));
private static byte[] bels_13 = {0x61,0x74,0x20};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_13, 3));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(0));
private static byte[] bels_14 = {0x20};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_14, 1));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_7 = (new BEC_4_3_MathInt(3));
private static byte[] bels_15 = {0x69,0x6E};
private static BEC_4_6_TextString bevo_8 = (new BEC_4_6_TextString(bels_15, 2));
private static BEC_4_3_MathInt bevo_9 = (new BEC_4_3_MathInt(3));
private static byte[] bels_16 = {0x20};
private static BEC_4_6_TextString bevo_10 = (new BEC_4_6_TextString(bels_16, 1));
private static BEC_4_3_MathInt bevo_11 = (new BEC_4_3_MathInt(1));
private static byte[] bels_17 = {0x3A};
private static BEC_4_3_MathInt bevo_12 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_13 = (new BEC_4_3_MathInt(1));
private static byte[] bels_18 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_4_6_TextString bevo_14 = (new BEC_4_6_TextString(bels_18, 5));
private static byte[] bels_19 = {0x28};
private static BEC_4_6_TextString bevo_15 = (new BEC_4_6_TextString(bels_19, 1));
private static byte[] bels_20 = {0x29};
private static BEC_4_6_TextString bevo_16 = (new BEC_4_6_TextString(bels_20, 1));
private static BEC_4_3_MathInt bevo_17 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_18 = (new BEC_4_3_MathInt(1));
private static byte[] bels_21 = {0x3A};
private static BEC_4_3_MathInt bevo_19 = (new BEC_4_3_MathInt(0));
private static byte[] bels_22 = {0x3A};
private static BEC_4_3_MathInt bevo_20 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_21 = (new BEC_4_3_MathInt(1));
private static byte[] bels_23 = {0x28};
private static BEC_4_6_TextString bevo_22 = (new BEC_4_6_TextString(bels_23, 1));
private static BEC_4_3_MathInt bevo_23 = (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_24 = (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_25 = (new BEC_4_3_MathInt(3));
private static byte[] bels_24 = {0x2E};
private static byte[] bels_25 = {0x2E};
private static BEC_4_3_MathInt bevo_26 = (new BEC_4_3_MathInt(1));
private static byte[] bels_26 = {0x42,0x45,0x4C,0x5F};
private static BEC_4_6_TextString bevo_27 = (new BEC_4_6_TextString(bels_26, 4));
private static BEC_4_3_MathInt bevo_28 = (new BEC_4_3_MathInt(0));
private static byte[] bels_27 = {0x5F};
private static BEC_4_6_TextString bevo_29 = (new BEC_4_6_TextString(bels_27, 1));
private static BEC_4_3_MathInt bevo_30 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_31 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_32 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_33 = (new BEC_4_3_MathInt(7));
private static byte[] bels_28 = {0x62,0x65};
private static byte[] bels_29 = {0x6A,0x76};
private static BEC_4_6_TextString bevo_34 = (new BEC_4_6_TextString(bels_29, 2));
private static byte[] bels_30 = {0x62,0x65};
private static byte[] bels_31 = {0x2E};
private static byte[] bels_32 = {0x42,0x45,0x43,0x5F};
private static BEC_4_6_TextString bevo_35 = (new BEC_4_6_TextString(bels_32, 4));
private static byte[] bels_33 = {0x5F};
private static BEC_4_3_MathInt bevo_36 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_37 = (new BEC_4_3_MathInt(1));
private static byte[] bels_34 = {0x3A};
private static byte[] bels_35 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_38 = (new BEC_4_6_TextString(bels_35, 4));
private static byte[] bels_36 = {0x5F};
private static BEC_4_3_MathInt bevo_39 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_40 = (new BEC_4_3_MathInt(1));
private static byte[] bels_37 = {0x5F};
private static byte[] bels_38 = {0x0A};
private static BEC_4_6_TextString bevo_41 = (new BEC_4_6_TextString(bels_38, 1));
public static BEC_6_9_SystemException bevs_inst;
public BEC_6_6_SystemObject bevp_methodName;
public BEC_6_6_SystemObject bevp_klassName;
public BEC_6_6_SystemObject bevp_description;
public BEC_6_6_SystemObject bevp_fileName;
public BEC_6_6_SystemObject bevp_lineNumber;
public BEC_4_6_TextString bevp_lang;
public BEC_4_6_TextString bevp_emitLang;
public BEC_9_10_ContainerLinkedList bevp_frames;
public BEC_4_6_TextString bevp_framesText;
public BEC_6_9_SystemException bem_new_1(BEC_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_6_6_SystemObject bevl_toRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (new BEC_4_6_TextString(11, bels_0));
if (bevp_lang == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 39 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(7, bels_1));
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevl_toRet = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_lang);
} /* Line: 40 */
if (bevp_emitLang == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 42 */ {
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(11, bels_2));
bevt_4_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_emitLang);
} /* Line: 43 */
if (bevp_methodName == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 45 */ {
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(9, bels_3));
bevt_7_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_8_tmpvar_phold);
bevl_toRet = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_methodName);
} /* Line: 46 */
if (bevp_klassName == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevt_11_tmpvar_phold = (new BEC_4_6_TextString(8, bels_4));
bevt_10_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_toRet = bevt_10_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_klassName);
} /* Line: 49 */
if (bevp_description == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(14, bels_5));
bevt_13_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevl_toRet = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_description);
} /* Line: 52 */
if (bevp_fileName == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(7, bels_6));
bevt_16_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_17_tmpvar_phold);
bevl_toRet = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_fileName);
} /* Line: 55 */
if (bevp_lineNumber == null) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(7, bels_7));
bevt_19_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = bevp_lineNumber.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toRet = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
} /* Line: 58 */
if (bevp_framesText == null) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_24_tmpvar_phold = (new BEC_4_6_TextString(14, bels_8));
bevt_23_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevl_toRet = bevt_23_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_framesText);
} /* Line: 61 */
if (bevp_frames == null) {
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 63 */ {
bevt_26_tmpvar_phold = this.bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 64 */
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_6_6_SystemObject bem_translateEmittedException_0() throws Throwable {
BEC_4_9_TextTokenizer bevl_ltok = null;
BEC_9_10_ContainerLinkedList bevl_lines = null;
BEC_5_4_LogicBool bevl_isCs = null;
BEC_4_6_TextString bevl_line = null;
BEC_4_3_MathInt bevl_start = null;
BEC_4_6_TextString bevl_efile = null;
BEC_4_3_MathInt bevl_eline = null;
BEC_4_3_MathInt bevl_end = null;
BEC_4_6_TextString bevl_callPart = null;
BEC_4_6_TextString bevl_inPart = null;
BEC_4_3_MathInt bevl_pdelim = null;
BEC_4_6_TextString bevl_iv = null;
BEC_9_10_ContainerLinkedList bevl_parts = null;
BEC_4_6_TextString bevl_klass = null;
BEC_4_6_TextString bevl_mtd = null;
BEC_4_6_TextString bevl_libLens = null;
BEC_4_3_MathInt bevl_libLen = null;
BEC_6_9_5_SystemExceptionFrame bevl_fr = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_4_3_MathInt bevt_68_tmpvar_phold = null;
BEC_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_89_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_95_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_105_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_106_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_4_6_TextString bevt_115_tmpvar_phold = null;
if (bevp_framesText == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 70 */ {
if (bevp_lang == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 70 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 70 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 70 */
 else  /* Line: 70 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 70 */ {
bevt_14_tmpvar_phold = bevo_0;
bevt_13_tmpvar_phold = bevp_lang.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 70 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 70 */ {
bevt_16_tmpvar_phold = bevo_1;
bevt_15_tmpvar_phold = bevp_lang.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 70 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 70 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 70 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 70 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 70 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 70 */
 else  /* Line: 70 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 70 */ {
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(2, bels_11));
bevl_ltok = (new BEC_4_9_TextTokenizer()).bem_new_1(bevt_17_tmpvar_phold);
bevl_lines = (BEC_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_19_tmpvar_phold = bevo_2;
bevt_18_tmpvar_phold = bevp_lang.bem_equals_1(bevt_19_tmpvar_phold);
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevl_isCs = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 74 */
 else  /* Line: 75 */ {
bevl_isCs = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 76 */
bevt_0_tmpvar_loop = bevl_lines.bem_iteratorGet_0();
while (true)
 /* Line: 78 */ {
bevt_20_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 78 */ {
bevl_line = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_21_tmpvar_phold = bevo_3;
bevl_start = bevl_line.bem_find_1(bevt_21_tmpvar_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 83 */ {
bevt_24_tmpvar_phold = bevo_4;
bevt_23_tmpvar_phold = bevl_start.bem_greaterEquals_1(bevt_24_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 83 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 83 */ {
bevt_25_tmpvar_phold = bevo_5;
bevt_27_tmpvar_phold = bevo_6;
bevt_26_tmpvar_phold = bevl_start.bem_add_1(bevt_27_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_25_tmpvar_phold, bevt_26_tmpvar_phold);
if (bevl_end == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 86 */ {
bevt_29_tmpvar_phold = bevl_end.bem_greater_1(bevl_start);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 86 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
 else  /* Line: 86 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 86 */ {
bevt_31_tmpvar_phold = bevo_7;
bevt_30_tmpvar_phold = bevl_start.bem_add_1(bevt_31_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_30_tmpvar_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 90 */ {
bevt_32_tmpvar_phold = bevo_8;
bevl_start = bevl_line.bem_find_2(bevt_32_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 92 */ {
bevt_35_tmpvar_phold = bevo_9;
bevt_34_tmpvar_phold = bevl_start.bem_add_1(bevt_35_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_34_tmpvar_phold);
bevt_37_tmpvar_phold = bevo_10;
bevt_36_tmpvar_phold = bevl_inPart.bem_ends_1(bevt_37_tmpvar_phold);
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 95 */ {
bevt_39_tmpvar_phold = bevl_inPart.bem_sizeGet_0();
bevt_40_tmpvar_phold = bevo_11;
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_subtract_1(bevt_40_tmpvar_phold);
bevl_inPart.bem_sizeSet_1(bevt_38_tmpvar_phold);
} /* Line: 96 */
bevt_41_tmpvar_phold = (new BEC_4_6_TextString(1, bels_17));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_41_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_42_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_42_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_43_tmpvar_phold = bevo_12;
bevl_efile = bevl_inPart.bem_substring_2(bevt_43_tmpvar_phold, bevl_pdelim);
bevt_45_tmpvar_phold = bevo_13;
bevt_44_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_45_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_44_tmpvar_phold);
bevt_47_tmpvar_phold = bevo_14;
bevt_46_tmpvar_phold = bevl_iv.bem_begins_1(bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_48_tmpvar_phold = (new BEC_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_48_tmpvar_phold);
} /* Line: 105 */
bevt_49_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_49_tmpvar_phold.bevi_bool) /* Line: 108 */ {
bevl_eline = (new BEC_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 109 */
} /* Line: 108 */
} /* Line: 100 */
} /* Line: 92 */
 else  /* Line: 113 */ {
bevt_50_tmpvar_phold = bevo_15;
bevl_start = bevl_line.bem_find_2(bevt_50_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevt_52_tmpvar_phold = bevo_16;
bevt_54_tmpvar_phold = bevo_17;
bevt_53_tmpvar_phold = bevl_start.bem_add_1(bevt_54_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_52_tmpvar_phold, bevt_53_tmpvar_phold);
if (bevl_end == null) {
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_55_tmpvar_phold.bevi_bool) /* Line: 119 */ {
bevt_57_tmpvar_phold = bevo_18;
bevt_56_tmpvar_phold = bevl_start.bem_add_1(bevt_57_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_56_tmpvar_phold, bevl_end);
bevt_58_tmpvar_phold = (new BEC_4_6_TextString(1, bels_21));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_58_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_59_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_60_tmpvar_phold = bevo_19;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_60_tmpvar_phold, bevl_pdelim);
bevt_61_tmpvar_phold = (new BEC_4_6_TextString(1, bels_22));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_61_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 128 */ {
bevt_63_tmpvar_phold = bevo_20;
bevl_efile = bevl_inPart.bem_substring_2(bevt_63_tmpvar_phold, bevl_pdelim);
} /* Line: 129 */
bevt_65_tmpvar_phold = bevo_21;
bevt_64_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_65_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_64_tmpvar_phold);
bevt_66_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 133 */ {
bevl_eline = (new BEC_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 134 */
} /* Line: 133 */
} /* Line: 124 */
} /* Line: 119 */
} /* Line: 115 */
} /* Line: 90 */
 else  /* Line: 140 */ {
bevt_67_tmpvar_phold = bevo_22;
bevt_69_tmpvar_phold = bevo_23;
bevt_68_tmpvar_phold = bevl_start.bem_add_1(bevt_69_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_67_tmpvar_phold, bevt_68_tmpvar_phold);
if (bevl_end == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 142 */ {
bevt_71_tmpvar_phold = bevl_end.bem_greater_1(bevl_start);
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 142 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 142 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 142 */
 else  /* Line: 142 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 142 */ {
bevt_73_tmpvar_phold = bevo_24;
bevt_72_tmpvar_phold = bevl_start.bem_add_1(bevt_73_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_72_tmpvar_phold, bevl_end);
} /* Line: 143 */
 else  /* Line: 144 */ {
bevt_75_tmpvar_phold = bevo_25;
bevt_74_tmpvar_phold = bevl_start.bem_add_1(bevt_75_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_74_tmpvar_phold);
} /* Line: 145 */
} /* Line: 142 */
if (bevl_callPart == null) {
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 148 */ {
if (bevl_isCs.bevi_bool) /* Line: 149 */ {
bevt_77_tmpvar_phold = (new BEC_4_6_TextString(1, bels_24));
bevl_parts = (BEC_9_10_ContainerLinkedList) bevl_callPart.bem_split_1(bevt_77_tmpvar_phold);
bevt_78_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevl_klass = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_78_tmpvar_phold);
bevt_79_tmpvar_phold = (new BEC_4_3_MathInt(3));
bevl_mtd = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_79_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevl_fr = (new BEC_6_9_5_SystemExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_81_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_80_tmpvar_phold = this.bem_getSourceFileName_1(bevt_81_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_80_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 162 */
 else  /* Line: 163 */ {
bevt_82_tmpvar_phold = (new BEC_4_6_TextString(1, bels_25));
bevl_parts = (BEC_9_10_ContainerLinkedList) bevl_callPart.bem_split_1(bevt_82_tmpvar_phold);
bevt_84_tmpvar_phold = bevl_parts.bem_sizeGet_0();
bevt_85_tmpvar_phold = bevo_26;
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_greater_1(bevt_85_tmpvar_phold);
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 167 */ {
bevt_86_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevl_mtd = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_86_tmpvar_phold);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevt_87_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevl_klass = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = bevo_27;
bevl_start = bevl_klass.bem_find_1(bevt_88_tmpvar_phold);
if (bevl_start == null) {
bevt_89_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpvar_phold.bevi_bool) /* Line: 173 */ {
bevt_91_tmpvar_phold = bevo_28;
bevt_90_tmpvar_phold = bevl_start.bem_greater_1(bevt_91_tmpvar_phold);
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 173 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 173 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 173 */
 else  /* Line: 173 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 173 */ {
bevt_92_tmpvar_phold = bevo_29;
bevt_94_tmpvar_phold = bevo_30;
bevt_93_tmpvar_phold = bevl_start.bem_add_1(bevt_94_tmpvar_phold);
bevl_end = bevl_klass.bem_find_2(bevt_92_tmpvar_phold, bevt_93_tmpvar_phold);
if (bevl_end == null) {
bevt_95_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_95_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_95_tmpvar_phold.bevi_bool) /* Line: 175 */ {
bevt_97_tmpvar_phold = bevo_31;
bevt_96_tmpvar_phold = bevl_end.bem_greater_1(bevt_97_tmpvar_phold);
if (bevt_96_tmpvar_phold.bevi_bool) /* Line: 175 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 175 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 175 */
 else  /* Line: 175 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 175 */ {
bevt_99_tmpvar_phold = bevo_32;
bevt_98_tmpvar_phold = bevl_start.bem_add_1(bevt_99_tmpvar_phold);
bevl_libLens = bevl_klass.bem_substring_2(bevt_98_tmpvar_phold, bevl_end);
bevl_libLen = (new BEC_4_3_MathInt()).bem_new_1(bevl_libLens);
bevt_102_tmpvar_phold = bevo_33;
bevt_101_tmpvar_phold = bevl_start.bem_add_1(bevt_102_tmpvar_phold);
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_add_1(bevl_libLen);
bevl_klass = bevl_klass.bem_substring_1(bevt_100_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_fr = (new BEC_6_9_5_SystemExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_104_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_103_tmpvar_phold = this.bem_getSourceFileName_1(bevt_104_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_103_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 185 */
} /* Line: 175 */
} /* Line: 173 */
} /* Line: 167 */
} /* Line: 149 */
} /* Line: 148 */
} /* Line: 83 */
 else  /* Line: 78 */ {
break;
} /* Line: 78 */
} /* Line: 78 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_4_6_TextString(2, bels_28));
bevp_framesText = null;
} /* Line: 195 */
 else  /* Line: 70 */ {
if (bevp_frames == null) {
bevt_105_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_105_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_105_tmpvar_phold.bevi_bool) /* Line: 196 */ {
if (bevp_lang == null) {
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_106_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 196 */
 else  /* Line: 196 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 196 */ {
bevt_108_tmpvar_phold = bevo_34;
bevt_107_tmpvar_phold = bevp_lang.bem_equals_1(bevt_108_tmpvar_phold);
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 196 */
 else  /* Line: 196 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 196 */ {
bevt_1_tmpvar_loop = bevp_frames.bem_iteratorGet_0();
while (true)
 /* Line: 197 */ {
bevt_109_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_109_tmpvar_phold != null && bevt_109_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_109_tmpvar_phold).bevi_bool) /* Line: 197 */ {
bevl_fr = (BEC_6_9_5_SystemExceptionFrame) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_111_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_110_tmpvar_phold = this.bem_extractKlassLib_1(bevt_111_tmpvar_phold);
bevl_fr.bem_klassNameSet_1(bevt_110_tmpvar_phold);
bevt_113_tmpvar_phold = bevl_fr.bem_methodNameGet_0();
bevt_112_tmpvar_phold = this.bem_extractMethod_1(bevt_113_tmpvar_phold);
bevl_fr.bem_methodNameSet_1(bevt_112_tmpvar_phold);
bevt_115_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_114_tmpvar_phold = this.bem_getSourceFileName_1(bevt_115_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_114_tmpvar_phold);
} /* Line: 200 */
 else  /* Line: 197 */ {
break;
} /* Line: 197 */
} /* Line: 197 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_4_6_TextString(2, bels_30));
} /* Line: 203 */
} /* Line: 70 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_getSourceFileName_1(BEC_4_6_TextString beva_klassName) throws Throwable {
BEC_6_6_SystemObject bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = this.bem_createInstance_2(beva_klassName, bevt_0_tmpvar_phold);
if (bevl_i == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_2_tmpvar_phold = bevl_i.bemd_0(478622533, BEL_4_Base.bevn_sourceFileNameGet_0);
return (BEC_4_6_TextString) bevt_2_tmpvar_phold;
} /* Line: 212 */
return null;
} /*method end*/
public BEC_4_6_TextString bem_extractKlassLib_1(BEC_4_6_TextString beva_callPart) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_parts = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(1, bels_31));
bevl_parts = (BEC_9_10_ContainerLinkedList) beva_callPart.bem_split_1(bevt_0_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevt_2_tmpvar_phold = bevl_parts.bem_get_1(bevt_3_tmpvar_phold);
bevt_1_tmpvar_phold = this.bem_extractKlass_1((BEC_4_6_TextString) bevt_2_tmpvar_phold);
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_extractKlass_1(BEC_4_6_TextString beva_klass) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_kparts = null;
BEC_4_3_MathInt bevl_kps = null;
BEC_4_6_TextString bevl_rawkl = null;
BEC_4_6_TextString bevl_bec = null;
BEC_4_3_MathInt bevl_sofar = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_len = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
if (beva_klass == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 225 */ {
bevt_4_tmpvar_phold = bevo_35;
bevt_3_tmpvar_phold = beva_klass.bem_begins_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 225 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 225 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 225 */ {
return beva_klass;
} /* Line: 226 */
bevt_6_tmpvar_phold = (new BEC_4_3_MathInt(4));
bevt_5_tmpvar_phold = beva_klass.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_4_6_TextString(1, bels_33));
bevl_kparts = (BEC_9_10_ContainerLinkedList) bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_36;
bevl_kps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_rawkl = (BEC_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (new BEC_4_6_TextString()).bem_new_0();
bevl_sofar = (new BEC_4_3_MathInt(0));
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 233 */ {
bevt_10_tmpvar_phold = bevl_i.bem_lesser_1(bevl_kps);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 233 */ {
bevt_11_tmpvar_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (new BEC_4_3_MathInt()).bem_new_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpvar_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpvar_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_16_tmpvar_phold = bevo_37;
bevt_15_tmpvar_phold = bevl_i.bem_add_1(bevt_16_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_lesser_1(bevl_kps);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 237 */ {
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(1, bels_34));
bevl_bec.bem_addValue_1(bevt_17_tmpvar_phold);
} /* Line: 237 */
bevl_sofar.bem_addValue_1(bevl_len);
bevl_i.bem_incrementValue_0();
} /* Line: 233 */
 else  /* Line: 233 */ {
break;
} /* Line: 233 */
} /* Line: 233 */
return bevl_bec;
} /*method end*/
public BEC_4_6_TextString bem_extractMethod_1(BEC_4_6_TextString beva_mtd) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_mparts = null;
BEC_4_3_MathInt bevl_mps = null;
BEC_4_6_TextString bevl_bem = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
if (beva_mtd == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_4_tmpvar_phold = bevo_38;
bevt_3_tmpvar_phold = beva_mtd.bem_begins_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 245 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 245 */ {
return beva_mtd;
} /* Line: 246 */
bevt_6_tmpvar_phold = (new BEC_4_3_MathInt(4));
bevt_5_tmpvar_phold = beva_mtd.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_4_6_TextString(1, bels_36));
bevl_mparts = (BEC_9_10_ContainerLinkedList) bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_39;
bevl_mps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_bem = (new BEC_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 251 */ {
bevt_10_tmpvar_phold = bevl_i.bem_lesser_1(bevl_mps);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 251 */ {
bevt_11_tmpvar_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_40;
bevt_13_tmpvar_phold = bevl_i.bem_add_1(bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_lesser_1(bevl_mps);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 253 */ {
bevt_15_tmpvar_phold = (new BEC_4_6_TextString(1, bels_37));
bevl_bem.bem_addValue_1(bevt_15_tmpvar_phold);
} /* Line: 253 */
bevl_i.bem_incrementValue_0();
} /* Line: 251 */
 else  /* Line: 251 */ {
break;
} /* Line: 251 */
} /* Line: 251 */
return bevl_bem;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_framesGet_0() throws Throwable {
return bevp_frames;
} /*method end*/
public BEC_4_6_TextString bem_getFrameText_0() throws Throwable {
BEC_4_6_TextString bevl_toRet = null;
BEC_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_6_6_SystemObject bevl_ft = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_toRet = (new BEC_4_6_TextString()).bem_new_0();
bevl_myFrames = this.bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevt_2_tmpvar_phold = bevo_41;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_loop = bevl_myFrames.bem_iteratorGet_0();
while (true)
 /* Line: 270 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 270 */ {
bevl_ft = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 271 */
 else  /* Line: 270 */ {
break;
} /* Line: 270 */
} /* Line: 270 */
} /* Line: 270 */
return bevl_toRet;
} /*method end*/
public BEC_4_6_TextString bem_klassNameGet_0() throws Throwable {
return (BEC_4_6_TextString) bevp_klassName;
} /*method end*/
public BEC_6_6_SystemObject bem_addFrame_1(BEC_6_9_5_SystemExceptionFrame beva_frame) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_frames == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 282 */ {
bevp_frames = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 283 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addFrame_4(BEC_4_6_TextString beva__klassName, BEC_4_6_TextString beva__methodName, BEC_4_6_TextString beva__fileName, BEC_4_3_MathInt beva__line) throws Throwable {
BEC_6_9_5_SystemExceptionFrame bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_6_9_5_SystemExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
this.bem_addFrame_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_6_6_SystemObject bem_methodNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_methodName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_klassNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_klassName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_descriptionGet_0() throws Throwable {
return bevp_description;
} /*method end*/
public BEC_6_6_SystemObject bem_descriptionSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_description = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_6_6_SystemObject bem_fileNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fileName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_lineNumberGet_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public BEC_6_6_SystemObject bem_lineNumberSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lineNumber = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_langGet_0() throws Throwable {
return bevp_lang;
} /*method end*/
public BEC_6_6_SystemObject bem_langSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lang = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_emitLangGet_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLangSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLang = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_framesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_frames = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_framesTextGet_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public BEC_6_6_SystemObject bem_framesTextSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_framesText = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {32, 36, 38, 39, 39, 40, 40, 40, 42, 42, 43, 43, 43, 45, 45, 46, 46, 46, 48, 48, 49, 49, 49, 51, 51, 52, 52, 52, 54, 54, 55, 55, 55, 57, 57, 58, 58, 58, 58, 60, 60, 61, 61, 61, 63, 63, 64, 64, 66, 70, 70, 70, 70, 0, 0, 0, 70, 70, 0, 70, 70, 0, 0, 0, 0, 0, 71, 71, 72, 73, 73, 74, 76, 78, 0, 78, 78, 80, 80, 81, 82, 83, 83, 83, 83, 0, 0, 0, 85, 85, 85, 85, 86, 86, 86, 0, 0, 0, 88, 88, 88, 91, 91, 92, 92, 94, 94, 94, 95, 95, 96, 96, 96, 96, 99, 99, 100, 100, 101, 101, 103, 103, 103, 104, 104, 105, 105, 108, 109, 114, 114, 115, 115, 118, 118, 118, 118, 119, 119, 121, 121, 121, 123, 123, 124, 124, 125, 125, 127, 127, 128, 128, 129, 129, 131, 131, 131, 133, 134, 141, 141, 141, 141, 142, 142, 142, 0, 0, 0, 143, 143, 143, 145, 145, 145, 148, 148, 151, 151, 153, 153, 154, 154, 156, 158, 160, 161, 161, 161, 162, 166, 166, 167, 167, 167, 168, 168, 169, 171, 171, 172, 172, 173, 173, 173, 173, 0, 0, 0, 174, 174, 174, 174, 175, 175, 175, 175, 0, 0, 0, 176, 176, 176, 178, 179, 179, 179, 179, 181, 183, 184, 184, 184, 185, 193, 194, 195, 196, 196, 196, 196, 0, 0, 0, 196, 196, 0, 0, 0, 197, 0, 197, 197, 198, 198, 198, 199, 199, 199, 200, 200, 200, 202, 203, 209, 209, 210, 210, 212, 212, 215, 219, 219, 221, 221, 221, 221, 225, 225, 0, 225, 225, 225, 0, 0, 226, 228, 228, 228, 228, 229, 229, 229, 230, 231, 232, 233, 233, 234, 234, 236, 236, 236, 237, 237, 237, 237, 237, 238, 233, 241, 245, 245, 0, 245, 245, 245, 0, 0, 246, 248, 248, 248, 248, 249, 249, 249, 250, 251, 251, 252, 252, 253, 253, 253, 253, 253, 251, 256, 262, 266, 267, 268, 268, 269, 269, 270, 0, 270, 270, 271, 274, 278, 282, 282, 283, 285, 289, 289, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {99, 131, 132, 133, 138, 139, 140, 141, 143, 148, 149, 150, 151, 153, 158, 159, 160, 161, 163, 168, 169, 170, 171, 173, 178, 179, 180, 181, 183, 188, 189, 190, 191, 193, 198, 199, 200, 201, 202, 204, 209, 210, 211, 212, 214, 219, 220, 221, 223, 360, 365, 366, 371, 372, 375, 379, 382, 383, 385, 388, 389, 391, 394, 398, 401, 405, 408, 409, 410, 411, 412, 414, 417, 419, 419, 422, 424, 425, 426, 427, 428, 429, 434, 435, 436, 438, 441, 445, 448, 449, 450, 451, 452, 457, 458, 460, 463, 467, 470, 471, 472, 474, 475, 476, 481, 482, 483, 484, 485, 486, 488, 489, 490, 491, 493, 494, 495, 500, 501, 502, 503, 504, 505, 506, 507, 509, 510, 512, 514, 520, 521, 522, 527, 528, 529, 530, 531, 532, 537, 538, 539, 540, 541, 542, 543, 548, 549, 550, 551, 552, 553, 558, 559, 560, 562, 563, 564, 565, 567, 575, 576, 577, 578, 579, 584, 585, 587, 590, 594, 597, 598, 599, 602, 603, 604, 607, 612, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 629, 630, 631, 632, 633, 635, 636, 637, 638, 639, 640, 641, 642, 647, 648, 649, 651, 654, 658, 661, 662, 663, 664, 665, 670, 671, 672, 674, 677, 681, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 709, 710, 711, 714, 719, 720, 725, 726, 729, 733, 736, 737, 739, 742, 746, 749, 749, 752, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 769, 770, 780, 781, 782, 787, 788, 789, 791, 799, 800, 801, 802, 803, 804, 832, 837, 838, 841, 842, 843, 845, 848, 852, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 867, 869, 870, 871, 872, 873, 874, 875, 876, 878, 879, 881, 882, 888, 911, 916, 917, 920, 921, 922, 924, 927, 931, 933, 934, 935, 936, 937, 938, 939, 940, 941, 944, 946, 947, 948, 949, 950, 952, 953, 955, 961, 964, 974, 975, 976, 981, 982, 983, 984, 984, 987, 989, 990, 997, 1000, 1004, 1009, 1010, 1012, 1017, 1018, 1022, 1025, 1029, 1033, 1036, 1040, 1043, 1047, 1050, 1054, 1057, 1061, 1064, 1068, 1072, 1075};
/* BEGIN LINEINFO 
assign 1 32 99
translateEmittedException 0 36 131
assign 1 38 132
new 0 38 132
assign 1 39 133
def 1 39 138
assign 1 40 139
new 0 40 139
assign 1 40 140
add 1 40 140
assign 1 40 141
add 1 40 141
assign 1 42 143
def 1 42 148
assign 1 43 149
new 0 43 149
assign 1 43 150
add 1 43 150
assign 1 43 151
add 1 43 151
assign 1 45 153
def 1 45 158
assign 1 46 159
new 0 46 159
assign 1 46 160
add 1 46 160
assign 1 46 161
add 1 46 161
assign 1 48 163
def 1 48 168
assign 1 49 169
new 0 49 169
assign 1 49 170
add 1 49 170
assign 1 49 171
add 1 49 171
assign 1 51 173
def 1 51 178
assign 1 52 179
new 0 52 179
assign 1 52 180
add 1 52 180
assign 1 52 181
add 1 52 181
assign 1 54 183
def 1 54 188
assign 1 55 189
new 0 55 189
assign 1 55 190
add 1 55 190
assign 1 55 191
add 1 55 191
assign 1 57 193
def 1 57 198
assign 1 58 199
new 0 58 199
assign 1 58 200
add 1 58 200
assign 1 58 201
toString 0 58 201
assign 1 58 202
add 1 58 202
assign 1 60 204
def 1 60 209
assign 1 61 210
new 0 61 210
assign 1 61 211
add 1 61 211
assign 1 61 212
add 1 61 212
assign 1 63 214
def 1 63 219
assign 1 64 220
getFrameText 0 64 220
assign 1 64 221
add 1 64 221
return 1 66 223
assign 1 70 360
def 1 70 365
assign 1 70 366
def 1 70 371
assign 1 0 372
assign 1 0 375
assign 1 0 379
assign 1 70 382
new 0 70 382
assign 1 70 383
equals 1 70 383
assign 1 0 385
assign 1 70 388
new 0 70 388
assign 1 70 389
equals 1 70 389
assign 1 0 391
assign 1 0 394
assign 1 0 398
assign 1 0 401
assign 1 0 405
assign 1 71 408
new 0 71 408
assign 1 71 409
new 1 71 409
assign 1 72 410
tokenize 1 72 410
assign 1 73 411
new 0 73 411
assign 1 73 412
equals 1 73 412
assign 1 74 414
new 0 74 414
assign 1 76 417
new 0 76 417
assign 1 78 419
iteratorGet 0 0 419
assign 1 78 422
hasNextGet 0 78 422
assign 1 78 424
nextGet 0 78 424
assign 1 80 425
new 0 80 425
assign 1 80 426
find 1 80 426
assign 1 81 427
assign 1 82 428
assign 1 83 429
def 1 83 434
assign 1 83 435
new 0 83 435
assign 1 83 436
greaterEquals 1 83 436
assign 1 0 438
assign 1 0 441
assign 1 0 445
assign 1 85 448
new 0 85 448
assign 1 85 449
new 0 85 449
assign 1 85 450
add 1 85 450
assign 1 85 451
find 2 85 451
assign 1 86 452
def 1 86 457
assign 1 86 458
greater 1 86 458
assign 1 0 460
assign 1 0 463
assign 1 0 467
assign 1 88 470
new 0 88 470
assign 1 88 471
add 1 88 471
assign 1 88 472
substring 2 88 472
assign 1 91 474
new 0 91 474
assign 1 91 475
find 2 91 475
assign 1 92 476
def 1 92 481
assign 1 94 482
new 0 94 482
assign 1 94 483
add 1 94 483
assign 1 94 484
substring 1 94 484
assign 1 95 485
new 0 95 485
assign 1 95 486
ends 1 95 486
assign 1 96 488
sizeGet 0 96 488
assign 1 96 489
new 0 96 489
assign 1 96 490
subtract 1 96 490
sizeSet 1 96 491
assign 1 99 493
new 0 99 493
assign 1 99 494
rfind 1 99 494
assign 1 100 495
def 1 100 500
assign 1 101 501
new 0 101 501
assign 1 101 502
substring 2 101 502
assign 1 103 503
new 0 103 503
assign 1 103 504
add 1 103 504
assign 1 103 505
substring 1 103 505
assign 1 104 506
new 0 104 506
assign 1 104 507
begins 1 104 507
assign 1 105 509
new 0 105 509
assign 1 105 510
substring 1 105 510
assign 1 108 512
isInteger 0 108 512
assign 1 109 514
new 1 109 514
assign 1 114 520
new 0 114 520
assign 1 114 521
find 2 114 521
assign 1 115 522
def 1 115 527
assign 1 118 528
new 0 118 528
assign 1 118 529
new 0 118 529
assign 1 118 530
add 1 118 530
assign 1 118 531
find 2 118 531
assign 1 119 532
def 1 119 537
assign 1 121 538
new 0 121 538
assign 1 121 539
add 1 121 539
assign 1 121 540
substring 2 121 540
assign 1 123 541
new 0 123 541
assign 1 123 542
rfind 1 123 542
assign 1 124 543
def 1 124 548
assign 1 125 549
new 0 125 549
assign 1 125 550
substring 2 125 550
assign 1 127 551
new 0 127 551
assign 1 127 552
rfind 1 127 552
assign 1 128 553
def 1 128 558
assign 1 129 559
new 0 129 559
assign 1 129 560
substring 2 129 560
assign 1 131 562
new 0 131 562
assign 1 131 563
add 1 131 563
assign 1 131 564
substring 1 131 564
assign 1 133 565
isInteger 0 133 565
assign 1 134 567
new 1 134 567
assign 1 141 575
new 0 141 575
assign 1 141 576
new 0 141 576
assign 1 141 577
add 1 141 577
assign 1 141 578
find 2 141 578
assign 1 142 579
def 1 142 584
assign 1 142 585
greater 1 142 585
assign 1 0 587
assign 1 0 590
assign 1 0 594
assign 1 143 597
new 0 143 597
assign 1 143 598
add 1 143 598
assign 1 143 599
substring 2 143 599
assign 1 145 602
new 0 145 602
assign 1 145 603
add 1 145 603
assign 1 145 604
substring 1 145 604
assign 1 148 607
def 1 148 612
assign 1 151 614
new 0 151 614
assign 1 151 615
split 1 151 615
assign 1 153 616
new 0 153 616
assign 1 153 617
get 1 153 617
assign 1 154 618
new 0 154 618
assign 1 154 619
get 1 154 619
assign 1 156 620
extractKlass 1 156 620
assign 1 158 621
extractMethod 1 158 621
assign 1 160 622
new 4 160 622
assign 1 161 623
klassNameGet 0 161 623
assign 1 161 624
getSourceFileName 1 161 624
fileNameSet 1 161 625
addFrame 1 162 626
assign 1 166 629
new 0 166 629
assign 1 166 630
split 1 166 630
assign 1 167 631
sizeGet 0 167 631
assign 1 167 632
new 0 167 632
assign 1 167 633
greater 1 167 633
assign 1 168 635
new 0 168 635
assign 1 168 636
get 1 168 636
assign 1 169 637
extractMethod 1 169 637
assign 1 171 638
new 0 171 638
assign 1 171 639
get 1 171 639
assign 1 172 640
new 0 172 640
assign 1 172 641
find 1 172 641
assign 1 173 642
def 1 173 647
assign 1 173 648
new 0 173 648
assign 1 173 649
greater 1 173 649
assign 1 0 651
assign 1 0 654
assign 1 0 658
assign 1 174 661
new 0 174 661
assign 1 174 662
new 0 174 662
assign 1 174 663
add 1 174 663
assign 1 174 664
find 2 174 664
assign 1 175 665
def 1 175 670
assign 1 175 671
new 0 175 671
assign 1 175 672
greater 1 175 672
assign 1 0 674
assign 1 0 677
assign 1 0 681
assign 1 176 684
new 0 176 684
assign 1 176 685
add 1 176 685
assign 1 176 686
substring 2 176 686
assign 1 178 687
new 1 178 687
assign 1 179 688
new 0 179 688
assign 1 179 689
add 1 179 689
assign 1 179 690
add 1 179 690
assign 1 179 691
substring 1 179 691
assign 1 181 692
extractKlass 1 181 692
assign 1 183 693
new 4 183 693
assign 1 184 694
klassNameGet 0 184 694
assign 1 184 695
getSourceFileName 1 184 695
fileNameSet 1 184 696
addFrame 1 185 697
assign 1 193 709
assign 1 194 710
new 0 194 710
assign 1 195 711
assign 1 196 714
def 1 196 719
assign 1 196 720
def 1 196 725
assign 1 0 726
assign 1 0 729
assign 1 0 733
assign 1 196 736
new 0 196 736
assign 1 196 737
equals 1 196 737
assign 1 0 739
assign 1 0 742
assign 1 0 746
assign 1 197 749
iteratorGet 0 0 749
assign 1 197 752
hasNextGet 0 197 752
assign 1 197 754
nextGet 0 197 754
assign 1 198 755
klassNameGet 0 198 755
assign 1 198 756
extractKlassLib 1 198 756
klassNameSet 1 198 757
assign 1 199 758
methodNameGet 0 199 758
assign 1 199 759
extractMethod 1 199 759
methodNameSet 1 199 760
assign 1 200 761
klassNameGet 0 200 761
assign 1 200 762
getSourceFileName 1 200 762
fileNameSet 1 200 763
assign 1 202 769
assign 1 203 770
new 0 203 770
assign 1 209 780
new 0 209 780
assign 1 209 781
createInstance 2 209 781
assign 1 210 782
def 1 210 787
assign 1 212 788
sourceFileNameGet 0 212 788
return 1 212 789
return 1 215 791
assign 1 219 799
new 0 219 799
assign 1 219 800
split 1 219 800
assign 1 221 801
new 0 221 801
assign 1 221 802
get 1 221 802
assign 1 221 803
extractKlass 1 221 803
return 1 221 804
assign 1 225 832
undef 1 225 837
assign 1 0 838
assign 1 225 841
new 0 225 841
assign 1 225 842
begins 1 225 842
assign 1 225 843
not 0 225 843
assign 1 0 845
assign 1 0 848
return 1 226 852
assign 1 228 854
new 0 228 854
assign 1 228 855
substring 1 228 855
assign 1 228 856
new 0 228 856
assign 1 228 857
split 1 228 857
assign 1 229 858
sizeGet 0 229 858
assign 1 229 859
new 0 229 859
assign 1 229 860
subtract 1 229 860
assign 1 230 861
get 1 230 861
assign 1 231 862
new 0 231 862
assign 1 232 863
new 0 232 863
assign 1 233 864
new 0 233 864
assign 1 233 867
lesser 1 233 867
assign 1 234 869
get 1 234 869
assign 1 234 870
new 1 234 870
assign 1 236 871
add 1 236 871
assign 1 236 872
substring 2 236 872
addValue 1 236 873
assign 1 237 874
new 0 237 874
assign 1 237 875
add 1 237 875
assign 1 237 876
lesser 1 237 876
assign 1 237 878
new 0 237 878
addValue 1 237 879
addValue 1 238 881
incrementValue 0 233 882
return 1 241 888
assign 1 245 911
undef 1 245 916
assign 1 0 917
assign 1 245 920
new 0 245 920
assign 1 245 921
begins 1 245 921
assign 1 245 922
not 0 245 922
assign 1 0 924
assign 1 0 927
return 1 246 931
assign 1 248 933
new 0 248 933
assign 1 248 934
substring 1 248 934
assign 1 248 935
new 0 248 935
assign 1 248 936
split 1 248 936
assign 1 249 937
sizeGet 0 249 937
assign 1 249 938
new 0 249 938
assign 1 249 939
subtract 1 249 939
assign 1 250 940
new 0 250 940
assign 1 251 941
new 0 251 941
assign 1 251 944
lesser 1 251 944
assign 1 252 946
get 1 252 946
addValue 1 252 947
assign 1 253 948
new 0 253 948
assign 1 253 949
add 1 253 949
assign 1 253 950
lesser 1 253 950
assign 1 253 952
new 0 253 952
addValue 1 253 953
incrementValue 0 251 955
return 1 256 961
return 1 262 964
assign 1 266 974
new 0 266 974
assign 1 267 975
framesGet 0 267 975
assign 1 268 976
def 1 268 981
assign 1 269 982
new 0 269 982
assign 1 269 983
add 1 269 983
assign 1 270 984
iteratorGet 0 0 984
assign 1 270 987
hasNextGet 0 270 987
assign 1 270 989
nextGet 0 270 989
assign 1 271 990
add 1 271 990
return 1 274 997
return 1 278 1000
assign 1 282 1004
undef 1 282 1009
assign 1 283 1010
new 0 283 1010
addValue 1 285 1012
assign 1 289 1017
new 4 289 1017
addFrame 1 289 1018
return 1 0 1022
assign 1 0 1025
assign 1 0 1029
return 1 0 1033
assign 1 0 1036
return 1 0 1040
assign 1 0 1043
return 1 0 1047
assign 1 0 1050
return 1 0 1054
assign 1 0 1057
return 1 0 1061
assign 1 0 1064
assign 1 0 1068
return 1 0 1072
assign 1 0 1075
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1353219100: return bem_klassNameGet_0();
case 1774940957: return bem_toString_0();
case 1354714650: return bem_copy_0();
case 734830721: return bem_framesGet_0();
case 1475977273: return bem_langGet_0();
case 1308786538: return bem_echo_0();
case 1307921883: return bem_methodNameGet_0();
case 764669899: return bem_getFrameText_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 484558571: return bem_descriptionGet_0();
case 1611190486: return bem_lineNumberGet_0();
case 556476320: return bem_fileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case 154290862: return bem_translateEmittedException_0();
case 1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 845792839: return bem_iteratorGet_0();
case 1141730732: return bem_framesTextGet_0();
case 314718434: return bem_print_0();
case 220901978: return bem_emitLangGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1286797640: return bem_extractKlassLib_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1600108233: return bem_lineNumberSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 495640824: return bem_descriptionSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 567558573: return bem_fileNameSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1364301353: return bem_klassNameSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 745912974: return bem_framesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1487059526: return bem_langSet_1(bevd_0);
case 813541388: return bem_extractMethod_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 205231606: return bem_getSourceFileName_1((BEC_4_6_TextString) bevd_0);
case 1319004136: return bem_methodNameSet_1(bevd_0);
case 1300981246: return bem_addFrame_1((BEC_6_9_5_SystemExceptionFrame) bevd_0);
case 371136143: return bem_extractKlass_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1130648479: return bem_framesTextSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1300981249: return bem_addFrame_4((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_9_SystemException();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_9_SystemException.bevs_inst = (BEC_6_9_SystemException)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_9_SystemException.bevs_inst;
}
}
