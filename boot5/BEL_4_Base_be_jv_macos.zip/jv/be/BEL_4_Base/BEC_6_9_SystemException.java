package be.BEL_4_Base;
/* File: source/base/Exceptions.be */
public class BEC_6_9_SystemException extends BEC_6_6_SystemObject {
public BEC_6_9_SystemException() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bels_1 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_2 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_5 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bels_6 = {0x20,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_7 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bels_9 = {0x63,0x73};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_9, 2));
private static byte[] bels_10 = {0x6A,0x73};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_10, 2));
private static byte[] bels_11 = {0x0D,0x0A};
private static byte[] bels_12 = {0x63,0x73};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_12, 2));
private static byte[] bels_13 = {0x61,0x74,0x20};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_13, 3));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(0));
private static byte[] bels_14 = {0x20};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_14, 1));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_7 = (new BEC_4_3_MathInt(3));
private static byte[] bels_15 = {0x69,0x6E};
private static BEC_4_6_TextString bevo_8 = (new BEC_4_6_TextString(bels_15, 2));
private static BEC_4_3_MathInt bevo_9 = (new BEC_4_3_MathInt(3));
private static byte[] bels_16 = {0x20};
private static BEC_4_6_TextString bevo_10 = (new BEC_4_6_TextString(bels_16, 1));
private static BEC_4_3_MathInt bevo_11 = (new BEC_4_3_MathInt(1));
private static byte[] bels_17 = {0x3A};
private static BEC_4_3_MathInt bevo_12 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_13 = (new BEC_4_3_MathInt(1));
private static byte[] bels_18 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_4_6_TextString bevo_14 = (new BEC_4_6_TextString(bels_18, 5));
private static byte[] bels_19 = {0x28};
private static BEC_4_6_TextString bevo_15 = (new BEC_4_6_TextString(bels_19, 1));
private static byte[] bels_20 = {0x29};
private static BEC_4_6_TextString bevo_16 = (new BEC_4_6_TextString(bels_20, 1));
private static BEC_4_3_MathInt bevo_17 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_18 = (new BEC_4_3_MathInt(1));
private static byte[] bels_21 = {0x3A};
private static BEC_4_3_MathInt bevo_19 = (new BEC_4_3_MathInt(0));
private static byte[] bels_22 = {0x3A};
private static BEC_4_3_MathInt bevo_20 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_21 = (new BEC_4_3_MathInt(1));
private static byte[] bels_23 = {0x28};
private static BEC_4_6_TextString bevo_22 = (new BEC_4_6_TextString(bels_23, 1));
private static BEC_4_3_MathInt bevo_23 = (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_24 = (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_25 = (new BEC_4_3_MathInt(3));
private static byte[] bels_24 = {0x2E};
private static byte[] bels_25 = {0x2E};
private static BEC_4_3_MathInt bevo_26 = (new BEC_4_3_MathInt(1));
private static byte[] bels_26 = {0x42,0x45,0x4C,0x5F};
private static BEC_4_6_TextString bevo_27 = (new BEC_4_6_TextString(bels_26, 4));
private static BEC_4_3_MathInt bevo_28 = (new BEC_4_3_MathInt(0));
private static byte[] bels_27 = {0x5F};
private static BEC_4_6_TextString bevo_29 = (new BEC_4_6_TextString(bels_27, 1));
private static BEC_4_3_MathInt bevo_30 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_31 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_32 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_33 = (new BEC_4_3_MathInt(7));
private static byte[] bels_28 = {0x62,0x65};
private static byte[] bels_29 = {0x6A,0x76};
private static BEC_4_6_TextString bevo_34 = (new BEC_4_6_TextString(bels_29, 2));
private static byte[] bels_30 = {0x62,0x65};
private static byte[] bels_31 = {0x2E};
private static byte[] bels_32 = {0x42,0x45,0x43,0x5F};
private static BEC_4_6_TextString bevo_35 = (new BEC_4_6_TextString(bels_32, 4));
private static byte[] bels_33 = {0x5F};
private static BEC_4_3_MathInt bevo_36 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_37 = (new BEC_4_3_MathInt(1));
private static byte[] bels_34 = {0x3A};
private static byte[] bels_35 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_38 = (new BEC_4_6_TextString(bels_35, 4));
private static byte[] bels_36 = {0x5F};
private static BEC_4_3_MathInt bevo_39 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_40 = (new BEC_4_3_MathInt(1));
private static byte[] bels_37 = {0x5F};
private static byte[] bels_38 = {0x0A};
private static BEC_4_6_TextString bevo_41 = (new BEC_4_6_TextString(bels_38, 1));
public static BEC_6_9_SystemException bevs_inst;
public BEC_6_6_SystemObject bevp_methodName;
public BEC_6_6_SystemObject bevp_klassName;
public BEC_6_6_SystemObject bevp_description;
public BEC_6_6_SystemObject bevp_fileName;
public BEC_6_6_SystemObject bevp_lineNumber;
public BEC_4_6_TextString bevp_lang;
public BEC_4_6_TextString bevp_emitLang;
public BEC_9_10_ContainerLinkedList bevp_frames;
public BEC_4_6_TextString bevp_framesText;
public BEC_5_4_LogicBool bevp_translated;
public BEC_6_9_SystemException bem_new_1(BEC_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_6_6_SystemObject bevl_toRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (new BEC_4_6_TextString(11, bels_0));
if (bevp_lang == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 40 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(7, bels_1));
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevl_toRet = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_lang);
} /* Line: 41 */
if (bevp_emitLang == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 43 */ {
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(11, bels_2));
bevt_4_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_emitLang);
} /* Line: 44 */
if (bevp_methodName == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 46 */ {
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(9, bels_3));
bevt_7_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_8_tmpvar_phold);
bevl_toRet = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_methodName);
} /* Line: 47 */
if (bevp_klassName == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 49 */ {
bevt_11_tmpvar_phold = (new BEC_4_6_TextString(8, bels_4));
bevt_10_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_toRet = bevt_10_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_klassName);
} /* Line: 50 */
if (bevp_description == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(14, bels_5));
bevt_13_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevl_toRet = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_description);
} /* Line: 53 */
if (bevp_fileName == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(7, bels_6));
bevt_16_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_17_tmpvar_phold);
bevl_toRet = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_fileName);
} /* Line: 56 */
if (bevp_lineNumber == null) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 58 */ {
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(7, bels_7));
bevt_19_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = bevp_lineNumber.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toRet = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
} /* Line: 59 */
if (bevp_framesText == null) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 61 */ {
bevt_24_tmpvar_phold = (new BEC_4_6_TextString(14, bels_8));
bevt_23_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevl_toRet = bevt_23_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_framesText);
} /* Line: 62 */
if (bevp_frames == null) {
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 64 */ {
bevt_26_tmpvar_phold = this.bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 65 */
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_6_6_SystemObject bem_translateEmittedException_0() throws Throwable {
BEC_4_9_TextTokenizer bevl_ltok = null;
BEC_9_10_ContainerLinkedList bevl_lines = null;
BEC_5_4_LogicBool bevl_isCs = null;
BEC_4_6_TextString bevl_line = null;
BEC_4_3_MathInt bevl_start = null;
BEC_4_6_TextString bevl_efile = null;
BEC_4_3_MathInt bevl_eline = null;
BEC_4_3_MathInt bevl_end = null;
BEC_4_6_TextString bevl_callPart = null;
BEC_4_6_TextString bevl_inPart = null;
BEC_4_3_MathInt bevl_pdelim = null;
BEC_4_6_TextString bevl_iv = null;
BEC_9_10_ContainerLinkedList bevl_parts = null;
BEC_4_6_TextString bevl_klass = null;
BEC_4_6_TextString bevl_mtd = null;
BEC_4_6_TextString bevl_libLens = null;
BEC_4_3_MathInt bevl_libLen = null;
BEC_6_9_5_SystemExceptionFrame bevl_fr = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_98_tmpvar_phold = null;
BEC_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
if (bevp_translated == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 71 */ {
if (bevp_translated.bevi_bool) /* Line: 71 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 71 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 71 */
 else  /* Line: 71 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 71 */ {
return this;
} /* Line: 72 */
bevp_translated = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 75 */ {
if (bevp_lang == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 75 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 75 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 75 */
 else  /* Line: 75 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 75 */ {
bevt_16_tmpvar_phold = bevo_0;
bevt_15_tmpvar_phold = bevp_lang.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 75 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 75 */ {
bevt_18_tmpvar_phold = bevo_1;
bevt_17_tmpvar_phold = bevp_lang.bem_equals_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 75 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 75 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 75 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 75 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 75 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 75 */
 else  /* Line: 75 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 75 */ {
bevt_19_tmpvar_phold = (new BEC_4_6_TextString(2, bels_11));
bevl_ltok = (new BEC_4_9_TextTokenizer()).bem_new_1(bevt_19_tmpvar_phold);
bevl_lines = (BEC_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_21_tmpvar_phold = bevo_2;
bevt_20_tmpvar_phold = bevp_lang.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 78 */ {
bevl_isCs = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 79 */
 else  /* Line: 80 */ {
bevl_isCs = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 81 */
bevt_0_tmpvar_loop = bevl_lines.bem_iteratorGet_0();
while (true)
 /* Line: 83 */ {
bevt_22_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 83 */ {
bevl_line = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_23_tmpvar_phold = bevo_3;
bevl_start = bevl_line.bem_find_1(bevt_23_tmpvar_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 88 */ {
bevt_26_tmpvar_phold = bevo_4;
bevt_25_tmpvar_phold = bevl_start.bem_greaterEquals_1(bevt_26_tmpvar_phold);
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 88 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 88 */
 else  /* Line: 88 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 88 */ {
bevt_27_tmpvar_phold = bevo_5;
bevt_29_tmpvar_phold = bevo_6;
bevt_28_tmpvar_phold = bevl_start.bem_add_1(bevt_29_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_27_tmpvar_phold, bevt_28_tmpvar_phold);
if (bevl_end == null) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_31_tmpvar_phold = bevl_end.bem_greater_1(bevl_start);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 91 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 91 */
 else  /* Line: 91 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 91 */ {
bevt_33_tmpvar_phold = bevo_7;
bevt_32_tmpvar_phold = bevl_start.bem_add_1(bevt_33_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_32_tmpvar_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 95 */ {
bevt_34_tmpvar_phold = bevo_8;
bevl_start = bevl_line.bem_find_2(bevt_34_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 97 */ {
bevt_37_tmpvar_phold = bevo_9;
bevt_36_tmpvar_phold = bevl_start.bem_add_1(bevt_37_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = bevo_10;
bevt_38_tmpvar_phold = bevl_inPart.bem_ends_1(bevt_39_tmpvar_phold);
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_41_tmpvar_phold = bevl_inPart.bem_sizeGet_0();
bevt_42_tmpvar_phold = bevo_11;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_subtract_1(bevt_42_tmpvar_phold);
bevl_inPart.bem_sizeSet_1(bevt_40_tmpvar_phold);
} /* Line: 101 */
bevt_43_tmpvar_phold = (new BEC_4_6_TextString(1, bels_17));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_43_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 105 */ {
bevt_45_tmpvar_phold = bevo_12;
bevl_efile = bevl_inPart.bem_substring_2(bevt_45_tmpvar_phold, bevl_pdelim);
bevt_47_tmpvar_phold = bevo_13;
bevt_46_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_47_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_46_tmpvar_phold);
bevt_49_tmpvar_phold = bevo_14;
bevt_48_tmpvar_phold = bevl_iv.bem_begins_1(bevt_49_tmpvar_phold);
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_50_tmpvar_phold = (new BEC_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_50_tmpvar_phold);
} /* Line: 110 */
bevt_51_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevl_eline = (new BEC_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 114 */
} /* Line: 113 */
} /* Line: 105 */
} /* Line: 97 */
 else  /* Line: 118 */ {
bevt_52_tmpvar_phold = bevo_15;
bevl_start = bevl_line.bem_find_2(bevt_52_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevt_54_tmpvar_phold = bevo_16;
bevt_56_tmpvar_phold = bevo_17;
bevt_55_tmpvar_phold = bevl_start.bem_add_1(bevt_56_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_54_tmpvar_phold, bevt_55_tmpvar_phold);
if (bevl_end == null) {
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_59_tmpvar_phold = bevo_18;
bevt_58_tmpvar_phold = bevl_start.bem_add_1(bevt_59_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_58_tmpvar_phold, bevl_end);
bevt_60_tmpvar_phold = (new BEC_4_6_TextString(1, bels_21));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_60_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_61_tmpvar_phold.bevi_bool) /* Line: 129 */ {
bevt_62_tmpvar_phold = bevo_19;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_62_tmpvar_phold, bevl_pdelim);
bevt_63_tmpvar_phold = (new BEC_4_6_TextString(1, bels_22));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_63_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 133 */ {
bevt_65_tmpvar_phold = bevo_20;
bevl_efile = bevl_inPart.bem_substring_2(bevt_65_tmpvar_phold, bevl_pdelim);
} /* Line: 134 */
bevt_67_tmpvar_phold = bevo_21;
bevt_66_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_67_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_66_tmpvar_phold);
bevt_68_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 138 */ {
bevl_eline = (new BEC_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 139 */
} /* Line: 138 */
} /* Line: 129 */
} /* Line: 124 */
} /* Line: 120 */
} /* Line: 95 */
 else  /* Line: 145 */ {
bevt_69_tmpvar_phold = bevo_22;
bevt_71_tmpvar_phold = bevo_23;
bevt_70_tmpvar_phold = bevl_start.bem_add_1(bevt_71_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_69_tmpvar_phold, bevt_70_tmpvar_phold);
if (bevl_end == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 147 */ {
bevt_73_tmpvar_phold = bevl_end.bem_greater_1(bevl_start);
if (bevt_73_tmpvar_phold.bevi_bool) /* Line: 147 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 147 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 147 */
 else  /* Line: 147 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 147 */ {
bevt_75_tmpvar_phold = bevo_24;
bevt_74_tmpvar_phold = bevl_start.bem_add_1(bevt_75_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_74_tmpvar_phold, bevl_end);
} /* Line: 148 */
 else  /* Line: 149 */ {
bevt_77_tmpvar_phold = bevo_25;
bevt_76_tmpvar_phold = bevl_start.bem_add_1(bevt_77_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_76_tmpvar_phold);
} /* Line: 150 */
} /* Line: 147 */
if (bevl_callPart == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 153 */ {
if (bevl_isCs.bevi_bool) /* Line: 154 */ {
bevt_79_tmpvar_phold = (new BEC_4_6_TextString(1, bels_24));
bevl_parts = (BEC_9_10_ContainerLinkedList) bevl_callPart.bem_split_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevl_klass = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_80_tmpvar_phold);
bevt_81_tmpvar_phold = (new BEC_4_3_MathInt(3));
bevl_mtd = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_81_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevl_fr = (new BEC_6_9_5_SystemExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_83_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_82_tmpvar_phold = this.bem_getSourceFileName_1(bevt_83_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_82_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 167 */
 else  /* Line: 168 */ {
bevt_84_tmpvar_phold = (new BEC_4_6_TextString(1, bels_25));
bevl_parts = (BEC_9_10_ContainerLinkedList) bevl_callPart.bem_split_1(bevt_84_tmpvar_phold);
bevt_86_tmpvar_phold = bevl_parts.bem_sizeGet_0();
bevt_87_tmpvar_phold = bevo_26;
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_greater_1(bevt_87_tmpvar_phold);
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevt_88_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevl_mtd = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_88_tmpvar_phold);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevt_89_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevl_klass = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = bevo_27;
bevl_start = bevl_klass.bem_find_1(bevt_90_tmpvar_phold);
if (bevl_start == null) {
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 178 */ {
bevt_93_tmpvar_phold = bevo_28;
bevt_92_tmpvar_phold = bevl_start.bem_greater_1(bevt_93_tmpvar_phold);
if (bevt_92_tmpvar_phold.bevi_bool) /* Line: 178 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 178 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 178 */
 else  /* Line: 178 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 178 */ {
bevt_94_tmpvar_phold = bevo_29;
bevt_96_tmpvar_phold = bevo_30;
bevt_95_tmpvar_phold = bevl_start.bem_add_1(bevt_96_tmpvar_phold);
bevl_end = bevl_klass.bem_find_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
if (bevl_end == null) {
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevt_99_tmpvar_phold = bevo_31;
bevt_98_tmpvar_phold = bevl_end.bem_greater_1(bevt_99_tmpvar_phold);
if (bevt_98_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 180 */
 else  /* Line: 180 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 180 */ {
bevt_101_tmpvar_phold = bevo_32;
bevt_100_tmpvar_phold = bevl_start.bem_add_1(bevt_101_tmpvar_phold);
bevl_libLens = bevl_klass.bem_substring_2(bevt_100_tmpvar_phold, bevl_end);
bevl_libLen = (new BEC_4_3_MathInt()).bem_new_1(bevl_libLens);
bevt_104_tmpvar_phold = bevo_33;
bevt_103_tmpvar_phold = bevl_start.bem_add_1(bevt_104_tmpvar_phold);
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bem_add_1(bevl_libLen);
bevl_klass = bevl_klass.bem_substring_1(bevt_102_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_fr = (new BEC_6_9_5_SystemExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_106_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_105_tmpvar_phold = this.bem_getSourceFileName_1(bevt_106_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_105_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 190 */
} /* Line: 180 */
} /* Line: 178 */
} /* Line: 172 */
} /* Line: 154 */
} /* Line: 153 */
} /* Line: 88 */
 else  /* Line: 83 */ {
break;
} /* Line: 83 */
} /* Line: 83 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_4_6_TextString(2, bels_28));
bevp_framesText = null;
} /* Line: 200 */
 else  /* Line: 75 */ {
if (bevp_frames == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 201 */ {
if (bevp_lang == null) {
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 201 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 201 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 201 */
 else  /* Line: 201 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 201 */ {
bevt_110_tmpvar_phold = bevo_34;
bevt_109_tmpvar_phold = bevp_lang.bem_equals_1(bevt_110_tmpvar_phold);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 201 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 201 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 201 */
 else  /* Line: 201 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 201 */ {
bevt_1_tmpvar_loop = bevp_frames.bem_iteratorGet_0();
while (true)
 /* Line: 202 */ {
bevt_111_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_111_tmpvar_phold != null && bevt_111_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_111_tmpvar_phold).bevi_bool) /* Line: 202 */ {
bevl_fr = (BEC_6_9_5_SystemExceptionFrame) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_113_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_112_tmpvar_phold = this.bem_extractKlassLib_1(bevt_113_tmpvar_phold);
bevl_fr.bem_klassNameSet_1(bevt_112_tmpvar_phold);
bevt_115_tmpvar_phold = bevl_fr.bem_methodNameGet_0();
bevt_114_tmpvar_phold = this.bem_extractMethod_1(bevt_115_tmpvar_phold);
bevl_fr.bem_methodNameSet_1(bevt_114_tmpvar_phold);
bevt_117_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_116_tmpvar_phold = this.bem_getSourceFileName_1(bevt_117_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_116_tmpvar_phold);
 /* Line: 206 */ {
bevl_fr.bem_extractLine_0();
} /* Line: 207 */
} /* Line: 206 */
 else  /* Line: 202 */ {
break;
} /* Line: 202 */
} /* Line: 202 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_4_6_TextString(2, bels_30));
} /* Line: 211 */
 else  /* Line: 212 */ {
} /* Line: 212 */
} /* Line: 75 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_getSourceFileName_1(BEC_4_6_TextString beva_klassName) throws Throwable {
BEC_6_6_SystemObject bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = this.bem_createInstance_2(beva_klassName, bevt_0_tmpvar_phold);
if (bevl_i == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevt_2_tmpvar_phold = bevl_i.bemd_0(478622533, BEL_4_Base.bevn_sourceFileNameGet_0);
return (BEC_4_6_TextString) bevt_2_tmpvar_phold;
} /* Line: 222 */
return null;
} /*method end*/
public BEC_4_6_TextString bem_extractKlassLib_1(BEC_4_6_TextString beva_callPart) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_parts = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(1, bels_31));
bevl_parts = (BEC_9_10_ContainerLinkedList) beva_callPart.bem_split_1(bevt_0_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevt_2_tmpvar_phold = bevl_parts.bem_get_1(bevt_3_tmpvar_phold);
bevt_1_tmpvar_phold = this.bem_extractKlass_1((BEC_4_6_TextString) bevt_2_tmpvar_phold);
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_extractKlass_1(BEC_4_6_TextString beva_klass) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_kparts = null;
BEC_4_3_MathInt bevl_kps = null;
BEC_4_6_TextString bevl_rawkl = null;
BEC_4_6_TextString bevl_bec = null;
BEC_4_3_MathInt bevl_sofar = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_len = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
if (beva_klass == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 236 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 236 */ {
bevt_4_tmpvar_phold = bevo_35;
bevt_3_tmpvar_phold = beva_klass.bem_begins_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 236 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 236 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 236 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 236 */ {
return beva_klass;
} /* Line: 237 */
bevt_6_tmpvar_phold = (new BEC_4_3_MathInt(4));
bevt_5_tmpvar_phold = beva_klass.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_4_6_TextString(1, bels_33));
bevl_kparts = (BEC_9_10_ContainerLinkedList) bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_36;
bevl_kps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_rawkl = (BEC_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (new BEC_4_6_TextString()).bem_new_0();
bevl_sofar = (new BEC_4_3_MathInt(0));
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 244 */ {
bevt_10_tmpvar_phold = bevl_i.bem_lesser_1(bevl_kps);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 244 */ {
bevt_11_tmpvar_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (new BEC_4_3_MathInt()).bem_new_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpvar_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpvar_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_16_tmpvar_phold = bevo_37;
bevt_15_tmpvar_phold = bevl_i.bem_add_1(bevt_16_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_lesser_1(bevl_kps);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 248 */ {
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(1, bels_34));
bevl_bec.bem_addValue_1(bevt_17_tmpvar_phold);
} /* Line: 248 */
bevl_sofar.bem_addValue_1(bevl_len);
bevl_i.bem_incrementValue_0();
} /* Line: 244 */
 else  /* Line: 244 */ {
break;
} /* Line: 244 */
} /* Line: 244 */
return bevl_bec;
} /*method end*/
public BEC_4_6_TextString bem_extractMethod_1(BEC_4_6_TextString beva_mtd) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_mparts = null;
BEC_4_3_MathInt bevl_mps = null;
BEC_4_6_TextString bevl_bem = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
if (beva_mtd == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 256 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 256 */ {
bevt_4_tmpvar_phold = bevo_38;
bevt_3_tmpvar_phold = beva_mtd.bem_begins_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 256 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 256 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 256 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 256 */ {
return beva_mtd;
} /* Line: 257 */
bevt_6_tmpvar_phold = (new BEC_4_3_MathInt(4));
bevt_5_tmpvar_phold = beva_mtd.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_4_6_TextString(1, bels_36));
bevl_mparts = (BEC_9_10_ContainerLinkedList) bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_39;
bevl_mps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_bem = (new BEC_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 262 */ {
bevt_10_tmpvar_phold = bevl_i.bem_lesser_1(bevl_mps);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevt_11_tmpvar_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_40;
bevt_13_tmpvar_phold = bevl_i.bem_add_1(bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_lesser_1(bevl_mps);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevt_15_tmpvar_phold = (new BEC_4_6_TextString(1, bels_37));
bevl_bem.bem_addValue_1(bevt_15_tmpvar_phold);
} /* Line: 264 */
bevl_i.bem_incrementValue_0();
} /* Line: 262 */
 else  /* Line: 262 */ {
break;
} /* Line: 262 */
} /* Line: 262 */
return bevl_bem;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_framesGet_0() throws Throwable {
return bevp_frames;
} /*method end*/
public BEC_4_6_TextString bem_getFrameText_0() throws Throwable {
BEC_4_6_TextString bevl_toRet = null;
BEC_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_6_6_SystemObject bevl_ft = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (new BEC_4_6_TextString()).bem_new_0();
bevl_myFrames = this.bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 280 */ {
bevt_2_tmpvar_phold = bevo_41;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_loop = bevl_myFrames.bem_iteratorGet_0();
while (true)
 /* Line: 282 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 282 */ {
bevl_ft = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 283 */
 else  /* Line: 282 */ {
break;
} /* Line: 282 */
} /* Line: 282 */
} /* Line: 282 */
return bevl_toRet;
} /*method end*/
public BEC_4_6_TextString bem_klassNameGet_0() throws Throwable {
return (BEC_4_6_TextString) bevp_klassName;
} /*method end*/
public BEC_6_6_SystemObject bem_addFrame_1(BEC_6_9_5_SystemExceptionFrame beva_frame) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_frames == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevp_frames = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 295 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addFrame_4(BEC_4_6_TextString beva__klassName, BEC_4_6_TextString beva__methodName, BEC_4_6_TextString beva__fileName, BEC_4_3_MathInt beva__line) throws Throwable {
BEC_6_9_5_SystemExceptionFrame bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_6_9_5_SystemExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
this.bem_addFrame_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_6_6_SystemObject bem_methodNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_methodName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_klassNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_klassName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_descriptionGet_0() throws Throwable {
return bevp_description;
} /*method end*/
public BEC_6_6_SystemObject bem_descriptionSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_description = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_6_6_SystemObject bem_fileNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fileName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_lineNumberGet_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public BEC_6_6_SystemObject bem_lineNumberSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lineNumber = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_langGet_0() throws Throwable {
return bevp_lang;
} /*method end*/
public BEC_6_6_SystemObject bem_langSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lang = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_emitLangGet_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLangSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLang = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_framesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_frames = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_framesTextGet_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public BEC_6_6_SystemObject bem_framesTextSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_framesText = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_translatedGet_0() throws Throwable {
return bevp_translated;
} /*method end*/
public BEC_6_6_SystemObject bem_translatedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_translated = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {33, 37, 39, 40, 40, 41, 41, 41, 43, 43, 44, 44, 44, 46, 46, 47, 47, 47, 49, 49, 50, 50, 50, 52, 52, 53, 53, 53, 55, 55, 56, 56, 56, 58, 58, 59, 59, 59, 59, 61, 61, 62, 62, 62, 64, 64, 65, 65, 67, 71, 71, 0, 0, 0, 72, 74, 75, 75, 75, 75, 0, 0, 0, 75, 75, 0, 75, 75, 0, 0, 0, 0, 0, 76, 76, 77, 78, 78, 79, 81, 83, 0, 83, 83, 85, 85, 86, 87, 88, 88, 88, 88, 0, 0, 0, 90, 90, 90, 90, 91, 91, 91, 0, 0, 0, 93, 93, 93, 96, 96, 97, 97, 99, 99, 99, 100, 100, 101, 101, 101, 101, 104, 104, 105, 105, 106, 106, 108, 108, 108, 109, 109, 110, 110, 113, 114, 119, 119, 120, 120, 123, 123, 123, 123, 124, 124, 126, 126, 126, 128, 128, 129, 129, 130, 130, 132, 132, 133, 133, 134, 134, 136, 136, 136, 138, 139, 146, 146, 146, 146, 147, 147, 147, 0, 0, 0, 148, 148, 148, 150, 150, 150, 153, 153, 156, 156, 158, 158, 159, 159, 161, 163, 165, 166, 166, 166, 167, 171, 171, 172, 172, 172, 173, 173, 174, 176, 176, 177, 177, 178, 178, 178, 178, 0, 0, 0, 179, 179, 179, 179, 180, 180, 180, 180, 0, 0, 0, 181, 181, 181, 183, 184, 184, 184, 184, 186, 188, 189, 189, 189, 190, 198, 199, 200, 201, 201, 201, 201, 0, 0, 0, 201, 201, 0, 0, 0, 202, 0, 202, 202, 203, 203, 203, 204, 204, 204, 205, 205, 205, 207, 210, 211, 219, 219, 220, 220, 222, 222, 225, 230, 230, 232, 232, 232, 232, 236, 236, 0, 236, 236, 236, 0, 0, 237, 239, 239, 239, 239, 240, 240, 240, 241, 242, 243, 244, 244, 245, 245, 247, 247, 247, 248, 248, 248, 248, 248, 249, 244, 252, 256, 256, 0, 256, 256, 256, 0, 0, 257, 259, 259, 259, 259, 260, 260, 260, 261, 262, 262, 263, 263, 264, 264, 264, 264, 264, 262, 267, 273, 277, 278, 279, 280, 280, 281, 281, 282, 0, 282, 282, 283, 286, 290, 294, 294, 295, 297, 301, 301, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {100, 132, 133, 134, 139, 140, 141, 142, 144, 149, 150, 151, 152, 154, 159, 160, 161, 162, 164, 169, 170, 171, 172, 174, 179, 180, 181, 182, 184, 189, 190, 191, 192, 194, 199, 200, 201, 202, 203, 205, 210, 211, 212, 213, 215, 220, 221, 222, 224, 363, 368, 370, 373, 377, 380, 382, 383, 388, 389, 394, 395, 398, 402, 405, 406, 408, 411, 412, 414, 417, 421, 424, 428, 431, 432, 433, 434, 435, 437, 440, 442, 442, 445, 447, 448, 449, 450, 451, 452, 457, 458, 459, 461, 464, 468, 471, 472, 473, 474, 475, 480, 481, 483, 486, 490, 493, 494, 495, 497, 498, 499, 504, 505, 506, 507, 508, 509, 511, 512, 513, 514, 516, 517, 518, 523, 524, 525, 526, 527, 528, 529, 530, 532, 533, 535, 537, 543, 544, 545, 550, 551, 552, 553, 554, 555, 560, 561, 562, 563, 564, 565, 566, 571, 572, 573, 574, 575, 576, 581, 582, 583, 585, 586, 587, 588, 590, 598, 599, 600, 601, 602, 607, 608, 610, 613, 617, 620, 621, 622, 625, 626, 627, 630, 635, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 652, 653, 654, 655, 656, 658, 659, 660, 661, 662, 663, 664, 665, 670, 671, 672, 674, 677, 681, 684, 685, 686, 687, 688, 693, 694, 695, 697, 700, 704, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 732, 733, 734, 737, 742, 743, 748, 749, 752, 756, 759, 760, 762, 765, 769, 772, 772, 775, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 788, 795, 796, 808, 809, 810, 815, 816, 817, 819, 827, 828, 829, 830, 831, 832, 860, 865, 866, 869, 870, 871, 873, 876, 880, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 895, 897, 898, 899, 900, 901, 902, 903, 904, 906, 907, 909, 910, 916, 939, 944, 945, 948, 949, 950, 952, 955, 959, 961, 962, 963, 964, 965, 966, 967, 968, 969, 972, 974, 975, 976, 977, 978, 980, 981, 983, 989, 992, 1002, 1003, 1004, 1005, 1010, 1011, 1012, 1013, 1013, 1016, 1018, 1019, 1026, 1029, 1033, 1038, 1039, 1041, 1046, 1047, 1051, 1054, 1058, 1062, 1065, 1069, 1072, 1076, 1079, 1083, 1086, 1090, 1093, 1097, 1101, 1104, 1108, 1111};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 33 100
translateEmittedException 0 37 132
assign 1 39 133
new 0 39 133
assign 1 40 134
def 1 40 139
assign 1 41 140
new 0 41 140
assign 1 41 141
add 1 41 141
assign 1 41 142
add 1 41 142
assign 1 43 144
def 1 43 149
assign 1 44 150
new 0 44 150
assign 1 44 151
add 1 44 151
assign 1 44 152
add 1 44 152
assign 1 46 154
def 1 46 159
assign 1 47 160
new 0 47 160
assign 1 47 161
add 1 47 161
assign 1 47 162
add 1 47 162
assign 1 49 164
def 1 49 169
assign 1 50 170
new 0 50 170
assign 1 50 171
add 1 50 171
assign 1 50 172
add 1 50 172
assign 1 52 174
def 1 52 179
assign 1 53 180
new 0 53 180
assign 1 53 181
add 1 53 181
assign 1 53 182
add 1 53 182
assign 1 55 184
def 1 55 189
assign 1 56 190
new 0 56 190
assign 1 56 191
add 1 56 191
assign 1 56 192
add 1 56 192
assign 1 58 194
def 1 58 199
assign 1 59 200
new 0 59 200
assign 1 59 201
add 1 59 201
assign 1 59 202
toString 0 59 202
assign 1 59 203
add 1 59 203
assign 1 61 205
def 1 61 210
assign 1 62 211
new 0 62 211
assign 1 62 212
add 1 62 212
assign 1 62 213
add 1 62 213
assign 1 64 215
def 1 64 220
assign 1 65 221
getFrameText 0 65 221
assign 1 65 222
add 1 65 222
return 1 67 224
assign 1 71 363
def 1 71 368
assign 1 0 370
assign 1 0 373
assign 1 0 377
return 1 72 380
assign 1 74 382
new 0 74 382
assign 1 75 383
def 1 75 388
assign 1 75 389
def 1 75 394
assign 1 0 395
assign 1 0 398
assign 1 0 402
assign 1 75 405
new 0 75 405
assign 1 75 406
equals 1 75 406
assign 1 0 408
assign 1 75 411
new 0 75 411
assign 1 75 412
equals 1 75 412
assign 1 0 414
assign 1 0 417
assign 1 0 421
assign 1 0 424
assign 1 0 428
assign 1 76 431
new 0 76 431
assign 1 76 432
new 1 76 432
assign 1 77 433
tokenize 1 77 433
assign 1 78 434
new 0 78 434
assign 1 78 435
equals 1 78 435
assign 1 79 437
new 0 79 437
assign 1 81 440
new 0 81 440
assign 1 83 442
iteratorGet 0 0 442
assign 1 83 445
hasNextGet 0 83 445
assign 1 83 447
nextGet 0 83 447
assign 1 85 448
new 0 85 448
assign 1 85 449
find 1 85 449
assign 1 86 450
assign 1 87 451
assign 1 88 452
def 1 88 457
assign 1 88 458
new 0 88 458
assign 1 88 459
greaterEquals 1 88 459
assign 1 0 461
assign 1 0 464
assign 1 0 468
assign 1 90 471
new 0 90 471
assign 1 90 472
new 0 90 472
assign 1 90 473
add 1 90 473
assign 1 90 474
find 2 90 474
assign 1 91 475
def 1 91 480
assign 1 91 481
greater 1 91 481
assign 1 0 483
assign 1 0 486
assign 1 0 490
assign 1 93 493
new 0 93 493
assign 1 93 494
add 1 93 494
assign 1 93 495
substring 2 93 495
assign 1 96 497
new 0 96 497
assign 1 96 498
find 2 96 498
assign 1 97 499
def 1 97 504
assign 1 99 505
new 0 99 505
assign 1 99 506
add 1 99 506
assign 1 99 507
substring 1 99 507
assign 1 100 508
new 0 100 508
assign 1 100 509
ends 1 100 509
assign 1 101 511
sizeGet 0 101 511
assign 1 101 512
new 0 101 512
assign 1 101 513
subtract 1 101 513
sizeSet 1 101 514
assign 1 104 516
new 0 104 516
assign 1 104 517
rfind 1 104 517
assign 1 105 518
def 1 105 523
assign 1 106 524
new 0 106 524
assign 1 106 525
substring 2 106 525
assign 1 108 526
new 0 108 526
assign 1 108 527
add 1 108 527
assign 1 108 528
substring 1 108 528
assign 1 109 529
new 0 109 529
assign 1 109 530
begins 1 109 530
assign 1 110 532
new 0 110 532
assign 1 110 533
substring 1 110 533
assign 1 113 535
isInteger 0 113 535
assign 1 114 537
new 1 114 537
assign 1 119 543
new 0 119 543
assign 1 119 544
find 2 119 544
assign 1 120 545
def 1 120 550
assign 1 123 551
new 0 123 551
assign 1 123 552
new 0 123 552
assign 1 123 553
add 1 123 553
assign 1 123 554
find 2 123 554
assign 1 124 555
def 1 124 560
assign 1 126 561
new 0 126 561
assign 1 126 562
add 1 126 562
assign 1 126 563
substring 2 126 563
assign 1 128 564
new 0 128 564
assign 1 128 565
rfind 1 128 565
assign 1 129 566
def 1 129 571
assign 1 130 572
new 0 130 572
assign 1 130 573
substring 2 130 573
assign 1 132 574
new 0 132 574
assign 1 132 575
rfind 1 132 575
assign 1 133 576
def 1 133 581
assign 1 134 582
new 0 134 582
assign 1 134 583
substring 2 134 583
assign 1 136 585
new 0 136 585
assign 1 136 586
add 1 136 586
assign 1 136 587
substring 1 136 587
assign 1 138 588
isInteger 0 138 588
assign 1 139 590
new 1 139 590
assign 1 146 598
new 0 146 598
assign 1 146 599
new 0 146 599
assign 1 146 600
add 1 146 600
assign 1 146 601
find 2 146 601
assign 1 147 602
def 1 147 607
assign 1 147 608
greater 1 147 608
assign 1 0 610
assign 1 0 613
assign 1 0 617
assign 1 148 620
new 0 148 620
assign 1 148 621
add 1 148 621
assign 1 148 622
substring 2 148 622
assign 1 150 625
new 0 150 625
assign 1 150 626
add 1 150 626
assign 1 150 627
substring 1 150 627
assign 1 153 630
def 1 153 635
assign 1 156 637
new 0 156 637
assign 1 156 638
split 1 156 638
assign 1 158 639
new 0 158 639
assign 1 158 640
get 1 158 640
assign 1 159 641
new 0 159 641
assign 1 159 642
get 1 159 642
assign 1 161 643
extractKlass 1 161 643
assign 1 163 644
extractMethod 1 163 644
assign 1 165 645
new 4 165 645
assign 1 166 646
klassNameGet 0 166 646
assign 1 166 647
getSourceFileName 1 166 647
fileNameSet 1 166 648
addFrame 1 167 649
assign 1 171 652
new 0 171 652
assign 1 171 653
split 1 171 653
assign 1 172 654
sizeGet 0 172 654
assign 1 172 655
new 0 172 655
assign 1 172 656
greater 1 172 656
assign 1 173 658
new 0 173 658
assign 1 173 659
get 1 173 659
assign 1 174 660
extractMethod 1 174 660
assign 1 176 661
new 0 176 661
assign 1 176 662
get 1 176 662
assign 1 177 663
new 0 177 663
assign 1 177 664
find 1 177 664
assign 1 178 665
def 1 178 670
assign 1 178 671
new 0 178 671
assign 1 178 672
greater 1 178 672
assign 1 0 674
assign 1 0 677
assign 1 0 681
assign 1 179 684
new 0 179 684
assign 1 179 685
new 0 179 685
assign 1 179 686
add 1 179 686
assign 1 179 687
find 2 179 687
assign 1 180 688
def 1 180 693
assign 1 180 694
new 0 180 694
assign 1 180 695
greater 1 180 695
assign 1 0 697
assign 1 0 700
assign 1 0 704
assign 1 181 707
new 0 181 707
assign 1 181 708
add 1 181 708
assign 1 181 709
substring 2 181 709
assign 1 183 710
new 1 183 710
assign 1 184 711
new 0 184 711
assign 1 184 712
add 1 184 712
assign 1 184 713
add 1 184 713
assign 1 184 714
substring 1 184 714
assign 1 186 715
extractKlass 1 186 715
assign 1 188 716
new 4 188 716
assign 1 189 717
klassNameGet 0 189 717
assign 1 189 718
getSourceFileName 1 189 718
fileNameSet 1 189 719
addFrame 1 190 720
assign 1 198 732
assign 1 199 733
new 0 199 733
assign 1 200 734
assign 1 201 737
def 1 201 742
assign 1 201 743
def 1 201 748
assign 1 0 749
assign 1 0 752
assign 1 0 756
assign 1 201 759
new 0 201 759
assign 1 201 760
equals 1 201 760
assign 1 0 762
assign 1 0 765
assign 1 0 769
assign 1 202 772
iteratorGet 0 0 772
assign 1 202 775
hasNextGet 0 202 775
assign 1 202 777
nextGet 0 202 777
assign 1 203 778
klassNameGet 0 203 778
assign 1 203 779
extractKlassLib 1 203 779
klassNameSet 1 203 780
assign 1 204 781
methodNameGet 0 204 781
assign 1 204 782
extractMethod 1 204 782
methodNameSet 1 204 783
assign 1 205 784
klassNameGet 0 205 784
assign 1 205 785
getSourceFileName 1 205 785
fileNameSet 1 205 786
extractLine 0 207 788
assign 1 210 795
assign 1 211 796
new 0 211 796
assign 1 219 808
new 0 219 808
assign 1 219 809
createInstance 2 219 809
assign 1 220 810
def 1 220 815
assign 1 222 816
sourceFileNameGet 0 222 816
return 1 222 817
return 1 225 819
assign 1 230 827
new 0 230 827
assign 1 230 828
split 1 230 828
assign 1 232 829
new 0 232 829
assign 1 232 830
get 1 232 830
assign 1 232 831
extractKlass 1 232 831
return 1 232 832
assign 1 236 860
undef 1 236 865
assign 1 0 866
assign 1 236 869
new 0 236 869
assign 1 236 870
begins 1 236 870
assign 1 236 871
not 0 236 871
assign 1 0 873
assign 1 0 876
return 1 237 880
assign 1 239 882
new 0 239 882
assign 1 239 883
substring 1 239 883
assign 1 239 884
new 0 239 884
assign 1 239 885
split 1 239 885
assign 1 240 886
sizeGet 0 240 886
assign 1 240 887
new 0 240 887
assign 1 240 888
subtract 1 240 888
assign 1 241 889
get 1 241 889
assign 1 242 890
new 0 242 890
assign 1 243 891
new 0 243 891
assign 1 244 892
new 0 244 892
assign 1 244 895
lesser 1 244 895
assign 1 245 897
get 1 245 897
assign 1 245 898
new 1 245 898
assign 1 247 899
add 1 247 899
assign 1 247 900
substring 2 247 900
addValue 1 247 901
assign 1 248 902
new 0 248 902
assign 1 248 903
add 1 248 903
assign 1 248 904
lesser 1 248 904
assign 1 248 906
new 0 248 906
addValue 1 248 907
addValue 1 249 909
incrementValue 0 244 910
return 1 252 916
assign 1 256 939
undef 1 256 944
assign 1 0 945
assign 1 256 948
new 0 256 948
assign 1 256 949
begins 1 256 949
assign 1 256 950
not 0 256 950
assign 1 0 952
assign 1 0 955
return 1 257 959
assign 1 259 961
new 0 259 961
assign 1 259 962
substring 1 259 962
assign 1 259 963
new 0 259 963
assign 1 259 964
split 1 259 964
assign 1 260 965
sizeGet 0 260 965
assign 1 260 966
new 0 260 966
assign 1 260 967
subtract 1 260 967
assign 1 261 968
new 0 261 968
assign 1 262 969
new 0 262 969
assign 1 262 972
lesser 1 262 972
assign 1 263 974
get 1 263 974
addValue 1 263 975
assign 1 264 976
new 0 264 976
assign 1 264 977
add 1 264 977
assign 1 264 978
lesser 1 264 978
assign 1 264 980
new 0 264 980
addValue 1 264 981
incrementValue 0 262 983
return 1 267 989
return 1 273 992
translateEmittedException 0 277 1002
assign 1 278 1003
new 0 278 1003
assign 1 279 1004
framesGet 0 279 1004
assign 1 280 1005
def 1 280 1010
assign 1 281 1011
new 0 281 1011
assign 1 281 1012
add 1 281 1012
assign 1 282 1013
iteratorGet 0 0 1013
assign 1 282 1016
hasNextGet 0 282 1016
assign 1 282 1018
nextGet 0 282 1018
assign 1 283 1019
add 1 283 1019
return 1 286 1026
return 1 290 1029
assign 1 294 1033
undef 1 294 1038
assign 1 295 1039
new 0 295 1039
addValue 1 297 1041
assign 1 301 1046
new 4 301 1046
addFrame 1 301 1047
return 1 0 1051
assign 1 0 1054
assign 1 0 1058
return 1 0 1062
assign 1 0 1065
return 1 0 1069
assign 1 0 1072
return 1 0 1076
assign 1 0 1079
return 1 0 1083
assign 1 0 1086
return 1 0 1090
assign 1 0 1093
assign 1 0 1097
return 1 0 1101
assign 1 0 1104
return 1 0 1108
assign 1 0 1111
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1353219100: return bem_klassNameGet_0();
case 1774940957: return bem_toString_0();
case 1354714650: return bem_copy_0();
case 734830721: return bem_framesGet_0();
case 1475977273: return bem_langGet_0();
case 1308786538: return bem_echo_0();
case 1307921883: return bem_methodNameGet_0();
case 1184167343: return bem_translatedGet_0();
case 764669899: return bem_getFrameText_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 484558571: return bem_descriptionGet_0();
case 1611190486: return bem_lineNumberGet_0();
case 556476320: return bem_fileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case 154290862: return bem_translateEmittedException_0();
case 1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 845792839: return bem_iteratorGet_0();
case 1141730732: return bem_framesTextGet_0();
case 314718434: return bem_print_0();
case 220901978: return bem_emitLangGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1286797640: return bem_extractKlassLib_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1600108233: return bem_lineNumberSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 495640824: return bem_descriptionSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 567558573: return bem_fileNameSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1364301353: return bem_klassNameSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 745912974: return bem_framesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1487059526: return bem_langSet_1(bevd_0);
case 813541388: return bem_extractMethod_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1173085090: return bem_translatedSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 205231606: return bem_getSourceFileName_1((BEC_4_6_TextString) bevd_0);
case 1319004136: return bem_methodNameSet_1(bevd_0);
case 1300981246: return bem_addFrame_1((BEC_6_9_5_SystemExceptionFrame) bevd_0);
case 371136143: return bem_extractKlass_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1130648479: return bem_framesTextSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1300981249: return bem_addFrame_4((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_9_SystemException();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_9_SystemException.bevs_inst = (BEC_6_9_SystemException)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_9_SystemException.bevs_inst;
}
}
