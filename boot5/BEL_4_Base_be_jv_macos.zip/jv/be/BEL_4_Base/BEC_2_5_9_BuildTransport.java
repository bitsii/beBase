package be.BEL_4_Base;
/* IO:File: source/build/Transport.be */
public class BEC_2_5_9_BuildTransport extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransport() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65,0x3A};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_1, 38));
private static byte[] bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_2, 10));
private static byte[] bels_3 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_4, 10));
private static byte[] bels_5 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bels_6 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_7 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bels_8 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_9 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_10 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static BEC_2_5_9_BuildTransport bevs_inst;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_5_4_BuildNode bevp_outermost;
public BEC_2_5_4_BuildNode bevp_current;
public BEC_2_5_9_BuildTransport bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
BEC_2_5_9_BuildConstants bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_new_2(BEC_2_5_5_BuildBuild beva__build, BEC_2_5_4_BuildNode beva__outermost) throws Throwable {
BEC_2_5_9_BuildConstants bevt_0_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_traverse_1(BEC_3_5_5_7_BuildVisitVisitor beva_visitor) throws Throwable {
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
try  /* Line: 38 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 43 */ {
if (bevl_node == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 43 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 44 */
 else  /* Line: 43 */ {
break;
} /* Line: 43 */
} /* Line: 43 */
beva_visitor.bem_end_1(this);
} /* Line: 47 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 49 */ {
bevt_2_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold.bem_print_0();
bevl_node.bem_print_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_3_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
} /* Line: 53 */
 else  /* Line: 54 */ {
bevt_4_tmpvar_phold = bevo_2;
bevt_4_tmpvar_phold.bem_print_0();
bevt_5_tmpvar_phold = bevo_3;
bevt_5_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
} /* Line: 57 */
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 59 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_contain_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_conTypes = null;
BEC_2_5_4_BuildNode bevl_curr = null;
BEC_2_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_5_4_BuildNode bevl_wf = null;
BEC_2_5_4_BuildNode bevl_cnode = null;
BEC_2_5_4_BuildNode bevl_mnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_9_BuildConstants bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_69_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpvar_phold = null;
bevt_7_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_tmpvar_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 68 */ {
bevt_8_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 68 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevl_i.bem_nextGet_0();
bevt_10_tmpvar_phold = bevl_node.bem_delayDeleteGet_0();
if (bevt_10_tmpvar_phold.bevi_bool) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 72 */ {
bevt_12_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_13_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_12_tmpvar_phold.bevi_int == bevt_13_tmpvar_phold.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevt_15_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_16_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_15_tmpvar_phold.bevi_int == bevt_16_tmpvar_phold.bevi_int) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
 else  /* Line: 73 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 73 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 77 */ {
if (bevl_wf == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevt_19_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_20_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_19_tmpvar_phold.bevi_int == bevt_20_tmpvar_phold.bevi_int) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_22_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_23_tmpvar_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_22_tmpvar_phold.bevi_int == bevt_23_tmpvar_phold.bevi_int) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 77 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_25_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
if (bevt_25_tmpvar_phold.bevi_int == bevt_26_tmpvar_phold.bevi_int) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 78 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 77 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 77 */
 else  /* Line: 77 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 78 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 79 */
 else  /* Line: 77 */ {
break;
} /* Line: 77 */
} /* Line: 77 */
if (bevl_wf == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_29_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_30_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_29_tmpvar_phold.bevi_int == bevt_30_tmpvar_phold.bevi_int) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_32_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_33_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_32_tmpvar_phold.bevi_int == bevt_33_tmpvar_phold.bevi_int) {
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 81 */ {
bevl_cnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_5));
bevl_cnode.bem_heldSet_1(bevt_35_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 88 */
} /* Line: 81 */
bevt_37_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_38_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_37_tmpvar_phold.bevi_int == bevt_38_tmpvar_phold.bevi_int) {
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_41_tmpvar_phold = bevl_curr.bem_containerGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_typenameGet_0();
bevt_42_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_40_tmpvar_phold.bevi_int == bevt_42_tmpvar_phold.bevi_int) {
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 91 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 91 */
 else  /* Line: 91 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 91 */ {
bevt_44_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_45_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_44_tmpvar_phold.bevi_int == bevt_45_tmpvar_phold.bevi_int) {
bevt_43_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_43_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 91 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 91 */
 else  /* Line: 91 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 91 */ {
bevl_mnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_tmpvar_phold);
bevt_47_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_6));
bevl_mnode.bem_heldSet_1(bevt_47_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 97 */
bevt_49_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_50_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_49_tmpvar_phold.bevi_int == bevt_50_tmpvar_phold.bevi_int) {
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_52_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_53_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_52_tmpvar_phold.bevi_int == bevt_53_tmpvar_phold.bevi_int) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 100 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 100 */
 else  /* Line: 100 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 100 */ {
bevl_mnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_7));
bevl_mnode.bem_heldSet_1(bevt_55_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 106 */
bevt_57_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_58_tmpvar_phold = bevp_ntypes.bem_RPARENSGet_0();
if (bevt_57_tmpvar_phold.bevi_int == bevt_58_tmpvar_phold.bevi_int) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 110 */
 else  /* Line: 109 */ {
bevt_60_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_61_tmpvar_phold = bevp_ntypes.bem_RIDXGet_0();
if (bevt_60_tmpvar_phold.bevi_int == bevt_61_tmpvar_phold.bevi_int) {
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpvar_phold.bevi_bool) /* Line: 111 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 112 */
 else  /* Line: 109 */ {
bevt_63_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_64_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_63_tmpvar_phold.bevi_int == bevt_64_tmpvar_phold.bevi_int) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevt_67_tmpvar_phold = (new BEC_2_4_6_TextString(32, bels_8));
bevt_66_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_67_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_66_tmpvar_phold);
} /* Line: 116 */
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 119 */ {
bevt_70_tmpvar_phold = (new BEC_2_4_6_TextString(32, bels_9));
bevt_69_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_70_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_69_tmpvar_phold);
} /* Line: 120 */
} /* Line: 119 */
 else  /* Line: 122 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 123 */
} /* Line: 109 */
} /* Line: 109 */
bevt_72_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_71_tmpvar_phold = bevl_conTypes.bem_has_1(bevt_72_tmpvar_phold);
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 125 */ {
bevl_curr = bevl_node;
} /* Line: 126 */
} /* Line: 125 */
} /* Line: 72 */
 else  /* Line: 68 */ {
break;
} /* Line: 68 */
} /* Line: 68 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_stepBack_1(BEC_2_5_4_BuildNode beva_curr) throws Throwable {
BEC_2_5_4_BuildNode bevl_hop = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 134 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(32, bels_10));
bevt_1_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpvar_phold, beva_curr);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 135 */
return bevl_hop;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_outermostGet_0() throws Throwable {
return bevp_outermost;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outermostSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 21, 21, 22, 23, 25, 25, 26, 26, 30, 31, 31, 32, 33, 39, 41, 43, 43, 44, 47, 49, 49, 50, 50, 51, 52, 52, 53, 55, 55, 56, 56, 57, 59, 64, 64, 65, 66, 67, 68, 68, 71, 72, 72, 72, 73, 73, 73, 73, 73, 73, 73, 73, 0, 0, 0, 76, 77, 77, 77, 77, 77, 77, 0, 77, 77, 77, 77, 0, 0, 0, 78, 78, 78, 78, 0, 0, 0, 0, 0, 79, 81, 81, 81, 81, 81, 81, 0, 81, 81, 81, 81, 0, 0, 0, 0, 0, 84, 85, 85, 86, 86, 87, 88, 91, 91, 91, 91, 91, 91, 91, 91, 91, 0, 0, 0, 91, 91, 91, 91, 0, 0, 0, 93, 94, 94, 95, 95, 96, 97, 100, 100, 100, 100, 100, 100, 100, 100, 0, 0, 0, 102, 103, 103, 104, 104, 105, 106, 109, 109, 109, 109, 110, 111, 111, 111, 111, 112, 113, 113, 113, 113, 114, 115, 115, 116, 116, 116, 118, 119, 119, 120, 120, 120, 123, 125, 125, 126, 133, 134, 134, 135, 135, 135, 137, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {31, 32, 33, 34, 35, 36, 37, 38, 39, 44, 45, 46, 47, 48, 61, 62, 65, 70, 71, 77, 81, 86, 87, 88, 89, 90, 91, 92, 95, 96, 97, 98, 99, 101, 187, 188, 189, 190, 191, 192, 195, 197, 198, 199, 204, 205, 206, 207, 212, 213, 214, 215, 220, 221, 224, 228, 231, 234, 239, 240, 241, 242, 247, 248, 251, 252, 253, 258, 259, 262, 266, 269, 270, 271, 276, 277, 280, 284, 287, 291, 294, 300, 305, 306, 307, 308, 313, 314, 317, 318, 319, 324, 325, 328, 332, 335, 339, 342, 343, 344, 345, 346, 347, 348, 351, 352, 353, 358, 359, 360, 361, 362, 367, 368, 371, 375, 378, 379, 380, 385, 386, 389, 393, 396, 397, 398, 399, 400, 401, 402, 404, 405, 406, 411, 412, 413, 414, 419, 420, 423, 427, 430, 431, 432, 433, 434, 435, 436, 438, 439, 440, 445, 446, 449, 450, 451, 456, 457, 460, 461, 462, 467, 468, 469, 474, 475, 476, 477, 479, 480, 485, 486, 487, 488, 492, 496, 497, 499, 514, 515, 520, 521, 522, 523, 525, 528, 531, 535, 538, 542, 545, 549, 552};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 31
assign 1 21 32
constantsGet 0 21 32
assign 1 21 33
ntypesGet 0 21 33
assign 1 22 34
new 1 22 34
assign 1 23 35
assign 1 25 36
TRANSUNITGet 0 25 36
typenameSet 1 25 37
assign 1 26 38
new 0 26 38
heldSet 1 26 39
assign 1 30 44
assign 1 31 45
constantsGet 0 31 45
assign 1 31 46
ntypesGet 0 31 46
assign 1 32 47
assign 1 33 48
begin 1 39 61
assign 1 41 62
accept 1 41 62
assign 1 43 65
def 1 43 70
assign 1 44 71
accept 1 44 71
end 1 47 77
assign 1 49 81
def 1 49 86
assign 1 50 87
new 0 50 87
print 0 50 88
print 0 51 89
assign 1 52 90
new 0 52 90
print 0 52 91
print 0 53 92
assign 1 55 95
new 0 55 95
print 0 55 96
assign 1 56 97
new 0 56 97
print 0 56 98
print 0 57 99
throw 1 59 101
assign 1 64 187
constantsGet 0 64 187
assign 1 64 188
conTypesGet 0 64 188
assign 1 65 189
assign 1 66 190
containedGet 0 66 190
containedSet 1 67 191
assign 1 68 192
linkedListIteratorGet 0 68 192
assign 1 68 195
hasNextGet 0 68 195
assign 1 71 197
nextGet 0 71 197
assign 1 72 198
delayDeleteGet 0 72 198
assign 1 72 199
not 0 72 204
assign 1 73 205
typenameGet 0 73 205
assign 1 73 206
TRANSUNITGet 0 73 206
assign 1 73 207
equals 1 73 212
assign 1 73 213
typenameGet 0 73 213
assign 1 73 214
IDGet 0 73 214
assign 1 73 215
equals 1 73 220
assign 1 0 221
assign 1 0 224
assign 1 0 228
assign 1 76 231
assign 1 77 234
def 1 77 239
assign 1 77 240
typenameGet 0 77 240
assign 1 77 241
IDGet 0 77 241
assign 1 77 242
equals 1 77 247
assign 1 0 248
assign 1 77 251
typenameGet 0 77 251
assign 1 77 252
COLONGet 0 77 252
assign 1 77 253
equals 1 77 258
assign 1 0 259
assign 1 0 262
assign 1 0 266
assign 1 78 269
typenameGet 0 78 269
assign 1 78 270
SPACEGet 0 78 270
assign 1 78 271
equals 1 78 276
assign 1 0 277
assign 1 0 280
assign 1 0 284
assign 1 0 287
assign 1 0 291
assign 1 79 294
nextPeerGet 0 79 294
assign 1 81 300
def 1 81 305
assign 1 81 306
typenameGet 0 81 306
assign 1 81 307
PARENSGet 0 81 307
assign 1 81 308
equals 1 81 313
assign 1 0 314
assign 1 81 317
typenameGet 0 81 317
assign 1 81 318
BRACESGet 0 81 318
assign 1 81 319
equals 1 81 324
assign 1 0 325
assign 1 0 328
assign 1 0 332
assign 1 0 335
assign 1 0 339
assign 1 84 342
new 1 84 342
assign 1 85 343
CLASSGet 0 85 343
typenameSet 1 85 344
assign 1 86 345
new 0 86 345
heldSet 1 86 346
addValue 1 87 347
assign 1 88 348
assign 1 91 351
typenameGet 0 91 351
assign 1 91 352
BRACESGet 0 91 352
assign 1 91 353
equals 1 91 358
assign 1 91 359
containerGet 0 91 359
assign 1 91 360
typenameGet 0 91 360
assign 1 91 361
CLASSGet 0 91 361
assign 1 91 362
equals 1 91 367
assign 1 0 368
assign 1 0 371
assign 1 0 375
assign 1 91 378
typenameGet 0 91 378
assign 1 91 379
IDGet 0 91 379
assign 1 91 380
equals 1 91 385
assign 1 0 386
assign 1 0 389
assign 1 0 393
assign 1 93 396
new 1 93 396
assign 1 94 397
METHODGet 0 94 397
typenameSet 1 94 398
assign 1 95 399
new 0 95 399
heldSet 1 95 400
addValue 1 96 401
assign 1 97 402
assign 1 100 404
typenameGet 0 100 404
assign 1 100 405
BRACESGet 0 100 405
assign 1 100 406
equals 1 100 411
assign 1 100 412
typenameGet 0 100 412
assign 1 100 413
BRACESGet 0 100 413
assign 1 100 414
equals 1 100 419
assign 1 0 420
assign 1 0 423
assign 1 0 427
assign 1 102 430
new 1 102 430
assign 1 103 431
PROPERTIESGet 0 103 431
typenameSet 1 103 432
assign 1 104 433
new 0 104 433
heldSet 1 104 434
addValue 1 105 435
assign 1 106 436
assign 1 109 438
typenameGet 0 109 438
assign 1 109 439
RPARENSGet 0 109 439
assign 1 109 440
equals 1 109 445
assign 1 110 446
stepBack 1 110 446
assign 1 111 449
typenameGet 0 111 449
assign 1 111 450
RIDXGet 0 111 450
assign 1 111 451
equals 1 111 456
assign 1 112 457
stepBack 1 112 457
assign 1 113 460
typenameGet 0 113 460
assign 1 113 461
RBRACESGet 0 113 461
assign 1 113 462
equals 1 113 467
assign 1 114 468
stepBack 1 114 468
assign 1 115 469
undef 1 115 474
assign 1 116 475
new 0 116 475
assign 1 116 476
new 2 116 476
throw 1 116 477
assign 1 118 479
stepBack 1 118 479
assign 1 119 480
undef 1 119 485
assign 1 120 486
new 0 120 486
assign 1 120 487
new 2 120 487
throw 1 120 488
addValue 1 123 492
assign 1 125 496
typenameGet 0 125 496
assign 1 125 497
has 1 125 497
assign 1 126 499
assign 1 133 514
containerGet 0 133 514
assign 1 134 515
undef 1 134 520
assign 1 135 521
new 0 135 521
assign 1 135 522
new 2 135 522
throw 1 135 523
return 1 137 525
return 1 0 528
assign 1 0 531
return 1 0 535
assign 1 0 538
return 1 0 542
assign 1 0 545
return 1 0 549
assign 1 0 552
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 410956923: return bem_contain_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case 1081412016: return bem_many_0();
case 1380522583: return bem_outermostGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 2101994299: return bem_stepBack_1((BEC_2_5_4_BuildNode) bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1369440330: return bem_outermostSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 688372900: return bem_traverse_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_5_5_BuildBuild) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildTransport();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildTransport.bevs_inst = (BEC_2_5_9_BuildTransport)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildTransport.bevs_inst;
}
}
