package be.BEL_4_Base;
/* File: source/extended/Json.be */
public class BEC_4_12_JsonUnmarshaller extends BEC_6_6_SystemObject {
public BEC_4_12_JsonUnmarshaller() { }
private static byte[] becc_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x55,0x6E,0x6D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
public static BEC_4_12_JsonUnmarshaller bevs_inst;
public BEC_4_6_JsonParser bevp_parser;
public BEC_9_10_ContainerLinkedList bevp_ll;
public BEC_6_6_SystemObject bevp_key;
public BEC_6_6_SystemObject bevp_top;
public BEC_9_5_ContainerStack bevp_stack;
public BEC_5_4_LogicBool bevp_inList;
public BEC_4_12_JsonUnmarshaller bem_new_0() throws Throwable {
bevp_parser = (new BEC_4_6_JsonParser()).bem_new_0();
bevp_ll = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_inList = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_unmarshall_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_parser == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 481 */ {
this.bem_new_0();
} /* Line: 482 */
bevp_key = null;
bevp_top = null;
bevp_stack = (new BEC_9_5_ContainerStack()).bem_new_0();
bevp_inList = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parser.bem_parse_2(beva_str, this);
return bevp_top;
} /*method end*/
public BEC_6_6_SystemObject bem_beginMap_0() throws Throwable {
BEC_9_3_ContainerMap bevl_m = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_m = (new BEC_9_3_ContainerMap()).bem_new_0();
if (bevp_top == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 496 */ {
this.bem_addItem_1(bevl_m);
bevp_stack.bem_push_1(bevp_top);
} /* Line: 498 */
bevp_top = bevl_m;
bevp_inList = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_endMap_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_stack.bem_isEmptyGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 506 */ {
bevp_top = bevp_stack.bem_pop_0();
bevt_2_tmpvar_phold = bevp_top.bemd_1(631500772, BEL_4_Base.bevn_sameClass_1, bevp_ll);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 509 */ {
bevp_inList = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 510 */
 else  /* Line: 511 */ {
bevp_inList = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 512 */
} /* Line: 509 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_kvMid_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_beginList_0() throws Throwable {
BEC_9_5_ContainerArray bevl_l = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_l = (new BEC_9_5_ContainerArray()).bem_new_0();
if (bevp_top == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 524 */ {
this.bem_addItem_1(bevl_l);
bevp_stack.bem_push_1(bevp_top);
} /* Line: 526 */
bevp_top = bevl_l;
bevp_inList = be.BELS_Base.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_endList_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_stack.bem_isEmptyGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 534 */ {
bevp_top = bevp_stack.bem_pop_0();
bevt_2_tmpvar_phold = bevp_top.bemd_1(631500772, BEL_4_Base.bevn_sameClass_1, bevp_ll);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 537 */ {
bevp_inList = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 538 */
 else  /* Line: 539 */ {
bevp_inList = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 540 */
} /* Line: 537 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addItem_1(BEC_6_6_SystemObject beva_item) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
if (bevp_top == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 546 */ {
if (bevp_inList.bevi_bool) /* Line: 548 */ {
bevp_top.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_item);
} /* Line: 549 */
 else  /* Line: 550 */ {
if (bevp_key == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 553 */ {
bevp_key = beva_item;
} /* Line: 554 */
 else  /* Line: 555 */ {
bevp_top.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevp_key, beva_item);
bevp_key = null;
} /* Line: 557 */
} /* Line: 553 */
} /* Line: 548 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_handleString_1(BEC_4_6_TextString beva_str) throws Throwable {
this.bem_addItem_1(beva_str);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_handleTrue_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
this.bem_addItem_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_handleFalse_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
this.bem_addItem_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_handleNull_0() throws Throwable {
this.bem_addItem_1(null);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_handleInteger_1(BEC_4_3_MathInt beva_int) throws Throwable {
this.bem_addItem_1(beva_int);
return this;
} /*method end*/
public BEC_4_6_JsonParser bem_parserGet_0() throws Throwable {
return bevp_parser;
} /*method end*/
public BEC_6_6_SystemObject bem_parserSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parser = (BEC_4_6_JsonParser) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_llGet_0() throws Throwable {
return bevp_ll;
} /*method end*/
public BEC_6_6_SystemObject bem_llSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ll = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_keyGet_0() throws Throwable {
return bevp_key;
} /*method end*/
public BEC_6_6_SystemObject bem_keySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_key = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_topGet_0() throws Throwable {
return bevp_top;
} /*method end*/
public BEC_6_6_SystemObject bem_topSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_top = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_5_ContainerStack bem_stackGet_0() throws Throwable {
return bevp_stack;
} /*method end*/
public BEC_6_6_SystemObject bem_stackSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_stack = (BEC_9_5_ContainerStack) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_inListGet_0() throws Throwable {
return bevp_inList;
} /*method end*/
public BEC_6_6_SystemObject bem_inListSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inList = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {470, 471, 476, 481, 481, 482, 484, 485, 486, 487, 489, 490, 495, 496, 496, 497, 498, 500, 501, 506, 506, 507, 509, 510, 512, 523, 524, 524, 525, 526, 528, 529, 534, 534, 535, 537, 538, 540, 546, 546, 549, 553, 553, 554, 556, 557, 566, 571, 571, 576, 576, 581, 586, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 22, 27, 28, 30, 31, 32, 33, 34, 35, 40, 41, 46, 47, 48, 50, 51, 58, 59, 61, 62, 64, 67, 78, 79, 84, 85, 86, 88, 89, 96, 97, 99, 100, 102, 105, 113, 118, 120, 123, 128, 129, 132, 133, 140, 145, 146, 151, 152, 156, 160, 164, 167, 171, 174, 178, 181, 185, 188, 192, 195, 199, 202};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 470 15
new 0 470 15
assign 1 471 16
new 0 471 16
assign 1 476 17
new 0 476 17
assign 1 481 22
undef 1 481 27
new 0 482 28
assign 1 484 30
assign 1 485 31
assign 1 486 32
new 0 486 32
assign 1 487 33
new 0 487 33
parse 2 489 34
return 1 490 35
assign 1 495 40
new 0 495 40
assign 1 496 41
def 1 496 46
addItem 1 497 47
push 1 498 48
assign 1 500 50
assign 1 501 51
new 0 501 51
assign 1 506 58
isEmptyGet 0 506 58
assign 1 506 59
not 0 506 59
assign 1 507 61
pop 0 507 61
assign 1 509 62
sameClass 1 509 62
assign 1 510 64
new 0 510 64
assign 1 512 67
new 0 512 67
assign 1 523 78
new 0 523 78
assign 1 524 79
def 1 524 84
addItem 1 525 85
push 1 526 86
assign 1 528 88
assign 1 529 89
new 0 529 89
assign 1 534 96
isEmptyGet 0 534 96
assign 1 534 97
not 0 534 97
assign 1 535 99
pop 0 535 99
assign 1 537 100
sameClass 1 537 100
assign 1 538 102
new 0 538 102
assign 1 540 105
new 0 540 105
assign 1 546 113
def 1 546 118
addValue 1 549 120
assign 1 553 123
undef 1 553 128
assign 1 554 129
put 2 556 132
assign 1 557 133
addItem 1 566 140
assign 1 571 145
new 0 571 145
addItem 1 571 146
assign 1 576 151
new 0 576 151
addItem 1 576 152
addItem 1 581 156
addItem 1 586 160
return 1 0 164
assign 1 0 167
return 1 0 171
assign 1 0 174
return 1 0 178
assign 1 0 181
return 1 0 185
assign 1 0 188
return 1 0 192
assign 1 0 195
return 1 0 199
assign 1 0 202
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1398681994: return bem_endList_0();
case 1095000804: return bem_beginMap_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 914308068: return bem_inListGet_0();
case 1774940957: return bem_toString_0();
case 1354714650: return bem_copy_0();
case 506014516: return bem_handleFalse_0();
case 167292072: return bem_parserGet_0();
case 435843368: return bem_beginList_0();
case 1308786538: return bem_echo_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1431394368: return bem_handleNull_0();
case 368775858: return bem_kvMid_0();
case 1708368370: return bem_endMap_0();
case 786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 478524008: return bem_keyGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1012494862: return bem_once_0();
case 1262128633: return bem_handleTrue_0();
case 988612302: return bem_topGet_0();
case 287040793: return bem_hashGet_0();
case 1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 226791399: return bem_llGet_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 845792839: return bem_iteratorGet_0();
case 2013904863: return bem_stackGet_0();
case 314718434: return bem_print_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 178374325: return bem_parserSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2024987116: return bem_stackSet_1(bevd_0);
case 489606261: return bem_keySet_1(bevd_0);
case 925390321: return bem_inListSet_1(bevd_0);
case 1512002600: return bem_handleInteger_1((BEC_4_3_MathInt) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 977530049: return bem_topSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1818023961: return bem_unmarshall_1((BEC_4_6_TextString) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1774332469: return bem_handleString_1((BEC_4_6_TextString) bevd_0);
case 237873652: return bem_llSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 285821434: return bem_addItem_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_12_JsonUnmarshaller();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_12_JsonUnmarshaller.bevs_inst = (BEC_4_12_JsonUnmarshaller)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_12_JsonUnmarshaller.bevs_inst;
}
}
