package be.BEL_4_Base;
/* File: source/build/CCallAssembler.be */
public class BEC_5_14_BuildCCallAssembler extends BEC_6_6_SystemObject {
public BEC_5_14_BuildCCallAssembler() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x61,0x6C,0x6C,0x41,0x73,0x73,0x65,0x6D,0x62,0x6C,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x61,0x6C,0x6C,0x41,0x73,0x73,0x65,0x6D,0x62,0x6C,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_2 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_3 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_4 = {0x47,0x45,0x54};
private static byte[] bels_5 = {0x53,0x45,0x54};
private static byte[] bels_6 = {0x69,0x66,0x20,0x28,0x74,0x77,0x63,0x76,0x5F,0x6D,0x74,0x64,0x64,0x65,0x66,0x2D,0x3E,0x70,0x69,0x64,0x78,0x20,0x21,0x3D,0x20,0x30,0x29,0x20,0x7B};
private static byte[] bels_7 = {0x5B,0x74,0x77,0x63,0x76,0x5F,0x6D,0x74,0x64,0x64,0x65,0x66,0x2D,0x3E,0x70,0x69,0x64,0x78,0x5D,0x3B};
private static byte[] bels_8 = {0x7D,0x20,0x65,0x6C,0x73,0x65,0x20,0x7B};
private static byte[] bels_9 = {0x69,0x66,0x20,0x28,0x74,0x77,0x63,0x76,0x5F,0x6D,0x74,0x64,0x64,0x65,0x66,0x2D,0x3E,0x70,0x69,0x64,0x78,0x20,0x21,0x3D,0x20,0x30,0x29,0x20,0x7B};
private static byte[] bels_10 = {0x5B,0x74,0x77,0x63,0x76,0x5F,0x6D,0x74,0x64,0x64,0x65,0x66,0x2D,0x3E,0x70,0x69,0x64,0x78,0x5D,0x3B};
private static byte[] bels_11 = {0x7D,0x20,0x65,0x6C,0x73,0x65,0x20,0x7B};
private static byte[] bels_12 = {0x7D};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(0));
private static byte[] bels_13 = {0x74,0x77,0x74,0x63,0x5F,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x56,0x61,0x72,0x73};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_13, 17));
private static byte[] bels_14 = {0x74,0x77,0x74,0x63,0x5F,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x56,0x61,0x72,0x73};
private static byte[] bels_15 = {0x76,0x6F,0x69,0x64,0x2A,0x2A,0x20,0x74,0x77,0x74,0x63,0x5F,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x56,0x61,0x72,0x73,0x3B};
private static byte[] bels_16 = {0x74,0x77,0x74,0x63,0x5F,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x56,0x61,0x72,0x73,0x20,0x3D,0x20,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x56,0x61,0x72,0x73,0x5B};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_16, 52));
private static byte[] bels_17 = {0x2D,0x3E,0x63,0x6C,0x61,0x73,0x73,0x49,0x64,0x5D,0x3B};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_17, 11));
private static byte[] bels_18 = {0x42,0x45,0x49,0x4E,0x54,0x2A,0x20,0x74,0x77,0x74,0x63,0x5F,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x46,0x6C,0x61,0x67,0x73,0x3B};
private static byte[] bels_19 = {0x74,0x77,0x74,0x63,0x5F,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x46,0x6C,0x61,0x67,0x73,0x20,0x3D,0x20,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x46,0x6C,0x61,0x67,0x73,0x5B};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_19, 45));
private static byte[] bels_20 = {0x2D,0x3E,0x63,0x6C,0x61,0x73,0x73,0x49,0x64,0x5D,0x3B};
private static BEC_4_6_TextString bevo_6 = (new BEC_4_6_TextString(bels_20, 11));
private static byte[] bels_21 = {0x74,0x77,0x74,0x63,0x5F,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x56,0x61,0x72,0x73,0x5B};
private static byte[] bels_22 = {0x5D,0x3B};
private static byte[] bels_23 = {0x69,0x66,0x20,0x28};
private static byte[] bels_24 = {0x20,0x3D,0x3D,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x26,0x26,0x20,0x74,0x77,0x74,0x63,0x5F,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x46,0x6C,0x61,0x67,0x73,0x5B};
private static byte[] bels_25 = {0x5D,0x20,0x3D,0x3D,0x20,0x30,0x29,0x20,0x7B};
private static byte[] bels_26 = {0x74,0x77,0x74,0x63,0x5F,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x56,0x61,0x72,0x73,0x5B};
private static byte[] bels_27 = {0x5D,0x20,0x3D,0x20};
private static byte[] bels_28 = {0x3B};
private static byte[] bels_29 = {0x74,0x77,0x74,0x63,0x5F,0x6F,0x6E,0x63,0x65,0x45,0x76,0x61,0x6C,0x46,0x6C,0x61,0x67,0x73,0x5B};
private static byte[] bels_30 = {0x5D,0x20,0x3D,0x20,0x31,0x3B};
private static byte[] bels_31 = {0x42,0x45,0x52,0x46,0x5F,0x41,0x64,0x64,0x5F,0x4F,0x6E,0x63,0x65,0x28,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2C,0x20};
private static byte[] bels_32 = {0x29,0x3B};
private static byte[] bels_33 = {0x7D};
private static byte[] bels_34 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_35 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x6C,0x69,0x74,0x65,0x72,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x74,0x79,0x70,0x65,0x20};
private static BEC_4_6_TextString bevo_7 = (new BEC_4_6_TextString(bels_35, 27));
private static byte[] bels_36 = {0x6E,0x6F,0x74,0x5F,0x30};
private static byte[] bels_37 = {0x5B};
private static byte[] bels_38 = {0x5D};
private static byte[] bels_39 = {0x3B};
private static byte[] bels_40 = {0x5B};
private static byte[] bels_41 = {0x5D,0x20,0x3D,0x20};
private static byte[] bels_42 = {0x3B};
private static byte[] bels_43 = {0x69,0x66,0x20,0x28,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x29,0x20};
private static byte[] bels_44 = {0x20,0x3D,0x3D,0x20,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x29,0x20,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x29,0x20,0x7B,0x20};
private static byte[] bels_45 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x3B,0x20,0x7D};
private static byte[] bels_46 = {0x65,0x6C,0x73,0x65,0x20,0x69,0x66,0x20,0x28,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x29,0x20};
private static byte[] bels_47 = {0x20,0x3D,0x3D,0x20,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x29,0x20,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x29,0x20,0x7B,0x20};
private static byte[] bels_48 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x3B,0x20,0x7D};
private static byte[] bels_49 = {0x65,0x6C,0x73,0x65,0x20,0x7B};
private static byte[] bels_50 = {0x7D};
public static BEC_5_14_BuildCCallAssembler bevs_inst;
public BEC_9_3_ContainerMap bevp_fromTypes;
public BEC_6_6_SystemObject bevp_build;
public BEC_4_6_TextString bevp_nl;
public BEC_5_14_BuildCCallAssembler bem_new_1(BEC_6_6_SystemObject beva_build) throws Throwable {
BEC_6_6_SystemObject bevl_il = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
this.bem_loadBuild_1(beva_build);
bevp_fromTypes = (new BEC_9_3_ContainerMap()).bem_new_0();
bevl_il = (new BEC_5_12_BuildCAssembleInt()).bem_new_1(beva_build);
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(8, bels_0));
bevp_fromTypes.bem_put_2(bevt_0_tmpvar_phold, bevl_il);
bevl_il = (new BEC_5_14_BuildCAssembleFloat()).bem_new_1(beva_build);
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(10, bels_1));
bevp_fromTypes.bem_put_2(bevt_1_tmpvar_phold, bevl_il);
bevl_il = (new BEC_5_13_BuildCAssembleBool()).bem_new_1(beva_build);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(10, bels_2));
bevp_fromTypes.bem_put_2(bevt_2_tmpvar_phold, bevl_il);
bevl_il = (new BEC_5_15_BuildCAssembleString()).bem_new_1(beva_build);
bevt_3_tmpvar_phold = (new BEC_4_6_TextString(11, bels_3));
bevp_fromTypes.bem_put_2(bevt_3_tmpvar_phold, bevl_il);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_loadBuild_1(BEC_6_6_SystemObject beva__build) throws Throwable {
bevp_build = beva__build;
bevp_nl = (BEC_4_6_TextString) beva__build.bemd_0(2001798761, BEL_4_Base.bevn_nlGet_0);
return this;
} /*method end*/
public BEC_4_6_TextString bem_standardCall_1(BEC_5_10_BuildCallCursor beva_ca) throws Throwable {
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_6_BuildMtdSyn bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
bevt_3_tmpvar_phold = beva_ca.bem_optimizedCallGet_0();
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_6_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(682709225, BEL_4_Base.bevn_wasAccessorGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 61 */ {
bevt_8_tmpvar_phold = beva_ca.bem_mtdsGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_isGenAccessorGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 61 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 61 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 61 */
 else  /* Line: 61 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 61 */ {
bevt_12_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_heldGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(783669222, BEL_4_Base.bevn_accessorTypeGet_0);
bevt_13_tmpvar_phold = (new BEC_4_6_TextString(3, bels_4));
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_13_tmpvar_phold);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 62 */ {
bevt_14_tmpvar_phold = this.bem_processOptimizedGetter_1(beva_ca);
return bevt_14_tmpvar_phold;
} /* Line: 63 */
 else  /* Line: 62 */ {
bevt_18_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(783669222, BEL_4_Base.bevn_accessorTypeGet_0);
bevt_19_tmpvar_phold = (new BEC_4_6_TextString(3, bels_5));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_19_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 64 */ {
bevt_23_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 64 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 64 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 64 */
 else  /* Line: 64 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 64 */ {
bevt_25_tmpvar_phold = beva_ca.bem_asnRGet_0();
if (bevt_25_tmpvar_phold == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 64 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 64 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 64 */
 else  /* Line: 64 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 64 */ {
bevt_26_tmpvar_phold = this.bem_processOptimizedSetter_1(beva_ca);
return bevt_26_tmpvar_phold;
} /* Line: 65 */
} /* Line: 62 */
} /* Line: 62 */
} /* Line: 61 */
 else  /* Line: 68 */ {
} /* Line: 68 */
bevl_callRet = (new BEC_4_6_TextString()).bem_new_0();
bevt_27_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_27_tmpvar_phold);
this.bem_accessorCheckBlock_2(beva_ca, bevl_callRet);
bevt_28_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_28_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public BEC_6_6_SystemObject bem_accessorCheckBlock_2(BEC_5_10_BuildCallCursor beva_ca, BEC_4_6_TextString beva_callRet) throws Throwable {
BEC_4_6_TextString bevl_nl = null;
BEC_5_4_LogicBool bevl_isGetter = null;
BEC_5_5_BuildBuild bevt_0_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_0_tmpvar_phold.bem_nlGet_0();
bevl_isGetter = beva_ca.bem_isGetterGet_0();
bevt_2_tmpvar_phold = beva_ca.bem_prepCldefGet_0();
beva_callRet.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = beva_ca.bem_prepMdefGet_0();
beva_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
beva_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = beva_ca.bem_utPreCheckGet_0();
beva_callRet.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_6_tmpvar_phold);
if (bevl_isGetter.bevi_bool) /* Line: 89 */ {
bevt_7_tmpvar_phold = beva_ca.bem_isTypedGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 90 */ {
bevt_9_tmpvar_phold = (new BEC_4_6_TextString(29, bels_6));
bevt_8_tmpvar_phold = beva_callRet.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_13_tmpvar_phold = beva_ca.bem_assignToVGet_0();
bevt_12_tmpvar_phold = beva_callRet.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = (new BEC_4_6_TextString(20, bels_7));
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_10_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(8, bels_8));
bevt_16_tmpvar_phold = beva_callRet.bem_addValue_1(bevt_17_tmpvar_phold);
bevt_16_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 95 */
 else  /* Line: 96 */ {
bevt_19_tmpvar_phold = (new BEC_4_6_TextString(29, bels_9));
bevt_18_tmpvar_phold = beva_callRet.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_18_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_23_tmpvar_phold = beva_ca.bem_assignToVGet_0();
bevt_22_tmpvar_phold = beva_callRet.bem_addValue_1(bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_addValue_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(20, bels_10));
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_addValue_1(bevt_25_tmpvar_phold);
bevt_20_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_27_tmpvar_phold = (new BEC_4_6_TextString(8, bels_11));
bevt_26_tmpvar_phold = beva_callRet.bem_addValue_1(bevt_27_tmpvar_phold);
bevt_26_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 99 */
} /* Line: 90 */
bevt_29_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_28_tmpvar_phold = beva_callRet.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevt_28_tmpvar_phold.bem_addValue_1(bevt_30_tmpvar_phold);
if (bevl_isGetter.bevi_bool) /* Line: 105 */ {
bevt_32_tmpvar_phold = (new BEC_4_6_TextString(1, bels_12));
bevt_31_tmpvar_phold = beva_callRet.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_31_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 107 */
bevt_33_tmpvar_phold = beva_ca.bem_utPostCheckBBGet_0();
beva_callRet.bem_addValue_1(bevt_33_tmpvar_phold);
bevt_36_tmpvar_phold = beva_ca.bem_utPostCheckCGet_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_sizeGet_0();
bevt_37_tmpvar_phold = bevo_0;
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bem_greater_1(bevt_37_tmpvar_phold);
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 111 */ {
bevt_38_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
beva_callRet.bem_addValue_1(bevt_38_tmpvar_phold);
} /* Line: 112 */
bevt_39_tmpvar_phold = beva_ca.bem_utPostCheckCGet_0();
beva_callRet.bem_addValue_1(bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = beva_ca.bem_utPostCheckEBGet_0();
beva_callRet.bem_addValue_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
beva_callRet.bem_addValue_1(bevt_41_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_standardBlock_2(BEC_5_10_BuildCallCursor beva_ca, BEC_4_6_TextString beva_callRet) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_prepCldefGet_0();
beva_callRet.bem_addValue_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_ca.bem_prepMdefGet_0();
beva_callRet.bem_addValue_1(bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = beva_ca.bem_utPreCheckGet_0();
beva_callRet.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_3_tmpvar_phold = beva_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevt_3_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = beva_ca.bem_utPostCheckBBGet_0();
beva_callRet.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_9_tmpvar_phold = beva_ca.bem_utPostCheckCGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_sizeGet_0();
bevt_10_tmpvar_phold = bevo_1;
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_greater_1(bevt_10_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 126 */ {
bevt_11_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
beva_callRet.bem_addValue_1(bevt_11_tmpvar_phold);
} /* Line: 127 */
bevt_12_tmpvar_phold = beva_ca.bem_utPostCheckCGet_0();
beva_callRet.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = beva_ca.bem_utPostCheckEBGet_0();
beva_callRet.bem_addValue_1(bevt_13_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_standardBlockAssign_2(BEC_5_10_BuildCallCursor beva_ca, BEC_4_6_TextString beva_callRet) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
this.bem_standardBlock_2(beva_ca, beva_callRet);
bevt_0_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
beva_callRet.bem_addValue_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_4_6_TextString bem_processCall_1(BEC_5_10_BuildCallCursor beva_ca) throws Throwable {
BEC_4_6_TextString bevl_nl = null;
BEC_5_5_5_BuildVisitCEmit bevl_emvisit = null;
BEC_4_3_MathInt bevl_onceEvalCount = null;
BEC_6_6_SystemObject bevl_np = null;
BEC_5_14_BuildCCallAssembler bevl_fromType = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_5_9_BuildClassInfo bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_5_9_BuildClassInfo bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_90_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_91_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_92_tmpvar_phold = null;
BEC_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_96_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_5_9_BuildClassInfo bevt_99_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_103_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_104_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_4_6_TextString bevt_107_tmpvar_phold = null;
BEC_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_5_9_BuildClassInfo bevt_109_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_112_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_113_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_114_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_120_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_121_tmpvar_phold = null;
BEC_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_4_6_TextString bevt_124_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_hasOnceAssignGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 139 */ {
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_emvisit = beva_ca.bem_emvisitGet_0();
bevt_4_tmpvar_phold = bevl_emvisit.bem_inClassGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_heldGet_0();
bevl_onceEvalCount = (BEC_4_3_MathInt) bevt_3_tmpvar_phold.bemd_0(1458936917, BEL_4_Base.bevn_onceEvalCountGet_0);
bevt_6_tmpvar_phold = bevl_emvisit.bem_inClassGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_heldGet_0();
bevt_10_tmpvar_phold = bevl_emvisit.bem_inClassGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1458936917, BEL_4_Base.bevn_onceEvalCountGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevt_5_tmpvar_phold.bemd_1(1470019170, BEL_4_Base.bevn_onceEvalCountSet_1, bevt_7_tmpvar_phold);
bevt_13_tmpvar_phold = bevl_emvisit.bem_mtdDeclaredGet_0();
bevt_14_tmpvar_phold = bevo_2;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_has_1(bevt_14_tmpvar_phold);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_not_0();
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 144 */ {
bevt_15_tmpvar_phold = bevl_emvisit.bem_mtdDeclaredGet_0();
bevt_16_tmpvar_phold = (new BEC_4_6_TextString(17, bels_14));
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_15_tmpvar_phold.bem_put_2(bevt_16_tmpvar_phold, bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevl_emvisit.bem_mtdDeclaresGet_0();
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(25, bels_15));
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_18_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_22_tmpvar_phold = bevl_emvisit.bem_postPrepGet_0();
bevt_25_tmpvar_phold = bevo_3;
bevt_27_tmpvar_phold = bevl_emvisit.bem_classInfoGet_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_cldefNameGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_add_1(bevt_26_tmpvar_phold);
bevt_28_tmpvar_phold = bevo_4;
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_addValue_1(bevt_23_tmpvar_phold);
bevt_21_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_30_tmpvar_phold = bevl_emvisit.bem_mtdDeclaresGet_0();
bevt_31_tmpvar_phold = (new BEC_4_6_TextString(26, bels_18));
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_addValue_1(bevt_31_tmpvar_phold);
bevt_29_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_33_tmpvar_phold = bevl_emvisit.bem_postPrepGet_0();
bevt_36_tmpvar_phold = bevo_5;
bevt_38_tmpvar_phold = bevl_emvisit.bem_classInfoGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_cldefNameGet_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_add_1(bevt_37_tmpvar_phold);
bevt_39_tmpvar_phold = bevo_6;
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bem_add_1(bevt_39_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_32_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 151 */
bevt_44_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevt_45_tmpvar_phold = beva_ca.bem_assignToVGet_0();
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_addValue_1(bevt_45_tmpvar_phold);
bevt_46_tmpvar_phold = (new BEC_4_6_TextString(18, bels_21));
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_addValue_1(bevt_46_tmpvar_phold);
bevt_47_tmpvar_phold = bevl_onceEvalCount.bem_toString_0();
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_addValue_1(bevt_47_tmpvar_phold);
bevt_48_tmpvar_phold = (new BEC_4_6_TextString(2, bels_22));
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_addValue_1(bevt_48_tmpvar_phold);
bevt_40_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_54_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevt_55_tmpvar_phold = (new BEC_4_6_TextString(4, bels_23));
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_addValue_1(bevt_55_tmpvar_phold);
bevt_56_tmpvar_phold = beva_ca.bem_embedTargGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_addValue_1(bevt_56_tmpvar_phold);
bevt_57_tmpvar_phold = (new BEC_4_6_TextString(31, bels_24));
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bem_addValue_1(bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = bevl_onceEvalCount.bem_toString_0();
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_59_tmpvar_phold = (new BEC_4_6_TextString(9, bels_25));
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_49_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_65_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevt_66_tmpvar_phold = (new BEC_4_6_TextString(18, bels_26));
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bem_addValue_1(bevt_66_tmpvar_phold);
bevt_67_tmpvar_phold = bevl_onceEvalCount.bem_toString_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_addValue_1(bevt_67_tmpvar_phold);
bevt_68_tmpvar_phold = (new BEC_4_6_TextString(4, bels_27));
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_addValue_1(bevt_68_tmpvar_phold);
bevt_70_tmpvar_phold = beva_ca.bem_asnRGet_0();
bevt_69_tmpvar_phold = bevl_emvisit.bem_formRTarg_1(bevt_70_tmpvar_phold);
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bem_addValue_1(bevt_69_tmpvar_phold);
bevt_71_tmpvar_phold = (new BEC_4_6_TextString(1, bels_28));
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_addValue_1(bevt_71_tmpvar_phold);
bevt_60_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_75_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevt_76_tmpvar_phold = (new BEC_4_6_TextString(19, bels_29));
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bem_addValue_1(bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = bevl_onceEvalCount.bem_toString_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bem_addValue_1(bevt_77_tmpvar_phold);
bevt_78_tmpvar_phold = (new BEC_4_6_TextString(6, bels_30));
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bem_addValue_1(bevt_78_tmpvar_phold);
bevt_72_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_82_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevt_83_tmpvar_phold = (new BEC_4_6_TextString(24, bels_31));
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bem_addValue_1(bevt_83_tmpvar_phold);
bevt_84_tmpvar_phold = beva_ca.bem_embedTargGet_0();
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bem_addValue_1(bevt_84_tmpvar_phold);
bevt_85_tmpvar_phold = (new BEC_4_6_TextString(2, bels_32));
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_addValue_1(bevt_85_tmpvar_phold);
bevt_79_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_87_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevt_88_tmpvar_phold = (new BEC_4_6_TextString(1, bels_33));
bevt_86_tmpvar_phold = bevt_87_tmpvar_phold.bem_addValue_1(bevt_88_tmpvar_phold);
bevt_86_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 158 */
bevt_92_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_91_tmpvar_phold = bevt_92_tmpvar_phold.bem_heldGet_0();
bevt_90_tmpvar_phold = bevt_91_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_93_tmpvar_phold = (new BEC_4_6_TextString(6, bels_34));
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_93_tmpvar_phold);
if (bevt_89_tmpvar_phold != null && bevt_89_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_89_tmpvar_phold).bevi_bool) /* Line: 160 */ {
bevt_94_tmpvar_phold = this.bem_processAssign_1(beva_ca);
return bevt_94_tmpvar_phold;
} /* Line: 161 */
bevt_97_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_96_tmpvar_phold = bevt_97_tmpvar_phold.bem_heldGet_0();
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_95_tmpvar_phold != null && bevt_95_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_95_tmpvar_phold).bevi_bool) /* Line: 164 */ {
bevt_99_tmpvar_phold = beva_ca.bem_ainfoGet_0();
bevt_98_tmpvar_phold = bevt_99_tmpvar_phold.bem_clNameGet_0();
bevl_fromType = (BEC_5_14_BuildCCallAssembler) bevp_fromTypes.bem_get_1(bevt_98_tmpvar_phold);
if (bevl_fromType == null) {
bevt_100_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_100_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_100_tmpvar_phold.bevi_bool) /* Line: 166 */ {
bevt_101_tmpvar_phold = bevl_fromType.bem_processCall_1(beva_ca);
return bevt_101_tmpvar_phold;
} /* Line: 167 */
 else  /* Line: 166 */ {
bevt_104_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bem_heldGet_0();
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_102_tmpvar_phold != null && bevt_102_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_102_tmpvar_phold).bevi_bool) /* Line: 168 */ {
bevt_107_tmpvar_phold = bevo_7;
bevt_109_tmpvar_phold = beva_ca.bem_ainfoGet_0();
bevt_108_tmpvar_phold = bevt_109_tmpvar_phold.bem_clNameGet_0();
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bem_add_1(bevt_108_tmpvar_phold);
bevt_105_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_106_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_105_tmpvar_phold);
} /* Line: 169 */
} /* Line: 166 */
} /* Line: 166 */
bevt_113_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_112_tmpvar_phold = bevt_113_tmpvar_phold.bem_containedGet_0();
bevt_111_tmpvar_phold = bevt_112_tmpvar_phold.bem_firstGet_0();
bevt_110_tmpvar_phold = bevt_111_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_np = bevt_110_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_114_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_114_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_114_tmpvar_phold.bevi_bool) /* Line: 174 */ {
bevt_115_tmpvar_phold = bevl_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_fromType = (BEC_5_14_BuildCCallAssembler) bevp_fromTypes.bem_get_1(bevt_115_tmpvar_phold);
if (bevl_fromType == null) {
bevt_116_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_116_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_116_tmpvar_phold.bevi_bool) /* Line: 176 */ {
bevt_117_tmpvar_phold = bevl_fromType.bem_processCall_1(beva_ca);
return bevt_117_tmpvar_phold;
} /* Line: 177 */
} /* Line: 176 */
 else  /* Line: 174 */ {
bevt_121_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_120_tmpvar_phold = bevt_121_tmpvar_phold.bem_heldGet_0();
bevt_119_tmpvar_phold = bevt_120_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_122_tmpvar_phold = (new BEC_4_6_TextString(5, bels_36));
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_122_tmpvar_phold);
if (bevt_118_tmpvar_phold != null && bevt_118_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_118_tmpvar_phold).bevi_bool) /* Line: 179 */ {
bevt_123_tmpvar_phold = this.bem_processNot_1(beva_ca);
return bevt_123_tmpvar_phold;
} /* Line: 180 */
} /* Line: 174 */
bevt_124_tmpvar_phold = this.bem_standardCall_1(beva_ca);
return bevt_124_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_processAssign_1(BEC_5_10_BuildCallCursor beva_ca) throws Throwable {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_5_BuildBuild bevt_0_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_0_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (new BEC_4_6_TextString()).bem_new_0();
bevt_2_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = beva_ca.bem_typeCheckAssignGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public BEC_4_6_TextString bem_processOptimizedGetter_1(BEC_5_10_BuildCallCursor beva_ca) throws Throwable {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_4_6_TextString bevl_rhs = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_14_tmpvar_phold = null;
BEC_5_8_BuildClassSyn bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_6_BuildMtdSyn bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_9_BuildConstants bevt_19_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_20_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_26_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
bevt_8_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = (new BEC_4_6_TextString(1, bels_37));
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_15_tmpvar_phold = beva_ca.bem_asynGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_ptyMapGet_0();
bevt_17_tmpvar_phold = beva_ca.bem_mtdsGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_propertyNameGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_get_1(bevt_16_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1271927552, BEL_4_Base.bevn_mposGet_0);
bevt_21_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_buildGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_constantsGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_extraSlotsGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_18_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_22_tmpvar_phold = (new BEC_4_6_TextString(1, bels_38));
bevl_rhs = bevt_4_tmpvar_phold.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_24_tmpvar_phold = beva_ca.bem_checkAssignTypesGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_not_0();
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_26_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_27_tmpvar_phold = beva_ca.bem_asnRGet_0();
bevt_28_tmpvar_phold = bevl_rhs.bem_toString_0();
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_finalAssign_3(bevt_27_tmpvar_phold, bevt_28_tmpvar_phold, bevt_29_tmpvar_phold);
bevl_callRet.bem_addValue_1(bevt_25_tmpvar_phold);
} /* Line: 203 */
 else  /* Line: 204 */ {
bevt_33_tmpvar_phold = beva_ca.bem_assignToVGet_0();
bevt_32_tmpvar_phold = bevl_callRet.bem_addValue_1(bevt_33_tmpvar_phold);
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_addValue_1(bevl_rhs);
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(1, bels_39));
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_30_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_35_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_35_tmpvar_phold);
} /* Line: 206 */
bevt_36_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_36_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public BEC_4_6_TextString bem_processOptimizedSetter_1(BEC_5_10_BuildCallCursor beva_ca) throws Throwable {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_5_BuildBuild bevt_0_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_15_tmpvar_phold = null;
BEC_5_8_BuildClassSyn bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_6_BuildMtdSyn bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_5_9_BuildConstants bevt_20_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_21_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_27_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_0_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (new BEC_4_6_TextString()).bem_new_0();
bevt_2_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_9_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_8_tmpvar_phold = bevl_callRet.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = (new BEC_4_6_TextString(1, bels_40));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_16_tmpvar_phold = beva_ca.bem_asynGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_ptyMapGet_0();
bevt_18_tmpvar_phold = beva_ca.bem_mtdsGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_propertyNameGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_get_1(bevt_17_tmpvar_phold);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1271927552, BEL_4_Base.bevn_mposGet_0);
bevt_22_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_buildGet_0();
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_constantsGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_extraSlotsGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_19_tmpvar_phold);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_23_tmpvar_phold = (new BEC_4_6_TextString(4, bels_41));
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_addValue_1(bevt_23_tmpvar_phold);
bevt_25_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_28_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_containedGet_0();
bevt_29_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_get_1(bevt_29_tmpvar_phold);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_formRTarg_1((BEC_5_4_BuildNode) bevt_26_tmpvar_phold);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_addValue_1(bevt_24_tmpvar_phold);
bevt_30_tmpvar_phold = (new BEC_4_6_TextString(1, bels_42));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_addValue_1(bevt_30_tmpvar_phold);
bevt_3_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_31_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_31_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public BEC_4_6_TextString bem_processNot_1(BEC_5_10_BuildCallCursor beva_ca) throws Throwable {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_10_tmpvar_phold = (new BEC_4_6_TextString(13, bels_43));
bevt_9_tmpvar_phold = bevl_callRet.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = (new BEC_4_6_TextString(36, bels_44));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(23, bels_45));
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_5_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(18, bels_46));
bevt_19_tmpvar_phold = bevl_callRet.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (new BEC_4_6_TextString(37, bels_47));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_addValue_1(bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (new BEC_4_6_TextString(22, bels_48));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_addValue_1(bevt_24_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(6, bels_49));
bevl_callRet.bem_addValue_1(bevt_25_tmpvar_phold);
this.bem_standardBlock_2(beva_ca, bevl_callRet);
bevt_28_tmpvar_phold = (new BEC_4_6_TextString(1, bels_50));
bevt_27_tmpvar_phold = bevl_callRet.bem_addValue_1(bevt_28_tmpvar_phold);
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_29_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevt_26_tmpvar_phold.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_30_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public BEC_9_3_ContainerMap bem_fromTypesGet_0() throws Throwable {
return bevp_fromTypes;
} /*method end*/
public BEC_6_6_SystemObject bem_fromTypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromTypes = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_build = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nl = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {29, 36, 38, 39, 39, 41, 42, 42, 44, 45, 45, 47, 48, 48, 53, 54, 60, 61, 61, 61, 61, 61, 0, 0, 0, 62, 62, 62, 62, 62, 63, 63, 64, 64, 64, 64, 64, 64, 64, 64, 64, 0, 0, 0, 64, 64, 64, 0, 0, 0, 65, 65, 71, 72, 72, 73, 74, 74, 75, 79, 79, 79, 80, 82, 82, 83, 83, 84, 84, 85, 85, 87, 87, 90, 92, 92, 92, 93, 93, 93, 93, 93, 93, 93, 95, 95, 95, 97, 97, 97, 98, 98, 98, 98, 98, 98, 98, 99, 99, 99, 103, 103, 103, 103, 107, 107, 107, 110, 110, 111, 111, 111, 111, 112, 112, 114, 114, 115, 115, 116, 116, 121, 121, 122, 122, 123, 123, 124, 124, 124, 124, 125, 125, 126, 126, 126, 126, 127, 127, 129, 129, 130, 130, 134, 135, 135, 139, 140, 140, 140, 141, 142, 142, 142, 143, 143, 143, 143, 143, 143, 143, 144, 144, 144, 144, 145, 145, 145, 145, 147, 147, 147, 147, 148, 148, 148, 148, 148, 148, 148, 148, 148, 150, 150, 150, 150, 151, 151, 151, 151, 151, 151, 151, 151, 151, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 154, 154, 154, 154, 154, 154, 154, 154, 154, 154, 154, 154, 155, 155, 155, 155, 155, 155, 155, 155, 155, 155, 155, 155, 155, 156, 156, 156, 156, 156, 156, 156, 156, 157, 157, 157, 157, 157, 157, 157, 157, 158, 158, 158, 158, 160, 160, 160, 160, 160, 161, 161, 164, 164, 164, 165, 165, 165, 166, 166, 167, 167, 168, 168, 168, 169, 169, 169, 169, 169, 169, 173, 173, 173, 173, 173, 174, 174, 175, 175, 176, 176, 177, 177, 179, 179, 179, 179, 179, 180, 180, 182, 182, 186, 186, 186, 187, 188, 188, 189, 189, 190, 190, 191, 196, 196, 198, 198, 198, 199, 200, 200, 201, 201, 201, 201, 201, 201, 201, 201, 201, 201, 201, 201, 201, 201, 201, 201, 201, 201, 201, 201, 202, 202, 203, 203, 203, 203, 203, 203, 205, 205, 205, 205, 205, 205, 206, 206, 208, 208, 209, 213, 213, 213, 214, 215, 215, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 217, 217, 218, 223, 223, 225, 225, 225, 226, 227, 227, 228, 228, 229, 229, 229, 229, 229, 229, 229, 229, 229, 229, 229, 230, 230, 230, 230, 230, 230, 230, 230, 230, 230, 230, 231, 231, 232, 233, 233, 233, 233, 233, 234, 234, 235, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 93, 94, 128, 130, 131, 132, 134, 135, 137, 140, 144, 147, 148, 149, 150, 151, 153, 154, 157, 158, 159, 160, 161, 163, 164, 165, 166, 168, 171, 175, 178, 179, 184, 185, 188, 192, 195, 196, 203, 204, 205, 206, 207, 208, 209, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 271, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 303, 304, 305, 306, 308, 309, 310, 312, 313, 314, 315, 316, 317, 319, 320, 322, 323, 324, 325, 326, 327, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 362, 363, 365, 366, 367, 368, 373, 374, 375, 509, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 617, 618, 619, 620, 621, 623, 624, 626, 627, 628, 630, 631, 632, 633, 638, 639, 640, 643, 644, 645, 647, 648, 649, 650, 651, 652, 656, 657, 658, 659, 660, 661, 666, 667, 668, 669, 674, 675, 676, 680, 681, 682, 683, 684, 686, 687, 690, 691, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 785, 786, 787, 788, 789, 790, 793, 794, 795, 796, 797, 798, 799, 800, 802, 803, 804, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 959, 962, 966, 969, 973, 976};
/* BEGIN LINEINFO 
loadBuild 1 29 76
assign 1 36 77
new 0 36 77
assign 1 38 78
new 1 38 78
assign 1 39 79
new 0 39 79
put 2 39 80
assign 1 41 81
new 1 41 81
assign 1 42 82
new 0 42 82
put 2 42 83
assign 1 44 84
new 1 44 84
assign 1 45 85
new 0 45 85
put 2 45 86
assign 1 47 87
new 1 47 87
assign 1 48 88
new 0 48 88
put 2 48 89
assign 1 53 93
assign 1 54 94
nlGet 0 54 94
assign 1 60 128
optimizedCallGet 0 60 128
assign 1 61 130
nodeGet 0 61 130
assign 1 61 131
heldGet 0 61 131
assign 1 61 132
wasAccessorGet 0 61 132
assign 1 61 134
mtdsGet 0 61 134
assign 1 61 135
isGenAccessorGet 0 61 135
assign 1 0 137
assign 1 0 140
assign 1 0 144
assign 1 62 147
nodeGet 0 62 147
assign 1 62 148
heldGet 0 62 148
assign 1 62 149
accessorTypeGet 0 62 149
assign 1 62 150
new 0 62 150
assign 1 62 151
equals 1 62 151
assign 1 63 153
processOptimizedGetter 1 63 153
return 1 63 154
assign 1 64 157
nodeGet 0 64 157
assign 1 64 158
heldGet 0 64 158
assign 1 64 159
accessorTypeGet 0 64 159
assign 1 64 160
new 0 64 160
assign 1 64 161
equals 1 64 161
assign 1 64 163
nodeGet 0 64 163
assign 1 64 164
heldGet 0 64 164
assign 1 64 165
checkTypesGet 0 64 165
assign 1 64 166
not 0 64 166
assign 1 0 168
assign 1 0 171
assign 1 0 175
assign 1 64 178
asnRGet 0 64 178
assign 1 64 179
undef 1 64 184
assign 1 0 185
assign 1 0 188
assign 1 0 192
assign 1 65 195
processOptimizedSetter 1 65 195
return 1 65 196
assign 1 71 203
new 0 71 203
assign 1 72 204
preOnceEvalGet 0 72 204
addValue 1 72 205
accessorCheckBlock 2 73 206
assign 1 74 207
postOnceEvalGet 0 74 207
addValue 1 74 208
return 1 75 209
assign 1 79 256
emvisitGet 0 79 256
assign 1 79 257
buildGet 0 79 257
assign 1 79 258
nlGet 0 79 258
assign 1 80 259
isGetterGet 0 80 259
assign 1 82 260
prepCldefGet 0 82 260
addValue 1 82 261
assign 1 83 262
prepMdefGet 0 83 262
addValue 1 83 263
assign 1 84 264
callArgsGet 0 84 264
addValue 1 84 265
assign 1 85 266
utPreCheckGet 0 85 266
addValue 1 85 267
assign 1 87 268
isValidGet 0 87 268
assertTrue 1 87 269
assign 1 90 271
isTypedGet 0 90 271
assign 1 92 273
new 0 92 273
assign 1 92 274
addValue 1 92 274
addValue 1 92 275
assign 1 93 276
assignToVGet 0 93 276
assign 1 93 277
addValue 1 93 277
assign 1 93 278
targsGet 0 93 278
assign 1 93 279
addValue 1 93 279
assign 1 93 280
new 0 93 280
assign 1 93 281
addValue 1 93 281
addValue 1 93 282
assign 1 95 283
new 0 95 283
assign 1 95 284
addValue 1 95 284
addValue 1 95 285
assign 1 97 288
new 0 97 288
assign 1 97 289
addValue 1 97 289
addValue 1 97 290
assign 1 98 291
assignToVGet 0 98 291
assign 1 98 292
addValue 1 98 292
assign 1 98 293
targsGet 0 98 293
assign 1 98 294
addValue 1 98 294
assign 1 98 295
new 0 98 295
assign 1 98 296
addValue 1 98 296
addValue 1 98 297
assign 1 99 298
new 0 99 298
assign 1 99 299
addValue 1 99 299
addValue 1 99 300
assign 1 103 303
assignToVVGet 0 103 303
assign 1 103 304
addValue 1 103 304
assign 1 103 305
tcallGet 0 103 305
addValue 1 103 306
assign 1 107 308
new 0 107 308
assign 1 107 309
addValue 1 107 309
addValue 1 107 310
assign 1 110 312
utPostCheckBBGet 0 110 312
addValue 1 110 313
assign 1 111 314
utPostCheckCGet 0 111 314
assign 1 111 315
sizeGet 0 111 315
assign 1 111 316
new 0 111 316
assign 1 111 317
greater 1 111 317
assign 1 112 319
assignToVVGet 0 112 319
addValue 1 112 320
assign 1 114 322
utPostCheckCGet 0 114 322
addValue 1 114 323
assign 1 115 324
utPostCheckEBGet 0 115 324
addValue 1 115 325
assign 1 116 326
assignToCheckGet 0 116 326
addValue 1 116 327
assign 1 121 345
prepCldefGet 0 121 345
addValue 1 121 346
assign 1 122 347
prepMdefGet 0 122 347
addValue 1 122 348
assign 1 123 349
utPreCheckGet 0 123 349
addValue 1 123 350
assign 1 124 351
assignToVVGet 0 124 351
assign 1 124 352
addValue 1 124 352
assign 1 124 353
tcallGet 0 124 353
addValue 1 124 354
assign 1 125 355
utPostCheckBBGet 0 125 355
addValue 1 125 356
assign 1 126 357
utPostCheckCGet 0 126 357
assign 1 126 358
sizeGet 0 126 358
assign 1 126 359
new 0 126 359
assign 1 126 360
greater 1 126 360
assign 1 127 362
assignToVVGet 0 127 362
addValue 1 127 363
assign 1 129 365
utPostCheckCGet 0 129 365
addValue 1 129 366
assign 1 130 367
utPostCheckEBGet 0 130 367
addValue 1 130 368
standardBlock 2 134 373
assign 1 135 374
assignToCheckGet 0 135 374
addValue 1 135 375
assign 1 139 509
hasOnceAssignGet 0 139 509
assign 1 140 511
emvisitGet 0 140 511
assign 1 140 512
buildGet 0 140 512
assign 1 140 513
nlGet 0 140 513
assign 1 141 514
emvisitGet 0 141 514
assign 1 142 515
inClassGet 0 142 515
assign 1 142 516
heldGet 0 142 516
assign 1 142 517
onceEvalCountGet 0 142 517
assign 1 143 518
inClassGet 0 143 518
assign 1 143 519
heldGet 0 143 519
assign 1 143 520
inClassGet 0 143 520
assign 1 143 521
heldGet 0 143 521
assign 1 143 522
onceEvalCountGet 0 143 522
assign 1 143 523
increment 0 143 523
onceEvalCountSet 1 143 524
assign 1 144 525
mtdDeclaredGet 0 144 525
assign 1 144 526
new 0 144 526
assign 1 144 527
has 1 144 527
assign 1 144 528
not 0 144 528
assign 1 145 530
mtdDeclaredGet 0 145 530
assign 1 145 531
new 0 145 531
assign 1 145 532
new 0 145 532
put 2 145 533
assign 1 147 534
mtdDeclaresGet 0 147 534
assign 1 147 535
new 0 147 535
assign 1 147 536
addValue 1 147 536
addValue 1 147 537
assign 1 148 538
postPrepGet 0 148 538
assign 1 148 539
new 0 148 539
assign 1 148 540
classInfoGet 0 148 540
assign 1 148 541
cldefNameGet 0 148 541
assign 1 148 542
add 1 148 542
assign 1 148 543
new 0 148 543
assign 1 148 544
add 1 148 544
assign 1 148 545
addValue 1 148 545
addValue 1 148 546
assign 1 150 547
mtdDeclaresGet 0 150 547
assign 1 150 548
new 0 150 548
assign 1 150 549
addValue 1 150 549
addValue 1 150 550
assign 1 151 551
postPrepGet 0 151 551
assign 1 151 552
new 0 151 552
assign 1 151 553
classInfoGet 0 151 553
assign 1 151 554
cldefNameGet 0 151 554
assign 1 151 555
add 1 151 555
assign 1 151 556
new 0 151 556
assign 1 151 557
add 1 151 557
assign 1 151 558
addValue 1 151 558
addValue 1 151 559
assign 1 153 561
preOnceEvalGet 0 153 561
assign 1 153 562
assignToVGet 0 153 562
assign 1 153 563
addValue 1 153 563
assign 1 153 564
new 0 153 564
assign 1 153 565
addValue 1 153 565
assign 1 153 566
toString 0 153 566
assign 1 153 567
addValue 1 153 567
assign 1 153 568
new 0 153 568
assign 1 153 569
addValue 1 153 569
addValue 1 153 570
assign 1 154 571
preOnceEvalGet 0 154 571
assign 1 154 572
new 0 154 572
assign 1 154 573
addValue 1 154 573
assign 1 154 574
embedTargGet 0 154 574
assign 1 154 575
addValue 1 154 575
assign 1 154 576
new 0 154 576
assign 1 154 577
addValue 1 154 577
assign 1 154 578
toString 0 154 578
assign 1 154 579
addValue 1 154 579
assign 1 154 580
new 0 154 580
assign 1 154 581
addValue 1 154 581
addValue 1 154 582
assign 1 155 583
postOnceEvalGet 0 155 583
assign 1 155 584
new 0 155 584
assign 1 155 585
addValue 1 155 585
assign 1 155 586
toString 0 155 586
assign 1 155 587
addValue 1 155 587
assign 1 155 588
new 0 155 588
assign 1 155 589
addValue 1 155 589
assign 1 155 590
asnRGet 0 155 590
assign 1 155 591
formRTarg 1 155 591
assign 1 155 592
addValue 1 155 592
assign 1 155 593
new 0 155 593
assign 1 155 594
addValue 1 155 594
addValue 1 155 595
assign 1 156 596
postOnceEvalGet 0 156 596
assign 1 156 597
new 0 156 597
assign 1 156 598
addValue 1 156 598
assign 1 156 599
toString 0 156 599
assign 1 156 600
addValue 1 156 600
assign 1 156 601
new 0 156 601
assign 1 156 602
addValue 1 156 602
addValue 1 156 603
assign 1 157 604
postOnceEvalGet 0 157 604
assign 1 157 605
new 0 157 605
assign 1 157 606
addValue 1 157 606
assign 1 157 607
embedTargGet 0 157 607
assign 1 157 608
addValue 1 157 608
assign 1 157 609
new 0 157 609
assign 1 157 610
addValue 1 157 610
addValue 1 157 611
assign 1 158 612
postOnceEvalGet 0 158 612
assign 1 158 613
new 0 158 613
assign 1 158 614
addValue 1 158 614
addValue 1 158 615
assign 1 160 617
nodeGet 0 160 617
assign 1 160 618
heldGet 0 160 618
assign 1 160 619
orgNameGet 0 160 619
assign 1 160 620
new 0 160 620
assign 1 160 621
equals 1 160 621
assign 1 161 623
processAssign 1 161 623
return 1 161 624
assign 1 164 626
nodeGet 0 164 626
assign 1 164 627
heldGet 0 164 627
assign 1 164 628
isConstructGet 0 164 628
assign 1 165 630
ainfoGet 0 165 630
assign 1 165 631
clNameGet 0 165 631
assign 1 165 632
get 1 165 632
assign 1 166 633
def 1 166 638
assign 1 167 639
processCall 1 167 639
return 1 167 640
assign 1 168 643
nodeGet 0 168 643
assign 1 168 644
heldGet 0 168 644
assign 1 168 645
isLiteralGet 0 168 645
assign 1 169 647
new 0 169 647
assign 1 169 648
ainfoGet 0 169 648
assign 1 169 649
clNameGet 0 169 649
assign 1 169 650
add 1 169 650
assign 1 169 651
new 1 169 651
throw 1 169 652
assign 1 173 656
nodeGet 0 173 656
assign 1 173 657
containedGet 0 173 657
assign 1 173 658
firstGet 0 173 658
assign 1 173 659
heldGet 0 173 659
assign 1 173 660
namepathGet 0 173 660
assign 1 174 661
def 1 174 666
assign 1 175 667
toString 0 175 667
assign 1 175 668
get 1 175 668
assign 1 176 669
def 1 176 674
assign 1 177 675
processCall 1 177 675
return 1 177 676
assign 1 179 680
nodeGet 0 179 680
assign 1 179 681
heldGet 0 179 681
assign 1 179 682
nameGet 0 179 682
assign 1 179 683
new 0 179 683
assign 1 179 684
equals 1 179 684
assign 1 180 686
processNot 1 180 686
return 1 180 687
assign 1 182 690
standardCall 1 182 690
return 1 182 691
assign 1 186 701
emvisitGet 0 186 701
assign 1 186 702
buildGet 0 186 702
assign 1 186 703
nlGet 0 186 703
assign 1 187 704
new 0 187 704
assign 1 188 705
preOnceEvalGet 0 188 705
addValue 1 188 706
assign 1 189 707
typeCheckAssignGet 0 189 707
addValue 1 189 708
assign 1 190 709
postOnceEvalGet 0 190 709
addValue 1 190 710
return 1 191 711
assign 1 196 754
isValidGet 0 196 754
assertTrue 1 196 755
assign 1 198 756
emvisitGet 0 198 756
assign 1 198 757
buildGet 0 198 757
assign 1 198 758
nlGet 0 198 758
assign 1 199 759
new 0 199 759
assign 1 200 760
preOnceEvalGet 0 200 760
addValue 1 200 761
assign 1 201 762
new 0 201 762
assign 1 201 763
targsGet 0 201 763
assign 1 201 764
addValue 1 201 764
assign 1 201 765
new 0 201 765
assign 1 201 766
addValue 1 201 766
assign 1 201 767
asynGet 0 201 767
assign 1 201 768
ptyMapGet 0 201 768
assign 1 201 769
mtdsGet 0 201 769
assign 1 201 770
propertyNameGet 0 201 770
assign 1 201 771
get 1 201 771
assign 1 201 772
mposGet 0 201 772
assign 1 201 773
emvisitGet 0 201 773
assign 1 201 774
buildGet 0 201 774
assign 1 201 775
constantsGet 0 201 775
assign 1 201 776
extraSlotsGet 0 201 776
assign 1 201 777
add 1 201 777
assign 1 201 778
toString 0 201 778
assign 1 201 779
addValue 1 201 779
assign 1 201 780
new 0 201 780
assign 1 201 781
addValue 1 201 781
assign 1 202 782
checkAssignTypesGet 0 202 782
assign 1 202 783
not 0 202 783
assign 1 203 785
emvisitGet 0 203 785
assign 1 203 786
asnRGet 0 203 786
assign 1 203 787
toString 0 203 787
assign 1 203 788
new 0 203 788
assign 1 203 789
finalAssign 3 203 789
addValue 1 203 790
assign 1 205 793
assignToVGet 0 205 793
assign 1 205 794
addValue 1 205 794
assign 1 205 795
addValue 1 205 795
assign 1 205 796
new 0 205 796
assign 1 205 797
addValue 1 205 797
addValue 1 205 798
assign 1 206 799
assignToCheckGet 0 206 799
addValue 1 206 800
assign 1 208 802
postOnceEvalGet 0 208 802
addValue 1 208 803
return 1 209 804
assign 1 213 841
emvisitGet 0 213 841
assign 1 213 842
buildGet 0 213 842
assign 1 213 843
nlGet 0 213 843
assign 1 214 844
new 0 214 844
assign 1 215 845
preOnceEvalGet 0 215 845
addValue 1 215 846
assign 1 216 847
targsGet 0 216 847
assign 1 216 848
addValue 1 216 848
assign 1 216 849
new 0 216 849
assign 1 216 850
addValue 1 216 850
assign 1 216 851
asynGet 0 216 851
assign 1 216 852
ptyMapGet 0 216 852
assign 1 216 853
mtdsGet 0 216 853
assign 1 216 854
propertyNameGet 0 216 854
assign 1 216 855
get 1 216 855
assign 1 216 856
mposGet 0 216 856
assign 1 216 857
emvisitGet 0 216 857
assign 1 216 858
buildGet 0 216 858
assign 1 216 859
constantsGet 0 216 859
assign 1 216 860
extraSlotsGet 0 216 860
assign 1 216 861
add 1 216 861
assign 1 216 862
toString 0 216 862
assign 1 216 863
addValue 1 216 863
assign 1 216 864
new 0 216 864
assign 1 216 865
addValue 1 216 865
assign 1 216 866
emvisitGet 0 216 866
assign 1 216 867
nodeGet 0 216 867
assign 1 216 868
containedGet 0 216 868
assign 1 216 869
new 0 216 869
assign 1 216 870
get 1 216 870
assign 1 216 871
formRTarg 1 216 871
assign 1 216 872
addValue 1 216 872
assign 1 216 873
new 0 216 873
assign 1 216 874
addValue 1 216 874
addValue 1 216 875
assign 1 217 876
postOnceEvalGet 0 217 876
addValue 1 217 877
return 1 218 878
assign 1 223 914
isValidGet 0 223 914
assertTrue 1 223 915
assign 1 225 916
emvisitGet 0 225 916
assign 1 225 917
buildGet 0 225 917
assign 1 225 918
nlGet 0 225 918
assign 1 226 919
new 0 226 919
assign 1 227 920
preOnceEvalGet 0 227 920
addValue 1 227 921
assign 1 228 922
callArgsGet 0 228 922
addValue 1 228 923
assign 1 229 924
new 0 229 924
assign 1 229 925
addValue 1 229 925
assign 1 229 926
targsGet 0 229 926
assign 1 229 927
addValue 1 229 927
assign 1 229 928
new 0 229 928
assign 1 229 929
addValue 1 229 929
assign 1 229 930
assignToVVGet 0 229 930
assign 1 229 931
addValue 1 229 931
assign 1 229 932
new 0 229 932
assign 1 229 933
addValue 1 229 933
addValue 1 229 934
assign 1 230 935
new 0 230 935
assign 1 230 936
addValue 1 230 936
assign 1 230 937
targsGet 0 230 937
assign 1 230 938
addValue 1 230 938
assign 1 230 939
new 0 230 939
assign 1 230 940
addValue 1 230 940
assign 1 230 941
assignToVVGet 0 230 941
assign 1 230 942
addValue 1 230 942
assign 1 230 943
new 0 230 943
assign 1 230 944
addValue 1 230 944
addValue 1 230 945
assign 1 231 946
new 0 231 946
addValue 1 231 947
standardBlock 2 232 948
assign 1 233 949
new 0 233 949
assign 1 233 950
addValue 1 233 950
assign 1 233 951
addValue 1 233 951
assign 1 233 952
assignToCheckGet 0 233 952
addValue 1 233 953
assign 1 234 954
postOnceEvalGet 0 234 954
addValue 1 234 955
return 1 235 956
return 1 0 959
assign 1 0 962
return 1 0 966
assign 1 0 969
return 1 0 973
assign 1 0 976
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 2001798761: return bem_nlGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1178476504: return bem_fromTypesGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 846242271: return bem_processCall_1((BEC_5_10_BuildCallCursor) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 281832742: return bem_loadBuild_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 1189558757: return bem_fromTypesSet_1(bevd_0);
case 224779883: return bem_processOptimizedGetter_1((BEC_5_10_BuildCallCursor) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1292480624: return bem_processAssign_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1833349037: return bem_standardCall_1((BEC_5_10_BuildCallCursor) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1977543830: return bem_processNot_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 785892343: return bem_processOptimizedSetter_1((BEC_5_10_BuildCallCursor) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 19297983: return bem_accessorCheckBlock_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 429177731: return bem_standardBlock_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 436992814: return bem_standardBlockAssign_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_14_BuildCCallAssembler();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_14_BuildCCallAssembler.bevs_inst = (BEC_5_14_BuildCCallAssembler)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_14_BuildCCallAssembler.bevs_inst;
}
}
