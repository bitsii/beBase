package be.BEL_4_Base;
/* File: source/build/BuildTypes.be */
public class BEC_5_3_BuildVar extends BEC_6_6_SystemObject {
public BEC_5_3_BuildVar() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(-1));
private static byte[] bels_0 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_0, 7));
private static byte[] bels_1 = {0x20,0x69,0x73,0x41,0x72,0x67};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_1, 6));
private static byte[] bels_2 = {0x20,0x69,0x73,0x54,0x6D,0x70,0x56,0x61,0x72};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_2, 9));
private static byte[] bels_3 = {0x20,0x6E,0x6F,0x74,0x44,0x65,0x63,0x6C,0x61,0x72,0x65,0x64};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_3, 12));
private static byte[] bels_4 = {0x20,0x69,0x73,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_4, 11));
public static BEC_5_3_BuildVar bevs_inst;
public BEC_4_6_TextString bevp_name;
public BEC_5_8_BuildNamePath bevp_namepath;
public BEC_6_6_SystemObject bevp_refs;
public BEC_9_3_ContainerMap bevp_allCalls;
public BEC_4_6_TextString bevp_suffix;
public BEC_5_4_LogicBool bevp_isArg;
public BEC_5_4_LogicBool bevp_isAdded;
public BEC_5_4_LogicBool bevp_isTmpVar;
public BEC_5_4_LogicBool bevp_isDeclared;
public BEC_5_4_LogicBool bevp_isProperty;
public BEC_4_3_MathInt bevp_numAssigns;
public BEC_5_4_LogicBool bevp_isTyped;
public BEC_4_3_MathInt bevp_vpos;
public BEC_5_4_LogicBool bevp_isSelf;
public BEC_4_3_MathInt bevp_maxCpos;
public BEC_4_3_MathInt bevp_minCpos;
public BEC_4_6_TextString bevp_nativeName;
public BEC_5_3_BuildVar bem_new_0() throws Throwable {
BEC_4_4_MathInts bevt_0_tmpvar_phold = null;
bevp_isArg = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isAdded = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isTmpVar = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isDeclared = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_isProperty = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_numAssigns = (new BEC_4_3_MathInt(0));
bevp_isTyped = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_vpos = (new BEC_4_3_MathInt(-1));
bevp_isSelf = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_maxCpos = (new BEC_4_3_MathInt(-1));
bevt_0_tmpvar_phold = (BEC_4_4_MathInts) BEC_4_4_MathInts.bevs_inst.bem_new_0();
bevp_minCpos = bevt_0_tmpvar_phold.bem_maxGet_0();
return this;
} /*method end*/
public BEC_5_3_BuildVar bem_synNew_1(BEC_5_3_BuildVar beva_full) throws Throwable {
bevp_isArg = beva_full.bem_isArgGet_0();
bevp_name = beva_full.bem_nameGet_0();
bevp_isAdded = beva_full.bem_isAddedGet_0();
bevp_isTmpVar = beva_full.bem_isTmpVarGet_0();
bevp_isProperty = beva_full.bem_isPropertyGet_0();
bevp_numAssigns = (new BEC_4_3_MathInt(0));
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_vpos = beva_full.bem_vposGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addCall_1(BEC_5_4_BuildNode beva_call) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_allCalls == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevp_allCalls = (new BEC_9_3_ContainerMap()).bem_new_0();
} /* Line: 240 */
bevp_allCalls.bem_put_2(beva_call, beva_call);
return this;
} /*method end*/
public BEC_4_3_MathInt bem_maxCposGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_kv = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevp_maxCpos.bem_greater_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 246 */ {
return bevp_maxCpos;
} /* Line: 246 */
bevt_0_tmpvar_loop = bevp_allCalls.bem_iteratorGet_0();
while (true)
 /* Line: 247 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 247 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_7_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(2128364298, BEL_4_Base.bevn_cposGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevp_maxCpos);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevt_9_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_maxCpos = (BEC_4_3_MathInt) bevt_8_tmpvar_phold.bemd_0(2128364298, BEL_4_Base.bevn_cposGet_0);
} /* Line: 249 */
} /* Line: 248 */
 else  /* Line: 247 */ {
break;
} /* Line: 247 */
} /* Line: 247 */
return bevp_maxCpos;
} /*method end*/
public BEC_4_3_MathInt bem_minCposGet_0() throws Throwable {
BEC_4_3_MathInt bevl_bigun = null;
BEC_6_6_SystemObject bevl_kv = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_4_4_MathInts bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_4_MathInts) BEC_4_4_MathInts.bevs_inst.bem_new_0();
bevl_bigun = bevt_1_tmpvar_phold.bem_maxGet_0();
bevt_2_tmpvar_phold = bevp_minCpos.bem_lesser_1(bevl_bigun);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 258 */ {
return bevp_minCpos;
} /* Line: 258 */
bevt_0_tmpvar_loop = bevp_allCalls.bem_iteratorGet_0();
while (true)
 /* Line: 259 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 259 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_7_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(2128364298, BEL_4_Base.bevn_cposGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevp_minCpos);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevt_9_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_minCpos = (BEC_4_3_MathInt) bevt_8_tmpvar_phold.bemd_0(2128364298, BEL_4_Base.bevn_cposGet_0);
} /* Line: 261 */
} /* Line: 260 */
 else  /* Line: 259 */ {
break;
} /* Line: 259 */
} /* Line: 259 */
return bevp_minCpos;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_4_6_TextString bevl_ret = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
bevl_ret = this.bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_2_tmpvar_phold = bevo_1;
bevt_1_tmpvar_phold = bevl_ret.bem_add_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_1_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
} /* Line: 270 */
if (bevp_isArg.bevi_bool) /* Line: 272 */ {
bevt_4_tmpvar_phold = bevo_2;
bevl_ret = bevl_ret.bem_add_1(bevt_4_tmpvar_phold);
} /* Line: 273 */
if (bevp_isTmpVar.bevi_bool) /* Line: 275 */ {
bevt_5_tmpvar_phold = bevo_3;
bevl_ret = bevl_ret.bem_add_1(bevt_5_tmpvar_phold);
} /* Line: 276 */
bevt_6_tmpvar_phold = bevp_isDeclared.bem_not_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_7_tmpvar_phold = bevo_4;
bevl_ret = bevl_ret.bem_add_1(bevt_7_tmpvar_phold);
} /* Line: 279 */
if (bevp_isProperty.bevi_bool) /* Line: 281 */ {
bevt_8_tmpvar_phold = bevo_5;
bevl_ret = bevl_ret.bem_add_1(bevt_8_tmpvar_phold);
} /* Line: 282 */
return bevl_ret;
} /*method end*/
public BEC_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_6_6_SystemObject bem_nameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_name = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_6_6_SystemObject bem_namepathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_namepath = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_refsGet_0() throws Throwable {
return bevp_refs;
} /*method end*/
public BEC_6_6_SystemObject bem_refsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_refs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerMap bem_allCallsGet_0() throws Throwable {
return bevp_allCalls;
} /*method end*/
public BEC_6_6_SystemObject bem_allCallsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allCalls = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_suffixGet_0() throws Throwable {
return bevp_suffix;
} /*method end*/
public BEC_6_6_SystemObject bem_suffixSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_suffix = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isArgGet_0() throws Throwable {
return bevp_isArg;
} /*method end*/
public BEC_6_6_SystemObject bem_isArgSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isArg = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isAddedGet_0() throws Throwable {
return bevp_isAdded;
} /*method end*/
public BEC_6_6_SystemObject bem_isAddedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isAdded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isTmpVarGet_0() throws Throwable {
return bevp_isTmpVar;
} /*method end*/
public BEC_6_6_SystemObject bem_isTmpVarSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isTmpVar = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isDeclaredGet_0() throws Throwable {
return bevp_isDeclared;
} /*method end*/
public BEC_6_6_SystemObject bem_isDeclaredSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isDeclared = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isPropertyGet_0() throws Throwable {
return bevp_isProperty;
} /*method end*/
public BEC_6_6_SystemObject bem_isPropertySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isProperty = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_numAssignsGet_0() throws Throwable {
return bevp_numAssigns;
} /*method end*/
public BEC_6_6_SystemObject bem_numAssignsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_numAssigns = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isTypedGet_0() throws Throwable {
return bevp_isTyped;
} /*method end*/
public BEC_6_6_SystemObject bem_isTypedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isTyped = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_vposGet_0() throws Throwable {
return bevp_vpos;
} /*method end*/
public BEC_6_6_SystemObject bem_vposSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_vpos = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isSelfGet_0() throws Throwable {
return bevp_isSelf;
} /*method end*/
public BEC_6_6_SystemObject bem_isSelfSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isSelf = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_maxCposSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_maxCpos = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_minCposSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_minCpos = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_nativeNameGet_0() throws Throwable {
return bevp_nativeName;
} /*method end*/
public BEC_6_6_SystemObject bem_nativeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nativeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 219, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 239, 239, 240, 242, 246, 246, 246, 247, 0, 247, 247, 248, 248, 248, 248, 249, 249, 249, 252, 256, 256, 258, 258, 259, 0, 259, 259, 260, 260, 260, 260, 261, 261, 261, 264, 268, 269, 269, 270, 270, 270, 270, 273, 273, 276, 276, 278, 279, 279, 282, 282, 284, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 67, 72, 73, 75, 90, 91, 93, 95, 95, 98, 100, 101, 102, 103, 104, 106, 107, 108, 115, 130, 131, 132, 134, 136, 136, 139, 141, 142, 143, 144, 145, 147, 148, 149, 156, 169, 170, 175, 176, 177, 178, 179, 182, 183, 186, 187, 189, 191, 192, 195, 196, 198, 201, 204, 208, 211, 215, 218, 222, 225, 229, 232, 236, 239, 243, 246, 250, 253, 257, 260, 264, 267, 271, 274, 278, 281, 285, 288, 292, 295, 299, 303, 307, 310};
/* BEGIN LINEINFO 
assign 1 209 38
new 0 209 38
assign 1 210 39
new 0 210 39
assign 1 211 40
new 0 211 40
assign 1 212 41
new 0 212 41
assign 1 213 42
new 0 213 42
assign 1 214 43
new 0 214 43
assign 1 215 44
new 0 215 44
assign 1 216 45
new 0 216 45
assign 1 217 46
new 0 217 46
assign 1 218 47
new 0 218 47
assign 1 219 48
new 0 219 48
assign 1 219 49
maxGet 0 219 49
assign 1 226 53
isArgGet 0 226 53
assign 1 227 54
nameGet 0 227 54
assign 1 228 55
isAddedGet 0 228 55
assign 1 229 56
isTmpVarGet 0 229 56
assign 1 230 57
isPropertyGet 0 230 57
assign 1 231 58
new 0 231 58
assign 1 232 59
namepathGet 0 232 59
assign 1 233 60
isTypedGet 0 233 60
assign 1 234 61
vposGet 0 234 61
assign 1 235 62
isSelfGet 0 235 62
assign 1 239 67
undef 1 239 72
assign 1 240 73
new 0 240 73
put 2 242 75
assign 1 246 90
new 0 246 90
assign 1 246 91
greater 1 246 91
return 1 246 93
assign 1 247 95
iteratorGet 0 0 95
assign 1 247 98
hasNextGet 0 247 98
assign 1 247 100
nextGet 0 247 100
assign 1 248 101
keyGet 0 248 101
assign 1 248 102
heldGet 0 248 102
assign 1 248 103
cposGet 0 248 103
assign 1 248 104
greater 1 248 104
assign 1 249 106
keyGet 0 249 106
assign 1 249 107
heldGet 0 249 107
assign 1 249 108
cposGet 0 249 108
return 1 252 115
assign 1 256 130
new 0 256 130
assign 1 256 131
maxGet 0 256 131
assign 1 258 132
lesser 1 258 132
return 1 258 134
assign 1 259 136
iteratorGet 0 0 136
assign 1 259 139
hasNextGet 0 259 139
assign 1 259 141
nextGet 0 259 141
assign 1 260 142
keyGet 0 260 142
assign 1 260 143
heldGet 0 260 143
assign 1 260 144
cposGet 0 260 144
assign 1 260 145
lesser 1 260 145
assign 1 261 147
keyGet 0 261 147
assign 1 261 148
heldGet 0 261 148
assign 1 261 149
cposGet 0 261 149
return 1 264 156
assign 1 268 169
classNameGet 0 268 169
assign 1 269 170
def 1 269 175
assign 1 270 176
new 0 270 176
assign 1 270 177
add 1 270 177
assign 1 270 178
toString 0 270 178
assign 1 270 179
add 1 270 179
assign 1 273 182
new 0 273 182
assign 1 273 183
add 1 273 183
assign 1 276 186
new 0 276 186
assign 1 276 187
add 1 276 187
assign 1 278 189
not 0 278 189
assign 1 279 191
new 0 279 191
assign 1 279 192
add 1 279 192
assign 1 282 195
new 0 282 195
assign 1 282 196
add 1 282 196
return 1 284 198
return 1 0 201
assign 1 0 204
return 1 0 208
assign 1 0 211
return 1 0 215
assign 1 0 218
return 1 0 222
assign 1 0 225
return 1 0 229
assign 1 0 232
return 1 0 236
assign 1 0 239
return 1 0 243
assign 1 0 246
return 1 0 250
assign 1 0 253
return 1 0 257
assign 1 0 260
return 1 0 264
assign 1 0 267
return 1 0 271
assign 1 0 274
return 1 0 278
assign 1 0 281
return 1 0 285
assign 1 0 288
return 1 0 292
assign 1 0 295
assign 1 0 299
assign 1 0 303
return 1 0 307
assign 1 0 310
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 781552485: return bem_nativeNameGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 495053105: return bem_isAddedGet_0();
case 1774940957: return bem_toString_0();
case 1354714650: return bem_copy_0();
case 354142775: return bem_namepathGet_0();
case 1126433704: return bem_isPropertyGet_0();
case 1135771315: return bem_isTmpVarGet_0();
case 1308786538: return bem_echo_0();
case 1193313287: return bem_isTypedGet_0();
case 729571811: return bem_serializeToString_0();
case 389100841: return bem_numAssignsGet_0();
case 1454846051: return bem_isDeclaredGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2024716595: return bem_allCallsGet_0();
case 535212143: return bem_isSelfGet_0();
case 786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 2110260727: return bem_vposGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1211273660: return bem_nameGet_0();
case 1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case 1081412016: return bem_many_0();
case 564053209: return bem_refsGet_0();
case 443668840: return bem_methodNotDefined_0();
case 743311346: return bem_maxCposGet_0();
case 2104155978: return bem_suffixGet_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 1869307931: return bem_isArgGet_0();
case 845792839: return bem_iteratorGet_0();
case 314718434: return bem_print_0();
case 1217737412: return bem_minCposGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1797856106: return bem_synNew_1((BEC_5_3_BuildVar) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 792634738: return bem_nativeNameSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 2099178474: return bem_vposSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 506135358: return bem_isAddedSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case 552970956: return bem_refsSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1124689062: return bem_isTmpVarSet_1(bevd_0);
case 754393599: return bem_maxCposSet_1(bevd_0);
case 1137515957: return bem_isPropertySet_1(bevd_0);
case 2093073725: return bem_suffixSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1880390184: return bem_isArgSet_1(bevd_0);
case 1204395540: return bem_isTypedSet_1(bevd_0);
case 400183094: return bem_numAssignsSet_1(bevd_0);
case 1465928304: return bem_isDeclaredSet_1(bevd_0);
case 524129890: return bem_isSelfSet_1(bevd_0);
case 474935663: return bem_addCall_1((BEC_5_4_BuildNode) bevd_0);
case 1228819665: return bem_minCposSet_1(bevd_0);
case 2035798848: return bem_allCallsSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_3_BuildVar();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_3_BuildVar.bevs_inst = (BEC_5_3_BuildVar)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_3_BuildVar.bevs_inst;
}
}
