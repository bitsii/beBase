package be.BEL_4_Base;
/* IO:File: source/build/Pass8.be */
public class BEC_5_5_5_BuildVisitPass8 extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass8() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x38};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x38,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x6F,0x74,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_3 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_5 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_6 = {0x61,0x64,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_7 = {0x61,0x64,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_8 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_9 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_10 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_11 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_12 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_13 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_15 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_17 = {0x64,0x69,0x76,0x69,0x64,0x65,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_19 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_20 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x61,0x6E,0x64};
private static byte[] bels_21 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bels_22 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x6F,0x72};
private static byte[] bels_23 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bels_24 = {0x61,0x6E,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_25 = {0x61,0x6E,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_26 = {0x6F,0x72,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_27 = {0x6F,0x72,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_28 = {0x3D,0x40};
private static byte[] bels_29 = {0x3D,0x23};
public static BEC_5_5_5_BuildVisitPass8 bevs_inst;
public BEC_6_6_SystemObject bem_acceptClass_1(BEC_6_6_SystemObject beva_node) throws Throwable {
BEC_5_8_BuildEmitData bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_0_tmpvar_phold.bem_addParsedClass_1(beva_node);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_prepOps_0() throws Throwable {
BEC_6_6_SystemObject bevl_ops = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(10));
bevl_ops = (new BEC_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 25 */ {
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(10));
bevt_1_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 25 */ {
bevt_3_tmpvar_phold = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevl_ops.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_3_tmpvar_phold);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 25 */
 else  /* Line: 25 */ {
break;
} /* Line: 25 */
} /* Line: 25 */
return bevl_ops;
} /*method end*/
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_it = null;
BEC_6_6_SystemObject bevl_prec = null;
BEC_6_6_SystemObject bevl_cont = null;
BEC_6_6_SystemObject bevl_ops = null;
BEC_6_6_SystemObject bevl_onode = null;
BEC_6_6_SystemObject bevl_mo = null;
BEC_6_6_SystemObject bevl_inode = null;
BEC_6_6_SystemObject bevl_mt = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_30_tmpvar_phold = null;
bevt_3_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 35 */ {
this.bem_acceptClass_1(beva_node);
bevt_5_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_5_tmpvar_phold;
} /* Line: 37 */
bevt_6_tmpvar_phold = bevp_const.bem_operGet_0();
bevt_7_tmpvar_phold = beva_node.bem_typenameGet_0();
bevl_prec = bevt_6_tmpvar_phold.bem_get_1(bevt_7_tmpvar_phold);
if (bevl_prec == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 40 */ {
bevl_cont = beva_node.bem_containerGet_0();
bevl_ops = this.bem_prepOps_0();
bevl_onode = beva_node;
beva_node = null;
while (true)
 /* Line: 50 */ {
if (bevl_onode == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 50 */ {
if (bevl_prec == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 50 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 50 */ {
bevt_12_tmpvar_phold = bevl_onode.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_cont);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 50 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 50 */ {
bevt_13_tmpvar_phold = bevl_ops.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_prec);
bevt_13_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_onode);
bevl_inode = bevl_onode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevl_inode = bevl_inode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevt_17_tmpvar_phold = bevl_inode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_18_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_18_tmpvar_phold);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 56 */ {
bevl_inode = bevl_inode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 58 */ {
bevl_inode = bevl_inode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
} /* Line: 59 */
} /* Line: 58 */
} /* Line: 56 */
} /* Line: 55 */
bevl_onode = bevl_inode;
if (bevl_onode == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 65 */ {
bevt_21_tmpvar_phold = bevp_const.bem_operGet_0();
bevt_22_tmpvar_phold = bevl_onode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevl_prec = bevt_21_tmpvar_phold.bem_get_1(bevt_22_tmpvar_phold);
} /* Line: 66 */
 else  /* Line: 67 */ {
bevl_prec = null;
} /* Line: 68 */
} /* Line: 65 */
 else  /* Line: 50 */ {
break;
} /* Line: 50 */
} /* Line: 50 */
bevl_prec = (new BEC_4_3_MathInt(0));
bevl_it = bevl_ops.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 72 */ {
bevt_23_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 72 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_i.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_26_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_26_tmpvar_phold);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 74 */ {
bevl_mt = bevl_i.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 75 */ {
bevt_27_tmpvar_phold = bevl_mt.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_27_tmpvar_phold != null && bevt_27_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_27_tmpvar_phold).bevi_bool) /* Line: 75 */ {
bevl_mo = bevl_mt.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_28_tmpvar_phold = bevl_mo.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
bevt_29_tmpvar_phold = bevl_mo.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_mo = this.bem_callFromOper_4(bevl_mo, bevl_prec, bevt_28_tmpvar_phold, bevt_29_tmpvar_phold);
beva_node = (BEC_5_4_BuildNode) bevl_mo;
} /* Line: 78 */
 else  /* Line: 75 */ {
break;
} /* Line: 75 */
} /* Line: 75 */
} /* Line: 75 */
bevl_prec = bevl_prec.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 81 */
 else  /* Line: 72 */ {
break;
} /* Line: 72 */
} /* Line: 72 */
} /* Line: 72 */
bevt_30_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_callFromOper_4(BEC_6_6_SystemObject beva_op, BEC_6_6_SystemObject beva_prec, BEC_6_6_SystemObject beva_pr, BEC_6_6_SystemObject beva_nx) throws Throwable {
BEC_6_6_SystemObject bevl_gc = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_77_tmpvar_phold = null;
BEC_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_4_3_MathInt bevt_80_tmpvar_phold = null;
bevl_gc = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1795527427, BEL_4_Base.bevn_wasOperSet_1, bevt_2_tmpvar_phold);
bevt_5_tmpvar_phold = bevp_const.bem_operNamesGet_0();
bevt_6_tmpvar_phold = beva_op.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_get_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(357005938, BEL_4_Base.bevn_lower_0);
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_3_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = (new BEC_4_6_TextString(10, bels_0));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 93 */ {
bevt_10_tmpvar_phold = (new BEC_4_6_TextString(9, bels_1));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_10_tmpvar_phold);
} /* Line: 94 */
bevt_12_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = (new BEC_4_6_TextString(13, bels_2));
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_13_tmpvar_phold);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 96 */ {
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(12, bels_3));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_14_tmpvar_phold);
} /* Line: 97 */
bevt_16_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(14, bels_4));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 99 */ {
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(13, bels_5));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_18_tmpvar_phold);
} /* Line: 100 */
bevt_20_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(9, bels_6));
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_19_tmpvar_phold != null && bevt_19_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_19_tmpvar_phold).bevi_bool) /* Line: 102 */ {
bevt_22_tmpvar_phold = (new BEC_4_6_TextString(8, bels_7));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_22_tmpvar_phold);
} /* Line: 103 */
bevt_24_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(14, bels_8));
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_25_tmpvar_phold);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 105 */ {
bevt_26_tmpvar_phold = (new BEC_4_6_TextString(13, bels_9));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_26_tmpvar_phold);
} /* Line: 106 */
bevt_28_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_29_tmpvar_phold = (new BEC_4_6_TextString(15, bels_10));
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_29_tmpvar_phold);
if (bevt_27_tmpvar_phold != null && bevt_27_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_27_tmpvar_phold).bevi_bool) /* Line: 108 */ {
bevt_30_tmpvar_phold = (new BEC_4_6_TextString(14, bels_11));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_30_tmpvar_phold);
} /* Line: 109 */
bevt_32_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_33_tmpvar_phold = (new BEC_4_6_TextString(15, bels_12));
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 111 */ {
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(14, bels_13));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_34_tmpvar_phold);
} /* Line: 112 */
bevt_36_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_37_tmpvar_phold = (new BEC_4_6_TextString(14, bels_14));
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_37_tmpvar_phold);
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 114 */ {
bevt_38_tmpvar_phold = (new BEC_4_6_TextString(13, bels_15));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_38_tmpvar_phold);
} /* Line: 115 */
bevt_40_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_41_tmpvar_phold = (new BEC_4_6_TextString(12, bels_16));
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_41_tmpvar_phold);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 117 */ {
bevt_42_tmpvar_phold = (new BEC_4_6_TextString(11, bels_17));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_42_tmpvar_phold);
} /* Line: 118 */
bevt_44_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_45_tmpvar_phold = (new BEC_4_6_TextString(13, bels_18));
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_45_tmpvar_phold);
if (bevt_43_tmpvar_phold != null && bevt_43_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_43_tmpvar_phold).bevi_bool) /* Line: 120 */ {
bevt_46_tmpvar_phold = (new BEC_4_6_TextString(12, bels_19));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_46_tmpvar_phold);
} /* Line: 121 */
bevt_48_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_49_tmpvar_phold = (new BEC_4_6_TextString(11, bels_20));
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_49_tmpvar_phold);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 123 */ {
bevt_50_tmpvar_phold = (new BEC_4_6_TextString(10, bels_21));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_50_tmpvar_phold);
} /* Line: 124 */
bevt_52_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpvar_phold = (new BEC_4_6_TextString(10, bels_22));
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_53_tmpvar_phold);
if (bevt_51_tmpvar_phold != null && bevt_51_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_51_tmpvar_phold).bevi_bool) /* Line: 126 */ {
bevt_54_tmpvar_phold = (new BEC_4_6_TextString(9, bels_23));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_54_tmpvar_phold);
} /* Line: 127 */
bevt_56_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_57_tmpvar_phold = (new BEC_4_6_TextString(9, bels_24));
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_57_tmpvar_phold);
if (bevt_55_tmpvar_phold != null && bevt_55_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_55_tmpvar_phold).bevi_bool) /* Line: 129 */ {
bevt_58_tmpvar_phold = (new BEC_4_6_TextString(8, bels_25));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_58_tmpvar_phold);
} /* Line: 130 */
bevt_60_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_61_tmpvar_phold = (new BEC_4_6_TextString(8, bels_26));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_61_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 132 */ {
bevt_62_tmpvar_phold = (new BEC_4_6_TextString(7, bels_27));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_62_tmpvar_phold);
} /* Line: 133 */
bevt_63_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_63_tmpvar_phold);
bevt_65_tmpvar_phold = beva_op.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_66_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_66_tmpvar_phold);
if (bevt_64_tmpvar_phold != null && bevt_64_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_64_tmpvar_phold).bevi_bool) /* Line: 137 */ {
bevt_68_tmpvar_phold = beva_op.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_69_tmpvar_phold = (new BEC_4_6_TextString(2, bels_28));
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 137 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 137 */
 else  /* Line: 137 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 137 */ {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1489916809, BEL_4_Base.bevn_isOnceSet_1, bevt_70_tmpvar_phold);
} /* Line: 139 */
bevt_72_tmpvar_phold = beva_op.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_73_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_73_tmpvar_phold);
if (bevt_71_tmpvar_phold != null && bevt_71_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_71_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevt_75_tmpvar_phold = beva_op.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_76_tmpvar_phold = (new BEC_4_6_TextString(2, bels_29));
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_74_tmpvar_phold != null && bevt_74_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_74_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
 else  /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_77_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1373349483, BEL_4_Base.bevn_isManySet_1, bevt_77_tmpvar_phold);
} /* Line: 143 */
bevt_78_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_op.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpvar_phold);
beva_op.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_pr.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_op.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_pr);
bevt_80_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_79_tmpvar_phold = beva_prec.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_80_tmpvar_phold);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 149 */ {
beva_nx.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_op.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_nx);
} /* Line: 151 */
return beva_op;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 24, 25, 26, 25, 28, 35, 36, 37, 39, 40, 45, 46, 47, 49, 50, 0, 50, 0, 51, 52, 53, 54, 55, 56, 57, 58, 59, 64, 65, 66, 68, 71, 72, 73, 74, 75, 76, 77, 78, 81, 86, 90, 91, 92, 93, 94, 96, 97, 99, 100, 102, 103, 105, 106, 108, 109, 111, 112, 114, 115, 117, 118, 120, 121, 123, 124, 126, 127, 129, 130, 132, 133, 136, 137, 0, 139, 141, 0, 143, 145, 146, 147, 148, 149, 150, 151, 153};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 40
emitDataGet 0 20 40
addParsedClass 1 20 40
assign 1 24 40
new 0 24 40
assign 1 24 40
new 1 24 40
assign 1 25 40
new 0 25 40
assign 1 25 40
new 0 25 40
assign 1 25 40
lesser 1 25 40
assign 1 26 40
new 0 26 40
put 2 26 40
assign 1 25 40
increment 0 25 40
return 1 28 40
assign 1 35 40
typenameGet 0 35 40
assign 1 35 40
CLASSGet 0 35 40
assign 1 35 40
equals 1 35 40
acceptClass 1 36 40
assign 1 37 40
nextDescendGet 0 37 40
return 1 37 40
assign 1 39 40
operGet 0 39 40
assign 1 39 40
typenameGet 0 39 40
assign 1 39 40
get 1 39 40
assign 1 40 40
def 1 40 40
assign 1 45 40
containerGet 0 45 40
assign 1 46 40
prepOps 0 46 40
assign 1 47 40
assign 1 49 40
assign 1 50 40
def 1 50 40
assign 1 50 40
def 1 50 40
assign 1 0 40
assign 1 0 40
assign 1 0 40
assign 1 50 40
containerGet 0 50 40
assign 1 50 40
equals 1 50 40
assign 1 0 40
assign 1 0 40
assign 1 0 40
assign 1 51 40
get 1 51 40
addValue 1 51 40
assign 1 52 40
nextPeerGet 0 52 40
assign 1 53 40
def 1 53 40
assign 1 54 40
nextPeerGet 0 54 40
assign 1 55 40
def 1 55 40
assign 1 56 40
typenameGet 0 56 40
assign 1 56 40
COMMAGet 0 56 40
assign 1 56 40
equals 1 56 40
assign 1 57 40
nextPeerGet 0 57 40
assign 1 58 40
def 1 58 40
assign 1 59 40
nextPeerGet 0 59 40
assign 1 64 40
assign 1 65 40
def 1 65 40
assign 1 66 40
operGet 0 66 40
assign 1 66 40
typenameGet 0 66 40
assign 1 66 40
get 1 66 40
assign 1 68 40
assign 1 71 40
new 0 71 40
assign 1 72 40
iteratorGet 0 72 40
assign 1 72 40
hasNextGet 0 72 40
assign 1 73 40
nextGet 0 73 40
assign 1 74 40
lengthGet 0 74 40
assign 1 74 40
new 0 74 40
assign 1 74 40
greater 1 74 40
assign 1 75 40
iteratorGet 0 75 40
assign 1 75 40
hasNextGet 0 75 40
assign 1 76 40
nextGet 0 76 40
assign 1 77 40
priorPeerGet 0 77 40
assign 1 77 40
nextPeerGet 0 77 40
assign 1 77 40
callFromOper 4 77 40
assign 1 78 40
assign 1 81 40
increment 0 81 40
assign 1 86 40
nextDescendGet 0 86 40
return 1 86 40
assign 1 90 40
new 0 90 40
assign 1 91 40
new 0 91 40
wasOperSet 1 91 40
assign 1 92 40
operNamesGet 0 92 40
assign 1 92 40
typenameGet 0 92 40
assign 1 92 40
get 1 92 40
assign 1 92 40
lower 0 92 40
nameSet 1 92 40
assign 1 93 40
nameGet 0 93 40
assign 1 93 40
new 0 93 40
assign 1 93 40
equals 1 93 40
assign 1 94 40
new 0 94 40
nameSet 1 94 40
assign 1 96 40
nameGet 0 96 40
assign 1 96 40
new 0 96 40
assign 1 96 40
equals 1 96 40
assign 1 97 40
new 0 97 40
nameSet 1 97 40
assign 1 99 40
nameGet 0 99 40
assign 1 99 40
new 0 99 40
assign 1 99 40
equals 1 99 40
assign 1 100 40
new 0 100 40
nameSet 1 100 40
assign 1 102 40
nameGet 0 102 40
assign 1 102 40
new 0 102 40
assign 1 102 40
equals 1 102 40
assign 1 103 40
new 0 103 40
nameSet 1 103 40
assign 1 105 40
nameGet 0 105 40
assign 1 105 40
new 0 105 40
assign 1 105 40
equals 1 105 40
assign 1 106 40
new 0 106 40
nameSet 1 106 40
assign 1 108 40
nameGet 0 108 40
assign 1 108 40
new 0 108 40
assign 1 108 40
equals 1 108 40
assign 1 109 40
new 0 109 40
nameSet 1 109 40
assign 1 111 40
nameGet 0 111 40
assign 1 111 40
new 0 111 40
assign 1 111 40
equals 1 111 40
assign 1 112 40
new 0 112 40
nameSet 1 112 40
assign 1 114 40
nameGet 0 114 40
assign 1 114 40
new 0 114 40
assign 1 114 40
equals 1 114 40
assign 1 115 40
new 0 115 40
nameSet 1 115 40
assign 1 117 40
nameGet 0 117 40
assign 1 117 40
new 0 117 40
assign 1 117 40
equals 1 117 40
assign 1 118 40
new 0 118 40
nameSet 1 118 40
assign 1 120 40
nameGet 0 120 40
assign 1 120 40
new 0 120 40
assign 1 120 40
equals 1 120 40
assign 1 121 40
new 0 121 40
nameSet 1 121 40
assign 1 123 40
nameGet 0 123 40
assign 1 123 40
new 0 123 40
assign 1 123 40
equals 1 123 40
assign 1 124 40
new 0 124 40
nameSet 1 124 40
assign 1 126 40
nameGet 0 126 40
assign 1 126 40
new 0 126 40
assign 1 126 40
equals 1 126 40
assign 1 127 40
new 0 127 40
nameSet 1 127 40
assign 1 129 40
nameGet 0 129 40
assign 1 129 40
new 0 129 40
assign 1 129 40
equals 1 129 40
assign 1 130 40
new 0 130 40
nameSet 1 130 40
assign 1 132 40
nameGet 0 132 40
assign 1 132 40
new 0 132 40
assign 1 132 40
equals 1 132 40
assign 1 133 40
new 0 133 40
nameSet 1 133 40
assign 1 136 40
new 0 136 40
wasBoundSet 1 136 40
assign 1 137 40
typenameGet 0 137 40
assign 1 137 40
ASSIGNGet 0 137 40
assign 1 137 40
equals 1 137 40
assign 1 137 40
heldGet 0 137 40
assign 1 137 40
new 0 137 40
assign 1 137 40
equals 1 137 40
assign 1 0 40
assign 1 0 40
assign 1 0 40
assign 1 139 40
new 0 139 40
isOnceSet 1 139 40
assign 1 141 40
typenameGet 0 141 40
assign 1 141 40
ASSIGNGet 0 141 40
assign 1 141 40
equals 1 141 40
assign 1 141 40
heldGet 0 141 40
assign 1 141 40
new 0 141 40
assign 1 141 40
equals 1 141 40
assign 1 0 40
assign 1 0 40
assign 1 0 40
assign 1 143 40
new 0 143 40
isManySet 1 143 40
assign 1 145 40
CALLGet 0 145 40
typenameSet 1 145 40
heldSet 1 146 40
delete 0 147 40
addValue 1 148 40
assign 1 149 40
new 0 149 40
assign 1 149 40
greater 1 149 40
delete 0 150 40
addValue 1 151 40
return 1 153 40
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 1028089930: return bem_prepOps_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 724180734: return bem_acceptClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1204261941: return bem_callFromOper_4(bevd_0, bevd_1, bevd_2, bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_5_BuildVisitPass8();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_5_BuildVisitPass8.bevs_inst = (BEC_5_5_5_BuildVisitPass8)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_5_BuildVisitPass8.bevs_inst;
}
}
