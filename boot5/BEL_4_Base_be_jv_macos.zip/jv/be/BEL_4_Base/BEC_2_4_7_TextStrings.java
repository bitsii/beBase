package be.BEL_4_Base;
/* IO:File: source/base/String.be */
public class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static byte[] bels_1 = {0x0D,0x0A};
private static byte[] bels_2 = {0x0A};
private static byte[] bels_3 = {0x0A};
private static byte[] bels_4 = {0x3A};
private static byte[] bels_5 = {};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_6 = {};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_6, 0));
public static BEC_2_4_7_TextStrings bevs_inst;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevp_space = (new BEC_2_4_6_TextString(1, bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_tmpvar_phold);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bels_2));
bevt_2_tmpvar_phold = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_tmpvar_phold);
bevp_lf = (new BEC_2_4_6_TextString(1, bels_3));
bevp_colon = (new BEC_2_4_6_TextString(1, bels_4));
bevp_lineSplitter = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_i = beva_splits.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1123 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_tmpvar_phold;
} /* Line: 1124 */
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_buf.bem_addValue_1(bevt_3_tmpvar_phold);
while (true)
 /* Line: 1128 */ {
bevt_4_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 1128 */ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_buf.bem_addValue_1(bevt_5_tmpvar_phold);
} /* Line: 1130 */
 else  /* Line: 1128 */ {
break;
} /* Line: 1128 */
} /* Line: 1128 */
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
 /* Line: 1140 */ {
bevt_0_tmpvar_phold = bevl_mb.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1140 */ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_tmpvar_phold = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1142 */ {
if (bevl_foundChar.bevi_bool) /* Line: 1143 */ {
bevl_end = bevl_end.bem_increment_0();
} /* Line: 1144 */
 else  /* Line: 1145 */ {
bevl_beg = bevl_beg.bem_increment_0();
} /* Line: 1146 */
} /* Line: 1143 */
 else  /* Line: 1148 */ {
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1150 */
} /* Line: 1142 */
 else  /* Line: 1140 */ {
break;
} /* Line: 1140 */
} /* Line: 1140 */
if (bevl_foundChar.bevi_bool) /* Line: 1153 */ {
bevt_3_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_2_tmpvar_phold);
} /* Line: 1154 */
 else  /* Line: 1155 */ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bels_5));
} /* Line: 1156 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_4_MathInts bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
if (beva_a == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1162 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1162 */ {
if (beva_b == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1162 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1162 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1162 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1162 */ {
return null;
} /* Line: 1162 */
bevt_3_tmpvar_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bevs_inst;
bevt_4_tmpvar_phold = beva_a.bem_sizeGet_0();
bevt_5_tmpvar_phold = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_min_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 1168 */ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 1168 */ {
bevl_ai.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_av);
bevl_bi.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_bv);
bevt_7_tmpvar_phold = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 1171 */ {
bevt_9_tmpvar_phold = bevo_0;
bevt_8_tmpvar_phold = beva_a.bem_substring_2(bevt_9_tmpvar_phold, bevl_i);
return bevt_8_tmpvar_phold;
} /* Line: 1172 */
bevl_i.bevi_int++;
} /* Line: 1168 */
 else  /* Line: 1168 */ {
break;
} /* Line: 1168 */
} /* Line: 1168 */
bevt_11_tmpvar_phold = bevo_1;
bevt_10_tmpvar_phold = beva_a.bem_substring_2(bevt_11_tmpvar_phold, bevl_i);
return bevt_10_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_loop = beva_strs.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 1179 */ {
bevt_1_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 1179 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = this.bem_isEmpty_1(bevl_i);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1180 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /* Line: 1181 */
} /* Line: 1180 */
 else  /* Line: 1179 */ {
break;
} /* Line: 1179 */
} /* Line: 1179 */
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_value == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1188 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1188 */ {
bevt_3_tmpvar_phold = beva_value.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevo_2;
if (bevt_3_tmpvar_phold.bevi_int < bevt_4_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1188 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1188 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1188 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1188 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /* Line: 1189 */
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_value == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1195 */ {
bevt_3_tmpvar_phold = bevo_3;
bevt_2_tmpvar_phold = beva_value.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1195 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1195 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1195 */
 else  /* Line: 1195 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1195 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 1196 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_6_6_SystemObject bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_6_6_SystemObject bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_6_6_SystemObject bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_6_6_SystemObject bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_6_6_SystemObject bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() throws Throwable {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() throws Throwable {
return bevp_ws;
} /*method end*/
public BEC_2_6_6_SystemObject bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1097, 1098, 1099, 1099, 1100, 1100, 1101, 1102, 1104, 1104, 1105, 1106, 1107, 1108, 1111, 1112, 1113, 1114, 1118, 1118, 1122, 1123, 1123, 1124, 1124, 1126, 1127, 1127, 1128, 1129, 1130, 1130, 1132, 1136, 1137, 1138, 1139, 1140, 1141, 1142, 1144, 1146, 1149, 1150, 1154, 1154, 1154, 1156, 1158, 1162, 1162, 0, 1162, 1162, 0, 0, 1162, 1163, 1163, 1163, 1163, 1164, 1165, 1166, 1167, 1168, 1168, 1168, 1169, 1170, 1171, 1172, 1172, 1172, 1168, 1175, 1175, 1175, 1179, 0, 1179, 1179, 1180, 1181, 1181, 1184, 1184, 1188, 1188, 0, 1188, 1188, 1188, 1188, 0, 0, 1189, 1189, 1191, 1191, 1195, 1195, 1195, 1195, 0, 0, 0, 1196, 1196, 1198, 1198, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 60, 61, 72, 73, 74, 76, 77, 79, 80, 81, 84, 86, 87, 88, 94, 107, 108, 109, 110, 113, 115, 116, 119, 122, 126, 127, 135, 136, 137, 140, 142, 163, 168, 169, 172, 177, 178, 181, 185, 187, 188, 189, 190, 191, 192, 193, 194, 195, 198, 203, 204, 205, 206, 208, 209, 210, 212, 218, 219, 220, 229, 229, 232, 234, 235, 237, 238, 245, 246, 256, 261, 262, 265, 266, 267, 272, 273, 276, 280, 281, 283, 284, 293, 298, 299, 300, 302, 305, 309, 312, 313, 315, 316, 319, 322, 326, 329, 333, 336, 340, 343, 347, 350, 354, 357, 361, 364, 368, 371, 375, 378, 382, 385, 389, 392, 396, 399};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1097 38
new 0 1097 38
assign 1 1098 39
new 0 1098 39
assign 1 1099 40
new 0 1099 40
assign 1 1099 41
codeNew 1 1099 41
assign 1 1100 42
new 0 1100 42
assign 1 1100 43
codeNew 1 1100 43
assign 1 1101 44
new 0 1101 44
assign 1 1102 45
new 0 1102 45
assign 1 1104 46
new 0 1104 46
assign 1 1104 47
codeNew 1 1104 47
assign 1 1105 48
new 0 1105 48
assign 1 1106 49
new 0 1106 49
assign 1 1107 50
new 1 1107 50
assign 1 1108 51
new 0 1108 51
put 1 1111 52
put 1 1112 53
put 1 1113 54
put 1 1114 55
assign 1 1118 60
joinBuffer 2 1118 60
return 1 1118 61
assign 1 1122 72
iteratorGet 0 1122 72
assign 1 1123 73
hasNextGet 0 1123 73
assign 1 1123 74
not 0 1123 74
assign 1 1124 76
new 0 1124 76
return 1 1124 77
assign 1 1126 79
new 0 1126 79
assign 1 1127 80
nextGet 0 1127 80
addValue 1 1127 81
assign 1 1128 84
hasNextGet 0 1128 84
addValue 1 1129 86
assign 1 1130 87
nextGet 0 1130 87
addValue 1 1130 88
return 1 1132 94
assign 1 1136 107
new 0 1136 107
assign 1 1137 108
new 0 1137 108
assign 1 1138 109
new 0 1138 109
assign 1 1139 110
mbiterGet 0 1139 110
assign 1 1140 113
hasNextGet 0 1140 113
assign 1 1141 115
nextGet 0 1141 115
assign 1 1142 116
has 1 1142 116
assign 1 1144 119
increment 0 1144 119
assign 1 1146 122
increment 0 1146 122
assign 1 1149 126
new 0 1149 126
assign 1 1150 127
new 0 1150 127
assign 1 1154 135
sizeGet 0 1154 135
assign 1 1154 136
subtract 1 1154 136
assign 1 1154 137
substring 2 1154 137
assign 1 1156 140
new 0 1156 140
return 1 1158 142
assign 1 1162 163
undef 1 1162 168
assign 1 0 169
assign 1 1162 172
undef 1 1162 177
assign 1 0 178
assign 1 0 181
return 1 1162 185
assign 1 1163 187
new 0 1163 187
assign 1 1163 188
sizeGet 0 1163 188
assign 1 1163 189
sizeGet 0 1163 189
assign 1 1163 190
min 2 1163 190
assign 1 1164 191
biterGet 0 1164 191
assign 1 1165 192
biterGet 0 1165 192
assign 1 1166 193
new 0 1166 193
assign 1 1167 194
new 0 1167 194
assign 1 1168 195
new 0 1168 195
assign 1 1168 198
lesser 1 1168 203
next 1 1169 204
next 1 1170 205
assign 1 1171 206
notEquals 1 1171 206
assign 1 1172 208
new 0 1172 208
assign 1 1172 209
substring 2 1172 209
return 1 1172 210
incrementValue 0 1168 212
assign 1 1175 218
new 0 1175 218
assign 1 1175 219
substring 2 1175 219
return 1 1175 220
assign 1 1179 229
iteratorGet 0 0 229
assign 1 1179 232
hasNextGet 0 1179 232
assign 1 1179 234
nextGet 0 1179 234
assign 1 1180 235
isEmpty 1 1180 235
assign 1 1181 237
new 0 1181 237
return 1 1181 238
assign 1 1184 245
new 0 1184 245
return 1 1184 246
assign 1 1188 256
undef 1 1188 261
assign 1 0 262
assign 1 1188 265
sizeGet 0 1188 265
assign 1 1188 266
new 0 1188 266
assign 1 1188 267
lesser 1 1188 272
assign 1 0 273
assign 1 0 276
assign 1 1189 280
new 0 1189 280
return 1 1189 281
assign 1 1191 283
new 0 1191 283
return 1 1191 284
assign 1 1195 293
def 1 1195 298
assign 1 1195 299
new 0 1195 299
assign 1 1195 300
notEquals 1 1195 300
assign 1 0 302
assign 1 0 305
assign 1 0 309
assign 1 1196 312
new 0 1196 312
return 1 1196 313
assign 1 1198 315
new 0 1198 315
return 1 1198 316
return 1 0 319
assign 1 0 322
return 1 0 326
assign 1 0 329
return 1 0 333
assign 1 0 336
return 1 0 340
assign 1 0 343
return 1 0 347
assign 1 0 350
return 1 0 354
assign 1 0 357
return 1 0 361
assign 1 0 364
return 1 0 368
assign 1 0 371
return 1 0 375
assign 1 0 378
return 1 0 382
assign 1 0 385
return 1 0 389
assign 1 0 392
return 1 0 396
assign 1 0 399
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 482013217: return bem_spaceGet_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 1081741254: return bem_emptyGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1259904107: return bem_quoteGet_0();
case 1502128718: return bem_default_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1708371387: return bem_dosNewlineGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1599801355: return bem_wsGet_0();
case 55016493: return bem_lfGet_0();
case 929570062: return bem_tabGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 776765523: return bem_newlineGet_0();
case 1000967768: return bem_crGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1152565608: return bem_colonGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 527120532: return bem_lineSplitterGet_0();
case 1354714650: return bem_copy_0();
case 1567400443: return bem_unixNewlineGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1270986360: return bem_quoteSet_1(bevd_0);
case 1719453640: return bem_dosNewlineSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 516038279: return bem_lineSplitterSet_1(bevd_0);
case 1629015603: return bem_anyEmpty_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1012050021: return bem_crSet_1(bevd_0);
case 66098746: return bem_lfSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1437735788: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 493095470: return bem_spaceSet_1(bevd_0);
case 918487809: return bem_tabSet_1(bevd_0);
case 1578482696: return bem_unixNewlineSet_1(bevd_0);
case 1610883608: return bem_wsSet_1(bevd_0);
case 2091366709: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1070659001: return bem_emptySet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1163647861: return bem_colonSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1881757494: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1154529699: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 941304624: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1331758909: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bevs_inst = (BEC_2_4_7_TextStrings)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bevs_inst;
}
}
