package be.BEL_4_Base;
/* File: source/base/Int.be */
public class BEC_4_3_MathInt extends BEC_6_6_SystemObject {
public BEC_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(10));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(58));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(65));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(97));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(16));
private static BEC_4_3_MathInt bevo_5 = (new BEC_4_3_MathInt(58));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(71));
private static BEC_4_3_MathInt bevo_7 = (new BEC_4_3_MathInt(103));
private static BEC_4_3_MathInt bevo_8 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_9 = (new BEC_4_3_MathInt(24));
private static byte[] bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static BEC_4_6_TextString bevo_10 = (new BEC_4_6_TextString(bels_0, 39));
private static BEC_4_3_MathInt bevo_11 = (new BEC_4_3_MathInt(10));
private static BEC_4_3_MathInt bevo_12 = (new BEC_4_3_MathInt(65));
private static BEC_4_3_MathInt bevo_13 = (new BEC_4_3_MathInt(10));
private static BEC_4_3_MathInt bevo_14 = (new BEC_4_3_MathInt(97));
private static BEC_4_3_MathInt bevo_15 = (new BEC_4_3_MathInt(10));
private static BEC_4_3_MathInt bevo_16 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_17 = (new BEC_4_3_MathInt(47));
private static BEC_4_3_MathInt bevo_18 = (new BEC_4_3_MathInt(64));
private static BEC_4_3_MathInt bevo_19 = (new BEC_4_3_MathInt(96));
private static BEC_4_3_MathInt bevo_20 = (new BEC_4_3_MathInt(45));
private static byte[] bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static BEC_4_6_TextString bevo_21 = (new BEC_4_6_TextString(bels_1, 21));
private static byte[] bels_2 = {0x20};
private static BEC_4_6_TextString bevo_22 = (new BEC_4_6_TextString(bels_2, 1));
private static BEC_4_3_MathInt bevo_23 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_24 = (new BEC_4_3_MathInt(10));
private static BEC_4_3_MathInt bevo_25 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_26 = (new BEC_4_3_MathInt(16));
private static BEC_4_3_MathInt bevo_27 = (new BEC_4_3_MathInt(55));
private static BEC_4_3_MathInt bevo_28 = (new BEC_4_3_MathInt(55));
private static BEC_4_3_MathInt bevo_29 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_30 = (new BEC_4_3_MathInt(10));
private static BEC_4_3_MathInt bevo_31 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_32 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_33 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_34 = (new BEC_4_3_MathInt(48));
private static BEC_4_3_MathInt bevo_35 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_36 = (new BEC_4_3_MathInt(0));
private static byte[] bels_3 = {0x2D};
private static BEC_4_3_MathInt bevo_37 = (new BEC_4_3_MathInt(0));
public static BEC_4_3_MathInt bevs_inst;
public BEC_6_6_SystemObject bevp_vint;
public BEC_6_6_SystemObject bem_vintGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_vintSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_3_MathInt bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_create_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt()).bem_new_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_new_1(BEC_6_6_SystemObject beva_str) throws Throwable {
this.bem_setStringValueDec_1((BEC_4_6_TextString) beva_str);
return this;
} /*method end*/
public BEC_4_3_MathInt bem_hexNew_1(BEC_4_6_TextString beva_str) throws Throwable {
this.bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_4_3_MathInt bem_setStringValueDec_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
bevt_5_tmpvar_phold = bevo_2;
bevt_4_tmpvar_phold = (BEC_4_3_MathInt) bevt_5_tmpvar_phold.bem_once_0();
bevt_7_tmpvar_phold = bevo_3;
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) bevt_7_tmpvar_phold.bem_once_0();
this.bem_setStringValue_5(beva_str, bevt_0_tmpvar_phold, bevt_2_tmpvar_phold, bevt_4_tmpvar_phold, bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_4_3_MathInt bem_setStringValueHex_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
bevt_3_tmpvar_phold = bevo_5;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
bevt_5_tmpvar_phold = bevo_6;
bevt_4_tmpvar_phold = (BEC_4_3_MathInt) bevt_5_tmpvar_phold.bem_once_0();
bevt_7_tmpvar_phold = bevo_7;
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) bevt_7_tmpvar_phold.bem_once_0();
this.bem_setStringValue_5(beva_str, bevt_0_tmpvar_phold, bevt_2_tmpvar_phold, bevt_4_tmpvar_phold, bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_4_3_MathInt bem_setStringValue_2(BEC_4_6_TextString beva_str, BEC_4_3_MathInt beva_radix) throws Throwable {
BEC_4_3_MathInt bevl_max0 = null;
BEC_4_3_MathInt bevl_maxA = null;
BEC_4_3_MathInt bevl_maxa = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_6_9_SystemException bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_8;
bevt_1_tmpvar_phold = beva_radix.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 88 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_4_tmpvar_phold = bevo_9;
bevt_3_tmpvar_phold = beva_radix.bem_greater_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 88 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 88 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 88 */ {
bevt_7_tmpvar_phold = bevo_10;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(beva_radix);
bevt_5_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_6_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 89 */
bevt_9_tmpvar_phold = bevo_11;
bevt_8_tmpvar_phold = beva_radix.bem_lesser_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevl_max0 = (BEC_4_3_MathInt) beva_radix.bem_copy_0();
} /* Line: 92 */
 else  /* Line: 93 */ {
bevl_max0 = (new BEC_4_3_MathInt(10));
} /* Line: 94 */
bevt_10_tmpvar_phold = (new BEC_4_3_MathInt(48));
bevl_max0.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_12;
bevt_13_tmpvar_phold = bevo_13;
bevt_12_tmpvar_phold = beva_radix.bem_subtract_1(bevt_13_tmpvar_phold);
bevl_maxA = bevt_11_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_14;
bevt_16_tmpvar_phold = bevo_15;
bevt_15_tmpvar_phold = beva_radix.bem_subtract_1(bevt_16_tmpvar_phold);
bevl_maxa = bevt_14_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
this.bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_4_3_MathInt bem_setStringValue_5(BEC_4_6_TextString beva_str, BEC_4_3_MathInt beva_radix, BEC_4_3_MathInt beva_max0, BEC_4_3_MathInt beva_maxA, BEC_4_3_MathInt beva_maxa) throws Throwable {
BEC_4_3_MathInt bevl_j = null;
BEC_4_3_MathInt bevl_pow = null;
BEC_4_3_MathInt bevl_ic = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_6_9_SystemException bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
bevt_3_tmpvar_phold = (new BEC_4_3_MathInt(0));
this.bem_setValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_j = (BEC_4_3_MathInt) bevt_4_tmpvar_phold.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (new BEC_4_3_MathInt(1));
bevl_ic = (new BEC_4_3_MathInt()).bem_new_0();
while (true)
 /* Line: 108 */ {
bevt_6_tmpvar_phold = bevo_16;
bevt_5_tmpvar_phold = bevl_j.bem_greaterEquals_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 108 */ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_tmpvar_phold = bevo_17;
bevt_7_tmpvar_phold = bevl_ic.bem_greater_1(bevt_8_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 112 */ {
bevt_9_tmpvar_phold = bevl_ic.bem_lesser_1(beva_max0);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 112 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 112 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 112 */
 else  /* Line: 112 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 112 */ {
bevt_10_tmpvar_phold = (new BEC_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_tmpvar_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bem_addValue_1(bevl_ic);
} /* Line: 115 */
 else  /* Line: 112 */ {
bevt_12_tmpvar_phold = bevo_18;
bevt_11_tmpvar_phold = bevl_ic.bem_greater_1(bevt_12_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_13_tmpvar_phold = bevl_ic.bem_lesser_1(beva_maxA);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
 else  /* Line: 116 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 116 */ {
bevt_14_tmpvar_phold = (new BEC_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_tmpvar_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bem_addValue_1(bevl_ic);
} /* Line: 119 */
 else  /* Line: 112 */ {
bevt_16_tmpvar_phold = bevo_19;
bevt_15_tmpvar_phold = bevl_ic.bem_greater_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevt_17_tmpvar_phold = bevl_ic.bem_lesser_1(beva_maxa);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 120 */ {
bevt_18_tmpvar_phold = (new BEC_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_tmpvar_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bem_addValue_1(bevl_ic);
} /* Line: 123 */
 else  /* Line: 112 */ {
bevt_20_tmpvar_phold = bevo_20;
bevt_19_tmpvar_phold = bevl_ic.bem_equals_1(bevt_20_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_21_tmpvar_phold = (new BEC_4_3_MathInt(-1));
this.bem_multiplyValue_1(bevt_21_tmpvar_phold);
} /* Line: 126 */
 else  /* Line: 127 */ {
bevt_26_tmpvar_phold = bevo_21;
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_add_1(beva_str);
bevt_27_tmpvar_phold = bevo_22;
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevl_ic);
bevt_22_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_23_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_22_tmpvar_phold);
} /* Line: 128 */
} /* Line: 112 */
} /* Line: 112 */
} /* Line: 112 */
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 131 */
 else  /* Line: 108 */ {
break;
} /* Line: 108 */
} /* Line: 108 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) throws Throwable {
this.bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_hashGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_5_MathFloat bem_toFloat_0() throws Throwable {
BEC_4_5_MathFloat bevl_fi = null;
bevl_fi = (new BEC_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevt_1_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_4_tmpvar_phold = bevo_23;
bevt_3_tmpvar_phold = (BEC_4_3_MathInt) bevt_4_tmpvar_phold.bem_once_0();
bevt_6_tmpvar_phold = bevo_24;
bevt_5_tmpvar_phold = (BEC_4_3_MathInt) bevt_6_tmpvar_phold.bem_once_0();
bevt_0_tmpvar_phold = this.bem_toString_4(bevt_1_tmpvar_phold, bevt_3_tmpvar_phold, bevt_5_tmpvar_phold, null);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_toHexString_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevt_1_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_toHexString_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_toHexString_1(BEC_4_6_TextString beva_res) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_25;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) bevt_2_tmpvar_phold.bem_once_0();
bevt_4_tmpvar_phold = bevo_26;
bevt_3_tmpvar_phold = (BEC_4_3_MathInt) bevt_4_tmpvar_phold.bem_once_0();
bevt_0_tmpvar_phold = this.bem_toString_3(beva_res, bevt_1_tmpvar_phold, bevt_3_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_toString_2(BEC_4_3_MathInt beva_zeroPad, BEC_4_3_MathInt beva_radix) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_3_tmpvar_phold = bevo_27;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
bevt_0_tmpvar_phold = this.bem_toString_4(bevt_1_tmpvar_phold, beva_zeroPad, beva_radix, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_toString_3(BEC_4_6_TextString beva_res, BEC_4_3_MathInt beva_zeroPad, BEC_4_3_MathInt beva_radix) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_28;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) bevt_2_tmpvar_phold.bem_once_0();
bevt_0_tmpvar_phold = this.bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_toString_4(BEC_4_6_TextString beva_res, BEC_4_3_MathInt beva_zeroPad, BEC_4_3_MathInt beva_radix, BEC_4_3_MathInt beva_alphaStart) throws Throwable {
BEC_4_3_MathInt bevl_ts = null;
BEC_4_3_MathInt bevl_val = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
beva_res.bem_clear_0();
bevl_ts = this.bem_abs_0();
bevl_val = (new BEC_4_3_MathInt()).bem_new_0();
while (true)
 /* Line: 204 */ {
bevt_1_tmpvar_phold = bevo_29;
bevt_0_tmpvar_phold = bevl_ts.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevl_val.bem_setValue_1(bevl_ts);
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_tmpvar_phold = bevo_30;
bevt_2_tmpvar_phold = bevl_val.bem_lesser_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevt_4_tmpvar_phold = (new BEC_4_3_MathInt(48));
bevl_val.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 208 */
 else  /* Line: 209 */ {
bevl_val.bem_addValue_1(beva_alphaStart);
} /* Line: 210 */
bevt_6_tmpvar_phold = beva_res.bem_capacityGet_0();
bevt_7_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_lesserEquals_1(bevt_7_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevt_9_tmpvar_phold = beva_res.bem_capacityGet_0();
bevt_10_tmpvar_phold = bevo_31;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
beva_res.bem_capacitySet_1(bevt_8_tmpvar_phold);
} /* Line: 214 */
bevt_11_tmpvar_phold = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_tmpvar_phold, bevl_val);
bevt_13_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_14_tmpvar_phold = bevo_32;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
beva_res.bem_sizeSet_1(bevt_12_tmpvar_phold);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 221 */
 else  /* Line: 204 */ {
break;
} /* Line: 204 */
} /* Line: 204 */
while (true)
 /* Line: 224 */ {
bevt_19_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_lesser_1(beva_zeroPad);
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_21_tmpvar_phold = beva_res.bem_capacityGet_0();
bevt_22_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_lesserEquals_1(bevt_22_tmpvar_phold);
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevt_24_tmpvar_phold = beva_res.bem_capacityGet_0();
bevt_25_tmpvar_phold = bevo_33;
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
beva_res.bem_capacitySet_1(bevt_23_tmpvar_phold);
} /* Line: 226 */
bevt_26_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_28_tmpvar_phold = bevo_34;
bevt_27_tmpvar_phold = (BEC_4_3_MathInt) bevt_28_tmpvar_phold.bem_once_0();
beva_res.bem_setIntUnchecked_2(bevt_26_tmpvar_phold, bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_31_tmpvar_phold = bevo_35;
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_add_1(bevt_31_tmpvar_phold);
beva_res.bem_sizeSet_1(bevt_29_tmpvar_phold);
} /* Line: 230 */
 else  /* Line: 224 */ {
break;
} /* Line: 224 */
} /* Line: 224 */
bevt_36_tmpvar_phold = bevo_36;
bevt_35_tmpvar_phold = this.bem_lesser_1(bevt_36_tmpvar_phold);
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_37_tmpvar_phold = (new BEC_4_6_TextString(1, bels_3));
beva_res.bem_addValue_1(bevt_37_tmpvar_phold);
} /* Line: 235 */
bevt_38_tmpvar_phold = beva_res.bem_reverseBytes_0();
return bevt_38_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_4_3_MathInt bevl_c = null;
bevl_c = (new BEC_4_3_MathInt()).bem_new_0();
bevl_c.bem_setValue_1(this);
return bevl_c;
} /*method end*/
public BEC_4_3_MathInt bem_abs_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_copy_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1832132624, BEL_4_Base.bevn_absValue_0);
return (BEC_4_3_MathInt) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_absValue_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_37;
bevt_0_tmpvar_phold = this.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 251 */ {
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(-1));
this.bem_multiplyValue_1(bevt_2_tmpvar_phold);
} /* Line: 252 */
return this;
} /*method end*/
public BEC_4_3_MathInt bem_setValue_1(BEC_4_3_MathInt beva_xi) throws Throwable {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_increment_0() throws Throwable {
BEC_4_3_MathInt bevl_res = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 272 */ {
bevl_res = (new BEC_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /* Line: 279 */
} /*method end*/
public BEC_4_3_MathInt bem_decrement_0() throws Throwable {
BEC_4_3_MathInt bevl_res = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 287 */ {
bevl_res = (new BEC_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /* Line: 294 */
} /*method end*/
public BEC_4_3_MathInt bem_incrementValue_0() throws Throwable {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_4_3_MathInt bem_decrementValue_0() throws Throwable {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_4_3_MathInt bem_add_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_4_3_MathInt bevl_res = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 330 */ {
bevl_res = (new BEC_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /* Line: 337 */
} /*method end*/
public BEC_4_3_MathInt bem_addValue_1(BEC_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_4_3_MathInt bem_subtract_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_4_3_MathInt bevl_res = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 359 */ {
bevl_res = (new BEC_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /* Line: 366 */
} /*method end*/
public BEC_4_3_MathInt bem_subtractValue_1(BEC_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_4_3_MathInt bem_multiply_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_4_3_MathInt bevl_res = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 388 */ {
bevl_res = (new BEC_4_3_MathInt()).bem_new_0();

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /* Line: 395 */
} /*method end*/
public BEC_4_3_MathInt bem_multiplyValue_1(BEC_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_4_3_MathInt bem_divide_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_4_3_MathInt bevl_res = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 417 */ {
bevl_res = (new BEC_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /* Line: 429 */
} /*method end*/
public BEC_4_3_MathInt bem_divideValue_1(BEC_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_4_3_MathInt bem_modulus_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_4_3_MathInt bevl_res = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 456 */ {
bevl_res = (new BEC_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /* Line: 463 */
} /*method end*/
public BEC_4_3_MathInt bem_modulusValue_1(BEC_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_4_3_MathInt bem_and_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_4_3_MathInt()).bem_new_0();

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_4_3_MathInt bem_andValue_1(BEC_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_4_3_MathInt bem_or_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_4_3_MathInt()).bem_new_0();

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_4_3_MathInt bem_orValue_1(BEC_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_4_3_MathInt bem_shiftLeft_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_4_3_MathInt()).bem_new_0();

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_4_3_MathInt bem_shiftLeftValue_1(BEC_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_4_3_MathInt bem_shiftRight_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_4_3_MathInt()).bem_new_0();

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_4_3_MathInt bem_shiftRightValue_1(BEC_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_4_3_MathInt bem_power_1(BEC_4_3_MathInt beva_other) throws Throwable {
BEC_4_3_MathInt bevl_result = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_result = (new BEC_4_3_MathInt(1));
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 604 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(beva_other);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 604 */ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bem_incrementValue_0();
} /* Line: 604 */
 else  /* Line: 604 */ {
break;
} /* Line: 604 */
} /* Line: 604 */
return bevl_result;
} /*method end*/
public BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_xi) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (beva_xi instanceof BEC_4_3_MathInt && this.bevi_int == ((BEC_4_3_MathInt)beva_xi).bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_xi) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (!(beva_xi instanceof BEC_4_3_MathInt) || this.bevi_int != ((BEC_4_3_MathInt)beva_xi).bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_greater_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_lesser_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_greaterEquals_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_lesserEquals_1(BEC_4_3_MathInt beva_xi) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_vintSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_vint = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {69, 69, 72, 76, 80, 80, 80, 80, 80, 80, 80, 80, 80, 84, 84, 84, 84, 84, 84, 84, 84, 84, 88, 88, 0, 88, 88, 0, 0, 89, 89, 89, 89, 91, 91, 92, 94, 96, 96, 97, 97, 97, 97, 98, 98, 98, 98, 99, 103, 103, 104, 104, 105, 106, 107, 108, 108, 110, 112, 112, 112, 0, 0, 0, 113, 113, 114, 115, 116, 116, 116, 0, 0, 0, 117, 117, 118, 119, 120, 120, 120, 0, 0, 0, 121, 121, 122, 123, 124, 124, 126, 126, 128, 128, 128, 128, 128, 128, 128, 130, 131, 136, 136, 140, 144, 144, 148, 159, 177, 181, 181, 181, 181, 181, 181, 181, 181, 185, 185, 185, 185, 189, 189, 189, 189, 189, 189, 193, 193, 193, 193, 193, 197, 197, 197, 197, 201, 202, 203, 204, 204, 205, 206, 207, 207, 208, 208, 210, 213, 213, 213, 214, 214, 214, 214, 216, 216, 217, 217, 217, 217, 221, 224, 224, 225, 225, 225, 226, 226, 226, 226, 228, 228, 228, 228, 229, 229, 229, 229, 234, 234, 235, 235, 237, 237, 241, 242, 243, 247, 247, 247, 251, 251, 252, 252, 268, 273, 279, 288, 294, 312, 326, 331, 337, 355, 360, 366, 384, 389, 395, 413, 418, 429, 452, 457, 463, 481, 485, 496, 510, 514, 525, 539, 543, 554, 568, 572, 583, 597, 602, 604, 604, 605, 604, 607, 639, 639, 668, 668, 689, 689, 710, 710, 731, 731, 752, 752, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {67, 68, 71, 75, 87, 88, 89, 90, 91, 92, 93, 94, 95, 107, 108, 109, 110, 111, 112, 113, 114, 115, 139, 140, 142, 145, 146, 148, 151, 155, 156, 157, 158, 160, 161, 163, 166, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 213, 214, 215, 216, 217, 218, 219, 222, 223, 225, 226, 227, 229, 231, 234, 238, 241, 242, 243, 244, 247, 248, 250, 252, 255, 259, 262, 263, 264, 265, 268, 269, 271, 273, 276, 280, 283, 284, 285, 286, 289, 290, 292, 293, 296, 297, 298, 299, 300, 301, 302, 307, 308, 318, 319, 322, 327, 328, 331, 335, 338, 348, 349, 350, 351, 352, 353, 354, 355, 361, 362, 363, 364, 372, 373, 374, 375, 376, 377, 384, 385, 386, 387, 388, 394, 395, 396, 397, 441, 442, 443, 446, 447, 449, 450, 451, 452, 454, 455, 458, 460, 461, 462, 464, 465, 466, 467, 469, 470, 471, 472, 473, 474, 475, 483, 484, 486, 487, 488, 490, 491, 492, 493, 495, 496, 497, 498, 499, 500, 501, 502, 508, 509, 511, 512, 514, 515, 519, 520, 521, 526, 527, 528, 534, 535, 537, 538, 545, 551, 554, 561, 564, 570, 575, 581, 584, 590, 596, 599, 605, 611, 614, 620, 626, 629, 635, 641, 644, 650, 654, 657, 662, 666, 669, 674, 678, 681, 686, 690, 693, 698, 704, 705, 708, 710, 711, 717, 726, 727, 736, 737, 746, 747, 756, 757, 766, 767, 776, 777, 780};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 69 67
new 0 69 67
return 1 69 68
setStringValueDec 1 72 71
setStringValueHex 1 76 75
assign 1 80 87
new 0 80 87
assign 1 80 88
once 0 80 88
assign 1 80 89
new 0 80 89
assign 1 80 90
once 0 80 90
assign 1 80 91
new 0 80 91
assign 1 80 92
once 0 80 92
assign 1 80 93
new 0 80 93
assign 1 80 94
once 0 80 94
setStringValue 5 80 95
assign 1 84 107
new 0 84 107
assign 1 84 108
once 0 84 108
assign 1 84 109
new 0 84 109
assign 1 84 110
once 0 84 110
assign 1 84 111
new 0 84 111
assign 1 84 112
once 0 84 112
assign 1 84 113
new 0 84 113
assign 1 84 114
once 0 84 114
setStringValue 5 84 115
assign 1 88 139
new 0 88 139
assign 1 88 140
lesser 1 88 140
assign 1 0 142
assign 1 88 145
new 0 88 145
assign 1 88 146
greater 1 88 146
assign 1 0 148
assign 1 0 151
assign 1 89 155
new 0 89 155
assign 1 89 156
add 1 89 156
assign 1 89 157
new 1 89 157
throw 1 89 158
assign 1 91 160
new 0 91 160
assign 1 91 161
lesser 1 91 161
assign 1 92 163
copy 0 92 163
assign 1 94 166
new 0 94 166
assign 1 96 168
new 0 96 168
addValue 1 96 169
assign 1 97 170
new 0 97 170
assign 1 97 171
new 0 97 171
assign 1 97 172
subtract 1 97 172
assign 1 97 173
add 1 97 173
assign 1 98 174
new 0 98 174
assign 1 98 175
new 0 98 175
assign 1 98 176
subtract 1 98 176
assign 1 98 177
add 1 98 177
setStringValue 5 99 178
assign 1 103 213
new 0 103 213
setValue 1 103 214
assign 1 104 215
sizeGet 0 104 215
assign 1 104 216
copy 0 104 216
decrementValue 0 105 217
assign 1 106 218
new 0 106 218
assign 1 107 219
new 0 107 219
assign 1 108 222
new 0 108 222
assign 1 108 223
greaterEquals 1 108 223
getInt 2 110 225
assign 1 112 226
new 0 112 226
assign 1 112 227
greater 1 112 227
assign 1 112 229
lesser 1 112 229
assign 1 0 231
assign 1 0 234
assign 1 0 238
assign 1 113 241
new 0 113 241
subtractValue 1 113 242
multiplyValue 1 114 243
addValue 1 115 244
assign 1 116 247
new 0 116 247
assign 1 116 248
greater 1 116 248
assign 1 116 250
lesser 1 116 250
assign 1 0 252
assign 1 0 255
assign 1 0 259
assign 1 117 262
new 0 117 262
subtractValue 1 117 263
multiplyValue 1 118 264
addValue 1 119 265
assign 1 120 268
new 0 120 268
assign 1 120 269
greater 1 120 269
assign 1 120 271
lesser 1 120 271
assign 1 0 273
assign 1 0 276
assign 1 0 280
assign 1 121 283
new 0 121 283
subtractValue 1 121 284
multiplyValue 1 122 285
addValue 1 123 286
assign 1 124 289
new 0 124 289
assign 1 124 290
equals 1 124 290
assign 1 126 292
new 0 126 292
multiplyValue 1 126 293
assign 1 128 296
new 0 128 296
assign 1 128 297
add 1 128 297
assign 1 128 298
new 0 128 298
assign 1 128 299
add 1 128 299
assign 1 128 300
add 1 128 300
assign 1 128 301
new 1 128 301
throw 1 128 302
decrementValue 0 130 307
multiplyValue 1 131 308
assign 1 136 318
toString 0 136 318
return 1 136 319
new 1 140 322
assign 1 144 327
new 0 144 327
return 1 144 328
return 1 148 331
assign 1 159 335
new 0 159 335
return 1 177 338
assign 1 181 348
new 0 181 348
assign 1 181 349
new 1 181 349
assign 1 181 350
new 0 181 350
assign 1 181 351
once 0 181 351
assign 1 181 352
new 0 181 352
assign 1 181 353
once 0 181 353
assign 1 181 354
toString 4 181 354
return 1 181 355
assign 1 185 361
new 0 185 361
assign 1 185 362
new 1 185 362
assign 1 185 363
toHexString 1 185 363
return 1 185 364
assign 1 189 372
new 0 189 372
assign 1 189 373
once 0 189 373
assign 1 189 374
new 0 189 374
assign 1 189 375
once 0 189 375
assign 1 189 376
toString 3 189 376
return 1 189 377
assign 1 193 384
new 1 193 384
assign 1 193 385
new 0 193 385
assign 1 193 386
once 0 193 386
assign 1 193 387
toString 4 193 387
return 1 193 388
assign 1 197 394
new 0 197 394
assign 1 197 395
once 0 197 395
assign 1 197 396
toString 4 197 396
return 1 197 397
clear 0 201 441
assign 1 202 442
abs 0 202 442
assign 1 203 443
new 0 203 443
assign 1 204 446
new 0 204 446
assign 1 204 447
greater 1 204 447
setValue 1 205 449
modulusValue 1 206 450
assign 1 207 451
new 0 207 451
assign 1 207 452
lesser 1 207 452
assign 1 208 454
new 0 208 454
addValue 1 208 455
addValue 1 210 458
assign 1 213 460
capacityGet 0 213 460
assign 1 213 461
sizeGet 0 213 461
assign 1 213 462
lesserEquals 1 213 462
assign 1 214 464
capacityGet 0 214 464
assign 1 214 465
new 0 214 465
assign 1 214 466
add 1 214 466
capacitySet 1 214 467
assign 1 216 469
sizeGet 0 216 469
setIntUnchecked 2 216 470
assign 1 217 471
sizeGet 0 217 471
assign 1 217 472
new 0 217 472
assign 1 217 473
add 1 217 473
sizeSet 1 217 474
divideValue 1 221 475
assign 1 224 483
sizeGet 0 224 483
assign 1 224 484
lesser 1 224 484
assign 1 225 486
capacityGet 0 225 486
assign 1 225 487
sizeGet 0 225 487
assign 1 225 488
lesserEquals 1 225 488
assign 1 226 490
capacityGet 0 226 490
assign 1 226 491
new 0 226 491
assign 1 226 492
add 1 226 492
capacitySet 1 226 493
assign 1 228 495
sizeGet 0 228 495
assign 1 228 496
new 0 228 496
assign 1 228 497
once 0 228 497
setIntUnchecked 2 228 498
assign 1 229 499
sizeGet 0 229 499
assign 1 229 500
new 0 229 500
assign 1 229 501
add 1 229 501
sizeSet 1 229 502
assign 1 234 508
new 0 234 508
assign 1 234 509
lesser 1 234 509
assign 1 235 511
new 0 235 511
addValue 1 235 512
assign 1 237 514
reverseBytes 0 237 514
return 1 237 515
assign 1 241 519
new 0 241 519
setValue 1 242 520
return 1 243 521
assign 1 247 526
copy 0 247 526
assign 1 247 527
absValue 0 247 527
return 1 247 528
assign 1 251 534
new 0 251 534
assign 1 251 535
lesser 1 251 535
assign 1 252 537
new 0 252 537
multiplyValue 1 252 538
return 1 268 545
assign 1 273 551
new 0 273 551
return 1 279 554
assign 1 288 561
new 0 288 561
return 1 294 564
return 1 312 570
return 1 326 575
assign 1 331 581
new 0 331 581
return 1 337 584
return 1 355 590
assign 1 360 596
new 0 360 596
return 1 366 599
return 1 384 605
assign 1 389 611
new 0 389 611
return 1 395 614
return 1 413 620
assign 1 418 626
new 0 418 626
return 1 429 629
return 1 452 635
assign 1 457 641
new 0 457 641
return 1 463 644
return 1 481 650
assign 1 485 654
new 0 485 654
return 1 496 657
return 1 510 662
assign 1 514 666
new 0 514 666
return 1 525 669
return 1 539 674
assign 1 543 678
new 0 543 678
return 1 554 681
return 1 568 686
assign 1 572 690
new 0 572 690
return 1 583 693
return 1 597 698
assign 1 602 704
new 0 602 704
assign 1 604 705
new 0 604 705
assign 1 604 708
lesser 1 604 708
multiplyValue 1 605 710
incrementValue 0 604 711
return 1 607 717
assign 1 639 726
new 0 639 726
return 1 639 727
assign 1 668 736
new 0 668 736
return 1 668 737
assign 1 689 746
new 0 689 746
return 1 689 747
assign 1 710 756
new 0 710 756
return 1 710 757
assign 1 731 766
new 0 731 766
return 1 731 767
assign 1 752 776
new 0 752 776
return 1 752 777
assign 1 0 780
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1085372256: return bem_increment_0();
case 314718434: return bem_print_0();
case 92614563: return bem_abs_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1205852557: return bem_incrementValue_0();
case 2011061582: return bem_vintGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 2022143834: return bem_vintSet_0();
case 1046151292: return bem_decrement_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 663753935: return bem_decrementValue_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1717721534: return bem_toHexString_0();
case 1820417453: return bem_create_0();
case 1832132624: return bem_absValue_0();
case 1865310226: return bem_toFloat_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 736217829: return bem_shiftLeft_1((BEC_4_3_MathInt) bevd_0);
case 92659731: return bem_add_1((BEC_4_3_MathInt) bevd_0);
case 1551584407: return bem_modulus_1((BEC_4_3_MathInt) bevd_0);
case 3419349: return bem_or_1((BEC_4_3_MathInt) bevd_0);
case 81310150: return bem_subtract_1((BEC_4_3_MathInt) bevd_0);
case 50808448: return bem_orValue_1((BEC_4_3_MathInt) bevd_0);
case 2139839746: return bem_addValue_1((BEC_4_3_MathInt) bevd_0);
case 1567199433: return bem_shiftRightValue_1((BEC_4_3_MathInt) bevd_0);
case 202757140: return bem_shiftRight_1((BEC_4_3_MathInt) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1580104161: return bem_multiplyValue_1((BEC_4_3_MathInt) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 696708346: return bem_shiftLeftValue_1((BEC_4_3_MathInt) bevd_0);
case 364269035: return bem_divide_1((BEC_4_3_MathInt) bevd_0);
case 1717721533: return bem_toHexString_1((BEC_4_6_TextString) bevd_0);
case 2022143835: return bem_vintSet_1(bevd_0);
case 440702026: return bem_setStringValueDec_1((BEC_4_6_TextString) bevd_0);
case 477101321: return bem_hexNew_1((BEC_4_6_TextString) bevd_0);
case 1265088726: return bem_multiply_1((BEC_4_3_MathInt) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2116933162: return bem_divideValue_1((BEC_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_4_3_MathInt) bevd_0);
case 432448303: return bem_subtractValue_1((BEC_4_3_MathInt) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1220624855: return bem_lesserEquals_1((BEC_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1089696223: return bem_setValue_1((BEC_4_3_MathInt) bevd_0);
case 1852231828: return bem_modulusValue_1((BEC_4_3_MathInt) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 979186229: return bem_greaterEquals_1((BEC_4_3_MathInt) bevd_0);
case 92957641: return bem_and_1((BEC_4_3_MathInt) bevd_0);
case 436987761: return bem_setStringValueHex_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 387946633: return bem_power_1((BEC_4_3_MathInt) bevd_0);
case 1245164300: return bem_andValue_1((BEC_4_3_MathInt) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1774940959: return bem_toString_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1670339153: return bem_setStringValue_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 1774940960: return bem_toString_3((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1, (BEC_4_3_MathInt) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1774940961: return bem_toString_4((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_6_6_SystemObject bemd_5(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3, BEC_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case 1670339156: return bem_setStringValue_5((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_4_3_MathInt) bevd_3, (BEC_4_3_MathInt) bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_3_MathInt();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_3_MathInt.bevs_inst = (BEC_4_3_MathInt)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_3_MathInt.bevs_inst;
}
}
