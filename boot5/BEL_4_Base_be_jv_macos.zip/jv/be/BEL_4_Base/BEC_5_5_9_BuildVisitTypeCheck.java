package be.BEL_4_Base;
/* File: source/build/Pass12.be */
public class BEC_5_5_9_BuildVisitTypeCheck extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_9_BuildVisitTypeCheck() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x54,0x79,0x70,0x65,0x43,0x68,0x65,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x43,0x61,0x74,0x63,0x68,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x75,0x6E,0x74,0x79,0x70,0x65,0x64,0x20,0x28,0x76,0x61,0x72,0x29};
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_3 = {0x53,0x65,0x6C,0x66,0x20,0x6F,0x76,0x61,0x72,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x73,0x79,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_4 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x2C,0x20};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_4, 30));
private static byte[] bels_5 = {0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x73,0x74,0x20,0x74,0x6F,0x20};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_5, 19));
private static byte[] bels_6 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_7 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_8 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x65,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x63,0x61,0x73,0x74,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66,0x20,0x74,0x79,0x70,0x65,0x2E,0x20};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_8, 67));
private static byte[] bels_9 = {0x20};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_9, 1));
private static byte[] bels_10 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2E};
private static byte[] bels_11 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_12 = {0x6E,0x65,0x77,0x4E,0x70,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x74,0x79,0x70,0x65,0x63,0x68,0x65,0x63,0x6B,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_14 = {0x47,0x6F,0x74,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6E,0x6E,0x6F,0x64,0x65};
private static byte[] bels_15 = {0x6E,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x76,0x61,0x72,0x20};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_15, 19));
private static byte[] bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x61,0x74,0x69,0x62,0x6C,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x2C,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_16, 52));
private static byte[] bels_17 = {0x20,0x67,0x6F,0x74,0x20};
private static BEC_4_6_TextString bevo_6 = (new BEC_4_6_TextString(bels_17, 5));
public static BEC_5_5_9_BuildVisitTypeCheck bevs_inst;
public BEC_6_6_SystemObject bevp_emitter;
public BEC_5_4_BuildNode bevp_inClass;
public BEC_6_6_SystemObject bevp_inClassNp;
public BEC_6_6_SystemObject bevp_inClassSyn;
public BEC_4_3_MathInt bevp_cpos;
public BEC_5_5_9_BuildVisitTypeCheck bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_5_4_BuildNode bevl_cci = null;
BEC_5_4_BuildNode bevl_targ = null;
BEC_6_6_SystemObject bevl_tvar = null;
BEC_6_6_SystemObject bevl_ovar = null;
BEC_5_8_BuildClassSyn bevl_syn = null;
BEC_6_6_SystemObject bevl_mtdmy = null;
BEC_5_4_BuildNode bevl_ctarg = null;
BEC_6_6_SystemObject bevl_cvar = null;
BEC_6_6_SystemObject bevl_mtdc = null;
BEC_5_4_BuildNode bevl_org = null;
BEC_5_4_LogicBool bevl_castForSelf = null;
BEC_6_6_SystemObject bevl_ovnp = null;
BEC_6_6_SystemObject bevl_targsyn = null;
BEC_9_5_ContainerArray bevl_argSyns = null;
BEC_5_4_BuildNode bevl_nnode = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_6_BuildVarSyn bevl_marg = null;
BEC_5_3_BuildVar bevl_carg = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_16_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_86_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_87_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_94_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_103_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_106_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_113_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_119_tmpvar_phold = null;
BEC_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_125_tmpvar_phold = null;
BEC_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_129_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_130_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_132_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_137_tmpvar_phold = null;
BEC_4_3_MathInt bevt_138_tmpvar_phold = null;
BEC_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_143_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_144_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_147_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_148_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_152_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_155_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_161_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_164_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_165_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_166_tmpvar_phold = null;
BEC_4_6_TextString bevt_167_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_169_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_170_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_171_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_173_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_175_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_176_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_177_tmpvar_phold = null;
BEC_4_6_TextString bevt_178_tmpvar_phold = null;
BEC_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_4_6_TextString bevt_180_tmpvar_phold = null;
BEC_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_182_tmpvar_phold = null;
BEC_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_184_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_185_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_186_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_187_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_189_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_191_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_192_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_193_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_194_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_195_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_196_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_197_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_198_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_199_tmpvar_phold = null;
BEC_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_201_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_202_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_203_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_204_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_205_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_206_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_207_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_208_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_210_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_211_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_212_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_214_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_216_tmpvar_phold = null;
BEC_4_6_TextString bevt_217_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_219_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_220_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_221_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_222_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_224_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_225_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_227_tmpvar_phold = null;
BEC_4_6_TextString bevt_228_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_229_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_230_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_231_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_232_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_233_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_235_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_236_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_237_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_238_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_239_tmpvar_phold = null;
BEC_4_6_TextString bevt_240_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_241_tmpvar_phold = null;
BEC_4_3_MathInt bevt_242_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_243_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_244_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_245_tmpvar_phold = null;
BEC_4_6_TextString bevt_246_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_247_tmpvar_phold = null;
BEC_4_3_MathInt bevt_248_tmpvar_phold = null;
BEC_4_3_MathInt bevt_249_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_250_tmpvar_phold = null;
BEC_4_3_MathInt bevt_251_tmpvar_phold = null;
BEC_4_3_MathInt bevt_252_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_253_tmpvar_phold = null;
BEC_4_6_TextString bevt_254_tmpvar_phold = null;
BEC_4_6_TextString bevt_255_tmpvar_phold = null;
BEC_4_6_TextString bevt_256_tmpvar_phold = null;
BEC_4_3_MathInt bevt_257_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_258_tmpvar_phold = null;
BEC_4_3_MathInt bevt_259_tmpvar_phold = null;
BEC_4_3_MathInt bevt_260_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_261_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_263_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_264_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_265_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_266_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_267_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_268_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_269_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_270_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_271_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_272_tmpvar_phold = null;
BEC_4_6_TextString bevt_273_tmpvar_phold = null;
BEC_4_6_TextString bevt_274_tmpvar_phold = null;
BEC_4_6_TextString bevt_275_tmpvar_phold = null;
BEC_4_6_TextString bevt_276_tmpvar_phold = null;
BEC_4_6_TextString bevt_277_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_278_tmpvar_phold = null;
BEC_4_6_TextString bevt_279_tmpvar_phold = null;
BEC_4_6_TextString bevt_280_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_281_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_282_tmpvar_phold = null;
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 366 */ {
bevt_16_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_firstGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 367 */ {
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(46, bels_0));
bevt_17_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_17_tmpvar_phold);
} /* Line: 368 */
} /* Line: 367 */
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 371 */ {
bevp_inClass = beva_node;
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_22_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_23_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_23_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 374 */
bevt_25_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_equals_1(bevt_26_tmpvar_phold);
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 376 */ {
bevp_cpos = (new BEC_4_3_MathInt(0));
} /* Line: 377 */
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_equals_1(bevt_29_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 379 */ {
bevt_30_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_30_tmpvar_phold.bemd_1(2117282045, BEL_4_Base.bevn_cposSet_1, bevp_cpos);
bevp_cpos = bevp_cpos.bem_increment_0();
bevt_31_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_0_tmpvar_loop = bevt_31_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 382 */ {
bevt_32_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 382 */ {
bevl_cci = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_cci.bem_typenameGet_0();
bevt_35_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_equals_1(bevt_35_tmpvar_phold);
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 383 */ {
bevt_36_tmpvar_phold = bevl_cci.bem_heldGet_0();
bevt_36_tmpvar_phold.bemd_1(474935663, BEL_4_Base.bevn_addCall_1, beva_node);
} /* Line: 384 */
} /* Line: 383 */
 else  /* Line: 382 */ {
break;
} /* Line: 382 */
} /* Line: 382 */
bevt_39_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_40_tmpvar_phold = (new BEC_4_6_TextString(6, bels_1));
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_40_tmpvar_phold);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 395 */ {
bevt_41_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_5_4_BuildNode) bevt_41_tmpvar_phold.bem_firstGet_0();
bevt_43_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_42_tmpvar_phold != null && bevt_42_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_42_tmpvar_phold).bevi_bool) /* Line: 398 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 399 */
 else  /* Line: 400 */ {
bevt_45_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_47_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_46_tmpvar_phold);
bevl_tvar = bevt_44_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 401 */
bevt_49_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_48_tmpvar_phold != null && bevt_48_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_48_tmpvar_phold).bevi_bool) /* Line: 404 */ {
bevt_50_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_50_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_51_tmpvar_phold);
} /* Line: 405 */
 else  /* Line: 406 */ {
bevl_org = beva_node.bem_secondGet_0();
bevt_53_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_54_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_equals_1(bevt_54_tmpvar_phold);
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 408 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 408 */ {
bevt_56_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_57_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bem_equals_1(bevt_57_tmpvar_phold);
if (bevt_55_tmpvar_phold.bevi_bool) /* Line: 408 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 408 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 408 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 408 */ {
bevt_58_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_58_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_59_tmpvar_phold);
} /* Line: 410 */
 else  /* Line: 411 */ {
bevt_61_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_62_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_equals_1(bevt_62_tmpvar_phold);
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 412 */ {
bevt_64_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 413 */ {
bevl_ovar = bevl_org.bem_heldGet_0();
} /* Line: 414 */
 else  /* Line: 415 */ {
bevt_66_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_68_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_67_tmpvar_phold);
bevl_ovar = bevt_65_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 417 */
} /* Line: 413 */
 else  /* Line: 412 */ {
bevt_70_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_71_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_equals_1(bevt_71_tmpvar_phold);
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 420 */ {
bevt_72_tmpvar_phold = bevl_org.bem_containedGet_0();
bevl_ctarg = (BEC_5_4_BuildNode) bevt_72_tmpvar_phold.bem_firstGet_0();
bevt_74_tmpvar_phold = bevl_ctarg.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 423 */ {
bevl_cvar = bevl_ctarg.bem_heldGet_0();
} /* Line: 425 */
 else  /* Line: 426 */ {
bevt_76_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_78_tmpvar_phold = bevl_ctarg.bem_heldGet_0();
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_77_tmpvar_phold);
bevl_cvar = bevt_75_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 428 */
bevl_syn = null;
bevt_81_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_80_tmpvar_phold == null) {
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 432 */ {
bevt_83_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_82_tmpvar_phold);
} /* Line: 433 */
 else  /* Line: 432 */ {
bevt_84_tmpvar_phold = bevl_cvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_84_tmpvar_phold != null && bevt_84_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_84_tmpvar_phold).bevi_bool) /* Line: 434 */ {
bevt_85_tmpvar_phold = bevl_cvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_85_tmpvar_phold);
} /* Line: 436 */
} /* Line: 432 */
if (bevl_syn == null) {
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_86_tmpvar_phold.bevi_bool) /* Line: 438 */ {
bevt_87_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_89_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_87_tmpvar_phold.bem_get_1(bevt_88_tmpvar_phold);
if (bevl_mtdc == null) {
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 440 */ {
bevt_92_tmpvar_phold = (new BEC_4_6_TextString(12, bels_2));
bevt_91_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_92_tmpvar_phold, bevl_org);
throw new be.BELS_Base.BECS_ThrowBack(bevt_91_tmpvar_phold);
} /* Line: 441 */
 else  /* Line: 442 */ {
bevl_ovar = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
} /* Line: 443 */
} /* Line: 440 */
} /* Line: 438 */
} /* Line: 412 */
if (bevl_ovar == null) {
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 447 */ {
bevt_94_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_94_tmpvar_phold != null && bevt_94_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_94_tmpvar_phold).bevi_bool) /* Line: 447 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 447 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 447 */
 else  /* Line: 447 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 447 */ {
bevl_castForSelf = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_95_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_95_tmpvar_phold != null && bevt_95_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_95_tmpvar_phold).bevi_bool) /* Line: 450 */ {
if (bevl_syn == null) {
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_96_tmpvar_phold.bevi_bool) /* Line: 452 */ {
bevt_98_tmpvar_phold = (new BEC_4_6_TextString(28, bels_3));
bevt_97_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_98_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_97_tmpvar_phold);
} /* Line: 453 */
bevt_100_tmpvar_phold = bevl_mtdc.bemd_0(1707345409, BEL_4_Base.bevn_originGet_0);
bevt_101_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_101_tmpvar_phold);
if (bevt_99_tmpvar_phold != null && bevt_99_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_99_tmpvar_phold).bevi_bool) /* Line: 458 */ {
bevl_castForSelf = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 460 */
 else  /* Line: 458 */ {
bevt_103_tmpvar_phold = bevp_build.bem_emitCommonGet_0();
if (bevt_103_tmpvar_phold == null) {
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 461 */ {
bevt_106_tmpvar_phold = bevp_build.bem_emitCommonGet_0();
bevt_105_tmpvar_phold = bevt_106_tmpvar_phold.bem_covariantReturnsGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_104_tmpvar_phold != null && bevt_104_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_104_tmpvar_phold).bevi_bool) /* Line: 461 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 461 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 461 */
 else  /* Line: 461 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 461 */ {
bevl_castForSelf = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 462 */
} /* Line: 458 */
} /* Line: 458 */
 else  /* Line: 450 */ {
if (bevl_mtdc == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 464 */ {
bevt_108_tmpvar_phold = bevl_mtdc.bemd_2(583049050, BEL_4_Base.bevn_getEmitReturnType_2, bevl_syn, bevp_build);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_108_tmpvar_phold);
} /* Line: 465 */
 else  /* Line: 466 */ {
bevt_109_tmpvar_phold = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_109_tmpvar_phold);
} /* Line: 467 */
} /* Line: 450 */
bevt_111_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_110_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_5_8_BuildNamePath) bevt_111_tmpvar_phold);
if (bevt_110_tmpvar_phold != null && bevt_110_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_110_tmpvar_phold).bevi_bool) /* Line: 471 */ {
bevt_112_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_113_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_112_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_113_tmpvar_phold);
} /* Line: 473 */
 else  /* Line: 474 */ {
bevt_114_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_114_tmpvar_phold != null && bevt_114_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_114_tmpvar_phold).bevi_bool) /* Line: 475 */ {
bevl_ovnp = bevl_syn.bem_namepathGet_0();
} /* Line: 476 */
 else  /* Line: 477 */ {
bevl_ovnp = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 478 */
bevt_115_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_115_tmpvar_phold);
bevt_116_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_5_8_BuildNamePath) bevl_ovnp);
if (bevt_116_tmpvar_phold != null && bevt_116_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_116_tmpvar_phold).bevi_bool) /* Line: 481 */ {
bevt_117_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_118_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_117_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_118_tmpvar_phold);
} /* Line: 483 */
 else  /* Line: 484 */ {
bevt_123_tmpvar_phold = bevo_0;
bevt_125_tmpvar_phold = bevl_syn.bem_namepathGet_0();
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bem_toString_0();
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bem_add_1(bevt_124_tmpvar_phold);
bevt_126_tmpvar_phold = bevo_1;
bevt_121_tmpvar_phold = bevt_122_tmpvar_phold.bem_add_1(bevt_126_tmpvar_phold);
bevt_127_tmpvar_phold = bevl_ovnp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_120_tmpvar_phold = bevt_121_tmpvar_phold.bem_add_1(bevt_127_tmpvar_phold);
bevt_119_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_120_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_119_tmpvar_phold);
} /* Line: 485 */
} /* Line: 481 */
if (bevl_castForSelf.bevi_bool) /* Line: 489 */ {
bevt_128_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_129_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_128_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_129_tmpvar_phold);
} /* Line: 491 */
} /* Line: 489 */
bevt_132_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_131_tmpvar_phold = bevt_132_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevt_131_tmpvar_phold == null) {
bevt_130_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_130_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_130_tmpvar_phold.bevi_bool) /* Line: 494 */ {
} /* Line: 494 */
} /* Line: 494 */
} /* Line: 408 */
} /* Line: 404 */
 else  /* Line: 395 */ {
bevt_135_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_136_tmpvar_phold = (new BEC_4_6_TextString(6, bels_6));
bevt_133_tmpvar_phold = bevt_134_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpvar_phold);
if (bevt_133_tmpvar_phold != null && bevt_133_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_133_tmpvar_phold).bevi_bool) /* Line: 499 */ {
bevl_targ = beva_node.bem_secondGet_0();
bevt_138_tmpvar_phold = bevl_targ.bem_typenameGet_0();
bevt_139_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_137_tmpvar_phold = bevt_138_tmpvar_phold.bem_equals_1(bevt_139_tmpvar_phold);
if (bevt_137_tmpvar_phold.bevi_bool) /* Line: 501 */ {
bevt_141_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_140_tmpvar_phold = bevt_141_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_140_tmpvar_phold != null && bevt_140_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_140_tmpvar_phold).bevi_bool) /* Line: 502 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 503 */
 else  /* Line: 504 */ {
bevt_143_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_145_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_144_tmpvar_phold = bevt_145_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_142_tmpvar_phold = bevt_143_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_144_tmpvar_phold);
bevl_tvar = bevt_142_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 505 */
bevl_mtdmy = beva_node.bem_scopeGet_0();
bevt_147_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_146_tmpvar_phold = bevt_147_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_146_tmpvar_phold != null && bevt_146_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_146_tmpvar_phold).bevi_bool) /* Line: 509 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 510 */
 else  /* Line: 511 */ {
bevt_149_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_151_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_148_tmpvar_phold = bevt_149_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_150_tmpvar_phold);
bevl_tvar = bevt_148_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 512 */
bevt_154_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_153_tmpvar_phold == null) {
bevt_152_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_152_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_152_tmpvar_phold.bevi_bool) /* Line: 515 */ {
bevt_157_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_156_tmpvar_phold = bevt_157_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_155_tmpvar_phold = bevt_156_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_155_tmpvar_phold != null && bevt_155_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_155_tmpvar_phold).bevi_bool) /* Line: 515 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 515 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 515 */
 else  /* Line: 515 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 515 */ {
bevt_159_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_158_tmpvar_phold = bevt_159_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_158_tmpvar_phold != null && bevt_158_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_158_tmpvar_phold).bevi_bool) /* Line: 516 */ {
bevt_160_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_161_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_160_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_161_tmpvar_phold);
} /* Line: 518 */
 else  /* Line: 519 */ {
bevt_164_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_163_tmpvar_phold = bevt_164_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_162_tmpvar_phold != null && bevt_162_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_162_tmpvar_phold).bevi_bool) /* Line: 522 */ {
bevt_166_tmpvar_phold = bevl_tvar.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_167_tmpvar_phold = (new BEC_4_6_TextString(4, bels_7));
bevt_165_tmpvar_phold = bevt_166_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_167_tmpvar_phold);
if (bevt_165_tmpvar_phold != null && bevt_165_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_165_tmpvar_phold).bevi_bool) /* Line: 523 */ {
bevt_168_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_169_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_168_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_169_tmpvar_phold);
} /* Line: 525 */
 else  /* Line: 526 */ {
bevt_170_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_targsyn = bevp_build.bem_getSynNp_1(bevt_170_tmpvar_phold);
bevt_172_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_171_tmpvar_phold = bevp_inClassSyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_172_tmpvar_phold);
if (bevt_171_tmpvar_phold != null && bevt_171_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_171_tmpvar_phold).bevi_bool) /* Line: 528 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 528 */ {
bevt_174_tmpvar_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_173_tmpvar_phold = bevl_targsyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_174_tmpvar_phold);
if (bevt_173_tmpvar_phold != null && bevt_173_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_173_tmpvar_phold).bevi_bool) /* Line: 528 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 528 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 528 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 528 */ {
bevt_175_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_176_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_175_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_176_tmpvar_phold);
} /* Line: 530 */
 else  /* Line: 531 */ {
bevt_181_tmpvar_phold = bevo_2;
bevt_182_tmpvar_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_180_tmpvar_phold = bevt_181_tmpvar_phold.bem_add_1(bevt_182_tmpvar_phold);
bevt_183_tmpvar_phold = bevo_3;
bevt_179_tmpvar_phold = bevt_180_tmpvar_phold.bem_add_1(bevt_183_tmpvar_phold);
bevt_184_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_178_tmpvar_phold = bevt_179_tmpvar_phold.bem_add_1(bevt_184_tmpvar_phold);
bevt_177_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_178_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_177_tmpvar_phold);
} /* Line: 532 */
} /* Line: 528 */
} /* Line: 523 */
 else  /* Line: 535 */ {
bevt_185_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_185_tmpvar_phold);
bevt_189_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_188_tmpvar_phold = bevt_189_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_187_tmpvar_phold = bevt_188_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_186_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_5_8_BuildNamePath) bevt_187_tmpvar_phold);
if (bevt_186_tmpvar_phold != null && bevt_186_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_186_tmpvar_phold).bevi_bool) /* Line: 537 */ {
bevt_190_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_191_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_190_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_191_tmpvar_phold);
} /* Line: 539 */
 else  /* Line: 540 */ {
bevt_194_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_193_tmpvar_phold = bevt_194_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_192_tmpvar_phold = bevt_193_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_192_tmpvar_phold);
bevt_196_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_195_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_5_8_BuildNamePath) bevt_196_tmpvar_phold);
if (bevt_195_tmpvar_phold != null && bevt_195_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_195_tmpvar_phold).bevi_bool) /* Line: 542 */ {
bevt_197_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_198_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_197_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_198_tmpvar_phold);
} /* Line: 544 */
 else  /* Line: 545 */ {
bevt_200_tmpvar_phold = (new BEC_4_6_TextString(25, bels_10));
bevt_199_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_200_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_199_tmpvar_phold);
} /* Line: 546 */
} /* Line: 542 */
} /* Line: 537 */
} /* Line: 522 */
} /* Line: 516 */
 else  /* Line: 551 */ {
bevt_201_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_202_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_201_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_202_tmpvar_phold);
} /* Line: 553 */
} /* Line: 515 */
 else  /* Line: 555 */ {
bevt_203_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_204_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_203_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_204_tmpvar_phold);
} /* Line: 556 */
} /* Line: 501 */
 else  /* Line: 558 */ {
bevt_205_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_5_4_BuildNode) bevt_205_tmpvar_phold.bem_firstGet_0();
bevt_207_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_206_tmpvar_phold = bevt_207_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_206_tmpvar_phold != null && bevt_206_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_206_tmpvar_phold).bevi_bool) /* Line: 561 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 562 */
 else  /* Line: 563 */ {
bevt_209_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_211_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_210_tmpvar_phold = bevt_211_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_208_tmpvar_phold = bevt_209_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_210_tmpvar_phold);
bevl_tvar = bevt_208_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 564 */
bevt_213_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_212_tmpvar_phold = bevt_213_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_212_tmpvar_phold != null && bevt_212_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_212_tmpvar_phold).bevi_bool) /* Line: 567 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 567 */ {
bevt_216_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_215_tmpvar_phold = bevt_216_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_217_tmpvar_phold = (new BEC_4_6_TextString(5, bels_11));
bevt_214_tmpvar_phold = bevt_215_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_217_tmpvar_phold);
if (bevt_214_tmpvar_phold != null && bevt_214_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_214_tmpvar_phold).bevi_bool) /* Line: 567 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 567 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 567 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 567 */ {
bevt_218_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_219_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_218_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_219_tmpvar_phold);
} /* Line: 568 */
 else  /* Line: 569 */ {
bevt_220_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_221_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_220_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_221_tmpvar_phold);
bevt_223_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_222_tmpvar_phold = bevt_223_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_222_tmpvar_phold != null && bevt_222_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_222_tmpvar_phold).bevi_bool) /* Line: 571 */ {
bevt_226_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_225_tmpvar_phold == null) {
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_224_tmpvar_phold.bevi_bool) /* Line: 572 */ {
bevt_228_tmpvar_phold = (new BEC_4_6_TextString(49, bels_12));
bevt_227_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_228_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_227_tmpvar_phold);
} /* Line: 573 */
bevt_230_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_229_tmpvar_phold = bevt_230_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_229_tmpvar_phold);
bevt_231_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_233_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_232_tmpvar_phold = bevt_233_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_231_tmpvar_phold.bem_get_1(bevt_232_tmpvar_phold);
} /* Line: 576 */
 else  /* Line: 577 */ {
bevt_234_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_234_tmpvar_phold);
bevt_235_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_237_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_236_tmpvar_phold = bevt_237_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_235_tmpvar_phold.bem_get_1(bevt_236_tmpvar_phold);
} /* Line: 579 */
if (bevl_mtdc == null) {
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_238_tmpvar_phold.bevi_bool) /* Line: 581 */ {
bevt_240_tmpvar_phold = (new BEC_4_6_TextString(12, bels_13));
bevt_239_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_240_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_239_tmpvar_phold);
} /* Line: 582 */
bevl_argSyns = (BEC_9_5_ContainerArray) bevl_mtdc.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_nnode = bevl_targ.bem_nextPeerGet_0();
bevl_i = (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 586 */ {
bevt_242_tmpvar_phold = bevl_argSyns.bem_lengthGet_0();
bevt_241_tmpvar_phold = bevl_i.bem_lesser_1(bevt_242_tmpvar_phold);
if (bevt_241_tmpvar_phold.bevi_bool) /* Line: 586 */ {
bevl_marg = (BEC_5_6_BuildVarSyn) bevl_argSyns.bem_get_1(bevl_i);
bevt_243_tmpvar_phold = bevl_marg.bem_isTypedGet_0();
if (bevt_243_tmpvar_phold.bevi_bool) /* Line: 588 */ {
if (bevl_nnode == null) {
bevt_244_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_244_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_244_tmpvar_phold.bevi_bool) /* Line: 589 */ {
bevt_246_tmpvar_phold = (new BEC_4_6_TextString(16, bels_14));
bevt_245_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_246_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_245_tmpvar_phold);
} /* Line: 590 */
 else  /* Line: 589 */ {
bevt_248_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_249_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_247_tmpvar_phold = bevt_248_tmpvar_phold.bem_notEquals_1(bevt_249_tmpvar_phold);
if (bevt_247_tmpvar_phold.bevi_bool) /* Line: 591 */ {
bevt_251_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_252_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_250_tmpvar_phold = bevt_251_tmpvar_phold.bem_notEquals_1(bevt_252_tmpvar_phold);
if (bevt_250_tmpvar_phold.bevi_bool) /* Line: 591 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 591 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 591 */
 else  /* Line: 591 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 591 */ {
bevt_255_tmpvar_phold = bevo_4;
bevt_257_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_256_tmpvar_phold = bevt_257_tmpvar_phold.bem_toString_0();
bevt_254_tmpvar_phold = bevt_255_tmpvar_phold.bem_add_1(bevt_256_tmpvar_phold);
bevt_253_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_254_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_253_tmpvar_phold);
} /* Line: 592 */
} /* Line: 589 */
bevt_259_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_260_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_258_tmpvar_phold = bevt_259_tmpvar_phold.bem_equals_1(bevt_260_tmpvar_phold);
if (bevt_258_tmpvar_phold.bevi_bool) /* Line: 594 */ {
bevl_carg = (BEC_5_3_BuildVar) bevl_nnode.bem_heldGet_0();
bevt_262_tmpvar_phold = bevl_carg.bem_isTypedGet_0();
bevt_261_tmpvar_phold = bevt_262_tmpvar_phold.bem_not_0();
if (bevt_261_tmpvar_phold.bevi_bool) /* Line: 596 */ {
bevt_263_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_264_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_263_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_264_tmpvar_phold);
bevt_266_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_265_tmpvar_phold = bevt_266_tmpvar_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevt_267_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_265_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_267_tmpvar_phold);
} /* Line: 598 */
 else  /* Line: 600 */ {
bevt_268_tmpvar_phold = bevl_carg.bem_namepathGet_0();
bevl_syn = bevp_build.bem_getSynNp_1(bevt_268_tmpvar_phold);
bevt_271_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_270_tmpvar_phold = bevl_syn.bem_castsTo_1(bevt_271_tmpvar_phold);
bevt_269_tmpvar_phold = bevt_270_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_269_tmpvar_phold != null && bevt_269_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_269_tmpvar_phold).bevi_bool) /* Line: 602 */ {
bevt_276_tmpvar_phold = bevo_5;
bevt_278_tmpvar_phold = bevl_syn.bem_namepathGet_0();
bevt_277_tmpvar_phold = bevt_278_tmpvar_phold.bem_toString_0();
bevt_275_tmpvar_phold = bevt_276_tmpvar_phold.bem_add_1(bevt_277_tmpvar_phold);
bevt_279_tmpvar_phold = bevo_6;
bevt_274_tmpvar_phold = bevt_275_tmpvar_phold.bem_add_1(bevt_279_tmpvar_phold);
bevt_281_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_280_tmpvar_phold = bevt_281_tmpvar_phold.bem_toString_0();
bevt_273_tmpvar_phold = bevt_274_tmpvar_phold.bem_add_1(bevt_280_tmpvar_phold);
bevt_272_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_273_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_272_tmpvar_phold);
} /* Line: 603 */
} /* Line: 602 */
} /* Line: 596 */
} /* Line: 594 */
bevl_nnode = bevl_nnode.bem_nextPeerGet_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 586 */
 else  /* Line: 586 */ {
break;
} /* Line: 586 */
} /* Line: 586 */
} /* Line: 586 */
} /* Line: 567 */
} /* Line: 395 */
} /* Line: 395 */
bevt_282_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_282_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_6_6_SystemObject bem_emitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClass = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassNp = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassSynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassSyn = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_cposGet_0() throws Throwable {
return bevp_cpos;
} /*method end*/
public BEC_6_6_SystemObject bem_cposSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_cpos = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {366, 366, 366, 367, 367, 367, 367, 367, 367, 368, 368, 368, 371, 371, 371, 372, 373, 373, 374, 374, 376, 376, 376, 377, 379, 379, 379, 380, 380, 381, 382, 382, 0, 382, 382, 383, 383, 383, 384, 384, 395, 395, 395, 395, 396, 396, 398, 398, 399, 401, 401, 401, 401, 401, 404, 404, 405, 405, 405, 407, 408, 408, 408, 0, 408, 408, 408, 0, 0, 410, 410, 410, 412, 412, 412, 413, 413, 414, 417, 417, 417, 417, 417, 420, 420, 420, 421, 421, 423, 423, 425, 428, 428, 428, 428, 428, 431, 432, 432, 432, 432, 433, 433, 433, 434, 436, 436, 438, 438, 439, 439, 439, 439, 440, 440, 441, 441, 441, 443, 447, 447, 447, 0, 0, 0, 449, 450, 452, 452, 453, 453, 453, 458, 458, 458, 460, 461, 461, 461, 461, 461, 461, 0, 0, 0, 462, 464, 464, 465, 465, 467, 467, 471, 471, 473, 473, 473, 475, 476, 478, 480, 480, 481, 483, 483, 483, 485, 485, 485, 485, 485, 485, 485, 485, 485, 485, 491, 491, 491, 494, 494, 494, 494, 499, 499, 499, 499, 500, 501, 501, 501, 502, 502, 503, 505, 505, 505, 505, 505, 508, 509, 509, 510, 512, 512, 512, 512, 512, 515, 515, 515, 515, 515, 515, 515, 0, 0, 0, 516, 516, 518, 518, 518, 522, 522, 522, 523, 523, 523, 525, 525, 525, 527, 527, 528, 528, 0, 528, 528, 0, 0, 530, 530, 530, 532, 532, 532, 532, 532, 532, 532, 532, 532, 536, 536, 537, 537, 537, 537, 539, 539, 539, 541, 541, 541, 541, 542, 542, 544, 544, 544, 546, 546, 546, 553, 553, 553, 556, 556, 556, 559, 559, 561, 561, 562, 564, 564, 564, 564, 564, 567, 567, 0, 567, 567, 567, 567, 0, 0, 568, 568, 568, 570, 570, 570, 571, 571, 572, 572, 572, 572, 573, 573, 573, 575, 575, 575, 576, 576, 576, 576, 578, 578, 579, 579, 579, 579, 581, 581, 582, 582, 582, 584, 585, 586, 586, 586, 587, 588, 589, 589, 590, 590, 590, 591, 591, 591, 591, 591, 591, 0, 0, 0, 592, 592, 592, 592, 592, 592, 594, 594, 594, 595, 596, 596, 597, 597, 597, 598, 598, 598, 598, 601, 601, 602, 602, 602, 603, 603, 603, 603, 603, 603, 603, 603, 603, 603, 603, 612, 586, 617, 617, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {343, 344, 345, 347, 348, 349, 350, 351, 352, 354, 355, 356, 359, 360, 361, 363, 364, 365, 366, 367, 369, 370, 371, 373, 375, 376, 377, 379, 380, 381, 382, 383, 383, 386, 388, 389, 390, 391, 393, 394, 401, 402, 403, 404, 406, 407, 408, 409, 411, 414, 415, 416, 417, 418, 420, 421, 423, 424, 425, 428, 429, 430, 431, 433, 436, 437, 438, 440, 443, 447, 448, 449, 452, 453, 454, 456, 457, 459, 462, 463, 464, 465, 466, 470, 471, 472, 474, 475, 476, 477, 479, 482, 483, 484, 485, 486, 488, 489, 490, 491, 496, 497, 498, 499, 502, 504, 505, 508, 513, 514, 515, 516, 517, 518, 523, 524, 525, 526, 529, 534, 539, 540, 542, 545, 549, 552, 553, 555, 560, 561, 562, 563, 565, 566, 567, 569, 572, 573, 578, 579, 580, 581, 583, 586, 590, 593, 598, 603, 604, 605, 608, 609, 612, 613, 615, 616, 617, 620, 622, 625, 627, 628, 629, 631, 632, 633, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 649, 650, 651, 654, 655, 656, 661, 667, 668, 669, 670, 672, 673, 674, 675, 677, 678, 680, 683, 684, 685, 686, 687, 689, 690, 691, 693, 696, 697, 698, 699, 700, 702, 703, 704, 709, 710, 711, 712, 714, 717, 721, 724, 725, 727, 728, 729, 732, 733, 734, 736, 737, 738, 740, 741, 742, 745, 746, 747, 748, 750, 753, 754, 756, 759, 763, 764, 765, 768, 769, 770, 771, 772, 773, 774, 775, 776, 781, 782, 783, 784, 785, 786, 788, 789, 790, 793, 794, 795, 796, 797, 798, 800, 801, 802, 805, 806, 807, 814, 815, 816, 820, 821, 822, 826, 827, 828, 829, 831, 834, 835, 836, 837, 838, 840, 841, 843, 846, 847, 848, 849, 851, 854, 858, 859, 860, 863, 864, 865, 866, 867, 869, 870, 871, 876, 877, 878, 879, 881, 882, 883, 884, 885, 886, 887, 890, 891, 892, 893, 894, 895, 897, 902, 903, 904, 905, 907, 908, 909, 912, 913, 915, 916, 918, 923, 924, 925, 926, 929, 930, 931, 933, 934, 935, 937, 940, 944, 947, 948, 949, 950, 951, 952, 955, 956, 957, 959, 960, 961, 963, 964, 965, 966, 967, 968, 969, 972, 973, 974, 975, 976, 978, 979, 980, 981, 982, 983, 984, 985, 986, 987, 988, 993, 994, 1004, 1005, 1008, 1011, 1015, 1018, 1022, 1025, 1029, 1032, 1036, 1039};
/* BEGIN LINEINFO 
assign 1 366 343
typenameGet 0 366 343
assign 1 366 344
CATCHGet 0 366 344
assign 1 366 345
equals 1 366 345
assign 1 367 347
containedGet 0 367 347
assign 1 367 348
firstGet 0 367 348
assign 1 367 349
containedGet 0 367 349
assign 1 367 350
firstGet 0 367 350
assign 1 367 351
heldGet 0 367 351
assign 1 367 352
isTypedGet 0 367 352
assign 1 368 354
new 0 368 354
assign 1 368 355
new 1 368 355
throw 1 368 356
assign 1 371 359
typenameGet 0 371 359
assign 1 371 360
CLASSGet 0 371 360
assign 1 371 361
equals 1 371 361
assign 1 372 363
assign 1 373 364
heldGet 0 373 364
assign 1 373 365
namepathGet 0 373 365
assign 1 374 366
heldGet 0 374 366
assign 1 374 367
synGet 0 374 367
assign 1 376 369
typenameGet 0 376 369
assign 1 376 370
METHODGet 0 376 370
assign 1 376 371
equals 1 376 371
assign 1 377 373
new 0 377 373
assign 1 379 375
typenameGet 0 379 375
assign 1 379 376
CALLGet 0 379 376
assign 1 379 377
equals 1 379 377
assign 1 380 379
heldGet 0 380 379
cposSet 1 380 380
assign 1 381 381
increment 0 381 381
assign 1 382 382
containedGet 0 382 382
assign 1 382 383
iteratorGet 0 0 383
assign 1 382 386
hasNextGet 0 382 386
assign 1 382 388
nextGet 0 382 388
assign 1 383 389
typenameGet 0 383 389
assign 1 383 390
VARGet 0 383 390
assign 1 383 391
equals 1 383 391
assign 1 384 393
heldGet 0 384 393
addCall 1 384 394
assign 1 395 401
heldGet 0 395 401
assign 1 395 402
orgNameGet 0 395 402
assign 1 395 403
new 0 395 403
assign 1 395 404
equals 1 395 404
assign 1 396 406
containedGet 0 396 406
assign 1 396 407
firstGet 0 396 407
assign 1 398 408
heldGet 0 398 408
assign 1 398 409
isDeclaredGet 0 398 409
assign 1 399 411
heldGet 0 399 411
assign 1 401 414
ptyMapGet 0 401 414
assign 1 401 415
heldGet 0 401 415
assign 1 401 416
nameGet 0 401 416
assign 1 401 417
get 1 401 417
assign 1 401 418
memSynGet 0 401 418
assign 1 404 420
isTypedGet 0 404 420
assign 1 404 421
not 0 404 421
assign 1 405 423
heldGet 0 405 423
assign 1 405 424
new 0 405 424
checkTypesSet 1 405 425
assign 1 407 428
secondGet 0 407 428
assign 1 408 429
typenameGet 0 408 429
assign 1 408 430
TRUEGet 0 408 430
assign 1 408 431
equals 1 408 431
assign 1 0 433
assign 1 408 436
typenameGet 0 408 436
assign 1 408 437
FALSEGet 0 408 437
assign 1 408 438
equals 1 408 438
assign 1 0 440
assign 1 0 443
assign 1 410 447
heldGet 0 410 447
assign 1 410 448
new 0 410 448
checkTypesSet 1 410 449
assign 1 412 452
typenameGet 0 412 452
assign 1 412 453
VARGet 0 412 453
assign 1 412 454
equals 1 412 454
assign 1 413 456
heldGet 0 413 456
assign 1 413 457
isDeclaredGet 0 413 457
assign 1 414 459
heldGet 0 414 459
assign 1 417 462
ptyMapGet 0 417 462
assign 1 417 463
heldGet 0 417 463
assign 1 417 464
nameGet 0 417 464
assign 1 417 465
get 1 417 465
assign 1 417 466
memSynGet 0 417 466
assign 1 420 470
typenameGet 0 420 470
assign 1 420 471
CALLGet 0 420 471
assign 1 420 472
equals 1 420 472
assign 1 421 474
containedGet 0 421 474
assign 1 421 475
firstGet 0 421 475
assign 1 423 476
heldGet 0 423 476
assign 1 423 477
isDeclaredGet 0 423 477
assign 1 425 479
heldGet 0 425 479
assign 1 428 482
ptyMapGet 0 428 482
assign 1 428 483
heldGet 0 428 483
assign 1 428 484
nameGet 0 428 484
assign 1 428 485
get 1 428 485
assign 1 428 486
memSynGet 0 428 486
assign 1 431 488
assign 1 432 489
heldGet 0 432 489
assign 1 432 490
newNpGet 0 432 490
assign 1 432 491
def 1 432 496
assign 1 433 497
heldGet 0 433 497
assign 1 433 498
newNpGet 0 433 498
assign 1 433 499
getSynNp 1 433 499
assign 1 434 502
isTypedGet 0 434 502
assign 1 436 504
namepathGet 0 436 504
assign 1 436 505
getSynNp 1 436 505
assign 1 438 508
def 1 438 513
assign 1 439 514
mtdMapGet 0 439 514
assign 1 439 515
heldGet 0 439 515
assign 1 439 516
nameGet 0 439 516
assign 1 439 517
get 1 439 517
assign 1 440 518
undef 1 440 523
assign 1 441 524
new 0 441 524
assign 1 441 525
new 2 441 525
throw 1 441 526
assign 1 443 529
rsynGet 0 443 529
assign 1 447 534
def 1 447 539
assign 1 447 540
isTypedGet 0 447 540
assign 1 0 542
assign 1 0 545
assign 1 0 549
assign 1 449 552
new 0 449 552
assign 1 450 553
isSelfGet 0 450 553
assign 1 452 555
undef 1 452 560
assign 1 453 561
new 0 453 561
assign 1 453 562
new 1 453 562
throw 1 453 563
assign 1 458 565
originGet 0 458 565
assign 1 458 566
namepathGet 0 458 566
assign 1 458 567
notEquals 1 458 567
assign 1 460 569
new 0 460 569
assign 1 461 572
emitCommonGet 0 461 572
assign 1 461 573
def 1 461 578
assign 1 461 579
emitCommonGet 0 461 579
assign 1 461 580
covariantReturnsGet 0 461 580
assign 1 461 581
not 0 461 581
assign 1 0 583
assign 1 0 586
assign 1 0 590
assign 1 462 593
new 0 462 593
assign 1 464 598
def 1 464 603
assign 1 465 604
getEmitReturnType 2 465 604
assign 1 465 605
getSynNp 1 465 605
assign 1 467 608
namepathGet 0 467 608
assign 1 467 609
getSynNp 1 467 609
assign 1 471 612
namepathGet 0 471 612
assign 1 471 613
castsTo 1 471 613
assign 1 473 615
heldGet 0 473 615
assign 1 473 616
new 0 473 616
checkTypesSet 1 473 617
assign 1 475 620
isSelfGet 0 475 620
assign 1 476 622
namepathGet 0 476 622
assign 1 478 625
namepathGet 0 478 625
assign 1 480 627
namepathGet 0 480 627
assign 1 480 628
getSynNp 1 480 628
assign 1 481 629
castsTo 1 481 629
assign 1 483 631
heldGet 0 483 631
assign 1 483 632
new 0 483 632
checkTypesSet 1 483 633
assign 1 485 636
new 0 485 636
assign 1 485 637
namepathGet 0 485 637
assign 1 485 638
toString 0 485 638
assign 1 485 639
add 1 485 639
assign 1 485 640
new 0 485 640
assign 1 485 641
add 1 485 641
assign 1 485 642
toString 0 485 642
assign 1 485 643
add 1 485 643
assign 1 485 644
new 2 485 644
throw 1 485 645
assign 1 491 649
heldGet 0 491 649
assign 1 491 650
new 0 491 650
checkTypesSet 1 491 651
assign 1 494 654
heldGet 0 494 654
assign 1 494 655
namepathGet 0 494 655
assign 1 494 656
def 1 494 661
assign 1 499 667
heldGet 0 499 667
assign 1 499 668
orgNameGet 0 499 668
assign 1 499 669
new 0 499 669
assign 1 499 670
equals 1 499 670
assign 1 500 672
secondGet 0 500 672
assign 1 501 673
typenameGet 0 501 673
assign 1 501 674
VARGet 0 501 674
assign 1 501 675
equals 1 501 675
assign 1 502 677
heldGet 0 502 677
assign 1 502 678
isDeclaredGet 0 502 678
assign 1 503 680
heldGet 0 503 680
assign 1 505 683
ptyMapGet 0 505 683
assign 1 505 684
heldGet 0 505 684
assign 1 505 685
nameGet 0 505 685
assign 1 505 686
get 1 505 686
assign 1 505 687
memSynGet 0 505 687
assign 1 508 689
scopeGet 0 508 689
assign 1 509 690
heldGet 0 509 690
assign 1 509 691
isDeclaredGet 0 509 691
assign 1 510 693
heldGet 0 510 693
assign 1 512 696
ptyMapGet 0 512 696
assign 1 512 697
heldGet 0 512 697
assign 1 512 698
nameGet 0 512 698
assign 1 512 699
get 1 512 699
assign 1 512 700
memSynGet 0 512 700
assign 1 515 702
heldGet 0 515 702
assign 1 515 703
rtypeGet 0 515 703
assign 1 515 704
def 1 515 709
assign 1 515 710
heldGet 0 515 710
assign 1 515 711
rtypeGet 0 515 711
assign 1 515 712
isTypedGet 0 515 712
assign 1 0 714
assign 1 0 717
assign 1 0 721
assign 1 516 724
isTypedGet 0 516 724
assign 1 516 725
not 0 516 725
assign 1 518 727
heldGet 0 518 727
assign 1 518 728
new 0 518 728
checkTypesSet 1 518 729
assign 1 522 732
heldGet 0 522 732
assign 1 522 733
rtypeGet 0 522 733
assign 1 522 734
isSelfGet 0 522 734
assign 1 523 736
nameGet 0 523 736
assign 1 523 737
new 0 523 737
assign 1 523 738
equals 1 523 738
assign 1 525 740
heldGet 0 525 740
assign 1 525 741
new 0 525 741
checkTypesSet 1 525 742
assign 1 527 745
namepathGet 0 527 745
assign 1 527 746
getSynNp 1 527 746
assign 1 528 747
namepathGet 0 528 747
assign 1 528 748
castsTo 1 528 748
assign 1 0 750
assign 1 528 753
namepathGet 0 528 753
assign 1 528 754
castsTo 1 528 754
assign 1 0 756
assign 1 0 759
assign 1 530 763
heldGet 0 530 763
assign 1 530 764
new 0 530 764
checkTypesSet 1 530 765
assign 1 532 768
new 0 532 768
assign 1 532 769
namepathGet 0 532 769
assign 1 532 770
add 1 532 770
assign 1 532 771
new 0 532 771
assign 1 532 772
add 1 532 772
assign 1 532 773
namepathGet 0 532 773
assign 1 532 774
add 1 532 774
assign 1 532 775
new 2 532 775
throw 1 532 776
assign 1 536 781
namepathGet 0 536 781
assign 1 536 782
getSynNp 1 536 782
assign 1 537 783
heldGet 0 537 783
assign 1 537 784
rtypeGet 0 537 784
assign 1 537 785
namepathGet 0 537 785
assign 1 537 786
castsTo 1 537 786
assign 1 539 788
heldGet 0 539 788
assign 1 539 789
new 0 539 789
checkTypesSet 1 539 790
assign 1 541 793
heldGet 0 541 793
assign 1 541 794
rtypeGet 0 541 794
assign 1 541 795
namepathGet 0 541 795
assign 1 541 796
getSynNp 1 541 796
assign 1 542 797
namepathGet 0 542 797
assign 1 542 798
castsTo 1 542 798
assign 1 544 800
heldGet 0 544 800
assign 1 544 801
new 0 544 801
checkTypesSet 1 544 802
assign 1 546 805
new 0 546 805
assign 1 546 806
new 2 546 806
throw 1 546 807
assign 1 553 814
heldGet 0 553 814
assign 1 553 815
new 0 553 815
checkTypesSet 1 553 816
assign 1 556 820
heldGet 0 556 820
assign 1 556 821
new 0 556 821
checkTypesSet 1 556 822
assign 1 559 826
containedGet 0 559 826
assign 1 559 827
firstGet 0 559 827
assign 1 561 828
heldGet 0 561 828
assign 1 561 829
isDeclaredGet 0 561 829
assign 1 562 831
heldGet 0 562 831
assign 1 564 834
ptyMapGet 0 564 834
assign 1 564 835
heldGet 0 564 835
assign 1 564 836
nameGet 0 564 836
assign 1 564 837
get 1 564 837
assign 1 564 838
memSynGet 0 564 838
assign 1 567 840
isTypedGet 0 567 840
assign 1 567 841
not 0 567 841
assign 1 0 843
assign 1 567 846
heldGet 0 567 846
assign 1 567 847
orgNameGet 0 567 847
assign 1 567 848
new 0 567 848
assign 1 567 849
equals 1 567 849
assign 1 0 851
assign 1 0 854
assign 1 568 858
heldGet 0 568 858
assign 1 568 859
new 0 568 859
checkTypesSet 1 568 860
assign 1 570 863
heldGet 0 570 863
assign 1 570 864
new 0 570 864
checkTypesSet 1 570 865
assign 1 571 866
heldGet 0 571 866
assign 1 571 867
isConstructGet 0 571 867
assign 1 572 869
heldGet 0 572 869
assign 1 572 870
newNpGet 0 572 870
assign 1 572 871
undef 1 572 876
assign 1 573 877
new 0 573 877
assign 1 573 878
new 1 573 878
throw 1 573 879
assign 1 575 881
heldGet 0 575 881
assign 1 575 882
newNpGet 0 575 882
assign 1 575 883
getSynNp 1 575 883
assign 1 576 884
mtdMapGet 0 576 884
assign 1 576 885
heldGet 0 576 885
assign 1 576 886
nameGet 0 576 886
assign 1 576 887
get 1 576 887
assign 1 578 890
namepathGet 0 578 890
assign 1 578 891
getSynNp 1 578 891
assign 1 579 892
mtdMapGet 0 579 892
assign 1 579 893
heldGet 0 579 893
assign 1 579 894
nameGet 0 579 894
assign 1 579 895
get 1 579 895
assign 1 581 897
undef 1 581 902
assign 1 582 903
new 0 582 903
assign 1 582 904
new 2 582 904
throw 1 582 905
assign 1 584 907
argSynsGet 0 584 907
assign 1 585 908
nextPeerGet 0 585 908
assign 1 586 909
new 0 586 909
assign 1 586 912
lengthGet 0 586 912
assign 1 586 913
lesser 1 586 913
assign 1 587 915
get 1 587 915
assign 1 588 916
isTypedGet 0 588 916
assign 1 589 918
undef 1 589 923
assign 1 590 924
new 0 590 924
assign 1 590 925
new 2 590 925
throw 1 590 926
assign 1 591 929
typenameGet 0 591 929
assign 1 591 930
VARGet 0 591 930
assign 1 591 931
notEquals 1 591 931
assign 1 591 933
typenameGet 0 591 933
assign 1 591 934
NULLGet 0 591 934
assign 1 591 935
notEquals 1 591 935
assign 1 0 937
assign 1 0 940
assign 1 0 944
assign 1 592 947
new 0 592 947
assign 1 592 948
typenameGet 0 592 948
assign 1 592 949
toString 0 592 949
assign 1 592 950
add 1 592 950
assign 1 592 951
new 2 592 951
throw 1 592 952
assign 1 594 955
typenameGet 0 594 955
assign 1 594 956
VARGet 0 594 956
assign 1 594 957
equals 1 594 957
assign 1 595 959
heldGet 0 595 959
assign 1 596 960
isTypedGet 0 596 960
assign 1 596 961
not 0 596 961
assign 1 597 963
heldGet 0 597 963
assign 1 597 964
new 0 597 964
checkTypesSet 1 597 965
assign 1 598 966
heldGet 0 598 966
assign 1 598 967
argCastsGet 0 598 967
assign 1 598 968
namepathGet 0 598 968
put 2 598 969
assign 1 601 972
namepathGet 0 601 972
assign 1 601 973
getSynNp 1 601 973
assign 1 602 974
namepathGet 0 602 974
assign 1 602 975
castsTo 1 602 975
assign 1 602 976
not 0 602 976
assign 1 603 978
new 0 603 978
assign 1 603 979
namepathGet 0 603 979
assign 1 603 980
toString 0 603 980
assign 1 603 981
add 1 603 981
assign 1 603 982
new 0 603 982
assign 1 603 983
add 1 603 983
assign 1 603 984
namepathGet 0 603 984
assign 1 603 985
toString 0 603 985
assign 1 603 986
add 1 603 986
assign 1 603 987
new 2 603 987
throw 1 603 988
assign 1 612 993
nextPeerGet 0 612 993
assign 1 586 994
increment 0 586 994
assign 1 617 1004
nextDescendGet 0 617 1004
return 1 617 1005
return 1 0 1008
assign 1 0 1011
return 1 0 1015
assign 1 0 1018
return 1 0 1022
assign 1 0 1025
return 1 0 1029
assign 1 0 1032
return 1 0 1036
assign 1 0 1039
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 2028575047: return bem_emitterGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2128364298: return bem_cposGet_0();
case 2055025483: return bem_serializeContents_0();
case 2041762316: return bem_inClassGet_0();
case 1012494862: return bem_once_0();
case 997464046: return bem_inClassSynGet_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2117282045: return bem_cposSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_9_BuildVisitTypeCheck();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_9_BuildVisitTypeCheck.bevs_inst = (BEC_5_5_9_BuildVisitTypeCheck)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_9_BuildVisitTypeCheck.bevs_inst;
}
}
