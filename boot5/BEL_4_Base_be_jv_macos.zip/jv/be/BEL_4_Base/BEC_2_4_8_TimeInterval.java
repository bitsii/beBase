package be.BEL_4_Base;
/* IO:File: source/base/Time.be */
public class BEC_2_4_8_TimeInterval extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_TimeInterval() { }
private static byte[] becc_clname = {0x54,0x69,0x6D,0x65,0x3A,0x49,0x6E,0x74,0x65,0x72,0x76,0x61,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_11 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_16 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bevo_17 = (new BEC_2_4_3_MathInt(3600));
private static byte[] bels_0 = {0x20,0x6D,0x69,0x6E,0x75,0x74,0x65,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bevo_18 = (new BEC_2_4_6_TextString(bels_0, 10));
private static byte[] bels_1 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bevo_19 = (new BEC_2_4_6_TextString(bels_1, 13));
private static byte[] bels_2 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bevo_20 = (new BEC_2_4_6_TextString(bels_2, 13));
private static byte[] bels_3 = {0x3A};
private static BEC_2_4_6_TextString bevo_21 = (new BEC_2_4_6_TextString(bels_3, 1));
private static byte[] bels_4 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bevo_22 = (new BEC_2_4_6_TextString(bels_4, 13));
private static byte[] bels_5 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bevo_23 = (new BEC_2_4_6_TextString(bels_5, 13));
public static BEC_2_4_8_TimeInterval bevs_inst;
public BEC_2_4_3_MathInt bevp_secs;
public BEC_2_4_3_MathInt bevp_millis;
public BEC_2_4_8_TimeInterval bem_now_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt());
bevp_millis = (new BEC_2_4_3_MathInt());

            long ctm = System.currentTimeMillis();
            bevp_secs.bevi_int = (int) (ctm / 1000);
            bevp_millis.bevi_int = (int) (ctm % 1000);
            return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt(0));
bevp_millis = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_2(BEC_2_4_3_MathInt beva__secs, BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_secs = beva__secs;
bevp_millis = beva__millis;
this.bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_copy_0() throws Throwable {
BEC_2_4_8_TimeInterval bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevp_secs, bevp_millis);
return (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondInMinuteGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevp_secs.bem_modulus_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondInSecondGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_3_MathInt bem_minutesGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
bevt_0_tmpvar_phold = bevp_secs.bem_divide_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secondsSet_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = beva__secs;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondsGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisecondsSet_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = beva__millis;
this.bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_2;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_5;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_add_1(beva__secs);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_add_1(beva__millis);
this.bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_carryMillis_0() throws Throwable {
BEC_2_4_3_MathInt bevl_mmod = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_6;
bevl_mmod = bevp_millis.bem_modulus_1(bevt_2_tmpvar_phold);
if (bevl_mmod.bevi_int != bevp_millis.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 227 */ {
bevt_5_tmpvar_phold = bevo_7;
bevt_4_tmpvar_phold = bevp_millis.bem_divide_1(bevt_5_tmpvar_phold);
bevp_secs = bevp_secs.bem_add_1(bevt_4_tmpvar_phold);
bevp_millis = bevl_mmod;
} /* Line: 229 */
bevt_7_tmpvar_phold = bevo_8;
if (bevp_millis.bevi_int < bevt_7_tmpvar_phold.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 231 */ {
bevt_9_tmpvar_phold = bevo_9;
if (bevp_secs.bevi_int > bevt_9_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 231 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 231 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 231 */
 else  /* Line: 231 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 231 */ {
bevt_10_tmpvar_phold = bevo_10;
bevp_secs = bevp_secs.bem_subtract_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_11;
bevp_millis = bevt_11_tmpvar_phold.bem_add_1(bevp_millis);
} /* Line: 233 */
 else  /* Line: 231 */ {
bevt_13_tmpvar_phold = bevo_12;
if (bevp_millis.bevi_int > bevt_13_tmpvar_phold.bevi_int) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_15_tmpvar_phold = bevo_13;
if (bevp_secs.bevi_int < bevt_15_tmpvar_phold.bevi_int) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 234 */ {
bevt_16_tmpvar_phold = bevo_14;
bevp_secs = bevp_secs.bem_add_1(bevt_16_tmpvar_phold);
bevt_18_tmpvar_phold = bevo_15;
bevt_19_tmpvar_phold = bevo_16;
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_subtract_1(bevt_19_tmpvar_phold);
bevp_millis = bevt_17_tmpvar_phold.bem_add_1(bevp_millis);
} /* Line: 236 */
} /* Line: 231 */
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_subtract_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_subtract_1(beva__millis);
this.bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_add_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_add_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_add_1(bevt_1_tmpvar_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtract_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_subtract_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_subtract_1(bevt_1_tmpvar_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int > bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 266 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int > bevt_6_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 266 */
 else  /* Line: 266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 266 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 266 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 267 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 273 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int < bevt_6_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 273 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 273 */
 else  /* Line: 273 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 273 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 273 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 273 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 273 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 274 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int >= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 280 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 280 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 280 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int >= bevt_6_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 280 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 280 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 280 */
 else  /* Line: 280 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 280 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 280 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 280 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 280 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 281 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int <= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 287 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int <= bevt_6_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 287 */
 else  /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 287 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 287 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 288 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = this.bem_sameClass_1(beva_other);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevt_4_tmpvar_phold = beva_other.bemd_0(-739051419, BEL_4_Base.bevn_secsGet_0);
bevt_3_tmpvar_phold = bevp_secs.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 294 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 294 */
 else  /* Line: 294 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 294 */ {
bevt_6_tmpvar_phold = beva_other.bemd_0(1914769121, BEL_4_Base.bevn_millisGet_0);
bevt_5_tmpvar_phold = bevp_millis.bem_equals_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 294 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 294 */
 else  /* Line: 294 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 294 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 295 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevt_3_tmpvar_phold = this.bem_sameClass_1(beva_other);
if (bevt_3_tmpvar_phold.bevi_bool) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 301 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_5_tmpvar_phold = beva_other.bemd_0(-739051419, BEL_4_Base.bevn_secsGet_0);
bevt_4_tmpvar_phold = bevp_secs.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 301 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 301 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_7_tmpvar_phold = beva_other.bemd_0(1914769121, BEL_4_Base.bevn_millisGet_0);
bevt_6_tmpvar_phold = bevp_millis.bem_notEquals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 301 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 301 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 302 */
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_offByHour_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
if (beva_other == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 309 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 309 */
bevt_3_tmpvar_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int == bevt_3_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 310 */ {
bevt_7_tmpvar_phold = beva_other.bem_secsGet_0();
bevt_6_tmpvar_phold = bevp_secs.bem_subtract_1(bevt_7_tmpvar_phold);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_abs_0();
bevt_8_tmpvar_phold = bevo_17;
if (bevt_5_tmpvar_phold.bevi_int == bevt_8_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 311 */ {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_9_tmpvar_phold;
} /* Line: 312 */
} /* Line: 311 */
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_10_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringMinutes_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_6_tmpvar_phold = this.bem_minutesGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_toString_0();
bevt_7_tmpvar_phold = bevo_18;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = this.bem_secondInMinuteGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_19;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevp_millis);
bevt_10_tmpvar_phold = bevo_20;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toShortString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_secs.bem_toString_0();
bevt_3_tmpvar_phold = bevo_21;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_millis.bem_toString_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_secs.bem_toString_0();
bevt_4_tmpvar_phold = bevo_22;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevp_millis);
bevt_5_tmpvar_phold = bevo_23;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_6_6_SystemObject bem_millisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {116, 117, 154, 155, 161, 162, 163, 167, 167, 171, 171, 171, 175, 179, 179, 179, 183, 187, 191, 195, 196, 200, 200, 200, 204, 204, 204, 208, 208, 208, 212, 212, 212, 217, 221, 222, 226, 226, 227, 227, 228, 228, 228, 229, 231, 231, 231, 231, 231, 231, 0, 0, 0, 232, 232, 233, 233, 234, 234, 234, 234, 234, 234, 0, 0, 0, 235, 235, 236, 236, 236, 236, 241, 245, 246, 250, 250, 251, 251, 252, 253, 254, 258, 258, 259, 259, 260, 261, 262, 266, 266, 266, 0, 266, 266, 266, 266, 266, 266, 0, 0, 0, 0, 0, 267, 267, 269, 269, 273, 273, 273, 0, 273, 273, 273, 273, 273, 273, 0, 0, 0, 0, 0, 274, 274, 276, 276, 280, 280, 280, 0, 280, 280, 280, 280, 280, 280, 0, 0, 0, 0, 0, 281, 281, 283, 283, 287, 287, 287, 0, 287, 287, 287, 287, 287, 287, 0, 0, 0, 0, 0, 288, 288, 290, 290, 294, 294, 294, 0, 0, 0, 294, 294, 0, 0, 0, 295, 295, 297, 297, 301, 301, 301, 0, 301, 301, 0, 0, 0, 301, 301, 0, 0, 302, 302, 304, 304, 309, 309, 309, 309, 310, 310, 310, 311, 311, 311, 311, 311, 311, 312, 312, 315, 315, 319, 319, 319, 319, 319, 319, 319, 319, 319, 319, 319, 319, 323, 323, 323, 323, 323, 323, 327, 327, 327, 327, 327, 327, 327, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {41, 42, 50, 51, 55, 56, 57, 62, 63, 68, 69, 70, 73, 78, 79, 80, 83, 86, 90, 93, 94, 100, 101, 102, 108, 109, 110, 116, 117, 118, 124, 125, 126, 130, 134, 135, 160, 161, 162, 167, 168, 169, 170, 171, 173, 174, 179, 180, 181, 186, 187, 190, 194, 197, 198, 199, 200, 203, 204, 209, 210, 211, 216, 217, 220, 224, 227, 228, 229, 230, 231, 232, 238, 242, 243, 252, 253, 254, 255, 256, 257, 258, 266, 267, 268, 269, 270, 271, 272, 284, 285, 290, 291, 294, 295, 300, 301, 302, 307, 308, 311, 315, 318, 321, 325, 326, 328, 329, 341, 342, 347, 348, 351, 352, 357, 358, 359, 364, 365, 368, 372, 375, 378, 382, 383, 385, 386, 398, 399, 404, 405, 408, 409, 414, 415, 416, 421, 422, 425, 429, 432, 435, 439, 440, 442, 443, 455, 456, 461, 462, 465, 466, 471, 472, 473, 478, 479, 482, 486, 489, 492, 496, 497, 499, 500, 512, 514, 515, 517, 520, 524, 527, 528, 530, 533, 537, 540, 541, 543, 544, 557, 558, 563, 564, 567, 568, 570, 573, 577, 580, 581, 583, 586, 590, 591, 593, 594, 608, 613, 614, 615, 617, 618, 623, 624, 625, 626, 627, 628, 633, 634, 635, 638, 639, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 672, 673, 674, 675, 676, 677, 686, 687, 688, 689, 690, 691, 692, 695, 698, 702, 705};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 116 41
new 0 116 41
assign 1 117 42
new 0 117 42
assign 1 154 50
new 0 154 50
assign 1 155 51
new 0 155 51
assign 1 161 55
assign 1 162 56
carryMillis 0 163 57
assign 1 167 62
new 2 167 62
return 1 167 63
assign 1 171 68
new 0 171 68
assign 1 171 69
modulus 1 171 69
return 1 171 70
return 1 175 73
assign 1 179 78
new 0 179 78
assign 1 179 79
divide 1 179 79
return 1 179 80
return 1 183 83
assign 1 187 86
return 1 191 90
assign 1 195 93
carryMillis 0 196 94
assign 1 200 100
new 0 200 100
assign 1 200 101
multiply 1 200 101
assign 1 200 102
add 1 200 102
assign 1 204 108
new 0 204 108
assign 1 204 109
multiply 1 204 109
assign 1 204 110
add 1 204 110
assign 1 208 116
new 0 208 116
assign 1 208 117
multiply 1 208 117
assign 1 208 118
subtract 1 208 118
assign 1 212 124
new 0 212 124
assign 1 212 125
multiply 1 212 125
assign 1 212 126
subtract 1 212 126
assign 1 217 130
add 1 217 130
assign 1 221 134
add 1 221 134
carryMillis 0 222 135
assign 1 226 160
new 0 226 160
assign 1 226 161
modulus 1 226 161
assign 1 227 162
notEquals 1 227 167
assign 1 228 168
new 0 228 168
assign 1 228 169
divide 1 228 169
assign 1 228 170
add 1 228 170
assign 1 229 171
assign 1 231 173
new 0 231 173
assign 1 231 174
lesser 1 231 179
assign 1 231 180
new 0 231 180
assign 1 231 181
greater 1 231 186
assign 1 0 187
assign 1 0 190
assign 1 0 194
assign 1 232 197
new 0 232 197
assign 1 232 198
subtract 1 232 198
assign 1 233 199
new 0 233 199
assign 1 233 200
add 1 233 200
assign 1 234 203
new 0 234 203
assign 1 234 204
greater 1 234 209
assign 1 234 210
new 0 234 210
assign 1 234 211
lesser 1 234 216
assign 1 0 217
assign 1 0 220
assign 1 0 224
assign 1 235 227
new 0 235 227
assign 1 235 228
add 1 235 228
assign 1 236 229
new 0 236 229
assign 1 236 230
new 0 236 230
assign 1 236 231
subtract 1 236 231
assign 1 236 232
add 1 236 232
assign 1 241 238
subtract 1 241 238
assign 1 245 242
subtract 1 245 242
carryMillis 0 246 243
assign 1 250 252
secsGet 0 250 252
assign 1 250 253
add 1 250 253
assign 1 251 254
millisGet 0 251 254
assign 1 251 255
add 1 251 255
assign 1 252 256
new 2 252 256
carryMillis 0 253 257
return 1 254 258
assign 1 258 266
secsGet 0 258 266
assign 1 258 267
subtract 1 258 267
assign 1 259 268
millisGet 0 259 268
assign 1 259 269
subtract 1 259 269
assign 1 260 270
new 2 260 270
carryMillis 0 261 271
return 1 262 272
assign 1 266 284
secsGet 0 266 284
assign 1 266 285
greater 1 266 290
assign 1 0 291
assign 1 266 294
secsGet 0 266 294
assign 1 266 295
equals 1 266 300
assign 1 266 301
millisGet 0 266 301
assign 1 266 302
greater 1 266 307
assign 1 0 308
assign 1 0 311
assign 1 0 315
assign 1 0 318
assign 1 0 321
assign 1 267 325
new 0 267 325
return 1 267 326
assign 1 269 328
new 0 269 328
return 1 269 329
assign 1 273 341
secsGet 0 273 341
assign 1 273 342
lesser 1 273 347
assign 1 0 348
assign 1 273 351
secsGet 0 273 351
assign 1 273 352
equals 1 273 357
assign 1 273 358
millisGet 0 273 358
assign 1 273 359
lesser 1 273 364
assign 1 0 365
assign 1 0 368
assign 1 0 372
assign 1 0 375
assign 1 0 378
assign 1 274 382
new 0 274 382
return 1 274 383
assign 1 276 385
new 0 276 385
return 1 276 386
assign 1 280 398
secsGet 0 280 398
assign 1 280 399
greaterEquals 1 280 404
assign 1 0 405
assign 1 280 408
secsGet 0 280 408
assign 1 280 409
equals 1 280 414
assign 1 280 415
millisGet 0 280 415
assign 1 280 416
greaterEquals 1 280 421
assign 1 0 422
assign 1 0 425
assign 1 0 429
assign 1 0 432
assign 1 0 435
assign 1 281 439
new 0 281 439
return 1 281 440
assign 1 283 442
new 0 283 442
return 1 283 443
assign 1 287 455
secsGet 0 287 455
assign 1 287 456
lesserEquals 1 287 461
assign 1 0 462
assign 1 287 465
secsGet 0 287 465
assign 1 287 466
equals 1 287 471
assign 1 287 472
millisGet 0 287 472
assign 1 287 473
lesserEquals 1 287 478
assign 1 0 479
assign 1 0 482
assign 1 0 486
assign 1 0 489
assign 1 0 492
assign 1 288 496
new 0 288 496
return 1 288 497
assign 1 290 499
new 0 290 499
return 1 290 500
assign 1 294 512
sameClass 1 294 512
assign 1 294 514
secsGet 0 294 514
assign 1 294 515
equals 1 294 515
assign 1 0 517
assign 1 0 520
assign 1 0 524
assign 1 294 527
millisGet 0 294 527
assign 1 294 528
equals 1 294 528
assign 1 0 530
assign 1 0 533
assign 1 0 537
assign 1 295 540
new 0 295 540
return 1 295 541
assign 1 297 543
new 0 297 543
return 1 297 544
assign 1 301 557
sameClass 1 301 557
assign 1 301 558
not 0 301 563
assign 1 0 564
assign 1 301 567
secsGet 0 301 567
assign 1 301 568
notEquals 1 301 568
assign 1 0 570
assign 1 0 573
assign 1 0 577
assign 1 301 580
millisGet 0 301 580
assign 1 301 581
notEquals 1 301 581
assign 1 0 583
assign 1 0 586
assign 1 302 590
new 0 302 590
return 1 302 591
assign 1 304 593
new 0 304 593
return 1 304 594
assign 1 309 608
undef 1 309 613
assign 1 309 614
new 0 309 614
return 1 309 615
assign 1 310 617
millisGet 0 310 617
assign 1 310 618
equals 1 310 623
assign 1 311 624
secsGet 0 311 624
assign 1 311 625
subtract 1 311 625
assign 1 311 626
abs 0 311 626
assign 1 311 627
new 0 311 627
assign 1 311 628
equals 1 311 633
assign 1 312 634
new 0 312 634
return 1 312 635
assign 1 315 638
new 0 315 638
return 1 315 639
assign 1 319 653
minutesGet 0 319 653
assign 1 319 654
toString 0 319 654
assign 1 319 655
new 0 319 655
assign 1 319 656
add 1 319 656
assign 1 319 657
secondInMinuteGet 0 319 657
assign 1 319 658
add 1 319 658
assign 1 319 659
new 0 319 659
assign 1 319 660
add 1 319 660
assign 1 319 661
add 1 319 661
assign 1 319 662
new 0 319 662
assign 1 319 663
add 1 319 663
return 1 319 664
assign 1 323 672
toString 0 323 672
assign 1 323 673
new 0 323 673
assign 1 323 674
add 1 323 674
assign 1 323 675
toString 0 323 675
assign 1 323 676
add 1 323 676
return 1 323 677
assign 1 327 686
toString 0 327 686
assign 1 327 687
new 0 327 687
assign 1 327 688
add 1 327 688
assign 1 327 689
add 1 327 689
assign 1 327 690
new 0 327 690
assign 1 327 691
add 1 327 691
return 1 327 692
return 1 0 695
assign 1 0 698
return 1 0 702
assign 1 0 705
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case 284498275: return bem_toShortString_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -316166507: return bem_millisecondsGet_0();
case -314718434: return bem_print_0();
case 888746948: return bem_toStringMinutes_0();
case 478622533: return bem_sourceFileNameGet_0();
case 169908808: return bem_secondsGet_0();
case 1914769121: return bem_millisGet_0();
case 1490855437: return bem_millisecondInSecondGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -324838054: return bem_secondInMinuteGet_0();
case 24587954: return bem_carryMillis_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -864467992: return bem_minutesGet_0();
case 1820417453: return bem_create_0();
case -729571811: return bem_serializeToString_0();
case 105011463: return bem_now_0();
case -1354714650: return bem_copy_0();
case -739051419: return bem_secsGet_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -979186229: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 81310150: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 92659731: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1301342541: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case 180991061: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -445912502: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case -955482416: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -305084254: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1925851374: return bem_millisSet_1(bevd_0);
case 1220624855: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1286233312: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1103128156: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -727969166: return bem_secsSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -309281416: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1689132987: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 1992862333: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case -1081152067: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_TimeInterval();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_TimeInterval.bevs_inst = (BEC_2_4_8_TimeInterval)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_TimeInterval.bevs_inst;
}
}
