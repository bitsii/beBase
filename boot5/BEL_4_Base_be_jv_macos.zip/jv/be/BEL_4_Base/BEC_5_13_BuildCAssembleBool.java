package be.BEL_4_Base;
/* File: source/build/CCallAssembler.be */
public class BEC_5_13_BuildCAssembleBool extends BEC_5_14_BuildCCallAssembler {
public BEC_5_13_BuildCAssembleBool() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x41,0x73,0x73,0x65,0x6D,0x62,0x6C,0x65,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x61,0x6C,0x6C,0x41,0x73,0x73,0x65,0x6D,0x62,0x6C,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x6F,0x74,0x5F,0x30};
private static byte[] bels_1 = {0x74,0x72,0x75,0x65};
private static byte[] bels_2 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x3B};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_2, 20));
private static byte[] bels_3 = {0x42,0x45,0x4B,0x46,0x5F,0x35,0x5F,0x35,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x73,0x5F,0x66,0x6F,0x72,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x31,0x28,0x30,0x2C,0x20,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2C,0x20,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x73,0x5F,0x73,0x69,0x6E,0x67,0x6C,0x65,0x74,0x6F,0x6E,0x2C,0x20};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_3, 72));
private static byte[] bels_4 = {0x20,0x29,0x3B};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_4, 3));
private static byte[] bels_5 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x3B};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_5, 21));
private static byte[] bels_6 = {0x69,0x66,0x20,0x28,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x29,0x20};
private static byte[] bels_7 = {0x20,0x3D,0x3D,0x20,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x29,0x20,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x29,0x20,0x7B,0x20};
private static byte[] bels_8 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x3B,0x20,0x7D};
private static byte[] bels_9 = {0x65,0x6C,0x73,0x65,0x20,0x7B,0x20};
private static byte[] bels_10 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x3B,0x20,0x7D};
public static BEC_5_13_BuildCAssembleBool bevs_inst;
public BEC_5_13_BuildCAssembleBool bem_new_1(BEC_6_6_SystemObject beva_build) throws Throwable {
this.bem_loadBuild_1(beva_build);
return this;
} /*method end*/
public BEC_4_6_TextString bem_processCall_1(BEC_5_10_BuildCallCursor beva_ca) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_heldGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 535 */ {
bevt_3_tmpvar_phold = this.bem_processConstruct_1(beva_ca);
return bevt_3_tmpvar_phold;
} /* Line: 536 */
bevt_7_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(5, bels_0));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 538 */ {
bevt_9_tmpvar_phold = this.bem_processNot_1(beva_ca);
return bevt_9_tmpvar_phold;
} /* Line: 539 */
bevt_10_tmpvar_phold = this.bem_standardCall_1(beva_ca);
return bevt_10_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_processConstruct_1(BEC_5_10_BuildCallCursor beva_ca) throws Throwable {
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_33_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_34_tmpvar_phold = null;
BEC_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_ca.bem_asnRGet_0();
if (bevt_2_tmpvar_phold == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 545 */ {
bevt_5_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_heldGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 546 */ {
bevt_9_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_heldGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_10_tmpvar_phold = (new BEC_4_6_TextString(4, bels_1));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_10_tmpvar_phold);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 546 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 546 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 546 */
 else  /* Line: 546 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 546 */ {
bevt_14_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevt_15_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = bevo_0;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_16_tmpvar_phold);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevp_nl);
beva_ca.bem_tcallSet_1(bevt_11_tmpvar_phold);
} /* Line: 547 */
 else  /* Line: 546 */ {
bevt_20_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_21_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 548 */ {
bevt_27_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevt_28_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = bevo_1;
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_31_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_34_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_containedGet_0();
bevt_35_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_get_1(bevt_35_tmpvar_phold);
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_getBeavArg_1(bevt_32_tmpvar_phold);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_add_1(bevt_30_tmpvar_phold);
bevt_36_tmpvar_phold = bevo_2;
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_36_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevp_nl);
beva_ca.bem_tcallSet_1(bevt_22_tmpvar_phold);
} /* Line: 549 */
 else  /* Line: 550 */ {
bevt_40_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevt_41_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_add_1(bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = bevo_3;
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_add_1(bevt_42_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_add_1(bevp_nl);
beva_ca.bem_tcallSet_1(bevt_37_tmpvar_phold);
} /* Line: 551 */
} /* Line: 546 */
} /* Line: 546 */
bevl_callRet = (new BEC_4_6_TextString()).bem_new_0();
bevt_43_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_43_tmpvar_phold);
bevt_44_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevl_callRet.bem_addValue_1(bevt_44_tmpvar_phold);
bevt_45_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_45_tmpvar_phold);
bevt_46_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_46_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public BEC_4_6_TextString bem_processNot_1(BEC_5_10_BuildCallCursor beva_ca) throws Throwable {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_10_tmpvar_phold = (new BEC_4_6_TextString(13, bels_6));
bevt_9_tmpvar_phold = bevl_callRet.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = (new BEC_4_6_TextString(36, bels_7));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(23, bels_8));
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_5_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(7, bels_9));
bevt_17_tmpvar_phold = bevl_callRet.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(22, bels_10));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_21_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_22_tmpvar_phold);
return bevl_callRet;
} /*method end*/
//int[] bevs_nlcs = {532, 535, 535, 535, 536, 536, 538, 538, 538, 538, 538, 539, 539, 541, 541, 545, 545, 545, 546, 546, 546, 546, 546, 546, 546, 546, 0, 0, 0, 547, 547, 547, 547, 547, 547, 547, 548, 548, 548, 548, 548, 549, 549, 549, 549, 549, 549, 549, 549, 549, 549, 549, 549, 549, 549, 549, 549, 551, 551, 551, 551, 551, 551, 551, 554, 555, 555, 556, 556, 557, 557, 558, 558, 559, 564, 564, 566, 566, 566, 567, 568, 568, 569, 569, 570, 570, 570, 570, 570, 570, 570, 570, 570, 570, 570, 571, 571, 571, 571, 571, 571, 571, 572, 572, 573, 573, 574};
//int[] bevs_nlecs = {24, 39, 40, 41, 43, 44, 46, 47, 48, 49, 50, 52, 53, 55, 56, 107, 108, 113, 114, 115, 116, 118, 119, 120, 121, 122, 124, 127, 131, 134, 135, 136, 137, 138, 139, 140, 143, 144, 145, 146, 147, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 167, 168, 169, 170, 171, 172, 173, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246};
/* BEGIN LINEINFO 
loadBuild 1 532 24
assign 1 535 39
nodeGet 0 535 39
assign 1 535 40
heldGet 0 535 40
assign 1 535 41
isConstructGet 0 535 41
assign 1 536 43
processConstruct 1 536 43
return 1 536 44
assign 1 538 46
nodeGet 0 538 46
assign 1 538 47
heldGet 0 538 47
assign 1 538 48
nameGet 0 538 48
assign 1 538 49
new 0 538 49
assign 1 538 50
equals 1 538 50
assign 1 539 52
processNot 1 539 52
return 1 539 53
assign 1 541 55
standardCall 1 541 55
return 1 541 56
assign 1 545 107
asnRGet 0 545 107
assign 1 545 108
def 1 545 113
assign 1 546 114
nodeGet 0 546 114
assign 1 546 115
heldGet 0 546 115
assign 1 546 116
isLiteralGet 0 546 116
assign 1 546 118
nodeGet 0 546 118
assign 1 546 119
heldGet 0 546 119
assign 1 546 120
literalValueGet 0 546 120
assign 1 546 121
new 0 546 121
assign 1 546 122
equals 1 546 122
assign 1 0 124
assign 1 0 127
assign 1 0 131
assign 1 547 134
tcallGet 0 547 134
assign 1 547 135
assignToVVGet 0 547 135
assign 1 547 136
add 1 547 136
assign 1 547 137
new 0 547 137
assign 1 547 138
add 1 547 138
assign 1 547 139
add 1 547 139
tcallSet 1 547 140
assign 1 548 143
nodeGet 0 548 143
assign 1 548 144
heldGet 0 548 144
assign 1 548 145
numargsGet 0 548 145
assign 1 548 146
new 0 548 146
assign 1 548 147
equals 1 548 147
assign 1 549 149
tcallGet 0 549 149
assign 1 549 150
assignToVVGet 0 549 150
assign 1 549 151
add 1 549 151
assign 1 549 152
new 0 549 152
assign 1 549 153
add 1 549 153
assign 1 549 154
emvisitGet 0 549 154
assign 1 549 155
nodeGet 0 549 155
assign 1 549 156
containedGet 0 549 156
assign 1 549 157
new 0 549 157
assign 1 549 158
get 1 549 158
assign 1 549 159
getBeavArg 1 549 159
assign 1 549 160
add 1 549 160
assign 1 549 161
new 0 549 161
assign 1 549 162
add 1 549 162
assign 1 549 163
add 1 549 163
tcallSet 1 549 164
assign 1 551 167
tcallGet 0 551 167
assign 1 551 168
assignToVVGet 0 551 168
assign 1 551 169
add 1 551 169
assign 1 551 170
new 0 551 170
assign 1 551 171
add 1 551 171
assign 1 551 172
add 1 551 172
tcallSet 1 551 173
assign 1 554 177
new 0 554 177
assign 1 555 178
preOnceEvalGet 0 555 178
addValue 1 555 179
assign 1 556 180
tcallGet 0 556 180
addValue 1 556 181
assign 1 557 182
assignToCheckGet 0 557 182
addValue 1 557 183
assign 1 558 184
postOnceEvalGet 0 558 184
addValue 1 558 185
return 1 559 186
assign 1 564 214
isValidGet 0 564 214
assertTrue 1 564 215
assign 1 566 216
emvisitGet 0 566 216
assign 1 566 217
buildGet 0 566 217
assign 1 566 218
nlGet 0 566 218
assign 1 567 219
new 0 567 219
assign 1 568 220
preOnceEvalGet 0 568 220
addValue 1 568 221
assign 1 569 222
callArgsGet 0 569 222
addValue 1 569 223
assign 1 570 224
new 0 570 224
assign 1 570 225
addValue 1 570 225
assign 1 570 226
targsGet 0 570 226
assign 1 570 227
addValue 1 570 227
assign 1 570 228
new 0 570 228
assign 1 570 229
addValue 1 570 229
assign 1 570 230
assignToVVGet 0 570 230
assign 1 570 231
addValue 1 570 231
assign 1 570 232
new 0 570 232
assign 1 570 233
addValue 1 570 233
addValue 1 570 234
assign 1 571 235
new 0 571 235
assign 1 571 236
addValue 1 571 236
assign 1 571 237
assignToVVGet 0 571 237
assign 1 571 238
addValue 1 571 238
assign 1 571 239
new 0 571 239
assign 1 571 240
addValue 1 571 240
addValue 1 571 241
assign 1 572 242
assignToCheckGet 0 572 242
addValue 1 572 243
assign 1 573 244
postOnceEvalGet 0 573 244
addValue 1 573 245
return 1 574 246
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 2001798761: return bem_nlGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1178476504: return bem_fromTypesGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 846242271: return bem_processCall_1((BEC_5_10_BuildCallCursor) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 281832742: return bem_loadBuild_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 1189558757: return bem_fromTypesSet_1(bevd_0);
case 224779883: return bem_processOptimizedGetter_1((BEC_5_10_BuildCallCursor) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1292480624: return bem_processAssign_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1833349037: return bem_standardCall_1((BEC_5_10_BuildCallCursor) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 880235482: return bem_processConstruct_1((BEC_5_10_BuildCallCursor) bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1977543830: return bem_processNot_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 785892343: return bem_processOptimizedSetter_1((BEC_5_10_BuildCallCursor) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 19297983: return bem_accessorCheckBlock_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 429177731: return bem_standardBlock_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 436992814: return bem_standardBlockAssign_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_13_BuildCAssembleBool();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_13_BuildCAssembleBool.bevs_inst = (BEC_5_13_BuildCAssembleBool)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_13_BuildCAssembleBool.bevs_inst;
}
}
