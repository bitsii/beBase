package be.BEL_4_Base;
/* File: source/build/Pass1.be */
public class BEC_5_5_5_BuildVisitPass1 extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass1() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2E};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_0, 1));
private static byte[] bels_1 = {0x2E};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_1, 1));
public static BEC_5_5_5_BuildVisitPass1 bevs_inst;
public BEC_5_4_LogicBool bevp_print;
public BEC_9_3_ContainerSet bevp_printAstElements;
public BEC_5_4_LogicBool bevp_hasAstMethods;
public BEC_6_6_SystemObject bevp_f;
public BEC_4_6_TextString bevp_inClass;
public BEC_4_6_TextString bevp_inClassMethod;
public BEC_5_5_5_BuildVisitPass1 bem_new_0() throws Throwable {
bevp_print = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_5_5_5_BuildVisitPass1 bem_new_3(BEC_5_4_LogicBool beva__print, BEC_9_3_ContainerSet beva__printAstElements, BEC_4_6_TextString beva__fname) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_IOFile bevt_3_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_4_tmpvar_phold = null;
bevp_print = beva__print;
bevp_printAstElements = beva__printAstElements;
bevt_0_tmpvar_phold = bevp_printAstElements.bem_isEmptyGet_0();
bevp_hasAstMethods = bevt_0_tmpvar_phold.bem_not_0();
if (beva__fname == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 34 */ {
bevt_4_tmpvar_phold = (new BEC_2_4_4_IOFilePath()).bem_new_1(beva__fname);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_fileGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_writerGet_0();
bevp_f = bevt_2_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
} /* Line: 35 */
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_4_6_TextString bevl_inLine = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_32_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_33_tmpvar_phold = null;
bevt_7_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_8_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_equals_1(bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 44 */ {
bevt_10_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_inClass = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_inClassMethod = null;
bevl_inLine = null;
} /* Line: 47 */
bevt_12_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_13_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_13_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 49 */ {
if (bevp_inClass == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 49 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 49 */
 else  /* Line: 49 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 49 */ {
bevt_16_tmpvar_phold = bevo_0;
bevt_15_tmpvar_phold = bevp_inClass.bem_add_1(bevt_16_tmpvar_phold);
bevt_18_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevp_inClassMethod = bevt_15_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
} /* Line: 50 */
if (bevp_inClassMethod == null) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_21_tmpvar_phold = beva_node.bem_nlcGet_0();
if (bevt_21_tmpvar_phold == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_23_tmpvar_phold = bevo_1;
bevt_22_tmpvar_phold = bevp_inClassMethod.bem_add_1(bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = beva_node.bem_nlcGet_0();
bevl_inLine = bevt_22_tmpvar_phold.bem_add_1(bevt_24_tmpvar_phold);
} /* Line: 54 */
if (bevp_print.bevi_bool) /* Line: 56 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
if (bevp_hasAstMethods.bevi_bool) /* Line: 56 */ {
if (bevp_inClassMethod == null) {
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 56 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 56 */
 else  /* Line: 56 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 56 */ {
bevt_26_tmpvar_phold = bevp_printAstElements.bem_has_1(bevp_inClassMethod);
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 56 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 56 */
 else  /* Line: 56 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 56 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 56 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 56 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
if (bevp_hasAstMethods.bevi_bool) /* Line: 56 */ {
if (bevl_inLine == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 56 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 56 */
 else  /* Line: 56 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 56 */ {
bevt_28_tmpvar_phold = bevp_printAstElements.bem_has_1(bevl_inLine);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 56 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 56 */
 else  /* Line: 56 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 56 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 56 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 56 */ {
if (bevp_f == null) {
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_30_tmpvar_phold = beva_node.bem_toString_0();
bevp_f.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_30_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_newlineGet_0();
bevp_f.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_31_tmpvar_phold);
} /* Line: 59 */
 else  /* Line: 60 */ {
beva_node.bem_print_0();
} /* Line: 61 */
} /* Line: 57 */
bevt_33_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_33_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_printGet_0() throws Throwable {
return bevp_print;
} /*method end*/
public BEC_6_6_SystemObject bem_printSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_print = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_6_6_SystemObject bem_printAstElementsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAstElements = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_hasAstMethodsGet_0() throws Throwable {
return bevp_hasAstMethods;
} /*method end*/
public BEC_6_6_SystemObject bem_hasAstMethodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_hasAstMethods = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fGet_0() throws Throwable {
return bevp_f;
} /*method end*/
public BEC_6_6_SystemObject bem_fSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_f = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClass = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_inClassMethodGet_0() throws Throwable {
return bevp_inClassMethod;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassMethodSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassMethod = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {23, 31, 32, 33, 33, 34, 34, 35, 35, 35, 35, 44, 44, 44, 45, 45, 45, 46, 47, 49, 49, 49, 49, 49, 0, 0, 0, 50, 50, 50, 50, 50, 53, 53, 53, 53, 53, 0, 0, 0, 54, 54, 54, 54, 0, 56, 56, 0, 0, 0, 56, 0, 0, 0, 0, 0, 0, 56, 56, 0, 0, 0, 56, 0, 0, 0, 0, 0, 57, 57, 58, 58, 59, 59, 59, 61, 64, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {19, 28, 29, 30, 31, 32, 37, 38, 39, 40, 41, 81, 82, 83, 85, 86, 87, 88, 89, 91, 92, 93, 95, 100, 101, 104, 108, 111, 112, 113, 114, 115, 117, 122, 123, 124, 129, 130, 133, 137, 140, 141, 142, 143, 146, 150, 155, 156, 159, 163, 166, 168, 171, 175, 178, 181, 185, 189, 194, 195, 198, 202, 205, 207, 210, 214, 217, 220, 224, 229, 230, 231, 232, 233, 234, 237, 240, 241, 244, 247, 251, 254, 258, 261, 265, 268, 272, 275, 279, 282};
/* BEGIN LINEINFO 
assign 1 23 19
new 0 23 19
assign 1 31 28
assign 1 32 29
assign 1 33 30
isEmptyGet 0 33 30
assign 1 33 31
not 0 33 31
assign 1 34 32
def 1 34 37
assign 1 35 38
new 1 35 38
assign 1 35 39
fileGet 0 35 39
assign 1 35 40
writerGet 0 35 40
assign 1 35 41
open 0 35 41
assign 1 44 81
typenameGet 0 44 81
assign 1 44 82
CLASSGet 0 44 82
assign 1 44 83
equals 1 44 83
assign 1 45 85
heldGet 0 45 85
assign 1 45 86
namepathGet 0 45 86
assign 1 45 87
toString 0 45 87
assign 1 46 88
assign 1 47 89
assign 1 49 91
typenameGet 0 49 91
assign 1 49 92
METHODGet 0 49 92
assign 1 49 93
equals 1 49 93
assign 1 49 95
def 1 49 100
assign 1 0 101
assign 1 0 104
assign 1 0 108
assign 1 50 111
new 0 50 111
assign 1 50 112
add 1 50 112
assign 1 50 113
heldGet 0 50 113
assign 1 50 114
orgNameGet 0 50 114
assign 1 50 115
add 1 50 115
assign 1 53 117
def 1 53 122
assign 1 53 123
nlcGet 0 53 123
assign 1 53 124
def 1 53 129
assign 1 0 130
assign 1 0 133
assign 1 0 137
assign 1 54 140
new 0 54 140
assign 1 54 141
add 1 54 141
assign 1 54 142
nlcGet 0 54 142
assign 1 54 143
add 1 54 143
assign 1 0 146
assign 1 56 150
def 1 56 155
assign 1 0 156
assign 1 0 159
assign 1 0 163
assign 1 56 166
has 1 56 166
assign 1 0 168
assign 1 0 171
assign 1 0 175
assign 1 0 178
assign 1 0 181
assign 1 0 185
assign 1 56 189
def 1 56 194
assign 1 0 195
assign 1 0 198
assign 1 0 202
assign 1 56 205
has 1 56 205
assign 1 0 207
assign 1 0 210
assign 1 0 214
assign 1 0 217
assign 1 0 220
assign 1 57 224
def 1 57 229
assign 1 58 230
toString 0 58 230
write 1 58 231
assign 1 59 232
new 0 59 232
assign 1 59 233
newlineGet 0 59 233
write 1 59 234
print 0 61 237
assign 1 64 240
nextDescendGet 0 64 240
return 1 64 241
return 1 0 244
assign 1 0 247
return 1 0 251
assign 1 0 254
return 1 0 258
assign 1 0 261
return 1 0 265
assign 1 0 268
return 1 0 272
assign 1 0 275
return 1 0 279
assign 1 0 282
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 1820140899: return bem_hasAstMethodsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1306100543: return bem_fGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2041762316: return bem_inClassGet_0();
case 2055025483: return bem_serializeContents_0();
case 116268762: return bem_printGet_0();
case 729571811: return bem_serializeToString_0();
case 1810625581: return bem_inClassMethodGet_0();
case 443668840: return bem_methodNotDefined_0();
case 801883195: return bem_printAstElementsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
case 127351015: return bem_printSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1799543328: return bem_inClassMethodSet_1(bevd_0);
case 1295018290: return bem_fSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1809058646: return bem_hasAstMethodsSet_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 104713556: return bem_new_3((BEC_5_4_LogicBool) bevd_0, (BEC_9_3_ContainerSet) bevd_1, (BEC_4_6_TextString) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_5_BuildVisitPass1();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_5_BuildVisitPass1.bevs_inst = (BEC_5_5_5_BuildVisitPass1)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_5_BuildVisitPass1.bevs_inst;
}
}
