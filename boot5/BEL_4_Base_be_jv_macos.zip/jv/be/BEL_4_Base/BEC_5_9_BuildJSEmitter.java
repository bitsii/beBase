package be.BEL_4_Base;
/* File: source/build/JSEmitter.be */
public class BEC_5_9_BuildJSEmitter extends BEC_5_10_BuildEmitCommon {
public BEC_5_9_BuildJSEmitter() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6A,0x73};
private static byte[] bels_1 = {0x2E,0x6A,0x73};
private static byte[] bels_2 = {};
private static byte[] bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bels_7 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bels_8 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bels_9 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_9, 5));
private static byte[] bels_10 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bels_11 = {0x29,0x20,0x7B};
private static byte[] bels_12 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_12, 41));
private static byte[] bels_13 = {0x29,0x29};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bels_15 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_18 = {0x28,0x29,0x3B};
private static byte[] bels_19 = {0x7D};
private static byte[] bels_20 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bels_21 = {0x2C,0x20};
private static byte[] bels_22 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bels_23 = {0x5D,0x3B};
private static byte[] bels_24 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bels_25 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bels_26 = {0x7D};
private static byte[] bels_27 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_28 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_29 = {0x3B};
private static byte[] bels_30 = {0x7D};
private static byte[] bels_31 = {0x5D,0x3B};
private static byte[] bels_32 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_32, 10));
private static byte[] bels_33 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x5B};
private static byte[] bels_34 = {0x5D,0x20,0x3D,0x20};
private static byte[] bels_35 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bels_36 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_36, 4));
private static byte[] bels_37 = {0x28,0x29};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_37, 2));
private static byte[] bels_38 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bels_39 = {0x29,0x3B};
private static byte[] bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bels_41 = {0x29,0x3B};
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(0));
private static byte[] bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bels_45 = {};
private static byte[] bels_46 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_47 = {0x28,0x29,0x3B};
private static byte[] bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bels_50 = {0x22,0x3B};
private static byte[] bels_51 = {};
private static byte[] bels_52 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_53 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_54 = {0x28,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x36,0x5F,0x37,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x28,0x29,0x29,0x2E,0x62,0x65,0x6D,0x5F,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30,0x28,0x29,0x3B};
private static BEC_4_6_TextString bevo_7 = (new BEC_4_6_TextString(bels_54, 60));
private static byte[] bels_55 = {0x76,0x61,0x72,0x20};
private static byte[] bels_56 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bels_57 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_4_6_TextString bevo_8 = (new BEC_4_6_TextString(bels_57, 25));
private static byte[] bels_58 = {0x20,0x7B};
private static BEC_4_6_TextString bevo_9 = (new BEC_4_6_TextString(bels_58, 2));
private static byte[] bels_59 = {0x74,0x68,0x69,0x73};
private static byte[] bels_60 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_10 = (new BEC_4_6_TextString(bels_60, 17));
private static byte[] bels_61 = {0x28,0x29,0x3B};
private static BEC_4_6_TextString bevo_11 = (new BEC_4_6_TextString(bels_61, 3));
private static byte[] bels_62 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_4_6_TextString bevo_12 = (new BEC_4_6_TextString(bels_62, 38));
private static byte[] bels_63 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_13 = (new BEC_4_6_TextString(bels_63, 4));
private static byte[] bels_64 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_4_6_TextString bevo_14 = (new BEC_4_6_TextString(bels_64, 21));
private static byte[] bels_65 = {0x29};
private static BEC_4_6_TextString bevo_15 = (new BEC_4_6_TextString(bels_65, 1));
private static byte[] bels_66 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_16 = (new BEC_4_6_TextString(bels_66, 4));
private static byte[] bels_67 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_4_6_TextString bevo_17 = (new BEC_4_6_TextString(bels_67, 23));
private static byte[] bels_68 = {0x29};
private static BEC_4_6_TextString bevo_18 = (new BEC_4_6_TextString(bels_68, 1));
private static byte[] bels_69 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_19 = (new BEC_4_6_TextString(bels_69, 4));
private static byte[] bels_70 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_4_6_TextString bevo_20 = (new BEC_4_6_TextString(bels_70, 27));
private static byte[] bels_71 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_4_6_TextString bevo_21 = (new BEC_4_6_TextString(bels_71, 22));
private static byte[] bels_72 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_22 = (new BEC_4_6_TextString(bels_72, 2));
private static byte[] bels_73 = {0x29};
private static BEC_4_6_TextString bevo_23 = (new BEC_4_6_TextString(bels_73, 1));
private static byte[] bels_74 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_24 = (new BEC_4_6_TextString(bels_74, 4));
private static byte[] bels_75 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_4_6_TextString bevo_25 = (new BEC_4_6_TextString(bels_75, 32));
private static byte[] bels_76 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_4_6_TextString bevo_26 = (new BEC_4_6_TextString(bels_76, 22));
private static byte[] bels_77 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_27 = (new BEC_4_6_TextString(bels_77, 2));
private static byte[] bels_78 = {0x29};
private static BEC_4_6_TextString bevo_28 = (new BEC_4_6_TextString(bels_78, 1));
private static byte[] bels_79 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_80 = {0x76,0x61,0x72,0x20};
private static byte[] bels_81 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_82 = {0x7D};
private static byte[] bels_83 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_4_6_TextString bevo_29 = (new BEC_4_6_TextString(bels_83, 5));
private static byte[] bels_84 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_30 = (new BEC_4_6_TextString(bels_84, 4));
private static byte[] bels_85 = {};
private static byte[] bels_86 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_4_6_TextString bevo_31 = (new BEC_4_6_TextString(bels_86, 11));
private static byte[] bels_87 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_4_6_TextString bevo_32 = (new BEC_4_6_TextString(bels_87, 5));
private static byte[] bels_88 = {0x20,0x3D,0x20};
private static BEC_4_6_TextString bevo_33 = (new BEC_4_6_TextString(bels_88, 3));
private static byte[] bels_89 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_4_6_TextString bevo_34 = (new BEC_4_6_TextString(bels_89, 11));
private static byte[] bels_90 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_35 = (new BEC_4_6_TextString(bels_90, 4));
private static byte[] bels_91 = {0x3B};
private static BEC_4_6_TextString bevo_36 = (new BEC_4_6_TextString(bels_91, 1));
private static byte[] bels_92 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_93 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_94 = {};
private static byte[] bels_95 = {};
private static byte[] bels_96 = {};
private static byte[] bels_97 = {};
private static byte[] bels_98 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bels_99 = {};
private static byte[] bels_100 = {};
private static byte[] bels_101 = {};
private static byte[] bels_102 = {};
private static byte[] bels_103 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_4_6_TextString bevo_37 = (new BEC_4_6_TextString(bels_103, 7));
private static byte[] bels_104 = {0x3A,0x20};
private static BEC_4_6_TextString bevo_38 = (new BEC_4_6_TextString(bels_104, 2));
private static byte[] bels_105 = {};
private static byte[] bels_106 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_107 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_4_6_TextString bevo_39 = (new BEC_4_6_TextString(bels_107, 22));
private static byte[] bels_108 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_4_6_TextString bevo_40 = (new BEC_4_6_TextString(bels_108, 5));
private static byte[] bels_109 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_110 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bels_111 = {0x29,0x20,0x7B};
private static byte[] bels_112 = {};
private static byte[] bels_113 = {0x5F};
private static BEC_4_6_TextString bevo_41 = (new BEC_4_6_TextString(bels_113, 1));
private static byte[] bels_114 = {0x62,0x65,0x5F};
private static BEC_4_6_TextString bevo_42 = (new BEC_4_6_TextString(bels_114, 3));
public static BEC_5_9_BuildJSEmitter bevs_inst;
public BEC_4_6_TextString bevp_allOnceDecs;
public BEC_2_4_6_IOFileWriter bevp_shlibe;
public BEC_6_6_SystemObject bem_new_1(BEC_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_4_6_TextString(2, bels_0));
bevp_fileExt = (new BEC_4_6_TextString(3, bels_1));
bevp_exceptDec = (new BEC_4_6_TextString(0, bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_4_6_TextString(44, bels_3));
bevp_falseValue = (new BEC_4_6_TextString(45, bels_4));
bevp_instanceEqual = (new BEC_4_6_TextString(5, bels_5));
bevp_instanceNotEqual = (new BEC_4_6_TextString(5, bels_6));
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_acceptThrow_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevt_3_tmpvar_phold = (new BEC_4_6_TextString(38, bels_7));
bevt_2_tmpvar_phold = bevp_methodBody.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_4_tmpvar_phold = this.bem_formTarg_1(bevt_5_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(15, bels_8));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_acceptCatch_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_4_6_TextString bevl_catchVar = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpvar_phold.bem_add_1(bevt_1_tmpvar_phold);
bevp_methodCatch = bevp_methodCatch.bem_increment_0();
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(8, bels_10));
bevt_4_tmpvar_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(3, bels_11));
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_firstGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpvar_phold = bevo_1;
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpvar_phold = bevo_2;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_8_tmpvar_phold, bevt_12_tmpvar_phold, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_buildClassInfoMethod_1(BEC_4_6_TextString beva_belsBase) throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_lstringStart_2(BEC_4_6_TextString beva_sdec, BEC_4_6_TextString beva_belsName) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = beva_sdec.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_4_6_TextString(22, bels_14));
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(4, bels_15));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_buildCreate_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_4_6_TextString(37, bels_16));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpvar_phold = (new BEC_4_6_TextString(11, bels_17));
bevt_6_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_9_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_10_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_relEmitName_1(bevt_12_tmpvar_phold);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_13_tmpvar_phold = (new BEC_4_6_TextString(3, bels_18));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_4_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpvar_phold = (new BEC_4_6_TextString(1, bels_19));
bevt_14_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_14_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_buildPropList_0() throws Throwable {
BEC_5_8_BuildClassSyn bevl_syn = null;
BEC_9_5_ContainerArray bevl_ptyList = null;
BEC_5_4_LogicBool bevl_first = null;
BEC_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_5_8_BuildClassSyn) bevt_1_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_4_6_TextString(26, bels_20));
bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevl_first = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 77 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 77 */ {
bevl_ptySyn = (BEC_5_6_BuildPtySyn) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_first.bevi_bool) /* Line: 78 */ {
bevl_first = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 79 */
 else  /* Line: 80 */ {
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(2, bels_21));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpvar_phold);
} /* Line: 81 */
bevt_9_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpvar_phold = (new BEC_4_6_TextString(5, bels_22));
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_7_tmpvar_phold.bem_addValue_1(bevp_q);
} /* Line: 83 */
 else  /* Line: 77 */ {
break;
} /* Line: 77 */
} /* Line: 77 */
bevt_13_tmpvar_phold = (new BEC_4_6_TextString(2, bels_23));
bevt_12_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_12_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_buildInitial_0() throws Throwable {
BEC_5_11_BuildClassConfig bevl_newcc = null;
BEC_4_6_TextString bevl_stinst = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_0_tmpvar_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(50, bels_24));
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(14, bels_25));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpvar_phold = (new BEC_4_6_TextString(1, bels_26));
bevt_9_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_9_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(41, bels_27));
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_11_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(7, bels_28));
bevt_17_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpvar_phold = (new BEC_4_6_TextString(1, bels_29));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(1, bels_30));
bevt_20_tmpvar_phold = bevp_ccMethods.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_20_tmpvar_phold.bem_addValue_1(bevp_nl);
this.bem_buildPropList_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_lstringByte_5(BEC_4_6_TextString beva_sdec, BEC_4_6_TextString beva_lival, BEC_4_3_MathInt beva_lipos, BEC_4_3_MathInt beva_bcode, BEC_4_6_TextString beva_hs) throws Throwable {
BEC_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_lstringEnd_1(BEC_4_6_TextString beva_sdec) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(2, bels_31));
bevt_0_tmpvar_phold = beva_sdec.bem_addValue_1(bevt_1_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_4_6_TextString bem_nameForVar_1(BEC_5_3_BuildVar beva_v) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 127 */ {
bevt_2_tmpvar_phold = bevo_3;
bevt_3_tmpvar_phold = beva_v.bem_nameGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
return bevt_1_tmpvar_phold;
} /* Line: 128 */
bevt_4_tmpvar_phold = super.bem_nameForVar_1(beva_v);
return bevt_4_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLib_0() throws Throwable {
BEC_2_4_6_IOFileWriter bevl_libe = null;
BEC_4_6_TextString bevl_typeInstances = null;
BEC_4_6_TextString bevl_libInit = null;
BEC_4_6_TextString bevl_notNullInitConstruct = null;
BEC_4_6_TextString bevl_notNullInitDefault = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_4_6_TextString bevl_nc = null;
BEC_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_5_11_BuildClassConfig bevl_maincc = null;
BEC_4_6_TextString bevl_main = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_45_tmpvar_phold = null;
BEC_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
bevl_libe = this.bem_getLibOutput_0();
bevl_typeInstances = (new BEC_4_6_TextString()).bem_new_0();
bevl_libInit = (new BEC_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (new BEC_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (new BEC_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 142 */ {
bevt_0_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(50, bels_33));
bevt_7_tmpvar_phold = bevl_typeInstances.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_11_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_12_tmpvar_phold = (new BEC_4_6_TextString(4, bels_34));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_14_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_15_tmpvar_phold);
bevt_17_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_relEmitName_1(bevt_17_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(11, bels_35));
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_1_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_19_tmpvar_phold != null && bevt_19_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_19_tmpvar_phold).bevi_bool) /* Line: 148 */ {
bevt_23_tmpvar_phold = bevo_4;
bevt_27_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_25_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_26_tmpvar_phold);
bevt_28_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_relEmitName_1(bevt_28_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_24_tmpvar_phold);
bevt_29_tmpvar_phold = bevo_5;
bevl_nc = bevt_22_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_33_tmpvar_phold = (new BEC_4_6_TextString(75, bels_38));
bevt_32_tmpvar_phold = bevl_notNullInitConstruct.bem_addValue_1(bevt_33_tmpvar_phold);
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(2, bels_39));
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_30_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 157 */ {
bevt_41_tmpvar_phold = (new BEC_4_6_TextString(73, bels_40));
bevt_40_tmpvar_phold = bevl_notNullInitDefault.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_42_tmpvar_phold = (new BEC_4_6_TextString(2, bels_41));
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_38_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 158 */
} /* Line: 157 */
} /* Line: 148 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevl_libe.bem_write_1(bevl_typeInstances);
bevt_45_tmpvar_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bem_sizeGet_0();
bevt_46_tmpvar_phold = bevo_6;
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_equals_1(bevt_46_tmpvar_phold);
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 167 */ {
bevt_48_tmpvar_phold = (new BEC_4_6_TextString(110, bels_42));
bevt_47_tmpvar_phold = bevl_libInit.bem_addValue_1(bevt_48_tmpvar_phold);
bevt_47_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_50_tmpvar_phold = (new BEC_4_6_TextString(112, bels_43));
bevt_49_tmpvar_phold = bevl_libInit.bem_addValue_1(bevt_50_tmpvar_phold);
bevt_49_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_52_tmpvar_phold = (new BEC_4_6_TextString(97, bels_44));
bevt_51_tmpvar_phold = bevl_libInit.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_51_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 170 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_53_tmpvar_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_53_tmpvar_phold);
bevl_maincc = this.bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (new BEC_4_6_TextString(0, bels_45));
bevt_57_tmpvar_phold = (new BEC_4_6_TextString(13, bels_46));
bevt_56_tmpvar_phold = bevl_main.bem_addValue_1(bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_59_tmpvar_phold = (new BEC_4_6_TextString(3, bels_47));
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_54_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_61_tmpvar_phold = (new BEC_4_6_TextString(56, bels_48));
bevt_60_tmpvar_phold = bevl_main.bem_addValue_1(bevt_61_tmpvar_phold);
bevt_60_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_65_tmpvar_phold = (new BEC_4_6_TextString(52, bels_49));
bevt_64_tmpvar_phold = bevl_main.bem_addValue_1(bevt_65_tmpvar_phold);
bevt_67_tmpvar_phold = bevp_build.bem_outputPlatformGet_0();
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_addValue_1(bevt_66_tmpvar_phold);
bevt_68_tmpvar_phold = (new BEC_4_6_TextString(2, bels_50));
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_addValue_1(bevt_68_tmpvar_phold);
bevt_62_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (new BEC_4_6_TextString(0, bels_51));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_70_tmpvar_phold = (new BEC_4_6_TextString(15, bels_52));
bevt_69_tmpvar_phold = bevl_main.bem_addValue_1(bevt_70_tmpvar_phold);
bevt_69_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_72_tmpvar_phold = (new BEC_4_6_TextString(16, bels_53));
bevt_71_tmpvar_phold = bevl_main.bem_addValue_1(bevt_72_tmpvar_phold);
bevt_71_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
this.bem_finishLibOutput_1(bevl_libe);
return this;
} /*method end*/
public BEC_4_6_TextString bem_procStartGet_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_7;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_decForVar_2(BEC_4_6_TextString beva_b, BEC_5_3_BuildVar beva_v) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 203 */ {
} /* Line: 203 */
 else  /* Line: 205 */ {
bevt_2_tmpvar_phold = beva_v.bem_isArgGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_not_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 206 */ {
bevt_3_tmpvar_phold = (new BEC_4_6_TextString(4, bels_55));
beva_b.bem_addValue_1(bevt_3_tmpvar_phold);
} /* Line: 207 */
bevt_4_tmpvar_phold = this.bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 209 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(7, bels_56));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_8;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpvar_phold = bevo_9;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(4, bels_59));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_extend_1(BEC_4_6_TextString beva_parent) throws Throwable {
BEC_4_6_TextString bevl_extstr = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevo_10;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_parent);
bevt_5_tmpvar_phold = bevo_11;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevl_extstr = bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpvar_phold = bevl_extstr.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_12;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevl_extstr = bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public BEC_4_6_TextString bem_lintConstruct_2(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_13;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_14;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_15;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_lfloatConstruct_2(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_16;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_17;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_18;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_lstringConstruct_5(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node, BEC_4_6_TextString beva_belsName, BEC_4_3_MathInt beva_lisz, BEC_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 241 */ {
bevt_8_tmpvar_phold = bevo_19;
bevt_10_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_20;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_21;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(beva_belsName);
bevt_14_tmpvar_phold = bevo_22;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_lisz);
bevt_15_tmpvar_phold = bevo_23;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /* Line: 242 */
bevt_24_tmpvar_phold = bevo_24;
bevt_26_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpvar_phold);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_25;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = bevo_26;
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_add_1(beva_belsName);
bevt_30_tmpvar_phold = bevo_27;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_30_tmpvar_phold);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_add_1(beva_lisz);
bevt_31_tmpvar_phold = bevo_28;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevt_31_tmpvar_phold);
return bevt_16_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_classBeginGet_0() throws Throwable {
BEC_4_6_TextString bevl_extends = null;
BEC_4_6_TextString bevl_begin = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 248 */ {
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevl_extends = this.bem_extend_1((BEC_4_6_TextString) bevt_1_tmpvar_phold);
} /* Line: 249 */
 else  /* Line: 250 */ {
bevt_3_tmpvar_phold = (new BEC_4_6_TextString(24, bels_79));
bevl_extends = this.bem_extend_1(bevt_3_tmpvar_phold);
} /* Line: 251 */
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(4, bels_80));
bevt_6_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_4_6_TextString(15, bels_81));
bevl_begin = bevt_4_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = (new BEC_4_6_TextString(1, bels_82));
bevt_8_tmpvar_phold = bevl_begin.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public BEC_4_6_TextString bem_emitNameForCall_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1796577138, BEL_4_Base.bevn_superCallGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 267 */ {
bevt_3_tmpvar_phold = bevo_29;
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /* Line: 268 */
bevt_7_tmpvar_phold = bevo_30;
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_4_6_TextString bevl_end = null;
BEC_5_4_BuildNode bevl_node = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
bevl_end = (new BEC_4_6_TextString(0, bels_85));
bevt_0_tmpvar_loop = bevp_superCalls.bem_iteratorGet_0();
while (true)
 /* Line: 275 */ {
bevt_1_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 275 */ {
bevl_node = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpvar_phold = bevo_31;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_32;
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_node.bem_heldGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_17_tmpvar_phold = bevo_33;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_34;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_35;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_22_tmpvar_phold = bevl_node.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_23_tmpvar_phold = bevo_36;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_23_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevl_end.bem_addValue_1(bevt_2_tmpvar_phold);
} /* Line: 276 */
 else  /* Line: 275 */ {
break;
} /* Line: 275 */
} /* Line: 275 */
return bevl_end;
} /*method end*/
public BEC_6_6_SystemObject bem_writeOnceDecs_2(BEC_6_6_SystemObject beva_cle, BEC_6_6_SystemObject beva_onceDecs) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevp_allOnceDecs = (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 286 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_2_4_6_IOFileWriter bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_getLibOutput_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_finishClassOutput_1(BEC_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_4_6_TextString bevl_p = null;
BEC_2_4_IOFile bevl_jsi = null;
BEC_4_6_TextString bevl_inc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_IOFile bevt_4_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_5_tmpvar_phold = null;
BEC_2_4_IOFile bevt_6_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_IOFile bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_10_SystemParameters bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_13_tmpvar_phold = null;
BEC_6_10_SystemParameters bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 302 */ {
bevp_lineCount = (new BEC_4_3_MathInt(0));
bevt_5_tmpvar_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_fileGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_existsGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_7_tmpvar_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_fileGet_0();
bevt_6_tmpvar_phold.bem_makeDirs_0();
} /* Line: 305 */
bevt_9_tmpvar_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_writerGet_0();
bevp_shlibe = (BEC_2_4_6_IOFileWriter) bevt_8_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevt_11_tmpvar_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpvar_phold = (new BEC_4_6_TextString(9, bels_92));
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_has_1(bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 309 */ {
bevt_14_tmpvar_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpvar_phold = (new BEC_4_6_TextString(9, bels_93));
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_get_1(bevt_15_tmpvar_phold);
bevt_0_tmpvar_loop = bevt_13_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 310 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 310 */ {
bevl_p = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_17_tmpvar_phold = (new BEC_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpvar_phold.bem_fileGet_0();
bevt_19_tmpvar_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_4_6_TextString) bevt_18_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_20_tmpvar_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 314 */
 else  /* Line: 310 */ {
break;
} /* Line: 310 */
} /* Line: 310 */
} /* Line: 310 */
} /* Line: 309 */
return bevp_shlibe;
} /*method end*/
public BEC_6_6_SystemObject bem_finishLibOutput_1(BEC_2_4_6_IOFileWriter beva_libe) throws Throwable {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public BEC_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(0, bels_94));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_beginNs_1(BEC_4_6_TextString beva_libName) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(0, bels_95));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_libNs_1(BEC_4_6_TextString beva_libName) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(0, bels_96));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_endNs_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(0, bels_97));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_klassDecGet_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(13, bels_98));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_spropDecGet_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(0, bels_99));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(0, bels_100));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(0, bels_101));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_baseSpropDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(0, bels_102));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_overrideSpropDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_37;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(beva_varName);
bevt_4_tmpvar_phold = bevo_38;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_typeName);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_onceDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(0, bels_105));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_getInitialInst_1(BEC_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_4_6_TextString(31, bels_106));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_onceVarDec_1(BEC_4_6_TextString beva_count) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevo_39;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_40;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_count);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_startMethod_5(BEC_4_6_TextString beva_mtdDec, BEC_5_11_BuildClassConfig beva_returnType, BEC_4_6_TextString beva_mtdName, BEC_4_6_TextString beva_argDecs, BEC_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = bevp_methods.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_4_6_TextString(11, bels_109));
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(12, bels_110));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpvar_phold = (new BEC_4_6_TextString(3, bels_111));
bevt_6_tmpvar_phold = bevp_methods.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_4_6_TextString bem_formCast_1(BEC_5_11_BuildClassConfig beva_cc) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(0, bels_112));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_useDynMethodsGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_getFullEmitName_2(BEC_4_6_TextString beva_nameSpace, BEC_4_6_TextString beva_emitName) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_41;
bevt_1_tmpvar_phold = beva_nameSpace.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_emitName);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_getNameSpace_1(BEC_4_6_TextString beva_libName) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_42;
bevt_2_tmpvar_phold = this.bem_libEmitName_1(beva_libName);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_11_BuildClassConfig bem_getClassConfig_1(BEC_5_8_BuildNamePath beva_np) throws Throwable {
BEC_5_11_BuildClassConfig bevl_cc = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_cc = super.bem_getClassConfig_1(beva_np);
bevt_0_tmpvar_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpvar_phold);
return bevl_cc;
} /*method end*/
public BEC_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_5_8_BuildNamePath beva_np) throws Throwable {
BEC_5_11_BuildClassConfig bevl_cc = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_cc = super.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpvar_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpvar_phold);
return bevl_cc;
} /*method end*/
public BEC_4_6_TextString bem_allOnceDecsGet_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public BEC_6_6_SystemObject bem_allOnceDecsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allOnceDecs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_6_6_SystemObject bem_shlibeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_shlibe = (BEC_2_4_6_IOFileWriter) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {27, 28, 29, 33, 35, 36, 38, 39, 43, 43, 43, 43, 43, 43, 43, 43, 47, 47, 47, 48, 49, 49, 49, 49, 49, 49, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 59, 59, 59, 59, 59, 59, 59, 63, 63, 63, 63, 63, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 66, 66, 66, 71, 71, 72, 74, 74, 74, 74, 76, 77, 0, 77, 77, 79, 81, 81, 83, 83, 83, 83, 83, 83, 87, 87, 87, 92, 92, 92, 93, 95, 95, 95, 95, 95, 98, 98, 98, 98, 100, 100, 100, 102, 102, 102, 102, 102, 105, 105, 105, 105, 105, 105, 107, 107, 107, 109, 114, 115, 116, 122, 122, 122, 127, 128, 128, 128, 128, 130, 130, 136, 138, 139, 140, 141, 142, 142, 144, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 148, 148, 148, 150, 150, 150, 150, 150, 150, 150, 150, 150, 156, 156, 156, 156, 156, 156, 157, 157, 157, 158, 158, 158, 158, 158, 158, 164, 167, 167, 167, 167, 168, 168, 168, 169, 169, 169, 170, 170, 170, 173, 174, 177, 178, 178, 179, 181, 182, 182, 182, 182, 182, 182, 182, 183, 183, 183, 184, 184, 184, 184, 184, 184, 184, 184, 186, 187, 188, 189, 190, 190, 190, 191, 191, 191, 192, 194, 199, 199, 199, 203, 206, 206, 207, 207, 209, 209, 214, 214, 218, 218, 218, 218, 218, 218, 222, 222, 227, 227, 227, 227, 227, 227, 227, 228, 228, 228, 228, 228, 229, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 248, 248, 249, 249, 249, 251, 251, 253, 253, 253, 253, 253, 261, 261, 261, 262, 263, 267, 267, 268, 268, 268, 268, 268, 270, 270, 270, 270, 270, 274, 275, 0, 275, 275, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 278, 285, 285, 286, 288, 289, 289, 294, 294, 302, 302, 303, 304, 304, 304, 304, 305, 305, 305, 307, 307, 307, 309, 309, 309, 310, 310, 310, 310, 0, 310, 310, 311, 311, 312, 312, 312, 313, 313, 314, 320, 324, 325, 330, 330, 334, 334, 338, 338, 342, 342, 346, 346, 350, 350, 354, 354, 359, 359, 364, 364, 368, 368, 368, 368, 368, 368, 372, 372, 376, 376, 376, 376, 376, 381, 381, 381, 381, 381, 381, 381, 386, 386, 386, 386, 386, 386, 386, 388, 390, 390, 390, 395, 395, 399, 399, 403, 403, 403, 403, 407, 407, 407, 407, 411, 412, 412, 413, 417, 418, 418, 419, 0, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {169, 170, 171, 172, 173, 174, 175, 176, 187, 188, 189, 190, 191, 192, 193, 194, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 247, 248, 249, 250, 251, 252, 253, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 313, 314, 315, 316, 317, 318, 319, 320, 321, 321, 324, 326, 328, 331, 332, 334, 335, 336, 337, 338, 339, 345, 346, 347, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 410, 411, 412, 418, 419, 420, 429, 431, 432, 433, 434, 436, 437, 524, 525, 526, 527, 528, 529, 532, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 577, 578, 579, 580, 581, 582, 590, 591, 592, 593, 594, 596, 597, 598, 599, 600, 601, 602, 603, 604, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 648, 649, 650, 658, 662, 663, 665, 666, 668, 669, 675, 676, 684, 685, 686, 687, 688, 689, 693, 694, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 855, 860, 861, 862, 863, 866, 867, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 891, 892, 894, 895, 896, 897, 898, 900, 901, 902, 903, 904, 933, 934, 934, 937, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 968, 973, 978, 979, 981, 982, 983, 987, 988, 1018, 1023, 1024, 1025, 1026, 1027, 1028, 1030, 1031, 1032, 1034, 1035, 1036, 1037, 1038, 1039, 1041, 1042, 1043, 1044, 1044, 1047, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1065, 1068, 1069, 1074, 1075, 1079, 1080, 1084, 1085, 1089, 1090, 1094, 1095, 1099, 1100, 1104, 1105, 1109, 1110, 1114, 1115, 1123, 1124, 1125, 1126, 1127, 1128, 1132, 1133, 1140, 1141, 1142, 1143, 1144, 1153, 1154, 1155, 1156, 1157, 1158, 1159, 1170, 1171, 1172, 1173, 1174, 1175, 1176, 1177, 1178, 1179, 1180, 1185, 1186, 1190, 1191, 1197, 1198, 1199, 1200, 1206, 1207, 1208, 1209, 1214, 1215, 1216, 1217, 1222, 1223, 1224, 1225, 1228, 1231, 1235, 1238};
/* BEGIN LINEINFO 
assign 1 27 169
new 0 27 169
assign 1 28 170
new 0 28 170
assign 1 29 171
new 0 29 171
new 1 33 172
assign 1 35 173
new 0 35 173
assign 1 36 174
new 0 36 174
assign 1 38 175
new 0 38 175
assign 1 39 176
new 0 39 176
assign 1 43 187
new 0 43 187
assign 1 43 188
addValue 1 43 188
assign 1 43 189
secondGet 0 43 189
assign 1 43 190
formTarg 1 43 190
assign 1 43 191
addValue 1 43 191
assign 1 43 192
new 0 43 192
assign 1 43 193
addValue 1 43 193
addValue 1 43 194
assign 1 47 215
new 0 47 215
assign 1 47 216
toString 0 47 216
assign 1 47 217
add 1 47 217
assign 1 48 218
increment 0 48 218
assign 1 49 219
new 0 49 219
assign 1 49 220
addValue 1 49 220
assign 1 49 221
addValue 1 49 221
assign 1 49 222
new 0 49 222
assign 1 49 223
addValue 1 49 223
addValue 1 49 224
assign 1 51 225
containedGet 0 51 225
assign 1 51 226
firstGet 0 51 226
assign 1 51 227
containedGet 0 51 227
assign 1 51 228
firstGet 0 51 228
assign 1 51 229
new 0 51 229
assign 1 51 230
add 1 51 230
assign 1 51 231
new 0 51 231
assign 1 51 232
add 1 51 232
assign 1 51 233
finalAssign 3 51 233
addValue 1 51 234
assign 1 59 247
emitNameGet 0 59 247
assign 1 59 248
addValue 1 59 248
assign 1 59 249
new 0 59 249
assign 1 59 250
addValue 1 59 250
assign 1 59 251
addValue 1 59 251
assign 1 59 252
new 0 59 252
addValue 1 59 253
assign 1 63 273
emitNameGet 0 63 273
assign 1 63 274
addValue 1 63 274
assign 1 63 275
new 0 63 275
assign 1 63 276
addValue 1 63 276
addValue 1 63 277
assign 1 64 278
new 0 64 278
assign 1 64 279
addValue 1 64 279
assign 1 64 280
heldGet 0 64 280
assign 1 64 281
namepathGet 0 64 281
assign 1 64 282
getClassConfig 1 64 282
assign 1 64 283
libNameGet 0 64 283
assign 1 64 284
relEmitName 1 64 284
assign 1 64 285
addValue 1 64 285
assign 1 64 286
new 0 64 286
assign 1 64 287
addValue 1 64 287
addValue 1 64 288
assign 1 66 289
new 0 66 289
assign 1 66 290
addValue 1 66 290
addValue 1 66 291
assign 1 71 313
heldGet 0 71 313
assign 1 71 314
synGet 0 71 314
assign 1 72 315
ptyListGet 0 72 315
assign 1 74 316
emitNameGet 0 74 316
assign 1 74 317
addValue 1 74 317
assign 1 74 318
new 0 74 318
addValue 1 74 319
assign 1 76 320
new 0 76 320
assign 1 77 321
iteratorGet 0 0 321
assign 1 77 324
hasNextGet 0 77 324
assign 1 77 326
nextGet 0 77 326
assign 1 79 328
new 0 79 328
assign 1 81 331
new 0 81 331
addValue 1 81 332
assign 1 83 334
addValue 1 83 334
assign 1 83 335
new 0 83 335
assign 1 83 336
addValue 1 83 336
assign 1 83 337
nameGet 0 83 337
assign 1 83 338
addValue 1 83 338
addValue 1 83 339
assign 1 87 345
new 0 87 345
assign 1 87 346
addValue 1 87 346
addValue 1 87 347
assign 1 92 375
heldGet 0 92 375
assign 1 92 376
namepathGet 0 92 376
assign 1 92 377
getClassConfig 1 92 377
assign 1 93 378
getInitialInst 1 93 378
assign 1 95 379
emitNameGet 0 95 379
assign 1 95 380
addValue 1 95 380
assign 1 95 381
new 0 95 381
assign 1 95 382
addValue 1 95 382
addValue 1 95 383
assign 1 98 384
addValue 1 98 384
assign 1 98 385
new 0 98 385
assign 1 98 386
addValue 1 98 386
addValue 1 98 387
assign 1 100 388
new 0 100 388
assign 1 100 389
addValue 1 100 389
addValue 1 100 390
assign 1 102 391
emitNameGet 0 102 391
assign 1 102 392
addValue 1 102 392
assign 1 102 393
new 0 102 393
assign 1 102 394
addValue 1 102 394
addValue 1 102 395
assign 1 105 396
new 0 105 396
assign 1 105 397
addValue 1 105 397
assign 1 105 398
addValue 1 105 398
assign 1 105 399
new 0 105 399
assign 1 105 400
addValue 1 105 400
addValue 1 105 401
assign 1 107 402
new 0 107 402
assign 1 107 403
addValue 1 107 403
addValue 1 107 404
buildPropList 0 109 405
getCode 2 114 410
assign 1 115 411
toString 0 115 411
addValue 1 116 412
assign 1 122 418
new 0 122 418
assign 1 122 419
addValue 1 122 419
addValue 1 122 420
assign 1 127 429
isPropertyGet 0 127 429
assign 1 128 431
new 0 128 431
assign 1 128 432
nameGet 0 128 432
assign 1 128 433
add 1 128 433
return 1 128 434
assign 1 130 436
nameForVar 1 130 436
return 1 130 437
assign 1 136 524
getLibOutput 0 136 524
assign 1 138 525
new 0 138 525
assign 1 139 526
new 0 139 526
assign 1 140 527
new 0 140 527
assign 1 141 528
new 0 141 528
assign 1 142 529
iteratorGet 0 142 529
assign 1 142 532
hasNextGet 0 142 532
assign 1 144 534
nextGet 0 144 534
assign 1 146 535
new 0 146 535
assign 1 146 536
addValue 1 146 536
assign 1 146 537
addValue 1 146 537
assign 1 146 538
heldGet 0 146 538
assign 1 146 539
namepathGet 0 146 539
assign 1 146 540
toString 0 146 540
assign 1 146 541
addValue 1 146 541
assign 1 146 542
addValue 1 146 542
assign 1 146 543
new 0 146 543
assign 1 146 544
addValue 1 146 544
assign 1 146 545
heldGet 0 146 545
assign 1 146 546
namepathGet 0 146 546
assign 1 146 547
getClassConfig 1 146 547
assign 1 146 548
libNameGet 0 146 548
assign 1 146 549
relEmitName 1 146 549
assign 1 146 550
addValue 1 146 550
assign 1 146 551
new 0 146 551
assign 1 146 552
addValue 1 146 552
addValue 1 146 553
assign 1 148 554
heldGet 0 148 554
assign 1 148 555
synGet 0 148 555
assign 1 148 556
hasDefaultGet 0 148 556
assign 1 150 558
new 0 150 558
assign 1 150 559
heldGet 0 150 559
assign 1 150 560
namepathGet 0 150 560
assign 1 150 561
getClassConfig 1 150 561
assign 1 150 562
libNameGet 0 150 562
assign 1 150 563
relEmitName 1 150 563
assign 1 150 564
add 1 150 564
assign 1 150 565
new 0 150 565
assign 1 150 566
add 1 150 566
assign 1 156 567
new 0 156 567
assign 1 156 568
addValue 1 156 568
assign 1 156 569
addValue 1 156 569
assign 1 156 570
new 0 156 570
assign 1 156 571
addValue 1 156 571
addValue 1 156 572
assign 1 157 573
heldGet 0 157 573
assign 1 157 574
synGet 0 157 574
assign 1 157 575
hasDefaultGet 0 157 575
assign 1 158 577
new 0 158 577
assign 1 158 578
addValue 1 158 578
assign 1 158 579
addValue 1 158 579
assign 1 158 580
new 0 158 580
assign 1 158 581
addValue 1 158 581
addValue 1 158 582
write 1 164 590
assign 1 167 591
usedLibrarysGet 0 167 591
assign 1 167 592
sizeGet 0 167 592
assign 1 167 593
new 0 167 593
assign 1 167 594
equals 1 167 594
assign 1 168 596
new 0 168 596
assign 1 168 597
addValue 1 168 597
addValue 1 168 598
assign 1 169 599
new 0 169 599
assign 1 169 600
addValue 1 169 600
addValue 1 169 601
assign 1 170 602
new 0 170 602
assign 1 170 603
addValue 1 170 603
addValue 1 170 604
write 1 173 606
write 1 174 607
assign 1 177 608
new 0 177 608
assign 1 178 609
mainNameGet 0 178 609
fromString 1 178 610
assign 1 179 611
getClassConfig 1 179 611
assign 1 181 612
new 0 181 612
assign 1 182 613
new 0 182 613
assign 1 182 614
addValue 1 182 614
assign 1 182 615
fullEmitNameGet 0 182 615
assign 1 182 616
addValue 1 182 616
assign 1 182 617
new 0 182 617
assign 1 182 618
addValue 1 182 618
addValue 1 182 619
assign 1 183 620
new 0 183 620
assign 1 183 621
addValue 1 183 621
addValue 1 183 622
assign 1 184 623
new 0 184 623
assign 1 184 624
addValue 1 184 624
assign 1 184 625
outputPlatformGet 0 184 625
assign 1 184 626
nameGet 0 184 626
assign 1 184 627
addValue 1 184 627
assign 1 184 628
new 0 184 628
assign 1 184 629
addValue 1 184 629
addValue 1 184 630
write 1 186 631
assign 1 187 632
new 0 187 632
write 1 188 633
write 1 189 634
assign 1 190 635
new 0 190 635
assign 1 190 636
addValue 1 190 636
addValue 1 190 637
assign 1 191 638
new 0 191 638
assign 1 191 639
addValue 1 191 639
addValue 1 191 640
write 1 192 641
finishLibOutput 1 194 642
assign 1 199 648
new 0 199 648
assign 1 199 649
add 1 199 649
return 1 199 650
assign 1 203 658
isPropertyGet 0 203 658
assign 1 206 662
isArgGet 0 206 662
assign 1 206 663
not 0 206 663
assign 1 207 665
new 0 207 665
addValue 1 207 666
assign 1 209 668
nameForVar 1 209 668
addValue 1 209 669
assign 1 214 675
new 0 214 675
return 1 214 676
assign 1 218 684
new 0 218 684
assign 1 218 685
add 1 218 685
assign 1 218 686
new 0 218 686
assign 1 218 687
add 1 218 687
assign 1 218 688
add 1 218 688
return 1 218 689
assign 1 222 693
new 0 222 693
return 1 222 694
assign 1 227 708
emitNameGet 0 227 708
assign 1 227 709
new 0 227 709
assign 1 227 710
add 1 227 710
assign 1 227 711
add 1 227 711
assign 1 227 712
new 0 227 712
assign 1 227 713
add 1 227 713
assign 1 227 714
addValue 1 227 714
assign 1 228 715
emitNameGet 0 228 715
assign 1 228 716
add 1 228 716
assign 1 228 717
new 0 228 717
assign 1 228 718
add 1 228 718
assign 1 228 719
addValue 1 228 719
return 1 229 720
assign 1 233 734
new 0 233 734
assign 1 233 735
libNameGet 0 233 735
assign 1 233 736
relEmitName 1 233 736
assign 1 233 737
add 1 233 737
assign 1 233 738
new 0 233 738
assign 1 233 739
add 1 233 739
assign 1 233 740
heldGet 0 233 740
assign 1 233 741
literalValueGet 0 233 741
assign 1 233 742
add 1 233 742
assign 1 233 743
new 0 233 743
assign 1 233 744
add 1 233 744
return 1 233 745
assign 1 237 759
new 0 237 759
assign 1 237 760
libNameGet 0 237 760
assign 1 237 761
relEmitName 1 237 761
assign 1 237 762
add 1 237 762
assign 1 237 763
new 0 237 763
assign 1 237 764
add 1 237 764
assign 1 237 765
heldGet 0 237 765
assign 1 237 766
literalValueGet 0 237 766
assign 1 237 767
add 1 237 767
assign 1 237 768
new 0 237 768
assign 1 237 769
add 1 237 769
return 1 237 770
assign 1 242 806
new 0 242 806
assign 1 242 807
libNameGet 0 242 807
assign 1 242 808
relEmitName 1 242 808
assign 1 242 809
add 1 242 809
assign 1 242 810
new 0 242 810
assign 1 242 811
add 1 242 811
assign 1 242 812
emitNameGet 0 242 812
assign 1 242 813
add 1 242 813
assign 1 242 814
new 0 242 814
assign 1 242 815
add 1 242 815
assign 1 242 816
add 1 242 816
assign 1 242 817
new 0 242 817
assign 1 242 818
add 1 242 818
assign 1 242 819
add 1 242 819
assign 1 242 820
new 0 242 820
assign 1 242 821
add 1 242 821
return 1 242 822
assign 1 244 824
new 0 244 824
assign 1 244 825
libNameGet 0 244 825
assign 1 244 826
relEmitName 1 244 826
assign 1 244 827
add 1 244 827
assign 1 244 828
new 0 244 828
assign 1 244 829
add 1 244 829
assign 1 244 830
emitNameGet 0 244 830
assign 1 244 831
add 1 244 831
assign 1 244 832
new 0 244 832
assign 1 244 833
add 1 244 833
assign 1 244 834
add 1 244 834
assign 1 244 835
new 0 244 835
assign 1 244 836
add 1 244 836
assign 1 244 837
add 1 244 837
assign 1 244 838
new 0 244 838
assign 1 244 839
add 1 244 839
return 1 244 840
assign 1 248 855
def 1 248 860
assign 1 249 861
libNameGet 0 249 861
assign 1 249 862
relEmitName 1 249 862
assign 1 249 863
extend 1 249 863
assign 1 251 866
new 0 251 866
assign 1 251 867
extend 1 251 867
assign 1 253 869
new 0 253 869
assign 1 253 870
emitNameGet 0 253 870
assign 1 253 871
addValue 1 253 871
assign 1 253 872
new 0 253 872
assign 1 253 873
addValue 1 253 873
assign 1 261 874
new 0 261 874
assign 1 261 875
addValue 1 261 875
addValue 1 261 876
addValue 1 262 877
return 1 263 878
assign 1 267 891
heldGet 0 267 891
assign 1 267 892
superCallGet 0 267 892
assign 1 268 894
new 0 268 894
assign 1 268 895
heldGet 0 268 895
assign 1 268 896
nameGet 0 268 896
assign 1 268 897
add 1 268 897
return 1 268 898
assign 1 270 900
new 0 270 900
assign 1 270 901
heldGet 0 270 901
assign 1 270 902
nameGet 0 270 902
assign 1 270 903
add 1 270 903
return 1 270 904
assign 1 274 933
new 0 274 933
assign 1 275 934
iteratorGet 0 0 934
assign 1 275 937
hasNextGet 0 275 937
assign 1 275 939
nextGet 0 275 939
assign 1 276 940
emitNameGet 0 276 940
assign 1 276 941
new 0 276 941
assign 1 276 942
add 1 276 942
assign 1 276 943
new 0 276 943
assign 1 276 944
add 1 276 944
assign 1 276 945
heldGet 0 276 945
assign 1 276 946
nameGet 0 276 946
assign 1 276 947
add 1 276 947
assign 1 276 948
new 0 276 948
assign 1 276 949
add 1 276 949
assign 1 276 950
emitNameGet 0 276 950
assign 1 276 951
add 1 276 951
assign 1 276 952
new 0 276 952
assign 1 276 953
add 1 276 953
assign 1 276 954
new 0 276 954
assign 1 276 955
add 1 276 955
assign 1 276 956
heldGet 0 276 956
assign 1 276 957
nameGet 0 276 957
assign 1 276 958
add 1 276 958
assign 1 276 959
new 0 276 959
assign 1 276 960
add 1 276 960
assign 1 276 961
add 1 276 961
addValue 1 276 962
return 1 278 968
assign 1 285 973
undef 1 285 978
assign 1 286 979
new 0 286 979
addValue 1 288 981
assign 1 289 982
new 0 289 982
return 1 289 983
assign 1 294 987
getLibOutput 0 294 987
return 1 294 988
assign 1 302 1018
undef 1 302 1023
assign 1 303 1024
new 0 303 1024
assign 1 304 1025
parentGet 0 304 1025
assign 1 304 1026
fileGet 0 304 1026
assign 1 304 1027
existsGet 0 304 1027
assign 1 304 1028
not 0 304 1028
assign 1 305 1030
parentGet 0 305 1030
assign 1 305 1031
fileGet 0 305 1031
makeDirs 0 305 1032
assign 1 307 1034
fileGet 0 307 1034
assign 1 307 1035
writerGet 0 307 1035
assign 1 307 1036
open 0 307 1036
assign 1 309 1037
paramsGet 0 309 1037
assign 1 309 1038
new 0 309 1038
assign 1 309 1039
has 1 309 1039
assign 1 310 1041
paramsGet 0 310 1041
assign 1 310 1042
new 0 310 1042
assign 1 310 1043
get 1 310 1043
assign 1 310 1044
iteratorGet 0 0 1044
assign 1 310 1047
hasNextGet 0 310 1047
assign 1 310 1049
nextGet 0 310 1049
assign 1 311 1050
apNew 1 311 1050
assign 1 311 1051
fileGet 0 311 1051
assign 1 312 1052
readerGet 0 312 1052
assign 1 312 1053
open 0 312 1053
assign 1 312 1054
readString 0 312 1054
assign 1 313 1055
readerGet 0 313 1055
close 0 313 1056
write 1 314 1057
return 1 320 1065
close 0 324 1068
assign 1 325 1069
assign 1 330 1074
new 0 330 1074
return 1 330 1075
assign 1 334 1079
new 0 334 1079
return 1 334 1080
assign 1 338 1084
new 0 338 1084
return 1 338 1085
assign 1 342 1089
new 0 342 1089
return 1 342 1090
assign 1 346 1094
new 0 346 1094
return 1 346 1095
assign 1 350 1099
new 0 350 1099
return 1 350 1100
assign 1 354 1104
new 0 354 1104
return 1 354 1105
assign 1 359 1109
new 0 359 1109
return 1 359 1110
assign 1 364 1114
new 0 364 1114
return 1 364 1115
assign 1 368 1123
new 0 368 1123
assign 1 368 1124
add 1 368 1124
assign 1 368 1125
new 0 368 1125
assign 1 368 1126
add 1 368 1126
assign 1 368 1127
add 1 368 1127
return 1 368 1128
assign 1 372 1132
new 0 372 1132
return 1 372 1133
assign 1 376 1140
libNameGet 0 376 1140
assign 1 376 1141
relEmitName 1 376 1141
assign 1 376 1142
new 0 376 1142
assign 1 376 1143
add 1 376 1143
return 1 376 1144
assign 1 381 1153
emitNameGet 0 381 1153
assign 1 381 1154
new 0 381 1154
assign 1 381 1155
add 1 381 1155
assign 1 381 1156
new 0 381 1156
assign 1 381 1157
add 1 381 1157
assign 1 381 1158
add 1 381 1158
return 1 381 1159
assign 1 386 1170
emitNameGet 0 386 1170
assign 1 386 1171
addValue 1 386 1171
assign 1 386 1172
new 0 386 1172
assign 1 386 1173
addValue 1 386 1173
assign 1 386 1174
addValue 1 386 1174
assign 1 386 1175
new 0 386 1175
addValue 1 386 1176
addValue 1 388 1177
assign 1 390 1178
new 0 390 1178
assign 1 390 1179
addValue 1 390 1179
addValue 1 390 1180
assign 1 395 1185
new 0 395 1185
return 1 395 1186
assign 1 399 1190
new 0 399 1190
return 1 399 1191
assign 1 403 1197
new 0 403 1197
assign 1 403 1198
add 1 403 1198
assign 1 403 1199
add 1 403 1199
return 1 403 1200
assign 1 407 1206
new 0 407 1206
assign 1 407 1207
libEmitName 1 407 1207
assign 1 407 1208
add 1 407 1208
return 1 407 1209
assign 1 411 1214
getClassConfig 1 411 1214
assign 1 412 1215
fullEmitNameGet 0 412 1215
emitNameSet 1 412 1216
return 1 413 1217
assign 1 417 1222
getLocalClassConfig 1 417 1222
assign 1 418 1223
fullEmitNameGet 0 418 1223
emitNameSet 1 418 1224
return 1 419 1225
return 1 0 1228
assign 1 0 1231
return 1 0 1235
assign 1 0 1238
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 493012039: return bem_buildGet_0();
case 1831751774: return bem_cnodeGet_0();
case 4647121: return bem_doEmit_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 902412214: return bem_classCallsGet_0();
case 962646066: return bem_shlibeGet_0();
case 1703922349: return bem_fullLibEmitNameGet_0();
case 991255330: return bem_mainStartGet_0();
case 287040793: return bem_hashGet_0();
case 402158238: return bem_inFilePathedGet_0();
case 1711936384: return bem_baseSmtdDecGet_0();
case 498080472: return bem_mnodeGet_0();
case 160277051: return bem_procStartGet_0();
case 622039562: return bem_intNpGet_0();
case 1638160588: return bem_lineCountGet_0();
case 681402717: return bem_boolTypeGet_0();
case 1354714650: return bem_copy_0();
case 845792839: return bem_iteratorGet_0();
case 103017121: return bem_runtimeInitGet_0();
case 1841706211: return bem_returnTypeGet_0();
case 772789066: return bem_libEmitPathGet_0();
case 916491491: return bem_emitLib_0();
case 1052944126: return bem_csynGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 955058175: return bem_lastMethodBodyLinesGet_0();
case 1177623581: return bem_callNamesGet_0();
case 36542021: return bem_mainEndGet_0();
case 314718434: return bem_print_0();
case 229958684: return bem_constGet_0();
case 101343106: return bem_nativeCSlotsGet_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 5583797: return bem_maxDynArgsGet_0();
case 1566392515: return bem_covariantReturnsGet_0();
case 603479476: return bem_allOnceDecsGet_0();
case 1240611285: return bem_onceDecsGet_0();
case 786424307: return bem_tagGet_0();
case 1947619572: return bem_msynGet_0();
case 1755995201: return bem_transGet_0();
case 1910715228: return bem_libEmitNameGet_0();
case 1727672536: return bem_propDecGet_0();
case 1064889660: return bem_trueValueGet_0();
case 362974009: return bem_parentConfGet_0();
case 1312373307: return bem_buildCreate_0();
case 1241388883: return bem_lastMethodBodySizeGet_0();
case 727049506: return bem_exceptDecGet_0();
case 722876119: return bem_buildClassInfo_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 86482693: return bem_overrideSmtdDecGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 1152064310: return bem_instOfGet_0();
case 1820417453: return bem_create_0();
case 2039613615: return bem_instanceNotEqualGet_0();
case 254265568: return bem_buildPropList_0();
case 1317806639: return bem_baseMtdDecGet_0();
case 2019411446: return bem_classBeginGet_0();
case 1073009537: return bem_beginNs_0();
case 378762597: return bem_boolNpGet_0();
case 89706405: return bem_ccCacheGet_0();
case 220901978: return bem_emitLangGet_0();
case 397629001: return bem_maxSpillArgsLenGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 236269941: return bem_ccMethodsGet_0();
case 2055025483: return bem_serializeContents_0();
case 644675716: return bem_ntypesGet_0();
case 1372235405: return bem_superCallsGet_0();
case 361542143: return bem_classEmitsGet_0();
case 388723214: return bem_preClassGet_0();
case 1081275759: return bem_classesInDepthOrderGet_0();
case 2001798761: return bem_nlGet_0();
case 1081412016: return bem_many_0();
case 1774940957: return bem_toString_0();
case 991179882: return bem_qGet_0();
case 946095539: return bem_mainInClassGet_0();
case 1449942744: return bem_instanceEqualGet_0();
case 1500143225: return bem_useDynMethodsGet_0();
case 1859739893: return bem_methodsGet_0();
case 1786051763: return bem_methodCatchGet_0();
case 729571811: return bem_serializeToString_0();
case 1181505319: return bem_buildInitial_0();
case 104713553: return bem_new_0();
case 1413054881: return bem_smnlcsGet_0();
case 57260628: return bem_getClassOutput_0();
case 628036310: return bem_lastMethodsSizeGet_0();
case 1967844855: return bem_initialDecGet_0();
case 483359873: return bem_superNameGet_0();
case 294732055: return bem_floatNpGet_0();
case 443668840: return bem_methodNotDefined_0();
case 604504089: return bem_falseValueGet_0();
case 1923547459: return bem_boolCcGet_0();
case 1012494862: return bem_once_0();
case 797225458: return bem_dynMethodsGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1178070402: return bem_fileExtGet_0();
case 1369896794: return bem_objectNpGet_0();
case 1380285640: return bem_objectCcGet_0();
case 1487140092: return bem_classEndGet_0();
case 1327064356: return bem_methodBodyGet_0();
case 2085643372: return bem_stringNpGet_0();
case 1607412815: return bem_endNs_0();
case 1431933907: return bem_lastCallGet_0();
case 1795655423: return bem_propertyDecsGet_0();
case 1109279973: return bem_spropDecGet_0();
case 1498619679: return bem_getLibOutput_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case 708434875: return bem_klassDecGet_0();
case 1102720804: return bem_classNameGet_0();
case 944442837: return bem_classConfGet_0();
case 1747980150: return bem_smnlecsGet_0();
case 1529527065: return bem_onceCountGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 571409003: return bem_libEmitName_1((BEC_4_6_TextString) bevd_0);
case 367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 1053807407: return bem_trueValueSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_5_4_BuildNode) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 165152860: return bem_libNs_1((BEC_4_6_TextString) bevd_0);
case 1227314505: return bem_acceptIf_1((BEC_5_4_BuildNode) bevd_0);
case 541207893: return bem_complete_1((BEC_5_4_BuildNode) bevd_0);
case 283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case 1702694534: return bem_acceptBraces_1((BEC_5_4_BuildNode) bevd_0);
case 1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 610957309: return bem_intNpSet_1(bevd_0);
case 386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_5_4_BuildNode) bevd_0);
case 593061802: return bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevd_0);
case 1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_5_4_BuildNode) bevd_0);
case 973728319: return bem_shlibeSet_1(bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case 891329961: return bem_classCallsSet_1(bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_5_4_BuildNode) bevd_0);
case 980097629: return bem_qSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1820669521: return bem_cnodeSet_1(bevd_0);
case 945327254: return bem_acceptIfEmit_1((BEC_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case 1073009536: return bem_beginNs_1((BEC_4_6_TextString) bevd_0);
case 90260853: return bem_nativeCSlotsSet_1(bevd_0);
case 1022041723: return bem_acceptCatch_1((BEC_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case 1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1901078234: return bem_getEmitName_1((BEC_5_8_BuildNamePath) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_4_6_TextString) bevd_0);
case 1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case 1912465206: return bem_boolCcSet_1(bevd_0);
case 377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case 943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case 1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 70425956: return bem_acceptRbraces_1((BEC_5_4_BuildNode) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 16141842: return bem_onceVarDec_1((BEC_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case 1980754914: return bem_oldacceptIf_1((BEC_5_4_BuildNode) bevd_0);
case 1936537319: return bem_msynSet_1(bevd_0);
case 551679723: return bem_formCast_1((BEC_5_11_BuildClassConfig) bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
case 616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1438860491: return bem_instanceEqualSet_1(bevd_0);
case 1899632975: return bem_libEmitNameSet_1(bevd_0);
case 478502832: return bem_lstringEnd_1((BEC_4_6_TextString) bevd_0);
case 1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_5_3_BuildVar) bevd_0);
case 2110408325: return bem_acceptMethod_1((BEC_5_4_BuildNode) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_5_4_BuildNode) bevd_0);
case 391075985: return bem_inFilePathedSet_1(bevd_0);
case 36312873: return bem_buildStackLines_1((BEC_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_5_4_BuildNode) bevd_0);
case 1041861873: return bem_csynSet_1(bevd_0);
case 1931824221: return bem_mangleName_1((BEC_5_8_BuildNamePath) bevd_0);
case 715967253: return bem_exceptDecSet_1(bevd_0);
case 1830623958: return bem_returnTypeSet_1(bevd_0);
case 1562282714: return bem_getInitialInst_1((BEC_5_11_BuildClassConfig) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case 1774969510: return bem_methodCatchSet_1(bevd_0);
case 614561729: return bem_allOnceDecsSet_1(bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case 1358814541: return bem_objectNpSet_1(bevd_0);
case 1820890036: return bem_extend_1((BEC_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case 2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case 65026440: return bem_formTarg_1((BEC_5_4_BuildNode) bevd_0);
case 627952553: return bem_getLocalClassConfig_1((BEC_5_8_BuildNamePath) bevd_0);
case 508002125: return bem_emitting_1((BEC_4_6_TextString) bevd_0);
case 707569329: return bem_getTraceInfo_1((BEC_5_4_BuildNode) bevd_0);
case 724180734: return bem_acceptClass_1((BEC_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_5_4_BuildNode) bevd_0, (BEC_5_8_BuildNamePath) bevd_1);
case 1978614329: return bem_lintConstruct_2((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 1604046278: return bem_lfloatConstruct_2((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 569933480: return bem_lstringStart_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1697242261: return bem_overrideSpropDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1671519971: return bem_countLines_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 297627956: return bem_onceDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_4_6_TextString) bevd_0, (BEC_5_3_BuildVar) bevd_1);
case 6388749: return bem_decForVar_2((BEC_4_6_TextString) bevd_0, (BEC_5_3_BuildVar) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 722876117: return bem_buildClassInfo_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_5_4_BuildNode) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_5_8_BuildNamePath) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_6_6_SystemObject bemd_5(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3, BEC_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case 316092711: return bem_startMethod_5((BEC_4_6_TextString) bevd_0, (BEC_5_11_BuildClassConfig) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_6_TextString) bevd_3, bevd_4);
case 2023930725: return bem_lstringByte_5((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_4_3_MathInt) bevd_3, (BEC_4_6_TextString) bevd_4);
case 1591575024: return bem_lstringConstruct_5((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_3_MathInt) bevd_3, (BEC_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_9_BuildJSEmitter();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_9_BuildJSEmitter.bevs_inst = (BEC_5_9_BuildJSEmitter)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_9_BuildJSEmitter.bevs_inst;
}
}
