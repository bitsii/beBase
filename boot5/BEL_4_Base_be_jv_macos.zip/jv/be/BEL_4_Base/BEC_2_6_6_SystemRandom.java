package be.BEL_4_Base;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_2_6_6_SystemRandom extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }

   
    public java.security.SecureRandom srand = new java.security.SecureRandom();
    
   private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(26));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(65));
public static BEC_2_6_6_SystemRandom bevs_inst;
public BEC_2_6_6_SystemRandom bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() throws Throwable {
this.bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() throws Throwable {

      srand.setSeed(srand.generateSeed(8));
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) throws Throwable {

      beva_value.bevi_int = srand.nextInt();
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = this.bem_getInt_1(beva_value);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_absValue_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_tmpvar_phold = this.bem_getString_2(bevt_1_tmpvar_phold, beva_size);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_str.bem_capacityGet_0();
if (bevt_1_tmpvar_phold.bevi_int < beva_size.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 277 */ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 278 */
bevt_2_tmpvar_phold = beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_tmpvar_phold);
bevl_value = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 286 */ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 286 */ {
bevt_9_tmpvar_phold = bevo_0;
bevt_8_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_9_tmpvar_phold.bem_once_0();
bevt_7_tmpvar_phold = this.bem_getInt_2(bevl_value, bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_1;
bevt_10_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_11_tmpvar_phold.bem_once_0();
bevt_7_tmpvar_phold.bevi_int += bevt_10_tmpvar_phold.bevi_int;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_6_tmpvar_phold);
bevl_i.bevi_int++;
} /* Line: 286 */
 else  /* Line: 286 */ {
break;
} /* Line: 286 */
} /* Line: 286 */
return beva_str;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {224, 265, 269, 269, 269, 269, 273, 273, 273, 277, 277, 277, 278, 280, 280, 285, 286, 286, 286, 288, 288, 288, 288, 288, 288, 288, 286, 290};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 31, 37, 38, 39, 40, 45, 46, 47, 64, 65, 70, 71, 73, 74, 75, 76, 79, 84, 85, 86, 87, 88, 89, 90, 92, 93, 99};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
seedNow 0 224 20
return 1 265 31
assign 1 269 37
getInt 1 269 37
assign 1 269 38
absValue 0 269 38
assign 1 269 39
modulusValue 1 269 39
return 1 269 40
assign 1 273 45
new 1 273 45
assign 1 273 46
getString 2 273 46
return 1 273 47
assign 1 277 64
capacityGet 0 277 64
assign 1 277 65
lesser 1 277 70
capacitySet 1 278 71
assign 1 280 73
copy 0 280 73
sizeSet 1 280 74
assign 1 285 75
new 0 285 75
assign 1 286 76
new 0 286 76
assign 1 286 79
lesser 1 286 84
assign 1 288 85
new 0 288 85
assign 1 288 86
once 0 288 86
assign 1 288 87
getInt 2 288 87
assign 1 288 88
new 0 288 88
assign 1 288 89
once 0 288 89
assign 1 288 90
addValue 1 288 90
setIntUnchecked 2 288 92
incrementValue 0 286 93
return 1 290 99
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 613284118: return bem_seedNow_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 422057735: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1956186667: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 1956186668: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 422057734: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemRandom();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemRandom.bevs_inst = (BEC_2_6_6_SystemRandom)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemRandom.bevs_inst;
}
}
