package be.BEL_4_Base;
/* File: source/base/OpiFc.be */
public class BEC_6_22_SystemObjectPropertyIterator extends BEC_6_6_SystemObject {
public BEC_6_22_SystemObjectPropertyIterator() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
public static BEC_6_22_SystemObjectPropertyIterator bevs_inst;
public BEC_6_6_SystemObject bevp_instance;
public BEC_4_3_MathInt bevp_minProperty;
public BEC_4_3_MathInt bevp_maxProperty;
public BEC_4_3_MathInt bevp_pos;
public BEC_6_22_SystemObjectPropertyIterator bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_22_SystemObjectPropertyIterator bem_new_1(BEC_6_6_SystemObject beva__instance) throws Throwable {
BEC_6_22_SystemObjectPropertyIterator bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_phold = this.bem_new_2(beva__instance, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_22_SystemObjectPropertyIterator bem_new_2(BEC_6_6_SystemObject beva__instance, BEC_5_4_LogicBool beva_forceFirstSlot) throws Throwable {
BEC_4_3_MathInt bevl__minProperty = null;
BEC_4_3_MathInt bevl__maxProperty = null;
bevl__minProperty = (new BEC_4_3_MathInt()).bem_new_0();
bevl__maxProperty = (new BEC_4_3_MathInt()).bem_new_0();
if (beva_forceFirstSlot.bevi_bool) /* Line: 54 */ {
} /* Line: 55 */

      String prefix = "bevp_";
      java.lang.reflect.Field[] fields = beva__instance.getClass().getFields();
      int numprops = 0;
      for (int i = 0;i < fields.length;i++) {
        if (fields[i].getName().startsWith(prefix)) {
            //System.out.println("got field named " + fields[i].getName());
            numprops++;
        }
      }
      bevl__minProperty.bevi_int = 0;
      bevl__maxProperty.bevi_int = numprops;
      bevp_instance = beva__instance;
bevp_minProperty = bevl__minProperty;
bevp_maxProperty = bevl__maxProperty;
bevp_pos = bevl__minProperty;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_pos.bem_lesser_1(bevp_maxProperty);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 111 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_1_tmpvar_phold;
} /* Line: 112 */
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_6_6_SystemObject bevl__instance = null;
BEC_4_3_MathInt bevl__pos = null;
BEC_6_6_SystemObject bevl_inst = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl__instance = bevp_instance;
bevl__pos = bevp_pos;
bevt_0_tmpvar_phold = bevp_pos.bem_lesser_1(bevp_maxProperty);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 130 */ {

          String prefix = "bevp_";
          java.lang.reflect.Field[] fields = bevl__instance.getClass().getFields();
          int numprops = 0;
          for (int i = 0;i < fields.length;i++) {
            if (fields[i].getName().startsWith(prefix)) {
                if (numprops == bevl__pos.bevi_int) {
                    bevl_inst = (BEC_6_6_SystemObject) (fields[i].get(bevl__instance));
                    break;
                }
                numprops++;
            }
          }
         bevp_pos = bevp_pos.bem_increment_0();
} /* Line: 177 */
return bevl_inst;
} /*method end*/
public BEC_6_6_SystemObject bem_nextSet_1(BEC_6_6_SystemObject beva_value) throws Throwable {
BEC_6_6_SystemObject bevl__instance = null;
BEC_4_3_MathInt bevl__pos = null;
BEC_6_6_SystemObject bevl__value = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl__instance = bevp_instance;
bevl__pos = bevp_pos;
bevl__value = beva_value;
bevt_0_tmpvar_phold = bevp_pos.bem_lesser_1(bevp_maxProperty);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 196 */ {

          String prefix = "bevp_";
          java.lang.reflect.Field[] fields = bevl__instance.getClass().getFields();
          int numprops = 0;
          for (int i = 0;i < fields.length;i++) {
            if (fields[i].getName().startsWith(prefix)) {
                if (numprops == bevl__pos.bevi_int) {
                    fields[i].set(bevl__instance, bevl__value);
                    break;
                }
                numprops++;
            }
          }
         bevp_pos = bevp_pos.bem_increment_0();
} /* Line: 241 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_skip_1(BEC_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevp_pos = bevp_pos.bem_add_1(beva_multiNullCount);
bevt_0_tmpvar_phold = bevp_pos.bem_greater_1(bevp_maxProperty);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevp_pos = bevp_maxProperty;
} /* Line: 248 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_instanceGet_0() throws Throwable {
return bevp_instance;
} /*method end*/
public BEC_6_6_SystemObject bem_instanceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_instance = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_minPropertyGet_0() throws Throwable {
return bevp_minProperty;
} /*method end*/
public BEC_6_6_SystemObject bem_minPropertySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_minProperty = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_maxPropertyGet_0() throws Throwable {
return bevp_maxProperty;
} /*method end*/
public BEC_6_6_SystemObject bem_maxPropertySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_maxProperty = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_6_6_SystemObject bem_posSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_pos = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {30, 30, 30, 43, 44, 103, 104, 105, 106, 111, 112, 112, 114, 114, 128, 129, 130, 177, 179, 193, 194, 195, 196, 241, 246, 247, 248, 0, 0, 0, 0, 0, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {18, 19, 20, 25, 26, 41, 42, 43, 44, 51, 53, 54, 56, 57, 64, 65, 66, 81, 83, 90, 91, 92, 93, 108, 114, 115, 117, 122, 125, 129, 132, 136, 139, 143, 146};
/* BEGIN LINEINFO 
assign 1 30 18
new 0 30 18
assign 1 30 19
new 2 30 19
return 1 30 20
assign 1 43 25
new 0 43 25
assign 1 44 26
new 0 44 26
assign 1 103 41
assign 1 104 42
assign 1 105 43
assign 1 106 44
assign 1 111 51
lesser 1 111 51
assign 1 112 53
new 0 112 53
return 1 112 54
assign 1 114 56
new 0 114 56
return 1 114 57
assign 1 128 64
assign 1 129 65
assign 1 130 66
lesser 1 130 66
assign 1 177 81
increment 0 177 81
return 1 179 83
assign 1 193 90
assign 1 194 91
assign 1 195 92
assign 1 196 93
lesser 1 196 93
assign 1 241 108
increment 0 241 108
assign 1 246 114
add 1 246 114
assign 1 247 115
greater 1 247 115
assign 1 248 117
return 1 0 122
assign 1 0 125
return 1 0 129
assign 1 0 132
return 1 0 136
assign 1 0 139
return 1 0 143
assign 1 0 146
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 390522450: return bem_maxPropertyGet_0();
case 715968403: return bem_posGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 454390912: return bem_minPropertyGet_0();
case 1820417453: return bem_create_0();
case 1405080078: return bem_instanceGet_0();
case 786424307: return bem_tagGet_0();
case 108485850: return bem_hasNextGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 443308659: return bem_minPropertySet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1393997825: return bem_instanceSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
case 900559503: return bem_skip_1((BEC_4_3_MathInt) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 379440197: return bem_maxPropertySet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 727050656: return bem_posSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_22_SystemObjectPropertyIterator();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_22_SystemObjectPropertyIterator.bevs_inst = (BEC_6_22_SystemObjectPropertyIterator)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_22_SystemObjectPropertyIterator.bevs_inst;
}
}
