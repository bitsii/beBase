package be.BEL_4_Base;
/* File: source/extended/FileReadWrite.be */
public class BEC_2_6_IOReader extends BEC_6_6_SystemObject {
public BEC_2_6_IOReader() { }

    public java.io.InputStream bevi_is;
    
   private static byte[] becc_clname = {0x49,0x4F,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x46,0x69,0x6C,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6F,0x70,0x65,0x6E,0x2C,0x20,0x72,0x65,0x61,0x64,0x20,0x61,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x2E};
private static byte[] bels_1 = {0x54,0x72,0x79,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x62,0x65,0x67,0x69,0x6E,0x20,0x72,0x65,0x61,0x64,0x20,0x62,0x65,0x79,0x6F,0x6E,0x64,0x20,0x62,0x75,0x66,0x66,0x65,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(16));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_5 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(0));
public static BEC_2_6_IOReader bevs_inst;
public BEC_6_6_SystemObject bevp_vfile;
public BEC_5_4_LogicBool bevp_isClosed;
public BEC_4_3_MathInt bevp_blockSize;
public BEC_2_6_IOReader bem_new_0() throws Throwable {
bevp_isClosed = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_blockSize = (new BEC_4_3_MathInt(256));
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_extOpen_0() throws Throwable {
bevp_isClosed = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_close_0() throws Throwable {

      if (this.bevi_is != null) {
        this.bevi_is.close();
        this.bevi_is = null;
      }
      bevp_isClosed = be.BELS_Base.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_vfileGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_vfileSet_1(BEC_6_6_SystemObject beva_vfile) throws Throwable {
return this;
} /*method end*/
public BEC_2_10_IOByteReader bem_byteReaderGet_0() throws Throwable {
BEC_2_10_IOByteReader bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_10_IOByteReader()).bem_readerNew_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_10_IOByteReader bem_byteReader_1(BEC_4_3_MathInt beva_blockSize) throws Throwable {
BEC_2_10_IOByteReader bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_10_IOByteReader()).bem_readerBlockNew_2(this, beva_blockSize);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_readIntoBuffer_1(BEC_4_6_TextString beva_readBuf) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = this.bem_readIntoBuffer_2(beva_readBuf, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_readIntoBuffer_2(BEC_4_6_TextString beva_readBuf, BEC_4_3_MathInt beva_at) throws Throwable {
BEC_4_3_MathInt bevl_readsz = null;
BEC_4_6_TextString bevl_intoi = null;
BEC_4_3_MathInt bevl_bleni = null;
BEC_6_9_SystemException bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_9_SystemException bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
if (bevp_isClosed.bevi_bool) /* Line: 241 */ {
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(33, bels_0));
bevt_0_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_1_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_0_tmpvar_phold);
} /* Line: 242 */
bevl_readsz = (new BEC_4_3_MathInt()).bem_new_0();
bevl_intoi = beva_readBuf;
bevl_bleni = bevl_intoi.bem_capacityGet_0();
bevt_2_tmpvar_phold = bevl_bleni.bem_lesserEquals_1(beva_at);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_4_tmpvar_phold = (new BEC_4_6_TextString(43, bels_1));
bevt_3_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 248 */

      int bevls_read = this.bevi_is.read(beva_readBuf.bevi_bytes, beva_at.bevi_int, beva_readBuf.bevi_bytes.length - beva_at.bevi_int);
      if (bevls_read < 0) {
        bevls_read = 0;
      }
      bevl_readsz.bevi_int = bevls_read + beva_at.bevi_int;
      bevl_intoi.bem_sizeSet_1(bevl_readsz);
return bevl_readsz;
} /*method end*/
public BEC_4_6_TextString bem_readBuffer_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_1(bevp_blockSize);
bevt_0_tmpvar_phold = this.bem_readBuffer_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_readBuffer_1(BEC_4_6_TextString beva_builder) throws Throwable {
BEC_4_3_MathInt bevl_at = null;
BEC_4_3_MathInt bevl_nowAt = null;
BEC_4_3_MathInt bevl_nsize = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
bevl_at = (new BEC_4_3_MathInt(0));
bevl_nowAt = this.bem_readIntoBuffer_2(beva_builder, bevl_at);
while (true)
 /* Line: 307 */ {
bevt_0_tmpvar_phold = bevl_nowAt.bem_greater_1(bevl_at);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 307 */ {
bevl_at = bevl_nowAt;
bevt_3_tmpvar_phold = beva_builder.bem_capacityGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_subtract_1(bevl_at);
bevt_4_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_lesser_1(bevt_4_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 309 */ {
bevt_7_tmpvar_phold = bevl_at.bem_add_1(bevp_blockSize);
bevt_8_tmpvar_phold = bevo_1;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_2;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_multiply_1(bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_3;
bevl_nsize = bevt_5_tmpvar_phold.bem_divide_1(bevt_10_tmpvar_phold);
beva_builder.bem_capacitySet_1(bevl_nsize);
} /* Line: 311 */
bevl_nowAt = this.bem_readIntoBuffer_2(beva_builder, bevl_at);
} /* Line: 313 */
 else  /* Line: 307 */ {
break;
} /* Line: 307 */
} /* Line: 307 */
return beva_builder;
} /*method end*/
public BEC_4_6_TextString bem_altReadBuffer_0() throws Throwable {
BEC_4_6_TextString bevl_rbuf = null;
BEC_4_6_TextString bevl_builder = null;
BEC_4_3_MathInt bevl_got = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevl_rbuf = (new BEC_4_6_TextString()).bem_new_1(bevp_blockSize);
bevl_builder = (new BEC_4_6_TextString()).bem_new_0();
bevl_got = this.bem_readIntoBuffer_1(bevl_rbuf);
bevl_builder.bem_addValue_1(bevl_rbuf);
while (true)
 /* Line: 323 */ {
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = bevl_got.bem_notEquals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 323 */ {
bevl_got = this.bem_readIntoBuffer_1(bevl_rbuf);
bevl_builder.bem_addValue_1(bevl_rbuf);
} /* Line: 325 */
 else  /* Line: 323 */ {
break;
} /* Line: 323 */
} /* Line: 323 */
return bevl_builder;
} /*method end*/
public BEC_4_6_TextString bem_readBufferLine_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_readBufferLine_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_readBufferLine_1(BEC_4_6_TextString beva_builder) throws Throwable {
BEC_4_6_TextString bevl_crb = null;
BEC_4_6_TextString bevl_rbuf = null;
BEC_4_3_MathInt bevl_got = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
bevt_2_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_newlineGet_0();
bevl_crb = bevt_0_tmpvar_phold.bem_addValue_1(bevt_1_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevl_rbuf = (new BEC_4_6_TextString()).bem_new_1(bevt_3_tmpvar_phold);
bevl_got = this.bem_readIntoBuffer_1(bevl_rbuf);
bevt_5_tmpvar_phold = bevo_5;
bevt_4_tmpvar_phold = bevl_got.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 341 */ {
beva_builder = null;
return beva_builder;
} /* Line: 343 */
beva_builder.bem_addValue_1(bevl_rbuf);
while (true)
 /* Line: 346 */ {
bevt_7_tmpvar_phold = bevo_6;
bevt_6_tmpvar_phold = bevl_got.bem_notEquals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 346 */ {
bevt_8_tmpvar_phold = bevl_rbuf.bem_equals_1(bevl_crb);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 347 */ {
return beva_builder;
} /* Line: 348 */
bevl_got = this.bem_readIntoBuffer_1(bevl_rbuf);
beva_builder.bem_addValue_1(bevl_rbuf);
} /* Line: 351 */
 else  /* Line: 346 */ {
break;
} /* Line: 346 */
} /* Line: 346 */
return beva_builder;
} /*method end*/
public BEC_4_6_TextString bem_readString_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_readBuffer_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_readString_1(BEC_4_6_TextString beva_builder) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_readBuffer_1(beva_builder);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_copy_0();
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public BEC_6_6_SystemObject bem_isClosedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isClosed = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_blockSizeGet_0() throws Throwable {
return bevp_blockSize;
} /*method end*/
public BEC_6_6_SystemObject bem_blockSizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_blockSize = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {165, 166, 172, 208, 216, 216, 220, 220, 224, 224, 224, 242, 242, 242, 244, 245, 246, 247, 248, 248, 248, 296, 297, 301, 301, 301, 305, 306, 307, 308, 309, 309, 309, 309, 310, 310, 310, 310, 310, 310, 310, 311, 313, 315, 319, 320, 321, 322, 323, 323, 324, 325, 327, 331, 331, 331, 338, 338, 338, 338, 339, 339, 340, 341, 341, 342, 343, 345, 346, 346, 347, 348, 350, 351, 353, 357, 357, 361, 361, 361, 0, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {24, 25, 29, 38, 49, 50, 54, 55, 60, 61, 62, 74, 75, 76, 78, 79, 80, 81, 83, 84, 85, 93, 94, 99, 100, 101, 118, 119, 122, 124, 125, 126, 127, 128, 130, 131, 132, 133, 134, 135, 136, 137, 139, 145, 153, 154, 155, 156, 159, 160, 162, 163, 169, 174, 175, 176, 191, 192, 193, 194, 195, 196, 197, 198, 199, 201, 202, 204, 207, 208, 210, 212, 214, 215, 221, 225, 226, 231, 232, 233, 236, 239, 243, 246};
/* BEGIN LINEINFO 
assign 1 165 24
new 0 165 24
assign 1 166 25
new 0 166 25
assign 1 172 29
new 0 172 29
assign 1 208 38
new 0 208 38
assign 1 216 49
readerNew 1 216 49
return 1 216 50
assign 1 220 54
readerBlockNew 2 220 54
return 1 220 55
assign 1 224 60
new 0 224 60
assign 1 224 61
readIntoBuffer 2 224 61
return 1 224 62
assign 1 242 74
new 0 242 74
assign 1 242 75
new 1 242 75
throw 1 242 76
assign 1 244 78
new 0 244 78
assign 1 245 79
assign 1 246 80
capacityGet 0 246 80
assign 1 247 81
lesserEquals 1 247 81
assign 1 248 83
new 0 248 83
assign 1 248 84
new 1 248 84
throw 1 248 85
sizeSet 1 296 93
return 1 297 94
assign 1 301 99
new 1 301 99
assign 1 301 100
readBuffer 1 301 100
return 1 301 101
assign 1 305 118
new 0 305 118
assign 1 306 119
readIntoBuffer 2 306 119
assign 1 307 122
greater 1 307 122
assign 1 308 124
assign 1 309 125
capacityGet 0 309 125
assign 1 309 126
subtract 1 309 126
assign 1 309 127
new 0 309 127
assign 1 309 128
lesser 1 309 128
assign 1 310 130
add 1 310 130
assign 1 310 131
new 0 310 131
assign 1 310 132
add 1 310 132
assign 1 310 133
new 0 310 133
assign 1 310 134
multiply 1 310 134
assign 1 310 135
new 0 310 135
assign 1 310 136
divide 1 310 136
capacitySet 1 311 137
assign 1 313 139
readIntoBuffer 2 313 139
return 1 315 145
assign 1 319 153
new 1 319 153
assign 1 320 154
new 0 320 154
assign 1 321 155
readIntoBuffer 1 321 155
addValue 1 322 156
assign 1 323 159
new 0 323 159
assign 1 323 160
notEquals 1 323 160
assign 1 324 162
readIntoBuffer 1 324 162
addValue 1 325 163
return 1 327 169
assign 1 331 174
new 0 331 174
assign 1 331 175
readBufferLine 1 331 175
return 1 331 176
assign 1 338 191
new 0 338 191
assign 1 338 192
new 0 338 192
assign 1 338 193
newlineGet 0 338 193
assign 1 338 194
addValue 1 338 194
assign 1 339 195
new 0 339 195
assign 1 339 196
new 1 339 196
assign 1 340 197
readIntoBuffer 1 340 197
assign 1 341 198
new 0 341 198
assign 1 341 199
equals 1 341 199
assign 1 342 201
return 1 343 202
addValue 1 345 204
assign 1 346 207
new 0 346 207
assign 1 346 208
notEquals 1 346 208
assign 1 347 210
equals 1 347 210
return 1 348 212
assign 1 350 214
readIntoBuffer 1 350 214
addValue 1 351 215
return 1 353 221
assign 1 357 225
readBuffer 0 357 225
return 1 357 226
assign 1 361 231
readBuffer 1 361 231
assign 1 361 232
copy 0 361 232
return 1 361 233
return 1 0 236
assign 1 0 239
return 1 0 243
assign 1 0 246
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1109612452: return bem_byteReaderGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1325881255: return bem_readBuffer_0();
case 1358082055: return bem_blockSizeGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 1242327477: return bem_vfileGet_0();
case 287040793: return bem_hashGet_0();
case 698342331: return bem_readBufferLine_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 1240964868: return bem_extOpen_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 866536361: return bem_close_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1041895440: return bem_altReadBuffer_0();
case 1081412016: return bem_many_0();
case 347960120: return bem_readString_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 792269839: return bem_isClosedGet_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1253409730: return bem_vfileSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1346999802: return bem_blockSizeSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1992292136: return bem_readIntoBuffer_1((BEC_4_6_TextString) bevd_0);
case 781187586: return bem_isClosedSet_1(bevd_0);
case 1325881256: return bem_readBuffer_1((BEC_4_6_TextString) bevd_0);
case 698342332: return bem_readBufferLine_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1385004253: return bem_byteReader_1((BEC_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 347960121: return bem_readString_1((BEC_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1992292137: return bem_readIntoBuffer_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_IOReader();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_IOReader.bevs_inst = (BEC_2_6_IOReader)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_IOReader.bevs_inst;
}
}
