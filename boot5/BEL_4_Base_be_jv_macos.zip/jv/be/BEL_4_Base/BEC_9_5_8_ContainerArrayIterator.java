package be.BEL_4_Base;
/* File: source/base/Array.be */
public class BEC_9_5_8_ContainerArrayIterator extends BEC_6_6_SystemObject {
public BEC_9_5_8_ContainerArrayIterator() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x41,0x72,0x72,0x61,0x79,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(-1));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(1));
public static BEC_9_5_8_ContainerArrayIterator bevs_inst;
public BEC_4_3_MathInt bevp_pos;
public BEC_9_5_ContainerArray bevp_list;
public BEC_9_5_8_ContainerArrayIterator bem_new_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevp_pos = (new BEC_4_3_MathInt(-1));
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevp_list = (new BEC_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_9_5_8_ContainerArrayIterator bem_new_1(BEC_6_6_SystemObject beva_a) throws Throwable {
bevp_pos = (new BEC_4_3_MathInt(-1));
bevp_list = (BEC_9_5_ContainerArray) beva_a;
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_containerGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_5_4_LogicBool bem_hasCurrentGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevp_pos.bem_greater_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 39 */ {
bevt_4_tmpvar_phold = bevp_list.bem_lengthGet_0();
bevt_3_tmpvar_phold = bevp_pos.bem_lesser_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 39 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 39 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 39 */
 else  /* Line: 39 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 39 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /* Line: 40 */
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_currentGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_list.bem_get_1(bevp_pos);
return (BEC_5_4_LogicBool) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_currentSet_1(BEC_6_6_SystemObject beva_toSet) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_1;
bevt_1_tmpvar_phold = bevp_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_5_tmpvar_phold = bevo_2;
bevt_4_tmpvar_phold = bevp_pos.bem_add_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevp_list.bem_lengthGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_lesser_1(bevt_6_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 54 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 54 */
 else  /* Line: 54 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 54 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 55 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_pos = bevp_pos.bem_increment_0();
bevt_0_tmpvar_phold = bevp_list.bem_get_1(bevp_pos);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_nextSet_1(BEC_6_6_SystemObject beva_toSet) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_pos = bevp_pos.bem_increment_0();
bevt_0_tmpvar_phold = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_skip_1(BEC_4_3_MathInt beva_multiNullCount) throws Throwable {
bevp_pos = bevp_pos.bem_add_1(beva_multiNullCount);
return this;
} /*method end*/
public BEC_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_6_6_SystemObject bem_posSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_pos = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_listGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_6_6_SystemObject bem_listSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_list = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {24, 25, 25, 30, 31, 35, 39, 39, 39, 39, 0, 0, 0, 40, 40, 42, 42, 46, 46, 50, 50, 54, 54, 54, 54, 54, 54, 0, 0, 0, 55, 55, 57, 57, 61, 62, 62, 66, 67, 67, 71, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 21, 22, 26, 36, 37, 39, 40, 42, 45, 49, 52, 53, 55, 56, 60, 61, 65, 66, 78, 79, 81, 82, 83, 84, 86, 89, 93, 96, 97, 99, 100, 104, 105, 106, 110, 111, 112, 115, 119, 122, 126, 129};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 24 15
new 0 24 15
assign 1 25 16
new 0 25 16
assign 1 25 17
new 1 25 17
assign 1 30 21
new 0 30 21
assign 1 31 22
return 1 35 26
assign 1 39 36
new 0 39 36
assign 1 39 37
greater 1 39 37
assign 1 39 39
lengthGet 0 39 39
assign 1 39 40
lesser 1 39 40
assign 1 0 42
assign 1 0 45
assign 1 0 49
assign 1 40 52
new 0 40 52
return 1 40 53
assign 1 42 55
new 0 42 55
return 1 42 56
assign 1 46 60
get 1 46 60
return 1 46 61
assign 1 50 65
put 2 50 65
return 1 50 66
assign 1 54 78
new 0 54 78
assign 1 54 79
greaterEquals 1 54 79
assign 1 54 81
new 0 54 81
assign 1 54 82
add 1 54 82
assign 1 54 83
lengthGet 0 54 83
assign 1 54 84
lesser 1 54 84
assign 1 0 86
assign 1 0 89
assign 1 0 93
assign 1 55 96
new 0 55 96
return 1 55 97
assign 1 57 99
new 0 57 99
return 1 57 100
assign 1 61 104
increment 0 61 104
assign 1 62 105
get 1 62 105
return 1 62 106
assign 1 66 110
increment 0 66 110
assign 1 67 111
put 2 67 111
return 1 67 112
assign 1 71 115
add 1 71 115
return 1 0 119
assign 1 0 122
return 1 0 126
assign 1 0 129
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 715968403: return bem_posGet_0();
case 1246679159: return bem_listGet_0();
case 1693924536: return bem_hasCurrentGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1446310798: return bem_currentGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 108485850: return bem_hasNextGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1235596906: return bem_listSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 900559503: return bem_skip_1((BEC_4_3_MathInt) bevd_0);
case 727050656: return bem_posSet_1(bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_9_5_8_ContainerArrayIterator();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_9_5_8_ContainerArrayIterator.bevs_inst = (BEC_9_5_8_ContainerArrayIterator)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_9_5_8_ContainerArrayIterator.bevs_inst;
}
}
