package be.BEL_4_Base;
/* File: source/build/Pass7.be */
public class BEC_5_5_5_BuildVisitPass7 extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass7() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x65,0x77};
private static byte[] bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_2 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_3 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_4 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_5 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_6 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_7 = {0x74,0x72,0x75,0x65};
private static byte[] bels_8 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_9 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_10 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_11, 41));
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_15 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_16 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_17 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_18 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_20 = {0x6E,0x65,0x77};
public static BEC_5_5_5_BuildVisitPass7 bevs_inst;
public BEC_5_8_BuildNamePath bevp_inClassNp;
public BEC_4_6_TextString bevp_inFile;
public BEC_5_5_5_BuildVisitPass7 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_buildLiteral_2(BEC_6_6_SystemObject beva_node, BEC_6_6_SystemObject beva_tName) throws Throwable {
BEC_6_6_SystemObject bevl_nlnp = null;
BEC_6_6_SystemObject bevl_nlnpn = null;
BEC_6_6_SystemObject bevl_nlc = null;
BEC_6_6_SystemObject bevl_pn = null;
BEC_6_6_SystemObject bevl_pn2 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
bevl_nlnp = (new BEC_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(630006451, BEL_4_Base.bevn_fromString_1, beva_tName);
bevl_nlnpn = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_5_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_5_tmpvar_phold);
bevl_nlnpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlnp);
bevl_nlnpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_nlc = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(3, bels_0));
bevl_nlc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1580478063, BEL_4_Base.bevn_isLiteralSet_1, bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_11_tmpvar_phold);
beva_node.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nlnpn);
bevt_12_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_12_tmpvar_phold);
beva_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlc);
bevl_nlnpn.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(8, bels_1));
bevt_13_tmpvar_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_16_tmpvar_phold = (new BEC_4_6_TextString(10, bels_2));
bevt_15_tmpvar_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevl_pn = beva_node.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_19_tmpvar_phold = bevl_pn.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_20_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_20_tmpvar_phold);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_22_tmpvar_phold = bevl_pn.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_23_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_23_tmpvar_phold);
if (bevt_21_tmpvar_phold != null && bevt_21_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_21_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevl_pn2 = bevl_pn.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn2 == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_26_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_27_tmpvar_phold);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_29_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_30_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_30_tmpvar_phold);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
 else  /* Line: 55 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_32_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_33_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
 else  /* Line: 55 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_35_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_36_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_36_tmpvar_phold);
if (bevt_34_tmpvar_phold != null && bevt_34_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_34_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
 else  /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_38_tmpvar_phold = bevl_pn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_39_tmpvar_phold = bevl_nlc.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_39_tmpvar_phold);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_37_tmpvar_phold);
bevl_pn.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 62 */
} /* Line: 55 */
} /* Line: 53 */
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_np = null;
BEC_6_6_SystemObject bevl_toremove = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_ii = null;
BEC_6_6_SystemObject bevl_nnode = null;
BEC_6_6_SystemObject bevl_dnode = null;
BEC_5_4_BuildNode bevl_onode = null;
BEC_6_6_SystemObject bevl_pc = null;
BEC_6_6_SystemObject bevl_gc = null;
BEC_5_8_BuildNamePath bevl_namepath = null;
BEC_6_6_SystemObject bevl_pnode = null;
BEC_6_6_SystemObject bevl_ponode = null;
BEC_6_6_SystemObject bevl_ga = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_62_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_96_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_97_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_98_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_104_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_105_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_114_tmpvar_phold = null;
BEC_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_116_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_4_3_MathInt bevt_119_tmpvar_phold = null;
BEC_4_3_MathInt bevt_120_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_122_tmpvar_phold = null;
BEC_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_124_tmpvar_phold = null;
BEC_4_3_MathInt bevt_125_tmpvar_phold = null;
BEC_4_3_MathInt bevt_126_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_127_tmpvar_phold = null;
BEC_4_6_TextString bevt_128_tmpvar_phold = null;
BEC_4_3_MathInt bevt_129_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_130_tmpvar_phold = null;
BEC_4_3_MathInt bevt_131_tmpvar_phold = null;
BEC_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_133_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_134_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_135_tmpvar_phold = null;
BEC_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_137_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_138_tmpvar_phold = null;
BEC_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_140_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_4_3_MathInt bevt_143_tmpvar_phold = null;
BEC_4_3_MathInt bevt_144_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_146_tmpvar_phold = null;
BEC_4_3_MathInt bevt_147_tmpvar_phold = null;
BEC_4_3_MathInt bevt_148_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_149_tmpvar_phold = null;
BEC_4_3_MathInt bevt_150_tmpvar_phold = null;
BEC_4_3_MathInt bevt_151_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_152_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_155_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_4_3_MathInt bevt_158_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_159_tmpvar_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_5_8_BuildNamePath) bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_13_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevp_inFile = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 93 */
if (bevp_inClassNp == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 95 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 97 */
bevt_16_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpvar_phold = bevp_ntypes.bem_INTLGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_equals_1(bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(8, bels_3));
this.bem_buildLiteral_2(beva_node, bevt_18_tmpvar_phold);
} /* Line: 100 */
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_FLOATLGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 102 */ {
bevt_22_tmpvar_phold = (new BEC_4_6_TextString(10, bels_4));
this.bem_buildLiteral_2(beva_node, bevt_22_tmpvar_phold);
} /* Line: 103 */
bevt_24_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_equals_1(bevt_25_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 105 */ {
bevt_26_tmpvar_phold = (new BEC_4_6_TextString(11, bels_5));
this.bem_buildLiteral_2(beva_node, bevt_26_tmpvar_phold);
} /* Line: 106 */
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_WSTRINGLGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_equals_1(bevt_29_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 108 */ {
bevt_30_tmpvar_phold = (new BEC_4_6_TextString(11, bels_6));
this.bem_buildLiteral_2(beva_node, bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpvar_phold);
} /* Line: 111 */
bevt_33_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_equals_1(bevt_34_tmpvar_phold);
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevt_35_tmpvar_phold = (new BEC_4_6_TextString(4, bels_7));
beva_node.bem_heldSet_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (new BEC_4_6_TextString(10, bels_8));
this.bem_buildLiteral_2(beva_node, bevt_36_tmpvar_phold);
} /* Line: 115 */
bevt_38_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_equals_1(bevt_39_tmpvar_phold);
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_40_tmpvar_phold = (new BEC_4_6_TextString(5, bels_9));
beva_node.bem_heldSet_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = (new BEC_4_6_TextString(10, bels_10));
this.bem_buildLiteral_2(beva_node, bevt_41_tmpvar_phold);
} /* Line: 123 */
 else  /* Line: 121 */ {
bevt_43_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_equals_1(bevt_44_tmpvar_phold);
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 125 */ {
bevt_47_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(1869307931, BEL_4_Base.bevn_isArgGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 125 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 125 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 125 */
 else  /* Line: 125 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 125 */ {
bevt_50_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
if (bevt_49_tmpvar_phold == null) {
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 126 */ {
if (bevl_nnode == null) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_53_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_54_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_54_tmpvar_phold);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
 else  /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 126 */ {
bevt_57_tmpvar_phold = bevo_0;
bevt_59_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_55_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_55_tmpvar_phold);
} /* Line: 127 */
 else  /* Line: 128 */ {
bevt_60_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_61_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_61_tmpvar_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_62_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpvar_phold;
} /* Line: 135 */
} /* Line: 126 */
 else  /* Line: 121 */ {
bevt_64_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_equals_1(bevt_65_tmpvar_phold);
if (bevt_63_tmpvar_phold.bevi_bool) /* Line: 137 */ {
if (bevl_nnode == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 138 */ {
bevt_68_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_69_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
 else  /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevt_71_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_71_tmpvar_phold == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 139 */ {
bevl_toremove = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_72_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 141 */ {
bevt_73_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_75_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_74_tmpvar_phold != null && bevt_74_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_74_tmpvar_phold).bevi_bool) /* Line: 143 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 144 */
} /* Line: 143 */
 else  /* Line: 141 */ {
break;
} /* Line: 141 */
} /* Line: 141 */
bevl_ii = bevl_toremove.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 147 */ {
bevt_77_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_77_tmpvar_phold != null && bevt_77_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_77_tmpvar_phold).bevi_bool) /* Line: 147 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 149 */
 else  /* Line: 147 */ {
break;
} /* Line: 147 */
} /* Line: 147 */
} /* Line: 147 */
bevl_pc = bevl_nnode;
bevt_78_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpvar_phold);
bevl_gc = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_79_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_79_tmpvar_phold);
bevl_pc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 160 */ {
bevt_82_tmpvar_phold = bevl_dnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_83_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_83_tmpvar_phold);
if (bevt_81_tmpvar_phold != null && bevt_81_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_81_tmpvar_phold).bevi_bool) /* Line: 160 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 160 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 160 */
 else  /* Line: 160 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 160 */ {
bevl_onode = (BEC_5_4_BuildNode) bevl_dnode.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_onode == null) {
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpvar_phold.bevi_bool) /* Line: 162 */ {
bevt_86_tmpvar_phold = (new BEC_4_6_TextString(38, bels_12));
bevt_85_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_85_tmpvar_phold);
} /* Line: 163 */
 else  /* Line: 162 */ {
bevt_88_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bem_equals_1(bevt_89_tmpvar_phold);
if (bevt_87_tmpvar_phold.bevi_bool) /* Line: 164 */ {
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_92_tmpvar_phold);
} /* Line: 168 */
 else  /* Line: 162 */ {
bevt_94_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_95_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_93_tmpvar_phold = bevt_94_tmpvar_phold.bem_equals_1(bevt_95_tmpvar_phold);
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevt_99_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_98_tmpvar_phold = bevt_99_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_100_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_96_tmpvar_phold = bevt_97_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_100_tmpvar_phold);
if (bevt_96_tmpvar_phold != null && bevt_96_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_96_tmpvar_phold).bevi_bool) /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 172 */
 else  /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 172 */ {
bevl_namepath = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_101_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_101_tmpvar_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_102_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_102_tmpvar_phold);
bevl_onode.bem_resolveNp_0();
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_103_tmpvar_phold);
bevt_104_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_104_tmpvar_phold);
bevt_105_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_105_tmpvar_phold);
} /* Line: 181 */
 else  /* Line: 162 */ {
bevt_107_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_108_tmpvar_phold = (new BEC_4_6_TextString(6, bels_13));
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_108_tmpvar_phold);
if (bevt_106_tmpvar_phold != null && bevt_106_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_106_tmpvar_phold).bevi_bool) /* Line: 185 */ {
bevt_110_tmpvar_phold = (new BEC_4_6_TextString(70, bels_14));
bevt_109_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_110_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_109_tmpvar_phold);
} /* Line: 186 */
 else  /* Line: 162 */ {
bevt_112_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_113_tmpvar_phold = (new BEC_4_6_TextString(5, bels_15));
bevt_111_tmpvar_phold = bevt_112_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_113_tmpvar_phold);
if (bevt_111_tmpvar_phold != null && bevt_111_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_111_tmpvar_phold).bevi_bool) /* Line: 187 */ {
bevt_115_tmpvar_phold = (new BEC_4_6_TextString(65, bels_16));
bevt_114_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_115_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_114_tmpvar_phold);
} /* Line: 188 */
} /* Line: 162 */
} /* Line: 162 */
} /* Line: 162 */
} /* Line: 162 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_onode);
bevl_dnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 193 */
 else  /* Line: 194 */ {
bevt_116_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_116_tmpvar_phold);
bevt_117_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_117_tmpvar_phold);
} /* Line: 196 */
} /* Line: 160 */
} /* Line: 138 */
 else  /* Line: 121 */ {
bevt_119_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_120_tmpvar_phold = bevp_ntypes.bem_IDXGet_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bem_equals_1(bevt_120_tmpvar_phold);
if (bevt_118_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_123_tmpvar_phold = (new BEC_4_6_TextString(34, bels_17));
bevt_122_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_123_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_122_tmpvar_phold);
} /* Line: 205 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_125_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_126_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bem_equals_1(bevt_126_tmpvar_phold);
if (bevt_124_tmpvar_phold.bevi_bool) /* Line: 209 */ {
bevt_128_tmpvar_phold = (new BEC_4_6_TextString(84, bels_18));
bevt_127_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_128_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_127_tmpvar_phold);
} /* Line: 210 */
bevt_129_tmpvar_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_129_tmpvar_phold);
} /* Line: 212 */
 else  /* Line: 121 */ {
bevt_131_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_132_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
bevt_130_tmpvar_phold = bevt_131_tmpvar_phold.bem_equals_1(bevt_132_tmpvar_phold);
if (bevt_130_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_133_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_133_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_133_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
if (bevl_onode == null) {
bevt_134_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_134_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_134_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 218 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 218 */ {
bevt_136_tmpvar_phold = (new BEC_4_6_TextString(34, bels_19));
bevt_135_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_136_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_135_tmpvar_phold);
} /* Line: 219 */
bevt_138_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_139_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_137_tmpvar_phold = bevt_138_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_139_tmpvar_phold);
if (bevt_137_tmpvar_phold != null && bevt_137_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_137_tmpvar_phold).bevi_bool) /* Line: 221 */ {
bevl_pnode = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_pnode == null) {
bevt_140_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_140_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_140_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_142_tmpvar_phold = bevl_pnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_143_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_141_tmpvar_phold = bevt_142_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_143_tmpvar_phold);
if (bevt_141_tmpvar_phold != null && bevt_141_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_141_tmpvar_phold).bevi_bool) /* Line: 223 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 223 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 223 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_144_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_144_tmpvar_phold);
bevl_ga = (new BEC_5_8_BuildAccessor()).bem_new_0();
bevt_145_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_ga.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_145_tmpvar_phold);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_147_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_148_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_146_tmpvar_phold = bevt_147_tmpvar_phold.bem_equals_1(bevt_148_tmpvar_phold);
if (bevt_146_tmpvar_phold.bevi_bool) /* Line: 232 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 233 */
 else  /* Line: 232 */ {
bevt_150_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_151_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_149_tmpvar_phold = bevt_150_tmpvar_phold.bem_equals_1(bevt_151_tmpvar_phold);
if (bevt_149_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_155_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_154_tmpvar_phold = bevt_155_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_156_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_152_tmpvar_phold = bevt_153_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_156_tmpvar_phold);
if (bevt_152_tmpvar_phold != null && bevt_152_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_152_tmpvar_phold).bevi_bool) /* Line: 234 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 234 */ {
bevl_namepath = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_157_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_157_tmpvar_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_158_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_158_tmpvar_phold);
bevl_onode.bem_resolveNp_0();
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 240 */
} /* Line: 232 */
} /* Line: 232 */
} /* Line: 223 */
} /* Line: 221 */
} /* Line: 121 */
} /* Line: 121 */
} /* Line: 121 */
} /* Line: 121 */
bevt_159_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_159_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_createImpliedConstruct_2(BEC_5_4_BuildNode beva_onode, BEC_6_6_SystemObject beva_gc) throws Throwable {
BEC_5_4_BuildNode bevl_npcnode = null;
BEC_5_4_BuildCall bevl_gnc = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
bevl_npcnode = (BEC_5_4_BuildNode) (new BEC_5_4_BuildNode()).bem_new_0();
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpvar_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(3, bels_20));
bevl_gnc.bem_nameSet_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpvar_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpvar_phold);
return this;
} /*method end*/
public BEC_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_6_6_SystemObject bem_inFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inFile = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {28, 29, 31, 32, 32, 33, 34, 36, 37, 37, 38, 38, 39, 39, 40, 40, 41, 41, 42, 42, 44, 46, 46, 47, 49, 51, 51, 0, 51, 51, 0, 0, 52, 53, 53, 53, 53, 53, 0, 53, 53, 53, 0, 0, 0, 0, 0, 54, 55, 55, 0, 55, 55, 55, 55, 55, 55, 0, 0, 0, 55, 55, 55, 0, 0, 0, 55, 55, 55, 0, 0, 0, 0, 0, 61, 61, 61, 61, 62, 88, 91, 91, 91, 92, 92, 93, 93, 93, 95, 95, 96, 97, 99, 99, 99, 100, 100, 102, 102, 102, 103, 103, 105, 105, 105, 106, 106, 108, 108, 108, 110, 110, 111, 111, 113, 113, 113, 114, 114, 115, 115, 121, 121, 121, 122, 122, 123, 123, 125, 125, 125, 125, 125, 125, 0, 0, 0, 126, 126, 126, 126, 126, 126, 0, 126, 126, 126, 0, 0, 0, 0, 0, 127, 127, 127, 127, 127, 127, 129, 129, 129, 130, 131, 135, 135, 137, 137, 137, 138, 138, 138, 138, 138, 0, 0, 0, 139, 139, 139, 140, 141, 141, 141, 142, 143, 143, 143, 144, 147, 147, 148, 149, 152, 153, 153, 154, 155, 155, 156, 157, 158, 159, 160, 160, 160, 160, 160, 0, 0, 0, 161, 162, 162, 163, 163, 163, 164, 164, 164, 166, 166, 167, 167, 168, 168, 172, 172, 172, 172, 172, 172, 172, 172, 0, 0, 0, 173, 174, 174, 175, 176, 176, 177, 179, 179, 180, 180, 181, 181, 185, 185, 185, 186, 186, 186, 187, 187, 187, 188, 188, 188, 191, 192, 193, 195, 195, 196, 196, 200, 200, 200, 203, 204, 204, 205, 205, 205, 207, 208, 209, 209, 209, 210, 210, 210, 212, 212, 213, 213, 213, 215, 218, 218, 0, 218, 218, 0, 0, 219, 219, 219, 221, 221, 221, 222, 223, 223, 0, 223, 223, 223, 0, 0, 224, 225, 225, 226, 227, 227, 228, 229, 230, 231, 232, 232, 232, 233, 234, 234, 234, 234, 234, 234, 234, 234, 0, 0, 0, 235, 236, 236, 237, 238, 238, 239, 240, 245, 245, 249, 250, 251, 251, 252, 252, 253, 255, 256, 256, 257, 257, 258, 258, 259, 259, 260, 260, 261, 262, 262, 0, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 109, 112, 113, 115, 118, 122, 123, 128, 129, 130, 131, 133, 136, 137, 138, 140, 143, 147, 150, 154, 157, 158, 163, 164, 167, 168, 169, 171, 172, 173, 175, 178, 182, 185, 186, 187, 189, 192, 196, 199, 200, 201, 203, 206, 210, 213, 216, 220, 221, 222, 223, 224, 405, 406, 407, 408, 410, 411, 412, 413, 414, 416, 421, 422, 423, 425, 426, 427, 429, 430, 432, 433, 434, 436, 437, 439, 440, 441, 443, 444, 446, 447, 448, 450, 451, 452, 453, 455, 456, 457, 459, 460, 461, 462, 464, 465, 466, 468, 469, 470, 471, 474, 475, 476, 478, 479, 480, 482, 485, 489, 492, 493, 494, 499, 500, 505, 506, 509, 510, 511, 513, 516, 520, 523, 527, 530, 531, 532, 533, 534, 535, 538, 539, 540, 541, 542, 543, 544, 548, 549, 550, 552, 557, 558, 559, 560, 562, 565, 569, 572, 573, 578, 579, 580, 581, 584, 586, 587, 588, 589, 591, 598, 601, 603, 604, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 626, 627, 628, 629, 631, 634, 638, 641, 642, 647, 648, 649, 650, 653, 654, 655, 657, 658, 659, 660, 661, 662, 665, 666, 667, 669, 670, 671, 672, 673, 675, 678, 682, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 700, 701, 702, 704, 705, 706, 709, 710, 711, 713, 714, 715, 721, 722, 723, 726, 727, 728, 729, 734, 735, 736, 738, 739, 744, 745, 746, 747, 749, 750, 751, 752, 753, 755, 756, 757, 759, 760, 763, 764, 765, 767, 768, 773, 774, 777, 782, 783, 786, 790, 791, 792, 794, 795, 796, 798, 799, 804, 805, 808, 809, 810, 812, 815, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 833, 836, 837, 838, 840, 841, 842, 843, 844, 846, 849, 853, 856, 857, 858, 859, 860, 861, 862, 863, 873, 874, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 911, 914, 918, 921};
/* BEGIN LINEINFO 
assign 1 28 81
new 0 28 81
fromString 1 29 82
assign 1 31 83
new 1 31 83
assign 1 32 84
NAMEPATHGet 0 32 84
typenameSet 1 32 85
heldSet 1 33 86
copyLoc 1 34 87
assign 1 36 88
new 0 36 88
assign 1 37 89
new 0 37 89
nameSet 1 37 90
assign 1 38 91
new 0 38 91
wasBoundSet 1 38 92
assign 1 39 93
new 0 39 93
boundSet 1 39 94
assign 1 40 95
new 0 40 95
isConstructSet 1 40 96
assign 1 41 97
new 0 41 97
isLiteralSet 1 41 98
assign 1 42 99
heldGet 0 42 99
literalValueSet 1 42 100
addValue 1 44 101
assign 1 46 102
CALLGet 0 46 102
typenameSet 1 46 103
heldSet 1 47 104
resolveNp 0 49 105
assign 1 51 106
new 0 51 106
assign 1 51 107
equals 1 51 107
assign 1 0 109
assign 1 51 112
new 0 51 112
assign 1 51 113
equals 1 51 113
assign 1 0 115
assign 1 0 118
assign 1 52 122
priorPeerGet 0 52 122
assign 1 53 123
def 1 53 128
assign 1 53 129
typenameGet 0 53 129
assign 1 53 130
SUBTRACTGet 0 53 130
assign 1 53 131
equals 1 53 131
assign 1 0 133
assign 1 53 136
typenameGet 0 53 136
assign 1 53 137
ADDGet 0 53 137
assign 1 53 138
equals 1 53 138
assign 1 0 140
assign 1 0 143
assign 1 0 147
assign 1 0 150
assign 1 0 154
assign 1 54 157
priorPeerGet 0 54 157
assign 1 55 158
undef 1 55 163
assign 1 0 164
assign 1 55 167
typenameGet 0 55 167
assign 1 55 168
CALLGet 0 55 168
assign 1 55 169
notEquals 1 55 169
assign 1 55 171
typenameGet 0 55 171
assign 1 55 172
IDGet 0 55 172
assign 1 55 173
notEquals 1 55 173
assign 1 0 175
assign 1 0 178
assign 1 0 182
assign 1 55 185
typenameGet 0 55 185
assign 1 55 186
VARGet 0 55 186
assign 1 55 187
notEquals 1 55 187
assign 1 0 189
assign 1 0 192
assign 1 0 196
assign 1 55 199
typenameGet 0 55 199
assign 1 55 200
ACCESSORGet 0 55 200
assign 1 55 201
notEquals 1 55 201
assign 1 0 203
assign 1 0 206
assign 1 0 210
assign 1 0 213
assign 1 0 216
assign 1 61 220
heldGet 0 61 220
assign 1 61 221
literalValueGet 0 61 221
assign 1 61 222
add 1 61 222
literalValueSet 1 61 223
delete 0 62 224
assign 1 88 405
nextPeerGet 0 88 405
assign 1 91 406
typenameGet 0 91 406
assign 1 91 407
CLASSGet 0 91 407
assign 1 91 408
equals 1 91 408
assign 1 92 410
heldGet 0 92 410
assign 1 92 411
namepathGet 0 92 411
assign 1 93 412
heldGet 0 93 412
assign 1 93 413
fromFileGet 0 93 413
assign 1 93 414
toString 0 93 414
assign 1 95 416
def 1 95 421
inClassNpSet 1 96 422
inFileSet 1 97 423
assign 1 99 425
typenameGet 0 99 425
assign 1 99 426
INTLGet 0 99 426
assign 1 99 427
equals 1 99 427
assign 1 100 429
new 0 100 429
buildLiteral 2 100 430
assign 1 102 432
typenameGet 0 102 432
assign 1 102 433
FLOATLGet 0 102 433
assign 1 102 434
equals 1 102 434
assign 1 103 436
new 0 103 436
buildLiteral 2 103 437
assign 1 105 439
typenameGet 0 105 439
assign 1 105 440
STRINGLGet 0 105 440
assign 1 105 441
equals 1 105 441
assign 1 106 443
new 0 106 443
buildLiteral 2 106 444
assign 1 108 446
typenameGet 0 108 446
assign 1 108 447
WSTRINGLGet 0 108 447
assign 1 108 448
equals 1 108 448
assign 1 110 450
new 0 110 450
buildLiteral 2 110 451
assign 1 111 452
new 0 111 452
wideStringSet 1 111 453
assign 1 113 455
typenameGet 0 113 455
assign 1 113 456
TRUEGet 0 113 456
assign 1 113 457
equals 1 113 457
assign 1 114 459
new 0 114 459
heldSet 1 114 460
assign 1 115 461
new 0 115 461
buildLiteral 2 115 462
assign 1 121 464
typenameGet 0 121 464
assign 1 121 465
FALSEGet 0 121 465
assign 1 121 466
equals 1 121 466
assign 1 122 468
new 0 122 468
heldSet 1 122 469
assign 1 123 470
new 0 123 470
buildLiteral 2 123 471
assign 1 125 474
typenameGet 0 125 474
assign 1 125 475
VARGet 0 125 475
assign 1 125 476
equals 1 125 476
assign 1 125 478
heldGet 0 125 478
assign 1 125 479
isArgGet 0 125 479
assign 1 125 480
not 0 125 480
assign 1 0 482
assign 1 0 485
assign 1 0 489
assign 1 126 492
heldGet 0 126 492
assign 1 126 493
nameGet 0 126 493
assign 1 126 494
undef 1 126 499
assign 1 126 500
undef 1 126 505
assign 1 0 506
assign 1 126 509
typenameGet 0 126 509
assign 1 126 510
IDGet 0 126 510
assign 1 126 511
notEquals 1 126 511
assign 1 0 513
assign 1 0 516
assign 1 0 520
assign 1 0 523
assign 1 0 527
assign 1 127 530
new 0 127 530
assign 1 127 531
heldGet 0 127 531
assign 1 127 532
nameGet 0 127 532
assign 1 127 533
add 1 127 533
assign 1 127 534
new 2 127 534
throw 1 127 535
assign 1 129 538
heldGet 0 129 538
assign 1 129 539
heldGet 0 129 539
nameSet 1 129 540
addVariable 0 130 541
delete 0 131 542
assign 1 135 543
nextDescendGet 0 135 543
return 1 135 544
assign 1 137 548
typenameGet 0 137 548
assign 1 137 549
IDGet 0 137 549
assign 1 137 550
equals 1 137 550
assign 1 138 552
def 1 138 557
assign 1 138 558
typenameGet 0 138 558
assign 1 138 559
PARENSGet 0 138 559
assign 1 138 560
equals 1 138 560
assign 1 0 562
assign 1 0 565
assign 1 0 569
assign 1 139 572
containedGet 0 139 572
assign 1 139 573
def 1 139 578
assign 1 140 579
new 0 140 579
assign 1 141 580
containedGet 0 141 580
assign 1 141 581
iteratorGet 0 141 581
assign 1 141 584
hasNextGet 0 141 584
assign 1 142 586
nextGet 0 142 586
assign 1 143 587
typenameGet 0 143 587
assign 1 143 588
COMMAGet 0 143 588
assign 1 143 589
equals 1 143 589
addValue 1 144 591
assign 1 147 598
iteratorGet 0 147 598
assign 1 147 601
hasNextGet 0 147 601
assign 1 148 603
nextGet 0 148 603
delete 0 149 604
assign 1 152 611
assign 1 153 612
CALLGet 0 153 612
typenameSet 1 153 613
assign 1 154 614
new 0 154 614
assign 1 155 615
heldGet 0 155 615
nameSet 1 155 616
heldSet 1 156 617
delete 0 157 618
assign 1 158 619
assign 1 159 620
priorPeerGet 0 159 620
assign 1 160 621
def 1 160 626
assign 1 160 627
typenameGet 0 160 627
assign 1 160 628
DOTGet 0 160 628
assign 1 160 629
equals 1 160 629
assign 1 0 631
assign 1 0 634
assign 1 0 638
assign 1 161 641
priorPeerGet 0 161 641
assign 1 162 642
undef 1 162 647
assign 1 163 648
new 0 163 648
assign 1 163 649
new 2 163 649
throw 1 163 650
assign 1 164 653
typenameGet 0 164 653
assign 1 164 654
NAMEPATHGet 0 164 654
assign 1 164 655
equals 1 164 655
assign 1 166 657
new 0 166 657
wasBoundSet 1 166 658
assign 1 167 659
new 0 167 659
boundSet 1 167 660
assign 1 168 661
new 0 168 661
isConstructSet 1 168 662
assign 1 172 665
typenameGet 0 172 665
assign 1 172 666
IDGet 0 172 666
assign 1 172 667
equals 1 172 667
assign 1 172 669
transUnitGet 0 172 669
assign 1 172 670
heldGet 0 172 670
assign 1 172 671
aliasedGet 0 172 671
assign 1 172 672
heldGet 0 172 672
assign 1 172 673
has 1 172 673
assign 1 0 675
assign 1 0 678
assign 1 0 682
assign 1 173 685
new 0 173 685
assign 1 174 686
heldGet 0 174 686
addStep 1 174 687
heldSet 1 175 688
assign 1 176 689
NAMEPATHGet 0 176 689
typenameSet 1 176 690
resolveNp 0 177 691
assign 1 179 692
new 0 179 692
wasBoundSet 1 179 693
assign 1 180 694
new 0 180 694
boundSet 1 180 695
assign 1 181 696
new 0 181 696
isConstructSet 1 181 697
assign 1 185 700
nameGet 0 185 700
assign 1 185 701
new 0 185 701
assign 1 185 702
equals 1 185 702
assign 1 186 704
new 0 186 704
assign 1 186 705
new 2 186 705
throw 1 186 706
assign 1 187 709
nameGet 0 187 709
assign 1 187 710
new 0 187 710
assign 1 187 711
equals 1 187 711
assign 1 188 713
new 0 188 713
assign 1 188 714
new 2 188 714
throw 1 188 715
delete 0 191 721
prepend 1 192 722
delete 0 193 723
assign 1 195 726
new 0 195 726
boundSet 1 195 727
assign 1 196 728
new 0 196 728
wasBoundSet 1 196 729
assign 1 200 734
typenameGet 0 200 734
assign 1 200 735
IDXGet 0 200 735
assign 1 200 736
equals 1 200 736
assign 1 203 738
priorPeerGet 0 203 738
assign 1 204 739
undef 1 204 744
assign 1 205 745
new 0 205 745
assign 1 205 746
new 2 205 746
throw 1 205 747
delete 0 207 749
prepend 1 208 750
assign 1 209 751
typenameGet 0 209 751
assign 1 209 752
NAMEPATHGet 0 209 752
assign 1 209 753
equals 1 209 753
assign 1 210 755
new 0 210 755
assign 1 210 756
new 2 210 756
throw 1 210 757
assign 1 212 759
IDXACCGet 0 212 759
typenameSet 1 212 760
assign 1 213 763
typenameGet 0 213 763
assign 1 213 764
DOTGet 0 213 764
assign 1 213 765
equals 1 213 765
assign 1 215 767
priorPeerGet 0 215 767
assign 1 218 768
undef 1 218 773
assign 1 0 774
assign 1 218 777
undef 1 218 782
assign 1 0 783
assign 1 0 786
assign 1 219 790
new 0 219 790
assign 1 219 791
new 2 219 791
throw 1 219 792
assign 1 221 794
typenameGet 0 221 794
assign 1 221 795
IDGet 0 221 795
assign 1 221 796
equals 1 221 796
assign 1 222 798
nextPeerGet 0 222 798
assign 1 223 799
undef 1 223 804
assign 1 0 805
assign 1 223 808
typenameGet 0 223 808
assign 1 223 809
PARENSGet 0 223 809
assign 1 223 810
notEquals 1 223 810
assign 1 0 812
assign 1 0 815
assign 1 224 819
priorPeerGet 0 224 819
assign 1 225 820
ACCESSORGet 0 225 820
typenameSet 1 225 821
assign 1 226 822
new 0 226 822
assign 1 227 823
heldGet 0 227 823
nameSet 1 227 824
delete 0 228 825
delete 0 229 826
heldSet 1 230 827
addValue 1 231 828
assign 1 232 829
typenameGet 0 232 829
assign 1 232 830
NAMEPATHGet 0 232 830
assign 1 232 831
equals 1 232 831
createImpliedConstruct 2 233 833
assign 1 234 836
typenameGet 0 234 836
assign 1 234 837
IDGet 0 234 837
assign 1 234 838
equals 1 234 838
assign 1 234 840
transUnitGet 0 234 840
assign 1 234 841
heldGet 0 234 841
assign 1 234 842
aliasedGet 0 234 842
assign 1 234 843
heldGet 0 234 843
assign 1 234 844
has 1 234 844
assign 1 0 846
assign 1 0 849
assign 1 0 853
assign 1 235 856
new 0 235 856
assign 1 236 857
heldGet 0 236 857
addStep 1 236 858
heldSet 1 237 859
assign 1 238 860
NAMEPATHGet 0 238 860
typenameSet 1 238 861
resolveNp 0 239 862
createImpliedConstruct 2 240 863
assign 1 245 873
nextDescendGet 0 245 873
return 1 245 874
assign 1 249 887
new 0 249 887
heldSet 1 250 888
assign 1 251 889
NAMEPATHGet 0 251 889
typenameSet 1 251 890
assign 1 252 891
heldGet 0 252 891
heldSet 1 252 892
prepend 1 253 893
assign 1 255 894
new 0 255 894
assign 1 256 895
new 0 256 895
nameSet 1 256 896
assign 1 257 897
new 0 257 897
wasBoundSet 1 257 898
assign 1 258 899
new 0 258 899
boundSet 1 258 900
assign 1 259 901
new 0 259 901
isConstructSet 1 259 902
assign 1 260 903
new 0 260 903
wasImpliedConstructSet 1 260 904
heldSet 1 261 905
assign 1 262 906
CALLGet 0 262 906
typenameSet 1 262 907
return 1 0 911
assign 1 0 914
return 1 0 918
assign 1 0 921
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 822104518: return bem_inFileGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 856627742: return bem_createImpliedConstruct_2((BEC_5_4_BuildNode) bevd_0, bevd_1);
case 681472468: return bem_buildLiteral_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_5_BuildVisitPass7();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_5_BuildVisitPass7.bevs_inst = (BEC_5_5_5_BuildVisitPass7)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_5_BuildVisitPass7.bevs_inst;
}
}
