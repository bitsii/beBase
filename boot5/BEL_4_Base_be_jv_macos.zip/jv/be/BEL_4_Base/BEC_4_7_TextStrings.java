package be.BEL_4_Base;
/* File: source/base/String.be */
public class BEC_4_7_TextStrings extends BEC_6_6_SystemObject {
public BEC_4_7_TextStrings() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static byte[] bels_1 = {0x0D,0x0A};
private static byte[] bels_2 = {0x0A};
private static byte[] bels_3 = {0x0A};
private static byte[] bels_4 = {0x3A};
private static byte[] bels_5 = {};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(1));
private static byte[] bels_6 = {};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_6, 0));
public static BEC_4_7_TextStrings bevs_inst;
public BEC_4_6_TextString bevp_space;
public BEC_4_6_TextString bevp_empty;
public BEC_4_6_TextString bevp_quote;
public BEC_4_6_TextString bevp_tab;
public BEC_4_6_TextString bevp_dosNewline;
public BEC_4_6_TextString bevp_unixNewline;
public BEC_4_6_TextString bevp_newline;
public BEC_4_6_TextString bevp_cr;
public BEC_4_6_TextString bevp_lf;
public BEC_4_6_TextString bevp_colon;
public BEC_4_9_TextTokenizer bevp_lineSplitter;
public BEC_9_3_ContainerSet bevp_ws;
public BEC_6_6_SystemObject bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_7_TextStrings bem_default_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevp_space = (new BEC_4_6_TextString(1, bels_0));
bevp_empty = (new BEC_4_6_TextString()).bem_new_0();
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(34));
bevp_quote = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(9));
bevp_tab = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_1_tmpvar_phold);
bevp_dosNewline = (new BEC_4_6_TextString(2, bels_1));
bevp_unixNewline = (new BEC_4_6_TextString(1, bels_2));
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(13));
bevp_cr = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_2_tmpvar_phold);
bevp_lf = (new BEC_4_6_TextString(1, bels_3));
bevp_colon = (new BEC_4_6_TextString(1, bels_4));
bevp_lineSplitter = (new BEC_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_4_6_TextString bem_join_2(BEC_4_6_TextString beva_delim, BEC_6_6_SystemObject beva_splits) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_joinBuffer_2(beva_delim, beva_splits);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_extractString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_joinBuffer_2(BEC_4_6_TextString beva_delim, BEC_6_6_SystemObject beva_splits) throws Throwable {
BEC_6_6_SystemObject bevl_i = null;
BEC_4_6_TextString bevl_buf = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_i = beva_splits.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1177 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
return bevt_2_tmpvar_phold;
} /* Line: 1178 */
bevl_buf = (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_buf.bem_addValue_1(bevt_3_tmpvar_phold);
while (true)
 /* Line: 1182 */ {
bevt_4_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 1182 */ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_buf.bem_addValue_1(bevt_5_tmpvar_phold);
} /* Line: 1184 */
 else  /* Line: 1182 */ {
break;
} /* Line: 1182 */
} /* Line: 1182 */
return bevl_buf;
} /*method end*/
public BEC_6_6_SystemObject bem_strip_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevl_beg = null;
BEC_4_3_MathInt bevl_end = null;
BEC_5_4_LogicBool bevl_foundChar = null;
BEC_4_17_TextMultiByteIterator bevl_mb = null;
BEC_4_6_TextString bevl_step = null;
BEC_4_6_TextString bevl_toRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevl_beg = (new BEC_4_3_MathInt(0));
bevl_end = (new BEC_4_3_MathInt(0));
bevl_foundChar = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
 /* Line: 1194 */ {
bevt_0_tmpvar_phold = bevl_mb.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1194 */ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_tmpvar_phold = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1196 */ {
if (bevl_foundChar.bevi_bool) /* Line: 1197 */ {
bevl_end = bevl_end.bem_increment_0();
} /* Line: 1198 */
 else  /* Line: 1199 */ {
bevl_beg = bevl_beg.bem_increment_0();
} /* Line: 1200 */
} /* Line: 1197 */
 else  /* Line: 1202 */ {
bevl_end = (new BEC_4_3_MathInt(0));
bevl_foundChar = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1204 */
} /* Line: 1196 */
 else  /* Line: 1194 */ {
break;
} /* Line: 1194 */
} /* Line: 1194 */
if (bevl_foundChar.bevi_bool) /* Line: 1207 */ {
bevt_3_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_2_tmpvar_phold);
} /* Line: 1208 */
 else  /* Line: 1209 */ {
bevl_toRet = (new BEC_4_6_TextString(0, bels_5));
} /* Line: 1210 */
return bevl_toRet;
} /*method end*/
public BEC_4_6_TextString bem_commonPrefix_2(BEC_4_6_TextString beva_a, BEC_4_6_TextString beva_b) throws Throwable {
BEC_4_3_MathInt bevl_sz = null;
BEC_6_6_SystemObject bevl_ai = null;
BEC_6_6_SystemObject bevl_bi = null;
BEC_4_6_TextString bevl_av = null;
BEC_4_6_TextString bevl_bv = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
if (beva_a == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1216 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1216 */ {
if (beva_b == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1216 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1216 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1216 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1216 */ {
return null;
} /* Line: 1216 */
bevt_3_tmpvar_phold = beva_a.bem_sizeGet_0();
bevt_4_tmpvar_phold = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_4_3_MathInt) BEC_4_4_MathInts.bevs_inst.bem_min_2(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 1222 */ {
bevt_5_tmpvar_phold = bevl_i.bem_lesser_1(bevl_sz);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 1222 */ {
bevl_ai.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_av);
bevl_bi.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_bv);
bevt_6_tmpvar_phold = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 1225 */ {
bevt_8_tmpvar_phold = bevo_0;
bevt_7_tmpvar_phold = beva_a.bem_substring_2(bevt_8_tmpvar_phold, bevl_i);
return bevt_7_tmpvar_phold;
} /* Line: 1226 */
bevl_i.bem_incrementValue_0();
} /* Line: 1222 */
 else  /* Line: 1222 */ {
break;
} /* Line: 1222 */
} /* Line: 1222 */
bevt_10_tmpvar_phold = bevo_1;
bevt_9_tmpvar_phold = beva_a.bem_substring_2(bevt_10_tmpvar_phold, bevl_i);
return bevt_9_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_anyEmpty_1(BEC_6_6_SystemObject beva_strs) throws Throwable {
BEC_4_6_TextString bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_loop = beva_strs.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 1233 */ {
bevt_1_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 1233 */ {
bevl_i = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = this.bem_isEmpty_1(bevl_i);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1234 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /* Line: 1235 */
} /* Line: 1234 */
 else  /* Line: 1233 */ {
break;
} /* Line: 1233 */
} /* Line: 1233 */
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isEmpty_1(BEC_4_6_TextString beva_value) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_value == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1242 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1242 */ {
bevt_3_tmpvar_phold = beva_value.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevo_2;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_lesser_1(bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1242 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1242 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1242 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1242 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /* Line: 1243 */
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_notEmpty_1(BEC_4_6_TextString beva_value) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_value == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1249 */ {
bevt_3_tmpvar_phold = bevo_3;
bevt_2_tmpvar_phold = beva_value.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1249 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1249 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1249 */
 else  /* Line: 1249 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1249 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 1250 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_6_6_SystemObject bem_spaceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_space = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_6_6_SystemObject bem_emptySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_empty = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_6_6_SystemObject bem_quoteSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_quote = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_6_6_SystemObject bem_tabSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_tab = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_6_6_SystemObject bem_dosNewlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_dosNewline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_6_6_SystemObject bem_unixNewlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_unixNewline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_6_6_SystemObject bem_newlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_6_6_SystemObject bem_crSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_cr = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_6_6_SystemObject bem_lfSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lf = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_6_6_SystemObject bem_colonSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_colon = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_lineSplitterGet_0() throws Throwable {
return bevp_lineSplitter;
} /*method end*/
public BEC_6_6_SystemObject bem_lineSplitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lineSplitter = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_wsGet_0() throws Throwable {
return bevp_ws;
} /*method end*/
public BEC_6_6_SystemObject bem_wsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ws = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {1151, 1152, 1153, 1153, 1154, 1154, 1155, 1156, 1158, 1158, 1159, 1160, 1161, 1162, 1165, 1166, 1167, 1168, 1172, 1172, 1172, 1176, 1177, 1177, 1178, 1178, 1180, 1181, 1181, 1182, 1183, 1184, 1184, 1186, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1198, 1200, 1203, 1204, 1208, 1208, 1208, 1210, 1212, 1216, 1216, 0, 1216, 1216, 0, 0, 1216, 1217, 1217, 1217, 1218, 1219, 1220, 1221, 1222, 1222, 1223, 1224, 1225, 1226, 1226, 1226, 1222, 1229, 1229, 1229, 1233, 0, 1233, 1233, 1234, 1235, 1235, 1238, 1238, 1242, 1242, 0, 1242, 1242, 1242, 0, 0, 1243, 1243, 1245, 1245, 1249, 1249, 1249, 1249, 0, 0, 0, 1250, 1250, 1252, 1252, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 61, 62, 63, 74, 75, 76, 78, 79, 81, 82, 83, 86, 88, 89, 90, 96, 109, 110, 111, 112, 115, 117, 118, 121, 124, 128, 129, 137, 138, 139, 142, 144, 164, 169, 170, 173, 178, 179, 182, 186, 188, 189, 190, 191, 192, 193, 194, 195, 198, 200, 201, 202, 204, 205, 206, 208, 214, 215, 216, 225, 225, 228, 230, 231, 233, 234, 241, 242, 252, 257, 258, 261, 262, 263, 265, 268, 272, 273, 275, 276, 285, 290, 291, 292, 294, 297, 301, 304, 305, 307, 308, 311, 314, 318, 321, 325, 328, 332, 335, 339, 342, 346, 349, 353, 356, 360, 363, 367, 370, 374, 377, 381, 384, 388, 391};
/* BEGIN LINEINFO 
assign 1 1151 38
new 0 1151 38
assign 1 1152 39
new 0 1152 39
assign 1 1153 40
new 0 1153 40
assign 1 1153 41
codeNew 1 1153 41
assign 1 1154 42
new 0 1154 42
assign 1 1154 43
codeNew 1 1154 43
assign 1 1155 44
new 0 1155 44
assign 1 1156 45
new 0 1156 45
assign 1 1158 46
new 0 1158 46
assign 1 1158 47
codeNew 1 1158 47
assign 1 1159 48
new 0 1159 48
assign 1 1160 49
new 0 1160 49
assign 1 1161 50
new 1 1161 50
assign 1 1162 51
new 0 1162 51
put 1 1165 52
put 1 1166 53
put 1 1167 54
put 1 1168 55
assign 1 1172 61
joinBuffer 2 1172 61
assign 1 1172 62
extractString 0 1172 62
return 1 1172 63
assign 1 1176 74
iteratorGet 0 1176 74
assign 1 1177 75
hasNextGet 0 1177 75
assign 1 1177 76
not 0 1177 76
assign 1 1178 78
new 0 1178 78
return 1 1178 79
assign 1 1180 81
new 0 1180 81
assign 1 1181 82
nextGet 0 1181 82
addValue 1 1181 83
assign 1 1182 86
hasNextGet 0 1182 86
addValue 1 1183 88
assign 1 1184 89
nextGet 0 1184 89
addValue 1 1184 90
return 1 1186 96
assign 1 1190 109
new 0 1190 109
assign 1 1191 110
new 0 1191 110
assign 1 1192 111
new 0 1192 111
assign 1 1193 112
mbiterGet 0 1193 112
assign 1 1194 115
hasNextGet 0 1194 115
assign 1 1195 117
nextGet 0 1195 117
assign 1 1196 118
has 1 1196 118
assign 1 1198 121
increment 0 1198 121
assign 1 1200 124
increment 0 1200 124
assign 1 1203 128
new 0 1203 128
assign 1 1204 129
new 0 1204 129
assign 1 1208 137
sizeGet 0 1208 137
assign 1 1208 138
subtract 1 1208 138
assign 1 1208 139
substring 2 1208 139
assign 1 1210 142
new 0 1210 142
return 1 1212 144
assign 1 1216 164
undef 1 1216 169
assign 1 0 170
assign 1 1216 173
undef 1 1216 178
assign 1 0 179
assign 1 0 182
return 1 1216 186
assign 1 1217 188
sizeGet 0 1217 188
assign 1 1217 189
sizeGet 0 1217 189
assign 1 1217 190
min 2 1217 190
assign 1 1218 191
biterGet 0 1218 191
assign 1 1219 192
biterGet 0 1219 192
assign 1 1220 193
new 0 1220 193
assign 1 1221 194
new 0 1221 194
assign 1 1222 195
new 0 1222 195
assign 1 1222 198
lesser 1 1222 198
next 1 1223 200
next 1 1224 201
assign 1 1225 202
notEquals 1 1225 202
assign 1 1226 204
new 0 1226 204
assign 1 1226 205
substring 2 1226 205
return 1 1226 206
incrementValue 0 1222 208
assign 1 1229 214
new 0 1229 214
assign 1 1229 215
substring 2 1229 215
return 1 1229 216
assign 1 1233 225
iteratorGet 0 0 225
assign 1 1233 228
hasNextGet 0 1233 228
assign 1 1233 230
nextGet 0 1233 230
assign 1 1234 231
isEmpty 1 1234 231
assign 1 1235 233
new 0 1235 233
return 1 1235 234
assign 1 1238 241
new 0 1238 241
return 1 1238 242
assign 1 1242 252
undef 1 1242 257
assign 1 0 258
assign 1 1242 261
sizeGet 0 1242 261
assign 1 1242 262
new 0 1242 262
assign 1 1242 263
lesser 1 1242 263
assign 1 0 265
assign 1 0 268
assign 1 1243 272
new 0 1243 272
return 1 1243 273
assign 1 1245 275
new 0 1245 275
return 1 1245 276
assign 1 1249 285
def 1 1249 290
assign 1 1249 291
new 0 1249 291
assign 1 1249 292
notEquals 1 1249 292
assign 1 0 294
assign 1 0 297
assign 1 0 301
assign 1 1250 304
new 0 1250 304
return 1 1250 305
assign 1 1252 307
new 0 1252 307
return 1 1252 308
return 1 0 311
assign 1 0 314
return 1 0 318
assign 1 0 321
return 1 0 325
assign 1 0 328
return 1 0 332
assign 1 0 335
return 1 0 339
assign 1 0 342
return 1 0 346
assign 1 0 349
return 1 0 353
assign 1 0 356
return 1 0 360
assign 1 0 363
return 1 0 367
assign 1 0 370
return 1 0 374
assign 1 0 377
return 1 0 381
assign 1 0 384
return 1 0 388
assign 1 0 391
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 482013217: return bem_spaceGet_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 1081741254: return bem_emptyGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1259904107: return bem_quoteGet_0();
case 1502128718: return bem_default_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1708371387: return bem_dosNewlineGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1599801355: return bem_wsGet_0();
case 55016493: return bem_lfGet_0();
case 929570062: return bem_tabGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 776765523: return bem_newlineGet_0();
case 1000967768: return bem_crGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1152565608: return bem_colonGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 527120532: return bem_lineSplitterGet_0();
case 1354714650: return bem_copy_0();
case 1567400443: return bem_unixNewlineGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1270986360: return bem_quoteSet_1(bevd_0);
case 1719453640: return bem_dosNewlineSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 516038279: return bem_lineSplitterSet_1(bevd_0);
case 1629015603: return bem_anyEmpty_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1012050021: return bem_crSet_1(bevd_0);
case 66098746: return bem_lfSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1437735788: return bem_notEmpty_1((BEC_4_6_TextString) bevd_0);
case 493095470: return bem_spaceSet_1(bevd_0);
case 918487809: return bem_tabSet_1(bevd_0);
case 1578482696: return bem_unixNewlineSet_1(bevd_0);
case 1610883608: return bem_wsSet_1(bevd_0);
case 2091366709: return bem_isEmpty_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1070659001: return bem_emptySet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1163647861: return bem_colonSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1881757494: return bem_strip_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1154529699: return bem_join_2((BEC_4_6_TextString) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 941304624: return bem_commonPrefix_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1331758909: return bem_joinBuffer_2((BEC_4_6_TextString) bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_7_TextStrings();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_7_TextStrings.bevs_inst = (BEC_4_7_TextStrings)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_7_TextStrings.bevs_inst;
}
}
