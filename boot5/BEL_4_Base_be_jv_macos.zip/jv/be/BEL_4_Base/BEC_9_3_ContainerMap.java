package be.BEL_4_Base;
/* File: source/base/Map.be */
public class BEC_9_3_ContainerMap extends BEC_9_3_ContainerSet {
public BEC_9_3_ContainerMap() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_9_3_ContainerMap bevs_inst;
public BEC_9_3_ContainerMap bem_new_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_9_3_ContainerMap bem_new_1(BEC_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_9_5_ContainerArray()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_4_3_MathInt(2));
bevp_rel = (BEC_9_3_9_ContainerSetRelations) BEC_9_3_9_ContainerSetRelations.bevs_inst.bem_new_0();
bevp_baseNode = (BEC_9_3_7_ContainerSetSetNode) (new BEC_9_3_7_ContainerMapMapNode()).bem_new_0();
bevp_size = (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_9_3_21_ContainerMapSerializationIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_contentsEqual_1(BEC_9_3_ContainerSet beva__other) throws Throwable {
BEC_9_3_ContainerMap bevl_other = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
bevl_other = (BEC_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 133 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 133 */ {
bevt_6_tmpvar_phold = bevl_other.bem_sizeGet_0();
bevt_7_tmpvar_phold = this.bem_sizeGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_notEquals_1(bevt_7_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 133 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 133 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 133 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 133 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 134 */
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 136 */ {
bevt_9_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 136 */ {
bevl_i = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_i.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevl_v = bevl_other.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_v == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_13_tmpvar_phold = bevl_i.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
if (bevt_13_tmpvar_phold == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 138 */ {
if (bevl_v == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
 else  /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_16_tmpvar_phold = bevl_i.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_v);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_17_tmpvar_phold;
} /* Line: 138 */
} /* Line: 138 */
 else  /* Line: 136 */ {
break;
} /* Line: 136 */
} /* Line: 136 */
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_18_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_put_2(BEC_6_6_SystemObject beva_k, BEC_6_6_SystemObject beva_v) throws Throwable {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_v, null, bevp_slots);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 144 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 147 */ {
bevt_3_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 147 */ {
bevl_slt = (BEC_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
} /* Line: 148 */
 else  /* Line: 147 */ {
break;
} /* Line: 147 */
} /* Line: 147 */
bevp_slots = bevl_slt;
} /* Line: 150 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 152 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 153 */
return this;
} /*method end*/
public BEC_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() throws Throwable {
BEC_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_9_3_13_ContainerMapValueIterator) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_3_13_ContainerMapValueIterator bem_valuesGet_0() throws Throwable {
BEC_9_3_13_ContainerMapValueIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_valueIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() throws Throwable {
BEC_9_3_16_ContainerMapKeyValueIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_3_ContainerMap bem_addValue_1(BEC_6_6_SystemObject beva_other) throws Throwable {
BEC_9_3_ContainerMap bevl_otherMap = null;
BEC_6_6_SystemObject bevl_x = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 174 */ {
bevt_2_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 175 */ {
bevl_otherMap = (BEC_9_3_ContainerMap) beva_other;
bevt_0_tmpvar_loop = bevl_otherMap.bem_iteratorGet_0();
while (true)
 /* Line: 177 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 177 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevl_x.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_5_tmpvar_phold = bevl_x.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
this.bem_put_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
} /* Line: 178 */
 else  /* Line: 177 */ {
break;
} /* Line: 177 */
} /* Line: 177 */
} /* Line: 177 */
 else  /* Line: 175 */ {
bevt_6_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 180 */ {
bevt_7_tmpvar_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_8_tmpvar_phold = beva_other.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
this.bem_put_2(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold);
} /* Line: 181 */
 else  /* Line: 182 */ {
this.bem_put_2(beva_other, beva_other);
} /* Line: 183 */
} /* Line: 175 */
} /* Line: 175 */
return this;
} /*method end*/
//int[] bevs_nlcs = {115, 115, 119, 120, 121, 122, 123, 124, 128, 128, 132, 133, 133, 0, 133, 133, 133, 0, 0, 134, 134, 136, 0, 136, 136, 137, 137, 138, 138, 0, 138, 138, 138, 138, 138, 0, 0, 0, 0, 0, 0, 138, 138, 0, 0, 138, 138, 140, 140, 144, 144, 145, 146, 147, 147, 148, 150, 153, 158, 158, 162, 162, 166, 166, 170, 170, 174, 174, 175, 176, 177, 0, 177, 177, 178, 178, 178, 180, 181, 181, 181, 183};
//int[] bevs_nlecs = {10, 11, 15, 16, 17, 18, 19, 20, 25, 26, 51, 52, 57, 58, 61, 62, 63, 65, 68, 72, 73, 75, 75, 78, 80, 81, 82, 83, 88, 89, 92, 93, 98, 99, 104, 105, 108, 112, 115, 118, 122, 125, 126, 128, 131, 135, 136, 143, 144, 152, 153, 155, 156, 159, 160, 162, 168, 171, 177, 178, 182, 183, 187, 188, 192, 193, 207, 212, 213, 215, 216, 216, 219, 221, 222, 223, 224, 232, 234, 235, 236, 239};
/* BEGIN LINEINFO 
assign 1 115 10
new 0 115 10
new 1 115 11
assign 1 119 15
new 1 119 15
assign 1 120 16
assign 1 121 17
new 0 121 17
assign 1 122 18
new 0 122 18
assign 1 123 19
new 0 123 19
assign 1 124 20
new 0 124 20
assign 1 128 25
new 1 128 25
return 1 128 26
assign 1 132 51
assign 1 133 52
undef 1 133 57
assign 1 0 58
assign 1 133 61
sizeGet 0 133 61
assign 1 133 62
sizeGet 0 133 62
assign 1 133 63
notEquals 1 133 63
assign 1 0 65
assign 1 0 68
assign 1 134 72
new 0 134 72
return 1 134 73
assign 1 136 75
iteratorGet 0 0 75
assign 1 136 78
hasNextGet 0 136 78
assign 1 136 80
nextGet 0 136 80
assign 1 137 81
keyGet 0 137 81
assign 1 137 82
get 1 137 82
assign 1 138 83
undef 1 138 88
assign 1 0 89
assign 1 138 92
valueGet 0 138 92
assign 1 138 93
undef 1 138 98
assign 1 138 99
def 1 138 104
assign 1 0 105
assign 1 0 108
assign 1 0 112
assign 1 0 115
assign 1 0 118
assign 1 0 122
assign 1 138 125
valueGet 0 138 125
assign 1 138 126
notEquals 1 138 126
assign 1 0 128
assign 1 0 131
assign 1 138 135
new 0 138 135
return 1 138 136
assign 1 140 143
new 0 140 143
return 1 140 144
assign 1 144 152
innerPut 4 144 152
assign 1 144 153
not 0 144 153
assign 1 145 155
assign 1 146 156
rehash 1 146 156
assign 1 147 159
innerPut 4 147 159
assign 1 147 160
not 0 147 160
assign 1 148 162
rehash 1 148 162
assign 1 150 168
assign 1 153 171
increment 0 153 171
assign 1 158 177
new 1 158 177
return 1 158 178
assign 1 162 182
valueIteratorGet 0 162 182
return 1 162 183
assign 1 166 187
new 1 166 187
return 1 166 188
assign 1 170 192
new 1 170 192
return 1 170 193
assign 1 174 207
def 1 174 212
assign 1 175 213
sameType 1 175 213
assign 1 176 215
assign 1 177 216
iteratorGet 0 0 216
assign 1 177 219
hasNextGet 0 177 219
assign 1 177 221
nextGet 0 177 221
assign 1 178 222
keyGet 0 178 222
assign 1 178 223
valueGet 0 178 223
put 2 178 224
assign 1 180 232
sameType 1 180 232
assign 1 181 234
keyGet 0 181 234
assign 1 181 235
valueGet 0 181 235
put 2 181 236
put 2 183 239
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1227011022: return bem_multiGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1431826729: return bem_nodeIteratorGet_0();
case 1774940957: return bem_toString_0();
case 1354714650: return bem_copy_0();
case 1586230380: return bem_moduGet_0();
case 550406779: return bem_valuesGet_0();
case 1308786538: return bem_echo_0();
case 354906194: return bem_slotsGet_0();
case 856777406: return bem_clear_0();
case 712928736: return bem_innerPutAddedGet_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2086347094: return bem_nodesGet_0();
case 902391673: return bem_keyValueIteratorGet_0();
case 235611348: return bem_baseNodeGet_0();
case 786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 2145224760: return bem_valueIteratorGet_0();
case 474162694: return bem_sizeGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1012494862: return bem_once_0();
case 578884498: return bem_relGet_0();
case 287040793: return bem_hashGet_0();
case 1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 2056412570: return bem_keyIteratorGet_0();
case 1114073101: return bem_keysGet_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 1089531140: return bem_isEmptyGet_0();
case 845792839: return bem_iteratorGet_0();
case 314718434: return bem_print_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1575148127: return bem_moduSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 567802245: return bem_relSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_9_3_ContainerSet) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 79841285: return bem_intersection_1((BEC_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 286659903: return bem_union_1((BEC_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_9_3_ContainerSet) bevd_0);
case 668984013: return bem_rehash_1((BEC_9_5_ContainerArray) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 107034370: return bem_put_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 131089957: return bem_insertAll_2((BEC_9_5_ContainerArray) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_9_5_ContainerArray) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_9_3_ContainerMap();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_9_3_ContainerMap.bevs_inst = (BEC_9_3_ContainerMap)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_9_3_ContainerMap.bevs_inst;
}
}
