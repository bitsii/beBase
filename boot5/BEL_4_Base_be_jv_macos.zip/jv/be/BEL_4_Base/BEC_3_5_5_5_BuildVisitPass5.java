package be.BEL_4_Base;
/* IO:File: source/build/Pass5.be */
public final class BEC_3_5_5_5_BuildVisitPass5 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass5() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x35};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x35,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_2 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x6F,0x66,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_3 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x61,0x6C,0x69,0x61,0x73,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x20,0x2D,0x61,0x73,0x2D,0x2E};
private static byte[] bels_4 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x6E,0x6F,0x74,0x20,0x77,0x69,0x74,0x68,0x69,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x75,0x6E,0x69,0x74};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(2));
private static byte[] bels_5 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_6 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_7 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bels_8 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_9 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_10 = {0x4F,0x6E,0x6C,0x79,0x20,0x73,0x69,0x6E,0x67,0x6C,0x65,0x20,0x69,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x69,0x73,0x20,0x61,0x6C,0x6C,0x6F,0x77,0x65,0x64};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_13 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x62,0x72,0x61,0x63,0x65,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_14 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_15 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(2));
private static byte[] bels_16 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_17 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_18 = {0x4C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bels_19 = {0x46,0x69,0x72,0x73,0x74,0x20,0x63,0x68,0x61,0x72,0x61,0x63,0x74,0x65,0x72,0x20,0x6F,0x66,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x61,0x6E,0x64,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x6E,0x61,0x6D,0x65,0x73,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x6E,0x75,0x6D,0x65,0x72,0x69,0x63,0x20,0x64,0x69,0x67,0x69,0x74};
private static byte[] bels_20 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x31};
private static byte[] bels_21 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x32};
private static byte[] bels_22 = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] bels_23 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x63,0x6F,0x6E,0x74,0x65,0x6E,0x74,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6F,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x2E};
private static byte[] bels_24 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x74,0x68,0x65,0x73,0x69,0x73,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x28,0x62,0x75,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x29,0x20,0x61,0x66,0x74,0x65,0x72,0x3A,0x20};
public static BEC_3_5_5_5_BuildVisitPass5 bevs_inst;
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_err = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_5_4_BuildNode bevl_lun = null;
BEC_2_5_4_LogicBool bevl_isLocalUse = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_namepath = null;
BEC_2_4_6_TextString bevl_alias = null;
BEC_2_6_6_SystemObject bevl_mas = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_6_6_SystemObject bevl_tnode = null;
BEC_2_5_4_LogicBool bevl_isFinal = null;
BEC_2_5_4_LogicBool bevl_isLocal = null;
BEC_2_5_4_LogicBool bevl_isNotNull = null;
BEC_2_5_4_BuildNode bevl_prp = null;
BEC_2_4_3_MathInt bevl_prpi = null;
BEC_2_5_4_BuildNode bevl_prptmp = null;
BEC_2_6_6_SystemObject bevl_m = null;
BEC_2_6_6_SystemObject bevl_mx = null;
BEC_2_6_6_SystemObject bevl_nx = null;
BEC_2_6_6_SystemObject bevl_con = null;
BEC_2_6_6_SystemObject bevl_lpnode = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_5_9_BuildTransUnit bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_31_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_67_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_77_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_92_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_96_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_97_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_98_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_99_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_104_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_121_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_2_5_5_BuildClass bevt_126_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_129_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_136_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_137_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_138_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_139_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_153_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_154_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_160_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_166_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_169_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_170_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_171_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_172_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_173_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_174_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_175_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_178_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_179_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_180_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_181_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_182_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_183_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_184_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_185_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_186_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_187_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_188_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_189_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_190_tmpvar_phold = null;
BEC_2_5_6_BuildMethod bevt_191_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_192_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_193_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_194_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_195_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_197_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_198_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_199_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_200_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_202_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_203_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_204_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_205_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_206_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_207_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_208_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_210_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_211_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_212_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_213_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_214_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_215_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_216_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_217_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_219_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_220_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_221_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_222_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_224_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_225_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_227_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_228_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_229_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_230_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_231_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_232_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_233_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_235_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_236_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_237_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_238_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_239_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_240_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_241_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_242_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_243_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_244_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_245_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_246_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_247_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_248_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_249_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_250_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_251_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_252_tmpvar_phold = null;
BEC_2_5_9_BuildConstants bevt_253_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_254_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_255_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_256_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_257_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_258_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_259_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_260_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_261_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_263_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_264_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_265_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_266_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_267_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_268_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_269_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_270_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_271_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_272_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_273_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_274_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_275_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_276_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_277_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_278_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_279_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_280_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_281_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_282_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_283_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_284_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_285_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_286_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_287_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_288_tmpvar_phold = null;
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_20_tmpvar_phold.bevi_int == bevt_21_tmpvar_phold.bevi_int) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 23 */ {
bevt_22_tmpvar_phold = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
beva_node.bem_heldSet_1(bevt_22_tmpvar_phold);
} /* Line: 24 */
bevt_24_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_24_tmpvar_phold.bevi_int == bevt_25_tmpvar_phold.bevi_int) {
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 26 */ {
bevt_27_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_27_tmpvar_phold == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_29_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_31_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_emptyGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevt_30_tmpvar_phold);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 27 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 27 */ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 29 */
} /* Line: 27 */
bevl_ix = beva_node.bem_nextPeerGet_0();
if (bevl_ix == null) {
bevt_32_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_32_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 33 */ {
bevt_34_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_35_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_34_tmpvar_phold.bevi_int == bevt_35_tmpvar_phold.bevi_int) {
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 33 */ {
bevt_37_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_38_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_37_tmpvar_phold.bevi_int == bevt_38_tmpvar_phold.bevi_int) {
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 33 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 33 */
 else  /* Line: 33 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 33 */ {
bevt_40_tmpvar_phold = bevl_ix.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_41_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_41_tmpvar_phold);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 33 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 33 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 33 */
 else  /* Line: 33 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 33 */ {
bevt_43_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_43_tmpvar_phold.bevi_int == bevt_44_tmpvar_phold.bevi_int) {
bevt_42_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 35 */ {
bevl_vinp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_45_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_45_tmpvar_phold);
} /* Line: 37 */
 else  /* Line: 38 */ {
bevl_vinp = beva_node.bem_heldGet_0();
} /* Line: 39 */
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_46_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_46_tmpvar_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_47_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_47_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 46 */
bevt_49_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_50_tmpvar_phold = bevp_ntypes.bem_USEGet_0();
if (bevt_49_tmpvar_phold.bevi_int == bevt_50_tmpvar_phold.bevi_int) {
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevl_lun = beva_node.bem_priorPeerGet_0();
if (bevl_lun == null) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_53_tmpvar_phold = bevl_lun.bem_typenameGet_0();
bevt_54_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_53_tmpvar_phold.bevi_int == bevt_54_tmpvar_phold.bevi_int) {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
 else  /* Line: 51 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevt_56_tmpvar_phold = bevl_lun.bem_heldGet_0();
bevt_57_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_0));
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_57_tmpvar_phold);
if (bevt_55_tmpvar_phold != null && bevt_55_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_55_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
 else  /* Line: 51 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevl_isLocalUse = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_lun.bem_delete_0();
} /* Line: 53 */
 else  /* Line: 54 */ {
bevl_isLocalUse = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 55 */
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 60 */ {
if (bevl_nnode == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_60_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_61_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_61_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 60 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevl_nnode = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
} /* Line: 61 */
 else  /* Line: 60 */ {
break;
} /* Line: 60 */
} /* Line: 60 */
if (bevl_nnode == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 63 */ {
bevt_64_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_65_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_65_tmpvar_phold);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 63 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 63 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 63 */
 else  /* Line: 63 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 63 */ {
bevl_clnode = bevl_nnode;
bevt_66_tmpvar_phold = bevl_clnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nnode = bevt_66_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 65 */
 else  /* Line: 66 */ {
bevl_clnode = null;
} /* Line: 67 */
if (bevl_nnode == null) {
bevt_67_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_67_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_67_tmpvar_phold.bevi_bool) /* Line: 70 */ {
bevt_69_tmpvar_phold = (new BEC_2_4_6_TextString(59, bels_1));
bevt_68_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_69_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_68_tmpvar_phold);
} /* Line: 71 */
bevt_71_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_72_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_72_tmpvar_phold);
if (bevt_70_tmpvar_phold != null && bevt_70_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_70_tmpvar_phold).bevi_bool) /* Line: 74 */ {
bevl_namepath = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_73_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_73_tmpvar_phold);
} /* Line: 76 */
 else  /* Line: 74 */ {
bevt_75_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_74_tmpvar_phold != null && bevt_74_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpvar_phold).bevi_bool) /* Line: 77 */ {
bevl_namepath = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 78 */
 else  /* Line: 79 */ {
bevt_78_tmpvar_phold = (new BEC_2_4_6_TextString(55, bels_2));
bevt_77_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_78_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_77_tmpvar_phold);
} /* Line: 80 */
} /* Line: 74 */
bevl_alias = null;
bevl_mas = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_80_tmpvar_phold = bevl_mas.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_81_tmpvar_phold = bevp_ntypes.bem_ASGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpvar_phold);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 85 */ {
bevl_nnode = bevl_mas.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_83_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_84_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_84_tmpvar_phold);
if (bevt_82_tmpvar_phold != null && bevt_82_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_82_tmpvar_phold).bevi_bool) /* Line: 87 */ {
bevt_86_tmpvar_phold = (new BEC_2_4_6_TextString(57, bels_3));
bevt_85_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_85_tmpvar_phold);
} /* Line: 88 */
bevl_alias = (BEC_2_4_6_TextString) bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 90 */
if (bevl_clnode == null) {
bevt_87_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpvar_phold.bevi_bool) /* Line: 93 */ {
bevl_gnext = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_89_tmpvar_phold = bevl_gnext.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_90_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_90_tmpvar_phold);
if (bevt_88_tmpvar_phold != null && bevt_88_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_88_tmpvar_phold).bevi_bool) /* Line: 97 */ {
bevl_nnode = bevl_gnext;
bevl_gnext = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 100 */
} /* Line: 97 */
 else  /* Line: 102 */ {
bevl_gnext = bevl_clnode;
} /* Line: 103 */
beva_node.bem_heldSet_1(bevl_namepath);
bevl_tnode = beva_node.bem_transUnitGet_0();
if (bevl_tnode == null) {
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_93_tmpvar_phold = (new BEC_2_4_6_TextString(53, bels_4));
bevt_92_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_93_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_92_tmpvar_phold);
} /* Line: 110 */
if (bevl_alias == null) {
bevt_94_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_94_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_94_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevl_alias = (BEC_2_4_6_TextString) bevl_namepath.bemd_0(1672091917, BEL_4_Base.bevn_labelGet_0);
} /* Line: 114 */
bevt_96_tmpvar_phold = bevl_tnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_95_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_alias, bevl_namepath);
if (bevl_isLocalUse.bevi_bool) /* Line: 117 */ {
bevt_98_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bem_aliasedGet_0();
bevt_97_tmpvar_phold.bem_put_2(bevl_alias, bevl_namepath);
} /* Line: 118 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 121 */
bevt_100_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_101_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_100_tmpvar_phold.bevi_int == bevt_101_tmpvar_phold.bevi_int) {
bevt_99_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_99_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_99_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevl_isFinal = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isLocal = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isNotNull = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 128 */ {
bevt_103_tmpvar_phold = bevo_0;
if (bevl_prpi.bevi_int < bevt_103_tmpvar_phold.bevi_int) {
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 128 */ {
if (bevl_prp == null) {
bevt_104_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_104_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_104_tmpvar_phold.bevi_bool) /* Line: 129 */ {
bevt_106_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_107_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_106_tmpvar_phold.bevi_int == bevt_107_tmpvar_phold.bevi_int) {
bevt_105_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_105_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_105_tmpvar_phold.bevi_bool) /* Line: 130 */ {
bevt_109_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_110_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_109_tmpvar_phold.bevi_int == bevt_110_tmpvar_phold.bevi_int) {
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 131 */ {
bevt_112_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_113_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_5));
bevt_111_tmpvar_phold = bevt_112_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_113_tmpvar_phold);
if (bevt_111_tmpvar_phold != null && bevt_111_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_111_tmpvar_phold).bevi_bool) /* Line: 131 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
 else  /* Line: 131 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 131 */ {
bevl_isFinal = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 132 */
 else  /* Line: 131 */ {
bevt_115_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_116_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_115_tmpvar_phold.bevi_int == bevt_116_tmpvar_phold.bevi_int) {
bevt_114_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpvar_phold.bevi_bool) /* Line: 133 */ {
bevt_118_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_119_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_6));
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_119_tmpvar_phold);
if (bevt_117_tmpvar_phold != null && bevt_117_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_117_tmpvar_phold).bevi_bool) /* Line: 133 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 133 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 133 */
 else  /* Line: 133 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 133 */ {
bevl_isLocal = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 134 */
 else  /* Line: 131 */ {
bevt_121_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_122_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_121_tmpvar_phold.bevi_int == bevt_122_tmpvar_phold.bevi_int) {
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_120_tmpvar_phold.bevi_bool) /* Line: 135 */ {
bevt_124_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_125_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_7));
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_125_tmpvar_phold);
if (bevt_123_tmpvar_phold != null && bevt_123_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_123_tmpvar_phold).bevi_bool) /* Line: 135 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 135 */ {
bevl_isNotNull = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 136 */
} /* Line: 131 */
} /* Line: 131 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 140 */
 else  /* Line: 141 */ {
bevl_prp = null;
} /* Line: 142 */
} /* Line: 130 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 128 */
 else  /* Line: 128 */ {
break;
} /* Line: 128 */
} /* Line: 128 */
bevt_126_tmpvar_phold = (new BEC_2_5_5_BuildClass()).bem_new_0();
beva_node.bem_heldSet_1(bevt_126_tmpvar_phold);
bevt_127_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_128_tmpvar_phold = bevp_build.bem_fromFileGet_0();
bevt_127_tmpvar_phold.bemd_1(806119150, BEL_4_Base.bevn_fromFileSet_1, bevt_128_tmpvar_phold);
try  /* Line: 148 */ {
bevt_129_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_129_tmpvar_phold.bem_firstGet_0();
bevt_131_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_132_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_130_tmpvar_phold = bevt_131_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_132_tmpvar_phold);
if (bevt_130_tmpvar_phold != null && bevt_130_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_130_tmpvar_phold).bevi_bool) /* Line: 150 */ {
bevl_namepath = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_133_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_133_tmpvar_phold);
} /* Line: 152 */
 else  /* Line: 150 */ {
bevt_135_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_136_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpvar_phold);
if (bevt_134_tmpvar_phold != null && bevt_134_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_134_tmpvar_phold).bevi_bool) /* Line: 153 */ {
bevl_namepath = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 154 */
 else  /* Line: 155 */ {
bevt_138_tmpvar_phold = (new BEC_2_4_6_TextString(35, bels_8));
bevt_137_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_138_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_137_tmpvar_phold);
} /* Line: 156 */
} /* Line: 150 */
bevt_139_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_139_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_namepath);
bevt_140_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_140_tmpvar_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevl_isFinal);
bevt_141_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_141_tmpvar_phold.bemd_1(831500365, BEL_4_Base.bevn_isLocalSet_1, bevl_isLocal);
bevt_142_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_142_tmpvar_phold.bemd_1(374719236, BEL_4_Base.bevn_isNotNullSet_1, bevl_isNotNull);
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 162 */
 catch (Throwable beve_0) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_144_tmpvar_phold = (new BEC_2_4_6_TextString(61, bels_9));
bevt_143_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_143_tmpvar_phold);
} /* Line: 165 */
try  /* Line: 167 */ {
bevt_145_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_nnode = bevt_145_tmpvar_phold.bem_firstGet_0();
bevt_147_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_148_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_146_tmpvar_phold = bevt_147_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_148_tmpvar_phold);
if (bevt_146_tmpvar_phold != null && bevt_146_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_146_tmpvar_phold).bevi_bool) /* Line: 169 */ {
bevt_151_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_152_tmpvar_phold = (new BEC_2_4_3_MathInt(2));
bevt_149_tmpvar_phold = bevt_150_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_152_tmpvar_phold);
if (bevt_149_tmpvar_phold != null && bevt_149_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_149_tmpvar_phold).bevi_bool) /* Line: 170 */ {
bevt_154_tmpvar_phold = (new BEC_2_4_6_TextString(34, bels_10));
bevt_153_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_154_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_153_tmpvar_phold);
} /* Line: 171 */
try  /* Line: 173 */ {
bevt_155_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_m = bevt_155_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_157_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_158_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_156_tmpvar_phold = bevt_157_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_158_tmpvar_phold);
if (bevt_156_tmpvar_phold != null && bevt_156_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_156_tmpvar_phold).bevi_bool) /* Line: 175 */ {
bevt_159_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_160_tmpvar_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_159_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_160_tmpvar_phold);
bevt_162_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_161_tmpvar_phold = bevt_162_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_163_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_161_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_163_tmpvar_phold);
} /* Line: 177 */
 else  /* Line: 175 */ {
bevt_165_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_166_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_164_tmpvar_phold = bevt_165_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_166_tmpvar_phold);
if (bevt_164_tmpvar_phold != null && bevt_164_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_164_tmpvar_phold).bevi_bool) /* Line: 178 */ {
bevt_167_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_168_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_167_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_168_tmpvar_phold);
} /* Line: 179 */
 else  /* Line: 180 */ {
bevt_170_tmpvar_phold = (new BEC_2_4_6_TextString(42, bels_11));
bevt_169_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_170_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_169_tmpvar_phold);
} /* Line: 181 */
} /* Line: 175 */
} /* Line: 175 */
 catch (Throwable beve_1) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_1));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_172_tmpvar_phold = (new BEC_2_4_6_TextString(68, bels_12));
bevt_171_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_172_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_171_tmpvar_phold);
} /* Line: 186 */
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 188 */
} /* Line: 169 */
 catch (Throwable beve_2) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_2));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_174_tmpvar_phold = (new BEC_2_4_6_TextString(60, bels_13));
bevt_173_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_174_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_173_tmpvar_phold);
} /* Line: 192 */
bevt_177_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_176_tmpvar_phold = bevt_177_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_176_tmpvar_phold == null) {
bevt_175_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_175_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_175_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevt_181_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_180_tmpvar_phold = bevt_181_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_179_tmpvar_phold = bevt_180_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_182_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_14));
bevt_178_tmpvar_phold = bevt_179_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_182_tmpvar_phold);
if (bevt_178_tmpvar_phold != null && bevt_178_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_178_tmpvar_phold).bevi_bool) /* Line: 195 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 195 */ {
bevt_183_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_185_tmpvar_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_186_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_15));
bevt_184_tmpvar_phold = bevt_185_tmpvar_phold.bem_fromString_1(bevt_186_tmpvar_phold);
bevt_183_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_184_tmpvar_phold);
} /* Line: 196 */
bevt_187_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_187_tmpvar_phold;
} /* Line: 199 */
bevt_189_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_190_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_189_tmpvar_phold.bevi_int == bevt_190_tmpvar_phold.bevi_int) {
bevt_188_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_188_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_188_tmpvar_phold.bevi_bool) /* Line: 201 */ {
bevt_191_tmpvar_phold = (new BEC_2_5_6_BuildMethod()).bem_new_0();
beva_node.bem_heldSet_1(bevt_191_tmpvar_phold);
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 204 */ {
bevt_193_tmpvar_phold = bevo_1;
if (bevl_prpi.bevi_int < bevt_193_tmpvar_phold.bevi_int) {
bevt_192_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_192_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_192_tmpvar_phold.bevi_bool) /* Line: 204 */ {
if (bevl_prp == null) {
bevt_194_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_194_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_194_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_196_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_197_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_196_tmpvar_phold.bevi_int == bevt_197_tmpvar_phold.bevi_int) {
bevt_195_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_195_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_195_tmpvar_phold.bevi_bool) /* Line: 206 */ {
bevt_199_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_200_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_199_tmpvar_phold.bevi_int == bevt_200_tmpvar_phold.bevi_int) {
bevt_198_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_198_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_198_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevt_202_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_203_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_16));
bevt_201_tmpvar_phold = bevt_202_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_203_tmpvar_phold);
if (bevt_201_tmpvar_phold != null && bevt_201_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_201_tmpvar_phold).bevi_bool) /* Line: 207 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 207 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 207 */
 else  /* Line: 207 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 207 */ {
bevt_204_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_205_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_204_tmpvar_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevt_205_tmpvar_phold);
} /* Line: 208 */
 else  /* Line: 207 */ {
bevt_207_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_208_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_207_tmpvar_phold.bevi_int == bevt_208_tmpvar_phold.bevi_int) {
bevt_206_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_206_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_206_tmpvar_phold.bevi_bool) /* Line: 209 */ {
bevt_210_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_211_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_17));
bevt_209_tmpvar_phold = bevt_210_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_211_tmpvar_phold);
if (bevt_209_tmpvar_phold != null && bevt_209_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_209_tmpvar_phold).bevi_bool) /* Line: 209 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 209 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 209 */
 else  /* Line: 209 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 209 */ {
bevt_213_tmpvar_phold = (new BEC_2_4_6_TextString(27, bels_18));
bevt_212_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_213_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_212_tmpvar_phold);
} /* Line: 211 */
} /* Line: 207 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 215 */
 else  /* Line: 216 */ {
bevl_prp = null;
} /* Line: 217 */
} /* Line: 206 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 204 */
 else  /* Line: 204 */ {
break;
} /* Line: 204 */
} /* Line: 204 */
try  /* Line: 221 */ {
bevt_214_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_214_tmpvar_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_215_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_215_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_215_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevl_mx = bevl_m.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_mx == null) {
bevt_216_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_216_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_216_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevl_mx = bevl_mx.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_218_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_219_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_217_tmpvar_phold = bevt_218_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_219_tmpvar_phold);
if (bevt_217_tmpvar_phold != null && bevt_217_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_217_tmpvar_phold).bevi_bool) /* Line: 227 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 227 */ {
bevt_221_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_222_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_220_tmpvar_phold = bevt_221_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_222_tmpvar_phold);
if (bevt_220_tmpvar_phold != null && bevt_220_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_220_tmpvar_phold).bevi_bool) /* Line: 227 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 227 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 227 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 227 */ {
bevt_224_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_225_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_223_tmpvar_phold = bevt_224_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_225_tmpvar_phold);
if (bevt_223_tmpvar_phold != null && bevt_223_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_223_tmpvar_phold).bevi_bool) /* Line: 229 */ {
bevl_vinp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_226_tmpvar_phold = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_226_tmpvar_phold);
} /* Line: 231 */
 else  /* Line: 232 */ {
bevl_vinp = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 233 */
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_227_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_227_tmpvar_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_228_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_mx.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_228_tmpvar_phold);
bevl_mx.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_v);
} /* Line: 239 */
} /* Line: 227 */
bevt_230_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_231_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_229_tmpvar_phold = bevt_230_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_231_tmpvar_phold);
if (bevt_229_tmpvar_phold != null && bevt_229_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_229_tmpvar_phold).bevi_bool) /* Line: 242 */ {
bevt_232_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_233_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_232_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_233_tmpvar_phold);
bevt_237_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_236_tmpvar_phold = bevt_237_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_238_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_235_tmpvar_phold = bevt_236_tmpvar_phold.bemd_1(636254476, BEL_4_Base.bevn_getPoint_1, bevt_238_tmpvar_phold);
bevt_234_tmpvar_phold = bevt_235_tmpvar_phold.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_234_tmpvar_phold != null && bevt_234_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_234_tmpvar_phold).bevi_bool) /* Line: 244 */ {
bevt_240_tmpvar_phold = (new BEC_2_4_6_TextString(75, bels_19));
bevt_239_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_240_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_239_tmpvar_phold);
} /* Line: 245 */
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 247 */
 else  /* Line: 248 */ {
bevt_242_tmpvar_phold = (new BEC_2_4_6_TextString(42, bels_20));
bevt_241_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_242_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_241_tmpvar_phold);
} /* Line: 249 */
} /* Line: 242 */
 else  /* Line: 251 */ {
bevt_244_tmpvar_phold = (new BEC_2_4_6_TextString(42, bels_21));
bevt_243_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_244_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_243_tmpvar_phold);
} /* Line: 252 */
} /* Line: 223 */
 catch (Throwable beve_3) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_3));
bevt_246_tmpvar_phold = bevl_err.bemd_0(1102720804, BEL_4_Base.bevn_classNameGet_0);
bevt_247_tmpvar_phold = (new BEC_2_4_6_TextString(16, bels_22));
bevt_245_tmpvar_phold = bevt_246_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_247_tmpvar_phold);
if (bevt_245_tmpvar_phold != null && bevt_245_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_245_tmpvar_phold).bevi_bool) /* Line: 255 */ {
throw new be.BELS_Base.BECS_ThrowBack(bevl_err);
} /* Line: 255 */
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_249_tmpvar_phold = (new BEC_2_4_6_TextString(104, bels_23));
bevt_248_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_249_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_248_tmpvar_phold);
} /* Line: 257 */
bevt_250_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_250_tmpvar_phold;
} /* Line: 259 */
bevt_253_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevt_252_tmpvar_phold = bevt_253_tmpvar_phold.bem_parensReqGet_0();
bevt_254_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_251_tmpvar_phold = bevt_252_tmpvar_phold.bem_has_1(bevt_254_tmpvar_phold);
if (bevt_251_tmpvar_phold.bevi_bool) /* Line: 261 */ {
bevt_255_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_255_tmpvar_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_256_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_256_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_256_tmpvar_phold.bevi_bool) /* Line: 263 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_258_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_259_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_257_tmpvar_phold = bevt_258_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_259_tmpvar_phold);
if (bevt_257_tmpvar_phold != null && bevt_257_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_257_tmpvar_phold).bevi_bool) /* Line: 263 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 263 */ {
bevt_261_tmpvar_phold = (new BEC_2_4_6_TextString(50, bels_24));
bevt_260_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_261_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_260_tmpvar_phold);
} /* Line: 264 */
} /* Line: 263 */
bevt_263_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_264_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_263_tmpvar_phold.bevi_int == bevt_264_tmpvar_phold.bevi_int) {
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_262_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevl_m = beva_node.bem_containerGet_0();
if (bevl_m == null) {
bevt_265_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_265_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_265_tmpvar_phold.bevi_bool) /* Line: 270 */ {
bevt_267_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_268_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_266_tmpvar_phold = bevt_267_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_268_tmpvar_phold);
if (bevt_266_tmpvar_phold != null && bevt_266_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_266_tmpvar_phold).bevi_bool) /* Line: 270 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 270 */
 else  /* Line: 270 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 270 */ {
bevt_269_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
beva_node.bem_typenameSet_1(bevt_269_tmpvar_phold);
} /* Line: 271 */
} /* Line: 270 */
bevt_271_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_272_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
if (bevt_271_tmpvar_phold.bevi_int == bevt_272_tmpvar_phold.bevi_int) {
bevt_270_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_270_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_270_tmpvar_phold.bevi_bool) /* Line: 274 */ {
bevl_nx = beva_node.bem_priorPeerGet_0();
bevl_gnext = beva_node.bem_nextAscendGet_0();
while (true)
 /* Line: 280 */ {
if (bevl_nx == null) {
bevt_273_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_273_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_273_tmpvar_phold.bevi_bool) /* Line: 280 */ {
bevt_275_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_276_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_274_tmpvar_phold = bevt_275_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_276_tmpvar_phold);
if (bevt_274_tmpvar_phold != null && bevt_274_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_274_tmpvar_phold).bevi_bool) /* Line: 280 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 280 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 280 */
 else  /* Line: 280 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_18_tmpvar_anchor.bevi_bool) /* Line: 280 */ {
bevt_278_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_279_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_277_tmpvar_phold = bevt_278_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_279_tmpvar_phold);
if (bevt_277_tmpvar_phold != null && bevt_277_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_277_tmpvar_phold).bevi_bool) /* Line: 280 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 280 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 280 */
 else  /* Line: 280 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpvar_anchor.bevi_bool) /* Line: 280 */ {
bevt_281_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_282_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_280_tmpvar_phold = bevt_281_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_282_tmpvar_phold);
if (bevt_280_tmpvar_phold != null && bevt_280_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_280_tmpvar_phold).bevi_bool) /* Line: 280 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 280 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 280 */
 else  /* Line: 280 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 280 */ {
if (bevl_con == null) {
bevt_283_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_283_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_283_tmpvar_phold.bevi_bool) /* Line: 281 */ {
bevl_con = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 282 */
bevl_con.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_nx);
bevl_nx = bevl_nx.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
} /* Line: 285 */
 else  /* Line: 280 */ {
break;
} /* Line: 280 */
} /* Line: 280 */
if (bevl_con == null) {
bevt_284_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_284_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_284_tmpvar_phold.bevi_bool) /* Line: 287 */ {
bevt_285_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
beva_node.bem_typenameSet_1(bevt_285_tmpvar_phold);
beva_node.bem_heldSet_1(null);
bevl_lpnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_286_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_lpnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_286_tmpvar_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_lpnode);
bevl_lpnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_ii = bevl_con.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 294 */ {
bevt_287_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_287_tmpvar_phold != null && bevt_287_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_287_tmpvar_phold).bevi_bool) /* Line: 294 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_lpnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 297 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
} /* Line: 294 */
 else  /* Line: 303 */ {
beva_node.bem_delete_0();
} /* Line: 304 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 306 */
bevt_288_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_288_tmpvar_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 23, 23, 23, 24, 24, 26, 26, 26, 26, 27, 27, 27, 0, 27, 27, 27, 27, 0, 0, 28, 29, 32, 33, 33, 33, 33, 33, 33, 0, 33, 33, 33, 33, 0, 0, 0, 0, 0, 33, 33, 33, 0, 0, 0, 35, 35, 35, 35, 36, 37, 37, 39, 41, 42, 42, 44, 45, 45, 46, 48, 48, 48, 48, 50, 51, 51, 51, 51, 51, 51, 0, 0, 0, 51, 51, 51, 0, 0, 0, 52, 53, 55, 59, 60, 60, 60, 60, 60, 0, 0, 0, 61, 63, 63, 63, 63, 63, 0, 0, 0, 64, 65, 65, 67, 70, 70, 71, 71, 71, 74, 74, 74, 75, 76, 76, 77, 77, 77, 78, 80, 80, 80, 83, 84, 85, 85, 85, 86, 87, 87, 87, 88, 88, 88, 90, 93, 93, 94, 95, 97, 97, 97, 98, 99, 100, 103, 105, 107, 109, 109, 110, 110, 110, 113, 113, 114, 116, 116, 116, 118, 118, 118, 121, 123, 123, 123, 123, 124, 125, 126, 127, 128, 128, 128, 128, 129, 129, 130, 130, 130, 130, 131, 131, 131, 131, 131, 131, 131, 0, 0, 0, 132, 133, 133, 133, 133, 133, 133, 133, 0, 0, 0, 134, 135, 135, 135, 135, 135, 135, 135, 0, 0, 0, 136, 138, 139, 140, 142, 128, 146, 146, 147, 147, 147, 149, 149, 150, 150, 150, 151, 152, 152, 153, 153, 153, 154, 156, 156, 156, 158, 158, 159, 159, 160, 160, 161, 161, 162, 164, 165, 165, 165, 168, 168, 169, 169, 169, 170, 170, 170, 170, 171, 171, 171, 174, 174, 175, 175, 175, 176, 176, 176, 177, 177, 177, 177, 178, 178, 178, 179, 179, 179, 181, 181, 181, 185, 186, 186, 186, 188, 191, 192, 192, 192, 195, 195, 195, 195, 195, 195, 195, 195, 195, 0, 0, 0, 196, 196, 196, 196, 196, 199, 199, 201, 201, 201, 201, 202, 202, 203, 204, 204, 204, 204, 205, 205, 206, 206, 206, 206, 207, 207, 207, 207, 207, 207, 207, 0, 0, 0, 208, 208, 208, 209, 209, 209, 209, 209, 209, 209, 0, 0, 0, 211, 211, 211, 213, 214, 215, 217, 204, 222, 222, 223, 223, 224, 225, 225, 226, 227, 227, 227, 0, 227, 227, 227, 0, 0, 229, 229, 229, 230, 231, 231, 233, 235, 236, 236, 237, 238, 238, 239, 242, 242, 242, 243, 243, 243, 244, 244, 244, 244, 244, 245, 245, 245, 247, 249, 249, 249, 252, 252, 252, 255, 255, 255, 255, 256, 257, 257, 257, 259, 259, 261, 261, 261, 261, 262, 262, 263, 263, 0, 263, 263, 263, 0, 0, 264, 264, 264, 268, 268, 268, 268, 269, 270, 270, 270, 270, 270, 0, 0, 0, 271, 271, 274, 274, 274, 274, 275, 276, 280, 280, 280, 280, 280, 0, 0, 0, 280, 280, 280, 0, 0, 0, 280, 280, 280, 0, 0, 0, 281, 281, 282, 284, 285, 287, 287, 288, 288, 289, 290, 291, 291, 292, 293, 294, 294, 295, 296, 297, 304, 306, 309, 309};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {351, 352, 353, 358, 359, 360, 362, 363, 364, 369, 370, 371, 376, 377, 380, 381, 382, 383, 385, 388, 392, 393, 396, 397, 402, 403, 404, 405, 410, 411, 414, 415, 416, 421, 422, 425, 429, 432, 436, 439, 440, 441, 443, 446, 450, 453, 454, 455, 460, 461, 462, 463, 466, 468, 469, 470, 471, 472, 473, 474, 476, 477, 478, 483, 484, 485, 490, 491, 492, 493, 498, 499, 502, 506, 509, 510, 511, 513, 516, 520, 523, 524, 527, 529, 532, 537, 538, 539, 540, 542, 545, 549, 552, 558, 563, 564, 565, 566, 568, 571, 575, 578, 579, 580, 583, 585, 590, 591, 592, 593, 595, 596, 597, 599, 600, 601, 604, 605, 606, 608, 611, 612, 613, 616, 617, 618, 619, 620, 622, 623, 624, 625, 627, 628, 629, 631, 633, 638, 639, 640, 641, 642, 643, 645, 646, 647, 651, 653, 654, 655, 660, 661, 662, 663, 665, 670, 671, 673, 674, 675, 677, 678, 679, 681, 683, 684, 685, 690, 691, 692, 693, 694, 695, 698, 699, 704, 705, 710, 711, 712, 713, 718, 719, 720, 721, 726, 727, 728, 729, 731, 734, 738, 741, 744, 745, 746, 751, 752, 753, 754, 756, 759, 763, 766, 769, 770, 771, 776, 777, 778, 779, 781, 784, 788, 791, 795, 796, 797, 800, 803, 809, 810, 811, 812, 813, 815, 816, 817, 818, 819, 821, 822, 823, 826, 827, 828, 830, 833, 834, 835, 838, 839, 840, 841, 842, 843, 844, 845, 846, 850, 851, 852, 853, 856, 857, 858, 859, 860, 862, 863, 864, 865, 867, 868, 869, 872, 873, 874, 875, 876, 878, 879, 880, 881, 882, 883, 884, 887, 888, 889, 891, 892, 893, 896, 897, 898, 904, 905, 906, 907, 909, 914, 915, 916, 917, 919, 920, 921, 926, 927, 928, 929, 930, 931, 933, 936, 940, 943, 944, 945, 946, 947, 949, 950, 952, 953, 954, 959, 960, 961, 962, 963, 966, 967, 972, 973, 978, 979, 980, 981, 986, 987, 988, 989, 994, 995, 996, 997, 999, 1002, 1006, 1009, 1010, 1011, 1014, 1015, 1016, 1021, 1022, 1023, 1024, 1026, 1029, 1033, 1036, 1037, 1038, 1041, 1042, 1043, 1046, 1049, 1056, 1057, 1058, 1063, 1064, 1065, 1070, 1071, 1072, 1073, 1074, 1076, 1079, 1080, 1081, 1083, 1086, 1090, 1091, 1092, 1094, 1095, 1096, 1099, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1110, 1111, 1112, 1114, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1123, 1124, 1125, 1127, 1130, 1131, 1132, 1136, 1137, 1138, 1143, 1144, 1145, 1147, 1149, 1150, 1151, 1152, 1154, 1155, 1157, 1158, 1159, 1160, 1162, 1163, 1164, 1169, 1170, 1173, 1174, 1175, 1177, 1180, 1184, 1185, 1186, 1189, 1190, 1191, 1196, 1197, 1198, 1203, 1204, 1205, 1206, 1208, 1211, 1215, 1218, 1219, 1222, 1223, 1224, 1229, 1230, 1231, 1234, 1239, 1240, 1241, 1242, 1244, 1247, 1251, 1254, 1255, 1256, 1258, 1261, 1265, 1268, 1269, 1270, 1272, 1275, 1279, 1282, 1287, 1288, 1290, 1291, 1297, 1302, 1303, 1304, 1305, 1306, 1307, 1308, 1309, 1310, 1311, 1314, 1316, 1317, 1318, 1326, 1328, 1330, 1331};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 351
typenameGet 0 23 351
assign 1 23 352
TRANSUNITGet 0 23 352
assign 1 23 353
equals 1 23 358
assign 1 24 359
new 0 24 359
heldSet 1 24 360
assign 1 26 362
typenameGet 0 26 362
assign 1 26 363
VARGet 0 26 363
assign 1 26 364
equals 1 26 369
assign 1 27 370
heldGet 0 27 370
assign 1 27 371
undef 1 27 376
assign 1 0 377
assign 1 27 380
heldGet 0 27 380
assign 1 27 381
new 0 27 381
assign 1 27 382
emptyGet 0 27 382
assign 1 27 383
sameType 1 27 383
assign 1 0 385
assign 1 0 388
assign 1 28 392
new 0 28 392
heldSet 1 29 393
assign 1 32 396
nextPeerGet 0 32 396
assign 1 33 397
def 1 33 402
assign 1 33 403
typenameGet 0 33 403
assign 1 33 404
IDGet 0 33 404
assign 1 33 405
equals 1 33 410
assign 1 0 411
assign 1 33 414
typenameGet 0 33 414
assign 1 33 415
NAMEPATHGet 0 33 415
assign 1 33 416
equals 1 33 421
assign 1 0 422
assign 1 0 425
assign 1 0 429
assign 1 0 432
assign 1 0 436
assign 1 33 439
typenameGet 0 33 439
assign 1 33 440
IDGet 0 33 440
assign 1 33 441
equals 1 33 441
assign 1 0 443
assign 1 0 446
assign 1 0 450
assign 1 35 453
typenameGet 0 35 453
assign 1 35 454
IDGet 0 35 454
assign 1 35 455
equals 1 35 460
assign 1 36 461
new 0 36 461
assign 1 37 462
heldGet 0 37 462
addStep 1 37 463
assign 1 39 466
heldGet 0 39 466
assign 1 41 468
new 0 41 468
assign 1 42 469
new 0 42 469
isTypedSet 1 42 470
namepathSet 1 44 471
assign 1 45 472
VARGet 0 45 472
typenameSet 1 45 473
heldSet 1 46 474
assign 1 48 476
typenameGet 0 48 476
assign 1 48 477
USEGet 0 48 477
assign 1 48 478
equals 1 48 483
assign 1 50 484
priorPeerGet 0 50 484
assign 1 51 485
def 1 51 490
assign 1 51 491
typenameGet 0 51 491
assign 1 51 492
DEFMODGet 0 51 492
assign 1 51 493
equals 1 51 498
assign 1 0 499
assign 1 0 502
assign 1 0 506
assign 1 51 509
heldGet 0 51 509
assign 1 51 510
new 0 51 510
assign 1 51 511
equals 1 51 511
assign 1 0 513
assign 1 0 516
assign 1 0 520
assign 1 52 523
new 0 52 523
delete 0 53 524
assign 1 55 527
new 0 55 527
assign 1 59 529
nextPeerGet 0 59 529
assign 1 60 532
def 1 60 537
assign 1 60 538
typenameGet 0 60 538
assign 1 60 539
DEFMODGet 0 60 539
assign 1 60 540
equals 1 60 540
assign 1 0 542
assign 1 0 545
assign 1 0 549
assign 1 61 552
nextPeerGet 0 61 552
assign 1 63 558
def 1 63 563
assign 1 63 564
typenameGet 0 63 564
assign 1 63 565
CLASSGet 0 63 565
assign 1 63 566
equals 1 63 566
assign 1 0 568
assign 1 0 571
assign 1 0 575
assign 1 64 578
assign 1 65 579
containedGet 0 65 579
assign 1 65 580
firstGet 0 65 580
assign 1 67 583
assign 1 70 585
undef 1 70 590
assign 1 71 591
new 0 71 591
assign 1 71 592
new 2 71 592
throw 1 71 593
assign 1 74 595
typenameGet 0 74 595
assign 1 74 596
IDGet 0 74 596
assign 1 74 597
equals 1 74 597
assign 1 75 599
new 0 75 599
assign 1 76 600
heldGet 0 76 600
addStep 1 76 601
assign 1 77 604
typenameGet 0 77 604
assign 1 77 605
NAMEPATHGet 0 77 605
assign 1 77 606
equals 1 77 606
assign 1 78 608
heldGet 0 78 608
assign 1 80 611
new 0 80 611
assign 1 80 612
new 2 80 612
throw 1 80 613
assign 1 83 616
assign 1 84 617
nextPeerGet 0 84 617
assign 1 85 618
typenameGet 0 85 618
assign 1 85 619
ASGet 0 85 619
assign 1 85 620
equals 1 85 620
assign 1 86 622
nextPeerGet 0 86 622
assign 1 87 623
typenameGet 0 87 623
assign 1 87 624
IDGet 0 87 624
assign 1 87 625
notEquals 1 87 625
assign 1 88 627
new 0 88 627
assign 1 88 628
new 2 88 628
throw 1 88 629
assign 1 90 631
heldGet 0 90 631
assign 1 93 633
undef 1 93 638
assign 1 94 639
nextPeerGet 0 94 639
delete 0 95 640
assign 1 97 641
typenameGet 0 97 641
assign 1 97 642
SEMIGet 0 97 642
assign 1 97 643
equals 1 97 643
assign 1 98 645
assign 1 99 646
nextPeerGet 0 99 646
delete 0 100 647
assign 1 103 651
heldSet 1 105 653
assign 1 107 654
transUnitGet 0 107 654
assign 1 109 655
undef 1 109 660
assign 1 110 661
new 0 110 661
assign 1 110 662
new 2 110 662
throw 1 110 663
assign 1 113 665
undef 1 113 670
assign 1 114 671
labelGet 0 114 671
assign 1 116 673
heldGet 0 116 673
assign 1 116 674
aliasedGet 0 116 674
put 2 116 675
assign 1 118 677
emitDataGet 0 118 677
assign 1 118 678
aliasedGet 0 118 678
put 2 118 679
return 1 121 681
assign 1 123 683
typenameGet 0 123 683
assign 1 123 684
CLASSGet 0 123 684
assign 1 123 685
equals 1 123 690
assign 1 124 691
new 0 124 691
assign 1 125 692
new 0 125 692
assign 1 126 693
new 0 126 693
assign 1 127 694
priorPeerGet 0 127 694
assign 1 128 695
new 0 128 695
assign 1 128 698
new 0 128 698
assign 1 128 699
lesser 1 128 704
assign 1 129 705
def 1 129 710
assign 1 130 711
typenameGet 0 130 711
assign 1 130 712
DEFMODGet 0 130 712
assign 1 130 713
equals 1 130 718
assign 1 131 719
typenameGet 0 131 719
assign 1 131 720
DEFMODGet 0 131 720
assign 1 131 721
equals 1 131 726
assign 1 131 727
heldGet 0 131 727
assign 1 131 728
new 0 131 728
assign 1 131 729
equals 1 131 729
assign 1 0 731
assign 1 0 734
assign 1 0 738
assign 1 132 741
new 0 132 741
assign 1 133 744
typenameGet 0 133 744
assign 1 133 745
DEFMODGet 0 133 745
assign 1 133 746
equals 1 133 751
assign 1 133 752
heldGet 0 133 752
assign 1 133 753
new 0 133 753
assign 1 133 754
equals 1 133 754
assign 1 0 756
assign 1 0 759
assign 1 0 763
assign 1 134 766
new 0 134 766
assign 1 135 769
typenameGet 0 135 769
assign 1 135 770
DEFMODGet 0 135 770
assign 1 135 771
equals 1 135 776
assign 1 135 777
heldGet 0 135 777
assign 1 135 778
new 0 135 778
assign 1 135 779
equals 1 135 779
assign 1 0 781
assign 1 0 784
assign 1 0 788
assign 1 136 791
new 0 136 791
assign 1 138 795
priorPeerGet 0 138 795
delete 0 139 796
assign 1 140 797
assign 1 142 800
assign 1 128 803
increment 0 128 803
assign 1 146 809
new 0 146 809
heldSet 1 146 810
assign 1 147 811
heldGet 0 147 811
assign 1 147 812
fromFileGet 0 147 812
fromFileSet 1 147 813
assign 1 149 815
containedGet 0 149 815
assign 1 149 816
firstGet 0 149 816
assign 1 150 817
typenameGet 0 150 817
assign 1 150 818
IDGet 0 150 818
assign 1 150 819
equals 1 150 819
assign 1 151 821
new 0 151 821
assign 1 152 822
heldGet 0 152 822
addStep 1 152 823
assign 1 153 826
typenameGet 0 153 826
assign 1 153 827
NAMEPATHGet 0 153 827
assign 1 153 828
equals 1 153 828
assign 1 154 830
heldGet 0 154 830
assign 1 156 833
new 0 156 833
assign 1 156 834
new 2 156 834
throw 1 156 835
assign 1 158 838
heldGet 0 158 838
namepathSet 1 158 839
assign 1 159 840
heldGet 0 159 840
isFinalSet 1 159 841
assign 1 160 842
heldGet 0 160 842
isLocalSet 1 160 843
assign 1 161 844
heldGet 0 161 844
isNotNullSet 1 161 845
delete 0 162 846
print 0 164 850
assign 1 165 851
new 0 165 851
assign 1 165 852
new 2 165 852
throw 1 165 853
assign 1 168 856
containedGet 0 168 856
assign 1 168 857
firstGet 0 168 857
assign 1 169 858
typenameGet 0 169 858
assign 1 169 859
PARENSGet 0 169 859
assign 1 169 860
equals 1 169 860
assign 1 170 862
containedGet 0 170 862
assign 1 170 863
lengthGet 0 170 863
assign 1 170 864
new 0 170 864
assign 1 170 865
greater 1 170 865
assign 1 171 867
new 0 171 867
assign 1 171 868
new 2 171 868
throw 1 171 869
assign 1 174 872
containedGet 0 174 872
assign 1 174 873
firstGet 0 174 873
assign 1 175 874
typenameGet 0 175 874
assign 1 175 875
IDGet 0 175 875
assign 1 175 876
equals 1 175 876
assign 1 176 878
heldGet 0 176 878
assign 1 176 879
new 0 176 879
extendsSet 1 176 880
assign 1 177 881
heldGet 0 177 881
assign 1 177 882
extendsGet 0 177 882
assign 1 177 883
heldGet 0 177 883
addStep 1 177 884
assign 1 178 887
typenameGet 0 178 887
assign 1 178 888
NAMEPATHGet 0 178 888
assign 1 178 889
equals 1 178 889
assign 1 179 891
heldGet 0 179 891
assign 1 179 892
heldGet 0 179 892
extendsSet 1 179 893
assign 1 181 896
new 0 181 896
assign 1 181 897
new 2 181 897
throw 1 181 898
print 0 185 904
assign 1 186 905
new 0 186 905
assign 1 186 906
new 2 186 906
throw 1 186 907
delete 0 188 909
print 0 191 914
assign 1 192 915
new 0 192 915
assign 1 192 916
new 2 192 916
throw 1 192 917
assign 1 195 919
heldGet 0 195 919
assign 1 195 920
extendsGet 0 195 920
assign 1 195 921
undef 1 195 926
assign 1 195 927
heldGet 0 195 927
assign 1 195 928
namepathGet 0 195 928
assign 1 195 929
toString 0 195 929
assign 1 195 930
new 0 195 930
assign 1 195 931
notEquals 1 195 931
assign 1 0 933
assign 1 0 936
assign 1 0 940
assign 1 196 943
heldGet 0 196 943
assign 1 196 944
new 0 196 944
assign 1 196 945
new 0 196 945
assign 1 196 946
fromString 1 196 946
extendsSet 1 196 947
assign 1 199 949
nextDescendGet 0 199 949
return 1 199 950
assign 1 201 952
typenameGet 0 201 952
assign 1 201 953
METHODGet 0 201 953
assign 1 201 954
equals 1 201 959
assign 1 202 960
new 0 202 960
heldSet 1 202 961
assign 1 203 962
priorPeerGet 0 203 962
assign 1 204 963
new 0 204 963
assign 1 204 966
new 0 204 966
assign 1 204 967
lesser 1 204 972
assign 1 205 973
def 1 205 978
assign 1 206 979
typenameGet 0 206 979
assign 1 206 980
DEFMODGet 0 206 980
assign 1 206 981
equals 1 206 986
assign 1 207 987
typenameGet 0 207 987
assign 1 207 988
DEFMODGet 0 207 988
assign 1 207 989
equals 1 207 994
assign 1 207 995
heldGet 0 207 995
assign 1 207 996
new 0 207 996
assign 1 207 997
equals 1 207 997
assign 1 0 999
assign 1 0 1002
assign 1 0 1006
assign 1 208 1009
heldGet 0 208 1009
assign 1 208 1010
new 0 208 1010
isFinalSet 1 208 1011
assign 1 209 1014
typenameGet 0 209 1014
assign 1 209 1015
DEFMODGet 0 209 1015
assign 1 209 1016
equals 1 209 1021
assign 1 209 1022
heldGet 0 209 1022
assign 1 209 1023
new 0 209 1023
assign 1 209 1024
equals 1 209 1024
assign 1 0 1026
assign 1 0 1029
assign 1 0 1033
assign 1 211 1036
new 0 211 1036
assign 1 211 1037
new 2 211 1037
throw 1 211 1038
assign 1 213 1041
priorPeerGet 0 213 1041
delete 0 214 1042
assign 1 215 1043
assign 1 217 1046
assign 1 204 1049
increment 0 204 1049
assign 1 222 1056
containedGet 0 222 1056
assign 1 222 1057
firstGet 0 222 1057
assign 1 223 1058
def 1 223 1063
assign 1 224 1064
nextPeerGet 0 224 1064
assign 1 225 1065
def 1 225 1070
assign 1 226 1071
nextPeerGet 0 226 1071
assign 1 227 1072
typenameGet 0 227 1072
assign 1 227 1073
IDGet 0 227 1073
assign 1 227 1074
equals 1 227 1074
assign 1 0 1076
assign 1 227 1079
typenameGet 0 227 1079
assign 1 227 1080
NAMEPATHGet 0 227 1080
assign 1 227 1081
equals 1 227 1081
assign 1 0 1083
assign 1 0 1086
assign 1 229 1090
typenameGet 0 229 1090
assign 1 229 1091
IDGet 0 229 1091
assign 1 229 1092
equals 1 229 1092
assign 1 230 1094
new 0 230 1094
assign 1 231 1095
heldGet 0 231 1095
addStep 1 231 1096
assign 1 233 1099
heldGet 0 233 1099
assign 1 235 1101
new 0 235 1101
assign 1 236 1102
new 0 236 1102
isTypedSet 1 236 1103
namepathSet 1 237 1104
assign 1 238 1105
VARGet 0 238 1105
typenameSet 1 238 1106
heldSet 1 239 1107
assign 1 242 1110
typenameGet 0 242 1110
assign 1 242 1111
IDGet 0 242 1111
assign 1 242 1112
equals 1 242 1112
assign 1 243 1114
heldGet 0 243 1114
assign 1 243 1115
heldGet 0 243 1115
nameSet 1 243 1116
assign 1 244 1117
heldGet 0 244 1117
assign 1 244 1118
nameGet 0 244 1118
assign 1 244 1119
new 0 244 1119
assign 1 244 1120
getPoint 1 244 1120
assign 1 244 1121
isInteger 0 244 1121
assign 1 245 1123
new 0 245 1123
assign 1 245 1124
new 2 245 1124
throw 1 245 1125
delete 0 247 1127
assign 1 249 1130
new 0 249 1130
assign 1 249 1131
new 2 249 1131
throw 1 249 1132
assign 1 252 1136
new 0 252 1136
assign 1 252 1137
new 2 252 1137
throw 1 252 1138
assign 1 255 1143
classNameGet 0 255 1143
assign 1 255 1144
new 0 255 1144
assign 1 255 1145
equals 1 255 1145
throw 1 255 1147
print 0 256 1149
assign 1 257 1150
new 0 257 1150
assign 1 257 1151
new 2 257 1151
throw 1 257 1152
assign 1 259 1154
nextDescendGet 0 259 1154
return 1 259 1155
assign 1 261 1157
constantsGet 0 261 1157
assign 1 261 1158
parensReqGet 0 261 1158
assign 1 261 1159
typenameGet 0 261 1159
assign 1 261 1160
has 1 261 1160
assign 1 262 1162
containedGet 0 262 1162
assign 1 262 1163
firstGet 0 262 1163
assign 1 263 1164
undef 1 263 1169
assign 1 0 1170
assign 1 263 1173
typenameGet 0 263 1173
assign 1 263 1174
PARENSGet 0 263 1174
assign 1 263 1175
notEquals 1 263 1175
assign 1 0 1177
assign 1 0 1180
assign 1 264 1184
new 0 264 1184
assign 1 264 1185
new 2 264 1185
throw 1 264 1186
assign 1 268 1189
typenameGet 0 268 1189
assign 1 268 1190
BRACESGet 0 268 1190
assign 1 268 1191
equals 1 268 1196
assign 1 269 1197
containerGet 0 269 1197
assign 1 270 1198
def 1 270 1203
assign 1 270 1204
typenameGet 0 270 1204
assign 1 270 1205
EXPRGet 0 270 1205
assign 1 270 1206
equals 1 270 1206
assign 1 0 1208
assign 1 0 1211
assign 1 0 1215
assign 1 271 1218
PARENSGet 0 271 1218
typenameSet 1 271 1219
assign 1 274 1222
typenameGet 0 274 1222
assign 1 274 1223
SEMIGet 0 274 1223
assign 1 274 1224
equals 1 274 1229
assign 1 275 1230
priorPeerGet 0 275 1230
assign 1 276 1231
nextAscendGet 0 276 1231
assign 1 280 1234
def 1 280 1239
assign 1 280 1240
typenameGet 0 280 1240
assign 1 280 1241
SEMIGet 0 280 1241
assign 1 280 1242
notEquals 1 280 1242
assign 1 0 1244
assign 1 0 1247
assign 1 0 1251
assign 1 280 1254
typenameGet 0 280 1254
assign 1 280 1255
BRACESGet 0 280 1255
assign 1 280 1256
notEquals 1 280 1256
assign 1 0 1258
assign 1 0 1261
assign 1 0 1265
assign 1 280 1268
typenameGet 0 280 1268
assign 1 280 1269
EXPRGet 0 280 1269
assign 1 280 1270
notEquals 1 280 1270
assign 1 0 1272
assign 1 0 1275
assign 1 0 1279
assign 1 281 1282
undef 1 281 1287
assign 1 282 1288
new 0 282 1288
prepend 1 284 1290
assign 1 285 1291
priorPeerGet 0 285 1291
assign 1 287 1297
def 1 287 1302
assign 1 288 1303
EXPRGet 0 288 1303
typenameSet 1 288 1304
heldSet 1 289 1305
assign 1 290 1306
new 1 290 1306
assign 1 291 1307
PARENSGet 0 291 1307
typenameSet 1 291 1308
addValue 1 292 1309
copyLoc 1 293 1310
assign 1 294 1311
iteratorGet 0 294 1311
assign 1 294 1314
hasNextGet 0 294 1314
assign 1 295 1316
nextGet 0 295 1316
delete 0 296 1317
addValue 1 297 1318
delete 0 304 1326
return 1 306 1328
assign 1 309 1330
nextDescendGet 0 309 1330
return 1 309 1331
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass5();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass5.bevs_inst = (BEC_3_5_5_5_BuildVisitPass5)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass5.bevs_inst;
}
}
