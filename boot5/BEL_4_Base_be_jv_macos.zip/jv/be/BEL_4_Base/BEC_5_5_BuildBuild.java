package be.BEL_4_Base;
/* File: source/build/Build.be */
public class BEC_5_5_BuildBuild extends BEC_6_6_SystemObject {
public BEC_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_6 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_7, 28));
private static byte[] bels_8 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_9 = {0x23,0x69,0x66,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_9, 12));
private static byte[] bels_10 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x65,0x78,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_10, 21));
private static byte[] bels_11 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_11, 6));
private static byte[] bels_12 = {0x23,0x69,0x66,0x6E,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_6 = (new BEC_4_6_TextString(bels_12, 13));
private static byte[] bels_13 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x69,0x6D,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_7 = (new BEC_4_6_TextString(bels_13, 21));
private static byte[] bels_14 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_8 = (new BEC_4_6_TextString(bels_14, 6));
private static byte[] bels_15 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_16 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_4_6_TextString bevo_9 = (new BEC_4_6_TextString(bels_16, 5));
private static byte[] bels_17 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_18 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_20 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_21 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_22 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_23 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_24 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_25 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_26 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_27 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_29 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_30 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_31 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_32 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_33 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_35 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_36 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_38 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_40 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_41 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x56,0x69,0x73,0x69,0x74,0x6F,0x72,0x73};
private static byte[] bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_44 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_45 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_46 = {0x72,0x75,0x6E};
private static byte[] bels_47 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_48 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_49 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_50 = {0x67,0x63,0x63};
private static byte[] bels_51 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_52 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_53 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_4_6_TextString bevo_10 = (new BEC_4_6_TextString(bels_53, 9));
private static byte[] bels_54 = {};
private static byte[] bels_55 = {0x63};
private static byte[] bels_56 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_4_6_TextString bevo_11 = (new BEC_4_6_TextString(bels_56, 8));
private static byte[] bels_57 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_4_6_TextString bevo_12 = (new BEC_4_6_TextString(bels_57, 7));
private static byte[] bels_58 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_59 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_60 = {0x6A,0x76};
private static BEC_4_6_TextString bevo_13 = (new BEC_4_6_TextString(bels_60, 2));
private static byte[] bels_61 = {0x63,0x73};
private static BEC_4_6_TextString bevo_14 = (new BEC_4_6_TextString(bels_61, 2));
private static byte[] bels_62 = {0x6A,0x73};
private static BEC_4_6_TextString bevo_15 = (new BEC_4_6_TextString(bels_62, 2));
private static byte[] bels_63 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_64 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_4_6_TextString bevo_16 = (new BEC_4_6_TextString(bels_64, 19));
private static byte[] bels_65 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_17 = (new BEC_4_6_TextString(bels_65, 31));
private static byte[] bels_66 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_18 = (new BEC_4_6_TextString(bels_66, 31));
private static byte[] bels_67 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_19 = (new BEC_4_6_TextString(bels_67, 41));
private static byte[] bels_68 = {0x2F};
private static byte[] bels_69 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_20 = (new BEC_4_6_TextString(bels_69, 31));
private static byte[] bels_70 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_21 = (new BEC_4_6_TextString(bels_70, 41));
private static byte[] bels_71 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_22 = (new BEC_4_6_TextString(bels_71, 51));
private static byte[] bels_72 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_23 = (new BEC_4_6_TextString(bels_72, 14));
private static byte[] bels_73 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_4_6_TextString bevo_24 = (new BEC_4_6_TextString(bels_73, 19));
private static byte[] bels_74 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_25 = (new BEC_4_6_TextString(bels_74, 9));
private static byte[] bels_75 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_4_6_TextString bevo_26 = (new BEC_4_6_TextString(bels_75, 13));
private static byte[] bels_76 = {0x2E,0x20};
private static BEC_4_6_TextString bevo_27 = (new BEC_4_6_TextString(bels_76, 2));
private static byte[] bels_77 = {0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_28 = (new BEC_4_6_TextString(bels_77, 3));
private static byte[] bels_78 = {0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_29 = (new BEC_4_6_TextString(bels_78, 4));
private static byte[] bels_79 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_30 = (new BEC_4_6_TextString(bels_79, 5));
private static byte[] bels_80 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_31 = (new BEC_4_6_TextString(bels_80, 6));
private static byte[] bels_81 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_32 = (new BEC_4_6_TextString(bels_81, 7));
private static byte[] bels_82 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_33 = (new BEC_4_6_TextString(bels_82, 8));
private static byte[] bels_83 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_34 = (new BEC_4_6_TextString(bels_83, 9));
private static byte[] bels_84 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_35 = (new BEC_4_6_TextString(bels_84, 10));
private static byte[] bels_85 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_36 = (new BEC_4_6_TextString(bels_85, 11));
private static byte[] bels_86 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_37 = (new BEC_4_6_TextString(bels_86, 12));
private static byte[] bels_87 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_38 = (new BEC_4_6_TextString(bels_87, 13));
private static byte[] bels_88 = {0x20};
private static BEC_4_6_TextString bevo_39 = (new BEC_4_6_TextString(bels_88, 1));
private static byte[] bels_89 = {0x50,0x72,0x69,0x6E,0x74,0x41,0x53,0x54};
private static BEC_4_6_TextString bevo_40 = (new BEC_4_6_TextString(bels_89, 8));
public static BEC_5_5_BuildBuild bevs_inst;
public BEC_4_6_TextString bevp_mainName;
public BEC_4_6_TextString bevp_libName;
public BEC_4_6_TextString bevp_exeName;
public BEC_6_6_SystemObject bevp_emitFileHeader;
public BEC_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_9_10_ContainerLinkedList bevp_extLibs;
public BEC_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_6_6_SystemObject bevp_fromFile;
public BEC_6_6_SystemObject bevp_platform;
public BEC_6_6_SystemObject bevp_outputPlatform;
public BEC_6_6_SystemObject bevp_emitLibrary;
public BEC_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_4_6_TextString bevp_nl;
public BEC_4_6_TextString bevp_newline;
public BEC_6_6_SystemObject bevp_runArgs;
public BEC_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_5_14_BuildCCallAssembler bevp_cassem;
public BEC_9_5_ContainerArray bevp_args;
public BEC_6_10_SystemParameters bevp_params;
public BEC_5_4_LogicBool bevp_buildSucceeded;
public BEC_4_6_TextString bevp_buildMessage;
public BEC_4_8_TimeInterval bevp_startTime;
public BEC_4_8_TimeInterval bevp_parseTime;
public BEC_4_8_TimeInterval bevp_parseEmitTime;
public BEC_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_2_4_4_IOFilePath bevp_buildPath;
public BEC_6_6_SystemObject bevp_includePath;
public BEC_9_3_ContainerMap bevp_built;
public BEC_9_10_ContainerLinkedList bevp_toBuild;
public BEC_5_4_LogicBool bevp_printVisitors;
public BEC_5_4_LogicBool bevp_printAst;
public BEC_5_4_LogicBool bevp_doEmit;
public BEC_5_4_LogicBool bevp_emitDebug;
public BEC_5_4_LogicBool bevp_parse;
public BEC_5_4_LogicBool bevp_prepMake;
public BEC_5_4_LogicBool bevp_make;
public BEC_5_4_LogicBool bevp_genOnly;
public BEC_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_5_8_BuildEmitData bevp_emitData;
public BEC_2_4_4_IOFilePath bevp_emitPath;
public BEC_6_6_SystemObject bevp_code;
public BEC_4_6_TextString bevp_estr;
public BEC_6_6_SystemObject bevp_sharedEmitter;
public BEC_5_9_BuildConstants bevp_constants;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_4_9_TextTokenizer bevp_twtok;
public BEC_4_9_TextTokenizer bevp_lctok;
public BEC_5_7_BuildLibrary bevp_deployLibrary;
public BEC_4_6_TextString bevp_deployPath;
public BEC_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_9_3_ContainerSet bevp_closeLibraries;
public BEC_5_4_LogicBool bevp_run;
public BEC_4_6_TextString bevp_compiler;
public BEC_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_4_6_TextString bevp_makeName;
public BEC_4_6_TextString bevp_makeArgs;
public BEC_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_5_4_LogicBool bevp_dynConditionsAll;
public BEC_4_6_TextString bevp_readBuffer;
public BEC_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_printVisitors = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAst = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parse = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_make = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_genOnly = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(3, bels_0));
bevp_lctok = (new BEC_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isNewish_1(BEC_4_6_TextString beva_name) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 99 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 99 */
 else  /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 99 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 100 */
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_process_1(BEC_4_6_TextString beva_arg) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_main_0() throws Throwable {
BEC_9_5_ContainerArray bevl__args = null;
BEC_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_7_SystemProcess) BEC_6_7_SystemProcess.bevs_inst.bem_new_0();
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = this.bem_main_1(bevl__args);
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_main_1(BEC_9_5_ContainerArray beva__args) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_0_tmpvar_phold = this.bem_go_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_go_0() throws Throwable {
BEC_4_3_MathInt bevl_whatResult = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_whatResult = (new BEC_4_3_MathInt(1));
this.bem_config_0();
try  /* Line: 123 */ {
bevp_buildMessage = (new BEC_4_6_TextString(16, bels_5));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (new BEC_4_6_TextString(14, bels_6));
} /* Line: 126 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevt_0_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_0_tmpvar_phold.bem_add_1(bevl_e);
bevl_whatResult = (new BEC_4_3_MathInt(1));
} /* Line: 129 */
bevp_buildMessage.bem_print_0();
return bevl_whatResult;
} /*method end*/
public BEC_4_6_TextString bem_dllhead_1(BEC_4_6_TextString beva_addTo) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(5, bels_8));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 136 */ {
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = beva_addTo.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevt_7_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_addTo.bem_add_1(bevt_7_tmpvar_phold);
beva_addTo = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
bevt_9_tmpvar_phold = bevo_5;
bevt_8_tmpvar_phold = beva_addTo.bem_add_1(bevt_9_tmpvar_phold);
beva_addTo = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
bevt_12_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold = beva_addTo.bem_add_1(bevt_12_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_10_tmpvar_phold.bem_add_1(bevp_nl);
bevt_14_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold = beva_addTo.bem_add_1(bevt_14_tmpvar_phold);
beva_addTo = bevt_13_tmpvar_phold.bem_add_1(bevp_nl);
bevt_16_tmpvar_phold = bevo_8;
bevt_15_tmpvar_phold = beva_addTo.bem_add_1(bevt_16_tmpvar_phold);
beva_addTo = bevt_15_tmpvar_phold.bem_add_1(bevp_nl);
} /* Line: 142 */
return beva_addTo;
} /*method end*/
public BEC_6_6_SystemObject bem_config_0() throws Throwable {
BEC_4_6_TextString bevl_istr = null;
BEC_9_3_ContainerSet bevl_bfiles = null;
BEC_4_6_TextString bevl_bkey = null;
BEC_4_6_TextString bevl_outLang = null;
BEC_6_6_SystemObject bevl_platformSources = null;
BEC_6_6_SystemObject bevl_langSources = null;
BEC_6_6_SystemObject bevl_emr = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_3_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_IOFile bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_IOFile bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_IOFile bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_88_tmpvar_phold = null;
BEC_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_92_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_94_tmpvar_phold = null;
BEC_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_98_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_101_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_IOFile bevt_104_tmpvar_phold = null;
BEC_2_4_IOFile bevt_105_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_106_tmpvar_phold = null;
BEC_2_4_IOFile bevt_107_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_108_tmpvar_phold = null;
bevl_bfiles = (new BEC_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_4_6_TextString(9, bels_15));
bevt_3_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 152 */ {
bevt_4_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_4_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 153 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 153 */ {
bevl_istr = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_7_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_not_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_8_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_8_tmpvar_phold);
} /* Line: 156 */
} /* Line: 154 */
 else  /* Line: 153 */ {
break;
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
bevt_11_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_nameGet_0();
bevt_12_tmpvar_phold = bevo_9;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_equals_1(bevt_12_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 162 */
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(11, bels_17));
bevt_13_tmpvar_phold = bevp_params.bem_get_1(bevt_14_tmpvar_phold);
bevp_libName = (BEC_4_6_TextString) bevt_13_tmpvar_phold.bem_firstGet_0();
bevt_16_tmpvar_phold = (new BEC_4_6_TextString(7, bels_18));
bevt_15_tmpvar_phold = bevp_params.bem_has_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 165 */ {
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(7, bels_19));
bevt_17_tmpvar_phold = bevp_params.bem_get_1(bevt_18_tmpvar_phold);
bevp_exeName = (BEC_4_6_TextString) bevt_17_tmpvar_phold.bem_firstGet_0();
} /* Line: 166 */
 else  /* Line: 167 */ {
bevp_exeName = bevp_libName;
} /* Line: 168 */
bevt_22_tmpvar_phold = (new BEC_4_6_TextString(9, bels_20));
bevt_23_tmpvar_phold = (new BEC_4_6_TextString(6, bels_21));
bevt_21_tmpvar_phold = bevp_params.bem_get_2(bevt_22_tmpvar_phold, bevt_23_tmpvar_phold);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_firstGet_0();
bevt_19_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevt_20_tmpvar_phold);
bevp_buildPath = bevt_19_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_24_tmpvar_phold = (new BEC_4_6_TextString(6, bels_22));
bevp_buildPath.bem_addStep_1(bevt_24_tmpvar_phold);
bevt_28_tmpvar_phold = (new BEC_4_6_TextString(11, bels_23));
bevt_29_tmpvar_phold = (new BEC_4_6_TextString(7, bels_24));
bevt_27_tmpvar_phold = bevp_params.bem_get_2(bevt_28_tmpvar_phold, bevt_29_tmpvar_phold);
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_firstGet_0();
bevt_25_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevt_26_tmpvar_phold);
bevp_includePath = bevt_25_tmpvar_phold.bem_pathGet_0();
bevt_32_tmpvar_phold = (new BEC_4_6_TextString(8, bels_25));
bevt_34_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_nameGet_0();
bevt_31_tmpvar_phold = bevp_params.bem_get_2(bevt_32_tmpvar_phold, bevt_33_tmpvar_phold);
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_30_tmpvar_phold);
bevt_37_tmpvar_phold = (new BEC_4_6_TextString(14, bels_26));
bevt_38_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_36_tmpvar_phold = bevp_params.bem_get_2(bevt_37_tmpvar_phold, (BEC_4_6_TextString) bevt_38_tmpvar_phold);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_35_tmpvar_phold);
bevt_41_tmpvar_phold = (new BEC_4_6_TextString(16, bels_27));
bevt_42_tmpvar_phold = (new BEC_4_6_TextString(5, bels_28));
bevt_40_tmpvar_phold = bevp_params.bem_get_2(bevt_41_tmpvar_phold, bevt_42_tmpvar_phold);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_5_4_LogicBool()).bem_new_1(bevt_39_tmpvar_phold);
bevt_44_tmpvar_phold = (new BEC_4_6_TextString(9, bels_29));
bevt_43_tmpvar_phold = bevp_params.bem_get_1(bevt_44_tmpvar_phold);
bevp_mainName = (BEC_4_6_TextString) bevt_43_tmpvar_phold.bem_firstGet_0();
bevt_46_tmpvar_phold = (new BEC_4_6_TextString(10, bels_30));
bevt_45_tmpvar_phold = bevp_params.bem_get_1(bevt_46_tmpvar_phold);
bevp_deployPath = (BEC_4_6_TextString) bevt_45_tmpvar_phold.bem_firstGet_0();
bevt_47_tmpvar_phold = (new BEC_4_6_TextString(10, bels_31));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_47_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 181 */ {
bevp_usedLibrarysStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 182 */
bevt_49_tmpvar_phold = (new BEC_4_6_TextString(15, bels_32));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_49_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 185 */ {
bevp_closeLibrariesStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 186 */
bevt_51_tmpvar_phold = (new BEC_4_6_TextString(14, bels_33));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_51_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 189 */ {
bevp_deployFilesFrom = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 190 */
bevt_53_tmpvar_phold = (new BEC_4_6_TextString(12, bels_34));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 193 */ {
bevp_deployFilesTo = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 194 */
bevt_55_tmpvar_phold = (new BEC_4_6_TextString(10, bels_35));
bevp_extIncludes = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 197 */ {
bevp_extIncludes = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 198 */
bevt_57_tmpvar_phold = (new BEC_4_6_TextString(9, bels_36));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 201 */ {
bevp_ccObjArgs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 202 */
bevt_59_tmpvar_phold = (new BEC_4_6_TextString(6, bels_37));
bevp_extLibs = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevp_extLibs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 206 */
bevt_61_tmpvar_phold = (new BEC_4_6_TextString(11, bels_38));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 209 */ {
bevp_linkLibArgs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 210 */
bevt_63_tmpvar_phold = (new BEC_4_6_TextString(13, bels_39));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevp_extLinkObjects = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 214 */
bevt_65_tmpvar_phold = (new BEC_4_6_TextString(14, bels_40));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 217 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 218 */
bevt_67_tmpvar_phold = (new BEC_4_6_TextString(7, bels_41));
bevp_runArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 221 */ {
bevp_runArgs = bevp_runArgs.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 222 */
 else  /* Line: 223 */ {
bevp_runArgs = (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 224 */
bevt_69_tmpvar_phold = (new BEC_4_6_TextString(13, bels_42));
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_printVisitors = bevp_params.bem_isTrue_2(bevt_69_tmpvar_phold, bevt_70_tmpvar_phold);
bevt_71_tmpvar_phold = (new BEC_4_6_TextString(8, bels_43));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_71_tmpvar_phold);
bevt_72_tmpvar_phold = (new BEC_4_6_TextString(7, bels_44));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_72_tmpvar_phold);
bevt_73_tmpvar_phold = (new BEC_4_6_TextString(19, bels_45));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_73_tmpvar_phold);
bevt_74_tmpvar_phold = (new BEC_4_6_TextString(3, bels_46));
bevp_run = bevp_params.bem_isTrue_1(bevt_74_tmpvar_phold);
bevt_75_tmpvar_phold = (new BEC_4_6_TextString(21, bels_47));
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (new BEC_4_6_TextString(8, bels_48));
bevp_emitLangs = bevp_params.bem_get_1(bevt_77_tmpvar_phold);
bevt_79_tmpvar_phold = (new BEC_4_6_TextString(8, bels_49));
bevt_80_tmpvar_phold = (new BEC_4_6_TextString(3, bels_50));
bevt_78_tmpvar_phold = bevp_params.bem_get_2(bevt_79_tmpvar_phold, bevt_80_tmpvar_phold);
bevp_compiler = (BEC_4_6_TextString) bevt_78_tmpvar_phold.bem_firstGet_0();
bevt_82_tmpvar_phold = (new BEC_4_6_TextString(4, bels_51));
bevt_83_tmpvar_phold = (new BEC_4_6_TextString(4, bels_52));
bevt_81_tmpvar_phold = bevp_params.bem_get_2(bevt_82_tmpvar_phold, bevt_83_tmpvar_phold);
bevp_makeName = (BEC_4_6_TextString) bevt_81_tmpvar_phold.bem_firstGet_0();
bevt_86_tmpvar_phold = bevo_10;
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_87_tmpvar_phold = (new BEC_4_6_TextString(0, bels_54));
bevt_84_tmpvar_phold = bevp_params.bem_get_2(bevt_85_tmpvar_phold, bevt_87_tmpvar_phold);
bevp_makeArgs = (BEC_4_6_TextString) bevt_84_tmpvar_phold.bem_firstGet_0();
bevp_parse = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_make = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_88_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevl_outLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 244 */
 else  /* Line: 245 */ {
bevl_outLang = (new BEC_4_6_TextString(1, bels_55));
} /* Line: 246 */
bevt_91_tmpvar_phold = bevo_11;
bevt_90_tmpvar_phold = bevl_outLang.bem_add_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bem_add_1(bevt_92_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_89_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevt_94_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_94_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 255 */
bevt_96_tmpvar_phold = bevo_12;
bevt_95_tmpvar_phold = bevl_outLang.bem_add_1(bevt_96_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_95_tmpvar_phold);
if (bevl_langSources == null) {
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevt_98_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_98_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 260 */
bevp_toBuild = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_99_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_1_tmpvar_loop = bevt_99_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 264 */ {
bevt_100_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_100_tmpvar_phold != null && bevt_100_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_100_tmpvar_phold).bevi_bool) /* Line: 264 */ {
bevl_istr = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_101_tmpvar_phold = (new BEC_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_101_tmpvar_phold);
} /* Line: 265 */
 else  /* Line: 264 */ {
break;
} /* Line: 264 */
} /* Line: 264 */
bevp_newline = (BEC_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_104_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bem_existsGet_0();
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bem_not_0();
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_105_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_105_tmpvar_phold.bem_makeDirs_0();
} /* Line: 273 */
if (bevp_emitFileHeader == null) {
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_106_tmpvar_phold.bevi_bool) /* Line: 275 */ {
bevt_107_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_107_tmpvar_phold.bem_readerGet_0();
bevt_108_tmpvar_phold = bevl_emr.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_108_tmpvar_phold.bemd_1(347960121, BEL_4_Base.bevn_readString_1, bevp_readBuffer);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 278 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_6_6_SystemObject bevl_toRet = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(13, bels_58));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(12, bels_59));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_6_6_SystemObject bem_setClassesToWrite_0() throws Throwable {
BEC_9_3_ContainerSet bevl_toEmit = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_9_3_ContainerSet bevl_usedBy = null;
BEC_4_6_TextString bevl_ub = null;
BEC_9_3_ContainerSet bevl_subClasses = null;
BEC_4_6_TextString bevl_sc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 292 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 292 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_iteratorGet_0();
while (true)
 /* Line: 298 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 298 */ {
bevl_ub = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 299 */
 else  /* Line: 298 */ {
break;
} /* Line: 298 */
} /* Line: 298 */
} /* Line: 298 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 303 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_iteratorGet_0();
while (true)
 /* Line: 304 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 304 */ {
bevl_sc = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 305 */
 else  /* Line: 304 */ {
break;
} /* Line: 304 */
} /* Line: 304 */
} /* Line: 304 */
} /* Line: 303 */
} /* Line: 294 */
 else  /* Line: 292 */ {
break;
} /* Line: 292 */
} /* Line: 292 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 310 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 310 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 312 */
 else  /* Line: 310 */ {
break;
} /* Line: 310 */
} /* Line: 310 */
return this;
} /*method end*/
public BEC_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_4_6_TextString bevl_emitLang = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 323 */ {
return bevp_emitCommon;
} /* Line: 324 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 329 */ {
bevl_emitLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_13;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 331 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 332 */
 else  /* Line: 331 */ {
bevt_5_tmpvar_phold = bevo_14;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 333 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 334 */
 else  /* Line: 331 */ {
bevt_7_tmpvar_phold = bevo_15;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 335 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 336 */
 else  /* Line: 337 */ {
bevt_9_tmpvar_phold = (new BEC_4_6_TextString(49, bels_63));
bevt_8_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 338 */
} /* Line: 331 */
} /* Line: 331 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 341 */
return null;
} /*method end*/
public BEC_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_6_6_SystemObject bevl_em = null;
BEC_9_3_ContainerSet bevl_ulibs = null;
BEC_6_6_SystemObject bevl_ups = null;
BEC_6_6_SystemObject bevl_pack = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_tb = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_bp = null;
BEC_6_6_SystemObject bevl_cpFrom = null;
BEC_6_6_SystemObject bevl_cpTo = null;
BEC_6_6_SystemObject bevl_fIter = null;
BEC_6_6_SystemObject bevl_tIter = null;
BEC_4_3_MathInt bevl_result = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_19_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
bevp_startTime = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_emitData = (new BEC_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 351 */ {
bevp_deployLibrary = (new BEC_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
bevt_6_tmpvar_phold = bevo_16;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevp_libName);
bevt_5_tmpvar_phold.bem_print_0();
} /* Line: 354 */
bevl_ulibs = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 358 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 358 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 359 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 362 */
} /* Line: 359 */
 else  /* Line: 358 */ {
break;
} /* Line: 358 */
} /* Line: 358 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 365 */ {
bevt_10_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 365 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_not_0();
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 366 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_13_tmpvar_phold = bevl_pack.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_13_tmpvar_phold);
} /* Line: 370 */
} /* Line: 366 */
 else  /* Line: 365 */ {
break;
} /* Line: 365 */
} /* Line: 365 */
if (bevp_parse.bevi_bool) /* Line: 373 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 375 */ {
bevt_14_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 375 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 378 */
 else  /* Line: 375 */ {
break;
} /* Line: 375 */
} /* Line: 375 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 380 */
bevt_15_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseTime = bevt_15_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_17_tmpvar_phold = bevo_17;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_16_tmpvar_phold.bem_print_0();
bevt_19_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_19_tmpvar_phold == null) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevt_20_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_20_tmpvar_phold.bem_doEmit_0();
bevt_21_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_21_tmpvar_phold;
} /* Line: 388 */
if (bevp_doEmit.bevi_bool) /* Line: 390 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevp_cassem = (new BEC_5_14_BuildCCallAssembler()).bem_new_1(this);
bevt_22_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_22_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 394 */ {
bevt_23_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 394 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 396 */
 else  /* Line: 394 */ {
break;
} /* Line: 394 */
} /* Line: 394 */
bevl_em.bemd_0(1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_24_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_24_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 400 */ {
bevt_25_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 400 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 402 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
} /* Line: 400 */
bevt_26_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitTime = bevt_26_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevt_29_tmpvar_phold = bevo_18;
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_28_tmpvar_phold.bem_print_0();
} /* Line: 408 */
bevt_31_tmpvar_phold = bevo_19;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_30_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 411 */ {
bevl_em.bemd_1(1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 413 */
if (bevp_make.bevi_bool) /* Line: 416 */ {
bevt_32_tmpvar_phold = bevp_genOnly.bem_not_0();
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 417 */ {
bevl_em.bemd_1(1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 420 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_iteratorGet_0();
while (true)
 /* Line: 421 */ {
bevt_33_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 421 */ {
bevl_bp = bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_34_tmpvar_phold.bemd_0(159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_35_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_35_tmpvar_phold.bem_copy_0();
bevt_37_tmpvar_phold = bevl_cpFrom.bemd_0(723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_38_tmpvar_phold != null && bevt_38_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_38_tmpvar_phold).bevi_bool) /* Line: 425 */ {
bevt_40_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_40_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 426 */
bevt_43_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 428 */ {
bevt_44_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_45_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_44_tmpvar_phold, bevt_45_tmpvar_phold);
} /* Line: 429 */
} /* Line: 428 */
 else  /* Line: 421 */ {
break;
} /* Line: 421 */
} /* Line: 421 */
} /* Line: 421 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 436 */ {
bevt_46_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 436 */ {
bevt_47_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 436 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 436 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 436 */
 else  /* Line: 436 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 436 */ {
bevt_48_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_48_tmpvar_phold);
bevt_53_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_copy_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_54_tmpvar_phold = (new BEC_4_6_TextString(1, bels_68));
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_55_tmpvar_phold);
bevl_cpTo = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_49_tmpvar_phold);
bevt_57_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_56_tmpvar_phold != null && bevt_56_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_56_tmpvar_phold).bevi_bool) /* Line: 440 */ {
bevt_58_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_58_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 441 */
bevt_61_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 443 */ {
bevt_62_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_63_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_62_tmpvar_phold, bevt_63_tmpvar_phold);
} /* Line: 444 */
} /* Line: 443 */
 else  /* Line: 436 */ {
break;
} /* Line: 436 */
} /* Line: 436 */
} /* Line: 436 */
} /* Line: 417 */
bevt_64_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitCompileTime = bevt_64_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 451 */ {
bevt_67_tmpvar_phold = bevo_20;
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_66_tmpvar_phold.bem_print_0();
} /* Line: 452 */
if (bevp_parseEmitTime == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 454 */ {
bevt_70_tmpvar_phold = bevo_21;
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_69_tmpvar_phold.bem_print_0();
} /* Line: 455 */
if (bevp_parseEmitCompileTime == null) {
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 457 */ {
bevt_73_tmpvar_phold = bevo_22;
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_72_tmpvar_phold.bem_print_0();
} /* Line: 458 */
if (bevp_run.bevi_bool) /* Line: 461 */ {
bevt_74_tmpvar_phold = bevo_23;
bevt_74_tmpvar_phold.bem_print_0();
bevl_result = (BEC_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_77_tmpvar_phold = bevo_24;
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_add_1(bevl_result);
bevt_78_tmpvar_phold = bevo_25;
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bem_add_1(bevt_78_tmpvar_phold);
bevt_75_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 465 */
bevt_79_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_79_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSyns_1(BEC_6_6_SystemObject beva_em) throws Throwable {
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_kls = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 471 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 471 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 475 */
 else  /* Line: 471 */ {
break;
} /* Line: 471 */
} /* Line: 471 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 477 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 477 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 481 */
 else  /* Line: 477 */ {
break;
} /* Line: 477 */
} /* Line: 477 */
bevt_6_tmpvar_phold = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_getSyn_2(BEC_6_6_SystemObject beva_klass, BEC_6_6_SystemObject beva_em) throws Throwable {
BEC_6_6_SystemObject bevl_syn = null;
BEC_6_6_SystemObject bevl_pklass = null;
BEC_6_6_SystemObject bevl_psyn = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 487 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 488 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 491 */ {
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 492 */
 else  /* Line: 493 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 496 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 498 */
 else  /* Line: 499 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 501 */
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 503 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevt_18_tmpvar_phold, (BEC_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public BEC_5_8_BuildClassSyn bem_getSynNp_1(BEC_6_6_SystemObject beva_np) throws Throwable {
BEC_6_6_SystemObject bevl_nps = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 513 */ {
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /* Line: 514 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevl_nps, (BEC_5_8_BuildClassSyn) bevl_syn);
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 529 */ {
bevp_sharedEmitter = (new BEC_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 530 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_6_6_SystemObject bem_doParse_1(BEC_6_6_SystemObject beva_toParse) throws Throwable {
BEC_6_6_SystemObject bevl_trans = null;
BEC_6_6_SystemObject bevl_blank = null;
BEC_6_6_SystemObject bevl_emitter = null;
BEC_5_4_LogicBool bevl_parseThis = null;
BEC_6_6_SystemObject bevl_src = null;
BEC_9_10_ContainerLinkedList bevl_toks = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_tunode = null;
BEC_6_6_SystemObject bevl_ntunode = null;
BEC_6_6_SystemObject bevl_ntt = null;
BEC_9_3_ContainerSet bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass2 bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass3 bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass4 bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass5 bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass6 bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass7 bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass8 bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass9 bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass10 bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass11 bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass12 bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_35_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
bevl_trans = (new BEC_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_0_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 543 */ {
bevt_2_tmpvar_phold = bevo_26;
bevt_3_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_1_tmpvar_phold.bem_print_0();
bevp_fromFile = beva_toParse;
bevt_6_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_4_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_8_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_7_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
bevt_9_tmpvar_phold = bevl_trans.bemd_0(1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_9_tmpvar_phold, bevl_toks);
if (bevp_printVisitors.bevi_bool) /* Line: 559 */ {
bevt_10_tmpvar_phold = bevo_27;
bevt_10_tmpvar_phold.bem_echo_0();
} /* Line: 560 */
bevt_11_tmpvar_phold = (BEC_5_5_5_BuildVisitPass2) (new BEC_5_5_5_BuildVisitPass2()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_11_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 563 */ {
bevt_12_tmpvar_phold = bevo_28;
bevt_12_tmpvar_phold.bem_echo_0();
} /* Line: 564 */
bevt_13_tmpvar_phold = (BEC_5_5_5_BuildVisitPass3) (new BEC_5_5_5_BuildVisitPass3()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_13_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 569 */ {
bevt_14_tmpvar_phold = bevo_29;
bevt_14_tmpvar_phold.bem_echo_0();
} /* Line: 570 */
bevl_trans.bemd_0(410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printVisitors.bevi_bool) /* Line: 574 */ {
bevt_15_tmpvar_phold = bevo_30;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 575 */
bevt_16_tmpvar_phold = (BEC_5_5_5_BuildVisitPass4) (new BEC_5_5_5_BuildVisitPass4()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 579 */ {
bevt_17_tmpvar_phold = bevo_31;
bevt_17_tmpvar_phold.bem_echo_0();
} /* Line: 580 */
bevt_18_tmpvar_phold = (BEC_5_5_5_BuildVisitPass5) (new BEC_5_5_5_BuildVisitPass5()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 584 */ {
bevt_19_tmpvar_phold = bevo_32;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 585 */
bevt_20_tmpvar_phold = (BEC_5_5_5_BuildVisitPass6) (new BEC_5_5_5_BuildVisitPass6()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 589 */ {
bevt_21_tmpvar_phold = bevo_33;
bevt_21_tmpvar_phold.bem_echo_0();
} /* Line: 590 */
bevt_22_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 594 */ {
bevt_23_tmpvar_phold = bevo_34;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 595 */
bevt_24_tmpvar_phold = (BEC_5_5_5_BuildVisitPass8) (new BEC_5_5_5_BuildVisitPass8()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 599 */ {
bevt_25_tmpvar_phold = bevo_35;
bevt_25_tmpvar_phold.bem_echo_0();
} /* Line: 600 */
bevt_26_tmpvar_phold = (BEC_5_5_5_BuildVisitPass9) (new BEC_5_5_5_BuildVisitPass9()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 604 */ {
bevt_27_tmpvar_phold = bevo_36;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 605 */
bevt_28_tmpvar_phold = (BEC_5_5_6_BuildVisitPass10) (new BEC_5_5_6_BuildVisitPass10()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 609 */ {
bevt_29_tmpvar_phold = bevo_37;
bevt_29_tmpvar_phold.bem_echo_0();
} /* Line: 610 */
bevt_30_tmpvar_phold = (new BEC_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 614 */ {
bevt_31_tmpvar_phold = bevo_38;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 615 */
bevt_32_tmpvar_phold = bevo_39;
bevt_32_tmpvar_phold.bem_print_0();
bevt_33_tmpvar_phold = (new BEC_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_33_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 619 */ {
if (bevp_printVisitors.bevi_bool) /* Line: 620 */ {
bevt_34_tmpvar_phold = bevo_40;
bevt_34_tmpvar_phold.bem_print_0();
} /* Line: 621 */
bevt_35_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_1(bevp_printAst);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_35_tmpvar_phold);
} /* Line: 623 */
bevt_36_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_36_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 625 */ {
bevt_37_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 625 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_38_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_38_tmpvar_phold);
bevl_ntt = (new BEC_5_9_BuildTransUnit()).bem_new_0();
bevt_40_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(557204364, BEL_4_Base.bevn_emitsSet_1, bevt_39_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 636 */
 else  /* Line: 625 */ {
break;
} /* Line: 625 */
} /* Line: 625 */
} /* Line: 625 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_nodify_2(BEC_6_6_SystemObject beva_parnode, BEC_6_6_SystemObject beva_toks) throws Throwable {
BEC_9_8_ContainerNodeList bevl_con = null;
BEC_6_6_SystemObject bevl_nlc = null;
BEC_4_6_TextString bevl_cr = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_node = null;
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 646 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 646 */ {
bevl_node = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 650 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 651 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 653 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 655 */
} /* Line: 653 */
 else  /* Line: 646 */ {
break;
} /* Line: 646 */
} /* Line: 646 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_6_6_SystemObject bem_mainNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mainName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_6_6_SystemObject bem_libNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_6_6_SystemObject bem_exeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_exeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_6_6_SystemObject bem_extIncludesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extIncludes = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_ccObjArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ccObjArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_6_6_SystemObject bem_extLibsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLibs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_linkLibArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_linkLibArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLinkObjects = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_6_6_SystemObject bem_platformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_6_6_SystemObject bem_outputPlatformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_6_6_SystemObject bem_deployFilesFromSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_6_6_SystemObject bem_deployFilesToSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesTo = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nl = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_6_6_SystemObject bem_newlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_runArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_6_6_SystemObject bem_compilerProfileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compilerProfile = (BEC_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_14_BuildCCallAssembler bem_cassemGet_0() throws Throwable {
return bevp_cassem;
} /*method end*/
public BEC_6_6_SystemObject bem_cassemSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_cassem = (BEC_5_14_BuildCCallAssembler) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_6_6_SystemObject bem_argsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_args = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_6_6_SystemObject bem_paramsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_params = (BEC_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSucceededSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildSucceeded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_6_6_SystemObject bem_buildMessageSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildMessage = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_6_6_SystemObject bem_startTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_startTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_6_6_SystemObject bem_buildPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_6_6_SystemObject bem_includePathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_6_6_SystemObject bem_builtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_built = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_6_6_SystemObject bem_toBuildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_toBuild = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printVisitorsGet_0() throws Throwable {
return bevp_printVisitors;
} /*method end*/
public BEC_6_6_SystemObject bem_printVisitorsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printVisitors = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_6_6_SystemObject bem_printAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_6_6_SystemObject bem_doEmitSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_doEmit = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_6_6_SystemObject bem_emitDebugSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitDebug = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_6_6_SystemObject bem_parseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parse = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_6_6_SystemObject bem_prepMakeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_prepMake = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_6_6_SystemObject bem_makeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_make = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_6_6_SystemObject bem_genOnlySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_genOnly = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_6_6_SystemObject bem_emitDataSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitData = (BEC_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_6_6_SystemObject bem_emitPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_6_6_SystemObject bem_codeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_6_6_SystemObject bem_estrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_estr = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_6_6_SystemObject bem_sharedEmitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_6_6_SystemObject bem_constantsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_constants = (BEC_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_6_6_SystemObject bem_twtokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_twtok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_6_6_SystemObject bem_lctokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lctok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_6_6_SystemObject bem_deployLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployLibrary = (BEC_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_6_6_SystemObject bem_deployPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployPath = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarys = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibraries = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_6_6_SystemObject bem_runSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_run = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_6_6_SystemObject bem_compilerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compiler = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLangsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLangs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_6_6_SystemObject bem_makeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_makeArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeArgs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_dynConditionsAllGet_0() throws Throwable {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_dynConditionsAll = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_6_6_SystemObject bem_readBufferSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_readBuffer = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitCommonSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {61, 63, 64, 65, 66, 67, 68, 69, 70, 71, 75, 77, 78, 79, 80, 80, 83, 86, 87, 92, 93, 94, 94, 99, 99, 99, 99, 0, 99, 99, 0, 0, 0, 0, 0, 100, 100, 102, 102, 106, 106, 106, 106, 110, 110, 111, 111, 115, 116, 117, 117, 121, 122, 124, 125, 126, 128, 128, 129, 131, 132, 136, 136, 136, 137, 137, 137, 137, 138, 138, 138, 139, 139, 139, 140, 140, 140, 140, 141, 141, 141, 142, 142, 142, 144, 149, 151, 152, 152, 152, 153, 153, 0, 153, 153, 154, 154, 155, 156, 156, 161, 161, 161, 161, 162, 164, 164, 164, 165, 165, 166, 166, 166, 168, 170, 170, 170, 170, 170, 170, 171, 172, 172, 173, 173, 173, 173, 173, 173, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 178, 178, 178, 179, 179, 179, 180, 180, 181, 181, 182, 184, 184, 185, 185, 186, 188, 188, 189, 189, 190, 192, 192, 193, 193, 194, 196, 196, 197, 197, 198, 200, 200, 201, 201, 202, 204, 204, 205, 205, 206, 208, 208, 209, 209, 210, 212, 212, 213, 213, 214, 216, 216, 217, 217, 218, 220, 220, 221, 221, 222, 224, 226, 226, 226, 227, 227, 228, 228, 229, 229, 230, 230, 231, 231, 231, 232, 232, 233, 233, 233, 233, 234, 234, 234, 234, 235, 235, 235, 235, 235, 236, 237, 238, 239, 240, 243, 243, 244, 246, 253, 253, 253, 253, 253, 254, 254, 255, 255, 258, 258, 258, 259, 259, 260, 260, 263, 264, 264, 0, 264, 264, 265, 265, 267, 268, 269, 271, 272, 272, 272, 273, 273, 275, 275, 276, 276, 277, 277, 278, 284, 285, 285, 285, 285, 285, 286, 286, 286, 286, 286, 287, 291, 292, 292, 292, 293, 294, 294, 294, 294, 295, 295, 295, 295, 296, 296, 296, 296, 296, 297, 297, 298, 0, 298, 298, 299, 302, 302, 302, 302, 302, 303, 303, 304, 0, 304, 304, 305, 310, 310, 310, 311, 312, 312, 312, 312, 312, 312, 319, 319, 323, 323, 324, 329, 329, 330, 331, 331, 332, 333, 333, 334, 335, 335, 336, 338, 338, 338, 340, 341, 343, 348, 349, 350, 351, 351, 352, 353, 354, 354, 354, 356, 358, 0, 358, 358, 359, 359, 360, 361, 362, 365, 0, 365, 365, 366, 366, 367, 368, 369, 370, 370, 375, 375, 376, 378, 380, 383, 383, 384, 384, 384, 385, 385, 385, 387, 387, 388, 388, 391, 392, 393, 394, 394, 394, 395, 396, 398, 399, 400, 400, 400, 401, 402, 406, 406, 407, 407, 408, 408, 408, 410, 410, 410, 413, 417, 418, 419, 421, 0, 421, 421, 422, 422, 423, 423, 424, 424, 424, 425, 425, 426, 426, 428, 428, 428, 429, 429, 429, 433, 434, 436, 436, 0, 0, 0, 437, 437, 438, 438, 438, 438, 438, 438, 438, 438, 440, 440, 441, 441, 443, 443, 443, 444, 444, 444, 449, 449, 451, 451, 452, 452, 452, 454, 454, 455, 455, 455, 457, 457, 458, 458, 458, 462, 462, 463, 464, 464, 464, 464, 464, 465, 467, 467, 471, 471, 471, 472, 473, 473, 474, 475, 477, 477, 477, 478, 479, 479, 480, 481, 483, 483, 487, 487, 487, 487, 488, 488, 488, 490, 490, 491, 491, 491, 491, 492, 494, 494, 494, 494, 494, 496, 496, 497, 497, 498, 501, 501, 501, 503, 505, 505, 506, 506, 506, 506, 507, 511, 512, 512, 513, 513, 514, 520, 520, 521, 522, 529, 529, 530, 532, 537, 538, 539, 540, 541, 542, 542, 544, 544, 544, 544, 545, 547, 547, 547, 547, 548, 548, 548, 549, 556, 556, 560, 560, 562, 562, 564, 564, 566, 566, 570, 570, 572, 575, 575, 577, 577, 580, 580, 582, 582, 585, 585, 587, 587, 590, 590, 592, 592, 595, 595, 597, 597, 600, 600, 602, 602, 605, 605, 607, 607, 610, 610, 612, 612, 615, 615, 617, 617, 618, 618, 621, 621, 623, 623, 625, 625, 625, 626, 628, 629, 630, 630, 631, 632, 632, 632, 633, 634, 635, 636, 642, 643, 644, 645, 645, 646, 646, 647, 648, 648, 649, 650, 650, 651, 653, 653, 654, 655, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 241, 246, 247, 248, 250, 253, 254, 256, 259, 263, 266, 270, 273, 274, 276, 277, 283, 284, 285, 286, 292, 293, 294, 295, 299, 300, 301, 302, 308, 309, 311, 312, 313, 317, 318, 319, 321, 322, 342, 343, 344, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 367, 486, 487, 488, 489, 494, 495, 496, 496, 499, 501, 502, 503, 505, 506, 507, 515, 516, 517, 518, 520, 522, 523, 524, 525, 526, 528, 529, 530, 533, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 579, 580, 582, 583, 584, 589, 590, 592, 593, 594, 599, 600, 602, 603, 604, 609, 610, 612, 613, 614, 619, 620, 622, 623, 624, 629, 630, 632, 633, 634, 639, 640, 642, 643, 644, 649, 650, 652, 653, 654, 659, 660, 662, 663, 664, 669, 670, 672, 673, 674, 679, 680, 683, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 724, 725, 728, 730, 731, 732, 733, 734, 735, 740, 741, 742, 744, 745, 746, 747, 752, 753, 754, 756, 757, 758, 758, 761, 763, 764, 765, 771, 772, 773, 774, 775, 776, 777, 779, 780, 782, 787, 788, 789, 790, 791, 792, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 857, 858, 859, 862, 864, 865, 866, 867, 868, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 884, 885, 885, 888, 890, 891, 898, 899, 900, 901, 902, 903, 908, 909, 909, 912, 914, 915, 928, 929, 932, 934, 935, 936, 937, 938, 939, 940, 950, 951, 965, 970, 971, 973, 978, 979, 980, 981, 983, 986, 987, 989, 992, 993, 995, 998, 999, 1000, 1004, 1005, 1007, 1104, 1105, 1106, 1107, 1112, 1113, 1114, 1115, 1116, 1117, 1119, 1120, 1120, 1123, 1125, 1126, 1127, 1129, 1130, 1131, 1138, 1138, 1141, 1143, 1144, 1145, 1147, 1148, 1149, 1150, 1151, 1159, 1162, 1164, 1165, 1171, 1173, 1174, 1175, 1176, 1177, 1178, 1179, 1184, 1185, 1186, 1187, 1188, 1191, 1192, 1193, 1194, 1195, 1198, 1200, 1201, 1207, 1208, 1209, 1210, 1213, 1215, 1216, 1223, 1224, 1225, 1230, 1231, 1232, 1233, 1235, 1236, 1237, 1239, 1242, 1244, 1245, 1247, 1247, 1250, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1259, 1260, 1261, 1263, 1264, 1266, 1267, 1268, 1270, 1271, 1272, 1280, 1281, 1284, 1286, 1288, 1291, 1295, 1298, 1299, 1300, 1301, 1302, 1303, 1304, 1305, 1306, 1307, 1308, 1309, 1311, 1312, 1314, 1315, 1316, 1318, 1319, 1320, 1329, 1330, 1331, 1336, 1337, 1338, 1339, 1341, 1346, 1347, 1348, 1349, 1351, 1356, 1357, 1358, 1359, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1372, 1373, 1386, 1387, 1390, 1392, 1393, 1394, 1395, 1396, 1402, 1403, 1406, 1408, 1409, 1410, 1411, 1412, 1418, 1419, 1447, 1448, 1449, 1454, 1455, 1456, 1457, 1459, 1460, 1461, 1462, 1463, 1468, 1469, 1472, 1473, 1474, 1475, 1476, 1477, 1482, 1483, 1484, 1485, 1488, 1489, 1490, 1492, 1494, 1495, 1496, 1497, 1498, 1499, 1500, 1508, 1509, 1510, 1511, 1516, 1517, 1519, 1520, 1521, 1522, 1526, 1531, 1532, 1534, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1597, 1598, 1599, 1600, 1601, 1602, 1603, 1604, 1605, 1606, 1607, 1608, 1609, 1610, 1611, 1613, 1614, 1616, 1617, 1619, 1620, 1622, 1623, 1625, 1626, 1628, 1630, 1631, 1633, 1634, 1636, 1637, 1639, 1640, 1642, 1643, 1645, 1646, 1648, 1649, 1651, 1652, 1654, 1655, 1657, 1658, 1660, 1661, 1663, 1664, 1666, 1667, 1669, 1670, 1672, 1673, 1675, 1676, 1678, 1679, 1681, 1682, 1683, 1684, 1687, 1688, 1690, 1691, 1693, 1694, 1697, 1699, 1700, 1701, 1702, 1703, 1704, 1705, 1706, 1707, 1708, 1709, 1710, 1711, 1733, 1734, 1735, 1736, 1737, 1738, 1741, 1743, 1744, 1745, 1746, 1747, 1748, 1750, 1752, 1753, 1755, 1756, 1766, 1769, 1773, 1776, 1780, 1783, 1787, 1790, 1794, 1797, 1801, 1804, 1808, 1811, 1815, 1818, 1822, 1825, 1829, 1832, 1836, 1839, 1843, 1846, 1850, 1853, 1857, 1860, 1864, 1867, 1871, 1874, 1878, 1881, 1885, 1888, 1892, 1895, 1899, 1902, 1906, 1909, 1913, 1916, 1920, 1923, 1927, 1930, 1934, 1937, 1941, 1944, 1948, 1951, 1955, 1958, 1962, 1965, 1969, 1972, 1976, 1979, 1983, 1986, 1990, 1993, 1997, 2000, 2004, 2007, 2011, 2014, 2018, 2021, 2025, 2028, 2032, 2035, 2039, 2042, 2046, 2049, 2053, 2056, 2060, 2063, 2067, 2070, 2074, 2077, 2081, 2084, 2088, 2091, 2095, 2098, 2102, 2105, 2109, 2112, 2116, 2119, 2123, 2126, 2130, 2133, 2137, 2140, 2144, 2147, 2151, 2154, 2158, 2161, 2165, 2168, 2172, 2175, 2179, 2182, 2186, 2189, 2193, 2196, 2200, 2203, 2207, 2210, 2214};
/* BEGIN LINEINFO 
assign 1 61 207
new 0 61 207
assign 1 63 208
new 0 63 208
assign 1 64 209
new 0 64 209
assign 1 65 210
new 0 65 210
assign 1 66 211
new 0 66 211
assign 1 67 212
new 0 67 212
assign 1 68 213
new 0 68 213
assign 1 69 214
new 0 69 214
assign 1 70 215
new 0 70 215
assign 1 71 216
new 0 71 216
assign 1 75 217
new 0 75 217
assign 1 77 218
new 1 77 218
assign 1 78 219
ntypesGet 0 78 219
assign 1 79 220
twtokGet 0 79 220
assign 1 80 221
new 0 80 221
assign 1 80 222
new 1 80 222
assign 1 83 223
new 0 83 223
assign 1 86 224
new 0 86 224
assign 1 87 225
new 0 87 225
assign 1 92 226
new 0 92 226
assign 1 93 227
new 0 93 227
assign 1 94 228
new 0 94 228
assign 1 94 229
new 1 94 229
assign 1 99 241
def 1 99 246
assign 1 99 247
new 0 99 247
assign 1 99 248
equals 1 99 248
assign 1 0 250
assign 1 99 253
new 0 99 253
assign 1 99 254
ends 1 99 254
assign 1 0 256
assign 1 0 259
assign 1 0 263
assign 1 0 266
assign 1 0 270
assign 1 100 273
new 0 100 273
return 1 100 274
assign 1 102 276
new 0 102 276
return 1 102 277
assign 1 106 283
new 0 106 283
assign 1 106 284
new 0 106 284
assign 1 106 285
swap 2 106 285
return 1 106 286
assign 1 110 292
new 0 110 292
assign 1 110 293
argsGet 0 110 293
assign 1 111 294
main 1 111 294
return 1 111 295
assign 1 115 299
assign 1 116 300
new 1 116 300
assign 1 117 301
go 0 117 301
return 1 117 302
assign 1 121 308
new 0 121 308
config 0 122 309
assign 1 124 311
new 0 124 311
assign 1 125 312
doWhat 0 125 312
assign 1 126 313
new 0 126 313
assign 1 128 317
new 0 128 317
assign 1 128 318
add 1 128 318
assign 1 129 319
new 0 129 319
print 0 131 321
return 1 132 322
assign 1 136 342
nameGet 0 136 342
assign 1 136 343
new 0 136 343
assign 1 136 344
equals 1 136 344
assign 1 137 346
new 0 137 346
assign 1 137 347
add 1 137 347
assign 1 137 348
add 1 137 348
assign 1 137 349
add 1 137 349
assign 1 138 350
new 0 138 350
assign 1 138 351
add 1 138 351
assign 1 138 352
add 1 138 352
assign 1 139 353
new 0 139 353
assign 1 139 354
add 1 139 354
assign 1 139 355
add 1 139 355
assign 1 140 356
new 0 140 356
assign 1 140 357
add 1 140 357
assign 1 140 358
add 1 140 358
assign 1 140 359
add 1 140 359
assign 1 141 360
new 0 141 360
assign 1 141 361
add 1 141 361
assign 1 141 362
add 1 141 362
assign 1 142 363
new 0 142 363
assign 1 142 364
add 1 142 364
assign 1 142 365
add 1 142 365
return 1 144 367
assign 1 149 486
new 0 149 486
assign 1 151 487
new 0 151 487
assign 1 152 488
get 1 152 488
assign 1 152 489
def 1 152 494
assign 1 153 495
get 1 153 495
assign 1 153 496
iteratorGet 0 0 496
assign 1 153 499
hasNextGet 0 153 499
assign 1 153 501
nextGet 0 153 501
assign 1 154 502
has 1 154 502
assign 1 154 503
not 0 154 503
put 1 155 505
assign 1 156 506
new 1 156 506
addFile 1 156 507
assign 1 161 515
new 0 161 515
assign 1 161 516
nameGet 0 161 516
assign 1 161 517
new 0 161 517
assign 1 161 518
equals 1 161 518
preProcessorSet 1 162 520
assign 1 164 522
new 0 164 522
assign 1 164 523
get 1 164 523
assign 1 164 524
firstGet 0 164 524
assign 1 165 525
new 0 165 525
assign 1 165 526
has 1 165 526
assign 1 166 528
new 0 166 528
assign 1 166 529
get 1 166 529
assign 1 166 530
firstGet 0 166 530
assign 1 168 533
assign 1 170 535
new 0 170 535
assign 1 170 536
new 0 170 536
assign 1 170 537
get 2 170 537
assign 1 170 538
firstGet 0 170 538
assign 1 170 539
new 1 170 539
assign 1 170 540
pathGet 0 170 540
addStep 1 171 541
assign 1 172 542
new 0 172 542
addStep 1 172 543
assign 1 173 544
new 0 173 544
assign 1 173 545
new 0 173 545
assign 1 173 546
get 2 173 546
assign 1 173 547
firstGet 0 173 547
assign 1 173 548
new 1 173 548
assign 1 173 549
pathGet 0 173 549
assign 1 174 550
new 0 174 550
assign 1 174 551
new 0 174 551
assign 1 174 552
nameGet 0 174 552
assign 1 174 553
get 2 174 553
assign 1 174 554
firstGet 0 174 554
assign 1 174 555
new 1 174 555
assign 1 175 556
new 0 175 556
assign 1 175 557
nameGet 0 175 557
assign 1 175 558
get 2 175 558
assign 1 175 559
firstGet 0 175 559
assign 1 175 560
new 1 175 560
assign 1 176 561
new 0 176 561
assign 1 176 562
new 0 176 562
assign 1 176 563
get 2 176 563
assign 1 176 564
firstGet 0 176 564
assign 1 176 565
new 1 176 565
assign 1 178 566
new 0 178 566
assign 1 178 567
get 1 178 567
assign 1 178 568
firstGet 0 178 568
assign 1 179 569
new 0 179 569
assign 1 179 570
get 1 179 570
assign 1 179 571
firstGet 0 179 571
assign 1 180 572
new 0 180 572
assign 1 180 573
get 1 180 573
assign 1 181 574
undef 1 181 579
assign 1 182 580
new 0 182 580
assign 1 184 582
new 0 184 582
assign 1 184 583
get 1 184 583
assign 1 185 584
undef 1 185 589
assign 1 186 590
new 0 186 590
assign 1 188 592
new 0 188 592
assign 1 188 593
get 1 188 593
assign 1 189 594
undef 1 189 599
assign 1 190 600
new 0 190 600
assign 1 192 602
new 0 192 602
assign 1 192 603
get 1 192 603
assign 1 193 604
undef 1 193 609
assign 1 194 610
new 0 194 610
assign 1 196 612
new 0 196 612
assign 1 196 613
get 1 196 613
assign 1 197 614
undef 1 197 619
assign 1 198 620
new 0 198 620
assign 1 200 622
new 0 200 622
assign 1 200 623
get 1 200 623
assign 1 201 624
undef 1 201 629
assign 1 202 630
new 0 202 630
assign 1 204 632
new 0 204 632
assign 1 204 633
get 1 204 633
assign 1 205 634
undef 1 205 639
assign 1 206 640
new 0 206 640
assign 1 208 642
new 0 208 642
assign 1 208 643
get 1 208 643
assign 1 209 644
undef 1 209 649
assign 1 210 650
new 0 210 650
assign 1 212 652
new 0 212 652
assign 1 212 653
get 1 212 653
assign 1 213 654
undef 1 213 659
assign 1 214 660
new 0 214 660
assign 1 216 662
new 0 216 662
assign 1 216 663
get 1 216 663
assign 1 217 664
def 1 217 669
assign 1 218 670
firstGet 0 218 670
assign 1 220 672
new 0 220 672
assign 1 220 673
get 1 220 673
assign 1 221 674
def 1 221 679
assign 1 222 680
firstGet 0 222 680
assign 1 224 683
new 0 224 683
assign 1 226 685
new 0 226 685
assign 1 226 686
new 0 226 686
assign 1 226 687
isTrue 2 226 687
assign 1 227 688
new 0 227 688
assign 1 227 689
isTrue 1 227 689
assign 1 228 690
new 0 228 690
assign 1 228 691
isTrue 1 228 691
assign 1 229 692
new 0 229 692
assign 1 229 693
isTrue 1 229 693
assign 1 230 694
new 0 230 694
assign 1 230 695
isTrue 1 230 695
assign 1 231 696
new 0 231 696
assign 1 231 697
new 0 231 697
assign 1 231 698
isTrue 2 231 698
assign 1 232 699
new 0 232 699
assign 1 232 700
get 1 232 700
assign 1 233 701
new 0 233 701
assign 1 233 702
new 0 233 702
assign 1 233 703
get 2 233 703
assign 1 233 704
firstGet 0 233 704
assign 1 234 705
new 0 234 705
assign 1 234 706
new 0 234 706
assign 1 234 707
get 2 234 707
assign 1 234 708
firstGet 0 234 708
assign 1 235 709
new 0 235 709
assign 1 235 710
add 1 235 710
assign 1 235 711
new 0 235 711
assign 1 235 712
get 2 235 712
assign 1 235 713
firstGet 0 235 713
assign 1 236 714
new 0 236 714
assign 1 237 715
new 0 237 715
assign 1 238 716
new 0 238 716
assign 1 239 717
new 0 239 717
assign 1 240 718
new 0 240 718
assign 1 243 719
def 1 243 724
assign 1 244 725
firstGet 0 244 725
assign 1 246 728
new 0 246 728
assign 1 253 730
new 0 253 730
assign 1 253 731
add 1 253 731
assign 1 253 732
nameGet 0 253 732
assign 1 253 733
add 1 253 733
assign 1 253 734
get 1 253 734
assign 1 254 735
def 1 254 740
assign 1 255 741
orderedGet 0 255 741
addAll 1 255 742
assign 1 258 744
new 0 258 744
assign 1 258 745
add 1 258 745
assign 1 258 746
get 1 258 746
assign 1 259 747
def 1 259 752
assign 1 260 753
orderedGet 0 260 753
addAll 1 260 754
assign 1 263 756
new 0 263 756
assign 1 264 757
orderedGet 0 264 757
assign 1 264 758
iteratorGet 0 0 758
assign 1 264 761
hasNextGet 0 264 761
assign 1 264 763
nextGet 0 264 763
assign 1 265 764
new 1 265 764
addValue 1 265 765
assign 1 267 771
newlineGet 0 267 771
assign 1 268 772
assign 1 269 773
new 1 269 773
assign 1 271 774
copy 0 271 774
assign 1 272 775
fileGet 0 272 775
assign 1 272 776
existsGet 0 272 776
assign 1 272 777
not 0 272 777
assign 1 273 779
fileGet 0 273 779
makeDirs 0 273 780
assign 1 275 782
def 1 275 787
assign 1 276 788
new 1 276 788
assign 1 276 789
readerGet 0 276 789
assign 1 277 790
open 0 277 790
assign 1 277 791
readString 1 277 791
close 0 278 792
assign 1 284 806
classNameGet 0 284 806
assign 1 285 807
add 1 285 807
assign 1 285 808
new 0 285 808
assign 1 285 809
add 1 285 809
assign 1 285 810
toString 0 285 810
assign 1 285 811
add 1 285 811
assign 1 286 812
add 1 286 812
assign 1 286 813
new 0 286 813
assign 1 286 814
add 1 286 814
assign 1 286 815
toString 0 286 815
assign 1 286 816
add 1 286 816
return 1 287 817
assign 1 291 857
new 0 291 857
assign 1 292 858
classesGet 0 292 858
assign 1 292 859
valueIteratorGet 0 292 859
assign 1 292 862
hasNextGet 0 292 862
assign 1 293 864
nextGet 0 293 864
assign 1 294 865
shouldEmitGet 0 294 865
assign 1 294 866
heldGet 0 294 866
assign 1 294 867
fromFileGet 0 294 867
assign 1 294 868
has 1 294 868
assign 1 295 870
heldGet 0 295 870
assign 1 295 871
namepathGet 0 295 871
assign 1 295 872
toString 0 295 872
put 1 295 873
assign 1 296 874
usedByGet 0 296 874
assign 1 296 875
heldGet 0 296 875
assign 1 296 876
namepathGet 0 296 876
assign 1 296 877
toString 0 296 877
assign 1 296 878
get 1 296 878
assign 1 297 879
def 1 297 884
assign 1 298 885
iteratorGet 0 0 885
assign 1 298 888
hasNextGet 0 298 888
assign 1 298 890
nextGet 0 298 890
put 1 299 891
assign 1 302 898
subClassesGet 0 302 898
assign 1 302 899
heldGet 0 302 899
assign 1 302 900
namepathGet 0 302 900
assign 1 302 901
toString 0 302 901
assign 1 302 902
get 1 302 902
assign 1 303 903
def 1 303 908
assign 1 304 909
iteratorGet 0 0 909
assign 1 304 912
hasNextGet 0 304 912
assign 1 304 914
nextGet 0 304 914
put 1 305 915
assign 1 310 928
classesGet 0 310 928
assign 1 310 929
valueIteratorGet 0 310 929
assign 1 310 932
hasNextGet 0 310 932
assign 1 311 934
nextGet 0 311 934
assign 1 312 935
heldGet 0 312 935
assign 1 312 936
heldGet 0 312 936
assign 1 312 937
namepathGet 0 312 937
assign 1 312 938
toString 0 312 938
assign 1 312 939
has 1 312 939
shouldWriteSet 1 312 940
assign 1 319 950
new 0 319 950
return 1 319 951
assign 1 323 965
def 1 323 970
return 1 324 971
assign 1 329 973
def 1 329 978
assign 1 330 979
firstGet 0 330 979
assign 1 331 980
new 0 331 980
assign 1 331 981
equals 1 331 981
assign 1 332 983
new 1 332 983
assign 1 333 986
new 0 333 986
assign 1 333 987
equals 1 333 987
assign 1 334 989
new 1 334 989
assign 1 335 992
new 0 335 992
assign 1 335 993
equals 1 335 993
assign 1 336 995
new 1 336 995
assign 1 338 998
new 0 338 998
assign 1 338 999
new 1 338 999
throw 1 338 1000
dynConditionsAllSet 1 340 1004
return 1 341 1005
return 1 343 1007
assign 1 348 1104
now 0 348 1104
assign 1 349 1105
new 0 349 1105
assign 1 350 1106
emitterGet 0 350 1106
assign 1 351 1107
def 1 351 1112
assign 1 352 1113
new 4 352 1113
put 1 353 1114
assign 1 354 1115
new 0 354 1115
assign 1 354 1116
add 1 354 1116
print 0 354 1117
assign 1 356 1119
new 0 356 1119
assign 1 358 1120
iteratorGet 0 0 1120
assign 1 358 1123
hasNextGet 0 358 1123
assign 1 358 1125
nextGet 0 358 1125
assign 1 359 1126
has 1 359 1126
assign 1 359 1127
not 0 359 1127
put 1 360 1129
assign 1 361 1130
new 2 361 1130
addValue 1 362 1131
assign 1 365 1138
iteratorGet 0 0 1138
assign 1 365 1141
hasNextGet 0 365 1141
assign 1 365 1143
nextGet 0 365 1143
assign 1 366 1144
has 1 366 1144
assign 1 366 1145
not 0 366 1145
put 1 367 1147
assign 1 368 1148
new 2 368 1148
addValue 1 369 1149
assign 1 370 1150
libNameGet 0 370 1150
put 1 370 1151
assign 1 375 1159
iteratorGet 0 375 1159
assign 1 375 1162
hasNextGet 0 375 1162
assign 1 376 1164
nextGet 0 376 1164
doParse 1 378 1165
buildSyns 1 380 1171
assign 1 383 1173
now 0 383 1173
assign 1 383 1174
subtract 1 383 1174
assign 1 384 1175
new 0 384 1175
assign 1 384 1176
add 1 384 1176
print 0 384 1177
assign 1 385 1178
emitCommonGet 0 385 1178
assign 1 385 1179
def 1 385 1184
assign 1 387 1185
emitCommonGet 0 387 1185
doEmit 0 387 1186
assign 1 388 1187
new 0 388 1187
return 1 388 1188
setClassesToWrite 0 391 1191
libnameInfoGet 0 392 1192
assign 1 393 1193
new 1 393 1193
assign 1 394 1194
classesGet 0 394 1194
assign 1 394 1195
valueIteratorGet 0 394 1195
assign 1 394 1198
hasNextGet 0 394 1198
assign 1 395 1200
nextGet 0 395 1200
doEmit 1 396 1201
emitMain 0 398 1207
emitCUInit 0 399 1208
assign 1 400 1209
classesGet 0 400 1209
assign 1 400 1210
valueIteratorGet 0 400 1210
assign 1 400 1213
hasNextGet 0 400 1213
assign 1 401 1215
nextGet 0 401 1215
emitSyn 1 402 1216
assign 1 406 1223
now 0 406 1223
assign 1 406 1224
subtract 1 406 1224
assign 1 407 1225
def 1 407 1230
assign 1 408 1231
new 0 408 1231
assign 1 408 1232
add 1 408 1232
print 0 408 1233
assign 1 410 1235
new 0 410 1235
assign 1 410 1236
add 1 410 1236
print 0 410 1237
prepMake 1 413 1239
assign 1 417 1242
not 0 417 1242
make 1 418 1244
deployLibrary 1 419 1245
assign 1 421 1247
iteratorGet 0 0 1247
assign 1 421 1250
hasNextGet 0 421 1250
assign 1 421 1252
nextGet 0 421 1252
assign 1 422 1253
libnameInfoGet 0 422 1253
assign 1 422 1254
unitShlibGet 0 422 1254
assign 1 423 1255
emitPathGet 0 423 1255
assign 1 423 1256
copy 0 423 1256
assign 1 424 1257
stepsGet 0 424 1257
assign 1 424 1258
lastGet 0 424 1258
addStep 1 424 1259
assign 1 425 1260
fileGet 0 425 1260
assign 1 425 1261
existsGet 0 425 1261
assign 1 426 1263
fileGet 0 426 1263
delete 0 426 1264
assign 1 428 1266
fileGet 0 428 1266
assign 1 428 1267
existsGet 0 428 1267
assign 1 428 1268
not 0 428 1268
assign 1 429 1270
fileGet 0 429 1270
assign 1 429 1271
fileGet 0 429 1271
deployFile 2 429 1272
assign 1 433 1280
iteratorGet 0 433 1280
assign 1 434 1281
iteratorGet 0 434 1281
assign 1 436 1284
hasNextGet 0 436 1284
assign 1 436 1286
hasNextGet 0 436 1286
assign 1 0 1288
assign 1 0 1291
assign 1 0 1295
assign 1 437 1298
nextGet 0 437 1298
assign 1 437 1299
apNew 1 437 1299
assign 1 438 1300
emitPathGet 0 438 1300
assign 1 438 1301
copy 0 438 1301
assign 1 438 1302
toString 0 438 1302
assign 1 438 1303
new 0 438 1303
assign 1 438 1304
add 1 438 1304
assign 1 438 1305
nextGet 0 438 1305
assign 1 438 1306
add 1 438 1306
assign 1 438 1307
apNew 1 438 1307
assign 1 440 1308
fileGet 0 440 1308
assign 1 440 1309
existsGet 0 440 1309
assign 1 441 1311
fileGet 0 441 1311
delete 0 441 1312
assign 1 443 1314
fileGet 0 443 1314
assign 1 443 1315
existsGet 0 443 1315
assign 1 443 1316
not 0 443 1316
assign 1 444 1318
fileGet 0 444 1318
assign 1 444 1319
fileGet 0 444 1319
deployFile 2 444 1320
assign 1 449 1329
now 0 449 1329
assign 1 449 1330
subtract 1 449 1330
assign 1 451 1331
def 1 451 1336
assign 1 452 1337
new 0 452 1337
assign 1 452 1338
add 1 452 1338
print 0 452 1339
assign 1 454 1341
def 1 454 1346
assign 1 455 1347
new 0 455 1347
assign 1 455 1348
add 1 455 1348
print 0 455 1349
assign 1 457 1351
def 1 457 1356
assign 1 458 1357
new 0 458 1357
assign 1 458 1358
add 1 458 1358
print 0 458 1359
assign 1 462 1362
new 0 462 1362
print 0 462 1363
assign 1 463 1364
run 2 463 1364
assign 1 464 1365
new 0 464 1365
assign 1 464 1366
add 1 464 1366
assign 1 464 1367
new 0 464 1367
assign 1 464 1368
add 1 464 1368
print 0 464 1369
return 1 465 1370
assign 1 467 1372
new 0 467 1372
return 1 467 1373
assign 1 471 1386
justParsedGet 0 471 1386
assign 1 471 1387
valueIteratorGet 0 471 1387
assign 1 471 1390
hasNextGet 0 471 1390
assign 1 472 1392
nextGet 0 472 1392
assign 1 473 1393
heldGet 0 473 1393
libNameSet 1 473 1394
assign 1 474 1395
getSyn 2 474 1395
libNameSet 1 475 1396
assign 1 477 1402
justParsedGet 0 477 1402
assign 1 477 1403
valueIteratorGet 0 477 1403
assign 1 477 1406
hasNextGet 0 477 1406
assign 1 478 1408
nextGet 0 478 1408
assign 1 479 1409
heldGet 0 479 1409
assign 1 479 1410
synGet 0 479 1410
checkInheritance 2 480 1411
integrate 1 481 1412
assign 1 483 1418
new 0 483 1418
justParsedSet 1 483 1419
assign 1 487 1447
heldGet 0 487 1447
assign 1 487 1448
synGet 0 487 1448
assign 1 487 1449
def 1 487 1454
assign 1 488 1455
heldGet 0 488 1455
assign 1 488 1456
synGet 0 488 1456
return 1 488 1457
assign 1 490 1459
heldGet 0 490 1459
libNameSet 1 490 1460
assign 1 491 1461
heldGet 0 491 1461
assign 1 491 1462
extendsGet 0 491 1462
assign 1 491 1463
undef 1 491 1468
assign 1 492 1469
new 1 492 1469
assign 1 494 1472
classesGet 0 494 1472
assign 1 494 1473
heldGet 0 494 1473
assign 1 494 1474
extendsGet 0 494 1474
assign 1 494 1475
toString 0 494 1475
assign 1 494 1476
get 1 494 1476
assign 1 496 1477
def 1 496 1482
assign 1 497 1483
heldGet 0 497 1483
libNameSet 1 497 1484
assign 1 498 1485
getSyn 2 498 1485
assign 1 501 1488
heldGet 0 501 1488
assign 1 501 1489
extendsGet 0 501 1489
assign 1 501 1490
loadSyn 1 501 1490
assign 1 503 1492
new 2 503 1492
assign 1 505 1494
heldGet 0 505 1494
synSet 1 505 1495
assign 1 506 1496
heldGet 0 506 1496
assign 1 506 1497
namepathGet 0 506 1497
assign 1 506 1498
toString 0 506 1498
addSynClass 2 506 1499
return 1 507 1500
assign 1 511 1508
toString 0 511 1508
assign 1 512 1509
synClassesGet 0 512 1509
assign 1 512 1510
get 1 512 1510
assign 1 513 1511
def 1 513 1516
return 1 514 1517
assign 1 520 1519
emitterGet 0 520 1519
assign 1 520 1520
loadSyn 1 520 1520
addSynClass 2 521 1521
return 1 522 1522
assign 1 529 1526
undef 1 529 1531
assign 1 530 1532
new 1 530 1532
return 1 532 1534
assign 1 537 1589
new 1 537 1589
assign 1 538 1590
new 0 538 1590
assign 1 539 1591
emitterGet 0 539 1591
assign 1 540 1592
assign 1 541 1593
new 0 541 1593
assign 1 542 1594
shouldEmitGet 0 542 1594
put 1 542 1595
assign 1 544 1597
new 0 544 1597
assign 1 544 1598
toString 0 544 1598
assign 1 544 1599
add 1 544 1599
print 0 544 1600
assign 1 545 1601
assign 1 547 1602
fileGet 0 547 1602
assign 1 547 1603
readerGet 0 547 1603
assign 1 547 1604
open 0 547 1604
assign 1 547 1605
readBuffer 1 547 1605
assign 1 548 1606
fileGet 0 548 1606
assign 1 548 1607
readerGet 0 548 1607
close 0 548 1608
assign 1 549 1609
tokenize 1 549 1609
assign 1 556 1610
outermostGet 0 556 1610
nodify 2 556 1611
assign 1 560 1613
new 0 560 1613
echo 0 560 1614
assign 1 562 1616
new 0 562 1616
traverse 1 562 1617
assign 1 564 1619
new 0 564 1619
echo 0 564 1620
assign 1 566 1622
new 0 566 1622
traverse 1 566 1623
assign 1 570 1625
new 0 570 1625
echo 0 570 1626
contain 0 572 1628
assign 1 575 1630
new 0 575 1630
echo 0 575 1631
assign 1 577 1633
new 0 577 1633
traverse 1 577 1634
assign 1 580 1636
new 0 580 1636
echo 0 580 1637
assign 1 582 1639
new 0 582 1639
traverse 1 582 1640
assign 1 585 1642
new 0 585 1642
echo 0 585 1643
assign 1 587 1645
new 0 587 1645
traverse 1 587 1646
assign 1 590 1648
new 0 590 1648
echo 0 590 1649
assign 1 592 1651
new 0 592 1651
traverse 1 592 1652
assign 1 595 1654
new 0 595 1654
echo 0 595 1655
assign 1 597 1657
new 0 597 1657
traverse 1 597 1658
assign 1 600 1660
new 0 600 1660
echo 0 600 1661
assign 1 602 1663
new 0 602 1663
traverse 1 602 1664
assign 1 605 1666
new 0 605 1666
echo 0 605 1667
assign 1 607 1669
new 0 607 1669
traverse 1 607 1670
assign 1 610 1672
new 0 610 1672
echo 0 610 1673
assign 1 612 1675
new 0 612 1675
traverse 1 612 1676
assign 1 615 1678
new 0 615 1678
echo 0 615 1679
assign 1 617 1681
new 0 617 1681
print 0 617 1682
assign 1 618 1683
new 0 618 1683
traverse 1 618 1684
assign 1 621 1687
new 0 621 1687
print 0 621 1688
assign 1 623 1690
new 1 623 1690
traverse 1 623 1691
assign 1 625 1693
classesGet 0 625 1693
assign 1 625 1694
valueIteratorGet 0 625 1694
assign 1 625 1697
hasNextGet 0 625 1697
assign 1 626 1699
nextGet 0 626 1699
assign 1 628 1700
transUnitGet 0 628 1700
assign 1 629 1701
new 1 629 1701
assign 1 630 1702
TRANSUNITGet 0 630 1702
typenameSet 1 630 1703
assign 1 631 1704
new 0 631 1704
assign 1 632 1705
heldGet 0 632 1705
assign 1 632 1706
emitsGet 0 632 1706
emitsSet 1 632 1707
heldSet 1 633 1708
delete 0 634 1709
addValue 1 635 1710
copyLoc 1 636 1711
reInitContained 0 642 1733
assign 1 643 1734
containedGet 0 643 1734
assign 1 644 1735
new 0 644 1735
assign 1 645 1736
new 0 645 1736
assign 1 645 1737
crGet 0 645 1737
assign 1 646 1738
iteratorGet 0 646 1738
assign 1 646 1741
hasNextGet 0 646 1741
assign 1 647 1743
new 1 647 1743
assign 1 648 1744
nextGet 0 648 1744
heldSet 1 648 1745
nlcSet 1 649 1746
assign 1 650 1747
heldGet 0 650 1747
assign 1 650 1748
equals 1 650 1748
assign 1 651 1750
increment 0 651 1750
assign 1 653 1752
heldGet 0 653 1752
assign 1 653 1753
notEquals 1 653 1753
addValue 1 654 1755
containerSet 1 655 1756
return 1 0 1766
assign 1 0 1769
return 1 0 1773
assign 1 0 1776
return 1 0 1780
assign 1 0 1783
return 1 0 1787
assign 1 0 1790
return 1 0 1794
assign 1 0 1797
return 1 0 1801
assign 1 0 1804
return 1 0 1808
assign 1 0 1811
return 1 0 1815
assign 1 0 1818
return 1 0 1822
assign 1 0 1825
return 1 0 1829
assign 1 0 1832
return 1 0 1836
assign 1 0 1839
return 1 0 1843
assign 1 0 1846
return 1 0 1850
assign 1 0 1853
return 1 0 1857
assign 1 0 1860
return 1 0 1864
assign 1 0 1867
return 1 0 1871
assign 1 0 1874
return 1 0 1878
assign 1 0 1881
return 1 0 1885
assign 1 0 1888
return 1 0 1892
assign 1 0 1895
return 1 0 1899
assign 1 0 1902
return 1 0 1906
assign 1 0 1909
return 1 0 1913
assign 1 0 1916
return 1 0 1920
assign 1 0 1923
return 1 0 1927
assign 1 0 1930
return 1 0 1934
assign 1 0 1937
return 1 0 1941
assign 1 0 1944
return 1 0 1948
assign 1 0 1951
return 1 0 1955
assign 1 0 1958
return 1 0 1962
assign 1 0 1965
return 1 0 1969
assign 1 0 1972
return 1 0 1976
assign 1 0 1979
return 1 0 1983
assign 1 0 1986
return 1 0 1990
assign 1 0 1993
return 1 0 1997
assign 1 0 2000
return 1 0 2004
assign 1 0 2007
return 1 0 2011
assign 1 0 2014
return 1 0 2018
assign 1 0 2021
return 1 0 2025
assign 1 0 2028
return 1 0 2032
assign 1 0 2035
return 1 0 2039
assign 1 0 2042
return 1 0 2046
assign 1 0 2049
return 1 0 2053
assign 1 0 2056
return 1 0 2060
assign 1 0 2063
return 1 0 2067
assign 1 0 2070
return 1 0 2074
assign 1 0 2077
return 1 0 2081
assign 1 0 2084
return 1 0 2088
assign 1 0 2091
return 1 0 2095
assign 1 0 2098
return 1 0 2102
assign 1 0 2105
return 1 0 2109
assign 1 0 2112
return 1 0 2116
assign 1 0 2119
return 1 0 2123
assign 1 0 2126
return 1 0 2130
assign 1 0 2133
return 1 0 2137
assign 1 0 2140
return 1 0 2144
assign 1 0 2147
return 1 0 2151
assign 1 0 2154
return 1 0 2158
assign 1 0 2161
return 1 0 2165
assign 1 0 2168
return 1 0 2172
assign 1 0 2175
return 1 0 2179
assign 1 0 2182
return 1 0 2186
assign 1 0 2189
return 1 0 2193
assign 1 0 2196
return 1 0 2200
assign 1 0 2203
return 1 0 2207
assign 1 0 2210
assign 1 0 2214
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1308786538: return bem_echo_0();
case 729571811: return bem_serializeToString_0();
case 2113443821: return bem_deployLibraryGet_0();
case 34945623: return bem_builtGet_0();
case 1380984085: return bem_printVisitorsGet_0();
case 1503762842: return bem_twtokGet_0();
case 340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case 580139405: return bem_config_0();
case 2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case 1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case 1803479881: return bem_libNameGet_0();
case 314718434: return bem_print_0();
case 2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case 186098742: return bem_exeNameGet_0();
case 1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case 829911139: return bem_compilerProfileGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case 658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case 2082855574: return bem_emitDataGet_0();
case 786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case 2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2025906022: return bem_includePathGet_0();
case 1919619119: return bem_setClassesToWrite_0();
case 2127864150: return bem_argsGet_0();
case 400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case 1003238764: return bem_parseGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 1505775346: return bem_putLineNumbersInTraceGet_0();
case 1713520961: return bem_linkLibArgsGet_0();
case 1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case 644675716: return bem_ntypesGet_0();
case 1185503219: return bem_deployFilesFromGet_0();
case 1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 102223041: return bem_cassemGet_0();
case 549080104: return bem_compilerGet_0();
case 560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case 733055122: return bem_makeNameGet_0();
case 328200718: return bem_printAstGet_0();
case 126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case 1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case 1458327669: return bem_emitFileHeaderGet_0();
case 1220511308: return bem_buildSucceededGet_0();
case 845792839: return bem_iteratorGet_0();
case 1149621350: return bem_codeGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 505952126: return bem_copyTo_1(bevd_0);
case 2071773321: return bem_emitDataSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 1702438708: return bem_linkLibArgsSet_1(bevd_0);
case 647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 721972869: return bem_makeNameSet_1(bevd_0);
case 175016489: return bem_exeNameSet_1(bevd_0);
case 972018826: return bem_dllhead_1((BEC_4_6_TextString) bevd_0);
case 317118465: return bem_printAstSet_1(bevd_0);
case 1392066338: return bem_printVisitorsSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case 2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 115429536: return bem_outputPlatformSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case 1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1094759839: return bem_process_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case 706249818: return bem_getSynNp_1(bevd_0);
case 1310359934: return bem_emitLangsSet_1(bevd_0);
case 329197947: return bem_startTimeSet_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case 1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case 1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case 2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1138539097: return bem_codeSet_1(bevd_0);
case 23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 2036609109: return bem_buildSyns_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case 1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case 1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case 113305294: return bem_cassemSet_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1081571541: return bem_main_1((BEC_9_5_ContainerArray) bevd_0);
case 593264218: return bem_isNewish_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_BuildBuild.bevs_inst = (BEC_5_5_BuildBuild)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_BuildBuild.bevs_inst;
}
}
