package be.BEL_4_Base;
/* File: source/build/Build.be */
public class BEC_5_5_BuildBuild extends BEC_6_6_SystemObject {
public BEC_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_6 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_7, 28));
private static byte[] bels_8 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_9 = {0x23,0x69,0x66,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_9, 12));
private static byte[] bels_10 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x65,0x78,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_10, 21));
private static byte[] bels_11 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_11, 6));
private static byte[] bels_12 = {0x23,0x69,0x66,0x6E,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_6 = (new BEC_4_6_TextString(bels_12, 13));
private static byte[] bels_13 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x69,0x6D,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_7 = (new BEC_4_6_TextString(bels_13, 21));
private static byte[] bels_14 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_8 = (new BEC_4_6_TextString(bels_14, 6));
private static byte[] bels_15 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_16 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_4_6_TextString bevo_9 = (new BEC_4_6_TextString(bels_16, 5));
private static byte[] bels_17 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_18 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_20 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_21 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_22 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_23 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_24 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_25 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_26 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_27 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_29 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_30 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_31 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_32 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_33 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_35 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_36 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_38 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_40 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_41 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_47 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_48 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_49 = {0x72,0x75,0x6E};
private static byte[] bels_50 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_51 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_52 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_53 = {0x67,0x63,0x63};
private static byte[] bels_54 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_55 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_56 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_4_6_TextString bevo_10 = (new BEC_4_6_TextString(bels_56, 9));
private static byte[] bels_57 = {};
private static byte[] bels_58 = {0x63};
private static byte[] bels_59 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_4_6_TextString bevo_11 = (new BEC_4_6_TextString(bels_59, 8));
private static byte[] bels_60 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_4_6_TextString bevo_12 = (new BEC_4_6_TextString(bels_60, 7));
private static byte[] bels_61 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_62 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_63 = {0x6A,0x76};
private static BEC_4_6_TextString bevo_13 = (new BEC_4_6_TextString(bels_63, 2));
private static byte[] bels_64 = {0x63,0x73};
private static BEC_4_6_TextString bevo_14 = (new BEC_4_6_TextString(bels_64, 2));
private static byte[] bels_65 = {0x6A,0x73};
private static BEC_4_6_TextString bevo_15 = (new BEC_4_6_TextString(bels_65, 2));
private static byte[] bels_66 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_67 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_4_6_TextString bevo_16 = (new BEC_4_6_TextString(bels_67, 19));
private static byte[] bels_68 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_17 = (new BEC_4_6_TextString(bels_68, 31));
private static byte[] bels_69 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_18 = (new BEC_4_6_TextString(bels_69, 31));
private static byte[] bels_70 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_19 = (new BEC_4_6_TextString(bels_70, 41));
private static byte[] bels_71 = {0x2F};
private static byte[] bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_20 = (new BEC_4_6_TextString(bels_72, 31));
private static byte[] bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_21 = (new BEC_4_6_TextString(bels_73, 41));
private static byte[] bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_22 = (new BEC_4_6_TextString(bels_74, 51));
private static byte[] bels_75 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_23 = (new BEC_4_6_TextString(bels_75, 14));
private static byte[] bels_76 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_4_6_TextString bevo_24 = (new BEC_4_6_TextString(bels_76, 19));
private static byte[] bels_77 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_25 = (new BEC_4_6_TextString(bels_77, 9));
private static byte[] bels_78 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_4_6_TextString bevo_26 = (new BEC_4_6_TextString(bels_78, 13));
private static byte[] bels_79 = {0x2E,0x20};
private static BEC_4_6_TextString bevo_27 = (new BEC_4_6_TextString(bels_79, 2));
private static byte[] bels_80 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_4_6_TextString bevo_28 = (new BEC_4_6_TextString(bels_80, 22));
private static byte[] bels_81 = {0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_29 = (new BEC_4_6_TextString(bels_81, 3));
private static byte[] bels_82 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_4_6_TextString bevo_30 = (new BEC_4_6_TextString(bels_82, 15));
private static byte[] bels_83 = {0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_31 = (new BEC_4_6_TextString(bels_83, 4));
private static byte[] bels_84 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_4_6_TextString bevo_32 = (new BEC_4_6_TextString(bels_84, 15));
private static byte[] bels_85 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_33 = (new BEC_4_6_TextString(bels_85, 5));
private static byte[] bels_86 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_4_6_TextString bevo_34 = (new BEC_4_6_TextString(bels_86, 15));
private static byte[] bels_87 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_35 = (new BEC_4_6_TextString(bels_87, 6));
private static byte[] bels_88 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_4_6_TextString bevo_36 = (new BEC_4_6_TextString(bels_88, 15));
private static byte[] bels_89 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_37 = (new BEC_4_6_TextString(bels_89, 7));
private static byte[] bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_4_6_TextString bevo_38 = (new BEC_4_6_TextString(bels_90, 15));
private static byte[] bels_91 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_39 = (new BEC_4_6_TextString(bels_91, 8));
private static byte[] bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_4_6_TextString bevo_40 = (new BEC_4_6_TextString(bels_92, 15));
private static byte[] bels_93 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_41 = (new BEC_4_6_TextString(bels_93, 9));
private static byte[] bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_4_6_TextString bevo_42 = (new BEC_4_6_TextString(bels_94, 15));
private static byte[] bels_95 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_43 = (new BEC_4_6_TextString(bels_95, 10));
private static byte[] bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_4_6_TextString bevo_44 = (new BEC_4_6_TextString(bels_96, 15));
private static byte[] bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_45 = (new BEC_4_6_TextString(bels_97, 11));
private static byte[] bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_4_6_TextString bevo_46 = (new BEC_4_6_TextString(bels_98, 16));
private static byte[] bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_47 = (new BEC_4_6_TextString(bels_99, 12));
private static byte[] bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_4_6_TextString bevo_48 = (new BEC_4_6_TextString(bels_100, 16));
private static byte[] bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_49 = (new BEC_4_6_TextString(bels_101, 13));
private static byte[] bels_102 = {0x20};
private static BEC_4_6_TextString bevo_50 = (new BEC_4_6_TextString(bels_102, 1));
private static byte[] bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_4_6_TextString bevo_51 = (new BEC_4_6_TextString(bels_103, 16));
public static BEC_5_5_BuildBuild bevs_inst;
public BEC_4_6_TextString bevp_mainName;
public BEC_4_6_TextString bevp_libName;
public BEC_4_6_TextString bevp_exeName;
public BEC_6_6_SystemObject bevp_emitFileHeader;
public BEC_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_9_10_ContainerLinkedList bevp_extLibs;
public BEC_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_6_6_SystemObject bevp_fromFile;
public BEC_6_6_SystemObject bevp_platform;
public BEC_6_6_SystemObject bevp_outputPlatform;
public BEC_6_6_SystemObject bevp_emitLibrary;
public BEC_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_4_6_TextString bevp_nl;
public BEC_4_6_TextString bevp_newline;
public BEC_6_6_SystemObject bevp_runArgs;
public BEC_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_9_5_ContainerArray bevp_args;
public BEC_6_10_SystemParameters bevp_params;
public BEC_5_4_LogicBool bevp_buildSucceeded;
public BEC_4_6_TextString bevp_buildMessage;
public BEC_4_8_TimeInterval bevp_startTime;
public BEC_4_8_TimeInterval bevp_parseTime;
public BEC_4_8_TimeInterval bevp_parseEmitTime;
public BEC_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_2_4_4_IOFilePath bevp_buildPath;
public BEC_6_6_SystemObject bevp_includePath;
public BEC_9_3_ContainerMap bevp_built;
public BEC_9_10_ContainerLinkedList bevp_toBuild;
public BEC_5_4_LogicBool bevp_printSteps;
public BEC_5_4_LogicBool bevp_printPlaces;
public BEC_5_4_LogicBool bevp_printAst;
public BEC_5_4_LogicBool bevp_printAllAst;
public BEC_9_3_ContainerSet bevp_printAstElements;
public BEC_5_4_LogicBool bevp_doEmit;
public BEC_5_4_LogicBool bevp_emitDebug;
public BEC_5_4_LogicBool bevp_parse;
public BEC_5_4_LogicBool bevp_prepMake;
public BEC_5_4_LogicBool bevp_make;
public BEC_5_4_LogicBool bevp_genOnly;
public BEC_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_5_8_BuildEmitData bevp_emitData;
public BEC_2_4_4_IOFilePath bevp_emitPath;
public BEC_6_6_SystemObject bevp_code;
public BEC_4_6_TextString bevp_estr;
public BEC_6_6_SystemObject bevp_sharedEmitter;
public BEC_5_9_BuildConstants bevp_constants;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_4_9_TextTokenizer bevp_twtok;
public BEC_4_9_TextTokenizer bevp_lctok;
public BEC_5_7_BuildLibrary bevp_deployLibrary;
public BEC_4_6_TextString bevp_deployPath;
public BEC_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_9_3_ContainerSet bevp_closeLibraries;
public BEC_5_4_LogicBool bevp_run;
public BEC_4_6_TextString bevp_compiler;
public BEC_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_4_6_TextString bevp_makeName;
public BEC_4_6_TextString bevp_makeArgs;
public BEC_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_5_4_LogicBool bevp_dynConditionsAll;
public BEC_4_6_TextString bevp_readBuffer;
public BEC_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAst = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parse = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_make = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_genOnly = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(3, bels_0));
bevp_lctok = (new BEC_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isNewish_1(BEC_4_6_TextString beva_name) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 102 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 102 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 102 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 102 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 102 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 102 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 102 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 102 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 102 */
 else  /* Line: 102 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 102 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 103 */
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_process_1(BEC_4_6_TextString beva_arg) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_main_0() throws Throwable {
BEC_9_5_ContainerArray bevl__args = null;
BEC_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_7_SystemProcess) BEC_6_7_SystemProcess.bevs_inst.bem_new_0();
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = this.bem_main_1(bevl__args);
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_main_1(BEC_9_5_ContainerArray beva__args) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_0_tmpvar_phold = this.bem_go_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_go_0() throws Throwable {
BEC_4_3_MathInt bevl_whatResult = null;
BEC_5_4_LogicBool bevl_buildFailed = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (new BEC_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = be.BELS_Base.BECS_Runtime.boolFalse;
try  /* Line: 127 */ {
bevp_buildMessage = (new BEC_4_6_TextString(16, bels_5));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (new BEC_4_6_TextString(14, bels_6));
} /* Line: 130 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevl_buildFailed = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevl_e);
bevl_whatResult = (new BEC_4_3_MathInt(1));
} /* Line: 134 */
if (bevp_printSteps.bevi_bool) /* Line: 136 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 136 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 136 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 136 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 137 */
return bevl_whatResult;
} /*method end*/
public BEC_4_6_TextString bem_dllhead_1(BEC_4_6_TextString beva_addTo) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(5, bels_8));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 143 */ {
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = beva_addTo.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevt_7_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_addTo.bem_add_1(bevt_7_tmpvar_phold);
beva_addTo = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
bevt_9_tmpvar_phold = bevo_5;
bevt_8_tmpvar_phold = beva_addTo.bem_add_1(bevt_9_tmpvar_phold);
beva_addTo = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
bevt_12_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold = beva_addTo.bem_add_1(bevt_12_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_10_tmpvar_phold.bem_add_1(bevp_nl);
bevt_14_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold = beva_addTo.bem_add_1(bevt_14_tmpvar_phold);
beva_addTo = bevt_13_tmpvar_phold.bem_add_1(bevp_nl);
bevt_16_tmpvar_phold = bevo_8;
bevt_15_tmpvar_phold = beva_addTo.bem_add_1(bevt_16_tmpvar_phold);
beva_addTo = bevt_15_tmpvar_phold.bem_add_1(bevp_nl);
} /* Line: 149 */
return beva_addTo;
} /*method end*/
public BEC_6_6_SystemObject bem_config_0() throws Throwable {
BEC_4_6_TextString bevl_istr = null;
BEC_9_3_ContainerSet bevl_bfiles = null;
BEC_4_6_TextString bevl_bkey = null;
BEC_9_10_ContainerLinkedList bevl_pacm = null;
BEC_4_6_TextString bevl_pa = null;
BEC_4_6_TextString bevl_outLang = null;
BEC_6_6_SystemObject bevl_platformSources = null;
BEC_6_6_SystemObject bevl_langSources = null;
BEC_6_6_SystemObject bevl_emr = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_88_tmpvar_phold = null;
BEC_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_94_tmpvar_phold = null;
BEC_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_108_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_109_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_111_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_113_tmpvar_phold = null;
BEC_2_4_IOFile bevt_114_tmpvar_phold = null;
BEC_2_4_IOFile bevt_115_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_116_tmpvar_phold = null;
BEC_2_4_IOFile bevt_117_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_118_tmpvar_phold = null;
bevl_bfiles = (new BEC_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_4_6_TextString(9, bels_15));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 160 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 160 */ {
bevl_istr = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 163 */
} /* Line: 161 */
 else  /* Line: 160 */ {
break;
} /* Line: 160 */
} /* Line: 160 */
} /* Line: 160 */
bevt_13_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_9;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 169 */
bevt_16_tmpvar_phold = (new BEC_4_6_TextString(11, bels_17));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(7, bels_18));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(7, bels_19));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 173 */
 else  /* Line: 174 */ {
bevp_exeName = bevp_libName;
} /* Line: 175 */
bevt_24_tmpvar_phold = (new BEC_4_6_TextString(9, bels_20));
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(6, bels_21));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (new BEC_4_6_TextString(6, bels_22));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (new BEC_4_6_TextString(11, bels_23));
bevt_31_tmpvar_phold = (new BEC_4_6_TextString(7, bels_24));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(8, bels_25));
bevt_36_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (new BEC_4_6_TextString(14, bels_26));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (new BEC_4_6_TextString(16, bels_27));
bevt_44_tmpvar_phold = (new BEC_4_6_TextString(5, bels_28));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_46_tmpvar_phold = (new BEC_4_6_TextString(9, bels_29));
bevt_45_tmpvar_phold = bevp_params.bem_get_1(bevt_46_tmpvar_phold);
bevp_mainName = (BEC_4_6_TextString) bevt_45_tmpvar_phold.bem_firstGet_0();
bevt_48_tmpvar_phold = (new BEC_4_6_TextString(10, bels_30));
bevt_47_tmpvar_phold = bevp_params.bem_get_1(bevt_48_tmpvar_phold);
bevp_deployPath = (BEC_4_6_TextString) bevt_47_tmpvar_phold.bem_firstGet_0();
bevt_49_tmpvar_phold = (new BEC_4_6_TextString(10, bels_31));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_49_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 188 */ {
bevp_usedLibrarysStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 189 */
bevt_51_tmpvar_phold = (new BEC_4_6_TextString(15, bels_32));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_51_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevp_closeLibrariesStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193 */
bevt_53_tmpvar_phold = (new BEC_4_6_TextString(14, bels_33));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevp_deployFilesFrom = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_55_tmpvar_phold = (new BEC_4_6_TextString(12, bels_34));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevp_deployFilesTo = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_57_tmpvar_phold = (new BEC_4_6_TextString(10, bels_35));
bevp_extIncludes = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevp_extIncludes = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_59_tmpvar_phold = (new BEC_4_6_TextString(9, bels_36));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevp_ccObjArgs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_61_tmpvar_phold = (new BEC_4_6_TextString(6, bels_37));
bevp_extLibs = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevp_extLibs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_63_tmpvar_phold = (new BEC_4_6_TextString(11, bels_38));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevp_linkLibArgs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_65_tmpvar_phold = (new BEC_4_6_TextString(13, bels_39));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevp_extLinkObjects = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221 */
bevt_67_tmpvar_phold = (new BEC_4_6_TextString(14, bels_40));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 225 */
bevt_69_tmpvar_phold = (new BEC_4_6_TextString(7, bels_41));
bevp_runArgs = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevp_runArgs = bevp_runArgs.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 229 */
 else  /* Line: 230 */ {
bevp_runArgs = (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 231 */
bevt_71_tmpvar_phold = (new BEC_4_6_TextString(10, bels_42));
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_71_tmpvar_phold, bevt_72_tmpvar_phold);
bevt_73_tmpvar_phold = (new BEC_4_6_TextString(11, bels_43));
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_73_tmpvar_phold, bevt_74_tmpvar_phold);
bevt_75_tmpvar_phold = (new BEC_4_6_TextString(8, bels_44));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_75_tmpvar_phold);
bevt_76_tmpvar_phold = (new BEC_4_6_TextString(11, bels_45));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_76_tmpvar_phold);
bevp_printAstElements = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_77_tmpvar_phold = (new BEC_4_6_TextString(15, bels_46));
bevl_pacm = bevp_params.bem_get_1(bevt_77_tmpvar_phold);
if (bevl_pacm == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevt_80_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_not_0();
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 239 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_iteratorGet_0();
while (true)
 /* Line: 240 */ {
bevt_81_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_81_tmpvar_phold != null && bevt_81_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_81_tmpvar_phold).bevi_bool) /* Line: 240 */ {
bevl_pa = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 241 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 240 */
bevt_82_tmpvar_phold = (new BEC_4_6_TextString(7, bels_47));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_82_tmpvar_phold);
bevt_83_tmpvar_phold = (new BEC_4_6_TextString(19, bels_48));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_83_tmpvar_phold);
bevt_84_tmpvar_phold = (new BEC_4_6_TextString(3, bels_49));
bevp_run = bevp_params.bem_isTrue_1(bevt_84_tmpvar_phold);
bevt_85_tmpvar_phold = (new BEC_4_6_TextString(21, bels_50));
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_85_tmpvar_phold, bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (new BEC_4_6_TextString(8, bels_51));
bevp_emitLangs = bevp_params.bem_get_1(bevt_87_tmpvar_phold);
bevt_89_tmpvar_phold = (new BEC_4_6_TextString(8, bels_52));
bevt_90_tmpvar_phold = (new BEC_4_6_TextString(3, bels_53));
bevt_88_tmpvar_phold = bevp_params.bem_get_2(bevt_89_tmpvar_phold, bevt_90_tmpvar_phold);
bevp_compiler = (BEC_4_6_TextString) bevt_88_tmpvar_phold.bem_firstGet_0();
bevt_92_tmpvar_phold = (new BEC_4_6_TextString(4, bels_54));
bevt_93_tmpvar_phold = (new BEC_4_6_TextString(4, bels_55));
bevt_91_tmpvar_phold = bevp_params.bem_get_2(bevt_92_tmpvar_phold, bevt_93_tmpvar_phold);
bevp_makeName = (BEC_4_6_TextString) bevt_91_tmpvar_phold.bem_firstGet_0();
bevt_96_tmpvar_phold = bevo_10;
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_97_tmpvar_phold = (new BEC_4_6_TextString(0, bels_57));
bevt_94_tmpvar_phold = bevp_params.bem_get_2(bevt_95_tmpvar_phold, bevt_97_tmpvar_phold);
bevp_makeArgs = (BEC_4_6_TextString) bevt_94_tmpvar_phold.bem_firstGet_0();
bevp_parse = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_make = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_98_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_98_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_98_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevl_outLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 260 */
 else  /* Line: 261 */ {
bevl_outLang = (new BEC_4_6_TextString(1, bels_58));
} /* Line: 262 */
bevt_101_tmpvar_phold = bevo_11;
bevt_100_tmpvar_phold = bevl_outLang.bem_add_1(bevt_101_tmpvar_phold);
bevt_102_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bem_add_1(bevt_102_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_99_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 270 */ {
bevt_104_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_104_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 271 */
bevt_106_tmpvar_phold = bevo_12;
bevt_105_tmpvar_phold = bevl_outLang.bem_add_1(bevt_106_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_105_tmpvar_phold);
if (bevl_langSources == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 275 */ {
bevt_108_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_108_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 276 */
bevp_toBuild = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_109_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_109_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 280 */ {
bevt_110_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_110_tmpvar_phold != null && bevt_110_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_110_tmpvar_phold).bevi_bool) /* Line: 280 */ {
bevl_istr = (BEC_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_111_tmpvar_phold = (new BEC_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_111_tmpvar_phold);
} /* Line: 281 */
 else  /* Line: 280 */ {
break;
} /* Line: 280 */
} /* Line: 280 */
bevp_newline = (BEC_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_114_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_113_tmpvar_phold = bevt_114_tmpvar_phold.bem_existsGet_0();
bevt_112_tmpvar_phold = bevt_113_tmpvar_phold.bem_not_0();
if (bevt_112_tmpvar_phold.bevi_bool) /* Line: 288 */ {
bevt_115_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_115_tmpvar_phold.bem_makeDirs_0();
} /* Line: 289 */
if (bevp_emitFileHeader == null) {
bevt_116_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_116_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_116_tmpvar_phold.bevi_bool) /* Line: 291 */ {
bevt_117_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_117_tmpvar_phold.bem_readerGet_0();
bevt_118_tmpvar_phold = bevl_emr.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_118_tmpvar_phold.bemd_1(347960121, BEL_4_Base.bevn_readString_1, bevp_readBuffer);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 294 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_6_6_SystemObject bevl_toRet = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(13, bels_61));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(12, bels_62));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_6_6_SystemObject bem_setClassesToWrite_0() throws Throwable {
BEC_9_3_ContainerSet bevl_toEmit = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_9_3_ContainerSet bevl_usedBy = null;
BEC_4_6_TextString bevl_ub = null;
BEC_9_3_ContainerSet bevl_subClasses = null;
BEC_4_6_TextString bevl_sc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 308 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 308 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 310 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_iteratorGet_0();
while (true)
 /* Line: 314 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 314 */ {
bevl_ub = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 315 */
 else  /* Line: 314 */ {
break;
} /* Line: 314 */
} /* Line: 314 */
} /* Line: 314 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 319 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_iteratorGet_0();
while (true)
 /* Line: 320 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 320 */ {
bevl_sc = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 321 */
 else  /* Line: 320 */ {
break;
} /* Line: 320 */
} /* Line: 320 */
} /* Line: 320 */
} /* Line: 319 */
} /* Line: 310 */
 else  /* Line: 308 */ {
break;
} /* Line: 308 */
} /* Line: 308 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 326 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 326 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 328 */
 else  /* Line: 326 */ {
break;
} /* Line: 326 */
} /* Line: 326 */
return this;
} /*method end*/
public BEC_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_4_6_TextString bevl_emitLang = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 339 */ {
return bevp_emitCommon;
} /* Line: 340 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 345 */ {
bevl_emitLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_13;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 347 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 348 */
 else  /* Line: 347 */ {
bevt_5_tmpvar_phold = bevo_14;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 349 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 350 */
 else  /* Line: 347 */ {
bevt_7_tmpvar_phold = bevo_15;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 351 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 352 */
 else  /* Line: 353 */ {
bevt_9_tmpvar_phold = (new BEC_4_6_TextString(49, bels_66));
bevt_8_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 354 */
} /* Line: 347 */
} /* Line: 347 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 357 */
return null;
} /*method end*/
public BEC_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_6_6_SystemObject bevl_em = null;
BEC_9_3_ContainerSet bevl_ulibs = null;
BEC_6_6_SystemObject bevl_ups = null;
BEC_6_6_SystemObject bevl_pack = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_tb = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_bp = null;
BEC_6_6_SystemObject bevl_cpFrom = null;
BEC_6_6_SystemObject bevl_cpTo = null;
BEC_6_6_SystemObject bevl_fIter = null;
BEC_6_6_SystemObject bevl_tIter = null;
BEC_4_3_MathInt bevl_result = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_19_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
bevp_startTime = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_emitData = (new BEC_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 367 */ {
bevp_deployLibrary = (new BEC_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 370 */ {
bevt_6_tmpvar_phold = bevo_16;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevp_libName);
bevt_5_tmpvar_phold.bem_print_0();
} /* Line: 371 */
} /* Line: 370 */
bevl_ulibs = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 376 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 376 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 377 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 380 */
} /* Line: 377 */
 else  /* Line: 376 */ {
break;
} /* Line: 376 */
} /* Line: 376 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 383 */ {
bevt_10_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 383 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_not_0();
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 384 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_13_tmpvar_phold = bevl_pack.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_13_tmpvar_phold);
} /* Line: 388 */
} /* Line: 384 */
 else  /* Line: 383 */ {
break;
} /* Line: 383 */
} /* Line: 383 */
if (bevp_parse.bevi_bool) /* Line: 391 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 393 */ {
bevt_14_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 393 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 396 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 398 */
bevt_15_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseTime = bevt_15_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_printSteps.bevi_bool) /* Line: 402 */ {
bevt_17_tmpvar_phold = bevo_17;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_16_tmpvar_phold.bem_print_0();
} /* Line: 403 */
bevt_19_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_19_tmpvar_phold == null) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 405 */ {
bevt_20_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_20_tmpvar_phold.bem_doEmit_0();
bevt_21_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_21_tmpvar_phold;
} /* Line: 408 */
if (bevp_doEmit.bevi_bool) /* Line: 410 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_22_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_22_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 414 */ {
bevt_23_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 414 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 416 */
 else  /* Line: 414 */ {
break;
} /* Line: 414 */
} /* Line: 414 */
bevl_em.bemd_0(1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_24_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_24_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 420 */ {
bevt_25_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 420 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 422 */
 else  /* Line: 420 */ {
break;
} /* Line: 420 */
} /* Line: 420 */
} /* Line: 420 */
bevt_26_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitTime = bevt_26_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 427 */ {
bevt_29_tmpvar_phold = bevo_18;
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_28_tmpvar_phold.bem_print_0();
} /* Line: 428 */
bevt_31_tmpvar_phold = bevo_19;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_30_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 431 */ {
bevl_em.bemd_1(1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 433 */
if (bevp_make.bevi_bool) /* Line: 436 */ {
bevt_32_tmpvar_phold = bevp_genOnly.bem_not_0();
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 437 */ {
bevl_em.bemd_1(1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 440 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_iteratorGet_0();
while (true)
 /* Line: 441 */ {
bevt_33_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 441 */ {
bevl_bp = bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_34_tmpvar_phold.bemd_0(159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_35_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_35_tmpvar_phold.bem_copy_0();
bevt_37_tmpvar_phold = bevl_cpFrom.bemd_0(723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_38_tmpvar_phold != null && bevt_38_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_38_tmpvar_phold).bevi_bool) /* Line: 445 */ {
bevt_40_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_40_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 446 */
bevt_43_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 448 */ {
bevt_44_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_45_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_44_tmpvar_phold, bevt_45_tmpvar_phold);
} /* Line: 449 */
} /* Line: 448 */
 else  /* Line: 441 */ {
break;
} /* Line: 441 */
} /* Line: 441 */
} /* Line: 441 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 456 */ {
bevt_46_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 456 */ {
bevt_47_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 456 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 456 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 456 */
 else  /* Line: 456 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 456 */ {
bevt_48_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_48_tmpvar_phold);
bevt_53_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_copy_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_54_tmpvar_phold = (new BEC_4_6_TextString(1, bels_71));
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_55_tmpvar_phold);
bevl_cpTo = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_49_tmpvar_phold);
bevt_57_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_56_tmpvar_phold != null && bevt_56_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_56_tmpvar_phold).bevi_bool) /* Line: 460 */ {
bevt_58_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_58_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 461 */
bevt_61_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 463 */ {
bevt_62_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_63_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_62_tmpvar_phold, bevt_63_tmpvar_phold);
} /* Line: 464 */
} /* Line: 463 */
 else  /* Line: 456 */ {
break;
} /* Line: 456 */
} /* Line: 456 */
} /* Line: 456 */
} /* Line: 437 */
bevt_64_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitCompileTime = bevt_64_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 471 */ {
bevt_67_tmpvar_phold = bevo_20;
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_66_tmpvar_phold.bem_print_0();
} /* Line: 472 */
if (bevp_parseEmitTime == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 474 */ {
bevt_70_tmpvar_phold = bevo_21;
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_69_tmpvar_phold.bem_print_0();
} /* Line: 475 */
if (bevp_parseEmitCompileTime == null) {
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 477 */ {
bevt_73_tmpvar_phold = bevo_22;
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_72_tmpvar_phold.bem_print_0();
} /* Line: 478 */
if (bevp_run.bevi_bool) /* Line: 481 */ {
bevt_74_tmpvar_phold = bevo_23;
bevt_74_tmpvar_phold.bem_print_0();
bevl_result = (BEC_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_77_tmpvar_phold = bevo_24;
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_add_1(bevl_result);
bevt_78_tmpvar_phold = bevo_25;
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bem_add_1(bevt_78_tmpvar_phold);
bevt_75_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 485 */
bevt_79_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_79_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSyns_1(BEC_6_6_SystemObject beva_em) throws Throwable {
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_kls = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 491 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 491 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 495 */
 else  /* Line: 491 */ {
break;
} /* Line: 491 */
} /* Line: 491 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 497 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 497 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 501 */
 else  /* Line: 497 */ {
break;
} /* Line: 497 */
} /* Line: 497 */
bevt_6_tmpvar_phold = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_getSyn_2(BEC_6_6_SystemObject beva_klass, BEC_6_6_SystemObject beva_em) throws Throwable {
BEC_6_6_SystemObject bevl_syn = null;
BEC_6_6_SystemObject bevl_pklass = null;
BEC_6_6_SystemObject bevl_psyn = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 507 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 508 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 511 */ {
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 512 */
 else  /* Line: 513 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 518 */
 else  /* Line: 519 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 521 */
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 523 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevt_18_tmpvar_phold, (BEC_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public BEC_5_8_BuildClassSyn bem_getSynNp_1(BEC_6_6_SystemObject beva_np) throws Throwable {
BEC_6_6_SystemObject bevl_nps = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 533 */ {
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /* Line: 534 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevl_nps, (BEC_5_8_BuildClassSyn) bevl_syn);
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 549 */ {
bevp_sharedEmitter = (new BEC_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 550 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_6_6_SystemObject bem_doParse_1(BEC_6_6_SystemObject beva_toParse) throws Throwable {
BEC_6_6_SystemObject bevl_trans = null;
BEC_6_6_SystemObject bevl_blank = null;
BEC_6_6_SystemObject bevl_emitter = null;
BEC_5_4_LogicBool bevl_parseThis = null;
BEC_6_6_SystemObject bevl_src = null;
BEC_9_10_ContainerLinkedList bevl_toks = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_tunode = null;
BEC_6_6_SystemObject bevl_ntunode = null;
BEC_6_6_SystemObject bevl_ntt = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 563 */ {
if (bevp_printSteps.bevi_bool) /* Line: 564 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 564 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 564 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 564 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 564 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 564 */ {
bevt_4_tmpvar_phold = bevo_26;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 565 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 578 */ {
bevt_11_tmpvar_phold = bevo_27;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 579 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 582 */ {
bevt_13_tmpvar_phold = bevo_28;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 584 */
if (bevp_printSteps.bevi_bool) /* Line: 587 */ {
bevt_15_tmpvar_phold = bevo_29;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 588 */
bevt_16_tmpvar_phold = (BEC_5_5_5_BuildVisitPass2) (new BEC_5_5_5_BuildVisitPass2()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 591 */ {
bevt_17_tmpvar_phold = bevo_30;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 593 */
if (bevp_printSteps.bevi_bool) /* Line: 595 */ {
bevt_19_tmpvar_phold = bevo_31;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 596 */
bevt_20_tmpvar_phold = (BEC_5_5_5_BuildVisitPass3) (new BEC_5_5_5_BuildVisitPass3()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 601 */ {
bevt_21_tmpvar_phold = bevo_32;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 603 */
if (bevp_printSteps.bevi_bool) /* Line: 606 */ {
bevt_23_tmpvar_phold = bevo_33;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 607 */
bevt_24_tmpvar_phold = (BEC_5_5_5_BuildVisitPass4) (new BEC_5_5_5_BuildVisitPass4()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 610 */ {
bevt_25_tmpvar_phold = bevo_34;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 612 */
if (bevp_printSteps.bevi_bool) /* Line: 615 */ {
bevt_27_tmpvar_phold = bevo_35;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 616 */
bevt_28_tmpvar_phold = (BEC_5_5_5_BuildVisitPass5) (new BEC_5_5_5_BuildVisitPass5()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 619 */ {
bevt_29_tmpvar_phold = bevo_36;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 621 */
if (bevp_printSteps.bevi_bool) /* Line: 624 */ {
bevt_31_tmpvar_phold = bevo_37;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 625 */
bevt_32_tmpvar_phold = (BEC_5_5_5_BuildVisitPass6) (new BEC_5_5_5_BuildVisitPass6()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 628 */ {
bevt_33_tmpvar_phold = bevo_38;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 630 */
if (bevp_printSteps.bevi_bool) /* Line: 633 */ {
bevt_35_tmpvar_phold = bevo_39;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 634 */
bevt_36_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 637 */ {
bevt_37_tmpvar_phold = bevo_40;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 639 */
if (bevp_printSteps.bevi_bool) /* Line: 642 */ {
bevt_39_tmpvar_phold = bevo_41;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 643 */
bevt_40_tmpvar_phold = (BEC_5_5_5_BuildVisitPass8) (new BEC_5_5_5_BuildVisitPass8()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 646 */ {
bevt_41_tmpvar_phold = bevo_42;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 648 */
if (bevp_printSteps.bevi_bool) /* Line: 651 */ {
bevt_43_tmpvar_phold = bevo_43;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 652 */
bevt_44_tmpvar_phold = (BEC_5_5_5_BuildVisitPass9) (new BEC_5_5_5_BuildVisitPass9()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 655 */ {
bevt_45_tmpvar_phold = bevo_44;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 657 */
if (bevp_printSteps.bevi_bool) /* Line: 660 */ {
bevt_47_tmpvar_phold = bevo_45;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 661 */
bevt_48_tmpvar_phold = (BEC_5_5_6_BuildVisitPass10) (new BEC_5_5_6_BuildVisitPass10()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 664 */ {
bevt_49_tmpvar_phold = bevo_46;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 666 */
if (bevp_printSteps.bevi_bool) /* Line: 668 */ {
bevt_51_tmpvar_phold = bevo_47;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 669 */
bevt_52_tmpvar_phold = (new BEC_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 672 */ {
bevt_53_tmpvar_phold = bevo_48;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 674 */
if (bevp_printSteps.bevi_bool) /* Line: 677 */ {
bevt_55_tmpvar_phold = bevo_49;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_50;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 679 */
bevt_57_tmpvar_phold = (new BEC_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 682 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 682 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 682 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 682 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 682 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 682 */ {
bevt_58_tmpvar_phold = bevo_51;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 684 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 686 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 686 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 697 */
 else  /* Line: 686 */ {
break;
} /* Line: 686 */
} /* Line: 686 */
} /* Line: 686 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_nodify_2(BEC_6_6_SystemObject beva_parnode, BEC_6_6_SystemObject beva_toks) throws Throwable {
BEC_9_8_ContainerNodeList bevl_con = null;
BEC_6_6_SystemObject bevl_nlc = null;
BEC_4_6_TextString bevl_cr = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_node = null;
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 707 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 707 */ {
bevl_node = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 711 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 712 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 714 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 716 */
} /* Line: 714 */
 else  /* Line: 707 */ {
break;
} /* Line: 707 */
} /* Line: 707 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_6_6_SystemObject bem_mainNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mainName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_6_6_SystemObject bem_libNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_6_6_SystemObject bem_exeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_exeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_6_6_SystemObject bem_extIncludesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extIncludes = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_ccObjArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ccObjArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_6_6_SystemObject bem_extLibsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLibs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_linkLibArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_linkLibArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLinkObjects = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_6_6_SystemObject bem_platformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_6_6_SystemObject bem_outputPlatformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_6_6_SystemObject bem_deployFilesFromSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_6_6_SystemObject bem_deployFilesToSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesTo = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nl = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_6_6_SystemObject bem_newlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_runArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_6_6_SystemObject bem_compilerProfileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compilerProfile = (BEC_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_6_6_SystemObject bem_argsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_args = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_6_6_SystemObject bem_paramsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_params = (BEC_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSucceededSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildSucceeded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_6_6_SystemObject bem_buildMessageSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildMessage = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_6_6_SystemObject bem_startTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_startTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_6_6_SystemObject bem_buildPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_6_6_SystemObject bem_includePathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_6_6_SystemObject bem_builtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_built = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_6_6_SystemObject bem_toBuildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_toBuild = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_6_6_SystemObject bem_printStepsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printSteps = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_6_6_SystemObject bem_printPlacesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printPlaces = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_6_6_SystemObject bem_printAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_6_6_SystemObject bem_printAllAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAllAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_6_6_SystemObject bem_printAstElementsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAstElements = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_6_6_SystemObject bem_doEmitSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_doEmit = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_6_6_SystemObject bem_emitDebugSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitDebug = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_6_6_SystemObject bem_parseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parse = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_6_6_SystemObject bem_prepMakeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_prepMake = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_6_6_SystemObject bem_makeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_make = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_6_6_SystemObject bem_genOnlySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_genOnly = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_6_6_SystemObject bem_emitDataSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitData = (BEC_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_6_6_SystemObject bem_emitPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_6_6_SystemObject bem_codeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_6_6_SystemObject bem_estrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_estr = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_6_6_SystemObject bem_sharedEmitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_6_6_SystemObject bem_constantsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_constants = (BEC_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_6_6_SystemObject bem_twtokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_twtok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_6_6_SystemObject bem_lctokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lctok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_6_6_SystemObject bem_deployLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployLibrary = (BEC_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_6_6_SystemObject bem_deployPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployPath = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarys = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibraries = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_6_6_SystemObject bem_runSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_run = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_6_6_SystemObject bem_compilerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compiler = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLangsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLangs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_6_6_SystemObject bem_makeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_makeArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeArgs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_dynConditionsAllGet_0() throws Throwable {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_dynConditionsAll = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_6_6_SystemObject bem_readBufferSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_readBuffer = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitCommonSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {61, 63, 64, 65, 66, 68, 69, 70, 71, 72, 73, 74, 78, 80, 81, 82, 83, 83, 86, 89, 90, 95, 96, 97, 97, 102, 102, 102, 102, 0, 102, 102, 0, 0, 0, 0, 0, 103, 103, 105, 105, 109, 109, 109, 109, 113, 113, 114, 114, 118, 119, 120, 120, 124, 125, 126, 128, 129, 130, 132, 133, 133, 134, 0, 0, 0, 137, 139, 143, 143, 143, 144, 144, 144, 144, 145, 145, 145, 146, 146, 146, 147, 147, 147, 147, 148, 148, 148, 149, 149, 149, 151, 156, 158, 159, 159, 159, 160, 160, 0, 160, 160, 161, 161, 162, 163, 163, 168, 168, 168, 168, 169, 171, 171, 171, 172, 172, 173, 173, 173, 175, 177, 177, 177, 177, 177, 177, 178, 179, 179, 180, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 185, 185, 185, 186, 186, 186, 187, 187, 188, 188, 189, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 233, 233, 233, 234, 234, 234, 235, 235, 236, 236, 237, 238, 238, 239, 239, 239, 239, 0, 0, 0, 240, 0, 240, 240, 241, 244, 244, 245, 245, 246, 246, 247, 247, 247, 248, 248, 249, 249, 249, 249, 250, 250, 250, 250, 251, 251, 251, 251, 251, 252, 253, 254, 255, 256, 259, 259, 260, 262, 269, 269, 269, 269, 269, 270, 270, 271, 271, 274, 274, 274, 275, 275, 276, 276, 279, 280, 280, 0, 280, 280, 281, 281, 283, 284, 285, 287, 288, 288, 288, 289, 289, 291, 291, 292, 292, 293, 293, 294, 300, 301, 301, 301, 301, 301, 302, 302, 302, 302, 302, 303, 307, 308, 308, 308, 309, 310, 310, 310, 310, 311, 311, 311, 311, 312, 312, 312, 312, 312, 313, 313, 314, 0, 314, 314, 315, 318, 318, 318, 318, 318, 319, 319, 320, 0, 320, 320, 321, 326, 326, 326, 327, 328, 328, 328, 328, 328, 328, 335, 335, 339, 339, 340, 345, 345, 346, 347, 347, 348, 349, 349, 350, 351, 351, 352, 354, 354, 354, 356, 357, 359, 364, 365, 366, 367, 367, 368, 369, 371, 371, 371, 374, 376, 0, 376, 376, 377, 377, 378, 379, 380, 383, 0, 383, 383, 384, 384, 385, 386, 387, 388, 388, 393, 393, 394, 396, 398, 401, 401, 403, 403, 403, 405, 405, 405, 407, 407, 408, 408, 411, 412, 414, 414, 414, 415, 416, 418, 419, 420, 420, 420, 421, 422, 426, 426, 427, 427, 428, 428, 428, 430, 430, 430, 433, 437, 438, 439, 441, 0, 441, 441, 442, 442, 443, 443, 444, 444, 444, 445, 445, 446, 446, 448, 448, 448, 449, 449, 449, 453, 454, 456, 456, 0, 0, 0, 457, 457, 458, 458, 458, 458, 458, 458, 458, 458, 460, 460, 461, 461, 463, 463, 463, 464, 464, 464, 469, 469, 471, 471, 472, 472, 472, 474, 474, 475, 475, 475, 477, 477, 478, 478, 478, 482, 482, 483, 484, 484, 484, 484, 484, 485, 487, 487, 491, 491, 491, 492, 493, 493, 494, 495, 497, 497, 497, 498, 499, 499, 500, 501, 503, 503, 507, 507, 507, 507, 508, 508, 508, 510, 510, 511, 511, 511, 511, 512, 514, 514, 514, 514, 514, 516, 516, 517, 517, 518, 521, 521, 521, 523, 525, 525, 526, 526, 526, 526, 527, 531, 532, 532, 533, 533, 534, 540, 540, 541, 542, 549, 549, 550, 552, 557, 558, 559, 560, 561, 562, 562, 0, 0, 0, 565, 565, 565, 565, 567, 569, 569, 569, 569, 570, 570, 570, 571, 579, 579, 581, 581, 583, 583, 584, 584, 588, 588, 590, 590, 592, 592, 593, 593, 596, 596, 599, 599, 600, 602, 602, 603, 603, 607, 607, 609, 609, 611, 611, 612, 612, 616, 616, 618, 618, 620, 620, 621, 621, 625, 625, 627, 627, 629, 629, 630, 630, 634, 634, 636, 636, 638, 638, 639, 639, 643, 643, 645, 645, 647, 647, 648, 648, 652, 652, 654, 654, 656, 656, 657, 657, 661, 661, 663, 663, 665, 665, 666, 666, 669, 669, 671, 671, 673, 673, 674, 674, 678, 678, 679, 679, 681, 681, 0, 0, 0, 683, 683, 684, 684, 686, 686, 686, 687, 689, 690, 691, 691, 692, 693, 693, 693, 694, 695, 696, 697, 703, 704, 705, 706, 706, 707, 707, 708, 709, 709, 710, 711, 711, 712, 714, 714, 715, 716, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 270, 275, 276, 277, 279, 282, 283, 285, 288, 292, 295, 299, 302, 303, 305, 306, 312, 313, 314, 315, 321, 322, 323, 324, 328, 329, 330, 331, 339, 340, 341, 343, 344, 345, 349, 350, 351, 352, 355, 359, 362, 366, 368, 388, 389, 390, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 413, 544, 545, 546, 547, 552, 553, 554, 554, 557, 559, 560, 561, 563, 564, 565, 573, 574, 575, 576, 578, 580, 581, 582, 583, 584, 586, 587, 588, 591, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 637, 638, 640, 641, 642, 647, 648, 650, 651, 652, 657, 658, 660, 661, 662, 667, 668, 670, 671, 672, 677, 678, 680, 681, 682, 687, 688, 690, 691, 692, 697, 698, 700, 701, 702, 707, 708, 710, 711, 712, 717, 718, 720, 721, 722, 727, 728, 730, 731, 732, 737, 738, 741, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 761, 762, 763, 765, 768, 772, 775, 775, 778, 780, 781, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 822, 823, 826, 828, 829, 830, 831, 832, 833, 838, 839, 840, 842, 843, 844, 845, 850, 851, 852, 854, 855, 856, 856, 859, 861, 862, 863, 869, 870, 871, 872, 873, 874, 875, 877, 878, 880, 885, 886, 887, 888, 889, 890, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 955, 956, 957, 960, 962, 963, 964, 965, 966, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 982, 983, 983, 986, 988, 989, 996, 997, 998, 999, 1000, 1001, 1006, 1007, 1007, 1010, 1012, 1013, 1026, 1027, 1030, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1048, 1049, 1063, 1068, 1069, 1071, 1076, 1077, 1078, 1079, 1081, 1084, 1085, 1087, 1090, 1091, 1093, 1096, 1097, 1098, 1102, 1103, 1105, 1202, 1203, 1204, 1205, 1210, 1211, 1212, 1214, 1215, 1216, 1219, 1220, 1220, 1223, 1225, 1226, 1227, 1229, 1230, 1231, 1238, 1238, 1241, 1243, 1244, 1245, 1247, 1248, 1249, 1250, 1251, 1259, 1262, 1264, 1265, 1271, 1273, 1274, 1276, 1277, 1278, 1280, 1281, 1286, 1287, 1288, 1289, 1290, 1293, 1294, 1295, 1296, 1299, 1301, 1302, 1308, 1309, 1310, 1311, 1314, 1316, 1317, 1324, 1325, 1326, 1331, 1332, 1333, 1334, 1336, 1337, 1338, 1340, 1343, 1345, 1346, 1348, 1348, 1351, 1353, 1354, 1355, 1356, 1357, 1358, 1359, 1360, 1361, 1362, 1364, 1365, 1367, 1368, 1369, 1371, 1372, 1373, 1381, 1382, 1385, 1387, 1389, 1392, 1396, 1399, 1400, 1401, 1402, 1403, 1404, 1405, 1406, 1407, 1408, 1409, 1410, 1412, 1413, 1415, 1416, 1417, 1419, 1420, 1421, 1430, 1431, 1432, 1437, 1438, 1439, 1440, 1442, 1447, 1448, 1449, 1450, 1452, 1457, 1458, 1459, 1460, 1463, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1473, 1474, 1487, 1488, 1491, 1493, 1494, 1495, 1496, 1497, 1503, 1504, 1507, 1509, 1510, 1511, 1512, 1513, 1519, 1520, 1548, 1549, 1550, 1555, 1556, 1557, 1558, 1560, 1561, 1562, 1563, 1564, 1569, 1570, 1573, 1574, 1575, 1576, 1577, 1578, 1583, 1584, 1585, 1586, 1589, 1590, 1591, 1593, 1595, 1596, 1597, 1598, 1599, 1600, 1601, 1609, 1610, 1611, 1612, 1617, 1618, 1620, 1621, 1622, 1623, 1627, 1632, 1633, 1635, 1714, 1715, 1716, 1717, 1718, 1719, 1720, 1723, 1727, 1730, 1734, 1735, 1736, 1737, 1739, 1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1749, 1750, 1752, 1753, 1755, 1756, 1757, 1758, 1761, 1762, 1764, 1765, 1767, 1768, 1769, 1770, 1773, 1774, 1776, 1777, 1778, 1780, 1781, 1782, 1783, 1786, 1787, 1789, 1790, 1792, 1793, 1794, 1795, 1798, 1799, 1801, 1802, 1804, 1805, 1806, 1807, 1810, 1811, 1813, 1814, 1816, 1817, 1818, 1819, 1822, 1823, 1825, 1826, 1828, 1829, 1830, 1831, 1834, 1835, 1837, 1838, 1840, 1841, 1842, 1843, 1846, 1847, 1849, 1850, 1852, 1853, 1854, 1855, 1858, 1859, 1861, 1862, 1864, 1865, 1866, 1867, 1870, 1871, 1873, 1874, 1876, 1877, 1878, 1879, 1882, 1883, 1884, 1885, 1887, 1888, 1890, 1894, 1897, 1901, 1902, 1903, 1904, 1906, 1907, 1910, 1912, 1913, 1914, 1915, 1916, 1917, 1918, 1919, 1920, 1921, 1922, 1923, 1924, 1946, 1947, 1948, 1949, 1950, 1951, 1954, 1956, 1957, 1958, 1959, 1960, 1961, 1963, 1965, 1966, 1968, 1969, 1979, 1982, 1986, 1989, 1993, 1996, 2000, 2003, 2007, 2010, 2014, 2017, 2021, 2024, 2028, 2031, 2035, 2038, 2042, 2045, 2049, 2052, 2056, 2059, 2063, 2066, 2070, 2073, 2077, 2080, 2084, 2087, 2091, 2094, 2098, 2101, 2105, 2108, 2112, 2115, 2119, 2122, 2126, 2129, 2133, 2136, 2140, 2143, 2147, 2150, 2154, 2157, 2161, 2164, 2168, 2171, 2175, 2178, 2182, 2185, 2189, 2192, 2196, 2199, 2203, 2206, 2210, 2213, 2217, 2220, 2224, 2227, 2231, 2234, 2238, 2241, 2245, 2248, 2252, 2255, 2259, 2262, 2266, 2269, 2273, 2276, 2280, 2283, 2287, 2290, 2294, 2297, 2301, 2304, 2308, 2311, 2315, 2318, 2322, 2325, 2329, 2332, 2336, 2339, 2343, 2346, 2350, 2353, 2357, 2360, 2364, 2367, 2371, 2374, 2378, 2381, 2385, 2388, 2392, 2395, 2399, 2402, 2406, 2409, 2413, 2416, 2420, 2423, 2427, 2430, 2434, 2437, 2441};
/* BEGIN LINEINFO 
assign 1 61 234
new 0 61 234
assign 1 63 235
new 0 63 235
assign 1 64 236
new 0 64 236
assign 1 65 237
new 0 65 237
assign 1 66 238
new 0 66 238
assign 1 68 239
new 0 68 239
assign 1 69 240
new 0 69 240
assign 1 70 241
new 0 70 241
assign 1 71 242
new 0 71 242
assign 1 72 243
new 0 72 243
assign 1 73 244
new 0 73 244
assign 1 74 245
new 0 74 245
assign 1 78 246
new 0 78 246
assign 1 80 247
new 1 80 247
assign 1 81 248
ntypesGet 0 81 248
assign 1 82 249
twtokGet 0 82 249
assign 1 83 250
new 0 83 250
assign 1 83 251
new 1 83 251
assign 1 86 252
new 0 86 252
assign 1 89 253
new 0 89 253
assign 1 90 254
new 0 90 254
assign 1 95 255
new 0 95 255
assign 1 96 256
new 0 96 256
assign 1 97 257
new 0 97 257
assign 1 97 258
new 1 97 258
assign 1 102 270
def 1 102 275
assign 1 102 276
new 0 102 276
assign 1 102 277
equals 1 102 277
assign 1 0 279
assign 1 102 282
new 0 102 282
assign 1 102 283
ends 1 102 283
assign 1 0 285
assign 1 0 288
assign 1 0 292
assign 1 0 295
assign 1 0 299
assign 1 103 302
new 0 103 302
return 1 103 303
assign 1 105 305
new 0 105 305
return 1 105 306
assign 1 109 312
new 0 109 312
assign 1 109 313
new 0 109 313
assign 1 109 314
swap 2 109 314
return 1 109 315
assign 1 113 321
new 0 113 321
assign 1 113 322
argsGet 0 113 322
assign 1 114 323
main 1 114 323
return 1 114 324
assign 1 118 328
assign 1 119 329
new 1 119 329
assign 1 120 330
go 0 120 330
return 1 120 331
assign 1 124 339
new 0 124 339
config 0 125 340
assign 1 126 341
new 0 126 341
assign 1 128 343
new 0 128 343
assign 1 129 344
doWhat 0 129 344
assign 1 130 345
new 0 130 345
assign 1 132 349
new 0 132 349
assign 1 133 350
new 0 133 350
assign 1 133 351
add 1 133 351
assign 1 134 352
new 0 134 352
assign 1 0 355
assign 1 0 359
assign 1 0 362
print 0 137 366
return 1 139 368
assign 1 143 388
nameGet 0 143 388
assign 1 143 389
new 0 143 389
assign 1 143 390
equals 1 143 390
assign 1 144 392
new 0 144 392
assign 1 144 393
add 1 144 393
assign 1 144 394
add 1 144 394
assign 1 144 395
add 1 144 395
assign 1 145 396
new 0 145 396
assign 1 145 397
add 1 145 397
assign 1 145 398
add 1 145 398
assign 1 146 399
new 0 146 399
assign 1 146 400
add 1 146 400
assign 1 146 401
add 1 146 401
assign 1 147 402
new 0 147 402
assign 1 147 403
add 1 147 403
assign 1 147 404
add 1 147 404
assign 1 147 405
add 1 147 405
assign 1 148 406
new 0 148 406
assign 1 148 407
add 1 148 407
assign 1 148 408
add 1 148 408
assign 1 149 409
new 0 149 409
assign 1 149 410
add 1 149 410
assign 1 149 411
add 1 149 411
return 1 151 413
assign 1 156 544
new 0 156 544
assign 1 158 545
new 0 158 545
assign 1 159 546
get 1 159 546
assign 1 159 547
def 1 159 552
assign 1 160 553
get 1 160 553
assign 1 160 554
iteratorGet 0 0 554
assign 1 160 557
hasNextGet 0 160 557
assign 1 160 559
nextGet 0 160 559
assign 1 161 560
has 1 161 560
assign 1 161 561
not 0 161 561
put 1 162 563
assign 1 163 564
new 1 163 564
addFile 1 163 565
assign 1 168 573
new 0 168 573
assign 1 168 574
nameGet 0 168 574
assign 1 168 575
new 0 168 575
assign 1 168 576
equals 1 168 576
preProcessorSet 1 169 578
assign 1 171 580
new 0 171 580
assign 1 171 581
get 1 171 581
assign 1 171 582
firstGet 0 171 582
assign 1 172 583
new 0 172 583
assign 1 172 584
has 1 172 584
assign 1 173 586
new 0 173 586
assign 1 173 587
get 1 173 587
assign 1 173 588
firstGet 0 173 588
assign 1 175 591
assign 1 177 593
new 0 177 593
assign 1 177 594
new 0 177 594
assign 1 177 595
get 2 177 595
assign 1 177 596
firstGet 0 177 596
assign 1 177 597
new 1 177 597
assign 1 177 598
pathGet 0 177 598
addStep 1 178 599
assign 1 179 600
new 0 179 600
addStep 1 179 601
assign 1 180 602
new 0 180 602
assign 1 180 603
new 0 180 603
assign 1 180 604
get 2 180 604
assign 1 180 605
firstGet 0 180 605
assign 1 180 606
new 1 180 606
assign 1 180 607
pathGet 0 180 607
assign 1 181 608
new 0 181 608
assign 1 181 609
new 0 181 609
assign 1 181 610
nameGet 0 181 610
assign 1 181 611
get 2 181 611
assign 1 181 612
firstGet 0 181 612
assign 1 181 613
new 1 181 613
assign 1 182 614
new 0 182 614
assign 1 182 615
nameGet 0 182 615
assign 1 182 616
get 2 182 616
assign 1 182 617
firstGet 0 182 617
assign 1 182 618
new 1 182 618
assign 1 183 619
new 0 183 619
assign 1 183 620
new 0 183 620
assign 1 183 621
get 2 183 621
assign 1 183 622
firstGet 0 183 622
assign 1 183 623
new 1 183 623
assign 1 185 624
new 0 185 624
assign 1 185 625
get 1 185 625
assign 1 185 626
firstGet 0 185 626
assign 1 186 627
new 0 186 627
assign 1 186 628
get 1 186 628
assign 1 186 629
firstGet 0 186 629
assign 1 187 630
new 0 187 630
assign 1 187 631
get 1 187 631
assign 1 188 632
undef 1 188 637
assign 1 189 638
new 0 189 638
assign 1 191 640
new 0 191 640
assign 1 191 641
get 1 191 641
assign 1 192 642
undef 1 192 647
assign 1 193 648
new 0 193 648
assign 1 195 650
new 0 195 650
assign 1 195 651
get 1 195 651
assign 1 196 652
undef 1 196 657
assign 1 197 658
new 0 197 658
assign 1 199 660
new 0 199 660
assign 1 199 661
get 1 199 661
assign 1 200 662
undef 1 200 667
assign 1 201 668
new 0 201 668
assign 1 203 670
new 0 203 670
assign 1 203 671
get 1 203 671
assign 1 204 672
undef 1 204 677
assign 1 205 678
new 0 205 678
assign 1 207 680
new 0 207 680
assign 1 207 681
get 1 207 681
assign 1 208 682
undef 1 208 687
assign 1 209 688
new 0 209 688
assign 1 211 690
new 0 211 690
assign 1 211 691
get 1 211 691
assign 1 212 692
undef 1 212 697
assign 1 213 698
new 0 213 698
assign 1 215 700
new 0 215 700
assign 1 215 701
get 1 215 701
assign 1 216 702
undef 1 216 707
assign 1 217 708
new 0 217 708
assign 1 219 710
new 0 219 710
assign 1 219 711
get 1 219 711
assign 1 220 712
undef 1 220 717
assign 1 221 718
new 0 221 718
assign 1 223 720
new 0 223 720
assign 1 223 721
get 1 223 721
assign 1 224 722
def 1 224 727
assign 1 225 728
firstGet 0 225 728
assign 1 227 730
new 0 227 730
assign 1 227 731
get 1 227 731
assign 1 228 732
def 1 228 737
assign 1 229 738
firstGet 0 229 738
assign 1 231 741
new 0 231 741
assign 1 233 743
new 0 233 743
assign 1 233 744
new 0 233 744
assign 1 233 745
isTrue 2 233 745
assign 1 234 746
new 0 234 746
assign 1 234 747
new 0 234 747
assign 1 234 748
isTrue 2 234 748
assign 1 235 749
new 0 235 749
assign 1 235 750
isTrue 1 235 750
assign 1 236 751
new 0 236 751
assign 1 236 752
isTrue 1 236 752
assign 1 237 753
new 0 237 753
assign 1 238 754
new 0 238 754
assign 1 238 755
get 1 238 755
assign 1 239 756
def 1 239 761
assign 1 239 762
isEmptyGet 0 239 762
assign 1 239 763
not 0 239 763
assign 1 0 765
assign 1 0 768
assign 1 0 772
assign 1 240 775
iteratorGet 0 0 775
assign 1 240 778
hasNextGet 0 240 778
assign 1 240 780
nextGet 0 240 780
put 1 241 781
assign 1 244 788
new 0 244 788
assign 1 244 789
isTrue 1 244 789
assign 1 245 790
new 0 245 790
assign 1 245 791
isTrue 1 245 791
assign 1 246 792
new 0 246 792
assign 1 246 793
isTrue 1 246 793
assign 1 247 794
new 0 247 794
assign 1 247 795
new 0 247 795
assign 1 247 796
isTrue 2 247 796
assign 1 248 797
new 0 248 797
assign 1 248 798
get 1 248 798
assign 1 249 799
new 0 249 799
assign 1 249 800
new 0 249 800
assign 1 249 801
get 2 249 801
assign 1 249 802
firstGet 0 249 802
assign 1 250 803
new 0 250 803
assign 1 250 804
new 0 250 804
assign 1 250 805
get 2 250 805
assign 1 250 806
firstGet 0 250 806
assign 1 251 807
new 0 251 807
assign 1 251 808
add 1 251 808
assign 1 251 809
new 0 251 809
assign 1 251 810
get 2 251 810
assign 1 251 811
firstGet 0 251 811
assign 1 252 812
new 0 252 812
assign 1 253 813
new 0 253 813
assign 1 254 814
new 0 254 814
assign 1 255 815
new 0 255 815
assign 1 256 816
new 0 256 816
assign 1 259 817
def 1 259 822
assign 1 260 823
firstGet 0 260 823
assign 1 262 826
new 0 262 826
assign 1 269 828
new 0 269 828
assign 1 269 829
add 1 269 829
assign 1 269 830
nameGet 0 269 830
assign 1 269 831
add 1 269 831
assign 1 269 832
get 1 269 832
assign 1 270 833
def 1 270 838
assign 1 271 839
orderedGet 0 271 839
addAll 1 271 840
assign 1 274 842
new 0 274 842
assign 1 274 843
add 1 274 843
assign 1 274 844
get 1 274 844
assign 1 275 845
def 1 275 850
assign 1 276 851
orderedGet 0 276 851
addAll 1 276 852
assign 1 279 854
new 0 279 854
assign 1 280 855
orderedGet 0 280 855
assign 1 280 856
iteratorGet 0 0 856
assign 1 280 859
hasNextGet 0 280 859
assign 1 280 861
nextGet 0 280 861
assign 1 281 862
new 1 281 862
addValue 1 281 863
assign 1 283 869
newlineGet 0 283 869
assign 1 284 870
assign 1 285 871
new 1 285 871
assign 1 287 872
copy 0 287 872
assign 1 288 873
fileGet 0 288 873
assign 1 288 874
existsGet 0 288 874
assign 1 288 875
not 0 288 875
assign 1 289 877
fileGet 0 289 877
makeDirs 0 289 878
assign 1 291 880
def 1 291 885
assign 1 292 886
new 1 292 886
assign 1 292 887
readerGet 0 292 887
assign 1 293 888
open 0 293 888
assign 1 293 889
readString 1 293 889
close 0 294 890
assign 1 300 904
classNameGet 0 300 904
assign 1 301 905
add 1 301 905
assign 1 301 906
new 0 301 906
assign 1 301 907
add 1 301 907
assign 1 301 908
toString 0 301 908
assign 1 301 909
add 1 301 909
assign 1 302 910
add 1 302 910
assign 1 302 911
new 0 302 911
assign 1 302 912
add 1 302 912
assign 1 302 913
toString 0 302 913
assign 1 302 914
add 1 302 914
return 1 303 915
assign 1 307 955
new 0 307 955
assign 1 308 956
classesGet 0 308 956
assign 1 308 957
valueIteratorGet 0 308 957
assign 1 308 960
hasNextGet 0 308 960
assign 1 309 962
nextGet 0 309 962
assign 1 310 963
shouldEmitGet 0 310 963
assign 1 310 964
heldGet 0 310 964
assign 1 310 965
fromFileGet 0 310 965
assign 1 310 966
has 1 310 966
assign 1 311 968
heldGet 0 311 968
assign 1 311 969
namepathGet 0 311 969
assign 1 311 970
toString 0 311 970
put 1 311 971
assign 1 312 972
usedByGet 0 312 972
assign 1 312 973
heldGet 0 312 973
assign 1 312 974
namepathGet 0 312 974
assign 1 312 975
toString 0 312 975
assign 1 312 976
get 1 312 976
assign 1 313 977
def 1 313 982
assign 1 314 983
iteratorGet 0 0 983
assign 1 314 986
hasNextGet 0 314 986
assign 1 314 988
nextGet 0 314 988
put 1 315 989
assign 1 318 996
subClassesGet 0 318 996
assign 1 318 997
heldGet 0 318 997
assign 1 318 998
namepathGet 0 318 998
assign 1 318 999
toString 0 318 999
assign 1 318 1000
get 1 318 1000
assign 1 319 1001
def 1 319 1006
assign 1 320 1007
iteratorGet 0 0 1007
assign 1 320 1010
hasNextGet 0 320 1010
assign 1 320 1012
nextGet 0 320 1012
put 1 321 1013
assign 1 326 1026
classesGet 0 326 1026
assign 1 326 1027
valueIteratorGet 0 326 1027
assign 1 326 1030
hasNextGet 0 326 1030
assign 1 327 1032
nextGet 0 327 1032
assign 1 328 1033
heldGet 0 328 1033
assign 1 328 1034
heldGet 0 328 1034
assign 1 328 1035
namepathGet 0 328 1035
assign 1 328 1036
toString 0 328 1036
assign 1 328 1037
has 1 328 1037
shouldWriteSet 1 328 1038
assign 1 335 1048
new 0 335 1048
return 1 335 1049
assign 1 339 1063
def 1 339 1068
return 1 340 1069
assign 1 345 1071
def 1 345 1076
assign 1 346 1077
firstGet 0 346 1077
assign 1 347 1078
new 0 347 1078
assign 1 347 1079
equals 1 347 1079
assign 1 348 1081
new 1 348 1081
assign 1 349 1084
new 0 349 1084
assign 1 349 1085
equals 1 349 1085
assign 1 350 1087
new 1 350 1087
assign 1 351 1090
new 0 351 1090
assign 1 351 1091
equals 1 351 1091
assign 1 352 1093
new 1 352 1093
assign 1 354 1096
new 0 354 1096
assign 1 354 1097
new 1 354 1097
throw 1 354 1098
dynConditionsAllSet 1 356 1102
return 1 357 1103
return 1 359 1105
assign 1 364 1202
now 0 364 1202
assign 1 365 1203
new 0 365 1203
assign 1 366 1204
emitterGet 0 366 1204
assign 1 367 1205
def 1 367 1210
assign 1 368 1211
new 4 368 1211
put 1 369 1212
assign 1 371 1214
new 0 371 1214
assign 1 371 1215
add 1 371 1215
print 0 371 1216
assign 1 374 1219
new 0 374 1219
assign 1 376 1220
iteratorGet 0 0 1220
assign 1 376 1223
hasNextGet 0 376 1223
assign 1 376 1225
nextGet 0 376 1225
assign 1 377 1226
has 1 377 1226
assign 1 377 1227
not 0 377 1227
put 1 378 1229
assign 1 379 1230
new 2 379 1230
addValue 1 380 1231
assign 1 383 1238
iteratorGet 0 0 1238
assign 1 383 1241
hasNextGet 0 383 1241
assign 1 383 1243
nextGet 0 383 1243
assign 1 384 1244
has 1 384 1244
assign 1 384 1245
not 0 384 1245
put 1 385 1247
assign 1 386 1248
new 2 386 1248
addValue 1 387 1249
assign 1 388 1250
libNameGet 0 388 1250
put 1 388 1251
assign 1 393 1259
iteratorGet 0 393 1259
assign 1 393 1262
hasNextGet 0 393 1262
assign 1 394 1264
nextGet 0 394 1264
doParse 1 396 1265
buildSyns 1 398 1271
assign 1 401 1273
now 0 401 1273
assign 1 401 1274
subtract 1 401 1274
assign 1 403 1276
new 0 403 1276
assign 1 403 1277
add 1 403 1277
print 0 403 1278
assign 1 405 1280
emitCommonGet 0 405 1280
assign 1 405 1281
def 1 405 1286
assign 1 407 1287
emitCommonGet 0 407 1287
doEmit 0 407 1288
assign 1 408 1289
new 0 408 1289
return 1 408 1290
setClassesToWrite 0 411 1293
libnameInfoGet 0 412 1294
assign 1 414 1295
classesGet 0 414 1295
assign 1 414 1296
valueIteratorGet 0 414 1296
assign 1 414 1299
hasNextGet 0 414 1299
assign 1 415 1301
nextGet 0 415 1301
doEmit 1 416 1302
emitMain 0 418 1308
emitCUInit 0 419 1309
assign 1 420 1310
classesGet 0 420 1310
assign 1 420 1311
valueIteratorGet 0 420 1311
assign 1 420 1314
hasNextGet 0 420 1314
assign 1 421 1316
nextGet 0 421 1316
emitSyn 1 422 1317
assign 1 426 1324
now 0 426 1324
assign 1 426 1325
subtract 1 426 1325
assign 1 427 1326
def 1 427 1331
assign 1 428 1332
new 0 428 1332
assign 1 428 1333
add 1 428 1333
print 0 428 1334
assign 1 430 1336
new 0 430 1336
assign 1 430 1337
add 1 430 1337
print 0 430 1338
prepMake 1 433 1340
assign 1 437 1343
not 0 437 1343
make 1 438 1345
deployLibrary 1 439 1346
assign 1 441 1348
iteratorGet 0 0 1348
assign 1 441 1351
hasNextGet 0 441 1351
assign 1 441 1353
nextGet 0 441 1353
assign 1 442 1354
libnameInfoGet 0 442 1354
assign 1 442 1355
unitShlibGet 0 442 1355
assign 1 443 1356
emitPathGet 0 443 1356
assign 1 443 1357
copy 0 443 1357
assign 1 444 1358
stepsGet 0 444 1358
assign 1 444 1359
lastGet 0 444 1359
addStep 1 444 1360
assign 1 445 1361
fileGet 0 445 1361
assign 1 445 1362
existsGet 0 445 1362
assign 1 446 1364
fileGet 0 446 1364
delete 0 446 1365
assign 1 448 1367
fileGet 0 448 1367
assign 1 448 1368
existsGet 0 448 1368
assign 1 448 1369
not 0 448 1369
assign 1 449 1371
fileGet 0 449 1371
assign 1 449 1372
fileGet 0 449 1372
deployFile 2 449 1373
assign 1 453 1381
iteratorGet 0 453 1381
assign 1 454 1382
iteratorGet 0 454 1382
assign 1 456 1385
hasNextGet 0 456 1385
assign 1 456 1387
hasNextGet 0 456 1387
assign 1 0 1389
assign 1 0 1392
assign 1 0 1396
assign 1 457 1399
nextGet 0 457 1399
assign 1 457 1400
apNew 1 457 1400
assign 1 458 1401
emitPathGet 0 458 1401
assign 1 458 1402
copy 0 458 1402
assign 1 458 1403
toString 0 458 1403
assign 1 458 1404
new 0 458 1404
assign 1 458 1405
add 1 458 1405
assign 1 458 1406
nextGet 0 458 1406
assign 1 458 1407
add 1 458 1407
assign 1 458 1408
apNew 1 458 1408
assign 1 460 1409
fileGet 0 460 1409
assign 1 460 1410
existsGet 0 460 1410
assign 1 461 1412
fileGet 0 461 1412
delete 0 461 1413
assign 1 463 1415
fileGet 0 463 1415
assign 1 463 1416
existsGet 0 463 1416
assign 1 463 1417
not 0 463 1417
assign 1 464 1419
fileGet 0 464 1419
assign 1 464 1420
fileGet 0 464 1420
deployFile 2 464 1421
assign 1 469 1430
now 0 469 1430
assign 1 469 1431
subtract 1 469 1431
assign 1 471 1432
def 1 471 1437
assign 1 472 1438
new 0 472 1438
assign 1 472 1439
add 1 472 1439
print 0 472 1440
assign 1 474 1442
def 1 474 1447
assign 1 475 1448
new 0 475 1448
assign 1 475 1449
add 1 475 1449
print 0 475 1450
assign 1 477 1452
def 1 477 1457
assign 1 478 1458
new 0 478 1458
assign 1 478 1459
add 1 478 1459
print 0 478 1460
assign 1 482 1463
new 0 482 1463
print 0 482 1464
assign 1 483 1465
run 2 483 1465
assign 1 484 1466
new 0 484 1466
assign 1 484 1467
add 1 484 1467
assign 1 484 1468
new 0 484 1468
assign 1 484 1469
add 1 484 1469
print 0 484 1470
return 1 485 1471
assign 1 487 1473
new 0 487 1473
return 1 487 1474
assign 1 491 1487
justParsedGet 0 491 1487
assign 1 491 1488
valueIteratorGet 0 491 1488
assign 1 491 1491
hasNextGet 0 491 1491
assign 1 492 1493
nextGet 0 492 1493
assign 1 493 1494
heldGet 0 493 1494
libNameSet 1 493 1495
assign 1 494 1496
getSyn 2 494 1496
libNameSet 1 495 1497
assign 1 497 1503
justParsedGet 0 497 1503
assign 1 497 1504
valueIteratorGet 0 497 1504
assign 1 497 1507
hasNextGet 0 497 1507
assign 1 498 1509
nextGet 0 498 1509
assign 1 499 1510
heldGet 0 499 1510
assign 1 499 1511
synGet 0 499 1511
checkInheritance 2 500 1512
integrate 1 501 1513
assign 1 503 1519
new 0 503 1519
justParsedSet 1 503 1520
assign 1 507 1548
heldGet 0 507 1548
assign 1 507 1549
synGet 0 507 1549
assign 1 507 1550
def 1 507 1555
assign 1 508 1556
heldGet 0 508 1556
assign 1 508 1557
synGet 0 508 1557
return 1 508 1558
assign 1 510 1560
heldGet 0 510 1560
libNameSet 1 510 1561
assign 1 511 1562
heldGet 0 511 1562
assign 1 511 1563
extendsGet 0 511 1563
assign 1 511 1564
undef 1 511 1569
assign 1 512 1570
new 1 512 1570
assign 1 514 1573
classesGet 0 514 1573
assign 1 514 1574
heldGet 0 514 1574
assign 1 514 1575
extendsGet 0 514 1575
assign 1 514 1576
toString 0 514 1576
assign 1 514 1577
get 1 514 1577
assign 1 516 1578
def 1 516 1583
assign 1 517 1584
heldGet 0 517 1584
libNameSet 1 517 1585
assign 1 518 1586
getSyn 2 518 1586
assign 1 521 1589
heldGet 0 521 1589
assign 1 521 1590
extendsGet 0 521 1590
assign 1 521 1591
loadSyn 1 521 1591
assign 1 523 1593
new 2 523 1593
assign 1 525 1595
heldGet 0 525 1595
synSet 1 525 1596
assign 1 526 1597
heldGet 0 526 1597
assign 1 526 1598
namepathGet 0 526 1598
assign 1 526 1599
toString 0 526 1599
addSynClass 2 526 1600
return 1 527 1601
assign 1 531 1609
toString 0 531 1609
assign 1 532 1610
synClassesGet 0 532 1610
assign 1 532 1611
get 1 532 1611
assign 1 533 1612
def 1 533 1617
return 1 534 1618
assign 1 540 1620
emitterGet 0 540 1620
assign 1 540 1621
loadSyn 1 540 1621
addSynClass 2 541 1622
return 1 542 1623
assign 1 549 1627
undef 1 549 1632
assign 1 550 1633
new 1 550 1633
return 1 552 1635
assign 1 557 1714
new 1 557 1714
assign 1 558 1715
new 0 558 1715
assign 1 559 1716
emitterGet 0 559 1716
assign 1 560 1717
assign 1 561 1718
new 0 561 1718
assign 1 562 1719
shouldEmitGet 0 562 1719
put 1 562 1720
assign 1 0 1723
assign 1 0 1727
assign 1 0 1730
assign 1 565 1734
new 0 565 1734
assign 1 565 1735
toString 0 565 1735
assign 1 565 1736
add 1 565 1736
print 0 565 1737
assign 1 567 1739
assign 1 569 1740
fileGet 0 569 1740
assign 1 569 1741
readerGet 0 569 1741
assign 1 569 1742
open 0 569 1742
assign 1 569 1743
readBuffer 1 569 1743
assign 1 570 1744
fileGet 0 570 1744
assign 1 570 1745
readerGet 0 570 1745
close 0 570 1746
assign 1 571 1747
tokenize 1 571 1747
assign 1 579 1749
new 0 579 1749
echo 0 579 1750
assign 1 581 1752
outermostGet 0 581 1752
nodify 2 581 1753
assign 1 583 1755
new 0 583 1755
print 0 583 1756
assign 1 584 1757
new 2 584 1757
traverse 1 584 1758
assign 1 588 1761
new 0 588 1761
echo 0 588 1762
assign 1 590 1764
new 0 590 1764
traverse 1 590 1765
assign 1 592 1767
new 0 592 1767
print 0 592 1768
assign 1 593 1769
new 2 593 1769
traverse 1 593 1770
assign 1 596 1773
new 0 596 1773
echo 0 596 1774
assign 1 599 1776
new 0 599 1776
traverse 1 599 1777
contain 0 600 1778
assign 1 602 1780
new 0 602 1780
print 0 602 1781
assign 1 603 1782
new 2 603 1782
traverse 1 603 1783
assign 1 607 1786
new 0 607 1786
echo 0 607 1787
assign 1 609 1789
new 0 609 1789
traverse 1 609 1790
assign 1 611 1792
new 0 611 1792
print 0 611 1793
assign 1 612 1794
new 2 612 1794
traverse 1 612 1795
assign 1 616 1798
new 0 616 1798
echo 0 616 1799
assign 1 618 1801
new 0 618 1801
traverse 1 618 1802
assign 1 620 1804
new 0 620 1804
print 0 620 1805
assign 1 621 1806
new 2 621 1806
traverse 1 621 1807
assign 1 625 1810
new 0 625 1810
echo 0 625 1811
assign 1 627 1813
new 0 627 1813
traverse 1 627 1814
assign 1 629 1816
new 0 629 1816
print 0 629 1817
assign 1 630 1818
new 2 630 1818
traverse 1 630 1819
assign 1 634 1822
new 0 634 1822
echo 0 634 1823
assign 1 636 1825
new 0 636 1825
traverse 1 636 1826
assign 1 638 1828
new 0 638 1828
print 0 638 1829
assign 1 639 1830
new 2 639 1830
traverse 1 639 1831
assign 1 643 1834
new 0 643 1834
echo 0 643 1835
assign 1 645 1837
new 0 645 1837
traverse 1 645 1838
assign 1 647 1840
new 0 647 1840
print 0 647 1841
assign 1 648 1842
new 2 648 1842
traverse 1 648 1843
assign 1 652 1846
new 0 652 1846
echo 0 652 1847
assign 1 654 1849
new 0 654 1849
traverse 1 654 1850
assign 1 656 1852
new 0 656 1852
print 0 656 1853
assign 1 657 1854
new 2 657 1854
traverse 1 657 1855
assign 1 661 1858
new 0 661 1858
echo 0 661 1859
assign 1 663 1861
new 0 663 1861
traverse 1 663 1862
assign 1 665 1864
new 0 665 1864
print 0 665 1865
assign 1 666 1866
new 2 666 1866
traverse 1 666 1867
assign 1 669 1870
new 0 669 1870
echo 0 669 1871
assign 1 671 1873
new 0 671 1873
traverse 1 671 1874
assign 1 673 1876
new 0 673 1876
print 0 673 1877
assign 1 674 1878
new 2 674 1878
traverse 1 674 1879
assign 1 678 1882
new 0 678 1882
echo 0 678 1883
assign 1 679 1884
new 0 679 1884
print 0 679 1885
assign 1 681 1887
new 0 681 1887
traverse 1 681 1888
assign 1 0 1890
assign 1 0 1894
assign 1 0 1897
assign 1 683 1901
new 0 683 1901
print 0 683 1902
assign 1 684 1903
new 2 684 1903
traverse 1 684 1904
assign 1 686 1906
classesGet 0 686 1906
assign 1 686 1907
valueIteratorGet 0 686 1907
assign 1 686 1910
hasNextGet 0 686 1910
assign 1 687 1912
nextGet 0 687 1912
assign 1 689 1913
transUnitGet 0 689 1913
assign 1 690 1914
new 1 690 1914
assign 1 691 1915
TRANSUNITGet 0 691 1915
typenameSet 1 691 1916
assign 1 692 1917
new 0 692 1917
assign 1 693 1918
heldGet 0 693 1918
assign 1 693 1919
emitsGet 0 693 1919
emitsSet 1 693 1920
heldSet 1 694 1921
delete 0 695 1922
addValue 1 696 1923
copyLoc 1 697 1924
reInitContained 0 703 1946
assign 1 704 1947
containedGet 0 704 1947
assign 1 705 1948
new 0 705 1948
assign 1 706 1949
new 0 706 1949
assign 1 706 1950
crGet 0 706 1950
assign 1 707 1951
iteratorGet 0 707 1951
assign 1 707 1954
hasNextGet 0 707 1954
assign 1 708 1956
new 1 708 1956
assign 1 709 1957
nextGet 0 709 1957
heldSet 1 709 1958
nlcSet 1 710 1959
assign 1 711 1960
heldGet 0 711 1960
assign 1 711 1961
equals 1 711 1961
assign 1 712 1963
increment 0 712 1963
assign 1 714 1965
heldGet 0 714 1965
assign 1 714 1966
notEquals 1 714 1966
addValue 1 715 1968
containerSet 1 716 1969
return 1 0 1979
assign 1 0 1982
return 1 0 1986
assign 1 0 1989
return 1 0 1993
assign 1 0 1996
return 1 0 2000
assign 1 0 2003
return 1 0 2007
assign 1 0 2010
return 1 0 2014
assign 1 0 2017
return 1 0 2021
assign 1 0 2024
return 1 0 2028
assign 1 0 2031
return 1 0 2035
assign 1 0 2038
return 1 0 2042
assign 1 0 2045
return 1 0 2049
assign 1 0 2052
return 1 0 2056
assign 1 0 2059
return 1 0 2063
assign 1 0 2066
return 1 0 2070
assign 1 0 2073
return 1 0 2077
assign 1 0 2080
return 1 0 2084
assign 1 0 2087
return 1 0 2091
assign 1 0 2094
return 1 0 2098
assign 1 0 2101
return 1 0 2105
assign 1 0 2108
return 1 0 2112
assign 1 0 2115
return 1 0 2119
assign 1 0 2122
return 1 0 2126
assign 1 0 2129
return 1 0 2133
assign 1 0 2136
return 1 0 2140
assign 1 0 2143
return 1 0 2147
assign 1 0 2150
return 1 0 2154
assign 1 0 2157
return 1 0 2161
assign 1 0 2164
return 1 0 2168
assign 1 0 2171
return 1 0 2175
assign 1 0 2178
return 1 0 2182
assign 1 0 2185
return 1 0 2189
assign 1 0 2192
return 1 0 2196
assign 1 0 2199
return 1 0 2203
assign 1 0 2206
return 1 0 2210
assign 1 0 2213
return 1 0 2217
assign 1 0 2220
return 1 0 2224
assign 1 0 2227
return 1 0 2231
assign 1 0 2234
return 1 0 2238
assign 1 0 2241
return 1 0 2245
assign 1 0 2248
return 1 0 2252
assign 1 0 2255
return 1 0 2259
assign 1 0 2262
return 1 0 2266
assign 1 0 2269
return 1 0 2273
assign 1 0 2276
return 1 0 2280
assign 1 0 2283
return 1 0 2287
assign 1 0 2290
return 1 0 2294
assign 1 0 2297
return 1 0 2301
assign 1 0 2304
return 1 0 2308
assign 1 0 2311
return 1 0 2315
assign 1 0 2318
return 1 0 2322
assign 1 0 2325
return 1 0 2329
assign 1 0 2332
return 1 0 2336
assign 1 0 2339
return 1 0 2343
assign 1 0 2346
return 1 0 2350
assign 1 0 2353
return 1 0 2357
assign 1 0 2360
return 1 0 2364
assign 1 0 2367
return 1 0 2371
assign 1 0 2374
return 1 0 2378
assign 1 0 2381
return 1 0 2385
assign 1 0 2388
return 1 0 2392
assign 1 0 2395
return 1 0 2399
assign 1 0 2402
return 1 0 2406
assign 1 0 2409
return 1 0 2413
assign 1 0 2416
return 1 0 2420
assign 1 0 2423
return 1 0 2427
assign 1 0 2430
return 1 0 2434
assign 1 0 2437
assign 1 0 2441
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1308786538: return bem_echo_0();
case 404051026: return bem_printPlacesGet_0();
case 729571811: return bem_serializeToString_0();
case 2113443821: return bem_deployLibraryGet_0();
case 34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case 340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case 580139405: return bem_config_0();
case 2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case 1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case 1803479881: return bem_libNameGet_0();
case 314718434: return bem_print_0();
case 2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case 186098742: return bem_exeNameGet_0();
case 1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case 829911139: return bem_compilerProfileGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case 658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case 2082855574: return bem_emitDataGet_0();
case 786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case 2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case 1919619119: return bem_setClassesToWrite_0();
case 2127864150: return bem_argsGet_0();
case 400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case 1003238764: return bem_parseGet_0();
case 902949587: return bem_printStepsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 1505775346: return bem_putLineNumbersInTraceGet_0();
case 1713520961: return bem_linkLibArgsGet_0();
case 1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case 644675716: return bem_ntypesGet_0();
case 1185503219: return bem_deployFilesFromGet_0();
case 1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case 1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case 560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case 733055122: return bem_makeNameGet_0();
case 328200718: return bem_printAstGet_0();
case 126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case 1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case 1458327669: return bem_emitFileHeaderGet_0();
case 1220511308: return bem_buildSucceededGet_0();
case 845792839: return bem_iteratorGet_0();
case 1149621350: return bem_codeGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 505952126: return bem_copyTo_1(bevd_0);
case 392968773: return bem_printPlacesSet_1(bevd_0);
case 2071773321: return bem_emitDataSet_1(bevd_0);
case 1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 1702438708: return bem_linkLibArgsSet_1(bevd_0);
case 891867334: return bem_printStepsSet_1(bevd_0);
case 647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 721972869: return bem_makeNameSet_1(bevd_0);
case 175016489: return bem_exeNameSet_1(bevd_0);
case 972018826: return bem_dllhead_1((BEC_4_6_TextString) bevd_0);
case 317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case 2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 115429536: return bem_outputPlatformSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case 1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1094759839: return bem_process_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case 706249818: return bem_getSynNp_1(bevd_0);
case 1310359934: return bem_emitLangsSet_1(bevd_0);
case 329197947: return bem_startTimeSet_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case 1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case 1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case 2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1138539097: return bem_codeSet_1(bevd_0);
case 23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 2036609109: return bem_buildSyns_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case 1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case 1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1081571541: return bem_main_1((BEC_9_5_ContainerArray) bevd_0);
case 593264218: return bem_isNewish_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_BuildBuild.bevs_inst = (BEC_5_5_BuildBuild)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_BuildBuild.bevs_inst;
}
}
