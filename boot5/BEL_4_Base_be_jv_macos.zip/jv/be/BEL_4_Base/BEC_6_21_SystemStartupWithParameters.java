package be.BEL_4_Base;
/* File: source/extended/Startup.be */
public class BEC_6_21_SystemStartupWithParameters extends BEC_6_6_SystemObject {
public BEC_6_21_SystemStartupWithParameters() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x57,0x69,0x74,0x68,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(1));
private static byte[] bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x41,0x72,0x72,0x61,0x79,0x20,0x61,0x72,0x67,0x73,0x2C,0x20,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73,0x20,0x70,0x61,0x72,0x61,0x6D,0x73,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(0));
public static BEC_6_21_SystemStartupWithParameters bevs_inst;
public BEC_9_5_ContainerArray bevp_args;
public BEC_6_10_SystemParameters bevp_params;
public BEC_6_6_SystemObject bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_21_SystemStartupWithParameters bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_main_0() throws Throwable {
BEC_6_6_SystemObject bevl_x = null;
BEC_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_6_9_SystemException bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_7_SystemProcess) BEC_6_7_SystemProcess.bevs_inst.bem_new_0();
bevp_args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_2_tmpvar_phold = bevp_args.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_lesser_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(165, bels_0));
bevt_4_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 97 */
bevp_params = (new BEC_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_8_tmpvar_phold = bevo_1;
bevt_7_tmpvar_phold = bevp_args.bem_get_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold = this.bem_createInstance_1((BEC_4_6_TextString) bevt_7_tmpvar_phold);
bevl_x = bevt_6_tmpvar_phold.bemd_0(104713553, BEL_4_Base.bevn_new_0);
bevt_9_tmpvar_phold = bevl_x.bemd_2(1081571540, BEL_4_Base.bevn_main_2, bevp_args, bevp_params);
return bevt_9_tmpvar_phold;
} /*method end*/
public BEC_9_5_ContainerArray bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_6_6_SystemObject bem_argsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_args = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_6_6_SystemObject bem_paramsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_params = (BEC_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {95, 95, 96, 96, 96, 97, 97, 97, 99, 100, 100, 100, 100, 101, 101, 0, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {31, 32, 33, 34, 35, 37, 38, 39, 41, 42, 43, 44, 45, 46, 47, 50, 53, 57, 60};
/* BEGIN LINEINFO 
assign 1 95 31
new 0 95 31
assign 1 95 32
argsGet 0 95 32
assign 1 96 33
sizeGet 0 96 33
assign 1 96 34
new 0 96 34
assign 1 96 35
lesser 1 96 35
assign 1 97 37
new 0 97 37
assign 1 97 38
new 1 97 38
throw 1 97 39
assign 1 99 41
new 1 99 41
assign 1 100 42
new 0 100 42
assign 1 100 43
get 1 100 43
assign 1 100 44
createInstance 1 100 44
assign 1 100 45
new 0 100 45
assign 1 101 46
main 2 101 46
return 1 101 47
return 1 0 50
assign 1 0 53
return 1 0 57
assign 1 0 60
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 1695168417: return bem_paramsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2127864150: return bem_argsGet_0();
case 2055025483: return bem_serializeContents_0();
case 1081571542: return bem_main_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_21_SystemStartupWithParameters();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_21_SystemStartupWithParameters.bevs_inst = (BEC_6_21_SystemStartupWithParameters)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_21_SystemStartupWithParameters.bevs_inst;
}
}
