package be.BEL_4_Base;
/* IO:File: source/base/Map.be */
public class BEC_9_3_ContainerSet extends BEC_6_6_SystemObject {
public BEC_9_3_ContainerSet() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_5 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(1));
public static BEC_9_3_ContainerSet bevs_inst;
public BEC_9_5_ContainerArray bevp_slots;
public BEC_4_3_MathInt bevp_modu;
public BEC_4_3_MathInt bevp_multi;
public BEC_9_3_9_ContainerSetRelations bevp_rel;
public BEC_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_4_3_MathInt bevp_size;
public BEC_5_4_LogicBool bevp_innerPutAdded;
public BEC_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_new_1(BEC_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_9_5_ContainerArray()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_4_3_MathInt(2));
bevp_rel = (BEC_9_3_9_ContainerSetRelations) BEC_9_3_9_ContainerSetRelations.bevs_inst.bem_new_0();
bevp_baseNode = (BEC_9_3_7_ContainerSetSetNode) (new BEC_9_3_7_ContainerSetSetNode()).bem_new_0();
bevp_size = (new BEC_4_3_MathInt(0));
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevp_size.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 226 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 227 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_21_SetSerializationIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_21_SetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_insertAll_2(BEC_9_5_ContainerArray beva_ninner, BEC_9_5_ContainerArray beva_ir) throws Throwable {
BEC_6_6_SystemObject bevl_i = null;
BEC_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = beva_ir.bem_iteratorGet_0();
while (true)
 /* Line: 245 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 245 */ {
bevl_ni = (BEC_9_3_7_ContainerSetSetNode) bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_ni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_4_tmpvar_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpvar_phold = this.bem_innerPut_4(bevt_4_tmpvar_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 249 */
} /* Line: 248 */
} /* Line: 247 */
 else  /* Line: 245 */ {
break;
} /* Line: 245 */
} /* Line: 245 */
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_rehash_1(BEC_9_5_ContainerArray beva_slt) throws Throwable {
BEC_4_3_MathInt bevl_nslots = null;
BEC_9_5_ContainerArray bevl_ninner = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpvar_phold = bevo_1;
bevl_nslots = bevt_0_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
bevl_ninner = (new BEC_9_5_ContainerArray()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 260 */ {
bevt_4_tmpvar_phold = this.bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (new BEC_9_5_ContainerArray()).bem_new_1(bevl_nslots);
} /* Line: 262 */
 else  /* Line: 260 */ {
break;
} /* Line: 260 */
} /* Line: 260 */
return bevl_ninner;
} /*method end*/
public BEC_5_4_LogicBool bem_contentsEqual_1(BEC_9_3_ContainerSet beva_other) throws Throwable {
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (beva_other == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
bevt_4_tmpvar_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpvar_phold = this.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 268 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 268 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 269 */
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 271 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevl_i = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = beva_other.bem_has_1(bevl_i);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_10_tmpvar_phold;
} /* Line: 272 */
} /* Line: 272 */
 else  /* Line: 271 */ {
break;
} /* Line: 271 */
} /* Line: 271 */
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_innerPut_4(BEC_6_6_SystemObject beva_k, BEC_6_6_SystemObject beva_v, BEC_6_6_SystemObject beva_inode, BEC_9_5_ContainerArray beva_slt) throws Throwable {
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 279 */ {
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_2;
bevt_1_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 281 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 282 */
} /* Line: 281 */
 else  /* Line: 284 */ {
bevl_hval = (BEC_4_3_MathInt) beva_inode.bemd_0(449328306, BEL_4_Base.bevn_hvalGet_0);
} /* Line: 285 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 289 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 291 */ {
if (beva_inode == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevt_6_tmpvar_phold = bevp_baseNode.bem_create_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_3(104713556, BEL_4_Base.bevn_new_3, bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpvar_phold);
} /* Line: 293 */
 else  /* Line: 294 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 295 */
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 298 */
 else  /* Line: 291 */ {
bevt_10_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 299 */ {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /* Line: 300 */
 else  /* Line: 291 */ {
bevt_13_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpvar_phold, beva_k);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 301 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_14_tmpvar_phold;
} /* Line: 305 */
 else  /* Line: 306 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_15_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 308 */ {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_16_tmpvar_phold;
} /* Line: 309 */
} /* Line: 308 */
} /* Line: 291 */
} /* Line: 291 */
} /* Line: 291 */
} /*method end*/
public BEC_6_6_SystemObject bem_put_1(BEC_6_6_SystemObject beva_k) throws Throwable {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 316 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 319 */ {
bevt_3_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 319 */ {
bevl_slt = (BEC_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
} /* Line: 320 */
 else  /* Line: 319 */ {
break;
} /* Line: 319 */
} /* Line: 319 */
bevp_slots = bevl_slt;
} /* Line: 322 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 324 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 325 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_get_1(BEC_6_6_SystemObject beva_k) throws Throwable {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 333 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 334 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 338 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 340 */ {
return null;
} /* Line: 341 */
 else  /* Line: 340 */ {
bevt_5_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 342 */ {
return null;
} /* Line: 343 */
 else  /* Line: 340 */ {
bevt_7_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpvar_phold, beva_k);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 344 */ {
bevt_8_tmpvar_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpvar_phold;
} /* Line: 345 */
 else  /* Line: 346 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_9_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 348 */ {
return null;
} /* Line: 349 */
} /* Line: 348 */
} /* Line: 340 */
} /* Line: 340 */
} /* Line: 340 */
} /*method end*/
public BEC_5_4_LogicBool bem_has_1(BEC_6_6_SystemObject beva_k) throws Throwable {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 359 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 360 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 364 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 366 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 367 */
 else  /* Line: 366 */ {
bevt_6_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 368 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /* Line: 369 */
 else  /* Line: 366 */ {
bevt_9_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpvar_phold, beva_k);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 370 */ {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 371 */
 else  /* Line: 372 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_11_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 374 */ {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /* Line: 375 */
} /* Line: 374 */
} /* Line: 366 */
} /* Line: 366 */
} /* Line: 366 */
} /*method end*/
public BEC_6_6_SystemObject bem_delete_1(BEC_6_6_SystemObject beva_k) throws Throwable {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_5;
bevt_1_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 386 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 387 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 391 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 393 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 394 */
 else  /* Line: 393 */ {
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 395 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 396 */
 else  /* Line: 393 */ {
bevt_10_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpvar_phold, beva_k);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 397 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 401 */ {
bevt_11_tmpvar_phold = bevl_sl.bem_lesser_1(bevl_modu);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 401 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 403 */ {
bevt_15_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 403 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 403 */ {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_16_tmpvar_phold;
} /* Line: 404 */
 else  /* Line: 405 */ {
bevt_18_tmpvar_phold = bevo_6;
bevt_17_tmpvar_phold = bevl_sl.bem_subtract_1(bevt_18_tmpvar_phold);
bevl_slt.bem_put_2(bevt_17_tmpvar_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 407 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 409 */
 else  /* Line: 401 */ {
break;
} /* Line: 401 */
} /* Line: 401 */
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_19_tmpvar_phold;
} /* Line: 411 */
 else  /* Line: 412 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_20_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 414 */ {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_21_tmpvar_phold;
} /* Line: 415 */
} /* Line: 414 */
} /* Line: 393 */
} /* Line: 393 */
} /* Line: 393 */
} /*method end*/
public BEC_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_6_6_SystemObject bevl_other = null;
BEC_4_3_MathInt bevl_i = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
bevl_other = this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = bevp_slots.bem_copy_0();
bevl_other.bemd_1(365988447, BEL_4_Base.bevn_slotsSet_1, bevt_0_tmpvar_phold);
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 425 */ {
bevt_2_tmpvar_phold = bevp_slots.bem_lengthGet_0();
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 425 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 427 */ {
bevt_4_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_6_tmpvar_phold = bevp_baseNode.bem_create_0();
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_3(104713556, BEL_4_Base.bevn_new_3, bevt_7_tmpvar_phold, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_4_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_5_tmpvar_phold);
} /* Line: 428 */
 else  /* Line: 429 */ {
bevt_10_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_10_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, null);
} /* Line: 430 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 425 */
 else  /* Line: 425 */ {
break;
} /* Line: 425 */
} /* Line: 425 */
return bevl_other;
} /*method end*/
public BEC_6_6_SystemObject bem_clear_0() throws Throwable {
bevp_slots.bem_clear_0();
bevp_size = (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_12_SetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_11_SetKeyIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_11_SetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_12_SetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_11_SetKeyIterator()).bem_new_1(this);
return (BEC_3_11_SetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_11_SetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_11_SetKeyIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_keyIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_12_SetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_12_SetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_12_SetNodeIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_12_SetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_12_SetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_nodeIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_3_ContainerSet bem_intersection_1(BEC_9_3_ContainerSet beva_other) throws Throwable {
BEC_9_3_ContainerSet bevl_i = null;
BEC_6_6_SystemObject bevl_x = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_i = (new BEC_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 464 */ {
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 465 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 465 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_3_tmpvar_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 466 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 467 */
} /* Line: 466 */
 else  /* Line: 465 */ {
break;
} /* Line: 465 */
} /* Line: 465 */
} /* Line: 465 */
return bevl_i;
} /*method end*/
public BEC_9_3_ContainerSet bem_union_1(BEC_9_3_ContainerSet beva_other) throws Throwable {
BEC_9_3_ContainerSet bevl_i = null;
BEC_6_6_SystemObject bevl_x = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevl_i = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 476 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 476 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bem_put_1(bevl_x);
} /* Line: 477 */
 else  /* Line: 476 */ {
break;
} /* Line: 476 */
} /* Line: 476 */
if (beva_other == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_1_tmpvar_loop = beva_other.bem_iteratorGet_0();
while (true)
 /* Line: 480 */ {
bevt_4_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 480 */ {
bevl_x = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bem_put_1(bevl_x);
} /* Line: 481 */
 else  /* Line: 480 */ {
break;
} /* Line: 480 */
} /* Line: 480 */
} /* Line: 480 */
return bevl_i;
} /*method end*/
public BEC_9_3_ContainerSet bem_add_1(BEC_9_3_ContainerSet beva_other) throws Throwable {
BEC_9_3_ContainerSet bevl_x = null;
bevl_x = (BEC_9_3_ContainerSet) this.bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_9_3_ContainerSet bem_addValue_1(BEC_6_6_SystemObject beva_other) throws Throwable {
BEC_6_6_SystemObject bevl_x = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 494 */ {
bevt_2_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 495 */ {
bevt_0_tmpvar_loop = beva_other.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 496 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 496 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_put_1(bevl_x);
} /* Line: 497 */
 else  /* Line: 496 */ {
break;
} /* Line: 496 */
} /* Line: 496 */
} /* Line: 496 */
 else  /* Line: 495 */ {
bevt_4_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 499 */ {
bevt_5_tmpvar_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
this.bem_put_1(bevt_5_tmpvar_phold);
} /* Line: 500 */
 else  /* Line: 501 */ {
this.bem_put_1(beva_other);
} /* Line: 502 */
} /* Line: 495 */
} /* Line: 495 */
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_6_6_SystemObject bem_slotsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_slots = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_6_6_SystemObject bem_moduSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_modu = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_multiGet_0() throws Throwable {
return bevp_multi;
} /*method end*/
public BEC_6_6_SystemObject bem_multiSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_multi = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_9_ContainerSetRelations bem_relGet_0() throws Throwable {
return bevp_rel;
} /*method end*/
public BEC_6_6_SystemObject bem_relSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_rel = (BEC_9_3_9_ContainerSetRelations) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public BEC_6_6_SystemObject bem_baseNodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_baseNode = (BEC_9_3_7_ContainerSetSetNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_6_6_SystemObject bem_sizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_size = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_innerPutAddedGet_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public BEC_6_6_SystemObject bem_innerPutAddedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_innerPutAdded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {208, 208, 214, 215, 216, 217, 218, 219, 220, 226, 226, 227, 227, 229, 229, 233, 233, 237, 237, 241, 241, 245, 245, 246, 247, 247, 248, 248, 248, 249, 249, 253, 253, 258, 258, 258, 258, 259, 260, 260, 261, 262, 264, 268, 268, 0, 268, 268, 268, 0, 0, 269, 269, 271, 0, 271, 271, 272, 272, 272, 272, 274, 274, 278, 279, 279, 280, 281, 281, 282, 285, 287, 288, 290, 291, 291, 292, 292, 293, 293, 293, 295, 297, 298, 298, 299, 299, 299, 300, 300, 301, 301, 302, 304, 305, 305, 307, 308, 309, 309, 316, 316, 317, 318, 319, 319, 320, 322, 325, 330, 331, 332, 333, 333, 334, 336, 337, 339, 340, 340, 341, 342, 342, 342, 343, 344, 344, 345, 345, 347, 348, 349, 356, 357, 358, 359, 359, 360, 362, 363, 365, 366, 366, 367, 367, 368, 368, 368, 369, 369, 370, 370, 371, 371, 373, 374, 375, 375, 382, 383, 385, 386, 386, 387, 389, 390, 392, 393, 393, 394, 394, 395, 395, 395, 396, 396, 397, 397, 398, 399, 400, 401, 402, 403, 403, 0, 403, 403, 403, 0, 0, 404, 404, 406, 406, 406, 407, 409, 411, 411, 413, 414, 415, 415, 422, 423, 424, 424, 425, 425, 425, 426, 427, 427, 428, 428, 428, 428, 428, 428, 428, 430, 430, 425, 433, 438, 439, 443, 443, 447, 447, 451, 451, 455, 455, 459, 459, 463, 464, 464, 465, 0, 465, 465, 466, 467, 471, 475, 476, 0, 476, 476, 477, 479, 479, 480, 0, 480, 480, 481, 484, 488, 489, 490, 494, 494, 495, 496, 0, 496, 496, 497, 499, 500, 500, 502, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 25, 29, 30, 31, 32, 33, 34, 35, 43, 44, 46, 47, 49, 50, 54, 55, 59, 60, 65, 66, 78, 81, 83, 84, 89, 90, 91, 92, 94, 95, 103, 104, 114, 115, 116, 117, 118, 121, 122, 124, 125, 131, 147, 152, 153, 156, 157, 158, 160, 163, 167, 168, 170, 170, 173, 175, 176, 177, 179, 180, 187, 188, 213, 214, 219, 220, 221, 222, 224, 228, 230, 231, 234, 235, 240, 241, 246, 247, 248, 249, 252, 254, 255, 256, 259, 260, 261, 263, 264, 267, 268, 270, 271, 272, 273, 276, 277, 279, 280, 293, 294, 296, 297, 300, 301, 303, 309, 312, 333, 334, 335, 336, 337, 339, 341, 342, 345, 346, 351, 352, 355, 356, 357, 359, 362, 363, 365, 366, 369, 370, 372, 399, 400, 401, 402, 403, 405, 407, 408, 411, 412, 417, 418, 419, 422, 423, 424, 426, 427, 430, 431, 433, 434, 437, 438, 440, 441, 477, 478, 479, 480, 481, 483, 485, 486, 489, 490, 495, 496, 497, 500, 501, 502, 504, 505, 508, 509, 511, 512, 513, 516, 518, 519, 524, 525, 528, 529, 530, 532, 535, 539, 540, 543, 544, 545, 546, 548, 554, 555, 558, 559, 561, 562, 584, 585, 586, 587, 588, 591, 592, 594, 595, 600, 601, 602, 603, 604, 605, 606, 607, 610, 611, 613, 619, 622, 623, 628, 629, 633, 634, 638, 639, 643, 644, 648, 649, 658, 659, 664, 665, 665, 668, 670, 671, 673, 681, 691, 692, 692, 695, 697, 698, 704, 709, 710, 710, 713, 715, 716, 723, 727, 728, 729, 739, 744, 745, 747, 747, 750, 752, 753, 761, 763, 764, 767, 774, 777, 781, 784, 788, 791, 795, 798, 802, 805, 809, 812, 816, 819};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 208 24
new 0 208 24
new 1 208 25
assign 1 214 29
new 1 214 29
assign 1 215 30
assign 1 216 31
new 0 216 31
assign 1 217 32
new 0 217 32
assign 1 218 33
new 0 218 33
assign 1 219 34
new 0 219 34
assign 1 220 35
new 0 220 35
assign 1 226 43
new 0 226 43
assign 1 226 44
equals 1 226 44
assign 1 227 46
new 0 227 46
return 1 227 47
assign 1 229 49
new 0 229 49
return 1 229 50
assign 1 233 54
toString 0 233 54
return 1 233 55
assign 1 237 59
new 1 237 59
new 1 237 60
assign 1 241 65
new 1 241 65
return 1 241 66
assign 1 245 78
iteratorGet 0 245 78
assign 1 245 81
hasNextGet 0 245 81
assign 1 246 83
nextGet 0 246 83
assign 1 247 84
def 1 247 89
assign 1 248 90
keyGet 0 248 90
assign 1 248 91
innerPut 4 248 91
assign 1 248 92
not 0 248 92
assign 1 249 94
new 0 249 94
return 1 249 95
assign 1 253 103
new 0 253 103
return 1 253 104
assign 1 258 114
sizeGet 0 258 114
assign 1 258 115
multiply 1 258 115
assign 1 258 116
new 0 258 116
assign 1 258 117
add 1 258 117
assign 1 259 118
new 1 259 118
assign 1 260 121
insertAll 2 260 121
assign 1 260 122
not 0 260 122
assign 1 261 124
increment 0 261 124
assign 1 262 125
new 1 262 125
return 1 264 131
assign 1 268 147
undef 1 268 152
assign 1 0 153
assign 1 268 156
sizeGet 0 268 156
assign 1 268 157
sizeGet 0 268 157
assign 1 268 158
notEquals 1 268 158
assign 1 0 160
assign 1 0 163
assign 1 269 167
new 0 269 167
return 1 269 168
assign 1 271 170
iteratorGet 0 0 170
assign 1 271 173
hasNextGet 0 271 173
assign 1 271 175
nextGet 0 271 175
assign 1 272 176
has 1 272 176
assign 1 272 177
not 0 272 177
assign 1 272 179
new 0 272 179
return 1 272 180
assign 1 274 187
new 0 274 187
return 1 274 188
assign 1 278 213
sizeGet 0 278 213
assign 1 279 214
undef 1 279 219
assign 1 280 220
getHash 1 280 220
assign 1 281 221
new 0 281 221
assign 1 281 222
lesser 1 281 222
assign 1 282 224
abs 0 282 224
assign 1 285 228
hvalGet 0 285 228
assign 1 287 230
modulus 1 287 230
assign 1 288 231
assign 1 290 234
get 1 290 234
assign 1 291 235
undef 1 291 240
assign 1 292 241
undef 1 292 246
assign 1 293 247
create 0 293 247
assign 1 293 248
new 3 293 248
put 2 293 249
put 2 295 252
assign 1 297 254
new 0 297 254
assign 1 298 255
new 0 298 255
return 1 298 256
assign 1 299 259
hvalGet 0 299 259
assign 1 299 260
modulus 1 299 260
assign 1 299 261
notEquals 1 299 261
assign 1 300 263
new 0 300 263
return 1 300 264
assign 1 301 267
keyGet 0 301 267
assign 1 301 268
isEqual 2 301 268
putTo 2 302 270
assign 1 304 271
new 0 304 271
assign 1 305 272
new 0 305 272
return 1 305 273
assign 1 307 276
increment 0 307 276
assign 1 308 277
greaterEquals 1 308 277
assign 1 309 279
new 0 309 279
return 1 309 280
assign 1 316 293
innerPut 4 316 293
assign 1 316 294
not 0 316 294
assign 1 317 296
assign 1 318 297
rehash 1 318 297
assign 1 319 300
innerPut 4 319 300
assign 1 319 301
not 0 319 301
assign 1 320 303
rehash 1 320 303
assign 1 322 309
assign 1 325 312
increment 0 325 312
assign 1 330 333
assign 1 331 334
sizeGet 0 331 334
assign 1 332 335
getHash 1 332 335
assign 1 333 336
new 0 333 336
assign 1 333 337
lesser 1 333 337
assign 1 334 339
abs 0 334 339
assign 1 336 341
modulus 1 336 341
assign 1 337 342
assign 1 339 345
get 1 339 345
assign 1 340 346
undef 1 340 351
return 1 341 352
assign 1 342 355
hvalGet 0 342 355
assign 1 342 356
modulus 1 342 356
assign 1 342 357
notEquals 1 342 357
return 1 343 359
assign 1 344 362
keyGet 0 344 362
assign 1 344 363
isEqual 2 344 363
assign 1 345 365
getFrom 0 345 365
return 1 345 366
assign 1 347 369
increment 0 347 369
assign 1 348 370
greaterEquals 1 348 370
return 1 349 372
assign 1 356 399
assign 1 357 400
sizeGet 0 357 400
assign 1 358 401
getHash 1 358 401
assign 1 359 402
new 0 359 402
assign 1 359 403
lesser 1 359 403
assign 1 360 405
abs 0 360 405
assign 1 362 407
modulus 1 362 407
assign 1 363 408
assign 1 365 411
get 1 365 411
assign 1 366 412
undef 1 366 417
assign 1 367 418
new 0 367 418
return 1 367 419
assign 1 368 422
hvalGet 0 368 422
assign 1 368 423
modulus 1 368 423
assign 1 368 424
notEquals 1 368 424
assign 1 369 426
new 0 369 426
return 1 369 427
assign 1 370 430
keyGet 0 370 430
assign 1 370 431
isEqual 2 370 431
assign 1 371 433
new 0 371 433
return 1 371 434
assign 1 373 437
increment 0 373 437
assign 1 374 438
greaterEquals 1 374 438
assign 1 375 440
new 0 375 440
return 1 375 441
assign 1 382 477
assign 1 383 478
sizeGet 0 383 478
assign 1 385 479
getHash 1 385 479
assign 1 386 480
new 0 386 480
assign 1 386 481
lesser 1 386 481
assign 1 387 483
abs 0 387 483
assign 1 389 485
modulus 1 389 485
assign 1 390 486
assign 1 392 489
get 1 392 489
assign 1 393 490
undef 1 393 495
assign 1 394 496
new 0 394 496
return 1 394 497
assign 1 395 500
hvalGet 0 395 500
assign 1 395 501
modulus 1 395 501
assign 1 395 502
notEquals 1 395 502
assign 1 396 504
new 0 396 504
return 1 396 505
assign 1 397 508
keyGet 0 397 508
assign 1 397 509
isEqual 2 397 509
put 2 398 511
assign 1 399 512
decrement 0 399 512
assign 1 400 513
increment 0 400 513
assign 1 401 516
lesser 1 401 516
assign 1 402 518
get 1 402 518
assign 1 403 519
undef 1 403 524
assign 1 0 525
assign 1 403 528
hvalGet 0 403 528
assign 1 403 529
modulus 1 403 529
assign 1 403 530
notEquals 1 403 530
assign 1 0 532
assign 1 0 535
assign 1 404 539
new 0 404 539
return 1 404 540
assign 1 406 543
new 0 406 543
assign 1 406 544
subtract 1 406 544
put 2 406 545
put 2 407 546
assign 1 409 548
increment 0 409 548
assign 1 411 554
new 0 411 554
return 1 411 555
assign 1 413 558
increment 0 413 558
assign 1 414 559
greaterEquals 1 414 559
assign 1 415 561
new 0 415 561
return 1 415 562
assign 1 422 584
create 0 422 584
copyTo 1 423 585
assign 1 424 586
copy 0 424 586
slotsSet 1 424 587
assign 1 425 588
new 0 425 588
assign 1 425 591
lengthGet 0 425 591
assign 1 425 592
lesser 1 425 592
assign 1 426 594
get 1 426 594
assign 1 427 595
def 1 427 600
assign 1 428 601
slotsGet 0 428 601
assign 1 428 602
create 0 428 602
assign 1 428 603
hvalGet 0 428 603
assign 1 428 604
keyGet 0 428 604
assign 1 428 605
getFrom 0 428 605
assign 1 428 606
new 3 428 606
put 2 428 607
assign 1 430 610
slotsGet 0 430 610
put 2 430 611
assign 1 425 613
increment 0 425 613
return 1 433 619
clear 0 438 622
assign 1 439 623
new 0 439 623
assign 1 443 628
new 1 443 628
return 1 443 629
assign 1 447 633
new 1 447 633
return 1 447 634
assign 1 451 638
keyIteratorGet 0 451 638
return 1 451 639
assign 1 455 643
new 1 455 643
return 1 455 644
assign 1 459 648
nodeIteratorGet 0 459 648
return 1 459 649
assign 1 463 658
new 0 463 658
assign 1 464 659
def 1 464 664
assign 1 465 665
iteratorGet 0 0 665
assign 1 465 668
hasNextGet 0 465 668
assign 1 465 670
nextGet 0 465 670
assign 1 466 671
has 1 466 671
put 1 467 673
return 1 471 681
assign 1 475 691
new 0 475 691
assign 1 476 692
iteratorGet 0 0 692
assign 1 476 695
hasNextGet 0 476 695
assign 1 476 697
nextGet 0 476 697
put 1 477 698
assign 1 479 704
def 1 479 709
assign 1 480 710
iteratorGet 0 0 710
assign 1 480 713
hasNextGet 0 480 713
assign 1 480 715
nextGet 0 480 715
put 1 481 716
return 1 484 723
assign 1 488 727
copy 0 488 727
addValue 1 489 728
return 1 490 729
assign 1 494 739
def 1 494 744
assign 1 495 745
sameType 1 495 745
assign 1 496 747
iteratorGet 0 0 747
assign 1 496 750
hasNextGet 0 496 750
assign 1 496 752
nextGet 0 496 752
put 1 497 753
assign 1 499 761
sameType 1 499 761
assign 1 500 763
keyGet 0 500 763
put 1 500 764
put 1 502 767
return 1 0 774
assign 1 0 777
return 1 0 781
assign 1 0 784
return 1 0 788
assign 1 0 791
return 1 0 795
assign 1 0 798
return 1 0 802
assign 1 0 805
return 1 0 809
assign 1 0 812
return 1 0 816
assign 1 0 819
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 712928736: return bem_innerPutAddedGet_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1586230380: return bem_moduGet_0();
case 1114073101: return bem_keysGet_0();
case 104713553: return bem_new_0();
case 2086347094: return bem_nodesGet_0();
case 287040793: return bem_hashGet_0();
case 2056412570: return bem_keyIteratorGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1431826729: return bem_nodeIteratorGet_0();
case 1820417453: return bem_create_0();
case 1227011022: return bem_multiGet_0();
case 578884498: return bem_relGet_0();
case 786424307: return bem_tagGet_0();
case 235611348: return bem_baseNodeGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1575148127: return bem_moduSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 567802245: return bem_relSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_9_3_ContainerSet) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 79841285: return bem_intersection_1((BEC_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 286659903: return bem_union_1((BEC_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_9_3_ContainerSet) bevd_0);
case 668984013: return bem_rehash_1((BEC_9_5_ContainerArray) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 131089957: return bem_insertAll_2((BEC_9_5_ContainerArray) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_9_5_ContainerArray) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_9_3_ContainerSet.bevs_inst = (BEC_9_3_ContainerSet)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_9_3_ContainerSet.bevs_inst;
}
}
