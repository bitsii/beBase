package be.BEL_4_Base;

import java.util.concurrent.locks.ReentrantLock;
/* File: source/base/System.be */
public class BEC_6_8_SystemBasePath extends BEC_6_6_SystemObject {
public BEC_6_8_SystemBasePath() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(1));
public static BEC_6_8_SystemBasePath bevs_inst;
public BEC_4_6_TextString bevp_separator;
public BEC_4_6_TextString bevp_path;
public BEC_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_new_1(BEC_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_4_6_TextString(1, bels_0));
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fromString_1(BEC_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_4_6_TextString bem_toString_1(BEC_4_6_TextString beva_newsep) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_toStringWithSeparator_1(BEC_4_6_TextString beva_newsep) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_4_6_TextString bevl_npath = null;
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_npath = bevt_0_tmpvar_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_8_SystemBasePath bem_add_1(BEC_6_6_SystemObject beva_other) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_9_10_ContainerLinkedList bevl_spath = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_l = null;
BEC_4_6_TextString bevl_rstr = null;
BEC_6_8_SystemBasePath bevl_rpath = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevt_3_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_emptyGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 381 */ {
bevt_4_tmpvar_phold = this.bem_copy_0();
return (BEC_6_8_SystemBasePath) bevt_4_tmpvar_phold;
} /* Line: 382 */
bevt_5_tmpvar_phold = beva_other.bemd_0(1359432006, BEL_4_Base.bevn_isAbsoluteGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 384 */ {
bevt_6_tmpvar_phold = beva_other.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
return (BEC_6_8_SystemBasePath) bevt_6_tmpvar_phold;
} /* Line: 385 */
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevl_spath = (BEC_9_10_ContainerLinkedList) bevt_7_tmpvar_phold.bemd_1(2001811380, BEL_4_Base.bevn_split_1, bevp_separator);
bevl_i = bevl_spath.bem_iteratorGet_0();
while (true)
 /* Line: 389 */ {
bevt_8_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 389 */ {
bevl_l = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 391 */
 else  /* Line: 389 */ {
break;
} /* Line: 389 */
} /* Line: 389 */
bevt_9_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_rstr = bevt_9_tmpvar_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_6_8_SystemBasePath) this.bem_copy_0();
bevl_rpath = (BEC_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return bevl_rpath;
} /*method end*/
public BEC_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_6_8_SystemBasePath bevl_rpath = null;
BEC_4_3_MathInt bevl_rpl = null;
BEC_4_3_MathInt bevl_c = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_6_8_SystemBasePath) this.bem_copy_0();
bevt_0_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpvar_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (new BEC_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_iteratorGet_0();
while (true)
 /* Line: 407 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 407 */ {
bevt_2_tmpvar_phold = bevl_c.bem_lesser_1(bevl_rpl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 408 */ {
bevt_3_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_rpath.bem_addStep_1(bevt_3_tmpvar_phold);
} /* Line: 409 */
 else  /* Line: 410 */ {
bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 411 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 413 */
 else  /* Line: 407 */ {
break;
} /* Line: 407 */
} /* Line: 407 */
bevt_4_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 415 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 416 */
return bevl_rpath;
} /*method end*/
public BEC_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (bevp_path == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 422 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 422 */ {
bevt_4_tmpvar_phold = bevp_path.bem_toString_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_sizeGet_0();
bevt_5_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 422 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 422 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 422 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 422 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 422 */
bevt_9_tmpvar_phold = bevo_1;
bevt_8_tmpvar_phold = bevp_path.bem_getPoint_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 424 */
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /*method end*/
public BEC_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 430 */ {
bevt_1_tmpvar_phold = bevo_2;
bevt_2_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
} /* Line: 431 */
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_isAbsoluteGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 436 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 437 */
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_trimParents_1(BEC_4_3_MathInt beva_howMany) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = beva_howMany.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 442 */ {
this.bem_makeNonAbsolute_0();
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 447 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(beva_howMany);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 447 */ {
if (bevl_next == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 448 */ {
break;
} /* Line: 448 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 447 */
 else  /* Line: 447 */ {
break;
} /* Line: 447 */
} /* Line: 447 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 453 */
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_addStep_1(BEC_6_6_SystemObject beva_step) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_4_3_MathInt bevl_fp = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 465 */ {
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevp_path = bevt_1_tmpvar_phold.bem_emptyGet_0();
} /* Line: 466 */
 else  /* Line: 467 */ {
bevt_3_tmpvar_phold = bevo_4;
bevt_2_tmpvar_phold = bevl_fp.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpvar_phold, bevt_4_tmpvar_phold);
} /* Line: 468 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addStepList_1(BEC_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_iteratorGet_0();
while (true)
 /* Line: 474 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 474 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_fpath.bem_addValue_1(bevt_1_tmpvar_phold);
} /* Line: 475 */
 else  /* Line: 474 */ {
break;
} /* Line: 474 */
} /* Line: 474 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addSteps_1(BEC_6_6_SystemObject beva_step) throws Throwable {
BEC_6_8_SystemBasePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_addStep_1(beva_step);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_addSteps_2(BEC_6_6_SystemObject beva_s1, BEC_6_6_SystemObject beva_s2) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_6_8_SystemBasePath bevl_other = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_other = (BEC_6_8_SystemBasePath) this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpvar_phold);
return bevl_other;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_x) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_x);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_x) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_x == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 514 */ {
bevt_3_tmpvar_phold = beva_x.bemd_1(1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 514 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 514 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 514 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 514 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 514 */ {
bevt_5_tmpvar_phold = beva_x.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevt_4_tmpvar_phold = bevp_path.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 514 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 514 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 514 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 515 */
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_subPath_1(BEC_4_3_MathInt beva_start) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_subPath_2(beva_start, null);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_subPath_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_st = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_6_6_SystemObject bevl_res = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_st = this.bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 526 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 527 */
 else  /* Line: 528 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 529 */
bevl_res = this.bem_create_0();
bevl_res.bemd_1(410741679, BEL_4_Base.bevn_separatorSet_1, bevp_separator);
bevt_1_tmpvar_phold = BEC_4_7_TextStrings.bevs_inst.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(389107089, BEL_4_Base.bevn_pathSet_1, bevt_1_tmpvar_phold);
return bevl_res;
} /*method end*/
public BEC_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_6_6_SystemObject bem_separatorSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_separator = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_6_6_SystemObject bem_pathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_path = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {342, 342, 346, 347, 351, 355, 359, 359, 363, 364, 364, 365, 369, 369, 373, 373, 373, 377, 377, 377, 381, 381, 381, 381, 382, 382, 384, 385, 385, 387, 388, 388, 389, 389, 390, 391, 393, 393, 394, 395, 397, 401, 402, 403, 403, 404, 405, 406, 407, 407, 408, 409, 409, 411, 413, 415, 416, 418, 422, 422, 0, 422, 422, 422, 422, 0, 0, 422, 422, 423, 423, 423, 424, 424, 426, 426, 430, 431, 431, 431, 436, 436, 437, 442, 442, 443, 444, 446, 447, 447, 448, 448, 449, 450, 451, 447, 453, 458, 459, 460, 464, 465, 465, 466, 466, 468, 468, 468, 468, 473, 474, 474, 475, 475, 477, 481, 481, 485, 486, 487, 488, 492, 493, 494, 494, 495, 499, 499, 503, 503, 507, 507, 507, 514, 514, 0, 514, 0, 0, 0, 514, 514, 0, 0, 515, 515, 517, 517, 521, 521, 525, 526, 526, 527, 529, 531, 532, 533, 533, 534, 0, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {20, 21, 25, 26, 30, 34, 38, 39, 45, 46, 47, 48, 52, 53, 58, 59, 60, 65, 66, 67, 86, 87, 88, 89, 91, 92, 94, 96, 97, 99, 100, 101, 102, 105, 107, 108, 114, 115, 116, 117, 118, 131, 132, 133, 134, 135, 136, 137, 138, 141, 143, 145, 146, 149, 151, 157, 159, 161, 176, 181, 182, 185, 186, 187, 188, 190, 193, 197, 198, 200, 201, 202, 204, 205, 207, 208, 214, 216, 217, 218, 225, 226, 228, 241, 242, 244, 245, 246, 247, 250, 252, 257, 260, 261, 262, 263, 269, 275, 276, 277, 287, 288, 293, 294, 295, 298, 299, 300, 301, 310, 311, 314, 316, 317, 323, 328, 329, 333, 334, 335, 336, 342, 343, 344, 345, 346, 350, 351, 355, 356, 361, 362, 363, 374, 379, 380, 383, 385, 388, 392, 395, 396, 398, 401, 405, 406, 408, 409, 413, 414, 422, 423, 428, 429, 432, 434, 435, 436, 437, 438, 441, 444, 448, 451};
/* BEGIN LINEINFO 
assign 1 342 20
new 0 342 20
new 1 342 21
assign 1 346 25
new 0 346 25
fromString 1 347 26
assign 1 351 30
return 1 355 34
assign 1 359 38
toStringWithSeparator 1 359 38
return 1 359 39
assign 1 363 45
split 1 363 45
assign 1 364 46
new 0 364 46
assign 1 364 47
join 2 364 47
return 1 365 48
assign 1 369 52
split 1 369 52
return 1 369 53
assign 1 373 58
split 1 373 58
assign 1 373 59
firstGet 0 373 59
return 1 373 60
assign 1 377 65
split 1 377 65
assign 1 377 66
lastGet 0 377 66
return 1 377 67
assign 1 381 86
pathGet 0 381 86
assign 1 381 87
new 0 381 87
assign 1 381 88
emptyGet 0 381 88
assign 1 381 89
equals 1 381 89
assign 1 382 91
copy 0 382 91
return 1 382 92
assign 1 384 94
isAbsoluteGet 0 384 94
assign 1 385 96
copy 0 385 96
return 1 385 97
assign 1 387 99
split 1 387 99
assign 1 388 100
pathGet 0 388 100
assign 1 388 101
split 1 388 101
assign 1 389 102
iteratorGet 0 389 102
assign 1 389 105
hasNextGet 0 389 105
assign 1 390 107
nextGet 0 390 107
addValue 1 391 108
assign 1 393 114
new 0 393 114
assign 1 393 115
join 2 393 115
assign 1 394 116
copy 0 394 116
assign 1 395 117
fromString 1 395 117
return 1 397 118
assign 1 401 131
split 1 401 131
assign 1 402 132
copy 0 402 132
assign 1 403 133
new 0 403 133
pathSet 1 403 134
assign 1 404 135
lengthGet 0 404 135
assign 1 405 136
decrement 0 405 136
assign 1 406 137
new 0 406 137
assign 1 407 138
iteratorGet 0 407 138
assign 1 407 141
hasNextGet 0 407 141
assign 1 408 143
lesser 1 408 143
assign 1 409 145
nextGet 0 409 145
addStep 1 409 146
nextGet 0 411 149
assign 1 413 151
increment 0 413 151
assign 1 415 157
isAbsoluteGet 0 415 157
makeAbsolute 0 416 159
return 1 418 161
assign 1 422 176
undef 1 422 181
assign 1 0 182
assign 1 422 185
toString 0 422 185
assign 1 422 186
sizeGet 0 422 186
assign 1 422 187
new 0 422 187
assign 1 422 188
lesser 1 422 188
assign 1 0 190
assign 1 0 193
assign 1 422 197
new 0 422 197
return 1 422 198
assign 1 423 200
new 0 423 200
assign 1 423 201
getPoint 1 423 201
assign 1 423 202
equals 1 423 202
assign 1 424 204
new 0 424 204
return 1 424 205
assign 1 426 207
new 0 426 207
return 1 426 208
assign 1 430 214
isAbsoluteGet 0 430 214
assign 1 431 216
new 0 431 216
assign 1 431 217
sizeGet 0 431 217
assign 1 431 218
substring 2 431 218
assign 1 436 225
isAbsoluteGet 0 436 225
assign 1 436 226
not 0 436 226
assign 1 437 228
add 1 437 228
assign 1 442 241
new 0 442 241
assign 1 442 242
greater 1 442 242
makeNonAbsolute 0 443 244
assign 1 444 245
split 1 444 245
assign 1 446 246
firstNodeGet 0 446 246
assign 1 447 247
new 0 447 247
assign 1 447 250
lesser 1 447 250
assign 1 448 252
undef 1 448 257
assign 1 449 260
assign 1 450 261
nextGet 0 450 261
delete 0 451 262
assign 1 447 263
increment 0 447 263
assign 1 453 269
join 2 453 269
assign 1 458 275
split 1 458 275
addValue 1 459 276
assign 1 460 277
join 2 460 277
assign 1 464 287
find 1 464 287
assign 1 465 288
undef 1 465 293
assign 1 466 294
new 0 466 294
assign 1 466 295
emptyGet 0 466 295
assign 1 468 298
new 0 468 298
assign 1 468 299
add 1 468 299
assign 1 468 300
sizeGet 0 468 300
assign 1 468 301
substring 2 468 301
assign 1 473 310
split 1 473 310
assign 1 474 311
iteratorGet 0 474 311
assign 1 474 314
hasNextGet 0 474 314
assign 1 475 316
nextGet 0 475 316
addValue 1 475 317
assign 1 477 323
join 2 477 323
assign 1 481 328
addStep 1 481 328
return 1 481 329
assign 1 485 333
split 1 485 333
addValue 1 486 334
addValue 1 487 335
assign 1 488 336
join 2 488 336
assign 1 492 342
create 0 492 342
copyTo 1 493 343
assign 1 494 344
copy 0 494 344
pathSet 1 494 345
return 1 495 346
assign 1 499 350
split 1 499 350
return 1 499 351
assign 1 503 355
hashGet 0 503 355
return 1 503 356
assign 1 507 361
equals 1 507 361
assign 1 507 362
not 0 507 362
return 1 507 363
assign 1 514 374
undef 1 514 379
assign 1 0 380
assign 1 514 383
otherType 1 514 383
assign 1 0 385
assign 1 0 388
assign 1 0 392
assign 1 514 395
pathGet 0 514 395
assign 1 514 396
notEquals 1 514 396
assign 1 0 398
assign 1 0 401
assign 1 515 405
new 0 515 405
return 1 515 406
assign 1 517 408
new 0 517 408
return 1 517 409
assign 1 521 413
subPath 2 521 413
return 1 521 414
assign 1 525 422
stepsGet 0 525 422
assign 1 526 423
undef 1 526 428
assign 1 527 429
subList 1 527 429
assign 1 529 432
subList 2 529 432
assign 1 531 434
create 0 531 434
separatorSet 1 532 435
assign 1 533 436
join 2 533 436
pathSet 1 533 437
return 1 534 438
return 1 0 441
assign 1 0 444
return 1 0 448
assign 1 0 451
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1359432006: return bem_isAbsoluteGet_0();
case 1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 471950299: return bem_lastStepGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case 935459934: return bem_deleteFirstStep_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 1719674549: return bem_firstStepGet_0();
case 723109216: return bem_stepsGet_0();
case 1354714650: return bem_copy_0();
case 400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case 1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 630006451: return bem_fromString_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 488966921: return bem_subPath_1((BEC_4_3_MathInt) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 389107089: return bem_pathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1787791811: return bem_addStepList_1((BEC_9_10_ContainerLinkedList) bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_6_TextString) bevd_0);
case 14682424: return bem_addSteps_1(bevd_0);
case 2006569863: return bem_trimParents_1((BEC_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 488966920: return bem_subPath_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_8_SystemBasePath.bevs_inst = (BEC_6_8_SystemBasePath)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_8_SystemBasePath.bevs_inst;
}
}
