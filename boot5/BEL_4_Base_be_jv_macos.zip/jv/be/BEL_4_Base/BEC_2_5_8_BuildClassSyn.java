package be.BEL_4_Base;
/* IO:File: source/build/Syns.be */
public class BEC_2_5_8_BuildClassSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildClassSyn() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_0, 9));
private static byte[] bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_2, 9));
private static byte[] bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_4, 78));
private static byte[] bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_5, 12));
private static byte[] bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_6, 38));
private static byte[] bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_7, 68));
private static byte[] bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_8, 75));
private static byte[] bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_9, 13));
private static byte[] bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_10, 65));
private static byte[] bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_11, 11));
private static byte[] bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_12, 33));
private static byte[] bels_13 = {0x20};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_13, 1));
private static byte[] bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_13 = (new BEC_2_4_6_TextString(bels_14, 95));
private static byte[] bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_14 = (new BEC_2_4_6_TextString(bels_15, 84));
private static byte[] bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bevo_15 = (new BEC_2_4_6_TextString(bels_16, 80));
private static byte[] bels_17 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_16 = (new BEC_2_4_6_TextString(bels_17, 9));
private static byte[] bels_18 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_17 = (new BEC_2_4_6_TextString(bels_18, 26));
private static BEC_2_9_5_ContainerArray bevo_18;
private static BEC_2_4_3_MathInt bevo_19 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_19 = {0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
private static byte[] bels_20 = {0x64,0x65,0x70,0x74,0x68};
private static byte[] bels_21 = {0x66,0x72,0x6F,0x6D,0x46,0x69,0x6C,0x65};
private static byte[] bels_22 = {0x6C,0x69,0x62,0x4E,0x61,0x6D,0x65};
private static byte[] bels_23 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bels_24 = {0x69,0x73,0x4C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_25 = {0x73,0x75,0x70,0x65,0x72,0x4C,0x69,0x73,0x74};
private static byte[] bels_26 = {0x75,0x73,0x65,0x73};
private static byte[] bels_27 = {0x70,0x74,0x79,0x4C,0x69,0x73,0x74};
private static byte[] bels_28 = {0x6D,0x74,0x64,0x4C,0x69,0x73,0x74};
private static byte[] bels_29 = {0x61,0x6C,0x6C,0x41,0x6E,0x63,0x65,0x73,0x74,0x6F,0x72,0x73,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_30 = {0x69,0x73,0x4E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
public static BEC_2_5_8_BuildClassSyn bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_superNp;
public BEC_2_4_3_MathInt bevp_depth;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_3_2_4_4_IOFilePath bevp_fromFile;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_4_3_MathInt bevp_newMbrs;
public BEC_2_4_3_MathInt bevp_newMtds;
public BEC_2_4_3_MathInt bevp_defMtds;
public BEC_2_5_4_LogicBool bevp_directProperties;
public BEC_2_5_4_LogicBool bevp_directMethods;
public BEC_2_9_3_ContainerMap bevp_allTypes;
public BEC_2_9_10_ContainerLinkedList bevp_superList;
public BEC_2_9_3_ContainerMap bevp_mtdMap;
public BEC_2_9_5_ContainerArray bevp_mtdList;
public BEC_2_9_3_ContainerMap bevp_ptyMap;
public BEC_2_9_5_ContainerArray bevp_ptyList;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_5_4_LogicBool bevp_allAncestorsClose;
public BEC_2_5_4_LogicBool bevp_integrated;
public BEC_2_5_4_LogicBool bevp_iChecked;
public BEC_2_9_3_ContainerSet bevp_uses;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_signatureChanged;
public BEC_2_5_4_LogicBool bevp_signatureChecked;
public BEC_2_5_8_BuildClassSyn bem_new_0() throws Throwable {
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_superList = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_integrated = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_iChecked = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxMtdxGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_maxMtdx = null;
BEC_3_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevl_maxMtdx = (new BEC_2_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 101 */ {
bevt_0_tmpvar_phold = bevl_vi.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 101 */ {
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_tmpvar_phold = bevl_ms.bem_mtdxGet_0();
if (bevt_2_tmpvar_phold.bevi_int > bevl_maxMtdx.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 104 */
} /* Line: 103 */
 else  /* Line: 101 */ {
break;
} /* Line: 101 */
} /* Line: 101 */
return bevl_maxMtdx;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasDefaultGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_dmtd = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_0;
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_tmpvar_phold);
if (bevl_dmtd == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 112 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 114 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
this.bem_new_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_psyn) throws Throwable {
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_integrated = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_iChecked = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = beva_psyn.bemd_0(1974592946, BEL_4_Base.bevn_superListGet_0);
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_3_tmpvar_phold = beva_psyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_superList.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_psyn.bemd_0(1477961836, BEL_4_Base.bevn_mtdListGet_0);
bevp_mtdList = (BEC_2_9_5_ContainerArray) bevt_4_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_5_tmpvar_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevp_ptyList = (BEC_2_9_5_ContainerArray) bevt_5_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_7_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_6_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 139 */ {
bevt_8_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 139 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = beva_psyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_11_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_9_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_10_tmpvar_phold);
bevt_14_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_1));
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_15_tmpvar_phold);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 142 */ {
if (bevl_pv == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 142 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 142 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 142 */
 else  /* Line: 142 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 142 */ {
bevt_19_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 142 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 142 */
 else  /* Line: 142 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 142 */ {
bevt_24_tmpvar_phold = bevo_1;
bevt_26_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_2;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_20_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 143 */
} /* Line: 142 */
 else  /* Line: 139 */ {
break;
} /* Line: 139 */
} /* Line: 139 */
bevt_31_tmpvar_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevl_iv = bevt_31_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 148 */ {
bevt_32_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 148 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 150 */ {
bevt_35_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_36_tmpvar_phold);
} /* Line: 151 */
} /* Line: 150 */
 else  /* Line: 148 */ {
break;
} /* Line: 148 */
} /* Line: 148 */
bevt_39_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_38_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 155 */ {
bevt_40_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpvar_phold != null && bevt_40_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpvar_phold).bevi_bool) /* Line: 155 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_41_tmpvar_phold = beva_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_43_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_41_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_42_tmpvar_phold);
if (bevl_pm == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 158 */ {
bevt_46_tmpvar_phold = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevt_46_tmpvar_phold == null) {
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevt_49_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_48_tmpvar_phold == null) {
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 160 */ {
bevt_54_tmpvar_phold = bevo_3;
bevt_56_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_add_1(bevt_55_tmpvar_phold);
bevt_57_tmpvar_phold = bevo_4;
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_add_1(bevt_57_tmpvar_phold);
bevt_59_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_50_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_51_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_50_tmpvar_phold);
} /* Line: 161 */
} /* Line: 160 */
} /* Line: 159 */
} /* Line: 158 */
 else  /* Line: 155 */ {
break;
} /* Line: 155 */
} /* Line: 155 */
this.bem_loadClass_1(beva_klass);
bevt_60_tmpvar_phold = beva_psyn.bemd_0(202810500, BEL_4_Base.bevn_depthGet_0);
bevt_61_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevp_depth = (BEC_2_4_3_MathInt) bevt_60_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_61_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_castsTo_1(BEC_2_5_8_BuildNamePath beva_cto) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_integrate_1(BEC_2_5_5_BuildBuild beva_build) throws Throwable {
BEC_2_5_6_BuildMtdSyn bevl_om = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_5_8_BuildNamePath bevl_pn = null;
BEC_2_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_5_6_BuildMtdSyn bevl_pm = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_9_tmpvar_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_9_5_ContainerArray bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_55_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_56_tmpvar_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_57_tmpvar_phold = null;
if (bevp_integrated.bevi_bool) /* Line: 175 */ {
return this;
} /* Line: 175 */
bevp_integrated = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_directProperties = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_directMethods = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_tmpvar_loop = bevp_mtdList.bem_arrayIteratorGet_0();
while (true)
 /* Line: 185 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 185 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_9_tmpvar_phold = beva_build.bem_emitDataGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_methodIndexesGet_0();
bevt_10_tmpvar_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_tmpvar_phold.bem_put_1(bevt_10_tmpvar_phold);
} /* Line: 186 */
 else  /* Line: 185 */ {
break;
} /* Line: 185 */
} /* Line: 185 */
return this;
} /* Line: 188 */
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (new BEC_2_4_3_MathInt(0));
bevp_defMtds = (new BEC_2_4_3_MathInt(0));
bevt_11_tmpvar_phold = bevp_ptyList.bem_sizeGet_0();
bevt_13_tmpvar_phold = bevl_psyn.bem_ptyListGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_sizeGet_0();
bevp_newMbrs = bevt_11_tmpvar_phold.bem_subtract_1(bevt_12_tmpvar_phold);
bevt_15_tmpvar_phold = bevl_psyn.bem_libNameGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_equals_1(bevp_libName);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 195 */
bevt_16_tmpvar_phold = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_19_tmpvar_phold = bevo_5;
bevt_20_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_17_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_17_tmpvar_phold);
} /* Line: 197 */
bevt_21_tmpvar_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 199 */ {
bevt_23_tmpvar_phold = bevl_psyn.bem_libNameGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_notEquals_1(bevp_libName);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 199 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 199 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 199 */
 else  /* Line: 199 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 199 */ {
bevt_26_tmpvar_phold = bevo_6;
bevt_27_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_24_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_25_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_24_tmpvar_phold);
} /* Line: 200 */
bevt_28_tmpvar_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 202 */ {
if (bevp_isLocal.bevi_bool) {
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 202 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 202 */
 else  /* Line: 202 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 202 */ {
if (bevp_isFinal.bevi_bool) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 202 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 202 */
 else  /* Line: 202 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 202 */ {
bevt_33_tmpvar_phold = bevo_7;
bevt_34_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_add_1(bevt_34_tmpvar_phold);
bevt_31_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_32_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_31_tmpvar_phold);
} /* Line: 203 */
bevt_1_tmpvar_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 205 */ {
bevt_35_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 205 */ {
bevl_pn = (BEC_2_5_8_BuildNamePath) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_tmpvar_phold = beva_build.bem_closeLibrariesGet_0();
bevt_39_tmpvar_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_has_1(bevt_39_tmpvar_phold);
if (bevt_37_tmpvar_phold.bevi_bool) {
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevt_41_tmpvar_phold = bevl_pn.bem_toString_0();
bevt_42_tmpvar_phold = bevo_8;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_notEquals_1(bevt_42_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 207 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 207 */
 else  /* Line: 207 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 207 */ {
bevp_directProperties = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_directMethods = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 210 */
bevt_45_tmpvar_phold = beva_build.bem_closeLibrariesGet_0();
bevt_46_tmpvar_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bem_has_1(bevt_46_tmpvar_phold);
if (bevt_44_tmpvar_phold.bevi_bool) {
bevt_43_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 213 */
} /* Line: 212 */
 else  /* Line: 205 */ {
break;
} /* Line: 205 */
} /* Line: 205 */
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 217 */ {
bevt_47_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 217 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_48_tmpvar_phold = bevl_psyn.bem_mtdMapGet_0();
bevt_49_tmpvar_phold = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_2_5_6_BuildMtdSyn) bevt_48_tmpvar_phold.bem_get_1(bevt_49_tmpvar_phold);
if (bevl_pm == null) {
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevt_51_tmpvar_phold = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 221 */ {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_tmpvar_phold);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 224 */
} /* Line: 221 */
 else  /* Line: 226 */ {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_tmpvar_phold);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_tmpvar_phold = beva_build.bem_emitDataGet_0();
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bem_methodIndexesGet_0();
bevt_57_tmpvar_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_tmpvar_phold.bem_put_1(bevt_57_tmpvar_phold);
} /* Line: 230 */
} /* Line: 220 */
 else  /* Line: 217 */ {
break;
} /* Line: 217 */
} /* Line: 217 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_checkInheritance_2(BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_6_6_SystemObject bevl_oa = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
if (bevp_iChecked.bevi_bool) /* Line: 237 */ {
return this;
} /* Line: 237 */
bevp_iChecked = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 239 */ {
return this;
} /* Line: 239 */
bevl_psyn = beva_build.bemd_1(706249818, BEL_4_Base.bevn_getSynNp_1, bevp_superNp);
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_3_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 241 */ {
bevt_5_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 241 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_6_tmpvar_phold = bevl_psyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_8_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_6_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpvar_phold);
if (bevl_pv == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 244 */ {
bevt_11_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 245 */ {
bevt_16_tmpvar_phold = bevo_9;
bevt_18_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_10;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_22_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_12_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_13_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_12_tmpvar_phold);
} /* Line: 246 */
 else  /* Line: 247 */ {
bevt_23_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_23_tmpvar_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_24_tmpvar_phold);
bevt_26_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_27_tmpvar_phold);
} /* Line: 249 */
} /* Line: 245 */
} /* Line: 244 */
 else  /* Line: 241 */ {
break;
} /* Line: 241 */
} /* Line: 241 */
bevt_30_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_29_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 253 */ {
bevt_31_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 253 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_32_tmpvar_phold = bevl_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_34_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_32_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_33_tmpvar_phold);
if (bevl_pm == null) {
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 256 */ {
bevt_36_tmpvar_phold = bevl_pm.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 257 */ {
bevt_41_tmpvar_phold = bevo_11;
bevt_43_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_add_1(bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_12;
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_add_1(bevt_44_tmpvar_phold);
bevt_47_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_add_1(bevt_45_tmpvar_phold);
bevt_37_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_38_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_37_tmpvar_phold);
} /* Line: 258 */
bevt_49_tmpvar_phold = bevl_om.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_oa = bevt_48_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 261 */ {
bevt_52_tmpvar_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_50_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_51_tmpvar_phold);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 261 */ {
bevt_53_tmpvar_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_pmr = bevt_53_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevt_54_tmpvar_phold = bevl_oa.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevl_omr = bevt_54_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
this.bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 261 */
 else  /* Line: 261 */ {
break;
} /* Line: 261 */
} /* Line: 261 */
bevl_pmr = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
bevt_55_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_omr = bevt_55_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevl_pmr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 269 */ {
if (bevl_omr == null) {
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 269 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 269 */ {
if (bevl_pmr == null) {
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpvar_phold.bevi_bool) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 270 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
if (bevl_omr == null) {
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_61_tmpvar_phold.bevi_bool) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 270 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 270 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 270 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 270 */ {
bevt_64_tmpvar_phold = bevo_13;
bevt_67_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_add_1(bevt_65_tmpvar_phold);
bevt_62_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_63_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_62_tmpvar_phold);
} /* Line: 271 */
} /* Line: 270 */
 else  /* Line: 273 */ {
this.bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 275 */
} /* Line: 269 */
} /* Line: 256 */
 else  /* Line: 253 */ {
break;
} /* Line: 253 */
} /* Line: 253 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_checkTypes_5(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_pmr, BEC_2_6_6_SystemObject beva_omr, BEC_2_6_6_SystemObject beva_om) throws Throwable {
BEC_2_6_6_SystemObject bevl_osyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_3_tmpvar_phold = beva_omr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 282 */ {
bevt_6_tmpvar_phold = bevo_14;
bevt_9_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_5_tmpvar_phold, beva_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 283 */
 else  /* Line: 282 */ {
bevt_10_tmpvar_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 284 */ {
bevt_11_tmpvar_phold = beva_pmr.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 287 */ {
bevt_12_tmpvar_phold = beva_omr.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 287 */
 else  /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 287 */ {
return this;
} /* Line: 288 */
bevt_13_tmpvar_phold = beva_omr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_osyn = beva_build.bemd_1(706249818, BEL_4_Base.bevn_getSynNp_1, bevt_13_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_osyn.bemd_0(986531569, BEL_4_Base.bevn_allTypesGet_0);
bevt_17_tmpvar_phold = beva_pmr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_17_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 291 */ {
bevt_20_tmpvar_phold = bevo_15;
bevt_23_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_18_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_tmpvar_phold, beva_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_18_tmpvar_phold);
} /* Line: 292 */
} /* Line: 291 */
} /* Line: 282 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
this.bem_new_0();
bevt_1_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_0_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 299 */ {
bevt_2_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 299 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 301 */ {
bevt_10_tmpvar_phold = bevo_16;
bevt_12_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_17;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_6_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_7_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_6_tmpvar_phold);
} /* Line: 302 */
} /* Line: 301 */
 else  /* Line: 299 */ {
break;
} /* Line: 299 */
} /* Line: 299 */
this.bem_loadClass_1(beva_klass);
bevp_depth = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_loadClass_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevl_ou = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_prop = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_msyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_1_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_1_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_libName = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevt_3_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_3_tmpvar_phold.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_4_tmpvar_phold.bemd_0(842582618, BEL_4_Base.bevn_isLocalGet_0);
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_5_tmpvar_phold.bemd_0(363636983, BEL_4_Base.bevn_isNotNullGet_0);
bevt_7_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(83882038, BEL_4_Base.bevn_usedGet_0);
bevl_iu = bevt_6_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 317 */ {
bevt_8_tmpvar_phold = bevl_iu.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 317 */ {
bevl_ou = bevl_iu.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ou.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_uses.bem_put_1(bevt_9_tmpvar_phold);
} /* Line: 319 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
bevt_11_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_10_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 321 */ {
bevt_12_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 321 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_prop = (new BEC_2_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 324 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
bevt_14_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_13_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 326 */ {
bevt_15_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 326 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_msyn = (new BEC_2_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 329 */
 else  /* Line: 326 */ {
break;
} /* Line: 326 */
} /* Line: 326 */
this.bem_postLoad_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_postLoad_0() throws Throwable {
BEC_2_9_5_ContainerArray bevl_nptyList = null;
BEC_2_9_5_ContainerArray bevl_mtdnList = null;
BEC_2_9_3_ContainerMap bevl_unq = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_mpos = null;
BEC_2_6_6_SystemObject bevl_nom = null;
BEC_2_9_3_ContainerMap bevl_mtdOmap = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_4_3_MathInt bevl_mtdx = null;
BEC_2_6_6_SystemObject bevl_oma = null;
BEC_2_5_6_BuildMtdSyn bevl_msyno = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_27_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_28_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
bevl_nptyList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevl_mtdnList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 339 */ {
bevt_1_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 339 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevp_ptyMap.bem_has_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 341 */ {
bevt_5_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_ptyMap.bem_put_2(bevt_5_tmpvar_phold, bevl_ov);
} /* Line: 343 */
} /* Line: 341 */
 else  /* Line: 339 */ {
break;
} /* Line: 339 */
} /* Line: 339 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_2_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 349 */ {
bevt_6_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 349 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpvar_phold = bevl_unq.bem_has_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 351 */ {
bevt_10_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_tmpvar_phold);
bevl_nom.bemd_1(1283009805, BEL_4_Base.bevn_mposSet_1, bevl_mpos);
bevt_11_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
} /* Line: 356 */
} /* Line: 351 */
 else  /* Line: 349 */ {
break;
} /* Line: 349 */
} /* Line: 349 */
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 363 */ {
bevt_14_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 363 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_15_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_mtdMap.bem_put_2(bevt_15_tmpvar_phold, bevl_om);
bevt_18_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpvar_phold = bevl_mtdOmap.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 368 */ {
bevt_19_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdOmap.bem_put_2(bevt_19_tmpvar_phold, bevl_om);
} /* Line: 369 */
} /* Line: 368 */
 else  /* Line: 363 */ {
break;
} /* Line: 363 */
} /* Line: 363 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (new BEC_2_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 375 */ {
bevt_20_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 375 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_23_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_22_tmpvar_phold = bevl_unq.bem_has_1(bevt_23_tmpvar_phold);
if (bevt_22_tmpvar_phold.bevi_bool) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 377 */ {
bevt_24_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_msyno = (BEC_2_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevl_msyno.bem_declarationGet_0();
if (bevt_27_tmpvar_phold == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 388 */ {
bevt_28_tmpvar_phold = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_tmpvar_phold);
} /* Line: 389 */
bevt_29_tmpvar_phold = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(885379526, BEL_4_Base.bevn_declarationSet_1, bevt_29_tmpvar_phold);
bevl_oma.bemd_1(1365143591, BEL_4_Base.bevn_mtdxSet_1, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_31_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
} /* Line: 395 */
} /* Line: 377 */
 else  /* Line: 375 */ {
break;
} /* Line: 375 */
} /* Line: 375 */
bevp_mtdList = bevl_mtdnList;
bevt_0_tmpvar_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 400 */ {
bevt_32_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 400 */ {
bevl_s = bevt_0_tmpvar_loop.bem_nextGet_0();
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevl_s;
} /* Line: 402 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_9_5_ContainerArray bevl_names = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(12));
synchronized (BEC_2_5_8_BuildClassSyn.class) {
if (bevo_18 == null) {
bevo_18 = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
}
}
bevl_names = bevo_18;
bevt_3_tmpvar_phold = bevo_19;
bevt_2_tmpvar_phold = bevl_names.bem_get_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 410 */ {
bevt_4_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_19));
bevl_names.bem_put_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevt_7_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_20));
bevl_names.bem_put_2(bevt_6_tmpvar_phold, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = (new BEC_2_4_3_MathInt(2));
bevt_9_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_21));
bevl_names.bem_put_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = (new BEC_2_4_3_MathInt(3));
bevt_11_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_22));
bevl_names.bem_put_2(bevt_10_tmpvar_phold, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = (new BEC_2_4_3_MathInt(4));
bevt_13_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_23));
bevl_names.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (new BEC_2_4_3_MathInt(5));
bevt_15_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_24));
bevl_names.bem_put_2(bevt_14_tmpvar_phold, bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (new BEC_2_4_3_MathInt(6));
bevt_17_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_25));
bevl_names.bem_put_2(bevt_16_tmpvar_phold, bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (new BEC_2_4_3_MathInt(7));
bevt_19_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_26));
bevl_names.bem_put_2(bevt_18_tmpvar_phold, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (new BEC_2_4_3_MathInt(8));
bevt_21_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_27));
bevl_names.bem_put_2(bevt_20_tmpvar_phold, bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (new BEC_2_4_3_MathInt(9));
bevt_23_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_28));
bevl_names.bem_put_2(bevt_22_tmpvar_phold, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (new BEC_2_4_3_MathInt(10));
bevt_25_tmpvar_phold = (new BEC_2_4_6_TextString(17, bels_29));
bevl_names.bem_put_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (new BEC_2_4_3_MathInt(11));
bevt_27_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_30));
bevl_names.bem_put_2(bevt_26_tmpvar_phold, bevt_27_tmpvar_phold);
} /* Line: 422 */
bevt_28_tmpvar_phold = (new BEC_2_6_23_SystemNamedPropertiesIterator()).bem_new_2(this, bevl_names);
return bevt_28_tmpvar_phold;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGet_0() throws Throwable {
return bevp_superNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_superNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
return bevp_depth;
} /*method end*/
public BEC_2_6_6_SystemObject bem_depthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGet_0() throws Throwable {
return bevp_newMbrs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newMbrsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGet_0() throws Throwable {
return bevp_newMtds;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGet_0() throws Throwable {
return bevp_defMtds;
} /*method end*/
public BEC_2_6_6_SystemObject bem_defMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGet_0() throws Throwable {
return bevp_directProperties;
} /*method end*/
public BEC_2_6_6_SystemObject bem_directPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGet_0() throws Throwable {
return bevp_directMethods;
} /*method end*/
public BEC_2_6_6_SystemObject bem_directMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGet_0() throws Throwable {
return bevp_allTypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGet_0() throws Throwable {
return bevp_superList;
} /*method end*/
public BEC_2_6_6_SystemObject bem_superListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGet_0() throws Throwable {
return bevp_mtdMap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mtdMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_mtdListGet_0() throws Throwable {
return bevp_mtdList;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mtdListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mtdList = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGet_0() throws Throwable {
return bevp_ptyMap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ptyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_ptyListGet_0() throws Throwable {
return bevp_ptyList;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ptyListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ptyList = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() throws Throwable {
return bevp_allNames;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() throws Throwable {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_6_6_SystemObject bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGet_0() throws Throwable {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allAncestorsCloseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGet_0() throws Throwable {
return bevp_integrated;
} /*method end*/
public BEC_2_6_6_SystemObject bem_integratedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGet_0() throws Throwable {
return bevp_iChecked;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGet_0() throws Throwable {
return bevp_uses;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGet_0() throws Throwable {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_6_6_SystemObject bem_signatureChangedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGet_0() throws Throwable {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_6_6_SystemObject bem_signatureCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {77, 79, 81, 83, 84, 85, 86, 87, 88, 89, 90, 92, 93, 94, 95, 100, 101, 101, 102, 103, 103, 103, 104, 107, 111, 111, 112, 112, 114, 114, 116, 116, 119, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 133, 134, 134, 135, 135, 136, 136, 139, 139, 139, 139, 140, 141, 141, 141, 141, 142, 142, 142, 142, 142, 142, 0, 0, 0, 142, 142, 142, 0, 0, 0, 143, 143, 143, 143, 143, 143, 143, 143, 143, 143, 143, 143, 148, 148, 148, 149, 150, 150, 151, 151, 151, 151, 155, 155, 155, 155, 156, 157, 157, 157, 157, 158, 158, 159, 159, 159, 160, 160, 160, 160, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 166, 167, 167, 167, 171, 171, 175, 176, 177, 178, 179, 180, 180, 181, 182, 183, 184, 185, 0, 185, 185, 186, 186, 186, 186, 188, 190, 191, 192, 194, 194, 194, 194, 195, 195, 195, 196, 197, 197, 197, 197, 197, 199, 199, 199, 0, 0, 0, 200, 200, 200, 200, 200, 202, 202, 202, 0, 0, 0, 202, 202, 0, 0, 0, 203, 203, 203, 203, 203, 205, 0, 205, 205, 206, 207, 207, 207, 207, 207, 207, 207, 207, 0, 0, 0, 209, 210, 212, 212, 212, 212, 212, 213, 217, 217, 218, 219, 219, 219, 220, 220, 221, 222, 222, 223, 223, 224, 227, 227, 228, 229, 230, 230, 230, 230, 237, 238, 239, 239, 239, 240, 241, 241, 241, 241, 242, 243, 243, 243, 243, 244, 244, 245, 245, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 248, 248, 248, 248, 249, 249, 249, 249, 253, 253, 253, 253, 254, 255, 255, 255, 255, 256, 256, 257, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 260, 260, 260, 261, 261, 261, 261, 262, 262, 263, 263, 265, 261, 267, 268, 268, 269, 269, 0, 269, 269, 0, 0, 270, 270, 270, 0, 270, 270, 270, 0, 0, 271, 271, 271, 271, 271, 271, 271, 275, 282, 282, 282, 283, 283, 283, 283, 283, 283, 283, 284, 287, 287, 0, 0, 0, 288, 290, 290, 291, 291, 291, 291, 292, 292, 292, 292, 292, 292, 292, 298, 299, 299, 299, 299, 300, 301, 301, 301, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 305, 306, 311, 311, 312, 312, 313, 313, 314, 314, 315, 315, 316, 316, 317, 317, 317, 317, 318, 319, 319, 321, 321, 321, 321, 322, 323, 324, 326, 326, 326, 326, 327, 328, 329, 331, 335, 336, 339, 339, 340, 341, 341, 341, 341, 343, 343, 347, 348, 349, 349, 350, 351, 351, 351, 351, 352, 352, 353, 354, 354, 355, 356, 356, 356, 359, 361, 363, 363, 364, 366, 366, 368, 368, 368, 368, 369, 369, 373, 374, 375, 375, 376, 377, 377, 377, 377, 378, 378, 387, 387, 388, 388, 388, 389, 389, 391, 391, 392, 393, 394, 395, 395, 395, 398, 400, 0, 400, 400, 401, 402, 405, 409, 409, 410, 410, 410, 410, 411, 411, 411, 412, 412, 412, 413, 413, 413, 414, 414, 414, 415, 415, 415, 416, 416, 416, 417, 417, 417, 418, 418, 418, 419, 419, 419, 420, 420, 420, 421, 421, 421, 422, 422, 422, 424, 424, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 111, 112, 115, 117, 118, 119, 124, 125, 132, 140, 141, 142, 147, 148, 149, 151, 152, 155, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 253, 255, 256, 257, 258, 259, 260, 261, 262, 263, 265, 270, 271, 274, 278, 281, 282, 283, 285, 288, 292, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 313, 314, 317, 319, 320, 321, 323, 324, 325, 326, 333, 334, 335, 338, 340, 341, 342, 343, 344, 345, 350, 351, 352, 357, 358, 359, 360, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 385, 386, 387, 388, 393, 394, 462, 464, 465, 466, 467, 468, 473, 474, 475, 476, 477, 478, 478, 481, 483, 484, 485, 486, 487, 493, 495, 496, 497, 498, 499, 500, 501, 502, 503, 505, 507, 509, 510, 511, 512, 513, 515, 517, 518, 520, 523, 527, 530, 531, 532, 533, 534, 536, 538, 543, 544, 547, 551, 554, 559, 560, 563, 567, 570, 571, 572, 573, 574, 576, 576, 579, 581, 582, 583, 584, 585, 586, 591, 592, 593, 594, 596, 599, 603, 606, 607, 609, 610, 611, 612, 617, 618, 625, 628, 630, 631, 632, 633, 634, 639, 640, 642, 643, 644, 645, 646, 650, 651, 652, 653, 654, 655, 656, 657, 747, 749, 750, 755, 756, 758, 759, 760, 761, 764, 766, 767, 768, 769, 770, 771, 776, 777, 778, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 794, 795, 796, 797, 798, 799, 800, 801, 809, 810, 811, 814, 816, 817, 818, 819, 820, 821, 826, 827, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 842, 843, 844, 845, 848, 849, 850, 852, 853, 854, 855, 856, 857, 863, 864, 865, 866, 871, 872, 875, 880, 881, 884, 888, 893, 898, 899, 902, 907, 912, 913, 916, 920, 921, 922, 923, 924, 925, 926, 930, 966, 967, 968, 970, 971, 972, 973, 974, 975, 976, 979, 981, 983, 985, 988, 992, 995, 997, 998, 999, 1000, 1001, 1002, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1036, 1037, 1038, 1039, 1042, 1044, 1045, 1046, 1047, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1067, 1068, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1113, 1115, 1116, 1117, 1123, 1124, 1125, 1128, 1130, 1131, 1132, 1138, 1139, 1140, 1143, 1145, 1146, 1147, 1153, 1204, 1205, 1206, 1209, 1211, 1212, 1213, 1214, 1219, 1220, 1221, 1228, 1229, 1230, 1233, 1235, 1236, 1237, 1238, 1243, 1244, 1245, 1246, 1247, 1248, 1249, 1250, 1251, 1252, 1259, 1260, 1261, 1264, 1266, 1267, 1268, 1269, 1270, 1271, 1276, 1277, 1278, 1285, 1286, 1287, 1290, 1292, 1293, 1294, 1295, 1300, 1301, 1302, 1303, 1304, 1305, 1306, 1311, 1312, 1313, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1329, 1330, 1330, 1333, 1335, 1336, 1337, 1343, 1377, 1378, 1384, 1385, 1386, 1391, 1392, 1393, 1394, 1395, 1396, 1397, 1398, 1399, 1400, 1401, 1402, 1403, 1404, 1405, 1406, 1407, 1408, 1409, 1410, 1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1429, 1430, 1433, 1436, 1440, 1443, 1447, 1450, 1454, 1457, 1461, 1464, 1468, 1471, 1475, 1478, 1482, 1485, 1489, 1492, 1496, 1499, 1503, 1506, 1510, 1513, 1517, 1520, 1524, 1527, 1531, 1534, 1538, 1541, 1545, 1548, 1552, 1555, 1559, 1562, 1566, 1569, 1573, 1576, 1580, 1583, 1587, 1590, 1594, 1597, 1601, 1604, 1608, 1611, 1615, 1618};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 77 87
new 0 77 87
assign 1 79 88
new 0 79 88
assign 1 81 89
new 0 81 89
assign 1 83 90
new 0 83 90
assign 1 84 91
new 0 84 91
assign 1 85 92
new 0 85 92
assign 1 86 93
new 0 86 93
assign 1 87 94
new 0 87 94
assign 1 88 95
new 0 88 95
assign 1 89 96
new 0 89 96
assign 1 90 97
new 0 90 97
assign 1 92 98
new 0 92 98
assign 1 93 99
new 0 93 99
assign 1 94 100
new 0 94 100
assign 1 95 101
new 0 95 101
assign 1 100 111
new 0 100 111
assign 1 101 112
valueIteratorGet 0 101 112
assign 1 101 115
hasNextGet 0 101 115
assign 1 102 117
nextGet 0 102 117
assign 1 103 118
mtdxGet 0 103 118
assign 1 103 119
greater 1 103 124
assign 1 104 125
mtdxGet 0 104 125
return 1 107 132
assign 1 111 140
new 0 111 140
assign 1 111 141
get 1 111 141
assign 1 112 142
def 1 112 147
assign 1 114 148
new 0 114 148
return 1 114 149
assign 1 116 151
new 0 116 151
return 1 116 152
new 0 119 155
assign 1 122 229
new 0 122 229
assign 1 123 230
new 0 123 230
assign 1 124 231
new 0 124 231
assign 1 125 232
new 0 125 232
assign 1 126 233
new 0 126 233
assign 1 127 234
new 0 127 234
assign 1 128 235
new 0 128 235
assign 1 129 236
new 0 129 236
assign 1 130 237
new 0 130 237
assign 1 131 238
new 0 131 238
assign 1 132 239
new 0 132 239
assign 1 133 240
superListGet 0 133 240
assign 1 133 241
copy 0 133 241
assign 1 134 242
namepathGet 0 134 242
addValue 1 134 243
assign 1 135 244
mtdListGet 0 135 244
assign 1 135 245
copy 0 135 245
assign 1 136 246
ptyListGet 0 136 246
assign 1 136 247
copy 0 136 247
assign 1 139 248
heldGet 0 139 248
assign 1 139 249
orderedVarsGet 0 139 249
assign 1 139 250
iteratorGet 0 139 250
assign 1 139 253
hasNextGet 0 139 253
assign 1 140 255
nextGet 0 140 255
assign 1 141 256
ptyMapGet 0 141 256
assign 1 141 257
heldGet 0 141 257
assign 1 141 258
nameGet 0 141 258
assign 1 141 259
get 1 141 259
assign 1 142 260
heldGet 0 142 260
assign 1 142 261
nameGet 0 142 261
assign 1 142 262
new 0 142 262
assign 1 142 263
notEquals 1 142 263
assign 1 142 265
undef 1 142 270
assign 1 0 271
assign 1 0 274
assign 1 0 278
assign 1 142 281
heldGet 0 142 281
assign 1 142 282
isDeclaredGet 0 142 282
assign 1 142 283
not 0 142 283
assign 1 0 285
assign 1 0 288
assign 1 0 292
assign 1 143 295
new 0 143 295
assign 1 143 296
heldGet 0 143 296
assign 1 143 297
nameGet 0 143 297
assign 1 143 298
add 1 143 298
assign 1 143 299
new 0 143 299
assign 1 143 300
add 1 143 300
assign 1 143 301
heldGet 0 143 301
assign 1 143 302
namepathGet 0 143 302
assign 1 143 303
toString 0 143 303
assign 1 143 304
add 1 143 304
assign 1 143 305
new 2 143 305
throw 1 143 306
assign 1 148 313
ptyListGet 0 148 313
assign 1 148 314
iteratorGet 0 148 314
assign 1 148 317
hasNextGet 0 148 317
assign 1 149 319
nextGet 0 149 319
assign 1 150 320
memSynGet 0 150 320
assign 1 150 321
isTypedGet 0 150 321
assign 1 151 323
heldGet 0 151 323
assign 1 151 324
memSynGet 0 151 324
assign 1 151 325
namepathGet 0 151 325
addUsed 1 151 326
assign 1 155 333
heldGet 0 155 333
assign 1 155 334
orderedMethodsGet 0 155 334
assign 1 155 335
iteratorGet 0 155 335
assign 1 155 338
hasNextGet 0 155 338
assign 1 156 340
nextGet 0 156 340
assign 1 157 341
mtdMapGet 0 157 341
assign 1 157 342
heldGet 0 157 342
assign 1 157 343
nameGet 0 157 343
assign 1 157 344
get 1 157 344
assign 1 158 345
def 1 158 350
assign 1 159 351
rsynGet 0 159 351
assign 1 159 352
def 1 159 357
assign 1 160 358
heldGet 0 160 358
assign 1 160 359
rtypeGet 0 160 359
assign 1 160 360
undef 1 160 365
assign 1 161 366
new 0 161 366
assign 1 161 367
heldGet 0 161 367
assign 1 161 368
nameGet 0 161 368
assign 1 161 369
add 1 161 369
assign 1 161 370
new 0 161 370
assign 1 161 371
add 1 161 371
assign 1 161 372
heldGet 0 161 372
assign 1 161 373
nameGet 0 161 373
assign 1 161 374
add 1 161 374
assign 1 161 375
new 2 161 375
throw 1 161 376
loadClass 1 166 385
assign 1 167 386
depthGet 0 167 386
assign 1 167 387
new 0 167 387
assign 1 167 388
add 1 167 388
assign 1 171 393
has 1 171 393
return 1 171 394
return 1 175 462
assign 1 176 464
new 0 176 464
assign 1 177 465
new 0 177 465
assign 1 178 466
new 0 178 466
assign 1 179 467
new 0 179 467
assign 1 180 468
undef 1 180 473
assign 1 181 474
new 0 181 474
assign 1 182 475
sizeGet 0 182 475
assign 1 183 476
sizeGet 0 183 476
assign 1 184 477
assign 1 185 478
arrayIteratorGet 0 0 478
assign 1 185 481
hasNextGet 0 185 481
assign 1 185 483
nextGet 0 185 483
assign 1 186 484
emitDataGet 0 186 484
assign 1 186 485
methodIndexesGet 0 186 485
assign 1 186 486
new 2 186 486
put 1 186 487
return 1 188 493
assign 1 190 495
getSynNp 1 190 495
assign 1 191 496
new 0 191 496
assign 1 192 497
new 0 192 497
assign 1 194 498
sizeGet 0 194 498
assign 1 194 499
ptyListGet 0 194 499
assign 1 194 500
sizeGet 0 194 500
assign 1 194 501
subtract 1 194 501
assign 1 195 502
libNameGet 0 195 502
assign 1 195 503
equals 1 195 503
integrate 1 195 505
assign 1 196 507
isFinalGet 0 196 507
assign 1 197 509
new 0 197 509
assign 1 197 510
toString 0 197 510
assign 1 197 511
add 1 197 511
assign 1 197 512
new 1 197 512
throw 1 197 513
assign 1 199 515
isLocalGet 0 199 515
assign 1 199 517
libNameGet 0 199 517
assign 1 199 518
notEquals 1 199 518
assign 1 0 520
assign 1 0 523
assign 1 0 527
assign 1 200 530
new 0 200 530
assign 1 200 531
toString 0 200 531
assign 1 200 532
add 1 200 532
assign 1 200 533
new 1 200 533
throw 1 200 534
assign 1 202 536
isLocalGet 0 202 536
assign 1 202 538
not 0 202 543
assign 1 0 544
assign 1 0 547
assign 1 0 551
assign 1 202 554
not 0 202 559
assign 1 0 560
assign 1 0 563
assign 1 0 567
assign 1 203 570
new 0 203 570
assign 1 203 571
toString 0 203 571
assign 1 203 572
add 1 203 572
assign 1 203 573
new 1 203 573
throw 1 203 574
assign 1 205 576
linkedListIteratorGet 0 0 576
assign 1 205 579
hasNextGet 0 205 579
assign 1 205 581
nextGet 0 205 581
assign 1 206 582
getSynNp 1 206 582
assign 1 207 583
closeLibrariesGet 0 207 583
assign 1 207 584
libNameGet 0 207 584
assign 1 207 585
has 1 207 585
assign 1 207 586
not 0 207 591
assign 1 207 592
toString 0 207 592
assign 1 207 593
new 0 207 593
assign 1 207 594
notEquals 1 207 594
assign 1 0 596
assign 1 0 599
assign 1 0 603
assign 1 209 606
new 0 209 606
assign 1 210 607
new 0 210 607
assign 1 212 609
closeLibrariesGet 0 212 609
assign 1 212 610
libNameGet 0 212 610
assign 1 212 611
has 1 212 611
assign 1 212 612
not 0 212 617
assign 1 213 618
new 0 213 618
assign 1 217 625
valueIteratorGet 0 217 625
assign 1 217 628
hasNextGet 0 217 628
assign 1 218 630
nextGet 0 218 630
assign 1 219 631
mtdMapGet 0 219 631
assign 1 219 632
nameGet 0 219 632
assign 1 219 633
get 1 219 633
assign 1 220 634
def 1 220 639
assign 1 221 640
notEquals 1 221 640
assign 1 222 642
new 0 222 642
lastDefSet 1 222 643
assign 1 223 644
new 0 223 644
isOverrideSet 1 223 645
assign 1 224 646
increment 0 224 646
assign 1 227 650
new 0 227 650
isOverrideSet 1 227 651
assign 1 228 652
increment 0 228 652
assign 1 229 653
increment 0 229 653
assign 1 230 654
emitDataGet 0 230 654
assign 1 230 655
methodIndexesGet 0 230 655
assign 1 230 656
new 2 230 656
put 1 230 657
return 1 237 747
assign 1 238 749
new 0 238 749
assign 1 239 750
undef 1 239 755
return 1 239 756
assign 1 240 758
getSynNp 1 240 758
assign 1 241 759
heldGet 0 241 759
assign 1 241 760
orderedVarsGet 0 241 760
assign 1 241 761
iteratorGet 0 241 761
assign 1 241 764
hasNextGet 0 241 764
assign 1 242 766
nextGet 0 242 766
assign 1 243 767
ptyMapGet 0 243 767
assign 1 243 768
heldGet 0 243 768
assign 1 243 769
nameGet 0 243 769
assign 1 243 770
get 1 243 770
assign 1 244 771
def 1 244 776
assign 1 245 777
heldGet 0 245 777
assign 1 245 778
isDeclaredGet 0 245 778
assign 1 246 780
new 0 246 780
assign 1 246 781
heldGet 0 246 781
assign 1 246 782
nameGet 0 246 782
assign 1 246 783
add 1 246 783
assign 1 246 784
new 0 246 784
assign 1 246 785
add 1 246 785
assign 1 246 786
heldGet 0 246 786
assign 1 246 787
namepathGet 0 246 787
assign 1 246 788
toString 0 246 788
assign 1 246 789
add 1 246 789
assign 1 246 790
new 1 246 790
throw 1 246 791
assign 1 248 794
heldGet 0 248 794
assign 1 248 795
memSynGet 0 248 795
assign 1 248 796
isTypedGet 0 248 796
isTypedSet 1 248 797
assign 1 249 798
heldGet 0 249 798
assign 1 249 799
memSynGet 0 249 799
assign 1 249 800
namepathGet 0 249 800
namepathSet 1 249 801
assign 1 253 809
heldGet 0 253 809
assign 1 253 810
orderedMethodsGet 0 253 810
assign 1 253 811
iteratorGet 0 253 811
assign 1 253 814
hasNextGet 0 253 814
assign 1 254 816
nextGet 0 254 816
assign 1 255 817
mtdMapGet 0 255 817
assign 1 255 818
heldGet 0 255 818
assign 1 255 819
nameGet 0 255 819
assign 1 255 820
get 1 255 820
assign 1 256 821
def 1 256 826
assign 1 257 827
isFinalGet 0 257 827
assign 1 258 829
new 0 258 829
assign 1 258 830
heldGet 0 258 830
assign 1 258 831
nameGet 0 258 831
assign 1 258 832
add 1 258 832
assign 1 258 833
new 0 258 833
assign 1 258 834
add 1 258 834
assign 1 258 835
heldGet 0 258 835
assign 1 258 836
namepathGet 0 258 836
assign 1 258 837
toString 0 258 837
assign 1 258 838
add 1 258 838
assign 1 258 839
new 2 258 839
throw 1 258 840
assign 1 260 842
containedGet 0 260 842
assign 1 260 843
firstGet 0 260 843
assign 1 260 844
containedGet 0 260 844
assign 1 261 845
new 0 261 845
assign 1 261 848
argSynsGet 0 261 848
assign 1 261 849
lengthGet 0 261 849
assign 1 261 850
lesser 1 261 850
assign 1 262 852
argSynsGet 0 262 852
assign 1 262 853
get 1 262 853
assign 1 263 854
get 1 263 854
assign 1 263 855
heldGet 0 263 855
checkTypes 5 265 856
assign 1 261 857
increment 0 261 857
assign 1 267 863
rsynGet 0 267 863
assign 1 268 864
heldGet 0 268 864
assign 1 268 865
rtypeGet 0 268 865
assign 1 269 866
undef 1 269 871
assign 1 0 872
assign 1 269 875
undef 1 269 880
assign 1 0 881
assign 1 0 884
assign 1 270 888
undef 1 270 893
assign 1 270 893
not 0 270 898
assign 1 0 899
assign 1 270 902
undef 1 270 907
assign 1 270 907
not 0 270 912
assign 1 0 913
assign 1 0 916
assign 1 271 920
new 0 271 920
assign 1 271 921
heldGet 0 271 921
assign 1 271 922
namepathGet 0 271 922
assign 1 271 923
toString 0 271 923
assign 1 271 924
add 1 271 924
assign 1 271 925
new 2 271 925
throw 1 271 926
checkTypes 5 275 930
assign 1 282 966
isTypedGet 0 282 966
assign 1 282 967
isTypedGet 0 282 967
assign 1 282 968
notEquals 1 282 968
assign 1 283 970
new 0 283 970
assign 1 283 971
heldGet 0 283 971
assign 1 283 972
namepathGet 0 283 972
assign 1 283 973
toString 0 283 973
assign 1 283 974
add 1 283 974
assign 1 283 975
new 2 283 975
throw 1 283 976
assign 1 284 979
isTypedGet 0 284 979
assign 1 287 981
isSelfGet 0 287 981
assign 1 287 983
isSelfGet 0 287 983
assign 1 0 985
assign 1 0 988
assign 1 0 992
return 1 288 995
assign 1 290 997
namepathGet 0 290 997
assign 1 290 998
getSynNp 1 290 998
assign 1 291 999
allTypesGet 0 291 999
assign 1 291 1000
namepathGet 0 291 1000
assign 1 291 1001
has 1 291 1001
assign 1 291 1002
not 0 291 1002
assign 1 292 1004
new 0 292 1004
assign 1 292 1005
heldGet 0 292 1005
assign 1 292 1006
namepathGet 0 292 1006
assign 1 292 1007
toString 0 292 1007
assign 1 292 1008
add 1 292 1008
assign 1 292 1009
new 2 292 1009
throw 1 292 1010
new 0 298 1036
assign 1 299 1037
heldGet 0 299 1037
assign 1 299 1038
orderedVarsGet 0 299 1038
assign 1 299 1039
iteratorGet 0 299 1039
assign 1 299 1042
hasNextGet 0 299 1042
assign 1 300 1044
nextGet 0 300 1044
assign 1 301 1045
heldGet 0 301 1045
assign 1 301 1046
isDeclaredGet 0 301 1046
assign 1 301 1047
not 0 301 1047
assign 1 302 1049
new 0 302 1049
assign 1 302 1050
heldGet 0 302 1050
assign 1 302 1051
nameGet 0 302 1051
assign 1 302 1052
add 1 302 1052
assign 1 302 1053
new 0 302 1053
assign 1 302 1054
add 1 302 1054
assign 1 302 1055
heldGet 0 302 1055
assign 1 302 1056
namepathGet 0 302 1056
assign 1 302 1057
toString 0 302 1057
assign 1 302 1058
add 1 302 1058
assign 1 302 1059
new 2 302 1059
throw 1 302 1060
loadClass 1 305 1067
assign 1 306 1068
new 0 306 1068
assign 1 311 1096
heldGet 0 311 1096
assign 1 311 1097
fromFileGet 0 311 1097
assign 1 312 1098
heldGet 0 312 1098
assign 1 312 1099
namepathGet 0 312 1099
assign 1 313 1100
heldGet 0 313 1100
assign 1 313 1101
libNameGet 0 313 1101
assign 1 314 1102
heldGet 0 314 1102
assign 1 314 1103
isFinalGet 0 314 1103
assign 1 315 1104
heldGet 0 315 1104
assign 1 315 1105
isLocalGet 0 315 1105
assign 1 316 1106
heldGet 0 316 1106
assign 1 316 1107
isNotNullGet 0 316 1107
assign 1 317 1108
heldGet 0 317 1108
assign 1 317 1109
usedGet 0 317 1109
assign 1 317 1110
iteratorGet 0 317 1110
assign 1 317 1113
hasNextGet 0 317 1113
assign 1 318 1115
nextGet 0 318 1115
assign 1 319 1116
toString 0 319 1116
put 1 319 1117
assign 1 321 1123
heldGet 0 321 1123
assign 1 321 1124
orderedVarsGet 0 321 1124
assign 1 321 1125
iteratorGet 0 321 1125
assign 1 321 1128
hasNextGet 0 321 1128
assign 1 322 1130
nextGet 0 322 1130
assign 1 323 1131
new 2 323 1131
addValue 1 324 1132
assign 1 326 1138
heldGet 0 326 1138
assign 1 326 1139
orderedMethodsGet 0 326 1139
assign 1 326 1140
iteratorGet 0 326 1140
assign 1 326 1143
hasNextGet 0 326 1143
assign 1 327 1145
nextGet 0 327 1145
assign 1 328 1146
new 2 328 1146
addValue 1 329 1147
postLoad 0 331 1153
assign 1 335 1204
new 0 335 1204
assign 1 336 1205
new 0 336 1205
assign 1 339 1206
iteratorGet 0 339 1206
assign 1 339 1209
hasNextGet 0 339 1209
assign 1 340 1211
nextGet 0 340 1211
assign 1 341 1212
nameGet 0 341 1212
assign 1 341 1213
has 1 341 1213
assign 1 341 1214
not 0 341 1219
assign 1 343 1220
nameGet 0 343 1220
put 2 343 1221
assign 1 347 1228
new 0 347 1228
assign 1 348 1229
new 0 348 1229
assign 1 349 1230
iteratorGet 0 349 1230
assign 1 349 1233
hasNextGet 0 349 1233
assign 1 350 1235
nextGet 0 350 1235
assign 1 351 1236
nameGet 0 351 1236
assign 1 351 1237
has 1 351 1237
assign 1 351 1238
not 0 351 1243
assign 1 352 1244
nameGet 0 352 1244
assign 1 352 1245
get 1 352 1245
mposSet 1 353 1246
assign 1 354 1247
new 0 354 1247
assign 1 354 1248
add 1 354 1248
addValue 1 355 1249
assign 1 356 1250
nameGet 0 356 1250
assign 1 356 1251
nameGet 0 356 1251
put 2 356 1252
assign 1 359 1259
assign 1 361 1260
new 0 361 1260
assign 1 363 1261
iteratorGet 0 363 1261
assign 1 363 1264
hasNextGet 0 363 1264
assign 1 364 1266
nextGet 0 364 1266
assign 1 366 1267
nameGet 0 366 1267
put 2 366 1268
assign 1 368 1269
nameGet 0 368 1269
assign 1 368 1270
has 1 368 1270
assign 1 368 1271
not 0 368 1276
assign 1 369 1277
nameGet 0 369 1277
put 2 369 1278
assign 1 373 1285
new 0 373 1285
assign 1 374 1286
new 0 374 1286
assign 1 375 1287
iteratorGet 0 375 1287
assign 1 375 1290
hasNextGet 0 375 1290
assign 1 376 1292
nextGet 0 376 1292
assign 1 377 1293
nameGet 0 377 1293
assign 1 377 1294
has 1 377 1294
assign 1 377 1295
not 0 377 1300
assign 1 378 1301
nameGet 0 378 1301
assign 1 378 1302
get 1 378 1302
assign 1 387 1303
nameGet 0 387 1303
assign 1 387 1304
get 1 387 1304
assign 1 388 1305
declarationGet 0 388 1305
assign 1 388 1306
undef 1 388 1311
assign 1 389 1312
originGet 0 389 1312
declarationSet 1 389 1313
assign 1 391 1315
declarationGet 0 391 1315
declarationSet 1 391 1316
mtdxSet 1 392 1317
assign 1 393 1318
increment 0 393 1318
addValue 1 394 1319
assign 1 395 1320
nameGet 0 395 1320
assign 1 395 1321
nameGet 0 395 1321
put 2 395 1322
assign 1 398 1329
assign 1 400 1330
linkedListIteratorGet 0 0 1330
assign 1 400 1333
hasNextGet 0 400 1333
assign 1 400 1335
nextGet 0 400 1335
put 2 401 1336
assign 1 402 1337
put 2 405 1343
assign 1 409 1377
new 0 409 1377
assign 1 409 1378
new 1 409 1378
assign 1 410 1384
new 0 410 1384
assign 1 410 1385
get 1 410 1385
assign 1 410 1386
undef 1 410 1391
assign 1 411 1392
new 0 411 1392
assign 1 411 1393
new 0 411 1393
put 2 411 1394
assign 1 412 1395
new 0 412 1395
assign 1 412 1396
new 0 412 1396
put 2 412 1397
assign 1 413 1398
new 0 413 1398
assign 1 413 1399
new 0 413 1399
put 2 413 1400
assign 1 414 1401
new 0 414 1401
assign 1 414 1402
new 0 414 1402
put 2 414 1403
assign 1 415 1404
new 0 415 1404
assign 1 415 1405
new 0 415 1405
put 2 415 1406
assign 1 416 1407
new 0 416 1407
assign 1 416 1408
new 0 416 1408
put 2 416 1409
assign 1 417 1410
new 0 417 1410
assign 1 417 1411
new 0 417 1411
put 2 417 1412
assign 1 418 1413
new 0 418 1413
assign 1 418 1414
new 0 418 1414
put 2 418 1415
assign 1 419 1416
new 0 419 1416
assign 1 419 1417
new 0 419 1417
put 2 419 1418
assign 1 420 1419
new 0 420 1419
assign 1 420 1420
new 0 420 1420
put 2 420 1421
assign 1 421 1422
new 0 421 1422
assign 1 421 1423
new 0 421 1423
put 2 421 1424
assign 1 422 1425
new 0 422 1425
assign 1 422 1426
new 0 422 1426
put 2 422 1427
assign 1 424 1429
new 2 424 1429
return 1 424 1430
return 1 0 1433
assign 1 0 1436
return 1 0 1440
assign 1 0 1443
return 1 0 1447
assign 1 0 1450
return 1 0 1454
assign 1 0 1457
return 1 0 1461
assign 1 0 1464
return 1 0 1468
assign 1 0 1471
return 1 0 1475
assign 1 0 1478
return 1 0 1482
assign 1 0 1485
return 1 0 1489
assign 1 0 1492
return 1 0 1496
assign 1 0 1499
return 1 0 1503
assign 1 0 1506
return 1 0 1510
assign 1 0 1513
return 1 0 1517
assign 1 0 1520
return 1 0 1524
assign 1 0 1527
return 1 0 1531
assign 1 0 1534
return 1 0 1538
assign 1 0 1541
return 1 0 1545
assign 1 0 1548
return 1 0 1552
assign 1 0 1555
return 1 0 1559
assign 1 0 1562
return 1 0 1566
assign 1 0 1569
return 1 0 1573
assign 1 0 1576
return 1 0 1580
assign 1 0 1583
return 1 0 1587
assign 1 0 1590
return 1 0 1594
assign 1 0 1597
return 1 0 1601
assign 1 0 1604
return 1 0 1608
assign 1 0 1611
return 1 0 1615
assign 1 0 1618
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 153365600: return bem_ptyMapGet_0();
case 1314364113: return bem_newMbrsGet_0();
case 2097069068: return bem_integratedGet_0();
case 1803479881: return bem_libNameGet_0();
case 287040793: return bem_hashGet_0();
case 1443447938: return bem_directMethodsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2033393684: return bem_ptyListGet_0();
case 842582618: return bem_isLocalGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 311680096: return bem_allNamesGet_0();
case 2058095605: return bem_signatureChangedGet_0();
case 1774940957: return bem_toString_0();
case 786424307: return bem_tagGet_0();
case 492006165: return bem_directPropertiesGet_0();
case 834964524: return bem_defMtdsGet_0();
case 1820417453: return bem_create_0();
case 1974592946: return bem_superListGet_0();
case 1760712968: return bem_signatureCheckedGet_0();
case 1274615854: return bem_allAncestorsCloseGet_0();
case 363636983: return bem_isNotNullGet_0();
case 1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case 1012494862: return bem_once_0();
case 1631955979: return bem_foreignClassesGet_0();
case 1214937871: return bem_newMtdsGet_0();
case 795036897: return bem_fromFileGet_0();
case 845792839: return bem_iteratorGet_0();
case 71634217: return bem_iCheckedGet_0();
case 287367803: return bem_isFinalGet_0();
case 354142775: return bem_namepathGet_0();
case 202810500: return bem_depthGet_0();
case 1477961836: return bem_mtdListGet_0();
case 345555227: return bem_usesGet_0();
case 1308786538: return bem_echo_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 244359240: return bem_mtdMapGet_0();
case 2055025483: return bem_serializeContents_0();
case 443668840: return bem_methodNotDefined_0();
case 986531569: return bem_allTypesGet_0();
case 481879936: return bem_hasDefaultGet_0();
case 1413594071: return bem_postLoad_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 729571811: return bem_serializeToString_0();
case 1354714650: return bem_copy_0();
case 68632810: return bem_superNpGet_0();
case 1495449800: return bem_maxMtdxGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 1118052001: return bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 82716470: return bem_iCheckedSet_1(bevd_0);
case 1432365685: return bem_directMethodsSet_1(bevd_0);
case 374719236: return bem_isNotNullSet_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 356637480: return bem_usesSet_1(bevd_0);
case 975449316: return bem_allTypesSet_1(bevd_0);
case 142283347: return bem_ptyMapSet_1(bevd_0);
case 79715063: return bem_superNpSet_1(bevd_0);
case 1749630715: return bem_signatureCheckedSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 2085986815: return bem_integratedSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 2047013352: return bem_signatureChangedSet_1(bevd_0);
case 255441493: return bem_mtdMapSet_1(bevd_0);
case 300597843: return bem_allNamesSet_1(bevd_0);
case 846046777: return bem_defMtdsSet_1(bevd_0);
case 831500365: return bem_isLocalSet_1(bevd_0);
case 480923912: return bem_directPropertiesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1489044089: return bem_mtdListSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1203855618: return bem_newMtdsSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1963510693: return bem_superListSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1285698107: return bem_allAncestorsCloseSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 340843364: return bem_loadClass_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1156342947: return bem_integrate_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1325446366: return bem_newMbrsSet_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 213892753: return bem_depthSet_1(bevd_0);
case 1620873726: return bem_foreignClassesSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2044475937: return bem_ptyListSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case 1694832085: return bem_checkInheritance_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case 913726521: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildClassSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildClassSyn.bevs_inst = (BEC_2_5_8_BuildClassSyn)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildClassSyn.bevs_inst;
}
}
