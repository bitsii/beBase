package be.BEL_4_Base;
/* File: source/build/CCallAssembler.be */
public class BEC_5_15_BuildCAssembleString extends BEC_5_14_BuildCCallAssembler {
public BEC_5_15_BuildCAssembleString() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x41,0x73,0x73,0x65,0x6D,0x62,0x6C,0x65,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x61,0x6C,0x6C,0x41,0x73,0x73,0x65,0x6D,0x62,0x6C,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x42,0x45,0x52,0x46,0x5F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x46,0x6F,0x72,0x5F,0x43,0x68,0x61,0x72,0x73,0x5F,0x53,0x69,0x7A,0x65,0x28,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2C,0x20,0x28,0x63,0x68,0x61,0x72,0x2A,0x29,0x20,0x26};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_0, 46));
private static byte[] bels_1 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_1, 2));
private static byte[] bels_2 = {0x29,0x3B};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_2, 2));
public static BEC_5_15_BuildCAssembleString bevs_inst;
public BEC_6_3_EncodeUrl bevp_encode;
public BEC_5_15_BuildCAssembleString bem_new_1(BEC_6_6_SystemObject beva_build) throws Throwable {
this.bem_loadBuild_1(beva_build);
bevp_encode = (BEC_6_3_EncodeUrl) BEC_6_3_EncodeUrl.bevs_inst.bem_new_0();
return this;
} /*method end*/
public BEC_4_6_TextString bem_processCall_1(BEC_5_10_BuildCallCursor beva_ca) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
bevt_4_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 588 */ {
bevt_6_tmpvar_phold = beva_ca.bem_asnRGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 588 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 588 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 588 */
 else  /* Line: 588 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 588 */ {
bevt_9_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_heldGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 588 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 588 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 588 */
 else  /* Line: 588 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 588 */ {
bevt_10_tmpvar_phold = this.bem_processLiteralConstruct_1(beva_ca);
return bevt_10_tmpvar_phold;
} /* Line: 589 */
bevt_11_tmpvar_phold = this.bem_standardCall_1(beva_ca);
return bevt_11_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_processLiteralConstruct_1(BEC_5_10_BuildCallCursor beva_ca) throws Throwable {
BEC_4_6_TextString bevl_callRet = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
bevt_7_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevt_8_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_0;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = beva_ca.bem_belsNameGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_1;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = beva_ca.bem_belsValueGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_2;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
beva_ca.bem_tcallSet_1(bevt_0_tmpvar_phold);
bevl_callRet = (new BEC_4_6_TextString()).bem_new_0();
bevt_15_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevl_callRet.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_17_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_18_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public BEC_6_3_EncodeUrl bem_encodeGet_0() throws Throwable {
return bevp_encode;
} /*method end*/
public BEC_6_6_SystemObject bem_encodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_encode = (BEC_6_3_EncodeUrl) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {581, 583, 588, 588, 588, 588, 588, 588, 0, 0, 0, 588, 588, 588, 0, 0, 0, 589, 589, 591, 591, 596, 596, 596, 596, 596, 596, 596, 596, 596, 596, 596, 596, 596, 596, 596, 596, 598, 599, 599, 600, 600, 601, 601, 602, 602, 603, 0, 0};
//int[] bevs_nlecs = {16, 17, 33, 34, 35, 37, 38, 43, 44, 47, 51, 54, 55, 56, 58, 61, 65, 68, 69, 71, 72, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 123, 126};
/* BEGIN LINEINFO 
loadBuild 1 581 16
assign 1 583 17
new 0 583 17
assign 1 588 33
nodeGet 0 588 33
assign 1 588 34
heldGet 0 588 34
assign 1 588 35
isConstructGet 0 588 35
assign 1 588 37
asnRGet 0 588 37
assign 1 588 38
def 1 588 43
assign 1 0 44
assign 1 0 47
assign 1 0 51
assign 1 588 54
nodeGet 0 588 54
assign 1 588 55
heldGet 0 588 55
assign 1 588 56
isLiteralGet 0 588 56
assign 1 0 58
assign 1 0 61
assign 1 0 65
assign 1 589 68
processLiteralConstruct 1 589 68
return 1 589 69
assign 1 591 71
standardCall 1 591 71
return 1 591 72
assign 1 596 95
tcallGet 0 596 95
assign 1 596 96
assignToVVGet 0 596 96
assign 1 596 97
add 1 596 97
assign 1 596 98
new 0 596 98
assign 1 596 99
add 1 596 99
assign 1 596 100
belsNameGet 0 596 100
assign 1 596 101
add 1 596 101
assign 1 596 102
new 0 596 102
assign 1 596 103
add 1 596 103
assign 1 596 104
belsValueGet 0 596 104
assign 1 596 105
sizeGet 0 596 105
assign 1 596 106
add 1 596 106
assign 1 596 107
new 0 596 107
assign 1 596 108
add 1 596 108
assign 1 596 109
add 1 596 109
tcallSet 1 596 110
assign 1 598 111
new 0 598 111
assign 1 599 112
preOnceEvalGet 0 599 112
addValue 1 599 113
assign 1 600 114
tcallGet 0 600 114
addValue 1 600 115
assign 1 601 116
assignToCheckGet 0 601 116
addValue 1 601 117
assign 1 602 118
postOnceEvalGet 0 602 118
addValue 1 602 119
return 1 603 120
return 1 0 123
assign 1 0 126
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2001798761: return bem_nlGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1900236049: return bem_encodeGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1178476504: return bem_fromTypesGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 281832742: return bem_loadBuild_1(bevd_0);
case 785892343: return bem_processOptimizedSetter_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1189558757: return bem_fromTypesSet_1(bevd_0);
case 1911318302: return bem_encodeSet_1(bevd_0);
case 224779883: return bem_processOptimizedGetter_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1977543830: return bem_processNot_1((BEC_5_10_BuildCallCursor) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1292480624: return bem_processAssign_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 77715863: return bem_processLiteralConstruct_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1833349037: return bem_standardCall_1((BEC_5_10_BuildCallCursor) bevd_0);
case 846242271: return bem_processCall_1((BEC_5_10_BuildCallCursor) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 19297983: return bem_accessorCheckBlock_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 429177731: return bem_standardBlock_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 436992814: return bem_standardBlockAssign_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_15_BuildCAssembleString();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_15_BuildCAssembleString.bevs_inst = (BEC_5_15_BuildCAssembleString)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_15_BuildCAssembleString.bevs_inst;
}
}
