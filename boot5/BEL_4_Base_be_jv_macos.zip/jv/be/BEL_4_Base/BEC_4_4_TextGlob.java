package be.BEL_4_Base;
/* File: source/base/Tokenize.be */
public class BEC_4_4_TextGlob extends BEC_6_6_SystemObject {
public BEC_4_4_TextGlob() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x47,0x6C,0x6F,0x62};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2A,0x3F};
private static byte[] bels_1 = {0x2A};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_1, 1));
private static byte[] bels_2 = {0x3F};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_2, 1));
public static BEC_4_4_TextGlob bevs_inst;
public BEC_4_6_TextString bevp_glob;
public BEC_9_10_ContainerLinkedList bevp_splits;
public BEC_4_4_TextGlob bem_new_1(BEC_4_6_TextString beva__glob) throws Throwable {
this.bem_globSet_1(beva__glob);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_globSet_1(BEC_4_6_TextString beva__glob) throws Throwable {
BEC_4_9_TextTokenizer bevl_tok = null;
BEC_9_10_ContainerLinkedList bevl__splits = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(2, bels_0));
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_tok = (new BEC_4_9_TextTokenizer()).bem_new_2(bevt_0_tmpvar_phold, bevt_1_tmpvar_phold);
bevl__splits = (BEC_9_10_ContainerLinkedList) bevl_tok.bem_tokenize_1(beva__glob);
bevp_glob = beva__glob;
bevp_splits = bevl__splits;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_match_1(BEC_4_6_TextString beva_input) throws Throwable {
BEC_9_10_4_ContainerLinkedListNode bevl_node = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_splits.bem_iteratorGet_0();
bevl_node = (BEC_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_phold.bemd_0(1816451342, BEL_4_Base.bevn_nextNodeGet_0);
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_1_tmpvar_phold = this.bem_caseMatch_4(bevl_node, beva_input, bevt_2_tmpvar_phold, null);
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_caseMatch_4(BEC_9_10_4_ContainerLinkedListNode beva_node, BEC_4_6_TextString beva_input, BEC_4_3_MathInt beva_pos, BEC_9_6_ContainerSingle beva_lpos) throws Throwable {
BEC_4_6_TextString bevl_val = null;
BEC_4_3_MathInt bevl_found = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
if (beva_node == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 135 */ {
bevt_2_tmpvar_phold = beva_input.bem_sizeGet_0();
bevt_1_tmpvar_phold = beva_pos.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /* Line: 137 */
 else  /* Line: 138 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 139 */
} /* Line: 136 */
bevl_val = (BEC_4_6_TextString) beva_node.bem_heldGet_0();
bevt_6_tmpvar_phold = bevo_0;
bevt_5_tmpvar_phold = bevl_val.bem_equals_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 143 */ {
bevt_7_tmpvar_phold = this.bem_starMatch_3(beva_node, beva_input, beva_pos);
return bevt_7_tmpvar_phold;
} /* Line: 144 */
bevt_9_tmpvar_phold = bevo_1;
bevt_8_tmpvar_phold = bevl_val.bem_equals_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 146 */ {
beva_pos = beva_pos.bem_increment_0();
bevt_11_tmpvar_phold = beva_input.bem_sizeGet_0();
bevt_10_tmpvar_phold = beva_pos.bem_lesserEquals_1(bevt_11_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 148 */ {
bevt_13_tmpvar_phold = beva_node.bem_nextGet_0();
bevt_12_tmpvar_phold = this.bem_caseMatch_4(bevt_13_tmpvar_phold, beva_input, beva_pos, null);
return bevt_12_tmpvar_phold;
} /* Line: 148 */
 else  /* Line: 148 */ {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_14_tmpvar_phold;
} /* Line: 148 */
} /* Line: 148 */
bevl_found = beva_input.bem_find_2(bevl_val, beva_pos);
if (bevl_found == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 151 */ {
bevt_16_tmpvar_phold = bevl_found.bem_equals_1(beva_pos);
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 152 */ {
bevt_18_tmpvar_phold = beva_node.bem_nextGet_0();
bevt_20_tmpvar_phold = bevl_val.bem_sizeGet_0();
bevt_19_tmpvar_phold = beva_pos.bem_add_1(bevt_20_tmpvar_phold);
bevt_17_tmpvar_phold = this.bem_caseMatch_4(bevt_18_tmpvar_phold, beva_input, bevt_19_tmpvar_phold, null);
return bevt_17_tmpvar_phold;
} /* Line: 153 */
 else  /* Line: 154 */ {
if (beva_lpos == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 155 */ {
beva_lpos.bem_firstSet_1(bevl_found);
} /* Line: 156 */
} /* Line: 155 */
} /* Line: 152 */
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_22_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_starMatch_3(BEC_9_10_4_ContainerLinkedListNode beva_node, BEC_4_6_TextString beva_input, BEC_4_3_MathInt beva_pos) throws Throwable {
BEC_9_10_4_ContainerLinkedListNode bevl_nx = null;
BEC_9_6_ContainerSingle bevl_lpos = null;
BEC_5_4_LogicBool bevl_ok = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_nx = beva_node.bem_nextGet_0();
bevl_lpos = (new BEC_9_6_ContainerSingle()).bem_new_0();
while (true)
 /* Line: 167 */ {
bevt_1_tmpvar_phold = beva_input.bem_sizeGet_0();
bevt_0_tmpvar_phold = beva_pos.bem_lesserEquals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 167 */ {
bevl_ok = this.bem_caseMatch_4(bevl_nx, beva_input, beva_pos, bevl_lpos);
if (bevl_ok.bevi_bool) /* Line: 169 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 169 */
bevt_4_tmpvar_phold = bevl_lpos.bem_firstGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 170 */ {
beva_pos = (BEC_4_3_MathInt) bevl_lpos.bem_firstGet_0();
bevl_lpos.bem_firstSet_1(null);
} /* Line: 172 */
 else  /* Line: 173 */ {
beva_pos = beva_pos.bem_increment_0();
} /* Line: 174 */
} /* Line: 170 */
 else  /* Line: 167 */ {
break;
} /* Line: 167 */
} /* Line: 167 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_globGet_0() throws Throwable {
return bevp_glob;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_splitsGet_0() throws Throwable {
return bevp_splits;
} /*method end*/
public BEC_6_6_SystemObject bem_splitsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_splits = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {112, 116, 116, 116, 117, 119, 120, 130, 130, 131, 131, 131, 135, 135, 136, 136, 137, 137, 139, 139, 142, 143, 143, 144, 144, 146, 146, 147, 148, 148, 148, 148, 148, 148, 148, 150, 151, 151, 152, 153, 153, 153, 153, 153, 155, 155, 156, 160, 160, 164, 165, 167, 167, 168, 169, 169, 170, 170, 170, 171, 172, 174, 177, 177, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {16, 24, 25, 26, 27, 28, 29, 37, 38, 39, 40, 41, 69, 74, 75, 76, 78, 79, 82, 83, 86, 87, 88, 90, 91, 93, 94, 96, 97, 98, 100, 101, 102, 105, 106, 109, 110, 115, 116, 118, 119, 120, 121, 122, 125, 130, 131, 135, 136, 148, 149, 152, 153, 155, 157, 158, 160, 161, 166, 167, 168, 171, 178, 179, 182, 185, 188};
/* BEGIN LINEINFO 
globSet 1 112 16
assign 1 116 24
new 0 116 24
assign 1 116 25
new 0 116 25
assign 1 116 26
new 2 116 26
assign 1 117 27
tokenize 1 117 27
assign 1 119 28
assign 1 120 29
assign 1 130 37
iteratorGet 0 130 37
assign 1 130 38
nextNodeGet 0 130 38
assign 1 131 39
new 0 131 39
assign 1 131 40
caseMatch 4 131 40
return 1 131 41
assign 1 135 69
undef 1 135 74
assign 1 136 75
sizeGet 0 136 75
assign 1 136 76
equals 1 136 76
assign 1 137 78
new 0 137 78
return 1 137 79
assign 1 139 82
new 0 139 82
return 1 139 83
assign 1 142 86
heldGet 0 142 86
assign 1 143 87
new 0 143 87
assign 1 143 88
equals 1 143 88
assign 1 144 90
starMatch 3 144 90
return 1 144 91
assign 1 146 93
new 0 146 93
assign 1 146 94
equals 1 146 94
assign 1 147 96
increment 0 147 96
assign 1 148 97
sizeGet 0 148 97
assign 1 148 98
lesserEquals 1 148 98
assign 1 148 100
nextGet 0 148 100
assign 1 148 101
caseMatch 4 148 101
return 1 148 102
assign 1 148 105
new 0 148 105
return 1 148 106
assign 1 150 109
find 2 150 109
assign 1 151 110
def 1 151 115
assign 1 152 116
equals 1 152 116
assign 1 153 118
nextGet 0 153 118
assign 1 153 119
sizeGet 0 153 119
assign 1 153 120
add 1 153 120
assign 1 153 121
caseMatch 4 153 121
return 1 153 122
assign 1 155 125
def 1 155 130
firstSet 1 156 131
assign 1 160 135
new 0 160 135
return 1 160 136
assign 1 164 148
nextGet 0 164 148
assign 1 165 149
new 0 165 149
assign 1 167 152
sizeGet 0 167 152
assign 1 167 153
lesserEquals 1 167 153
assign 1 168 155
caseMatch 4 168 155
assign 1 169 157
new 0 169 157
return 1 169 158
assign 1 170 160
firstGet 0 170 160
assign 1 170 161
def 1 170 166
assign 1 171 167
firstGet 0 171 167
firstSet 1 172 168
assign 1 174 171
increment 0 174 171
assign 1 177 178
new 0 177 178
return 1 177 179
return 1 0 182
return 1 0 185
assign 1 0 188
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 363750127: return bem_globGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1413456786: return bem_splitsGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 374832380: return bem_globSet_1((BEC_4_6_TextString) bevd_0);
case 1402374533: return bem_splitsSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 840861751: return bem_match_1((BEC_4_6_TextString) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 1718699641: return bem_starMatch_3((BEC_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_3_MathInt) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1345367786: return bem_caseMatch_4((BEC_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_9_6_ContainerSingle) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_4_TextGlob();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_4_TextGlob.bevs_inst = (BEC_4_4_TextGlob)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_4_TextGlob.bevs_inst;
}
}
