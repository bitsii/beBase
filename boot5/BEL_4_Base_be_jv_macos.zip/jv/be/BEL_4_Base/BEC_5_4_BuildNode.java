package be.BEL_4_Base;
/* File: source/build/Nodes.be */
public class BEC_5_4_BuildNode extends BEC_6_6_SystemObject {
public BEC_5_4_BuildNode() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x3C};
private static byte[] bels_1 = {0x3E};
private static byte[] bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x49,0x6E,0x20,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_5 = {0x20};
private static byte[] bels_6 = {0x3C};
private static byte[] bels_7 = {0x3E};
private static byte[] bels_8 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_8, 7));
private static byte[] bels_9 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_9, 8));
private static byte[] bels_10 = {0x20};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_10, 1));
private static byte[] bels_11 = {0x20,0x20};
private static byte[] bels_12 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bels_13 = {0x5F,0x74,0x6D,0x70,0x76,0x61,0x72,0x5F};
private static byte[] bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_15 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bels_17 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_17, 18));
private static byte[] bels_18 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_19 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bels_20 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static BEC_9_3_ContainerSet bevo_4;
private static BEC_9_3_ContainerSet bevo_5;
private static BEC_9_3_ContainerSet bevo_6;
private static BEC_9_3_ContainerSet bevo_7;
private static BEC_9_3_ContainerSet bevo_8;
private static BEC_4_3_MathInt bevo_9 = (new BEC_4_3_MathInt(0));
private static byte[] bels_21 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bels_22 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_23 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_24 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bels_25 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bels_26 = {0x70,0x72,0x69,0x6E,0x74,0x5F,0x30};
private static byte[] bels_27 = {0x65,0x63,0x68,0x6F,0x5F,0x30};
private static byte[] bels_28 = {0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x30};
private static byte[] bels_29 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bels_30 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bels_31 = {0x70,0x6F,0x77,0x65,0x72,0x5F,0x31};
private static byte[] bels_32 = {0x63,0x6F,0x6D,0x70,0x61,0x72,0x65,0x5F,0x31};
private static byte[] bels_33 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bels_34 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bels_35 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_36 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_37 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_38 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_39 = {0x66,0x69,0x6E,0x64,0x5F,0x32};
private static byte[] bels_40 = {0x66,0x69,0x6E,0x64,0x5F,0x31};
private static byte[] bels_41 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_42 = {0x69,0x73,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x5F,0x30};
private static byte[] bels_43 = {0x67,0x65,0x74,0x50,0x6F,0x69,0x6E,0x74,0x5F,0x31};
private static byte[] bels_44 = {0x65,0x6E,0x64,0x73,0x5F,0x31};
private static byte[] bels_45 = {0x62,0x65,0x67,0x69,0x6E,0x73,0x5F,0x31};
private static byte[] bels_46 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bels_47 = {0x73,0x75,0x62,0x73,0x74,0x72,0x69,0x6E,0x67,0x5F,0x32};
private static byte[] bels_48 = {0x73,0x69,0x7A,0x65,0x47,0x65,0x74,0x5F,0x30};
private static byte[] bels_49 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] bels_50 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] bels_51 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] bels_52 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] bels_53 = {0x67,0x65,0x74,0x5F,0x31};
private static byte[] bels_54 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_55 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_5_4_BuildNode bevs_inst;
public BEC_9_8_ContainerNodeList bevp_contained;
public BEC_5_4_BuildNode bevp_container;
public BEC_6_6_SystemObject bevp_held;
public BEC_6_6_SystemObject bevp_heldBy;
public BEC_6_6_SystemObject bevp_condvar;
public BEC_5_8_BuildNamePath bevp_inClassNp;
public BEC_4_6_TextString bevp_inFile;
public BEC_6_6_SystemObject bevp_typeDetail;
public BEC_5_4_LogicBool bevp_delayDelete;
public BEC_4_3_MathInt bevp_nlc;
public BEC_4_3_MathInt bevp_nlec;
public BEC_5_4_LogicBool bevp_wideString;
public BEC_5_5_BuildBuild bevp_build;
public BEC_5_9_BuildConstants bevp_constants;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_4_3_MathInt bevp_typename;
public BEC_5_4_BuildNode bem_new_1(BEC_5_5_BuildBuild beva__build) throws Throwable {
bevp_delayDelete = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_nlc = (new BEC_4_3_MathInt(0));
bevp_nlec = (new BEC_4_3_MathInt(0));
bevp_wideString = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_copyLoc_1(BEC_5_4_BuildNode beva_fromNode) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_fromNode.bem_nlcGet_0();
bevp_nlc = (BEC_4_3_MathInt) bevt_0_tmpvar_phold.bem_copy_0();
bevt_1_tmpvar_phold = beva_fromNode.bem_nlecGet_0();
bevp_nlec = (BEC_4_3_MathInt) bevt_1_tmpvar_phold.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_nextDescendGet_0() throws Throwable {
BEC_5_4_BuildNode bevl_ret = null;
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_4_tmpvar_phold = bevp_contained.bem_firstGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 52 */ {
bevt_5_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_5_4_BuildNode) bevt_5_tmpvar_phold;
} /* Line: 53 */
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 57 */ {
if (bevl_ret == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 57 */ {
if (bevl_con == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 57 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 59 */
 else  /* Line: 57 */ {
break;
} /* Line: 57 */
} /* Line: 57 */
return bevl_ret;
} /*method end*/
public BEC_5_4_BuildNode bem_nextAscendGet_0() throws Throwable {
BEC_5_4_BuildNode bevl_ret = null;
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 67 */ {
if (bevl_ret == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 67 */ {
if (bevl_con == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 67 */
 else  /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 67 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 69 */
 else  /* Line: 67 */ {
break;
} /* Line: 67 */
} /* Line: 67 */
return bevl_ret;
} /*method end*/
public BEC_5_4_BuildNode bem_nextPeerGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_hh = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 75 */ {
return null;
} /* Line: 76 */
bevl_hh = bevp_heldBy.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 79 */ {
return (BEC_5_4_BuildNode) bevl_hh;
} /* Line: 80 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public BEC_5_4_BuildNode bem_priorPeerGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_hh = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 86 */ {
return null;
} /* Line: 87 */
bevl_hh = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 90 */ {
return (BEC_5_4_BuildNode) bevl_hh;
} /* Line: 91 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public BEC_5_4_BuildNode bem_firstGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_BuildNode bem_secondGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_secondGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_BuildNode bem_thirdGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_thirdGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isFirstGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 110 */
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isSecondGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 116 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 117 */
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isThirdGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_4_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 123 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 124 */
bevt_12_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_10_tmpvar_phold == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_9_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_delayDelete_0() throws Throwable {
bevp_delayDelete = be.BELS_Base.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 134 */ {
return null;
} /* Line: 135 */
bevp_heldBy.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevp_container = null;
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_beforeInsert_1(BEC_5_4_BuildNode beva_x) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 143 */ {
return null;
} /* Line: 144 */
bevt_2_tmpvar_phold = bevp_heldBy.bemd_0(1849179299, BEL_4_Base.bevn_mylistGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(743891212, BEL_4_Base.bevn_newNode_1, beva_x);
bevp_heldBy.bemd_1(1505376950, BEL_4_Base.bevn_insertBefore_1, bevt_1_tmpvar_phold);
beva_x.bem_containerSet_1(bevp_container);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_prepend_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 151 */ {
this.bem_initContained_0();
} /* Line: 152 */
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addValue_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 159 */ {
this.bem_initContained_0();
} /* Line: 160 */
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_reInitContained_0() throws Throwable {
bevp_contained = (BEC_9_8_ContainerNodeList) (new BEC_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_initContained_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevp_contained = (BEC_9_8_ContainerNodeList) (new BEC_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 172 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_6_6_SystemObject bevl_e = null;
BEC_4_6_TextString bevl_res = null;
try  /* Line: 178 */ {
bevl_res = this.bem_toStringCompact_0();
} /* Line: 179 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 182 */
return bevl_res;
} /*method end*/
public BEC_4_6_TextString bem_toStringBig_0() throws Throwable {
BEC_6_6_SystemObject bevl_prefix = null;
BEC_6_6_SystemObject bevl_ret = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_3_tmpvar_phold = (new BEC_4_6_TextString(1, bels_0));
bevt_2_tmpvar_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_typename.bem_toString_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(1, bels_1));
bevl_ret = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_newlineGet_0();
bevt_8_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_11_tmpvar_phold = (new BEC_4_6_TextString(6, bels_2));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_12_tmpvar_phold);
if (bevp_inClassNp == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 191 */ {
if (bevp_inFile == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
 else  /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 191 */ {
bevt_22_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_newlineGet_0();
bevt_20_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_23_tmpvar_phold = (new BEC_4_6_TextString(11, bels_3));
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = bevp_inClassNp.bem_toString_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(10, bels_4));
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_25_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_inFile);
bevt_27_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_newlineGet_0();
bevl_ret = bevt_15_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 192 */
if (bevp_held == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevt_32_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_newlineGet_0();
bevt_30_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_31_tmpvar_phold);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_33_tmpvar_phold = (new BEC_4_6_TextString(1, bels_5));
bevl_ret = bevt_29_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_34_tmpvar_phold);
} /* Line: 196 */
return (BEC_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_4_6_TextString bem_toStringCompact_0() throws Throwable {
BEC_6_6_SystemObject bevl_prefix = null;
BEC_4_6_TextString bevl_ret = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_typename.bem_toString_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_4_6_TextString(1, bels_7));
bevl_ret = (BEC_4_6_TextString) bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpvar_phold);
if (bevp_nlc == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_7_tmpvar_phold = bevo_0;
bevt_6_tmpvar_phold = bevl_ret.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
} /* Line: 205 */
if (bevp_inClassNp == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevt_11_tmpvar_phold = bevo_1;
bevt_10_tmpvar_phold = bevl_ret.bem_add_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
} /* Line: 208 */
if (bevp_held == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_15_tmpvar_phold = bevo_2;
bevt_14_tmpvar_phold = bevl_ret.bem_add_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevt_14_tmpvar_phold.bem_add_1(bevt_16_tmpvar_phold);
} /* Line: 211 */
return bevl_ret;
} /*method end*/
public BEC_6_6_SystemObject bem_depthGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_d = null;
BEC_6_6_SystemObject bevl_c = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_d = (new BEC_4_3_MathInt(0));
bevl_c = bevp_container;
while (true)
 /* Line: 219 */ {
if (bevl_c == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 219 */ {
bevl_d = bevl_d.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevl_c = bevl_c.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 221 */
 else  /* Line: 219 */ {
break;
} /* Line: 219 */
} /* Line: 219 */
return bevl_d;
} /*method end*/
public BEC_6_6_SystemObject bem_prefixGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_d = null;
BEC_6_6_SystemObject bevl_p = null;
BEC_6_6_SystemObject bevl_q = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_d = this.bem_depthGet_0();
bevl_p = (new BEC_4_6_TextString()).bem_new_0();
bevl_q = (new BEC_4_6_TextString(2, bels_11));
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 230 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_d);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 230 */ {
bevl_p = bevl_p.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_q);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 230 */
 else  /* Line: 230 */ {
break;
} /* Line: 230 */
} /* Line: 230 */
return bevl_p;
} /*method end*/
public BEC_6_6_SystemObject bem_transUnitGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 238 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
 else  /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 238 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 239 */
 else  /* Line: 238 */ {
break;
} /* Line: 238 */
} /* Line: 238 */
return bevl_targ;
} /*method end*/
public BEC_6_6_SystemObject bem_tmpVar_2(BEC_6_6_SystemObject beva_suffix, BEC_6_6_SystemObject beva_build) throws Throwable {
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_tmpvarn = null;
BEC_6_6_SystemObject bevl_tmpvar = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
bevl_clnode = this.bem_scopeGet_0();
bevt_1_tmpvar_phold = bevl_clnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_2_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 246 */ {
bevt_4_tmpvar_phold = (new BEC_4_6_TextString(22, bels_12));
bevt_3_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_4_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 247 */
bevt_6_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevl_tmpvarn = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevt_7_tmpvar_phold.bemd_1(241589730, BEL_4_Base.bevn_tmpCntSet_1, bevt_8_tmpvar_phold);
bevl_tmpvar = (new BEC_5_3_BuildVar()).bem_new_0();
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_tmpvar.bemd_1(1124689062, BEL_4_Base.bevn_isTmpVarSet_1, bevt_11_tmpvar_phold);
bevl_tmpvar.bemd_1(2093073725, BEL_4_Base.bevn_suffixSet_1, beva_suffix);
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(8, bels_13));
bevt_13_tmpvar_phold = bevl_tmpvarn.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, beva_suffix);
bevl_tmpvar.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_12_tmpvar_phold);
return bevl_tmpvar;
} /*method end*/
public BEC_5_4_LogicBool bem_inPropertiesGet_0() throws Throwable {
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_con = bevp_container;
while (true)
 /* Line: 260 */ {
if (bevl_con == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 260 */ {
bevt_2_tmpvar_phold = bevl_con.bem_typenameGet_0();
bevt_3_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 261 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 262 */
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 264 */
 else  /* Line: 260 */ {
break;
} /* Line: 260 */
} /* Line: 260 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_addVariable_0() throws Throwable {
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_sco = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_2_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_3_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevt_5_tmpvar_phold = bevl_sco.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 274 */ {
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(54, bels_14));
bevt_7_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_8_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 275 */
bevt_9_tmpvar_phold = this.bem_inPropertiesGet_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevt_11_tmpvar_phold = bevl_v.bemd_0(1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
 else  /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 277 */ {
bevl_sco = this.bem_classGet_0();
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_12_tmpvar_phold);
} /* Line: 279 */
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_15_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 282 */ {
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(30, bels_15));
bevt_16_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_16_tmpvar_phold);
} /* Line: 283 */
bevt_18_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_19_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_18_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_19_tmpvar_phold, this);
bevt_20_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_20_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 286 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_syncAddVariable_0() throws Throwable {
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_sco = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_6_6_SystemObject bevl_cl = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_1_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 292 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_2_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_5_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 296 */ {
bevt_6_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_7_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_6_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpvar_phold);
} /* Line: 297 */
 else  /* Line: 298 */ {
bevt_8_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_11_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 300 */ {
bevt_12_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_13_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_12_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_13_tmpvar_phold);
} /* Line: 301 */
 else  /* Line: 302 */ {
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_14_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_15_tmpvar_phold, this);
bevt_16_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_16_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
bevt_18_tmpvar_phold = bevl_sco.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_19_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 305 */ {
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(35, bels_16));
bevt_20_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 306 */
} /* Line: 305 */
} /* Line: 300 */
} /* Line: 296 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_syncVariable_1(BEC_5_5_7_BuildVisitVisitor beva_visit) throws Throwable {
BEC_6_6_SystemObject bevl_vname = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_6_6_SystemObject bevl_cl = null;
BEC_6_6_SystemObject bevl_tunode = null;
BEC_6_6_SystemObject bevl_np = null;
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
bevl_vname = bevp_held;
bevt_0_tmpvar_phold = this.bem_scopeGet_0();
bevl_sc = bevt_0_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 317 */ {
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_3_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 318 */
 else  /* Line: 319 */ {
bevt_5_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_5_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 321 */ {
bevt_9_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 322 */
 else  /* Line: 323 */ {
bevl_tunode = this.bem_transUnitGet_0();
bevt_11_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevl_np = bevt_10_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
if (bevl_np == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 326 */ {
bevt_15_tmpvar_phold = bevo_3;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevl_np);
bevt_13_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_14_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_13_tmpvar_phold);
} /* Line: 327 */
 else  /* Line: 328 */ {
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevl_vname);
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(5, bels_18));
bevt_16_tmpvar_phold = bevl_vname.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_17_tmpvar_phold);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 332 */ {
bevp_held = bevl_v;
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevl_cl.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_20_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_21_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_21_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 337 */
 else  /* Line: 338 */ {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_v.bemd_1(1465928304, BEL_4_Base.bevn_isDeclaredSet_1, bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_23_tmpvar_phold);
bevp_held = bevl_v;
bevt_24_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_24_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_25_tmpvar_phold = bevl_cl.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_25_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 343 */
} /* Line: 332 */
} /* Line: 326 */
} /* Line: 321 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_anchorGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_node = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevl_node = this;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 352 */ {
while (true)
 /* Line: 353 */ {
bevt_2_tmpvar_phold = bevp_constants.bem_anchorTypesGet_0();
bevt_3_tmpvar_phold = bevl_node.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_has_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 354 */ {
return bevl_node;
} /* Line: 355 */
 else  /* Line: 356 */ {
bevl_node = bevl_node.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
if (bevl_node == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 358 */ {
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(18, bels_19));
bevt_5_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_6_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 359 */
} /* Line: 358 */
} /* Line: 354 */
} /* Line: 353 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_classGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 368 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 368 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 368 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 368 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 368 */
 else  /* Line: 368 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 368 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 369 */
 else  /* Line: 368 */ {
break;
} /* Line: 368 */
} /* Line: 368 */
return bevl_targ;
} /*method end*/
public BEC_6_6_SystemObject bem_scopeGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 376 */ {
if (bevl_targ == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 376 */ {
bevt_5_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 376 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 376 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 376 */
 else  /* Line: 376 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 376 */ {
bevt_8_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_9_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 376 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 376 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 376 */
 else  /* Line: 376 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 376 */ {
bevt_11_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 376 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 376 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 376 */
 else  /* Line: 376 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 376 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 377 */
 else  /* Line: 376 */ {
break;
} /* Line: 376 */
} /* Line: 376 */
return bevl_targ;
} /*method end*/
public BEC_6_6_SystemObject bem_replaceWith_1(BEC_5_4_BuildNode beva_other) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 383 */ {
return null;
} /* Line: 384 */
beva_other.bem_containerSet_1(bevp_container);
bevp_heldBy.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, beva_other);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_deleteAndAppend_1(BEC_5_4_BuildNode beva_other) throws Throwable {
beva_other.bem_delete_0();
this.bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_takeContents_1(BEC_5_4_BuildNode beva_other) throws Throwable {
BEC_6_6_SystemObject bevl_it = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
 /* Line: 397 */ {
bevt_0_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 397 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, this);
} /* Line: 399 */
 else  /* Line: 397 */ {
break;
} /* Line: 397 */
} /* Line: 397 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_resolveNp_0() throws Throwable {
BEC_5_8_BuildNamePath bevl_np = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_0_tmpvar_phold = bevp_typename.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 405 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 408 */
} /* Line: 407 */
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_3_tmpvar_phold = bevp_typename.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 411 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 413 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 414 */
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevl_np == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 417 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 418 */
bevt_8_tmpvar_phold = bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_held.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_7_tmpvar_phold);
} /* Line: 420 */
bevt_10_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_9_tmpvar_phold = bevp_typename.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 422 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 425 */
} /* Line: 424 */
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_callIsSafe_1(BEC_5_4_BuildNode beva_call) throws Throwable {
BEC_9_3_ContainerSet bevl_alwaysOkCalls = null;
BEC_9_3_ContainerSet bevl_okClasses = null;
BEC_9_3_ContainerSet bevl_okCalls = null;
BEC_9_3_ContainerSet bevl_okClasses2 = null;
BEC_9_3_ContainerSet bevl_okCalls2 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_54_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 435 */ {
bevt_6_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = (new BEC_4_6_TextString(10, bels_20));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_7_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 435 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 435 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 435 */
 else  /* Line: 435 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 435 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 436 */
synchronized (BEC_5_4_BuildNode.class) {
if (bevo_4 == null) {
bevo_4 = (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_alwaysOkCalls = bevo_4;
synchronized (BEC_5_4_BuildNode.class) {
if (bevo_5 == null) {
bevo_5 = (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses = bevo_5;
synchronized (BEC_5_4_BuildNode.class) {
if (bevo_6 == null) {
bevo_6 = (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls = bevo_6;
synchronized (BEC_5_4_BuildNode.class) {
if (bevo_7 == null) {
bevo_7 = (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses2 = bevo_7;
synchronized (BEC_5_4_BuildNode.class) {
if (bevo_8 == null) {
bevo_8 = (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls2 = bevo_8;
bevt_10_tmpvar_phold = bevl_okClasses.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevo_9;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_equals_1(bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 444 */ {
bevt_12_tmpvar_phold = (new BEC_4_6_TextString(6, bels_21));
bevl_alwaysOkCalls.bem_put_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = (new BEC_4_6_TextString(11, bels_22));
bevl_okClasses.bem_put_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(8, bels_23));
bevl_okClasses.bem_put_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = (new BEC_4_6_TextString(5, bels_24));
bevl_okCalls.bem_put_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (new BEC_4_6_TextString(10, bels_25));
bevl_okCalls.bem_put_1(bevt_16_tmpvar_phold);
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(7, bels_26));
bevl_okCalls.bem_put_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(6, bels_27));
bevl_okCalls.bem_put_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = (new BEC_4_6_TextString(10, bels_28));
bevl_okCalls.bem_put_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(10, bels_29));
bevl_okCalls.bem_put_1(bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(8, bels_30));
bevl_okCalls.bem_put_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (new BEC_4_6_TextString(7, bels_31));
bevl_okCalls.bem_put_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = (new BEC_4_6_TextString(9, bels_32));
bevl_okCalls.bem_put_1(bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (new BEC_4_6_TextString(9, bels_33));
bevl_okCalls.bem_put_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(8, bels_34));
bevl_okCalls.bem_put_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (new BEC_4_6_TextString(8, bels_35));
bevl_okCalls.bem_put_1(bevt_26_tmpvar_phold);
bevt_27_tmpvar_phold = (new BEC_4_6_TextString(11, bels_36));
bevl_okCalls.bem_put_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (new BEC_4_6_TextString(15, bels_37));
bevl_okCalls.bem_put_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = (new BEC_4_6_TextString(14, bels_38));
bevl_okCalls.bem_put_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (new BEC_4_6_TextString(6, bels_39));
bevl_okCalls.bem_put_1(bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = (new BEC_4_6_TextString(6, bels_40));
bevl_okCalls.bem_put_1(bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (new BEC_4_6_TextString(5, bels_41));
bevl_okCalls.bem_put_1(bevt_32_tmpvar_phold);
bevt_33_tmpvar_phold = (new BEC_4_6_TextString(11, bels_42));
bevl_okCalls.bem_put_1(bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(10, bels_43));
bevl_okCalls.bem_put_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = (new BEC_4_6_TextString(6, bels_44));
bevl_okCalls.bem_put_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (new BEC_4_6_TextString(8, bels_45));
bevl_okCalls.bem_put_1(bevt_36_tmpvar_phold);
bevt_37_tmpvar_phold = (new BEC_4_6_TextString(9, bels_46));
bevl_okCalls.bem_put_1(bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = (new BEC_4_6_TextString(11, bels_47));
bevl_okCalls.bem_put_1(bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = (new BEC_4_6_TextString(9, bels_48));
bevl_okCalls.bem_put_1(bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = (new BEC_4_6_TextString(13, bels_49));
bevl_okClasses2.bem_put_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = (new BEC_4_6_TextString(13, bels_50));
bevl_okClasses2.bem_put_1(bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = (new BEC_4_6_TextString(15, bels_51));
bevl_okClasses2.bem_put_1(bevt_42_tmpvar_phold);
bevt_43_tmpvar_phold = (new BEC_4_6_TextString(15, bels_52));
bevl_okClasses2.bem_put_1(bevt_43_tmpvar_phold);
bevt_44_tmpvar_phold = (new BEC_4_6_TextString(5, bels_53));
bevl_okCalls2.bem_put_1(bevt_44_tmpvar_phold);
bevt_45_tmpvar_phold = (new BEC_4_6_TextString(5, bels_54));
bevl_okCalls2.bem_put_1(bevt_45_tmpvar_phold);
} /* Line: 494 */
bevt_48_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_46_tmpvar_phold = bevl_alwaysOkCalls.bem_has_1(bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 498 */ {
bevt_49_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_49_tmpvar_phold;
} /* Line: 500 */
bevt_54_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 504 */ {
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_55_tmpvar_phold;
} /* Line: 506 */
bevt_61_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_firstGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_56_tmpvar_phold = bevl_okClasses.bem_has_1(bevt_57_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevt_64_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpvar_phold = bevl_okCalls.bem_has_1(bevt_63_tmpvar_phold);
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 515 */ {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_65_tmpvar_phold;
} /* Line: 517 */
 else  /* Line: 518 */ {
} /* Line: 518 */
} /* Line: 515 */
bevt_71_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bem_firstGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_66_tmpvar_phold = bevl_okClasses2.bem_has_1(bevt_67_tmpvar_phold);
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 522 */ {
bevt_74_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_72_tmpvar_phold = bevl_okCalls2.bem_has_1(bevt_73_tmpvar_phold);
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 523 */ {
bevt_75_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_75_tmpvar_phold;
} /* Line: 525 */
 else  /* Line: 526 */ {
} /* Line: 526 */
} /* Line: 523 */
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_76_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isLiteralOnceGet_0() throws Throwable {
BEC_5_4_LogicBool bevl_result = null;
BEC_5_4_BuildNode bevl_c0 = null;
BEC_5_4_BuildNode bevl_c1 = null;
BEC_6_6_SystemObject bevl_kv = null;
BEC_5_4_BuildNode bevl_call = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
bevl_result = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_4_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_3_tmpvar_phold = bevp_typename.bem_notEquals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 547 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 547 */
bevt_7_tmpvar_phold = bevp_held.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(6, bels_55));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 548 */ {
bevl_c0 = (BEC_5_4_BuildNode) bevp_contained.bem_firstGet_0();
bevl_c1 = (BEC_5_4_BuildNode) bevp_contained.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 551 */ {
bevt_11_tmpvar_phold = bevl_c1.bem_typenameGet_0();
bevt_12_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_equals_1(bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 551 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 551 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 551 */
 else  /* Line: 551 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 551 */ {
bevt_14_tmpvar_phold = bevl_c1.bem_heldGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 552 */ {
bevt_17_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(1126433704, BEL_4_Base.bevn_isPropertyGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 552 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 552 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 552 */
 else  /* Line: 552 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 552 */ {
bevl_result = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_19_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(2024716595, BEL_4_Base.bevn_allCallsGet_0);
bevt_0_tmpvar_loop = bevt_18_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 554 */ {
bevt_20_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 554 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_call = (BEC_5_4_BuildNode) bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_21_tmpvar_phold = bevl_call.bem_notEquals_1(this);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 556 */ {
bevt_23_tmpvar_phold = this.bem_callIsSafe_1(bevl_call);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_not_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 557 */ {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_24_tmpvar_phold;
} /* Line: 558 */
} /* Line: 557 */
} /* Line: 556 */
 else  /* Line: 554 */ {
break;
} /* Line: 554 */
} /* Line: 554 */
} /* Line: 554 */
} /* Line: 552 */
} /* Line: 551 */
return bevl_result;
} /*method end*/
public BEC_9_8_ContainerNodeList bem_containedGet_0() throws Throwable {
return bevp_contained;
} /*method end*/
public BEC_6_6_SystemObject bem_containedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_contained = (BEC_9_8_ContainerNodeList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_6_6_SystemObject bem_containerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_container = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_6_6_SystemObject bem_heldSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_held = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_heldByGet_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public BEC_6_6_SystemObject bem_heldBySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_heldBy = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_condvarGet_0() throws Throwable {
return bevp_condvar;
} /*method end*/
public BEC_6_6_SystemObject bem_condvarSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_condvar = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_6_6_SystemObject bem_inFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inFile = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_typeDetailGet_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public BEC_6_6_SystemObject bem_typeDetailSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_typeDetail = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_delayDeleteGet_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public BEC_6_6_SystemObject bem_delayDeleteSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_delayDelete = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_nlcGet_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public BEC_6_6_SystemObject bem_nlcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nlc = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_nlecGet_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public BEC_6_6_SystemObject bem_nlecSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nlec = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_wideStringGet_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public BEC_6_6_SystemObject bem_wideStringSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_wideString = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_build = (BEC_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_6_6_SystemObject bem_constantsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_constants = (BEC_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_typenameGet_0() throws Throwable {
return bevp_typename;
} /*method end*/
public BEC_6_6_SystemObject bem_typenameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_typename = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {32, 33, 34, 35, 37, 38, 39, 40, 45, 45, 46, 46, 47, 48, 52, 52, 52, 52, 52, 0, 0, 0, 53, 53, 55, 56, 57, 57, 57, 57, 0, 0, 0, 58, 59, 61, 65, 66, 67, 67, 67, 67, 0, 0, 0, 68, 69, 71, 75, 75, 76, 78, 79, 79, 80, 82, 82, 86, 86, 87, 89, 90, 90, 91, 93, 93, 97, 97, 101, 101, 105, 105, 109, 109, 110, 110, 112, 112, 112, 116, 116, 0, 116, 116, 116, 0, 0, 117, 117, 119, 119, 119, 119, 123, 123, 0, 123, 123, 123, 0, 0, 0, 123, 123, 123, 123, 0, 0, 124, 124, 126, 126, 126, 126, 126, 130, 134, 134, 135, 137, 138, 139, 143, 143, 144, 146, 146, 146, 147, 151, 151, 152, 154, 155, 159, 159, 160, 162, 163, 167, 171, 171, 172, 179, 181, 182, 184, 188, 189, 189, 189, 189, 189, 189, 190, 190, 190, 190, 190, 190, 190, 190, 191, 191, 191, 191, 0, 0, 0, 192, 192, 192, 192, 192, 192, 192, 192, 192, 192, 192, 192, 192, 192, 194, 194, 195, 195, 195, 195, 195, 195, 196, 196, 198, 202, 203, 203, 203, 203, 203, 203, 204, 204, 205, 205, 205, 205, 207, 207, 208, 208, 208, 208, 210, 210, 211, 211, 211, 211, 213, 217, 218, 219, 219, 220, 221, 223, 227, 228, 229, 230, 230, 231, 230, 233, 237, 238, 238, 238, 238, 238, 0, 0, 0, 239, 241, 245, 246, 246, 246, 247, 247, 247, 249, 249, 249, 250, 250, 250, 250, 250, 251, 252, 252, 253, 254, 254, 254, 254, 255, 259, 260, 260, 261, 261, 261, 262, 262, 264, 266, 266, 270, 271, 271, 272, 272, 273, 274, 274, 274, 275, 275, 275, 277, 277, 277, 0, 0, 0, 278, 279, 279, 281, 282, 282, 282, 283, 283, 283, 285, 285, 285, 286, 286, 291, 292, 292, 293, 293, 294, 295, 296, 296, 296, 297, 297, 297, 299, 299, 300, 300, 300, 301, 301, 301, 303, 303, 303, 304, 304, 305, 305, 305, 306, 306, 306, 315, 316, 316, 317, 317, 318, 318, 318, 320, 320, 321, 321, 322, 322, 322, 324, 325, 325, 325, 326, 326, 327, 327, 327, 327, 330, 331, 332, 332, 333, 334, 334, 335, 335, 336, 336, 337, 337, 339, 339, 340, 340, 341, 342, 342, 343, 343, 351, 352, 354, 354, 354, 355, 357, 358, 358, 359, 359, 359, 367, 368, 368, 368, 368, 368, 0, 0, 0, 369, 371, 375, 376, 376, 376, 376, 376, 0, 0, 0, 376, 376, 376, 0, 0, 0, 376, 376, 376, 0, 0, 0, 377, 379, 383, 383, 384, 386, 387, 391, 392, 396, 397, 397, 398, 399, 405, 405, 406, 407, 407, 408, 411, 411, 412, 413, 413, 414, 416, 417, 417, 418, 420, 420, 420, 422, 422, 423, 424, 424, 425, 435, 435, 435, 435, 435, 435, 435, 0, 0, 0, 436, 436, 439, 440, 441, 442, 443, 444, 444, 444, 451, 451, 454, 454, 455, 455, 457, 457, 458, 458, 459, 459, 460, 460, 461, 461, 462, 462, 463, 463, 464, 464, 465, 465, 466, 466, 467, 467, 468, 468, 469, 469, 470, 470, 471, 471, 472, 472, 473, 473, 474, 474, 475, 475, 476, 476, 477, 477, 478, 478, 479, 479, 480, 480, 481, 481, 485, 485, 486, 486, 487, 487, 488, 488, 493, 493, 494, 494, 498, 498, 498, 500, 500, 504, 504, 504, 504, 504, 506, 506, 514, 514, 514, 514, 514, 514, 515, 515, 515, 517, 517, 522, 522, 522, 522, 522, 522, 523, 523, 523, 525, 525, 531, 531, 542, 547, 547, 547, 547, 548, 548, 548, 549, 550, 551, 551, 551, 551, 551, 0, 0, 0, 552, 552, 552, 552, 552, 0, 0, 0, 553, 554, 554, 554, 0, 554, 554, 555, 556, 557, 557, 558, 558, 569, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {91, 92, 93, 94, 95, 96, 97, 98, 104, 105, 106, 107, 108, 109, 123, 128, 129, 130, 135, 136, 139, 143, 146, 147, 149, 150, 153, 158, 159, 164, 165, 168, 172, 175, 176, 182, 190, 191, 194, 199, 200, 205, 206, 209, 213, 216, 217, 223, 230, 235, 236, 238, 239, 244, 245, 247, 248, 255, 260, 261, 263, 264, 269, 270, 272, 273, 277, 278, 282, 283, 287, 288, 295, 300, 301, 302, 304, 305, 310, 321, 326, 327, 330, 331, 336, 337, 340, 344, 345, 347, 348, 349, 354, 370, 375, 376, 379, 380, 385, 386, 389, 393, 396, 397, 398, 403, 404, 407, 411, 412, 414, 415, 416, 417, 422, 425, 430, 435, 436, 438, 439, 440, 447, 452, 453, 455, 456, 457, 458, 463, 468, 469, 471, 472, 477, 482, 483, 485, 486, 490, 495, 500, 501, 509, 513, 514, 516, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 576, 577, 582, 583, 586, 590, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 608, 613, 614, 615, 616, 617, 618, 619, 620, 621, 623, 645, 646, 647, 648, 649, 650, 651, 652, 657, 658, 659, 660, 661, 663, 668, 669, 670, 671, 672, 674, 679, 680, 681, 682, 683, 685, 691, 692, 695, 700, 701, 702, 708, 716, 717, 718, 719, 722, 724, 725, 731, 740, 743, 748, 749, 750, 751, 753, 756, 760, 763, 769, 790, 791, 792, 793, 795, 796, 797, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 825, 828, 833, 834, 835, 836, 838, 839, 841, 847, 848, 875, 876, 877, 879, 880, 881, 882, 883, 884, 886, 887, 888, 890, 892, 893, 895, 898, 902, 905, 906, 907, 909, 910, 911, 912, 914, 915, 916, 918, 919, 920, 921, 922, 953, 954, 955, 957, 958, 959, 960, 961, 962, 963, 965, 966, 967, 970, 971, 972, 973, 974, 976, 977, 978, 981, 982, 983, 984, 985, 986, 987, 988, 990, 991, 992, 1032, 1033, 1034, 1035, 1036, 1038, 1039, 1040, 1043, 1044, 1045, 1046, 1048, 1049, 1050, 1053, 1054, 1055, 1056, 1057, 1062, 1063, 1064, 1065, 1066, 1069, 1070, 1071, 1072, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1093, 1109, 1110, 1114, 1115, 1116, 1118, 1121, 1122, 1127, 1128, 1129, 1130, 1144, 1147, 1152, 1153, 1154, 1155, 1157, 1160, 1164, 1167, 1173, 1190, 1193, 1198, 1199, 1200, 1201, 1203, 1206, 1210, 1213, 1214, 1215, 1217, 1220, 1224, 1227, 1228, 1229, 1231, 1234, 1238, 1241, 1247, 1251, 1256, 1257, 1259, 1260, 1264, 1265, 1272, 1273, 1276, 1278, 1279, 1301, 1302, 1304, 1305, 1310, 1311, 1314, 1315, 1317, 1318, 1323, 1324, 1326, 1327, 1332, 1333, 1335, 1336, 1337, 1339, 1340, 1342, 1343, 1348, 1349, 1437, 1438, 1440, 1441, 1442, 1443, 1444, 1446, 1449, 1453, 1456, 1457, 1459, 1465, 1471, 1477, 1483, 1489, 1490, 1491, 1493, 1494, 1495, 1496, 1497, 1498, 1499, 1500, 1501, 1502, 1503, 1504, 1505, 1506, 1507, 1508, 1509, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1518, 1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1562, 1563, 1564, 1566, 1567, 1569, 1570, 1571, 1572, 1573, 1575, 1576, 1578, 1579, 1580, 1581, 1582, 1583, 1585, 1586, 1587, 1589, 1590, 1595, 1596, 1597, 1598, 1599, 1600, 1602, 1603, 1604, 1606, 1607, 1612, 1613, 1646, 1647, 1648, 1650, 1651, 1653, 1654, 1655, 1657, 1658, 1659, 1664, 1665, 1666, 1667, 1669, 1672, 1676, 1679, 1680, 1682, 1683, 1684, 1686, 1689, 1693, 1696, 1697, 1698, 1699, 1699, 1702, 1704, 1705, 1706, 1708, 1709, 1711, 1712, 1723, 1726, 1729, 1733, 1736, 1740, 1743, 1747, 1750, 1754, 1757, 1761, 1764, 1768, 1771, 1775, 1778, 1782, 1785, 1789, 1792, 1796, 1799, 1803, 1806, 1810, 1813, 1817, 1820, 1824, 1827, 1831, 1834};
/* BEGIN LINEINFO 
assign 1 32 91
new 0 32 91
assign 1 33 92
new 0 33 92
assign 1 34 93
new 0 34 93
assign 1 35 94
new 0 35 94
assign 1 37 95
assign 1 38 96
constantsGet 0 38 96
assign 1 39 97
ntypesGet 0 39 97
assign 1 40 98
TOKENGet 0 40 98
assign 1 45 104
nlcGet 0 45 104
assign 1 45 105
copy 0 45 105
assign 1 46 106
nlecGet 0 46 106
assign 1 46 107
copy 0 46 107
assign 1 47 108
inClassNpGet 0 47 108
assign 1 48 109
inFileGet 0 48 109
assign 1 52 123
def 1 52 128
assign 1 52 129
firstGet 0 52 129
assign 1 52 130
def 1 52 135
assign 1 0 136
assign 1 0 139
assign 1 0 143
assign 1 53 146
firstGet 0 53 146
return 1 53 147
assign 1 55 149
nextPeerGet 0 55 149
assign 1 56 150
assign 1 57 153
undef 1 57 158
assign 1 57 159
def 1 57 164
assign 1 0 165
assign 1 0 168
assign 1 0 172
assign 1 58 175
nextPeerGet 0 58 175
assign 1 59 176
containerGet 0 59 176
return 1 61 182
assign 1 65 190
nextPeerGet 0 65 190
assign 1 66 191
assign 1 67 194
undef 1 67 199
assign 1 67 200
def 1 67 205
assign 1 0 206
assign 1 0 209
assign 1 0 213
assign 1 68 216
nextPeerGet 0 68 216
assign 1 69 217
containerGet 0 69 217
return 1 71 223
assign 1 75 230
undef 1 75 235
return 1 76 236
assign 1 78 238
nextGet 0 78 238
assign 1 79 239
undef 1 79 244
return 1 80 245
assign 1 82 247
heldGet 0 82 247
return 1 82 248
assign 1 86 255
undef 1 86 260
return 1 87 261
assign 1 89 263
priorGet 0 89 263
assign 1 90 264
undef 1 90 269
return 1 91 270
assign 1 93 272
heldGet 0 93 272
return 1 93 273
assign 1 97 277
firstGet 0 97 277
return 1 97 278
assign 1 101 282
secondGet 0 101 282
return 1 101 283
assign 1 105 287
thirdGet 0 105 287
return 1 105 288
assign 1 109 295
undef 1 109 300
assign 1 110 301
new 0 110 301
return 1 110 302
assign 1 112 304
priorGet 0 112 304
assign 1 112 305
undef 1 112 310
return 1 112 310
assign 1 116 321
undef 1 116 326
assign 1 0 327
assign 1 116 330
priorGet 0 116 330
assign 1 116 331
undef 1 116 336
assign 1 0 337
assign 1 0 340
assign 1 117 344
new 0 117 344
return 1 117 345
assign 1 119 347
priorGet 0 119 347
assign 1 119 348
priorGet 0 119 348
assign 1 119 349
undef 1 119 354
return 1 119 354
assign 1 123 370
undef 1 123 375
assign 1 0 376
assign 1 123 379
priorGet 0 123 379
assign 1 123 380
undef 1 123 385
assign 1 0 386
assign 1 0 389
assign 1 0 393
assign 1 123 396
priorGet 0 123 396
assign 1 123 397
priorGet 0 123 397
assign 1 123 398
undef 1 123 403
assign 1 0 404
assign 1 0 407
assign 1 124 411
new 0 124 411
return 1 124 412
assign 1 126 414
priorGet 0 126 414
assign 1 126 415
priorGet 0 126 415
assign 1 126 416
priorGet 0 126 416
assign 1 126 417
undef 1 126 422
return 1 126 422
assign 1 130 425
new 0 130 425
assign 1 134 430
undef 1 134 435
return 1 135 436
delete 0 137 438
assign 1 138 439
assign 1 139 440
assign 1 143 447
undef 1 143 452
return 1 144 453
assign 1 146 455
mylistGet 0 146 455
assign 1 146 456
newNode 1 146 456
insertBefore 1 146 457
containerSet 1 147 458
assign 1 151 463
undef 1 151 468
initContained 0 152 469
prepend 1 154 471
containerSet 1 155 472
assign 1 159 477
undef 1 159 482
initContained 0 160 483
addValue 1 162 485
containerSet 1 163 486
assign 1 167 490
new 0 167 490
assign 1 171 495
undef 1 171 500
assign 1 172 501
new 0 172 501
assign 1 179 509
toStringCompact 0 179 509
print 0 181 513
throw 1 182 514
return 1 184 516
assign 1 188 556
prefixGet 0 188 556
assign 1 189 557
new 0 189 557
assign 1 189 558
add 1 189 558
assign 1 189 559
toString 0 189 559
assign 1 189 560
add 1 189 560
assign 1 189 561
new 0 189 561
assign 1 189 562
add 1 189 562
assign 1 190 563
new 0 190 563
assign 1 190 564
newlineGet 0 190 564
assign 1 190 565
add 1 190 565
assign 1 190 566
add 1 190 566
assign 1 190 567
new 0 190 567
assign 1 190 568
add 1 190 568
assign 1 190 569
toString 0 190 569
assign 1 190 570
add 1 190 570
assign 1 191 571
def 1 191 576
assign 1 191 577
def 1 191 582
assign 1 0 583
assign 1 0 586
assign 1 0 590
assign 1 192 593
new 0 192 593
assign 1 192 594
newlineGet 0 192 594
assign 1 192 595
add 1 192 595
assign 1 192 596
add 1 192 596
assign 1 192 597
new 0 192 597
assign 1 192 598
add 1 192 598
assign 1 192 599
toString 0 192 599
assign 1 192 600
add 1 192 600
assign 1 192 601
new 0 192 601
assign 1 192 602
add 1 192 602
assign 1 192 603
add 1 192 603
assign 1 192 604
new 0 192 604
assign 1 192 605
newlineGet 0 192 605
assign 1 192 606
add 1 192 606
assign 1 194 608
def 1 194 613
assign 1 195 614
new 0 195 614
assign 1 195 615
newlineGet 0 195 615
assign 1 195 616
add 1 195 616
assign 1 195 617
add 1 195 617
assign 1 195 618
new 0 195 618
assign 1 195 619
add 1 195 619
assign 1 196 620
toString 0 196 620
assign 1 196 621
add 1 196 621
return 1 198 623
assign 1 202 645
prefixGet 0 202 645
assign 1 203 646
new 0 203 646
assign 1 203 647
add 1 203 647
assign 1 203 648
toString 0 203 648
assign 1 203 649
add 1 203 649
assign 1 203 650
new 0 203 650
assign 1 203 651
add 1 203 651
assign 1 204 652
def 1 204 657
assign 1 205 658
new 0 205 658
assign 1 205 659
add 1 205 659
assign 1 205 660
toString 0 205 660
assign 1 205 661
add 1 205 661
assign 1 207 663
def 1 207 668
assign 1 208 669
new 0 208 669
assign 1 208 670
add 1 208 670
assign 1 208 671
toString 0 208 671
assign 1 208 672
add 1 208 672
assign 1 210 674
def 1 210 679
assign 1 211 680
new 0 211 680
assign 1 211 681
add 1 211 681
assign 1 211 682
toString 0 211 682
assign 1 211 683
add 1 211 683
return 1 213 685
assign 1 217 691
new 0 217 691
assign 1 218 692
assign 1 219 695
def 1 219 700
assign 1 220 701
increment 0 220 701
assign 1 221 702
containerGet 0 221 702
return 1 223 708
assign 1 227 716
depthGet 0 227 716
assign 1 228 717
new 0 228 717
assign 1 229 718
new 0 229 718
assign 1 230 719
new 0 230 719
assign 1 230 722
lesser 1 230 722
assign 1 231 724
add 1 231 724
assign 1 230 725
increment 0 230 725
return 1 233 731
assign 1 237 740
assign 1 238 743
def 1 238 748
assign 1 238 749
typenameGet 0 238 749
assign 1 238 750
TRANSUNITGet 0 238 750
assign 1 238 751
notEquals 1 238 751
assign 1 0 753
assign 1 0 756
assign 1 0 760
assign 1 239 763
containerGet 0 239 763
return 1 241 769
assign 1 245 790
scopeGet 0 245 790
assign 1 246 791
typenameGet 0 246 791
assign 1 246 792
METHODGet 0 246 792
assign 1 246 793
notEquals 1 246 793
assign 1 247 795
new 0 247 795
assign 1 247 796
new 2 247 796
throw 1 247 797
assign 1 249 799
heldGet 0 249 799
assign 1 249 800
tmpCntGet 0 249 800
assign 1 249 801
toString 0 249 801
assign 1 250 802
heldGet 0 250 802
assign 1 250 803
heldGet 0 250 803
assign 1 250 804
tmpCntGet 0 250 804
assign 1 250 805
increment 0 250 805
tmpCntSet 1 250 806
assign 1 251 807
new 0 251 807
assign 1 252 808
new 0 252 808
isTmpVarSet 1 252 809
suffixSet 1 253 810
assign 1 254 811
new 0 254 811
assign 1 254 812
add 1 254 812
assign 1 254 813
add 1 254 813
nameSet 1 254 814
return 1 255 815
assign 1 259 825
assign 1 260 828
def 1 260 833
assign 1 261 834
typenameGet 0 261 834
assign 1 261 835
PROPERTIESGet 0 261 835
assign 1 261 836
equals 1 261 836
assign 1 262 838
new 0 262 838
return 1 262 839
assign 1 264 841
containerGet 0 264 841
assign 1 266 847
new 0 266 847
return 1 266 848
assign 1 270 875
assign 1 271 876
isAddedGet 0 271 876
assign 1 271 877
not 0 271 877
assign 1 272 879
new 0 272 879
isAddedSet 1 272 880
assign 1 273 881
scopeGet 0 273 881
assign 1 274 882
typenameGet 0 274 882
assign 1 274 883
CLASSGet 0 274 883
assign 1 274 884
equals 1 274 884
assign 1 275 886
new 0 275 886
assign 1 275 887
new 2 275 887
throw 1 275 888
assign 1 277 890
inPropertiesGet 0 277 890
assign 1 277 892
isTmpVarGet 0 277 892
assign 1 277 893
not 0 277 893
assign 1 0 895
assign 1 0 898
assign 1 0 902
assign 1 278 905
classGet 0 278 905
assign 1 279 906
new 0 279 906
isPropertySet 1 279 907
assign 1 281 909
heldGet 0 281 909
assign 1 282 910
varMapGet 0 282 910
assign 1 282 911
nameGet 0 282 911
assign 1 282 912
has 1 282 912
assign 1 283 914
new 0 283 914
assign 1 283 915
new 2 283 915
throw 1 283 916
assign 1 285 918
varMapGet 0 285 918
assign 1 285 919
nameGet 0 285 919
put 2 285 920
assign 1 286 921
orderedVarsGet 0 286 921
addValue 1 286 922
assign 1 291 953
assign 1 292 954
isAddedGet 0 292 954
assign 1 292 955
not 0 292 955
assign 1 293 957
new 0 293 957
isAddedSet 1 293 958
assign 1 294 959
scopeGet 0 294 959
assign 1 295 960
heldGet 0 295 960
assign 1 296 961
varMapGet 0 296 961
assign 1 296 962
nameGet 0 296 962
assign 1 296 963
has 1 296 963
assign 1 297 965
varMapGet 0 297 965
assign 1 297 966
nameGet 0 297 966
assign 1 297 967
get 1 297 967
assign 1 299 970
classGet 0 299 970
assign 1 299 971
heldGet 0 299 971
assign 1 300 972
varMapGet 0 300 972
assign 1 300 973
nameGet 0 300 973
assign 1 300 974
has 1 300 974
assign 1 301 976
varMapGet 0 301 976
assign 1 301 977
nameGet 0 301 977
assign 1 301 978
get 1 301 978
assign 1 303 981
varMapGet 0 303 981
assign 1 303 982
nameGet 0 303 982
put 2 303 983
assign 1 304 984
orderedVarsGet 0 304 984
addValue 1 304 985
assign 1 305 986
typenameGet 0 305 986
assign 1 305 987
CLASSGet 0 305 987
assign 1 305 988
equals 1 305 988
assign 1 306 990
new 0 306 990
assign 1 306 991
new 2 306 991
throw 1 306 992
assign 1 315 1032
assign 1 316 1033
scopeGet 0 316 1033
assign 1 316 1034
heldGet 0 316 1034
assign 1 317 1035
varMapGet 0 317 1035
assign 1 317 1036
has 1 317 1036
assign 1 318 1038
varMapGet 0 318 1038
assign 1 318 1039
get 1 318 1039
assign 1 318 1040
heldGet 0 318 1040
assign 1 320 1043
classGet 0 320 1043
assign 1 320 1044
heldGet 0 320 1044
assign 1 321 1045
varMapGet 0 321 1045
assign 1 321 1046
has 1 321 1046
assign 1 322 1048
varMapGet 0 322 1048
assign 1 322 1049
get 1 322 1049
assign 1 322 1050
heldGet 0 322 1050
assign 1 324 1053
transUnitGet 0 324 1053
assign 1 325 1054
heldGet 0 325 1054
assign 1 325 1055
aliasedGet 0 325 1055
assign 1 325 1056
get 1 325 1056
assign 1 326 1057
def 1 326 1062
assign 1 327 1063
new 0 327 1063
assign 1 327 1064
add 1 327 1064
assign 1 327 1065
new 2 327 1065
throw 1 327 1066
assign 1 330 1069
new 0 330 1069
nameSet 1 331 1070
assign 1 332 1071
new 0 332 1071
assign 1 332 1072
equals 1 332 1072
assign 1 333 1074
assign 1 334 1075
new 0 334 1075
isTypedSet 1 334 1076
assign 1 335 1077
extendsGet 0 335 1077
namepathSet 1 335 1078
assign 1 336 1079
varMapGet 0 336 1079
put 2 336 1080
assign 1 337 1081
orderedVarsGet 0 337 1081
addValue 1 337 1082
assign 1 339 1085
new 0 339 1085
isDeclaredSet 1 339 1086
assign 1 340 1087
new 0 340 1087
isPropertySet 1 340 1088
assign 1 341 1089
assign 1 342 1090
varMapGet 0 342 1090
put 2 342 1091
assign 1 343 1092
orderedVarsGet 0 343 1092
addValue 1 343 1093
assign 1 351 1109
assign 1 352 1110
new 0 352 1110
assign 1 354 1114
anchorTypesGet 0 354 1114
assign 1 354 1115
typenameGet 0 354 1115
assign 1 354 1116
has 1 354 1116
return 1 355 1118
assign 1 357 1121
containerGet 0 357 1121
assign 1 358 1122
undef 1 358 1127
assign 1 359 1128
new 0 359 1128
assign 1 359 1129
new 2 359 1129
throw 1 359 1130
assign 1 367 1144
assign 1 368 1147
def 1 368 1152
assign 1 368 1153
typenameGet 0 368 1153
assign 1 368 1154
CLASSGet 0 368 1154
assign 1 368 1155
notEquals 1 368 1155
assign 1 0 1157
assign 1 0 1160
assign 1 0 1164
assign 1 369 1167
containerGet 0 369 1167
return 1 371 1173
assign 1 375 1190
assign 1 376 1193
def 1 376 1198
assign 1 376 1199
typenameGet 0 376 1199
assign 1 376 1200
CLASSGet 0 376 1200
assign 1 376 1201
notEquals 1 376 1201
assign 1 0 1203
assign 1 0 1206
assign 1 0 1210
assign 1 376 1213
typenameGet 0 376 1213
assign 1 376 1214
METHODGet 0 376 1214
assign 1 376 1215
notEquals 1 376 1215
assign 1 0 1217
assign 1 0 1220
assign 1 0 1224
assign 1 376 1227
typenameGet 0 376 1227
assign 1 376 1228
TRANSUNITGet 0 376 1228
assign 1 376 1229
notEquals 1 376 1229
assign 1 0 1231
assign 1 0 1234
assign 1 0 1238
assign 1 377 1241
containerGet 0 377 1241
return 1 379 1247
assign 1 383 1251
undef 1 383 1256
return 1 384 1257
containerSet 1 386 1259
heldSet 1 387 1260
delete 0 391 1264
addValue 1 392 1265
assign 1 396 1272
containedGet 0 396 1272
assign 1 397 1273
iteratorGet 0 397 1273
assign 1 397 1276
hasNextGet 0 397 1276
assign 1 398 1278
nextGet 0 398 1278
containerSet 1 399 1279
assign 1 405 1301
NAMEPATHGet 0 405 1301
assign 1 405 1302
equals 1 405 1302
assign 1 406 1304
assign 1 407 1305
def 1 407 1310
resolve 1 408 1311
assign 1 411 1314
CLASSGet 0 411 1314
assign 1 411 1315
equals 1 411 1315
assign 1 412 1317
namepathGet 0 412 1317
assign 1 413 1318
def 1 413 1323
resolve 1 414 1324
assign 1 416 1326
extendsGet 0 416 1326
assign 1 417 1327
def 1 417 1332
resolve 1 418 1333
assign 1 420 1335
namepathGet 0 420 1335
assign 1 420 1336
toString 0 420 1336
nameSet 1 420 1337
assign 1 422 1339
VARGet 0 422 1339
assign 1 422 1340
equals 1 422 1340
assign 1 423 1342
namepathGet 0 423 1342
assign 1 424 1343
def 1 424 1348
resolve 1 425 1349
assign 1 435 1437
heldGet 0 435 1437
assign 1 435 1438
isConstructGet 0 435 1438
assign 1 435 1440
heldGet 0 435 1440
assign 1 435 1441
newNpGet 0 435 1441
assign 1 435 1442
toString 0 435 1442
assign 1 435 1443
new 0 435 1443
assign 1 435 1444
equals 1 435 1444
assign 1 0 1446
assign 1 0 1449
assign 1 0 1453
assign 1 436 1456
new 0 436 1456
return 1 436 1457
assign 1 439 1459
new 0 439 1459
assign 1 440 1465
new 0 440 1465
assign 1 441 1471
new 0 441 1471
assign 1 442 1477
new 0 442 1477
assign 1 443 1483
new 0 443 1483
assign 1 444 1489
sizeGet 0 444 1489
assign 1 444 1490
new 0 444 1490
assign 1 444 1491
equals 1 444 1491
assign 1 451 1493
new 0 451 1493
put 1 451 1494
assign 1 454 1495
new 0 454 1495
put 1 454 1496
assign 1 455 1497
new 0 455 1497
put 1 455 1498
assign 1 457 1499
new 0 457 1499
put 1 457 1500
assign 1 458 1501
new 0 458 1501
put 1 458 1502
assign 1 459 1503
new 0 459 1503
put 1 459 1504
assign 1 460 1505
new 0 460 1505
put 1 460 1506
assign 1 461 1507
new 0 461 1507
put 1 461 1508
assign 1 462 1509
new 0 462 1509
put 1 462 1510
assign 1 463 1511
new 0 463 1511
put 1 463 1512
assign 1 464 1513
new 0 464 1513
put 1 464 1514
assign 1 465 1515
new 0 465 1515
put 1 465 1516
assign 1 466 1517
new 0 466 1517
put 1 466 1518
assign 1 467 1519
new 0 467 1519
put 1 467 1520
assign 1 468 1521
new 0 468 1521
put 1 468 1522
assign 1 469 1523
new 0 469 1523
put 1 469 1524
assign 1 470 1525
new 0 470 1525
put 1 470 1526
assign 1 471 1527
new 0 471 1527
put 1 471 1528
assign 1 472 1529
new 0 472 1529
put 1 472 1530
assign 1 473 1531
new 0 473 1531
put 1 473 1532
assign 1 474 1533
new 0 474 1533
put 1 474 1534
assign 1 475 1535
new 0 475 1535
put 1 475 1536
assign 1 476 1537
new 0 476 1537
put 1 476 1538
assign 1 477 1539
new 0 477 1539
put 1 477 1540
assign 1 478 1541
new 0 478 1541
put 1 478 1542
assign 1 479 1543
new 0 479 1543
put 1 479 1544
assign 1 480 1545
new 0 480 1545
put 1 480 1546
assign 1 481 1547
new 0 481 1547
put 1 481 1548
assign 1 485 1549
new 0 485 1549
put 1 485 1550
assign 1 486 1551
new 0 486 1551
put 1 486 1552
assign 1 487 1553
new 0 487 1553
put 1 487 1554
assign 1 488 1555
new 0 488 1555
put 1 488 1556
assign 1 493 1557
new 0 493 1557
put 1 493 1558
assign 1 494 1559
new 0 494 1559
put 1 494 1560
assign 1 498 1562
heldGet 0 498 1562
assign 1 498 1563
nameGet 0 498 1563
assign 1 498 1564
has 1 498 1564
assign 1 500 1566
new 0 500 1566
return 1 500 1567
assign 1 504 1569
containedGet 0 504 1569
assign 1 504 1570
firstGet 0 504 1570
assign 1 504 1571
heldGet 0 504 1571
assign 1 504 1572
isTypedGet 0 504 1572
assign 1 504 1573
not 0 504 1573
assign 1 506 1575
new 0 506 1575
return 1 506 1576
assign 1 514 1578
containedGet 0 514 1578
assign 1 514 1579
firstGet 0 514 1579
assign 1 514 1580
heldGet 0 514 1580
assign 1 514 1581
namepathGet 0 514 1581
assign 1 514 1582
toString 0 514 1582
assign 1 514 1583
has 1 514 1583
assign 1 515 1585
heldGet 0 515 1585
assign 1 515 1586
nameGet 0 515 1586
assign 1 515 1587
has 1 515 1587
assign 1 517 1589
new 0 517 1589
return 1 517 1590
assign 1 522 1595
containedGet 0 522 1595
assign 1 522 1596
firstGet 0 522 1596
assign 1 522 1597
heldGet 0 522 1597
assign 1 522 1598
namepathGet 0 522 1598
assign 1 522 1599
toString 0 522 1599
assign 1 522 1600
has 1 522 1600
assign 1 523 1602
heldGet 0 523 1602
assign 1 523 1603
nameGet 0 523 1603
assign 1 523 1604
has 1 523 1604
assign 1 525 1606
new 0 525 1606
return 1 525 1607
assign 1 531 1612
new 0 531 1612
return 1 531 1613
assign 1 542 1646
new 0 542 1646
assign 1 547 1647
CALLGet 0 547 1647
assign 1 547 1648
notEquals 1 547 1648
assign 1 547 1650
new 0 547 1650
return 1 547 1651
assign 1 548 1653
orgNameGet 0 548 1653
assign 1 548 1654
new 0 548 1654
assign 1 548 1655
equals 1 548 1655
assign 1 549 1657
firstGet 0 549 1657
assign 1 550 1658
secondGet 0 550 1658
assign 1 551 1659
def 1 551 1664
assign 1 551 1665
typenameGet 0 551 1665
assign 1 551 1666
CALLGet 0 551 1666
assign 1 551 1667
equals 1 551 1667
assign 1 0 1669
assign 1 0 1672
assign 1 0 1676
assign 1 552 1679
heldGet 0 552 1679
assign 1 552 1680
isLiteralGet 0 552 1680
assign 1 552 1682
heldGet 0 552 1682
assign 1 552 1683
isPropertyGet 0 552 1683
assign 1 552 1684
not 0 552 1684
assign 1 0 1686
assign 1 0 1689
assign 1 0 1693
assign 1 553 1696
new 0 553 1696
assign 1 554 1697
heldGet 0 554 1697
assign 1 554 1698
allCallsGet 0 554 1698
assign 1 554 1699
iteratorGet 0 0 1699
assign 1 554 1702
hasNextGet 0 554 1702
assign 1 554 1704
nextGet 0 554 1704
assign 1 555 1705
keyGet 0 555 1705
assign 1 556 1706
notEquals 1 556 1706
assign 1 557 1708
callIsSafe 1 557 1708
assign 1 557 1709
not 0 557 1709
assign 1 558 1711
new 0 558 1711
return 1 558 1712
return 1 569 1723
return 1 0 1726
assign 1 0 1729
return 1 0 1733
assign 1 0 1736
return 1 0 1740
assign 1 0 1743
return 1 0 1747
assign 1 0 1750
return 1 0 1754
assign 1 0 1757
return 1 0 1761
assign 1 0 1764
return 1 0 1768
assign 1 0 1771
return 1 0 1775
assign 1 0 1778
return 1 0 1782
assign 1 0 1785
return 1 0 1789
assign 1 0 1792
return 1 0 1796
assign 1 0 1799
return 1 0 1803
assign 1 0 1806
return 1 0 1810
assign 1 0 1813
return 1 0 1817
assign 1 0 1820
return 1 0 1824
assign 1 0 1827
return 1 0 1831
assign 1 0 1834
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 339997707: return bem_nlecGet_0();
case 1820417453: return bem_create_0();
case 822104518: return bem_inFileGet_0();
case 443668840: return bem_methodNotDefined_0();
case 202810500: return bem_depthGet_0();
case 1595262430: return bem_nlcGet_0();
case 786424307: return bem_tagGet_0();
case 1740134355: return bem_syncAddVariable_0();
case 845792839: return bem_iteratorGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1522157789: return bem_wideStringGet_0();
case 68392679: return bem_delayDeleteGet_0();
case 1973596005: return bem_transUnitGet_0();
case 2110470555: return bem_priorPeerGet_0();
case 1081412016: return bem_many_0();
case 931239762: return bem_heldGet_0();
case 312889617: return bem_classGet_0();
case 1236878826: return bem_nextAscendGet_0();
case 1823343663: return bem_inPropertiesGet_0();
case 1014444004: return bem_typeDetailGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 1167184407: return bem_isSecondGet_0();
case 1193143594: return bem_isThirdGet_0();
case 1692872440: return bem_toStringCompact_0();
case 1437330926: return bem_inClassNpGet_0();
case 516830146: return bem_condvarGet_0();
case 576537281: return bem_delayDelete_0();
case 432255188: return bem_containedGet_0();
case 287040793: return bem_hashGet_0();
case 729571811: return bem_serializeToString_0();
case 1987872129: return bem_isFirstGet_0();
case 183400265: return bem_firstGet_0();
case 1758195374: return bem_addVariable_0();
case 242848115: return bem_secondGet_0();
case 1952633087: return bem_resolveNp_0();
case 1471053772: return bem_initContained_0();
case 1866790687: return bem_isLiteralOnceGet_0();
case 819712668: return bem_delete_0();
case 978128800: return bem_thirdGet_0();
case 1461034369: return bem_reInitContained_0();
case 1354714650: return bem_copy_0();
case 104713553: return bem_new_0();
case 1898686885: return bem_toStringBig_0();
case 1566845998: return bem_anchorGet_0();
case 213728365: return bem_scopeGet_0();
case 1956934267: return bem_heldByGet_0();
case 1388725781: return bem_prefixGet_0();
case 1779180144: return bem_nextDescendGet_0();
case 644675716: return bem_ntypesGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case 2087681086: return bem_typenameGet_0();
case 927274360: return bem_constantsGet_0();
case 1012494862: return bem_once_0();
case 493012039: return bem_buildGet_0();
case 314718434: return bem_print_0();
case 124944494: return bem_nextPeerGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1279784069: return bem_defined_1(bevd_0);
case 57310426: return bem_delayDeleteSet_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 875977779: return bem_takeContents_1((BEC_5_4_BuildNode) bevd_0);
case 443337441: return bem_containedSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case 205397975: return bem_syncVariable_1((BEC_5_5_7_BuildVisitVisitor) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 351079960: return bem_nlecSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1170500300: return bem_replaceWith_1((BEC_5_4_BuildNode) bevd_0);
case 1671186230: return bem_beforeInsert_1((BEC_5_4_BuildNode) bevd_0);
case 1487970429: return bem_copyLoc_1((BEC_5_4_BuildNode) bevd_0);
case 1003361751: return bem_typeDetailSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 2076598833: return bem_typenameSet_1(bevd_0);
case 527912399: return bem_condvarSet_1(bevd_0);
case 1668215656: return bem_deleteAndAppend_1((BEC_5_4_BuildNode) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1968016520: return bem_heldBySet_1(bevd_0);
case 167727545: return bem_callIsSafe_1((BEC_5_4_BuildNode) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1584180177: return bem_nlcSet_1(bevd_0);
case 1007846464: return bem_prepend_1((BEC_5_4_BuildNode) bevd_0);
case 2139839746: return bem_addValue_1((BEC_5_4_BuildNode) bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1511075536: return bem_wideStringSet_1(bevd_0);
case 942322015: return bem_heldSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1545079363: return bem_tmpVar_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_4_BuildNode();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_4_BuildNode.bevs_inst = (BEC_5_4_BuildNode)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_4_BuildNode.bevs_inst;
}
}
