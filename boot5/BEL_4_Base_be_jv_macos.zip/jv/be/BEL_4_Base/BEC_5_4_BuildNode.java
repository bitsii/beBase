package be.BEL_4_Base;
/* File: source/build/Nodes.be */
public class BEC_5_4_BuildNode extends BEC_6_6_SystemObject {
public BEC_5_4_BuildNode() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x3C};
private static byte[] bels_1 = {0x3E};
private static byte[] bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x49,0x6E,0x20,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_5 = {0x20};
private static byte[] bels_6 = {0x20,0x20};
private static byte[] bels_7 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bels_8 = {0x5F,0x74,0x6D,0x70,0x76,0x61,0x72,0x5F};
private static byte[] bels_9 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_10 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bels_11 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bels_12 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_12, 18));
private static byte[] bels_13 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_14 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bels_15 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static BEC_9_3_ContainerSet bevo_1;
private static BEC_9_3_ContainerSet bevo_2;
private static BEC_9_3_ContainerSet bevo_3;
private static BEC_9_3_ContainerSet bevo_4;
private static BEC_9_3_ContainerSet bevo_5;
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(0));
private static byte[] bels_16 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bels_17 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_18 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_19 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bels_20 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bels_21 = {0x70,0x72,0x69,0x6E,0x74,0x5F,0x30};
private static byte[] bels_22 = {0x65,0x63,0x68,0x6F,0x5F,0x30};
private static byte[] bels_23 = {0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x30};
private static byte[] bels_24 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bels_25 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bels_26 = {0x70,0x6F,0x77,0x65,0x72,0x5F,0x31};
private static byte[] bels_27 = {0x63,0x6F,0x6D,0x70,0x61,0x72,0x65,0x5F,0x31};
private static byte[] bels_28 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bels_29 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bels_30 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_31 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_32 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_33 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_34 = {0x66,0x69,0x6E,0x64,0x5F,0x32};
private static byte[] bels_35 = {0x66,0x69,0x6E,0x64,0x5F,0x31};
private static byte[] bels_36 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_37 = {0x69,0x73,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x5F,0x30};
private static byte[] bels_38 = {0x67,0x65,0x74,0x50,0x6F,0x69,0x6E,0x74,0x5F,0x31};
private static byte[] bels_39 = {0x65,0x6E,0x64,0x73,0x5F,0x31};
private static byte[] bels_40 = {0x62,0x65,0x67,0x69,0x6E,0x73,0x5F,0x31};
private static byte[] bels_41 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bels_42 = {0x73,0x75,0x62,0x73,0x74,0x72,0x69,0x6E,0x67,0x5F,0x32};
private static byte[] bels_43 = {0x73,0x69,0x7A,0x65,0x47,0x65,0x74,0x5F,0x30};
private static byte[] bels_44 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] bels_45 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] bels_46 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] bels_47 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] bels_48 = {0x67,0x65,0x74,0x5F,0x31};
private static byte[] bels_49 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_50 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_5_4_BuildNode bevs_inst;
public BEC_9_8_ContainerNodeList bevp_contained;
public BEC_5_4_BuildNode bevp_container;
public BEC_6_6_SystemObject bevp_held;
public BEC_6_6_SystemObject bevp_heldBy;
public BEC_6_6_SystemObject bevp_condvar;
public BEC_5_8_BuildNamePath bevp_inClassNp;
public BEC_4_6_TextString bevp_inFile;
public BEC_6_6_SystemObject bevp_typeDetail;
public BEC_5_4_LogicBool bevp_delayDelete;
public BEC_4_3_MathInt bevp_nlc;
public BEC_4_3_MathInt bevp_nlec;
public BEC_5_4_LogicBool bevp_wideString;
public BEC_5_5_BuildBuild bevp_build;
public BEC_5_9_BuildConstants bevp_constants;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_4_3_MathInt bevp_typename;
public BEC_5_4_BuildNode bem_new_1(BEC_5_5_BuildBuild beva__build) throws Throwable {
bevp_delayDelete = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_nlc = (new BEC_4_3_MathInt(0));
bevp_nlec = (new BEC_4_3_MathInt(0));
bevp_wideString = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_copyLoc_1(BEC_5_4_BuildNode beva_fromNode) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_fromNode.bem_nlcGet_0();
bevp_nlc = (BEC_4_3_MathInt) bevt_0_tmpvar_phold.bem_copy_0();
bevt_1_tmpvar_phold = beva_fromNode.bem_nlecGet_0();
bevp_nlec = (BEC_4_3_MathInt) bevt_1_tmpvar_phold.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_nextDescendGet_0() throws Throwable {
BEC_5_4_BuildNode bevl_ret = null;
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_4_tmpvar_phold = bevp_contained.bem_firstGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 52 */ {
bevt_5_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_5_4_BuildNode) bevt_5_tmpvar_phold;
} /* Line: 53 */
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 57 */ {
if (bevl_ret == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 57 */ {
if (bevl_con == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 57 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 59 */
 else  /* Line: 57 */ {
break;
} /* Line: 57 */
} /* Line: 57 */
return bevl_ret;
} /*method end*/
public BEC_5_4_BuildNode bem_nextAscendGet_0() throws Throwable {
BEC_5_4_BuildNode bevl_ret = null;
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 67 */ {
if (bevl_ret == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 67 */ {
if (bevl_con == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 67 */
 else  /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 67 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 69 */
 else  /* Line: 67 */ {
break;
} /* Line: 67 */
} /* Line: 67 */
return bevl_ret;
} /*method end*/
public BEC_5_4_BuildNode bem_nextPeerGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_hh = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 75 */ {
return null;
} /* Line: 76 */
bevl_hh = bevp_heldBy.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 79 */ {
return (BEC_5_4_BuildNode) bevl_hh;
} /* Line: 80 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public BEC_5_4_BuildNode bem_priorPeerGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_hh = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 86 */ {
return null;
} /* Line: 87 */
bevl_hh = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 90 */ {
return (BEC_5_4_BuildNode) bevl_hh;
} /* Line: 91 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public BEC_5_4_BuildNode bem_firstGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_BuildNode bem_secondGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_secondGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_BuildNode bem_thirdGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_thirdGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isFirstGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 110 */
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isSecondGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 116 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 117 */
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isThirdGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_4_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 123 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 124 */
bevt_12_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_10_tmpvar_phold == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_9_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_delayDelete_0() throws Throwable {
bevp_delayDelete = be.BELS_Base.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 134 */ {
return null;
} /* Line: 135 */
bevp_heldBy.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevp_container = null;
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_beforeInsert_1(BEC_5_4_BuildNode beva_x) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 143 */ {
return null;
} /* Line: 144 */
bevt_2_tmpvar_phold = bevp_heldBy.bemd_0(1849179299, BEL_4_Base.bevn_mylistGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(743891212, BEL_4_Base.bevn_newNode_1, beva_x);
bevp_heldBy.bemd_1(1505376950, BEL_4_Base.bevn_insertBefore_1, bevt_1_tmpvar_phold);
beva_x.bem_containerSet_1(bevp_container);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_prepend_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 151 */ {
this.bem_initContained_0();
} /* Line: 152 */
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addValue_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 159 */ {
this.bem_initContained_0();
} /* Line: 160 */
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_reInitContained_0() throws Throwable {
bevp_contained = (BEC_9_8_ContainerNodeList) (new BEC_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_initContained_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevp_contained = (BEC_9_8_ContainerNodeList) (new BEC_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 172 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_6_6_SystemObject bevl_prefix = null;
BEC_6_6_SystemObject bevl_ret = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_3_tmpvar_phold = (new BEC_4_6_TextString(1, bels_0));
bevt_2_tmpvar_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_typename.bem_toString_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(1, bels_1));
bevl_ret = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_newlineGet_0();
bevt_8_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_11_tmpvar_phold = (new BEC_4_6_TextString(6, bels_2));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_12_tmpvar_phold);
if (bevp_inClassNp == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 180 */ {
if (bevp_inFile == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 180 */
 else  /* Line: 180 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 180 */ {
bevt_22_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_newlineGet_0();
bevt_20_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_23_tmpvar_phold = (new BEC_4_6_TextString(11, bels_3));
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = bevp_inClassNp.bem_toString_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(10, bels_4));
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_25_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_inFile);
bevt_27_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_newlineGet_0();
bevl_ret = bevt_15_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 181 */
if (bevp_held == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 183 */ {
bevt_32_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_newlineGet_0();
bevt_30_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_31_tmpvar_phold);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_33_tmpvar_phold = (new BEC_4_6_TextString(1, bels_5));
bevl_ret = bevt_29_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_34_tmpvar_phold);
} /* Line: 185 */
return (BEC_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_6_6_SystemObject bem_depthGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_d = null;
BEC_6_6_SystemObject bevl_c = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_d = (new BEC_4_3_MathInt(0));
bevl_c = bevp_container;
while (true)
 /* Line: 193 */ {
if (bevl_c == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 193 */ {
bevl_d = bevl_d.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevl_c = bevl_c.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 195 */
 else  /* Line: 193 */ {
break;
} /* Line: 193 */
} /* Line: 193 */
return bevl_d;
} /*method end*/
public BEC_6_6_SystemObject bem_prefixGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_d = null;
BEC_6_6_SystemObject bevl_p = null;
BEC_6_6_SystemObject bevl_q = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_d = this.bem_depthGet_0();
bevl_p = (new BEC_4_6_TextString()).bem_new_0();
bevl_q = (new BEC_4_6_TextString(2, bels_6));
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 204 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_d);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 204 */ {
bevl_p = bevl_p.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_q);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 204 */
 else  /* Line: 204 */ {
break;
} /* Line: 204 */
} /* Line: 204 */
return bevl_p;
} /*method end*/
public BEC_6_6_SystemObject bem_transUnitGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 212 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 212 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 212 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 212 */
 else  /* Line: 212 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 212 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 213 */
 else  /* Line: 212 */ {
break;
} /* Line: 212 */
} /* Line: 212 */
return bevl_targ;
} /*method end*/
public BEC_6_6_SystemObject bem_tmpVar_2(BEC_6_6_SystemObject beva_suffix, BEC_6_6_SystemObject beva_build) throws Throwable {
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_tmpvarn = null;
BEC_6_6_SystemObject bevl_tmpvar = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
bevl_clnode = this.bem_scopeGet_0();
bevt_1_tmpvar_phold = bevl_clnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_2_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 220 */ {
bevt_4_tmpvar_phold = (new BEC_4_6_TextString(22, bels_7));
bevt_3_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_4_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 221 */
bevt_6_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevl_tmpvarn = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevt_7_tmpvar_phold.bemd_1(241589730, BEL_4_Base.bevn_tmpCntSet_1, bevt_8_tmpvar_phold);
bevl_tmpvar = (new BEC_5_3_BuildVar()).bem_new_0();
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_tmpvar.bemd_1(1124689062, BEL_4_Base.bevn_isTmpVarSet_1, bevt_11_tmpvar_phold);
bevl_tmpvar.bemd_1(2093073725, BEL_4_Base.bevn_suffixSet_1, beva_suffix);
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(8, bels_8));
bevt_13_tmpvar_phold = bevl_tmpvarn.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, beva_suffix);
bevl_tmpvar.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_12_tmpvar_phold);
return bevl_tmpvar;
} /*method end*/
public BEC_5_4_LogicBool bem_inPropertiesGet_0() throws Throwable {
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_con = bevp_container;
while (true)
 /* Line: 234 */ {
if (bevl_con == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_2_tmpvar_phold = bevl_con.bem_typenameGet_0();
bevt_3_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 235 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 236 */
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 238 */
 else  /* Line: 234 */ {
break;
} /* Line: 234 */
} /* Line: 234 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_addVariable_0() throws Throwable {
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_sco = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_2_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 245 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_3_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevt_5_tmpvar_phold = bevl_sco.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(54, bels_9));
bevt_7_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_8_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 249 */
bevt_9_tmpvar_phold = this.bem_inPropertiesGet_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 251 */ {
bevt_11_tmpvar_phold = bevl_v.bemd_0(1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 251 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 251 */ {
bevl_sco = this.bem_classGet_0();
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_12_tmpvar_phold);
} /* Line: 253 */
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_15_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 256 */ {
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(30, bels_10));
bevt_16_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_16_tmpvar_phold);
} /* Line: 257 */
bevt_18_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_19_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_18_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_19_tmpvar_phold, this);
bevt_20_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_20_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 260 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_syncAddVariable_0() throws Throwable {
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_sco = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_6_6_SystemObject bevl_cl = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_1_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 266 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_2_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_5_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 270 */ {
bevt_6_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_7_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_6_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpvar_phold);
} /* Line: 271 */
 else  /* Line: 272 */ {
bevt_8_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_11_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 274 */ {
bevt_12_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_13_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_12_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_13_tmpvar_phold);
} /* Line: 275 */
 else  /* Line: 276 */ {
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_14_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_15_tmpvar_phold, this);
bevt_16_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_16_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
bevt_18_tmpvar_phold = bevl_sco.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_19_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 279 */ {
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(35, bels_11));
bevt_20_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 280 */
} /* Line: 279 */
} /* Line: 274 */
} /* Line: 270 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_syncVariable_1(BEC_5_5_7_BuildVisitVisitor beva_visit) throws Throwable {
BEC_6_6_SystemObject bevl_vname = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_6_6_SystemObject bevl_cl = null;
BEC_6_6_SystemObject bevl_tunode = null;
BEC_6_6_SystemObject bevl_np = null;
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
bevl_vname = bevp_held;
bevt_0_tmpvar_phold = this.bem_scopeGet_0();
bevl_sc = bevt_0_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 291 */ {
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_3_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 292 */
 else  /* Line: 293 */ {
bevt_5_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_5_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 295 */ {
bevt_9_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 296 */
 else  /* Line: 297 */ {
bevl_tunode = this.bem_transUnitGet_0();
bevt_11_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevl_np = bevt_10_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
if (bevl_np == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevt_15_tmpvar_phold = bevo_0;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevl_np);
bevt_13_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_14_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_13_tmpvar_phold);
} /* Line: 301 */
 else  /* Line: 302 */ {
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevl_vname);
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(5, bels_13));
bevt_16_tmpvar_phold = bevl_vname.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_17_tmpvar_phold);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 306 */ {
bevp_held = bevl_v;
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevl_cl.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_20_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_21_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_21_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 311 */
 else  /* Line: 312 */ {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_v.bemd_1(1465928304, BEL_4_Base.bevn_isDeclaredSet_1, bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_23_tmpvar_phold);
bevp_held = bevl_v;
bevt_24_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_24_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_25_tmpvar_phold = bevl_cl.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_25_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 317 */
} /* Line: 306 */
} /* Line: 300 */
} /* Line: 295 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_anchorGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_node = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevl_node = this;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 326 */ {
while (true)
 /* Line: 327 */ {
bevt_2_tmpvar_phold = bevp_constants.bem_anchorTypesGet_0();
bevt_3_tmpvar_phold = bevl_node.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_has_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 328 */ {
return bevl_node;
} /* Line: 329 */
 else  /* Line: 330 */ {
bevl_node = bevl_node.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
if (bevl_node == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 332 */ {
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(18, bels_14));
bevt_5_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_6_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 333 */
} /* Line: 332 */
} /* Line: 328 */
} /* Line: 327 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_classGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 342 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 342 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 342 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 342 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 342 */
 else  /* Line: 342 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 342 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 343 */
 else  /* Line: 342 */ {
break;
} /* Line: 342 */
} /* Line: 342 */
return bevl_targ;
} /*method end*/
public BEC_6_6_SystemObject bem_scopeGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 350 */ {
if (bevl_targ == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevt_5_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 350 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 350 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 350 */
 else  /* Line: 350 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 350 */ {
bevt_8_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_9_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 350 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 350 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 350 */
 else  /* Line: 350 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 350 */ {
bevt_11_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 350 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 350 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 350 */
 else  /* Line: 350 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 350 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 351 */
 else  /* Line: 350 */ {
break;
} /* Line: 350 */
} /* Line: 350 */
return bevl_targ;
} /*method end*/
public BEC_6_6_SystemObject bem_replaceWith_1(BEC_5_4_BuildNode beva_other) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 357 */ {
return null;
} /* Line: 358 */
beva_other.bem_containerSet_1(bevp_container);
bevp_heldBy.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, beva_other);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_deleteAndAppend_1(BEC_5_4_BuildNode beva_other) throws Throwable {
beva_other.bem_delete_0();
this.bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_takeContents_1(BEC_5_4_BuildNode beva_other) throws Throwable {
BEC_6_6_SystemObject bevl_it = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
 /* Line: 371 */ {
bevt_0_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 371 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, this);
} /* Line: 373 */
 else  /* Line: 371 */ {
break;
} /* Line: 371 */
} /* Line: 371 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_resolveNp_0() throws Throwable {
BEC_5_8_BuildNamePath bevl_np = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_0_tmpvar_phold = bevp_typename.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 379 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 381 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 382 */
} /* Line: 381 */
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_3_tmpvar_phold = bevp_typename.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 387 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 388 */
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevl_np == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 392 */
bevt_8_tmpvar_phold = bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_held.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_7_tmpvar_phold);
} /* Line: 394 */
bevt_10_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_9_tmpvar_phold = bevp_typename.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 396 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 398 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 399 */
} /* Line: 398 */
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_callIsSafe_1(BEC_5_4_BuildNode beva_call) throws Throwable {
BEC_9_3_ContainerSet bevl_alwaysOkCalls = null;
BEC_9_3_ContainerSet bevl_okClasses = null;
BEC_9_3_ContainerSet bevl_okCalls = null;
BEC_9_3_ContainerSet bevl_okClasses2 = null;
BEC_9_3_ContainerSet bevl_okCalls2 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_54_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 409 */ {
bevt_6_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = (new BEC_4_6_TextString(10, bels_15));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_7_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 409 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 409 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 409 */
 else  /* Line: 409 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 409 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 410 */
synchronized (BEC_5_4_BuildNode.class) {
if (bevo_1 == null) {
bevo_1 = (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_alwaysOkCalls = bevo_1;
synchronized (BEC_5_4_BuildNode.class) {
if (bevo_2 == null) {
bevo_2 = (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses = bevo_2;
synchronized (BEC_5_4_BuildNode.class) {
if (bevo_3 == null) {
bevo_3 = (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls = bevo_3;
synchronized (BEC_5_4_BuildNode.class) {
if (bevo_4 == null) {
bevo_4 = (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses2 = bevo_4;
synchronized (BEC_5_4_BuildNode.class) {
if (bevo_5 == null) {
bevo_5 = (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls2 = bevo_5;
bevt_10_tmpvar_phold = bevl_okClasses.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevo_6;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_equals_1(bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevt_12_tmpvar_phold = (new BEC_4_6_TextString(6, bels_16));
bevl_alwaysOkCalls.bem_put_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = (new BEC_4_6_TextString(11, bels_17));
bevl_okClasses.bem_put_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(8, bels_18));
bevl_okClasses.bem_put_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = (new BEC_4_6_TextString(5, bels_19));
bevl_okCalls.bem_put_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (new BEC_4_6_TextString(10, bels_20));
bevl_okCalls.bem_put_1(bevt_16_tmpvar_phold);
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(7, bels_21));
bevl_okCalls.bem_put_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(6, bels_22));
bevl_okCalls.bem_put_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = (new BEC_4_6_TextString(10, bels_23));
bevl_okCalls.bem_put_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(10, bels_24));
bevl_okCalls.bem_put_1(bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(8, bels_25));
bevl_okCalls.bem_put_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (new BEC_4_6_TextString(7, bels_26));
bevl_okCalls.bem_put_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = (new BEC_4_6_TextString(9, bels_27));
bevl_okCalls.bem_put_1(bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (new BEC_4_6_TextString(9, bels_28));
bevl_okCalls.bem_put_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(8, bels_29));
bevl_okCalls.bem_put_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (new BEC_4_6_TextString(8, bels_30));
bevl_okCalls.bem_put_1(bevt_26_tmpvar_phold);
bevt_27_tmpvar_phold = (new BEC_4_6_TextString(11, bels_31));
bevl_okCalls.bem_put_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (new BEC_4_6_TextString(15, bels_32));
bevl_okCalls.bem_put_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = (new BEC_4_6_TextString(14, bels_33));
bevl_okCalls.bem_put_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (new BEC_4_6_TextString(6, bels_34));
bevl_okCalls.bem_put_1(bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = (new BEC_4_6_TextString(6, bels_35));
bevl_okCalls.bem_put_1(bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (new BEC_4_6_TextString(5, bels_36));
bevl_okCalls.bem_put_1(bevt_32_tmpvar_phold);
bevt_33_tmpvar_phold = (new BEC_4_6_TextString(11, bels_37));
bevl_okCalls.bem_put_1(bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(10, bels_38));
bevl_okCalls.bem_put_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = (new BEC_4_6_TextString(6, bels_39));
bevl_okCalls.bem_put_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (new BEC_4_6_TextString(8, bels_40));
bevl_okCalls.bem_put_1(bevt_36_tmpvar_phold);
bevt_37_tmpvar_phold = (new BEC_4_6_TextString(9, bels_41));
bevl_okCalls.bem_put_1(bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = (new BEC_4_6_TextString(11, bels_42));
bevl_okCalls.bem_put_1(bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = (new BEC_4_6_TextString(9, bels_43));
bevl_okCalls.bem_put_1(bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = (new BEC_4_6_TextString(13, bels_44));
bevl_okClasses2.bem_put_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = (new BEC_4_6_TextString(13, bels_45));
bevl_okClasses2.bem_put_1(bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = (new BEC_4_6_TextString(15, bels_46));
bevl_okClasses2.bem_put_1(bevt_42_tmpvar_phold);
bevt_43_tmpvar_phold = (new BEC_4_6_TextString(15, bels_47));
bevl_okClasses2.bem_put_1(bevt_43_tmpvar_phold);
bevt_44_tmpvar_phold = (new BEC_4_6_TextString(5, bels_48));
bevl_okCalls2.bem_put_1(bevt_44_tmpvar_phold);
bevt_45_tmpvar_phold = (new BEC_4_6_TextString(5, bels_49));
bevl_okCalls2.bem_put_1(bevt_45_tmpvar_phold);
} /* Line: 468 */
bevt_48_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_46_tmpvar_phold = bevl_alwaysOkCalls.bem_has_1(bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 472 */ {
bevt_49_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_49_tmpvar_phold;
} /* Line: 474 */
bevt_54_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 478 */ {
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_55_tmpvar_phold;
} /* Line: 480 */
bevt_61_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_firstGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_56_tmpvar_phold = bevl_okClasses.bem_has_1(bevt_57_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 488 */ {
bevt_64_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpvar_phold = bevl_okCalls.bem_has_1(bevt_63_tmpvar_phold);
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 489 */ {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_65_tmpvar_phold;
} /* Line: 491 */
 else  /* Line: 492 */ {
} /* Line: 492 */
} /* Line: 489 */
bevt_71_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bem_firstGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_66_tmpvar_phold = bevl_okClasses2.bem_has_1(bevt_67_tmpvar_phold);
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 496 */ {
bevt_74_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_72_tmpvar_phold = bevl_okCalls2.bem_has_1(bevt_73_tmpvar_phold);
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 497 */ {
bevt_75_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_75_tmpvar_phold;
} /* Line: 499 */
 else  /* Line: 500 */ {
} /* Line: 500 */
} /* Line: 497 */
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_76_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isLiteralOnceGet_0() throws Throwable {
BEC_5_4_LogicBool bevl_result = null;
BEC_5_4_BuildNode bevl_c0 = null;
BEC_5_4_BuildNode bevl_c1 = null;
BEC_6_6_SystemObject bevl_kv = null;
BEC_5_4_BuildNode bevl_call = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
bevl_result = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_4_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_3_tmpvar_phold = bevp_typename.bem_notEquals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 521 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 521 */
bevt_7_tmpvar_phold = bevp_held.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(6, bels_50));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 522 */ {
bevl_c0 = (BEC_5_4_BuildNode) bevp_contained.bem_firstGet_0();
bevl_c1 = (BEC_5_4_BuildNode) bevp_contained.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 525 */ {
bevt_11_tmpvar_phold = bevl_c1.bem_typenameGet_0();
bevt_12_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_equals_1(bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 525 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 525 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 525 */
 else  /* Line: 525 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 525 */ {
bevt_14_tmpvar_phold = bevl_c1.bem_heldGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 526 */ {
bevt_17_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(1126433704, BEL_4_Base.bevn_isPropertyGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 526 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 526 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 526 */
 else  /* Line: 526 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 526 */ {
bevl_result = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_19_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(2024716595, BEL_4_Base.bevn_allCallsGet_0);
bevt_0_tmpvar_loop = bevt_18_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 528 */ {
bevt_20_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 528 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_call = (BEC_5_4_BuildNode) bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_21_tmpvar_phold = bevl_call.bem_notEquals_1(this);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 530 */ {
bevt_23_tmpvar_phold = this.bem_callIsSafe_1(bevl_call);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_not_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 531 */ {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_24_tmpvar_phold;
} /* Line: 532 */
} /* Line: 531 */
} /* Line: 530 */
 else  /* Line: 528 */ {
break;
} /* Line: 528 */
} /* Line: 528 */
} /* Line: 528 */
} /* Line: 526 */
} /* Line: 525 */
return bevl_result;
} /*method end*/
public BEC_9_8_ContainerNodeList bem_containedGet_0() throws Throwable {
return bevp_contained;
} /*method end*/
public BEC_6_6_SystemObject bem_containedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_contained = (BEC_9_8_ContainerNodeList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_6_6_SystemObject bem_containerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_container = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_6_6_SystemObject bem_heldSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_held = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_heldByGet_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public BEC_6_6_SystemObject bem_heldBySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_heldBy = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_condvarGet_0() throws Throwable {
return bevp_condvar;
} /*method end*/
public BEC_6_6_SystemObject bem_condvarSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_condvar = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_6_6_SystemObject bem_inFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inFile = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_typeDetailGet_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public BEC_6_6_SystemObject bem_typeDetailSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_typeDetail = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_delayDeleteGet_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public BEC_6_6_SystemObject bem_delayDeleteSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_delayDelete = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_nlcGet_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public BEC_6_6_SystemObject bem_nlcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nlc = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_nlecGet_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public BEC_6_6_SystemObject bem_nlecSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nlec = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_wideStringGet_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public BEC_6_6_SystemObject bem_wideStringSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_wideString = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_build = (BEC_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_6_6_SystemObject bem_constantsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_constants = (BEC_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_typenameGet_0() throws Throwable {
return bevp_typename;
} /*method end*/
public BEC_6_6_SystemObject bem_typenameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_typename = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {32, 33, 34, 35, 37, 38, 39, 40, 45, 45, 46, 46, 47, 48, 52, 52, 52, 52, 52, 0, 0, 0, 53, 53, 55, 56, 57, 57, 57, 57, 0, 0, 0, 58, 59, 61, 65, 66, 67, 67, 67, 67, 0, 0, 0, 68, 69, 71, 75, 75, 76, 78, 79, 79, 80, 82, 82, 86, 86, 87, 89, 90, 90, 91, 93, 93, 97, 97, 101, 101, 105, 105, 109, 109, 110, 110, 112, 112, 112, 116, 116, 0, 116, 116, 116, 0, 0, 117, 117, 119, 119, 119, 119, 123, 123, 0, 123, 123, 123, 0, 0, 0, 123, 123, 123, 123, 0, 0, 124, 124, 126, 126, 126, 126, 126, 130, 134, 134, 135, 137, 138, 139, 143, 143, 144, 146, 146, 146, 147, 151, 151, 152, 154, 155, 159, 159, 160, 162, 163, 167, 171, 171, 172, 177, 178, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 179, 179, 179, 180, 180, 180, 180, 0, 0, 0, 181, 181, 181, 181, 181, 181, 181, 181, 181, 181, 181, 181, 181, 181, 183, 183, 184, 184, 184, 184, 184, 184, 185, 185, 187, 191, 192, 193, 193, 194, 195, 197, 201, 202, 203, 204, 204, 205, 204, 207, 211, 212, 212, 212, 212, 212, 0, 0, 0, 213, 215, 219, 220, 220, 220, 221, 221, 221, 223, 223, 223, 224, 224, 224, 224, 224, 225, 226, 226, 227, 228, 228, 228, 228, 229, 233, 234, 234, 235, 235, 235, 236, 236, 238, 240, 240, 244, 245, 245, 246, 246, 247, 248, 248, 248, 249, 249, 249, 251, 251, 251, 0, 0, 0, 252, 253, 253, 255, 256, 256, 256, 257, 257, 257, 259, 259, 259, 260, 260, 265, 266, 266, 267, 267, 268, 269, 270, 270, 270, 271, 271, 271, 273, 273, 274, 274, 274, 275, 275, 275, 277, 277, 277, 278, 278, 279, 279, 279, 280, 280, 280, 289, 290, 290, 291, 291, 292, 292, 292, 294, 294, 295, 295, 296, 296, 296, 298, 299, 299, 299, 300, 300, 301, 301, 301, 301, 304, 305, 306, 306, 307, 308, 308, 309, 309, 310, 310, 311, 311, 313, 313, 314, 314, 315, 316, 316, 317, 317, 325, 326, 328, 328, 328, 329, 331, 332, 332, 333, 333, 333, 341, 342, 342, 342, 342, 342, 0, 0, 0, 343, 345, 349, 350, 350, 350, 350, 350, 0, 0, 0, 350, 350, 350, 0, 0, 0, 350, 350, 350, 0, 0, 0, 351, 353, 357, 357, 358, 360, 361, 365, 366, 370, 371, 371, 372, 373, 379, 379, 380, 381, 381, 382, 385, 385, 386, 387, 387, 388, 390, 391, 391, 392, 394, 394, 394, 396, 396, 397, 398, 398, 399, 409, 409, 409, 409, 409, 409, 409, 0, 0, 0, 410, 410, 413, 414, 415, 416, 417, 418, 418, 418, 425, 425, 428, 428, 429, 429, 431, 431, 432, 432, 433, 433, 434, 434, 435, 435, 436, 436, 437, 437, 438, 438, 439, 439, 440, 440, 441, 441, 442, 442, 443, 443, 444, 444, 445, 445, 446, 446, 447, 447, 448, 448, 449, 449, 450, 450, 451, 451, 452, 452, 453, 453, 454, 454, 455, 455, 459, 459, 460, 460, 461, 461, 462, 462, 467, 467, 468, 468, 472, 472, 472, 474, 474, 478, 478, 478, 478, 478, 480, 480, 488, 488, 488, 488, 488, 488, 489, 489, 489, 491, 491, 496, 496, 496, 496, 496, 496, 497, 497, 497, 499, 499, 505, 505, 516, 521, 521, 521, 521, 522, 522, 522, 523, 524, 525, 525, 525, 525, 525, 0, 0, 0, 526, 526, 526, 526, 526, 0, 0, 0, 527, 528, 528, 528, 0, 528, 528, 529, 530, 531, 531, 532, 532, 543, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {83, 84, 85, 86, 87, 88, 89, 90, 96, 97, 98, 99, 100, 101, 115, 120, 121, 122, 127, 128, 131, 135, 138, 139, 141, 142, 145, 150, 151, 156, 157, 160, 164, 167, 168, 174, 182, 183, 186, 191, 192, 197, 198, 201, 205, 208, 209, 215, 222, 227, 228, 230, 231, 236, 237, 239, 240, 247, 252, 253, 255, 256, 261, 262, 264, 265, 269, 270, 274, 275, 279, 280, 287, 292, 293, 294, 296, 297, 302, 313, 318, 319, 322, 323, 328, 329, 332, 336, 337, 339, 340, 341, 346, 362, 367, 368, 371, 372, 377, 378, 381, 385, 388, 389, 390, 395, 396, 399, 403, 404, 406, 407, 408, 409, 414, 417, 422, 427, 428, 430, 431, 432, 439, 444, 445, 447, 448, 449, 450, 455, 460, 461, 463, 464, 469, 474, 475, 477, 478, 482, 487, 492, 493, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 555, 556, 561, 562, 565, 569, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 587, 592, 593, 594, 595, 596, 597, 598, 599, 600, 602, 608, 609, 612, 617, 618, 619, 625, 633, 634, 635, 636, 639, 641, 642, 648, 657, 660, 665, 666, 667, 668, 670, 673, 677, 680, 686, 707, 708, 709, 710, 712, 713, 714, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 742, 745, 750, 751, 752, 753, 755, 756, 758, 764, 765, 792, 793, 794, 796, 797, 798, 799, 800, 801, 803, 804, 805, 807, 809, 810, 812, 815, 819, 822, 823, 824, 826, 827, 828, 829, 831, 832, 833, 835, 836, 837, 838, 839, 870, 871, 872, 874, 875, 876, 877, 878, 879, 880, 882, 883, 884, 887, 888, 889, 890, 891, 893, 894, 895, 898, 899, 900, 901, 902, 903, 904, 905, 907, 908, 909, 949, 950, 951, 952, 953, 955, 956, 957, 960, 961, 962, 963, 965, 966, 967, 970, 971, 972, 973, 974, 979, 980, 981, 982, 983, 986, 987, 988, 989, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1026, 1027, 1031, 1032, 1033, 1035, 1038, 1039, 1044, 1045, 1046, 1047, 1061, 1064, 1069, 1070, 1071, 1072, 1074, 1077, 1081, 1084, 1090, 1107, 1110, 1115, 1116, 1117, 1118, 1120, 1123, 1127, 1130, 1131, 1132, 1134, 1137, 1141, 1144, 1145, 1146, 1148, 1151, 1155, 1158, 1164, 1168, 1173, 1174, 1176, 1177, 1181, 1182, 1189, 1190, 1193, 1195, 1196, 1218, 1219, 1221, 1222, 1227, 1228, 1231, 1232, 1234, 1235, 1240, 1241, 1243, 1244, 1249, 1250, 1252, 1253, 1254, 1256, 1257, 1259, 1260, 1265, 1266, 1354, 1355, 1357, 1358, 1359, 1360, 1361, 1363, 1366, 1370, 1373, 1374, 1376, 1382, 1388, 1394, 1400, 1406, 1407, 1408, 1410, 1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1430, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1461, 1462, 1463, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1473, 1474, 1475, 1476, 1477, 1479, 1480, 1481, 1483, 1484, 1486, 1487, 1488, 1489, 1490, 1492, 1493, 1495, 1496, 1497, 1498, 1499, 1500, 1502, 1503, 1504, 1506, 1507, 1512, 1513, 1514, 1515, 1516, 1517, 1519, 1520, 1521, 1523, 1524, 1529, 1530, 1563, 1564, 1565, 1567, 1568, 1570, 1571, 1572, 1574, 1575, 1576, 1581, 1582, 1583, 1584, 1586, 1589, 1593, 1596, 1597, 1599, 1600, 1601, 1603, 1606, 1610, 1613, 1614, 1615, 1616, 1616, 1619, 1621, 1622, 1623, 1625, 1626, 1628, 1629, 1640, 1643, 1646, 1650, 1653, 1657, 1660, 1664, 1667, 1671, 1674, 1678, 1681, 1685, 1688, 1692, 1695, 1699, 1702, 1706, 1709, 1713, 1716, 1720, 1723, 1727, 1730, 1734, 1737, 1741, 1744, 1748, 1751};
/* BEGIN LINEINFO 
assign 1 32 83
new 0 32 83
assign 1 33 84
new 0 33 84
assign 1 34 85
new 0 34 85
assign 1 35 86
new 0 35 86
assign 1 37 87
assign 1 38 88
constantsGet 0 38 88
assign 1 39 89
ntypesGet 0 39 89
assign 1 40 90
TOKENGet 0 40 90
assign 1 45 96
nlcGet 0 45 96
assign 1 45 97
copy 0 45 97
assign 1 46 98
nlecGet 0 46 98
assign 1 46 99
copy 0 46 99
assign 1 47 100
inClassNpGet 0 47 100
assign 1 48 101
inFileGet 0 48 101
assign 1 52 115
def 1 52 120
assign 1 52 121
firstGet 0 52 121
assign 1 52 122
def 1 52 127
assign 1 0 128
assign 1 0 131
assign 1 0 135
assign 1 53 138
firstGet 0 53 138
return 1 53 139
assign 1 55 141
nextPeerGet 0 55 141
assign 1 56 142
assign 1 57 145
undef 1 57 150
assign 1 57 151
def 1 57 156
assign 1 0 157
assign 1 0 160
assign 1 0 164
assign 1 58 167
nextPeerGet 0 58 167
assign 1 59 168
containerGet 0 59 168
return 1 61 174
assign 1 65 182
nextPeerGet 0 65 182
assign 1 66 183
assign 1 67 186
undef 1 67 191
assign 1 67 192
def 1 67 197
assign 1 0 198
assign 1 0 201
assign 1 0 205
assign 1 68 208
nextPeerGet 0 68 208
assign 1 69 209
containerGet 0 69 209
return 1 71 215
assign 1 75 222
undef 1 75 227
return 1 76 228
assign 1 78 230
nextGet 0 78 230
assign 1 79 231
undef 1 79 236
return 1 80 237
assign 1 82 239
heldGet 0 82 239
return 1 82 240
assign 1 86 247
undef 1 86 252
return 1 87 253
assign 1 89 255
priorGet 0 89 255
assign 1 90 256
undef 1 90 261
return 1 91 262
assign 1 93 264
heldGet 0 93 264
return 1 93 265
assign 1 97 269
firstGet 0 97 269
return 1 97 270
assign 1 101 274
secondGet 0 101 274
return 1 101 275
assign 1 105 279
thirdGet 0 105 279
return 1 105 280
assign 1 109 287
undef 1 109 292
assign 1 110 293
new 0 110 293
return 1 110 294
assign 1 112 296
priorGet 0 112 296
assign 1 112 297
undef 1 112 302
return 1 112 302
assign 1 116 313
undef 1 116 318
assign 1 0 319
assign 1 116 322
priorGet 0 116 322
assign 1 116 323
undef 1 116 328
assign 1 0 329
assign 1 0 332
assign 1 117 336
new 0 117 336
return 1 117 337
assign 1 119 339
priorGet 0 119 339
assign 1 119 340
priorGet 0 119 340
assign 1 119 341
undef 1 119 346
return 1 119 346
assign 1 123 362
undef 1 123 367
assign 1 0 368
assign 1 123 371
priorGet 0 123 371
assign 1 123 372
undef 1 123 377
assign 1 0 378
assign 1 0 381
assign 1 0 385
assign 1 123 388
priorGet 0 123 388
assign 1 123 389
priorGet 0 123 389
assign 1 123 390
undef 1 123 395
assign 1 0 396
assign 1 0 399
assign 1 124 403
new 0 124 403
return 1 124 404
assign 1 126 406
priorGet 0 126 406
assign 1 126 407
priorGet 0 126 407
assign 1 126 408
priorGet 0 126 408
assign 1 126 409
undef 1 126 414
return 1 126 414
assign 1 130 417
new 0 130 417
assign 1 134 422
undef 1 134 427
return 1 135 428
delete 0 137 430
assign 1 138 431
assign 1 139 432
assign 1 143 439
undef 1 143 444
return 1 144 445
assign 1 146 447
mylistGet 0 146 447
assign 1 146 448
newNode 1 146 448
insertBefore 1 146 449
containerSet 1 147 450
assign 1 151 455
undef 1 151 460
initContained 0 152 461
prepend 1 154 463
containerSet 1 155 464
assign 1 159 469
undef 1 159 474
initContained 0 160 475
addValue 1 162 477
containerSet 1 163 478
assign 1 167 482
new 0 167 482
assign 1 171 487
undef 1 171 492
assign 1 172 493
new 0 172 493
assign 1 177 535
prefixGet 0 177 535
assign 1 178 536
new 0 178 536
assign 1 178 537
add 1 178 537
assign 1 178 538
toString 0 178 538
assign 1 178 539
add 1 178 539
assign 1 178 540
new 0 178 540
assign 1 178 541
add 1 178 541
assign 1 179 542
new 0 179 542
assign 1 179 543
newlineGet 0 179 543
assign 1 179 544
add 1 179 544
assign 1 179 545
add 1 179 545
assign 1 179 546
new 0 179 546
assign 1 179 547
add 1 179 547
assign 1 179 548
toString 0 179 548
assign 1 179 549
add 1 179 549
assign 1 180 550
def 1 180 555
assign 1 180 556
def 1 180 561
assign 1 0 562
assign 1 0 565
assign 1 0 569
assign 1 181 572
new 0 181 572
assign 1 181 573
newlineGet 0 181 573
assign 1 181 574
add 1 181 574
assign 1 181 575
add 1 181 575
assign 1 181 576
new 0 181 576
assign 1 181 577
add 1 181 577
assign 1 181 578
toString 0 181 578
assign 1 181 579
add 1 181 579
assign 1 181 580
new 0 181 580
assign 1 181 581
add 1 181 581
assign 1 181 582
add 1 181 582
assign 1 181 583
new 0 181 583
assign 1 181 584
newlineGet 0 181 584
assign 1 181 585
add 1 181 585
assign 1 183 587
def 1 183 592
assign 1 184 593
new 0 184 593
assign 1 184 594
newlineGet 0 184 594
assign 1 184 595
add 1 184 595
assign 1 184 596
add 1 184 596
assign 1 184 597
new 0 184 597
assign 1 184 598
add 1 184 598
assign 1 185 599
toString 0 185 599
assign 1 185 600
add 1 185 600
return 1 187 602
assign 1 191 608
new 0 191 608
assign 1 192 609
assign 1 193 612
def 1 193 617
assign 1 194 618
increment 0 194 618
assign 1 195 619
containerGet 0 195 619
return 1 197 625
assign 1 201 633
depthGet 0 201 633
assign 1 202 634
new 0 202 634
assign 1 203 635
new 0 203 635
assign 1 204 636
new 0 204 636
assign 1 204 639
lesser 1 204 639
assign 1 205 641
add 1 205 641
assign 1 204 642
increment 0 204 642
return 1 207 648
assign 1 211 657
assign 1 212 660
def 1 212 665
assign 1 212 666
typenameGet 0 212 666
assign 1 212 667
TRANSUNITGet 0 212 667
assign 1 212 668
notEquals 1 212 668
assign 1 0 670
assign 1 0 673
assign 1 0 677
assign 1 213 680
containerGet 0 213 680
return 1 215 686
assign 1 219 707
scopeGet 0 219 707
assign 1 220 708
typenameGet 0 220 708
assign 1 220 709
METHODGet 0 220 709
assign 1 220 710
notEquals 1 220 710
assign 1 221 712
new 0 221 712
assign 1 221 713
new 2 221 713
throw 1 221 714
assign 1 223 716
heldGet 0 223 716
assign 1 223 717
tmpCntGet 0 223 717
assign 1 223 718
toString 0 223 718
assign 1 224 719
heldGet 0 224 719
assign 1 224 720
heldGet 0 224 720
assign 1 224 721
tmpCntGet 0 224 721
assign 1 224 722
increment 0 224 722
tmpCntSet 1 224 723
assign 1 225 724
new 0 225 724
assign 1 226 725
new 0 226 725
isTmpVarSet 1 226 726
suffixSet 1 227 727
assign 1 228 728
new 0 228 728
assign 1 228 729
add 1 228 729
assign 1 228 730
add 1 228 730
nameSet 1 228 731
return 1 229 732
assign 1 233 742
assign 1 234 745
def 1 234 750
assign 1 235 751
typenameGet 0 235 751
assign 1 235 752
PROPERTIESGet 0 235 752
assign 1 235 753
equals 1 235 753
assign 1 236 755
new 0 236 755
return 1 236 756
assign 1 238 758
containerGet 0 238 758
assign 1 240 764
new 0 240 764
return 1 240 765
assign 1 244 792
assign 1 245 793
isAddedGet 0 245 793
assign 1 245 794
not 0 245 794
assign 1 246 796
new 0 246 796
isAddedSet 1 246 797
assign 1 247 798
scopeGet 0 247 798
assign 1 248 799
typenameGet 0 248 799
assign 1 248 800
CLASSGet 0 248 800
assign 1 248 801
equals 1 248 801
assign 1 249 803
new 0 249 803
assign 1 249 804
new 2 249 804
throw 1 249 805
assign 1 251 807
inPropertiesGet 0 251 807
assign 1 251 809
isTmpVarGet 0 251 809
assign 1 251 810
not 0 251 810
assign 1 0 812
assign 1 0 815
assign 1 0 819
assign 1 252 822
classGet 0 252 822
assign 1 253 823
new 0 253 823
isPropertySet 1 253 824
assign 1 255 826
heldGet 0 255 826
assign 1 256 827
varMapGet 0 256 827
assign 1 256 828
nameGet 0 256 828
assign 1 256 829
has 1 256 829
assign 1 257 831
new 0 257 831
assign 1 257 832
new 2 257 832
throw 1 257 833
assign 1 259 835
varMapGet 0 259 835
assign 1 259 836
nameGet 0 259 836
put 2 259 837
assign 1 260 838
orderedVarsGet 0 260 838
addValue 1 260 839
assign 1 265 870
assign 1 266 871
isAddedGet 0 266 871
assign 1 266 872
not 0 266 872
assign 1 267 874
new 0 267 874
isAddedSet 1 267 875
assign 1 268 876
scopeGet 0 268 876
assign 1 269 877
heldGet 0 269 877
assign 1 270 878
varMapGet 0 270 878
assign 1 270 879
nameGet 0 270 879
assign 1 270 880
has 1 270 880
assign 1 271 882
varMapGet 0 271 882
assign 1 271 883
nameGet 0 271 883
assign 1 271 884
get 1 271 884
assign 1 273 887
classGet 0 273 887
assign 1 273 888
heldGet 0 273 888
assign 1 274 889
varMapGet 0 274 889
assign 1 274 890
nameGet 0 274 890
assign 1 274 891
has 1 274 891
assign 1 275 893
varMapGet 0 275 893
assign 1 275 894
nameGet 0 275 894
assign 1 275 895
get 1 275 895
assign 1 277 898
varMapGet 0 277 898
assign 1 277 899
nameGet 0 277 899
put 2 277 900
assign 1 278 901
orderedVarsGet 0 278 901
addValue 1 278 902
assign 1 279 903
typenameGet 0 279 903
assign 1 279 904
CLASSGet 0 279 904
assign 1 279 905
equals 1 279 905
assign 1 280 907
new 0 280 907
assign 1 280 908
new 2 280 908
throw 1 280 909
assign 1 289 949
assign 1 290 950
scopeGet 0 290 950
assign 1 290 951
heldGet 0 290 951
assign 1 291 952
varMapGet 0 291 952
assign 1 291 953
has 1 291 953
assign 1 292 955
varMapGet 0 292 955
assign 1 292 956
get 1 292 956
assign 1 292 957
heldGet 0 292 957
assign 1 294 960
classGet 0 294 960
assign 1 294 961
heldGet 0 294 961
assign 1 295 962
varMapGet 0 295 962
assign 1 295 963
has 1 295 963
assign 1 296 965
varMapGet 0 296 965
assign 1 296 966
get 1 296 966
assign 1 296 967
heldGet 0 296 967
assign 1 298 970
transUnitGet 0 298 970
assign 1 299 971
heldGet 0 299 971
assign 1 299 972
aliasedGet 0 299 972
assign 1 299 973
get 1 299 973
assign 1 300 974
def 1 300 979
assign 1 301 980
new 0 301 980
assign 1 301 981
add 1 301 981
assign 1 301 982
new 2 301 982
throw 1 301 983
assign 1 304 986
new 0 304 986
nameSet 1 305 987
assign 1 306 988
new 0 306 988
assign 1 306 989
equals 1 306 989
assign 1 307 991
assign 1 308 992
new 0 308 992
isTypedSet 1 308 993
assign 1 309 994
extendsGet 0 309 994
namepathSet 1 309 995
assign 1 310 996
varMapGet 0 310 996
put 2 310 997
assign 1 311 998
orderedVarsGet 0 311 998
addValue 1 311 999
assign 1 313 1002
new 0 313 1002
isDeclaredSet 1 313 1003
assign 1 314 1004
new 0 314 1004
isPropertySet 1 314 1005
assign 1 315 1006
assign 1 316 1007
varMapGet 0 316 1007
put 2 316 1008
assign 1 317 1009
orderedVarsGet 0 317 1009
addValue 1 317 1010
assign 1 325 1026
assign 1 326 1027
new 0 326 1027
assign 1 328 1031
anchorTypesGet 0 328 1031
assign 1 328 1032
typenameGet 0 328 1032
assign 1 328 1033
has 1 328 1033
return 1 329 1035
assign 1 331 1038
containerGet 0 331 1038
assign 1 332 1039
undef 1 332 1044
assign 1 333 1045
new 0 333 1045
assign 1 333 1046
new 2 333 1046
throw 1 333 1047
assign 1 341 1061
assign 1 342 1064
def 1 342 1069
assign 1 342 1070
typenameGet 0 342 1070
assign 1 342 1071
CLASSGet 0 342 1071
assign 1 342 1072
notEquals 1 342 1072
assign 1 0 1074
assign 1 0 1077
assign 1 0 1081
assign 1 343 1084
containerGet 0 343 1084
return 1 345 1090
assign 1 349 1107
assign 1 350 1110
def 1 350 1115
assign 1 350 1116
typenameGet 0 350 1116
assign 1 350 1117
CLASSGet 0 350 1117
assign 1 350 1118
notEquals 1 350 1118
assign 1 0 1120
assign 1 0 1123
assign 1 0 1127
assign 1 350 1130
typenameGet 0 350 1130
assign 1 350 1131
METHODGet 0 350 1131
assign 1 350 1132
notEquals 1 350 1132
assign 1 0 1134
assign 1 0 1137
assign 1 0 1141
assign 1 350 1144
typenameGet 0 350 1144
assign 1 350 1145
TRANSUNITGet 0 350 1145
assign 1 350 1146
notEquals 1 350 1146
assign 1 0 1148
assign 1 0 1151
assign 1 0 1155
assign 1 351 1158
containerGet 0 351 1158
return 1 353 1164
assign 1 357 1168
undef 1 357 1173
return 1 358 1174
containerSet 1 360 1176
heldSet 1 361 1177
delete 0 365 1181
addValue 1 366 1182
assign 1 370 1189
containedGet 0 370 1189
assign 1 371 1190
iteratorGet 0 371 1190
assign 1 371 1193
hasNextGet 0 371 1193
assign 1 372 1195
nextGet 0 372 1195
containerSet 1 373 1196
assign 1 379 1218
NAMEPATHGet 0 379 1218
assign 1 379 1219
equals 1 379 1219
assign 1 380 1221
assign 1 381 1222
def 1 381 1227
resolve 1 382 1228
assign 1 385 1231
CLASSGet 0 385 1231
assign 1 385 1232
equals 1 385 1232
assign 1 386 1234
namepathGet 0 386 1234
assign 1 387 1235
def 1 387 1240
resolve 1 388 1241
assign 1 390 1243
extendsGet 0 390 1243
assign 1 391 1244
def 1 391 1249
resolve 1 392 1250
assign 1 394 1252
namepathGet 0 394 1252
assign 1 394 1253
toString 0 394 1253
nameSet 1 394 1254
assign 1 396 1256
VARGet 0 396 1256
assign 1 396 1257
equals 1 396 1257
assign 1 397 1259
namepathGet 0 397 1259
assign 1 398 1260
def 1 398 1265
resolve 1 399 1266
assign 1 409 1354
heldGet 0 409 1354
assign 1 409 1355
isConstructGet 0 409 1355
assign 1 409 1357
heldGet 0 409 1357
assign 1 409 1358
newNpGet 0 409 1358
assign 1 409 1359
toString 0 409 1359
assign 1 409 1360
new 0 409 1360
assign 1 409 1361
equals 1 409 1361
assign 1 0 1363
assign 1 0 1366
assign 1 0 1370
assign 1 410 1373
new 0 410 1373
return 1 410 1374
assign 1 413 1376
new 0 413 1376
assign 1 414 1382
new 0 414 1382
assign 1 415 1388
new 0 415 1388
assign 1 416 1394
new 0 416 1394
assign 1 417 1400
new 0 417 1400
assign 1 418 1406
sizeGet 0 418 1406
assign 1 418 1407
new 0 418 1407
assign 1 418 1408
equals 1 418 1408
assign 1 425 1410
new 0 425 1410
put 1 425 1411
assign 1 428 1412
new 0 428 1412
put 1 428 1413
assign 1 429 1414
new 0 429 1414
put 1 429 1415
assign 1 431 1416
new 0 431 1416
put 1 431 1417
assign 1 432 1418
new 0 432 1418
put 1 432 1419
assign 1 433 1420
new 0 433 1420
put 1 433 1421
assign 1 434 1422
new 0 434 1422
put 1 434 1423
assign 1 435 1424
new 0 435 1424
put 1 435 1425
assign 1 436 1426
new 0 436 1426
put 1 436 1427
assign 1 437 1428
new 0 437 1428
put 1 437 1429
assign 1 438 1430
new 0 438 1430
put 1 438 1431
assign 1 439 1432
new 0 439 1432
put 1 439 1433
assign 1 440 1434
new 0 440 1434
put 1 440 1435
assign 1 441 1436
new 0 441 1436
put 1 441 1437
assign 1 442 1438
new 0 442 1438
put 1 442 1439
assign 1 443 1440
new 0 443 1440
put 1 443 1441
assign 1 444 1442
new 0 444 1442
put 1 444 1443
assign 1 445 1444
new 0 445 1444
put 1 445 1445
assign 1 446 1446
new 0 446 1446
put 1 446 1447
assign 1 447 1448
new 0 447 1448
put 1 447 1449
assign 1 448 1450
new 0 448 1450
put 1 448 1451
assign 1 449 1452
new 0 449 1452
put 1 449 1453
assign 1 450 1454
new 0 450 1454
put 1 450 1455
assign 1 451 1456
new 0 451 1456
put 1 451 1457
assign 1 452 1458
new 0 452 1458
put 1 452 1459
assign 1 453 1460
new 0 453 1460
put 1 453 1461
assign 1 454 1462
new 0 454 1462
put 1 454 1463
assign 1 455 1464
new 0 455 1464
put 1 455 1465
assign 1 459 1466
new 0 459 1466
put 1 459 1467
assign 1 460 1468
new 0 460 1468
put 1 460 1469
assign 1 461 1470
new 0 461 1470
put 1 461 1471
assign 1 462 1472
new 0 462 1472
put 1 462 1473
assign 1 467 1474
new 0 467 1474
put 1 467 1475
assign 1 468 1476
new 0 468 1476
put 1 468 1477
assign 1 472 1479
heldGet 0 472 1479
assign 1 472 1480
nameGet 0 472 1480
assign 1 472 1481
has 1 472 1481
assign 1 474 1483
new 0 474 1483
return 1 474 1484
assign 1 478 1486
containedGet 0 478 1486
assign 1 478 1487
firstGet 0 478 1487
assign 1 478 1488
heldGet 0 478 1488
assign 1 478 1489
isTypedGet 0 478 1489
assign 1 478 1490
not 0 478 1490
assign 1 480 1492
new 0 480 1492
return 1 480 1493
assign 1 488 1495
containedGet 0 488 1495
assign 1 488 1496
firstGet 0 488 1496
assign 1 488 1497
heldGet 0 488 1497
assign 1 488 1498
namepathGet 0 488 1498
assign 1 488 1499
toString 0 488 1499
assign 1 488 1500
has 1 488 1500
assign 1 489 1502
heldGet 0 489 1502
assign 1 489 1503
nameGet 0 489 1503
assign 1 489 1504
has 1 489 1504
assign 1 491 1506
new 0 491 1506
return 1 491 1507
assign 1 496 1512
containedGet 0 496 1512
assign 1 496 1513
firstGet 0 496 1513
assign 1 496 1514
heldGet 0 496 1514
assign 1 496 1515
namepathGet 0 496 1515
assign 1 496 1516
toString 0 496 1516
assign 1 496 1517
has 1 496 1517
assign 1 497 1519
heldGet 0 497 1519
assign 1 497 1520
nameGet 0 497 1520
assign 1 497 1521
has 1 497 1521
assign 1 499 1523
new 0 499 1523
return 1 499 1524
assign 1 505 1529
new 0 505 1529
return 1 505 1530
assign 1 516 1563
new 0 516 1563
assign 1 521 1564
CALLGet 0 521 1564
assign 1 521 1565
notEquals 1 521 1565
assign 1 521 1567
new 0 521 1567
return 1 521 1568
assign 1 522 1570
orgNameGet 0 522 1570
assign 1 522 1571
new 0 522 1571
assign 1 522 1572
equals 1 522 1572
assign 1 523 1574
firstGet 0 523 1574
assign 1 524 1575
secondGet 0 524 1575
assign 1 525 1576
def 1 525 1581
assign 1 525 1582
typenameGet 0 525 1582
assign 1 525 1583
CALLGet 0 525 1583
assign 1 525 1584
equals 1 525 1584
assign 1 0 1586
assign 1 0 1589
assign 1 0 1593
assign 1 526 1596
heldGet 0 526 1596
assign 1 526 1597
isLiteralGet 0 526 1597
assign 1 526 1599
heldGet 0 526 1599
assign 1 526 1600
isPropertyGet 0 526 1600
assign 1 526 1601
not 0 526 1601
assign 1 0 1603
assign 1 0 1606
assign 1 0 1610
assign 1 527 1613
new 0 527 1613
assign 1 528 1614
heldGet 0 528 1614
assign 1 528 1615
allCallsGet 0 528 1615
assign 1 528 1616
iteratorGet 0 0 1616
assign 1 528 1619
hasNextGet 0 528 1619
assign 1 528 1621
nextGet 0 528 1621
assign 1 529 1622
keyGet 0 529 1622
assign 1 530 1623
notEquals 1 530 1623
assign 1 531 1625
callIsSafe 1 531 1625
assign 1 531 1626
not 0 531 1626
assign 1 532 1628
new 0 532 1628
return 1 532 1629
return 1 543 1640
return 1 0 1643
assign 1 0 1646
return 1 0 1650
assign 1 0 1653
return 1 0 1657
assign 1 0 1660
return 1 0 1664
assign 1 0 1667
return 1 0 1671
assign 1 0 1674
return 1 0 1678
assign 1 0 1681
return 1 0 1685
assign 1 0 1688
return 1 0 1692
assign 1 0 1695
return 1 0 1699
assign 1 0 1702
return 1 0 1706
assign 1 0 1709
return 1 0 1713
assign 1 0 1716
return 1 0 1720
assign 1 0 1723
return 1 0 1727
assign 1 0 1730
return 1 0 1734
assign 1 0 1737
return 1 0 1741
assign 1 0 1744
return 1 0 1748
assign 1 0 1751
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 339997707: return bem_nlecGet_0();
case 1820417453: return bem_create_0();
case 822104518: return bem_inFileGet_0();
case 443668840: return bem_methodNotDefined_0();
case 202810500: return bem_depthGet_0();
case 1595262430: return bem_nlcGet_0();
case 786424307: return bem_tagGet_0();
case 1740134355: return bem_syncAddVariable_0();
case 845792839: return bem_iteratorGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1522157789: return bem_wideStringGet_0();
case 68392679: return bem_delayDeleteGet_0();
case 1973596005: return bem_transUnitGet_0();
case 2110470555: return bem_priorPeerGet_0();
case 1081412016: return bem_many_0();
case 931239762: return bem_heldGet_0();
case 312889617: return bem_classGet_0();
case 1236878826: return bem_nextAscendGet_0();
case 1823343663: return bem_inPropertiesGet_0();
case 1014444004: return bem_typeDetailGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 1167184407: return bem_isSecondGet_0();
case 1193143594: return bem_isThirdGet_0();
case 1437330926: return bem_inClassNpGet_0();
case 516830146: return bem_condvarGet_0();
case 576537281: return bem_delayDelete_0();
case 432255188: return bem_containedGet_0();
case 287040793: return bem_hashGet_0();
case 729571811: return bem_serializeToString_0();
case 1987872129: return bem_isFirstGet_0();
case 183400265: return bem_firstGet_0();
case 1758195374: return bem_addVariable_0();
case 242848115: return bem_secondGet_0();
case 1952633087: return bem_resolveNp_0();
case 1471053772: return bem_initContained_0();
case 1866790687: return bem_isLiteralOnceGet_0();
case 819712668: return bem_delete_0();
case 978128800: return bem_thirdGet_0();
case 1461034369: return bem_reInitContained_0();
case 1354714650: return bem_copy_0();
case 104713553: return bem_new_0();
case 1566845998: return bem_anchorGet_0();
case 213728365: return bem_scopeGet_0();
case 1956934267: return bem_heldByGet_0();
case 1388725781: return bem_prefixGet_0();
case 1779180144: return bem_nextDescendGet_0();
case 644675716: return bem_ntypesGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case 2087681086: return bem_typenameGet_0();
case 927274360: return bem_constantsGet_0();
case 1012494862: return bem_once_0();
case 493012039: return bem_buildGet_0();
case 314718434: return bem_print_0();
case 124944494: return bem_nextPeerGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1279784069: return bem_defined_1(bevd_0);
case 57310426: return bem_delayDeleteSet_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 875977779: return bem_takeContents_1((BEC_5_4_BuildNode) bevd_0);
case 443337441: return bem_containedSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case 205397975: return bem_syncVariable_1((BEC_5_5_7_BuildVisitVisitor) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 351079960: return bem_nlecSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1170500300: return bem_replaceWith_1((BEC_5_4_BuildNode) bevd_0);
case 1671186230: return bem_beforeInsert_1((BEC_5_4_BuildNode) bevd_0);
case 1487970429: return bem_copyLoc_1((BEC_5_4_BuildNode) bevd_0);
case 1003361751: return bem_typeDetailSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 2076598833: return bem_typenameSet_1(bevd_0);
case 527912399: return bem_condvarSet_1(bevd_0);
case 1668215656: return bem_deleteAndAppend_1((BEC_5_4_BuildNode) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1968016520: return bem_heldBySet_1(bevd_0);
case 167727545: return bem_callIsSafe_1((BEC_5_4_BuildNode) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1584180177: return bem_nlcSet_1(bevd_0);
case 1007846464: return bem_prepend_1((BEC_5_4_BuildNode) bevd_0);
case 2139839746: return bem_addValue_1((BEC_5_4_BuildNode) bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1511075536: return bem_wideStringSet_1(bevd_0);
case 942322015: return bem_heldSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1545079363: return bem_tmpVar_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_4_BuildNode();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_4_BuildNode.bevs_inst = (BEC_5_4_BuildNode)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_4_BuildNode.bevs_inst;
}
}
