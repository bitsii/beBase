package be.BEL_4_Base;
/* IO:File: source/build/Pass12.be */
public class BEC_3_5_5_9_BuildVisitTypeCheck extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_9_BuildVisitTypeCheck() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x54,0x79,0x70,0x65,0x43,0x68,0x65,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x43,0x61,0x74,0x63,0x68,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x75,0x6E,0x74,0x79,0x70,0x65,0x64,0x20,0x28,0x76,0x61,0x72,0x29};
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_3 = {0x53,0x65,0x6C,0x66,0x20,0x6F,0x76,0x61,0x72,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x73,0x79,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_4 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_4, 30));
private static byte[] bels_5 = {0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x73,0x74,0x20,0x74,0x6F,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_5, 19));
private static byte[] bels_6 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_7 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_8 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x65,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x63,0x61,0x73,0x74,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66,0x20,0x74,0x79,0x70,0x65,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_8, 67));
private static byte[] bels_9 = {0x20};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_9, 1));
private static byte[] bels_10 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2E};
private static byte[] bels_11 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_12 = {0x6E,0x65,0x77,0x4E,0x70,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x74,0x79,0x70,0x65,0x63,0x68,0x65,0x63,0x6B,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_14 = {0x47,0x6F,0x74,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6E,0x6E,0x6F,0x64,0x65};
private static byte[] bels_15 = {0x6E,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_15, 19));
private static byte[] bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x61,0x74,0x69,0x62,0x6C,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x2C,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_16, 52));
private static byte[] bels_17 = {0x20,0x67,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_17, 5));
public static BEC_3_5_5_9_BuildVisitTypeCheck bevs_inst;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_4_BuildNode bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_4_3_MathInt bevp_cpos;
public BEC_3_5_5_9_BuildVisitTypeCheck bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_cci = null;
BEC_2_5_4_BuildNode bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tvar = null;
BEC_2_6_6_SystemObject bevl_ovar = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_5_4_BuildNode bevl_ctarg = null;
BEC_2_6_6_SystemObject bevl_cvar = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_5_4_BuildNode bevl_org = null;
BEC_2_5_4_LogicBool bevl_castForSelf = null;
BEC_2_6_6_SystemObject bevl_ovnp = null;
BEC_2_6_6_SystemObject bevl_targsyn = null;
BEC_2_9_5_ContainerArray bevl_argSyns = null;
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_6_BuildVarSyn bevl_marg = null;
BEC_2_5_3_BuildVar bevl_carg = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_16_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_87_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_103_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_106_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_119_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_125_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_132_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_152_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_161_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_166_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_167_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_169_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_176_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_177_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_178_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_180_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_182_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_184_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_185_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_186_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_187_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_189_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_191_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_192_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_193_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_194_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_195_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_196_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_197_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_198_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_199_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_202_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_203_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_204_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_205_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_206_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_207_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_208_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_210_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_211_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_212_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_214_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_216_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_217_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_219_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_220_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_221_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_222_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_224_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_225_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_227_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_228_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_229_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_230_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_231_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_232_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_233_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_235_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_236_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_237_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_238_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_239_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_240_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_241_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_242_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_243_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_244_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_245_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_246_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_247_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_248_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_249_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_250_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_251_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_252_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_253_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_254_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_255_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_256_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_257_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_258_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_259_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_260_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_261_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_263_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_264_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_265_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_266_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_267_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_268_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_269_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_270_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_271_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_272_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_273_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_274_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_275_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_276_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_277_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_278_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_279_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_280_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_281_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_282_tmpvar_phold = null;
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
if (bevt_9_tmpvar_phold.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 384 */ {
bevt_16_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_firstGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 385 */ {
bevt_18_tmpvar_phold = (new BEC_2_4_6_TextString(46, bels_0));
bevt_17_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_17_tmpvar_phold);
} /* Line: 386 */
} /* Line: 385 */
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_20_tmpvar_phold.bevi_int == bevt_21_tmpvar_phold.bevi_int) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevp_inClass = beva_node;
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_22_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_23_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_23_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 392 */
bevt_25_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_25_tmpvar_phold.bevi_int == bevt_26_tmpvar_phold.bevi_int) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 394 */ {
bevp_cpos = (new BEC_2_4_3_MathInt(0));
} /* Line: 395 */
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_28_tmpvar_phold.bevi_int == bevt_29_tmpvar_phold.bevi_int) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 397 */ {
bevt_30_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_30_tmpvar_phold.bemd_1(2117282045, BEL_4_Base.bevn_cposSet_1, bevp_cpos);
bevp_cpos = bevp_cpos.bem_increment_0();
bevt_31_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_0_tmpvar_loop = bevt_31_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 400 */ {
bevt_32_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 400 */ {
bevl_cci = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_cci.bem_typenameGet_0();
bevt_35_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_34_tmpvar_phold.bevi_int == bevt_35_tmpvar_phold.bevi_int) {
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 401 */ {
bevt_36_tmpvar_phold = bevl_cci.bem_heldGet_0();
bevt_36_tmpvar_phold.bemd_1(474935663, BEL_4_Base.bevn_addCall_1, beva_node);
} /* Line: 402 */
} /* Line: 401 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
bevt_39_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_40_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_1));
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_40_tmpvar_phold);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 413 */ {
bevt_41_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_41_tmpvar_phold.bem_firstGet_0();
bevt_43_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_42_tmpvar_phold != null && bevt_42_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_42_tmpvar_phold).bevi_bool) /* Line: 416 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 417 */
 else  /* Line: 418 */ {
bevt_45_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_47_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_46_tmpvar_phold);
bevl_tvar = bevt_44_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 419 */
bevt_49_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_48_tmpvar_phold != null && bevt_48_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_48_tmpvar_phold).bevi_bool) /* Line: 422 */ {
bevt_50_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_50_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_51_tmpvar_phold);
} /* Line: 423 */
 else  /* Line: 424 */ {
bevl_org = beva_node.bem_secondGet_0();
bevt_53_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_54_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_53_tmpvar_phold.bevi_int == bevt_54_tmpvar_phold.bevi_int) {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 426 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 426 */ {
bevt_56_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_57_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_56_tmpvar_phold.bevi_int == bevt_57_tmpvar_phold.bevi_int) {
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_55_tmpvar_phold.bevi_bool) /* Line: 426 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 426 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 426 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 426 */ {
bevt_58_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_58_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_59_tmpvar_phold);
} /* Line: 428 */
 else  /* Line: 429 */ {
bevt_61_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_62_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_61_tmpvar_phold.bevi_int == bevt_62_tmpvar_phold.bevi_int) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 430 */ {
bevt_64_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 431 */ {
bevl_ovar = bevl_org.bem_heldGet_0();
} /* Line: 432 */
 else  /* Line: 433 */ {
bevt_66_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_68_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_67_tmpvar_phold);
bevl_ovar = bevt_65_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 435 */
} /* Line: 431 */
 else  /* Line: 430 */ {
bevt_70_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_71_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_70_tmpvar_phold.bevi_int == bevt_71_tmpvar_phold.bevi_int) {
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 438 */ {
bevt_72_tmpvar_phold = bevl_org.bem_containedGet_0();
bevl_ctarg = (BEC_2_5_4_BuildNode) bevt_72_tmpvar_phold.bem_firstGet_0();
bevt_74_tmpvar_phold = bevl_ctarg.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 441 */ {
bevl_cvar = bevl_ctarg.bem_heldGet_0();
} /* Line: 443 */
 else  /* Line: 444 */ {
bevt_76_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_78_tmpvar_phold = bevl_ctarg.bem_heldGet_0();
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_77_tmpvar_phold);
bevl_cvar = bevt_75_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 446 */
bevl_syn = null;
bevt_81_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_80_tmpvar_phold == null) {
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 450 */ {
bevt_83_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_82_tmpvar_phold);
} /* Line: 451 */
 else  /* Line: 450 */ {
bevt_84_tmpvar_phold = bevl_cvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_84_tmpvar_phold != null && bevt_84_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_84_tmpvar_phold).bevi_bool) /* Line: 452 */ {
bevt_85_tmpvar_phold = bevl_cvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_85_tmpvar_phold);
} /* Line: 454 */
} /* Line: 450 */
if (bevl_syn == null) {
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_86_tmpvar_phold.bevi_bool) /* Line: 456 */ {
bevt_87_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_89_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_87_tmpvar_phold.bem_get_1(bevt_88_tmpvar_phold);
if (bevl_mtdc == null) {
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 458 */ {
bevt_92_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_2));
bevt_91_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_92_tmpvar_phold, bevl_org);
throw new be.BELS_Base.BECS_ThrowBack(bevt_91_tmpvar_phold);
} /* Line: 459 */
 else  /* Line: 460 */ {
bevl_ovar = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
} /* Line: 461 */
} /* Line: 458 */
} /* Line: 456 */
} /* Line: 430 */
if (bevl_ovar == null) {
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 465 */ {
bevt_94_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_94_tmpvar_phold != null && bevt_94_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_94_tmpvar_phold).bevi_bool) /* Line: 465 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 465 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 465 */
 else  /* Line: 465 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 465 */ {
bevl_castForSelf = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_95_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_95_tmpvar_phold != null && bevt_95_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_95_tmpvar_phold).bevi_bool) /* Line: 468 */ {
if (bevl_syn == null) {
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_96_tmpvar_phold.bevi_bool) /* Line: 470 */ {
bevt_98_tmpvar_phold = (new BEC_2_4_6_TextString(28, bels_3));
bevt_97_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_98_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_97_tmpvar_phold);
} /* Line: 471 */
bevt_100_tmpvar_phold = bevl_mtdc.bemd_0(1707345409, BEL_4_Base.bevn_originGet_0);
bevt_101_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_101_tmpvar_phold);
if (bevt_99_tmpvar_phold != null && bevt_99_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_99_tmpvar_phold).bevi_bool) /* Line: 476 */ {
bevl_castForSelf = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 478 */
 else  /* Line: 476 */ {
bevt_103_tmpvar_phold = bevp_build.bem_emitCommonGet_0();
if (bevt_103_tmpvar_phold == null) {
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_106_tmpvar_phold = bevp_build.bem_emitCommonGet_0();
bevt_105_tmpvar_phold = bevt_106_tmpvar_phold.bem_covariantReturnsGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_104_tmpvar_phold != null && bevt_104_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_104_tmpvar_phold).bevi_bool) /* Line: 479 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 479 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 479 */
 else  /* Line: 479 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 479 */ {
bevl_castForSelf = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 480 */
} /* Line: 476 */
} /* Line: 476 */
 else  /* Line: 468 */ {
if (bevl_mtdc == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 482 */ {
bevt_108_tmpvar_phold = bevl_mtdc.bemd_2(583049050, BEL_4_Base.bevn_getEmitReturnType_2, bevl_syn, bevp_build);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_108_tmpvar_phold);
} /* Line: 483 */
 else  /* Line: 484 */ {
bevt_109_tmpvar_phold = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_109_tmpvar_phold);
} /* Line: 485 */
} /* Line: 468 */
bevt_111_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_110_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_111_tmpvar_phold);
if (bevt_110_tmpvar_phold != null && bevt_110_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_110_tmpvar_phold).bevi_bool) /* Line: 489 */ {
bevt_112_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_113_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_112_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_113_tmpvar_phold);
} /* Line: 491 */
 else  /* Line: 492 */ {
bevt_114_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_114_tmpvar_phold != null && bevt_114_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpvar_phold).bevi_bool) /* Line: 493 */ {
bevl_ovnp = bevl_syn.bem_namepathGet_0();
} /* Line: 494 */
 else  /* Line: 495 */ {
bevl_ovnp = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 496 */
bevt_115_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_115_tmpvar_phold);
bevt_116_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevl_ovnp);
if (bevt_116_tmpvar_phold != null && bevt_116_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_116_tmpvar_phold).bevi_bool) /* Line: 499 */ {
bevt_117_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_118_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_117_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_118_tmpvar_phold);
} /* Line: 501 */
 else  /* Line: 502 */ {
bevt_123_tmpvar_phold = bevo_0;
bevt_125_tmpvar_phold = bevl_syn.bem_namepathGet_0();
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bem_toString_0();
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bem_add_1(bevt_124_tmpvar_phold);
bevt_126_tmpvar_phold = bevo_1;
bevt_121_tmpvar_phold = bevt_122_tmpvar_phold.bem_add_1(bevt_126_tmpvar_phold);
bevt_127_tmpvar_phold = bevl_ovnp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_120_tmpvar_phold = bevt_121_tmpvar_phold.bem_add_1(bevt_127_tmpvar_phold);
bevt_119_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_120_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_119_tmpvar_phold);
} /* Line: 503 */
} /* Line: 499 */
if (bevl_castForSelf.bevi_bool) /* Line: 507 */ {
bevt_128_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_129_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_128_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_129_tmpvar_phold);
} /* Line: 509 */
} /* Line: 507 */
bevt_132_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_131_tmpvar_phold = bevt_132_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevt_131_tmpvar_phold == null) {
bevt_130_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_130_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_130_tmpvar_phold.bevi_bool) /* Line: 512 */ {
} /* Line: 512 */
} /* Line: 512 */
} /* Line: 426 */
} /* Line: 422 */
 else  /* Line: 413 */ {
bevt_135_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_136_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_6));
bevt_133_tmpvar_phold = bevt_134_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpvar_phold);
if (bevt_133_tmpvar_phold != null && bevt_133_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_133_tmpvar_phold).bevi_bool) /* Line: 517 */ {
bevl_targ = beva_node.bem_secondGet_0();
bevt_138_tmpvar_phold = bevl_targ.bem_typenameGet_0();
bevt_139_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_138_tmpvar_phold.bevi_int == bevt_139_tmpvar_phold.bevi_int) {
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_137_tmpvar_phold.bevi_bool) /* Line: 519 */ {
bevt_141_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_140_tmpvar_phold = bevt_141_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_140_tmpvar_phold != null && bevt_140_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_140_tmpvar_phold).bevi_bool) /* Line: 520 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 521 */
 else  /* Line: 522 */ {
bevt_143_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_145_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_144_tmpvar_phold = bevt_145_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_142_tmpvar_phold = bevt_143_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_144_tmpvar_phold);
bevl_tvar = bevt_142_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 523 */
bevl_mtdmy = beva_node.bem_scopeGet_0();
bevt_147_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_146_tmpvar_phold = bevt_147_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_146_tmpvar_phold != null && bevt_146_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_146_tmpvar_phold).bevi_bool) /* Line: 527 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 528 */
 else  /* Line: 529 */ {
bevt_149_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_151_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_148_tmpvar_phold = bevt_149_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_150_tmpvar_phold);
bevl_tvar = bevt_148_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 530 */
bevt_154_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_153_tmpvar_phold == null) {
bevt_152_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_152_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_152_tmpvar_phold.bevi_bool) /* Line: 533 */ {
bevt_157_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_156_tmpvar_phold = bevt_157_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_155_tmpvar_phold = bevt_156_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_155_tmpvar_phold != null && bevt_155_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_155_tmpvar_phold).bevi_bool) /* Line: 533 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 533 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 533 */
 else  /* Line: 533 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 533 */ {
bevt_159_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_158_tmpvar_phold = bevt_159_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_158_tmpvar_phold != null && bevt_158_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_158_tmpvar_phold).bevi_bool) /* Line: 534 */ {
bevt_160_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_161_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_160_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_161_tmpvar_phold);
} /* Line: 536 */
 else  /* Line: 537 */ {
bevt_164_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_163_tmpvar_phold = bevt_164_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_162_tmpvar_phold != null && bevt_162_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_162_tmpvar_phold).bevi_bool) /* Line: 540 */ {
bevt_166_tmpvar_phold = bevl_tvar.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_167_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_7));
bevt_165_tmpvar_phold = bevt_166_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_167_tmpvar_phold);
if (bevt_165_tmpvar_phold != null && bevt_165_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_165_tmpvar_phold).bevi_bool) /* Line: 541 */ {
bevt_168_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_169_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_168_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_169_tmpvar_phold);
} /* Line: 543 */
 else  /* Line: 544 */ {
bevt_170_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_targsyn = bevp_build.bem_getSynNp_1(bevt_170_tmpvar_phold);
bevt_172_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_171_tmpvar_phold = bevp_inClassSyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_172_tmpvar_phold);
if (bevt_171_tmpvar_phold != null && bevt_171_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_171_tmpvar_phold).bevi_bool) /* Line: 546 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 546 */ {
bevt_174_tmpvar_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_173_tmpvar_phold = bevl_targsyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_174_tmpvar_phold);
if (bevt_173_tmpvar_phold != null && bevt_173_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_173_tmpvar_phold).bevi_bool) /* Line: 546 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 546 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 546 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 546 */ {
bevt_175_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_176_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_175_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_176_tmpvar_phold);
} /* Line: 548 */
 else  /* Line: 549 */ {
bevt_181_tmpvar_phold = bevo_2;
bevt_182_tmpvar_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_180_tmpvar_phold = bevt_181_tmpvar_phold.bem_add_1(bevt_182_tmpvar_phold);
bevt_183_tmpvar_phold = bevo_3;
bevt_179_tmpvar_phold = bevt_180_tmpvar_phold.bem_add_1(bevt_183_tmpvar_phold);
bevt_184_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_178_tmpvar_phold = bevt_179_tmpvar_phold.bem_add_1(bevt_184_tmpvar_phold);
bevt_177_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_178_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_177_tmpvar_phold);
} /* Line: 550 */
} /* Line: 546 */
} /* Line: 541 */
 else  /* Line: 553 */ {
bevt_185_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_185_tmpvar_phold);
bevt_189_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_188_tmpvar_phold = bevt_189_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_187_tmpvar_phold = bevt_188_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_186_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_187_tmpvar_phold);
if (bevt_186_tmpvar_phold != null && bevt_186_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_186_tmpvar_phold).bevi_bool) /* Line: 555 */ {
bevt_190_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_191_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_190_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_191_tmpvar_phold);
} /* Line: 557 */
 else  /* Line: 558 */ {
bevt_194_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_193_tmpvar_phold = bevt_194_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_192_tmpvar_phold = bevt_193_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_192_tmpvar_phold);
bevt_196_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_195_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_196_tmpvar_phold);
if (bevt_195_tmpvar_phold != null && bevt_195_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_195_tmpvar_phold).bevi_bool) /* Line: 560 */ {
bevt_197_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_198_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_197_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_198_tmpvar_phold);
} /* Line: 562 */
 else  /* Line: 563 */ {
bevt_200_tmpvar_phold = (new BEC_2_4_6_TextString(25, bels_10));
bevt_199_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_200_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_199_tmpvar_phold);
} /* Line: 564 */
} /* Line: 560 */
} /* Line: 555 */
} /* Line: 540 */
} /* Line: 534 */
 else  /* Line: 569 */ {
bevt_201_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_202_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_201_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_202_tmpvar_phold);
} /* Line: 571 */
} /* Line: 533 */
 else  /* Line: 573 */ {
bevt_203_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_204_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_203_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_204_tmpvar_phold);
} /* Line: 574 */
} /* Line: 519 */
 else  /* Line: 576 */ {
bevt_205_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_205_tmpvar_phold.bem_firstGet_0();
bevt_207_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_206_tmpvar_phold = bevt_207_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_206_tmpvar_phold != null && bevt_206_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_206_tmpvar_phold).bevi_bool) /* Line: 579 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 580 */
 else  /* Line: 581 */ {
bevt_209_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_211_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_210_tmpvar_phold = bevt_211_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_208_tmpvar_phold = bevt_209_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_210_tmpvar_phold);
bevl_tvar = bevt_208_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 582 */
bevt_213_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_212_tmpvar_phold = bevt_213_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_212_tmpvar_phold != null && bevt_212_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_212_tmpvar_phold).bevi_bool) /* Line: 585 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 585 */ {
bevt_216_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_215_tmpvar_phold = bevt_216_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_217_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_11));
bevt_214_tmpvar_phold = bevt_215_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_217_tmpvar_phold);
if (bevt_214_tmpvar_phold != null && bevt_214_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_214_tmpvar_phold).bevi_bool) /* Line: 585 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 585 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 585 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 585 */ {
bevt_218_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_219_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_218_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_219_tmpvar_phold);
} /* Line: 586 */
 else  /* Line: 587 */ {
bevt_220_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_221_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_220_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_221_tmpvar_phold);
bevt_223_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_222_tmpvar_phold = bevt_223_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_222_tmpvar_phold != null && bevt_222_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_222_tmpvar_phold).bevi_bool) /* Line: 589 */ {
bevt_226_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_225_tmpvar_phold == null) {
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_224_tmpvar_phold.bevi_bool) /* Line: 590 */ {
bevt_228_tmpvar_phold = (new BEC_2_4_6_TextString(49, bels_12));
bevt_227_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_228_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_227_tmpvar_phold);
} /* Line: 591 */
bevt_230_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_229_tmpvar_phold = bevt_230_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_229_tmpvar_phold);
bevt_231_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_233_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_232_tmpvar_phold = bevt_233_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_231_tmpvar_phold.bem_get_1(bevt_232_tmpvar_phold);
} /* Line: 594 */
 else  /* Line: 595 */ {
bevt_234_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_234_tmpvar_phold);
bevt_235_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_237_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_236_tmpvar_phold = bevt_237_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_235_tmpvar_phold.bem_get_1(bevt_236_tmpvar_phold);
} /* Line: 597 */
if (bevl_mtdc == null) {
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_238_tmpvar_phold.bevi_bool) /* Line: 599 */ {
bevt_240_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_13));
bevt_239_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_240_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_239_tmpvar_phold);
} /* Line: 600 */
bevl_argSyns = (BEC_2_9_5_ContainerArray) bevl_mtdc.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_nnode = bevl_targ.bem_nextPeerGet_0();
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 604 */ {
bevt_242_tmpvar_phold = bevl_argSyns.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_242_tmpvar_phold.bevi_int) {
bevt_241_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_241_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_241_tmpvar_phold.bevi_bool) /* Line: 604 */ {
bevl_marg = (BEC_2_5_6_BuildVarSyn) bevl_argSyns.bem_get_1(bevl_i);
bevt_243_tmpvar_phold = bevl_marg.bem_isTypedGet_0();
if (bevt_243_tmpvar_phold.bevi_bool) /* Line: 606 */ {
if (bevl_nnode == null) {
bevt_244_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_244_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_244_tmpvar_phold.bevi_bool) /* Line: 607 */ {
bevt_246_tmpvar_phold = (new BEC_2_4_6_TextString(16, bels_14));
bevt_245_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_246_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_245_tmpvar_phold);
} /* Line: 608 */
 else  /* Line: 607 */ {
bevt_248_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_249_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_248_tmpvar_phold.bevi_int != bevt_249_tmpvar_phold.bevi_int) {
bevt_247_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_247_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_247_tmpvar_phold.bevi_bool) /* Line: 609 */ {
bevt_251_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_252_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_251_tmpvar_phold.bevi_int != bevt_252_tmpvar_phold.bevi_int) {
bevt_250_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_250_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_250_tmpvar_phold.bevi_bool) /* Line: 609 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 609 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 609 */
 else  /* Line: 609 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 609 */ {
bevt_255_tmpvar_phold = bevo_4;
bevt_257_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_256_tmpvar_phold = bevt_257_tmpvar_phold.bem_toString_0();
bevt_254_tmpvar_phold = bevt_255_tmpvar_phold.bem_add_1(bevt_256_tmpvar_phold);
bevt_253_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_254_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_253_tmpvar_phold);
} /* Line: 610 */
} /* Line: 607 */
bevt_259_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_260_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_259_tmpvar_phold.bevi_int == bevt_260_tmpvar_phold.bevi_int) {
bevt_258_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_258_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_258_tmpvar_phold.bevi_bool) /* Line: 612 */ {
bevl_carg = (BEC_2_5_3_BuildVar) bevl_nnode.bem_heldGet_0();
bevt_262_tmpvar_phold = bevl_carg.bem_isTypedGet_0();
if (bevt_262_tmpvar_phold.bevi_bool) {
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_261_tmpvar_phold.bevi_bool) /* Line: 614 */ {
bevt_263_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_264_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_263_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_264_tmpvar_phold);
bevt_266_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_265_tmpvar_phold = bevt_266_tmpvar_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevt_267_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_265_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_267_tmpvar_phold);
} /* Line: 616 */
 else  /* Line: 618 */ {
bevt_268_tmpvar_phold = bevl_carg.bem_namepathGet_0();
bevl_syn = bevp_build.bem_getSynNp_1(bevt_268_tmpvar_phold);
bevt_271_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_270_tmpvar_phold = bevl_syn.bem_castsTo_1(bevt_271_tmpvar_phold);
bevt_269_tmpvar_phold = bevt_270_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_269_tmpvar_phold != null && bevt_269_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_269_tmpvar_phold).bevi_bool) /* Line: 620 */ {
bevt_276_tmpvar_phold = bevo_5;
bevt_278_tmpvar_phold = bevl_syn.bem_namepathGet_0();
bevt_277_tmpvar_phold = bevt_278_tmpvar_phold.bem_toString_0();
bevt_275_tmpvar_phold = bevt_276_tmpvar_phold.bem_add_1(bevt_277_tmpvar_phold);
bevt_279_tmpvar_phold = bevo_6;
bevt_274_tmpvar_phold = bevt_275_tmpvar_phold.bem_add_1(bevt_279_tmpvar_phold);
bevt_281_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_280_tmpvar_phold = bevt_281_tmpvar_phold.bem_toString_0();
bevt_273_tmpvar_phold = bevt_274_tmpvar_phold.bem_add_1(bevt_280_tmpvar_phold);
bevt_272_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_273_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_272_tmpvar_phold);
} /* Line: 621 */
} /* Line: 620 */
} /* Line: 614 */
} /* Line: 612 */
bevl_nnode = bevl_nnode.bem_nextPeerGet_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 604 */
 else  /* Line: 604 */ {
break;
} /* Line: 604 */
} /* Line: 604 */
} /* Line: 604 */
} /* Line: 585 */
} /* Line: 413 */
} /* Line: 413 */
bevt_282_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_282_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClass = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassNp = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassSyn = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() throws Throwable {
return bevp_cpos;
} /*method end*/
public BEC_2_6_6_SystemObject bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {384, 384, 384, 384, 385, 385, 385, 385, 385, 385, 386, 386, 386, 389, 389, 389, 389, 390, 391, 391, 392, 392, 394, 394, 394, 394, 395, 397, 397, 397, 397, 398, 398, 399, 400, 400, 0, 400, 400, 401, 401, 401, 401, 402, 402, 413, 413, 413, 413, 414, 414, 416, 416, 417, 419, 419, 419, 419, 419, 422, 422, 423, 423, 423, 425, 426, 426, 426, 426, 0, 426, 426, 426, 426, 0, 0, 428, 428, 428, 430, 430, 430, 430, 431, 431, 432, 435, 435, 435, 435, 435, 438, 438, 438, 438, 439, 439, 441, 441, 443, 446, 446, 446, 446, 446, 449, 450, 450, 450, 450, 451, 451, 451, 452, 454, 454, 456, 456, 457, 457, 457, 457, 458, 458, 459, 459, 459, 461, 465, 465, 465, 0, 0, 0, 467, 468, 470, 470, 471, 471, 471, 476, 476, 476, 478, 479, 479, 479, 479, 479, 479, 0, 0, 0, 480, 482, 482, 483, 483, 485, 485, 489, 489, 491, 491, 491, 493, 494, 496, 498, 498, 499, 501, 501, 501, 503, 503, 503, 503, 503, 503, 503, 503, 503, 503, 509, 509, 509, 512, 512, 512, 512, 517, 517, 517, 517, 518, 519, 519, 519, 519, 520, 520, 521, 523, 523, 523, 523, 523, 526, 527, 527, 528, 530, 530, 530, 530, 530, 533, 533, 533, 533, 533, 533, 533, 0, 0, 0, 534, 534, 536, 536, 536, 540, 540, 540, 541, 541, 541, 543, 543, 543, 545, 545, 546, 546, 0, 546, 546, 0, 0, 548, 548, 548, 550, 550, 550, 550, 550, 550, 550, 550, 550, 554, 554, 555, 555, 555, 555, 557, 557, 557, 559, 559, 559, 559, 560, 560, 562, 562, 562, 564, 564, 564, 571, 571, 571, 574, 574, 574, 577, 577, 579, 579, 580, 582, 582, 582, 582, 582, 585, 585, 0, 585, 585, 585, 585, 0, 0, 586, 586, 586, 588, 588, 588, 589, 589, 590, 590, 590, 590, 591, 591, 591, 593, 593, 593, 594, 594, 594, 594, 596, 596, 597, 597, 597, 597, 599, 599, 600, 600, 600, 602, 603, 604, 604, 604, 604, 605, 606, 607, 607, 608, 608, 608, 609, 609, 609, 609, 609, 609, 609, 609, 0, 0, 0, 610, 610, 610, 610, 610, 610, 612, 612, 612, 612, 613, 614, 614, 614, 615, 615, 615, 616, 616, 616, 616, 619, 619, 620, 620, 620, 621, 621, 621, 621, 621, 621, 621, 621, 621, 621, 621, 630, 604, 635, 635, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {343, 344, 345, 350, 351, 352, 353, 354, 355, 356, 358, 359, 360, 363, 364, 365, 370, 371, 372, 373, 374, 375, 377, 378, 379, 384, 385, 387, 388, 389, 394, 395, 396, 397, 398, 399, 399, 402, 404, 405, 406, 407, 412, 413, 414, 421, 422, 423, 424, 426, 427, 428, 429, 431, 434, 435, 436, 437, 438, 440, 441, 443, 444, 445, 448, 449, 450, 451, 456, 457, 460, 461, 462, 467, 468, 471, 475, 476, 477, 480, 481, 482, 487, 488, 489, 491, 494, 495, 496, 497, 498, 502, 503, 504, 509, 510, 511, 512, 513, 515, 518, 519, 520, 521, 522, 524, 525, 526, 527, 532, 533, 534, 535, 538, 540, 541, 544, 549, 550, 551, 552, 553, 554, 559, 560, 561, 562, 565, 570, 575, 576, 578, 581, 585, 588, 589, 591, 596, 597, 598, 599, 601, 602, 603, 605, 608, 609, 614, 615, 616, 617, 619, 622, 626, 629, 634, 639, 640, 641, 644, 645, 648, 649, 651, 652, 653, 656, 658, 661, 663, 664, 665, 667, 668, 669, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 685, 686, 687, 690, 691, 692, 697, 703, 704, 705, 706, 708, 709, 710, 711, 716, 717, 718, 720, 723, 724, 725, 726, 727, 729, 730, 731, 733, 736, 737, 738, 739, 740, 742, 743, 744, 749, 750, 751, 752, 754, 757, 761, 764, 765, 767, 768, 769, 772, 773, 774, 776, 777, 778, 780, 781, 782, 785, 786, 787, 788, 790, 793, 794, 796, 799, 803, 804, 805, 808, 809, 810, 811, 812, 813, 814, 815, 816, 821, 822, 823, 824, 825, 826, 828, 829, 830, 833, 834, 835, 836, 837, 838, 840, 841, 842, 845, 846, 847, 854, 855, 856, 860, 861, 862, 866, 867, 868, 869, 871, 874, 875, 876, 877, 878, 880, 881, 883, 886, 887, 888, 889, 891, 894, 898, 899, 900, 903, 904, 905, 906, 907, 909, 910, 911, 916, 917, 918, 919, 921, 922, 923, 924, 925, 926, 927, 930, 931, 932, 933, 934, 935, 937, 942, 943, 944, 945, 947, 948, 949, 952, 953, 958, 959, 960, 962, 967, 968, 969, 970, 973, 974, 975, 980, 981, 982, 983, 988, 989, 992, 996, 999, 1000, 1001, 1002, 1003, 1004, 1007, 1008, 1009, 1014, 1015, 1016, 1017, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1032, 1033, 1034, 1035, 1036, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1053, 1054, 1064, 1065, 1068, 1071, 1075, 1078, 1082, 1085, 1089, 1092, 1096, 1099};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 384 343
typenameGet 0 384 343
assign 1 384 344
CATCHGet 0 384 344
assign 1 384 345
equals 1 384 350
assign 1 385 351
containedGet 0 385 351
assign 1 385 352
firstGet 0 385 352
assign 1 385 353
containedGet 0 385 353
assign 1 385 354
firstGet 0 385 354
assign 1 385 355
heldGet 0 385 355
assign 1 385 356
isTypedGet 0 385 356
assign 1 386 358
new 0 386 358
assign 1 386 359
new 1 386 359
throw 1 386 360
assign 1 389 363
typenameGet 0 389 363
assign 1 389 364
CLASSGet 0 389 364
assign 1 389 365
equals 1 389 370
assign 1 390 371
assign 1 391 372
heldGet 0 391 372
assign 1 391 373
namepathGet 0 391 373
assign 1 392 374
heldGet 0 392 374
assign 1 392 375
synGet 0 392 375
assign 1 394 377
typenameGet 0 394 377
assign 1 394 378
METHODGet 0 394 378
assign 1 394 379
equals 1 394 384
assign 1 395 385
new 0 395 385
assign 1 397 387
typenameGet 0 397 387
assign 1 397 388
CALLGet 0 397 388
assign 1 397 389
equals 1 397 394
assign 1 398 395
heldGet 0 398 395
cposSet 1 398 396
assign 1 399 397
increment 0 399 397
assign 1 400 398
containedGet 0 400 398
assign 1 400 399
iteratorGet 0 0 399
assign 1 400 402
hasNextGet 0 400 402
assign 1 400 404
nextGet 0 400 404
assign 1 401 405
typenameGet 0 401 405
assign 1 401 406
VARGet 0 401 406
assign 1 401 407
equals 1 401 412
assign 1 402 413
heldGet 0 402 413
addCall 1 402 414
assign 1 413 421
heldGet 0 413 421
assign 1 413 422
orgNameGet 0 413 422
assign 1 413 423
new 0 413 423
assign 1 413 424
equals 1 413 424
assign 1 414 426
containedGet 0 414 426
assign 1 414 427
firstGet 0 414 427
assign 1 416 428
heldGet 0 416 428
assign 1 416 429
isDeclaredGet 0 416 429
assign 1 417 431
heldGet 0 417 431
assign 1 419 434
ptyMapGet 0 419 434
assign 1 419 435
heldGet 0 419 435
assign 1 419 436
nameGet 0 419 436
assign 1 419 437
get 1 419 437
assign 1 419 438
memSynGet 0 419 438
assign 1 422 440
isTypedGet 0 422 440
assign 1 422 441
not 0 422 441
assign 1 423 443
heldGet 0 423 443
assign 1 423 444
new 0 423 444
checkTypesSet 1 423 445
assign 1 425 448
secondGet 0 425 448
assign 1 426 449
typenameGet 0 426 449
assign 1 426 450
TRUEGet 0 426 450
assign 1 426 451
equals 1 426 456
assign 1 0 457
assign 1 426 460
typenameGet 0 426 460
assign 1 426 461
FALSEGet 0 426 461
assign 1 426 462
equals 1 426 467
assign 1 0 468
assign 1 0 471
assign 1 428 475
heldGet 0 428 475
assign 1 428 476
new 0 428 476
checkTypesSet 1 428 477
assign 1 430 480
typenameGet 0 430 480
assign 1 430 481
VARGet 0 430 481
assign 1 430 482
equals 1 430 487
assign 1 431 488
heldGet 0 431 488
assign 1 431 489
isDeclaredGet 0 431 489
assign 1 432 491
heldGet 0 432 491
assign 1 435 494
ptyMapGet 0 435 494
assign 1 435 495
heldGet 0 435 495
assign 1 435 496
nameGet 0 435 496
assign 1 435 497
get 1 435 497
assign 1 435 498
memSynGet 0 435 498
assign 1 438 502
typenameGet 0 438 502
assign 1 438 503
CALLGet 0 438 503
assign 1 438 504
equals 1 438 509
assign 1 439 510
containedGet 0 439 510
assign 1 439 511
firstGet 0 439 511
assign 1 441 512
heldGet 0 441 512
assign 1 441 513
isDeclaredGet 0 441 513
assign 1 443 515
heldGet 0 443 515
assign 1 446 518
ptyMapGet 0 446 518
assign 1 446 519
heldGet 0 446 519
assign 1 446 520
nameGet 0 446 520
assign 1 446 521
get 1 446 521
assign 1 446 522
memSynGet 0 446 522
assign 1 449 524
assign 1 450 525
heldGet 0 450 525
assign 1 450 526
newNpGet 0 450 526
assign 1 450 527
def 1 450 532
assign 1 451 533
heldGet 0 451 533
assign 1 451 534
newNpGet 0 451 534
assign 1 451 535
getSynNp 1 451 535
assign 1 452 538
isTypedGet 0 452 538
assign 1 454 540
namepathGet 0 454 540
assign 1 454 541
getSynNp 1 454 541
assign 1 456 544
def 1 456 549
assign 1 457 550
mtdMapGet 0 457 550
assign 1 457 551
heldGet 0 457 551
assign 1 457 552
nameGet 0 457 552
assign 1 457 553
get 1 457 553
assign 1 458 554
undef 1 458 559
assign 1 459 560
new 0 459 560
assign 1 459 561
new 2 459 561
throw 1 459 562
assign 1 461 565
rsynGet 0 461 565
assign 1 465 570
def 1 465 575
assign 1 465 576
isTypedGet 0 465 576
assign 1 0 578
assign 1 0 581
assign 1 0 585
assign 1 467 588
new 0 467 588
assign 1 468 589
isSelfGet 0 468 589
assign 1 470 591
undef 1 470 596
assign 1 471 597
new 0 471 597
assign 1 471 598
new 1 471 598
throw 1 471 599
assign 1 476 601
originGet 0 476 601
assign 1 476 602
namepathGet 0 476 602
assign 1 476 603
notEquals 1 476 603
assign 1 478 605
new 0 478 605
assign 1 479 608
emitCommonGet 0 479 608
assign 1 479 609
def 1 479 614
assign 1 479 615
emitCommonGet 0 479 615
assign 1 479 616
covariantReturnsGet 0 479 616
assign 1 479 617
not 0 479 617
assign 1 0 619
assign 1 0 622
assign 1 0 626
assign 1 480 629
new 0 480 629
assign 1 482 634
def 1 482 639
assign 1 483 640
getEmitReturnType 2 483 640
assign 1 483 641
getSynNp 1 483 641
assign 1 485 644
namepathGet 0 485 644
assign 1 485 645
getSynNp 1 485 645
assign 1 489 648
namepathGet 0 489 648
assign 1 489 649
castsTo 1 489 649
assign 1 491 651
heldGet 0 491 651
assign 1 491 652
new 0 491 652
checkTypesSet 1 491 653
assign 1 493 656
isSelfGet 0 493 656
assign 1 494 658
namepathGet 0 494 658
assign 1 496 661
namepathGet 0 496 661
assign 1 498 663
namepathGet 0 498 663
assign 1 498 664
getSynNp 1 498 664
assign 1 499 665
castsTo 1 499 665
assign 1 501 667
heldGet 0 501 667
assign 1 501 668
new 0 501 668
checkTypesSet 1 501 669
assign 1 503 672
new 0 503 672
assign 1 503 673
namepathGet 0 503 673
assign 1 503 674
toString 0 503 674
assign 1 503 675
add 1 503 675
assign 1 503 676
new 0 503 676
assign 1 503 677
add 1 503 677
assign 1 503 678
toString 0 503 678
assign 1 503 679
add 1 503 679
assign 1 503 680
new 2 503 680
throw 1 503 681
assign 1 509 685
heldGet 0 509 685
assign 1 509 686
new 0 509 686
checkTypesSet 1 509 687
assign 1 512 690
heldGet 0 512 690
assign 1 512 691
namepathGet 0 512 691
assign 1 512 692
def 1 512 697
assign 1 517 703
heldGet 0 517 703
assign 1 517 704
orgNameGet 0 517 704
assign 1 517 705
new 0 517 705
assign 1 517 706
equals 1 517 706
assign 1 518 708
secondGet 0 518 708
assign 1 519 709
typenameGet 0 519 709
assign 1 519 710
VARGet 0 519 710
assign 1 519 711
equals 1 519 716
assign 1 520 717
heldGet 0 520 717
assign 1 520 718
isDeclaredGet 0 520 718
assign 1 521 720
heldGet 0 521 720
assign 1 523 723
ptyMapGet 0 523 723
assign 1 523 724
heldGet 0 523 724
assign 1 523 725
nameGet 0 523 725
assign 1 523 726
get 1 523 726
assign 1 523 727
memSynGet 0 523 727
assign 1 526 729
scopeGet 0 526 729
assign 1 527 730
heldGet 0 527 730
assign 1 527 731
isDeclaredGet 0 527 731
assign 1 528 733
heldGet 0 528 733
assign 1 530 736
ptyMapGet 0 530 736
assign 1 530 737
heldGet 0 530 737
assign 1 530 738
nameGet 0 530 738
assign 1 530 739
get 1 530 739
assign 1 530 740
memSynGet 0 530 740
assign 1 533 742
heldGet 0 533 742
assign 1 533 743
rtypeGet 0 533 743
assign 1 533 744
def 1 533 749
assign 1 533 750
heldGet 0 533 750
assign 1 533 751
rtypeGet 0 533 751
assign 1 533 752
isTypedGet 0 533 752
assign 1 0 754
assign 1 0 757
assign 1 0 761
assign 1 534 764
isTypedGet 0 534 764
assign 1 534 765
not 0 534 765
assign 1 536 767
heldGet 0 536 767
assign 1 536 768
new 0 536 768
checkTypesSet 1 536 769
assign 1 540 772
heldGet 0 540 772
assign 1 540 773
rtypeGet 0 540 773
assign 1 540 774
isSelfGet 0 540 774
assign 1 541 776
nameGet 0 541 776
assign 1 541 777
new 0 541 777
assign 1 541 778
equals 1 541 778
assign 1 543 780
heldGet 0 543 780
assign 1 543 781
new 0 543 781
checkTypesSet 1 543 782
assign 1 545 785
namepathGet 0 545 785
assign 1 545 786
getSynNp 1 545 786
assign 1 546 787
namepathGet 0 546 787
assign 1 546 788
castsTo 1 546 788
assign 1 0 790
assign 1 546 793
namepathGet 0 546 793
assign 1 546 794
castsTo 1 546 794
assign 1 0 796
assign 1 0 799
assign 1 548 803
heldGet 0 548 803
assign 1 548 804
new 0 548 804
checkTypesSet 1 548 805
assign 1 550 808
new 0 550 808
assign 1 550 809
namepathGet 0 550 809
assign 1 550 810
add 1 550 810
assign 1 550 811
new 0 550 811
assign 1 550 812
add 1 550 812
assign 1 550 813
namepathGet 0 550 813
assign 1 550 814
add 1 550 814
assign 1 550 815
new 2 550 815
throw 1 550 816
assign 1 554 821
namepathGet 0 554 821
assign 1 554 822
getSynNp 1 554 822
assign 1 555 823
heldGet 0 555 823
assign 1 555 824
rtypeGet 0 555 824
assign 1 555 825
namepathGet 0 555 825
assign 1 555 826
castsTo 1 555 826
assign 1 557 828
heldGet 0 557 828
assign 1 557 829
new 0 557 829
checkTypesSet 1 557 830
assign 1 559 833
heldGet 0 559 833
assign 1 559 834
rtypeGet 0 559 834
assign 1 559 835
namepathGet 0 559 835
assign 1 559 836
getSynNp 1 559 836
assign 1 560 837
namepathGet 0 560 837
assign 1 560 838
castsTo 1 560 838
assign 1 562 840
heldGet 0 562 840
assign 1 562 841
new 0 562 841
checkTypesSet 1 562 842
assign 1 564 845
new 0 564 845
assign 1 564 846
new 2 564 846
throw 1 564 847
assign 1 571 854
heldGet 0 571 854
assign 1 571 855
new 0 571 855
checkTypesSet 1 571 856
assign 1 574 860
heldGet 0 574 860
assign 1 574 861
new 0 574 861
checkTypesSet 1 574 862
assign 1 577 866
containedGet 0 577 866
assign 1 577 867
firstGet 0 577 867
assign 1 579 868
heldGet 0 579 868
assign 1 579 869
isDeclaredGet 0 579 869
assign 1 580 871
heldGet 0 580 871
assign 1 582 874
ptyMapGet 0 582 874
assign 1 582 875
heldGet 0 582 875
assign 1 582 876
nameGet 0 582 876
assign 1 582 877
get 1 582 877
assign 1 582 878
memSynGet 0 582 878
assign 1 585 880
isTypedGet 0 585 880
assign 1 585 881
not 0 585 881
assign 1 0 883
assign 1 585 886
heldGet 0 585 886
assign 1 585 887
orgNameGet 0 585 887
assign 1 585 888
new 0 585 888
assign 1 585 889
equals 1 585 889
assign 1 0 891
assign 1 0 894
assign 1 586 898
heldGet 0 586 898
assign 1 586 899
new 0 586 899
checkTypesSet 1 586 900
assign 1 588 903
heldGet 0 588 903
assign 1 588 904
new 0 588 904
checkTypesSet 1 588 905
assign 1 589 906
heldGet 0 589 906
assign 1 589 907
isConstructGet 0 589 907
assign 1 590 909
heldGet 0 590 909
assign 1 590 910
newNpGet 0 590 910
assign 1 590 911
undef 1 590 916
assign 1 591 917
new 0 591 917
assign 1 591 918
new 1 591 918
throw 1 591 919
assign 1 593 921
heldGet 0 593 921
assign 1 593 922
newNpGet 0 593 922
assign 1 593 923
getSynNp 1 593 923
assign 1 594 924
mtdMapGet 0 594 924
assign 1 594 925
heldGet 0 594 925
assign 1 594 926
nameGet 0 594 926
assign 1 594 927
get 1 594 927
assign 1 596 930
namepathGet 0 596 930
assign 1 596 931
getSynNp 1 596 931
assign 1 597 932
mtdMapGet 0 597 932
assign 1 597 933
heldGet 0 597 933
assign 1 597 934
nameGet 0 597 934
assign 1 597 935
get 1 597 935
assign 1 599 937
undef 1 599 942
assign 1 600 943
new 0 600 943
assign 1 600 944
new 2 600 944
throw 1 600 945
assign 1 602 947
argSynsGet 0 602 947
assign 1 603 948
nextPeerGet 0 603 948
assign 1 604 949
new 0 604 949
assign 1 604 952
lengthGet 0 604 952
assign 1 604 953
lesser 1 604 958
assign 1 605 959
get 1 605 959
assign 1 606 960
isTypedGet 0 606 960
assign 1 607 962
undef 1 607 967
assign 1 608 968
new 0 608 968
assign 1 608 969
new 2 608 969
throw 1 608 970
assign 1 609 973
typenameGet 0 609 973
assign 1 609 974
VARGet 0 609 974
assign 1 609 975
notEquals 1 609 980
assign 1 609 981
typenameGet 0 609 981
assign 1 609 982
NULLGet 0 609 982
assign 1 609 983
notEquals 1 609 988
assign 1 0 989
assign 1 0 992
assign 1 0 996
assign 1 610 999
new 0 610 999
assign 1 610 1000
typenameGet 0 610 1000
assign 1 610 1001
toString 0 610 1001
assign 1 610 1002
add 1 610 1002
assign 1 610 1003
new 2 610 1003
throw 1 610 1004
assign 1 612 1007
typenameGet 0 612 1007
assign 1 612 1008
VARGet 0 612 1008
assign 1 612 1009
equals 1 612 1014
assign 1 613 1015
heldGet 0 613 1015
assign 1 614 1016
isTypedGet 0 614 1016
assign 1 614 1017
not 0 614 1022
assign 1 615 1023
heldGet 0 615 1023
assign 1 615 1024
new 0 615 1024
checkTypesSet 1 615 1025
assign 1 616 1026
heldGet 0 616 1026
assign 1 616 1027
argCastsGet 0 616 1027
assign 1 616 1028
namepathGet 0 616 1028
put 2 616 1029
assign 1 619 1032
namepathGet 0 619 1032
assign 1 619 1033
getSynNp 1 619 1033
assign 1 620 1034
namepathGet 0 620 1034
assign 1 620 1035
castsTo 1 620 1035
assign 1 620 1036
not 0 620 1036
assign 1 621 1038
new 0 621 1038
assign 1 621 1039
namepathGet 0 621 1039
assign 1 621 1040
toString 0 621 1040
assign 1 621 1041
add 1 621 1041
assign 1 621 1042
new 0 621 1042
assign 1 621 1043
add 1 621 1043
assign 1 621 1044
namepathGet 0 621 1044
assign 1 621 1045
toString 0 621 1045
assign 1 621 1046
add 1 621 1046
assign 1 621 1047
new 2 621 1047
throw 1 621 1048
assign 1 630 1053
nextPeerGet 0 630 1053
assign 1 604 1054
increment 0 604 1054
assign 1 635 1064
nextDescendGet 0 635 1064
return 1 635 1065
return 1 0 1068
assign 1 0 1071
return 1 0 1075
assign 1 0 1078
return 1 0 1082
assign 1 0 1085
return 1 0 1089
assign 1 0 1092
return 1 0 1096
assign 1 0 1099
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 2028575047: return bem_emitterGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2128364298: return bem_cposGet_0();
case 2055025483: return bem_serializeContents_0();
case 2041762316: return bem_inClassGet_0();
case 1012494862: return bem_once_0();
case 997464046: return bem_inClassSynGet_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2117282045: return bem_cposSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_9_BuildVisitTypeCheck();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst = (BEC_3_5_5_9_BuildVisitTypeCheck)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst;
}
}
