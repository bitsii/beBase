package be.BEL_4_Base;
/* File: source/build/Pass5.be */
public class BEC_5_5_5_BuildVisitPass5 extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass5() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x35};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x35,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x6F,0x66,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_2 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x61,0x6C,0x69,0x61,0x73,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x20,0x2D,0x61,0x73,0x2D,0x2E};
private static byte[] bels_3 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x6E,0x6F,0x74,0x20,0x77,0x69,0x74,0x68,0x69,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x75,0x6E,0x69,0x74};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(2));
private static byte[] bels_4 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_5 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_6 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bels_7 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_8 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_9 = {0x4F,0x6E,0x6C,0x79,0x20,0x73,0x69,0x6E,0x67,0x6C,0x65,0x20,0x69,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x69,0x73,0x20,0x61,0x6C,0x6C,0x6F,0x77,0x65,0x64};
private static byte[] bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x62,0x72,0x61,0x63,0x65,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_13 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_14 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(2));
private static byte[] bels_15 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_16 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_17 = {0x4C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bels_18 = {0x46,0x69,0x72,0x73,0x74,0x20,0x63,0x68,0x61,0x72,0x61,0x63,0x74,0x65,0x72,0x20,0x6F,0x66,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x61,0x6E,0x64,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x6E,0x61,0x6D,0x65,0x73,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x6E,0x75,0x6D,0x65,0x72,0x69,0x63,0x20,0x64,0x69,0x67,0x69,0x74};
private static byte[] bels_19 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x31};
private static byte[] bels_20 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x32};
private static byte[] bels_21 = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] bels_22 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x63,0x6F,0x6E,0x74,0x65,0x6E,0x74,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6F,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x2E};
private static byte[] bels_23 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x74,0x68,0x65,0x73,0x69,0x73,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x28,0x62,0x75,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x29,0x20,0x61,0x66,0x74,0x65,0x72,0x3A,0x20};
public static BEC_5_5_5_BuildVisitPass5 bevs_inst;
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_6_6_SystemObject bevl_err = null;
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_ix = null;
BEC_6_6_SystemObject bevl_vinp = null;
BEC_6_6_SystemObject bevl_nnode = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_namepath = null;
BEC_4_6_TextString bevl_alias = null;
BEC_6_6_SystemObject bevl_mas = null;
BEC_6_6_SystemObject bevl_gnext = null;
BEC_6_6_SystemObject bevl_tnode = null;
BEC_5_4_LogicBool bevl_isFinal = null;
BEC_5_4_LogicBool bevl_isLocal = null;
BEC_5_4_LogicBool bevl_isNotNull = null;
BEC_5_4_BuildNode bevl_prp = null;
BEC_4_3_MathInt bevl_prpi = null;
BEC_5_4_BuildNode bevl_prptmp = null;
BEC_6_6_SystemObject bevl_m = null;
BEC_6_6_SystemObject bevl_mx = null;
BEC_6_6_SystemObject bevl_nx = null;
BEC_6_6_SystemObject bevl_con = null;
BEC_6_6_SystemObject bevl_lpnode = null;
BEC_6_6_SystemObject bevl_ii = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_5_9_BuildTransUnit bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_29_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_86_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_4_3_MathInt bevt_92_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_4_3_MathInt bevt_105_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_4_3_MathInt bevt_110_tmpvar_phold = null;
BEC_4_3_MathInt bevt_111_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_113_tmpvar_phold = null;
BEC_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_5_5_BuildClass bevt_115_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_118_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_120_tmpvar_phold = null;
BEC_4_3_MathInt bevt_121_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_4_3_MathInt bevt_125_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_126_tmpvar_phold = null;
BEC_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_132_tmpvar_phold = null;
BEC_4_6_TextString bevt_133_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_134_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_136_tmpvar_phold = null;
BEC_4_3_MathInt bevt_137_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_138_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_139_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_4_3_MathInt bevt_141_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_142_tmpvar_phold = null;
BEC_4_6_TextString bevt_143_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_144_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_4_3_MathInt bevt_147_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_148_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_149_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_152_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_4_3_MathInt bevt_155_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_158_tmpvar_phold = null;
BEC_4_6_TextString bevt_159_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_160_tmpvar_phold = null;
BEC_4_6_TextString bevt_161_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_162_tmpvar_phold = null;
BEC_4_6_TextString bevt_163_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_164_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_165_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_166_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_167_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_169_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_170_tmpvar_phold = null;
BEC_4_6_TextString bevt_171_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_173_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_174_tmpvar_phold = null;
BEC_4_6_TextString bevt_175_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_176_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_177_tmpvar_phold = null;
BEC_4_3_MathInt bevt_178_tmpvar_phold = null;
BEC_4_3_MathInt bevt_179_tmpvar_phold = null;
BEC_5_6_BuildMethod bevt_180_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_181_tmpvar_phold = null;
BEC_4_3_MathInt bevt_182_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_183_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_184_tmpvar_phold = null;
BEC_4_3_MathInt bevt_185_tmpvar_phold = null;
BEC_4_3_MathInt bevt_186_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_187_tmpvar_phold = null;
BEC_4_3_MathInt bevt_188_tmpvar_phold = null;
BEC_4_3_MathInt bevt_189_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_191_tmpvar_phold = null;
BEC_4_6_TextString bevt_192_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_193_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_194_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_195_tmpvar_phold = null;
BEC_4_3_MathInt bevt_196_tmpvar_phold = null;
BEC_4_3_MathInt bevt_197_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_198_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_199_tmpvar_phold = null;
BEC_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_201_tmpvar_phold = null;
BEC_4_6_TextString bevt_202_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_203_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_204_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_205_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_206_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_207_tmpvar_phold = null;
BEC_4_3_MathInt bevt_208_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_210_tmpvar_phold = null;
BEC_4_3_MathInt bevt_211_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_212_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_4_3_MathInt bevt_214_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_216_tmpvar_phold = null;
BEC_4_3_MathInt bevt_217_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_219_tmpvar_phold = null;
BEC_4_3_MathInt bevt_220_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_221_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_222_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_224_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_225_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_4_3_MathInt bevt_227_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_228_tmpvar_phold = null;
BEC_4_6_TextString bevt_229_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_230_tmpvar_phold = null;
BEC_4_6_TextString bevt_231_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_232_tmpvar_phold = null;
BEC_4_6_TextString bevt_233_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_235_tmpvar_phold = null;
BEC_4_6_TextString bevt_236_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_237_tmpvar_phold = null;
BEC_4_6_TextString bevt_238_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_239_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_240_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_241_tmpvar_phold = null;
BEC_5_9_BuildConstants bevt_242_tmpvar_phold = null;
BEC_4_3_MathInt bevt_243_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_244_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_245_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_246_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_247_tmpvar_phold = null;
BEC_4_3_MathInt bevt_248_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_249_tmpvar_phold = null;
BEC_4_6_TextString bevt_250_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_251_tmpvar_phold = null;
BEC_4_3_MathInt bevt_252_tmpvar_phold = null;
BEC_4_3_MathInt bevt_253_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_254_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_255_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_256_tmpvar_phold = null;
BEC_4_3_MathInt bevt_257_tmpvar_phold = null;
BEC_4_3_MathInt bevt_258_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_259_tmpvar_phold = null;
BEC_4_3_MathInt bevt_260_tmpvar_phold = null;
BEC_4_3_MathInt bevt_261_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_263_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_264_tmpvar_phold = null;
BEC_4_3_MathInt bevt_265_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_266_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_267_tmpvar_phold = null;
BEC_4_3_MathInt bevt_268_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_269_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_270_tmpvar_phold = null;
BEC_4_3_MathInt bevt_271_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_272_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_273_tmpvar_phold = null;
BEC_4_3_MathInt bevt_274_tmpvar_phold = null;
BEC_4_3_MathInt bevt_275_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_276_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_277_tmpvar_phold = null;
bevt_18_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_equals_1(bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 26 */ {
bevt_20_tmpvar_phold = (new BEC_5_9_BuildTransUnit()).bem_new_0();
beva_node.bem_heldSet_1(bevt_20_tmpvar_phold);
} /* Line: 27 */
bevt_22_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_23_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_equals_1(bevt_23_tmpvar_phold);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_25_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_25_tmpvar_phold == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 30 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 30 */ {
bevt_27_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_29_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_emptyGet_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevt_28_tmpvar_phold);
if (bevt_26_tmpvar_phold != null && bevt_26_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_26_tmpvar_phold).bevi_bool) /* Line: 30 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 30 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 30 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 30 */ {
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 32 */
} /* Line: 30 */
bevl_ix = beva_node.bem_nextPeerGet_0();
if (bevl_ix == null) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 36 */ {
bevt_32_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_33_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_equals_1(bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_35_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_36_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bem_equals_1(bevt_36_tmpvar_phold);
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 36 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 36 */
 else  /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 36 */ {
bevt_38_tmpvar_phold = bevl_ix.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_39_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_39_tmpvar_phold);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 36 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 36 */
 else  /* Line: 36 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 36 */ {
bevt_41_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_42_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_equals_1(bevt_42_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 38 */ {
bevl_vinp = (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_43_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_43_tmpvar_phold);
} /* Line: 40 */
 else  /* Line: 41 */ {
bevl_vinp = beva_node.bem_heldGet_0();
} /* Line: 42 */
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_44_tmpvar_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_45_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_45_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 49 */
bevt_47_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_48_tmpvar_phold = bevp_ntypes.bem_USEGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bem_equals_1(bevt_48_tmpvar_phold);
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 54 */ {
if (bevl_nnode == null) {
bevt_49_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_49_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_49_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_51_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_52_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_52_tmpvar_phold);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 54 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 54 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 54 */
 else  /* Line: 54 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 54 */ {
bevl_nnode = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
} /* Line: 55 */
 else  /* Line: 54 */ {
break;
} /* Line: 54 */
} /* Line: 54 */
if (bevl_nnode == null) {
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_55_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_56_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_56_tmpvar_phold);
if (bevt_54_tmpvar_phold != null && bevt_54_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_54_tmpvar_phold).bevi_bool) /* Line: 57 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 57 */ {
bevl_clnode = bevl_nnode;
bevt_57_tmpvar_phold = bevl_clnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nnode = bevt_57_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 59 */
 else  /* Line: 60 */ {
bevl_clnode = null;
} /* Line: 61 */
if (bevl_nnode == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 64 */ {
bevt_60_tmpvar_phold = (new BEC_4_6_TextString(59, bels_0));
bevt_59_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_60_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_59_tmpvar_phold);
} /* Line: 65 */
bevt_62_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_63_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_63_tmpvar_phold);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 68 */ {
bevl_namepath = (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_64_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_64_tmpvar_phold);
} /* Line: 70 */
 else  /* Line: 68 */ {
bevt_66_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_67_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_67_tmpvar_phold);
if (bevt_65_tmpvar_phold != null && bevt_65_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_65_tmpvar_phold).bevi_bool) /* Line: 71 */ {
bevl_namepath = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 72 */
 else  /* Line: 73 */ {
bevt_69_tmpvar_phold = (new BEC_4_6_TextString(55, bels_1));
bevt_68_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_69_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_68_tmpvar_phold);
} /* Line: 74 */
} /* Line: 68 */
bevl_alias = null;
bevl_mas = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_71_tmpvar_phold = bevl_mas.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_72_tmpvar_phold = bevp_ntypes.bem_ASGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_72_tmpvar_phold);
if (bevt_70_tmpvar_phold != null && bevt_70_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_70_tmpvar_phold).bevi_bool) /* Line: 79 */ {
bevl_nnode = bevl_mas.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_74_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_75_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_75_tmpvar_phold);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 81 */ {
bevt_77_tmpvar_phold = (new BEC_4_6_TextString(57, bels_2));
bevt_76_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_77_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_76_tmpvar_phold);
} /* Line: 82 */
bevl_alias = (BEC_4_6_TextString) bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 84 */
if (bevl_clnode == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevl_gnext = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_80_tmpvar_phold = bevl_gnext.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_81_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpvar_phold);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 91 */ {
bevl_nnode = bevl_gnext;
bevl_gnext = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 94 */
} /* Line: 91 */
 else  /* Line: 96 */ {
bevl_gnext = bevl_clnode;
} /* Line: 97 */
beva_node.bem_heldSet_1(bevl_namepath);
bevl_tnode = beva_node.bem_transUnitGet_0();
if (bevl_tnode == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_84_tmpvar_phold = (new BEC_4_6_TextString(53, bels_3));
bevt_83_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_84_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_83_tmpvar_phold);
} /* Line: 104 */
if (bevl_alias == null) {
bevt_85_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_85_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 107 */ {
bevl_alias = (BEC_4_6_TextString) bevl_namepath.bemd_0(1672091917, BEL_4_Base.bevn_labelGet_0);
} /* Line: 108 */
bevt_87_tmpvar_phold = bevl_tnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_86_tmpvar_phold = bevt_87_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_86_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_alias, bevl_namepath);
return (BEC_5_4_BuildNode) bevl_gnext;
} /* Line: 112 */
bevt_89_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_90_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_equals_1(bevt_90_tmpvar_phold);
if (bevt_88_tmpvar_phold.bevi_bool) /* Line: 114 */ {
bevl_isFinal = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isLocal = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isNotNull = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 119 */ {
bevt_92_tmpvar_phold = bevo_0;
bevt_91_tmpvar_phold = bevl_prpi.bem_lesser_1(bevt_92_tmpvar_phold);
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 119 */ {
if (bevl_prp == null) {
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevt_95_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_96_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_94_tmpvar_phold = bevt_95_tmpvar_phold.bem_equals_1(bevt_96_tmpvar_phold);
if (bevt_94_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_98_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_99_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bem_equals_1(bevt_99_tmpvar_phold);
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 122 */ {
bevt_101_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_102_tmpvar_phold = (new BEC_4_6_TextString(5, bels_4));
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_102_tmpvar_phold);
if (bevt_100_tmpvar_phold != null && bevt_100_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_100_tmpvar_phold).bevi_bool) /* Line: 122 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 122 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 122 */
 else  /* Line: 122 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 122 */ {
bevl_isFinal = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 123 */
 else  /* Line: 122 */ {
bevt_104_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_105_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bem_equals_1(bevt_105_tmpvar_phold);
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_107_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_108_tmpvar_phold = (new BEC_4_6_TextString(5, bels_5));
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_108_tmpvar_phold);
if (bevt_106_tmpvar_phold != null && bevt_106_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_106_tmpvar_phold).bevi_bool) /* Line: 124 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 124 */
 else  /* Line: 124 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 124 */ {
bevl_isLocal = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 125 */
 else  /* Line: 122 */ {
bevt_110_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_111_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bem_equals_1(bevt_111_tmpvar_phold);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 126 */ {
bevt_113_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_114_tmpvar_phold = (new BEC_4_6_TextString(7, bels_6));
bevt_112_tmpvar_phold = bevt_113_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_114_tmpvar_phold);
if (bevt_112_tmpvar_phold != null && bevt_112_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_112_tmpvar_phold).bevi_bool) /* Line: 126 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
 else  /* Line: 126 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 126 */ {
bevl_isNotNull = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 127 */
} /* Line: 122 */
} /* Line: 122 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 131 */
 else  /* Line: 132 */ {
bevl_prp = null;
} /* Line: 133 */
} /* Line: 121 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 119 */
 else  /* Line: 119 */ {
break;
} /* Line: 119 */
} /* Line: 119 */
bevt_115_tmpvar_phold = (new BEC_5_5_BuildClass()).bem_new_0();
beva_node.bem_heldSet_1(bevt_115_tmpvar_phold);
bevt_116_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_117_tmpvar_phold = bevp_build.bem_fromFileGet_0();
bevt_116_tmpvar_phold.bemd_1(806119150, BEL_4_Base.bevn_fromFileSet_1, bevt_117_tmpvar_phold);
try  /* Line: 139 */ {
bevt_118_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_118_tmpvar_phold.bem_firstGet_0();
bevt_120_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_121_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_119_tmpvar_phold = bevt_120_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_121_tmpvar_phold);
if (bevt_119_tmpvar_phold != null && bevt_119_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_119_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevl_namepath = (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_122_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_122_tmpvar_phold);
} /* Line: 143 */
 else  /* Line: 141 */ {
bevt_124_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_125_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_125_tmpvar_phold);
if (bevt_123_tmpvar_phold != null && bevt_123_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_123_tmpvar_phold).bevi_bool) /* Line: 144 */ {
bevl_namepath = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 145 */
 else  /* Line: 146 */ {
bevt_127_tmpvar_phold = (new BEC_4_6_TextString(35, bels_7));
bevt_126_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_127_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_126_tmpvar_phold);
} /* Line: 147 */
} /* Line: 141 */
bevt_128_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_128_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_namepath);
bevt_129_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_129_tmpvar_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevl_isFinal);
bevt_130_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_130_tmpvar_phold.bemd_1(831500365, BEL_4_Base.bevn_isLocalSet_1, bevl_isLocal);
bevt_131_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_131_tmpvar_phold.bemd_1(374719236, BEL_4_Base.bevn_isNotNullSet_1, bevl_isNotNull);
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 153 */
 catch (Throwable beve_0) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_133_tmpvar_phold = (new BEC_4_6_TextString(61, bels_8));
bevt_132_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_133_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_132_tmpvar_phold);
} /* Line: 156 */
try  /* Line: 158 */ {
bevt_134_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_nnode = bevt_134_tmpvar_phold.bem_firstGet_0();
bevt_136_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_137_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_135_tmpvar_phold = bevt_136_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_137_tmpvar_phold);
if (bevt_135_tmpvar_phold != null && bevt_135_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_135_tmpvar_phold).bevi_bool) /* Line: 160 */ {
bevt_140_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_139_tmpvar_phold = bevt_140_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_141_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevt_138_tmpvar_phold = bevt_139_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_141_tmpvar_phold);
if (bevt_138_tmpvar_phold != null && bevt_138_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_138_tmpvar_phold).bevi_bool) /* Line: 161 */ {
bevt_143_tmpvar_phold = (new BEC_4_6_TextString(34, bels_9));
bevt_142_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_143_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_142_tmpvar_phold);
} /* Line: 162 */
try  /* Line: 164 */ {
bevt_144_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_m = bevt_144_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_146_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_147_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpvar_phold = bevt_146_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_147_tmpvar_phold);
if (bevt_145_tmpvar_phold != null && bevt_145_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_145_tmpvar_phold).bevi_bool) /* Line: 166 */ {
bevt_148_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_149_tmpvar_phold = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_148_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_149_tmpvar_phold);
bevt_151_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_152_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_150_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_152_tmpvar_phold);
} /* Line: 168 */
 else  /* Line: 166 */ {
bevt_154_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_155_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_155_tmpvar_phold);
if (bevt_153_tmpvar_phold != null && bevt_153_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_153_tmpvar_phold).bevi_bool) /* Line: 169 */ {
bevt_156_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_157_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_156_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_157_tmpvar_phold);
} /* Line: 170 */
 else  /* Line: 171 */ {
bevt_159_tmpvar_phold = (new BEC_4_6_TextString(42, bels_10));
bevt_158_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_159_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_158_tmpvar_phold);
} /* Line: 172 */
} /* Line: 166 */
} /* Line: 166 */
 catch (Throwable beve_1) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_1));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_161_tmpvar_phold = (new BEC_4_6_TextString(68, bels_11));
bevt_160_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_161_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_160_tmpvar_phold);
} /* Line: 177 */
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 179 */
} /* Line: 160 */
 catch (Throwable beve_2) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_2));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_163_tmpvar_phold = (new BEC_4_6_TextString(60, bels_12));
bevt_162_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_163_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_162_tmpvar_phold);
} /* Line: 183 */
bevt_166_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_165_tmpvar_phold = bevt_166_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_165_tmpvar_phold == null) {
bevt_164_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_164_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_164_tmpvar_phold.bevi_bool) /* Line: 186 */ {
bevt_170_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_169_tmpvar_phold = bevt_170_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_168_tmpvar_phold = bevt_169_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_171_tmpvar_phold = (new BEC_4_6_TextString(13, bels_13));
bevt_167_tmpvar_phold = bevt_168_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_171_tmpvar_phold);
if (bevt_167_tmpvar_phold != null && bevt_167_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_167_tmpvar_phold).bevi_bool) /* Line: 186 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 186 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 186 */
 else  /* Line: 186 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 186 */ {
bevt_172_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_174_tmpvar_phold = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_175_tmpvar_phold = (new BEC_4_6_TextString(13, bels_14));
bevt_173_tmpvar_phold = bevt_174_tmpvar_phold.bem_fromString_1(bevt_175_tmpvar_phold);
bevt_172_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_173_tmpvar_phold);
} /* Line: 187 */
bevt_176_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_176_tmpvar_phold;
} /* Line: 190 */
bevt_178_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_179_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_177_tmpvar_phold = bevt_178_tmpvar_phold.bem_equals_1(bevt_179_tmpvar_phold);
if (bevt_177_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevt_180_tmpvar_phold = (new BEC_5_6_BuildMethod()).bem_new_0();
beva_node.bem_heldSet_1(bevt_180_tmpvar_phold);
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 195 */ {
bevt_182_tmpvar_phold = bevo_1;
bevt_181_tmpvar_phold = bevl_prpi.bem_lesser_1(bevt_182_tmpvar_phold);
if (bevt_181_tmpvar_phold.bevi_bool) /* Line: 195 */ {
if (bevl_prp == null) {
bevt_183_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_183_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_183_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_185_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_186_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_184_tmpvar_phold = bevt_185_tmpvar_phold.bem_equals_1(bevt_186_tmpvar_phold);
if (bevt_184_tmpvar_phold.bevi_bool) /* Line: 197 */ {
bevt_188_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_189_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_187_tmpvar_phold = bevt_188_tmpvar_phold.bem_equals_1(bevt_189_tmpvar_phold);
if (bevt_187_tmpvar_phold.bevi_bool) /* Line: 198 */ {
bevt_191_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_192_tmpvar_phold = (new BEC_4_6_TextString(5, bels_15));
bevt_190_tmpvar_phold = bevt_191_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_192_tmpvar_phold);
if (bevt_190_tmpvar_phold != null && bevt_190_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_190_tmpvar_phold).bevi_bool) /* Line: 198 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 198 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 198 */
 else  /* Line: 198 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 198 */ {
bevt_193_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_194_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_193_tmpvar_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevt_194_tmpvar_phold);
} /* Line: 199 */
 else  /* Line: 198 */ {
bevt_196_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_197_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_195_tmpvar_phold = bevt_196_tmpvar_phold.bem_equals_1(bevt_197_tmpvar_phold);
if (bevt_195_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevt_199_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_200_tmpvar_phold = (new BEC_4_6_TextString(5, bels_16));
bevt_198_tmpvar_phold = bevt_199_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_200_tmpvar_phold);
if (bevt_198_tmpvar_phold != null && bevt_198_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_198_tmpvar_phold).bevi_bool) /* Line: 200 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 200 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 200 */
 else  /* Line: 200 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 200 */ {
bevt_202_tmpvar_phold = (new BEC_4_6_TextString(27, bels_17));
bevt_201_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_202_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_201_tmpvar_phold);
} /* Line: 202 */
} /* Line: 198 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 206 */
 else  /* Line: 207 */ {
bevl_prp = null;
} /* Line: 208 */
} /* Line: 197 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 195 */
 else  /* Line: 195 */ {
break;
} /* Line: 195 */
} /* Line: 195 */
try  /* Line: 212 */ {
bevt_203_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_203_tmpvar_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_204_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_204_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_204_tmpvar_phold.bevi_bool) /* Line: 214 */ {
bevl_mx = bevl_m.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_mx == null) {
bevt_205_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_205_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_205_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevl_mx = bevl_mx.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_207_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_208_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_206_tmpvar_phold = bevt_207_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_208_tmpvar_phold);
if (bevt_206_tmpvar_phold != null && bevt_206_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_206_tmpvar_phold).bevi_bool) /* Line: 218 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_210_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_211_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_209_tmpvar_phold = bevt_210_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_211_tmpvar_phold);
if (bevt_209_tmpvar_phold != null && bevt_209_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_209_tmpvar_phold).bevi_bool) /* Line: 218 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 218 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 218 */ {
bevt_213_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_214_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_212_tmpvar_phold = bevt_213_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_214_tmpvar_phold);
if (bevt_212_tmpvar_phold != null && bevt_212_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_212_tmpvar_phold).bevi_bool) /* Line: 220 */ {
bevl_vinp = (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_215_tmpvar_phold = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_215_tmpvar_phold);
} /* Line: 222 */
 else  /* Line: 223 */ {
bevl_vinp = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 224 */
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
bevt_216_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_216_tmpvar_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_217_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_mx.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_217_tmpvar_phold);
bevl_mx.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_v);
} /* Line: 230 */
} /* Line: 218 */
bevt_219_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_220_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_218_tmpvar_phold = bevt_219_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_220_tmpvar_phold);
if (bevt_218_tmpvar_phold != null && bevt_218_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_218_tmpvar_phold).bevi_bool) /* Line: 233 */ {
bevt_221_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_222_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_221_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_222_tmpvar_phold);
bevt_226_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_227_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_224_tmpvar_phold = bevt_225_tmpvar_phold.bemd_1(636254476, BEL_4_Base.bevn_getPoint_1, bevt_227_tmpvar_phold);
bevt_223_tmpvar_phold = bevt_224_tmpvar_phold.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_223_tmpvar_phold != null && bevt_223_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_223_tmpvar_phold).bevi_bool) /* Line: 235 */ {
bevt_229_tmpvar_phold = (new BEC_4_6_TextString(75, bels_18));
bevt_228_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_229_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_228_tmpvar_phold);
} /* Line: 236 */
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 238 */
 else  /* Line: 239 */ {
bevt_231_tmpvar_phold = (new BEC_4_6_TextString(42, bels_19));
bevt_230_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_231_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_230_tmpvar_phold);
} /* Line: 240 */
} /* Line: 233 */
 else  /* Line: 242 */ {
bevt_233_tmpvar_phold = (new BEC_4_6_TextString(42, bels_20));
bevt_232_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_233_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_232_tmpvar_phold);
} /* Line: 243 */
} /* Line: 214 */
 catch (Throwable beve_3) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_3));
bevt_235_tmpvar_phold = bevl_err.bemd_0(1102720804, BEL_4_Base.bevn_classNameGet_0);
bevt_236_tmpvar_phold = (new BEC_4_6_TextString(16, bels_21));
bevt_234_tmpvar_phold = bevt_235_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_236_tmpvar_phold);
if (bevt_234_tmpvar_phold != null && bevt_234_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_234_tmpvar_phold).bevi_bool) /* Line: 246 */ {
throw new be.BELS_Base.BECS_ThrowBack(bevl_err);
} /* Line: 246 */
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_238_tmpvar_phold = (new BEC_4_6_TextString(104, bels_22));
bevt_237_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_238_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_237_tmpvar_phold);
} /* Line: 248 */
bevt_239_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_239_tmpvar_phold;
} /* Line: 250 */
bevt_242_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevt_241_tmpvar_phold = bevt_242_tmpvar_phold.bem_parensReqGet_0();
bevt_243_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_240_tmpvar_phold = bevt_241_tmpvar_phold.bem_has_1(bevt_243_tmpvar_phold);
if (bevt_240_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_244_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_244_tmpvar_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_245_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_245_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_245_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 254 */ {
bevt_247_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_248_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_246_tmpvar_phold = bevt_247_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_248_tmpvar_phold);
if (bevt_246_tmpvar_phold != null && bevt_246_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_246_tmpvar_phold).bevi_bool) /* Line: 254 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 254 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 254 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 254 */ {
bevt_250_tmpvar_phold = (new BEC_4_6_TextString(50, bels_23));
bevt_249_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_250_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_249_tmpvar_phold);
} /* Line: 255 */
} /* Line: 254 */
bevt_252_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_253_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_251_tmpvar_phold = bevt_252_tmpvar_phold.bem_equals_1(bevt_253_tmpvar_phold);
if (bevt_251_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevl_m = beva_node.bem_containerGet_0();
if (bevl_m == null) {
bevt_254_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_254_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_254_tmpvar_phold.bevi_bool) /* Line: 261 */ {
bevt_256_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_257_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_255_tmpvar_phold = bevt_256_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_257_tmpvar_phold);
if (bevt_255_tmpvar_phold != null && bevt_255_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_255_tmpvar_phold).bevi_bool) /* Line: 261 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 261 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 261 */
 else  /* Line: 261 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 261 */ {
bevt_258_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
beva_node.bem_typenameSet_1(bevt_258_tmpvar_phold);
} /* Line: 262 */
} /* Line: 261 */
bevt_260_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_261_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_259_tmpvar_phold = bevt_260_tmpvar_phold.bem_equals_1(bevt_261_tmpvar_phold);
if (bevt_259_tmpvar_phold.bevi_bool) /* Line: 265 */ {
bevl_nx = beva_node.bem_priorPeerGet_0();
bevl_gnext = beva_node.bem_nextAscendGet_0();
while (true)
 /* Line: 271 */ {
if (bevl_nx == null) {
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_262_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_264_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_265_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_263_tmpvar_phold = bevt_264_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_265_tmpvar_phold);
if (bevt_263_tmpvar_phold != null && bevt_263_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_263_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 271 */ {
bevt_267_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_268_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_266_tmpvar_phold = bevt_267_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_268_tmpvar_phold);
if (bevt_266_tmpvar_phold != null && bevt_266_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_266_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 271 */ {
bevt_270_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_271_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_269_tmpvar_phold = bevt_270_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_271_tmpvar_phold);
if (bevt_269_tmpvar_phold != null && bevt_269_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_269_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 271 */ {
if (bevl_con == null) {
bevt_272_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_272_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_272_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevl_con = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 273 */
bevl_con.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_nx);
bevl_nx = bevl_nx.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
} /* Line: 276 */
 else  /* Line: 271 */ {
break;
} /* Line: 271 */
} /* Line: 271 */
if (bevl_con == null) {
bevt_273_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_273_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_273_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_274_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
beva_node.bem_typenameSet_1(bevt_274_tmpvar_phold);
beva_node.bem_heldSet_1(null);
bevl_lpnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_275_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_lpnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_275_tmpvar_phold);
beva_node.bem_addValue_1((BEC_5_4_BuildNode) bevl_lpnode);
bevl_lpnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_ii = bevl_con.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 285 */ {
bevt_276_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_276_tmpvar_phold != null && bevt_276_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_276_tmpvar_phold).bevi_bool) /* Line: 285 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_lpnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 288 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
} /* Line: 285 */
 else  /* Line: 294 */ {
beva_node.bem_delete_0();
} /* Line: 295 */
return (BEC_5_4_BuildNode) bevl_gnext;
} /* Line: 297 */
bevt_277_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_277_tmpvar_phold;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {26, 26, 26, 27, 27, 29, 29, 29, 30, 30, 30, 0, 30, 30, 30, 30, 0, 0, 31, 32, 35, 36, 36, 36, 36, 36, 0, 36, 36, 36, 0, 0, 0, 0, 0, 36, 36, 36, 0, 0, 0, 38, 38, 38, 39, 40, 40, 42, 44, 45, 45, 47, 48, 48, 49, 51, 51, 51, 53, 54, 54, 54, 54, 54, 0, 0, 0, 55, 57, 57, 57, 57, 57, 0, 0, 0, 58, 59, 59, 61, 64, 64, 65, 65, 65, 68, 68, 68, 69, 70, 70, 71, 71, 71, 72, 74, 74, 74, 77, 78, 79, 79, 79, 80, 81, 81, 81, 82, 82, 82, 84, 87, 87, 88, 89, 91, 91, 91, 92, 93, 94, 97, 99, 101, 103, 103, 104, 104, 104, 107, 107, 108, 110, 110, 110, 112, 114, 114, 114, 115, 116, 117, 118, 119, 119, 119, 120, 120, 121, 121, 121, 122, 122, 122, 122, 122, 122, 0, 0, 0, 123, 124, 124, 124, 124, 124, 124, 0, 0, 0, 125, 126, 126, 126, 126, 126, 126, 0, 0, 0, 127, 129, 130, 131, 133, 119, 137, 137, 138, 138, 138, 140, 140, 141, 141, 141, 142, 143, 143, 144, 144, 144, 145, 147, 147, 147, 149, 149, 150, 150, 151, 151, 152, 152, 153, 155, 156, 156, 156, 159, 159, 160, 160, 160, 161, 161, 161, 161, 162, 162, 162, 165, 165, 166, 166, 166, 167, 167, 167, 168, 168, 168, 168, 169, 169, 169, 170, 170, 170, 172, 172, 172, 176, 177, 177, 177, 179, 182, 183, 183, 183, 186, 186, 186, 186, 186, 186, 186, 186, 186, 0, 0, 0, 187, 187, 187, 187, 187, 190, 190, 192, 192, 192, 193, 193, 194, 195, 195, 195, 196, 196, 197, 197, 197, 198, 198, 198, 198, 198, 198, 0, 0, 0, 199, 199, 199, 200, 200, 200, 200, 200, 200, 0, 0, 0, 202, 202, 202, 204, 205, 206, 208, 195, 213, 213, 214, 214, 215, 216, 216, 217, 218, 218, 218, 0, 218, 218, 218, 0, 0, 220, 220, 220, 221, 222, 222, 224, 226, 227, 227, 228, 229, 229, 230, 233, 233, 233, 234, 234, 234, 235, 235, 235, 235, 235, 236, 236, 236, 238, 240, 240, 240, 243, 243, 243, 246, 246, 246, 246, 247, 248, 248, 248, 250, 250, 252, 252, 252, 252, 253, 253, 254, 254, 0, 254, 254, 254, 0, 0, 255, 255, 255, 259, 259, 259, 260, 261, 261, 261, 261, 261, 0, 0, 0, 262, 262, 265, 265, 265, 266, 267, 271, 271, 271, 271, 271, 0, 0, 0, 271, 271, 271, 0, 0, 0, 271, 271, 271, 0, 0, 0, 272, 272, 273, 275, 276, 278, 278, 279, 279, 280, 281, 282, 282, 283, 284, 285, 285, 286, 287, 288, 295, 297, 300, 300};
public static int[] bevs_smnlec
 = new int[] {337, 338, 339, 341, 342, 344, 345, 346, 348, 349, 354, 355, 358, 359, 360, 361, 363, 366, 370, 371, 374, 375, 380, 381, 382, 383, 385, 388, 389, 390, 392, 395, 399, 402, 406, 409, 410, 411, 413, 416, 420, 423, 424, 425, 427, 428, 429, 432, 434, 435, 436, 437, 438, 439, 440, 442, 443, 444, 446, 449, 454, 455, 456, 457, 459, 462, 466, 469, 475, 480, 481, 482, 483, 485, 488, 492, 495, 496, 497, 500, 502, 507, 508, 509, 510, 512, 513, 514, 516, 517, 518, 521, 522, 523, 525, 528, 529, 530, 533, 534, 535, 536, 537, 539, 540, 541, 542, 544, 545, 546, 548, 550, 555, 556, 557, 558, 559, 560, 562, 563, 564, 568, 570, 571, 572, 577, 578, 579, 580, 582, 587, 588, 590, 591, 592, 593, 595, 596, 597, 599, 600, 601, 602, 603, 606, 607, 609, 614, 615, 616, 617, 619, 620, 621, 623, 624, 625, 627, 630, 634, 637, 640, 641, 642, 644, 645, 646, 648, 651, 655, 658, 661, 662, 663, 665, 666, 667, 669, 672, 676, 679, 683, 684, 685, 688, 691, 697, 698, 699, 700, 701, 703, 704, 705, 706, 707, 709, 710, 711, 714, 715, 716, 718, 721, 722, 723, 726, 727, 728, 729, 730, 731, 732, 733, 734, 738, 739, 740, 741, 744, 745, 746, 747, 748, 750, 751, 752, 753, 755, 756, 757, 760, 761, 762, 763, 764, 766, 767, 768, 769, 770, 771, 772, 775, 776, 777, 779, 780, 781, 784, 785, 786, 792, 793, 794, 795, 797, 802, 803, 804, 805, 807, 808, 809, 814, 815, 816, 817, 818, 819, 821, 824, 828, 831, 832, 833, 834, 835, 837, 838, 840, 841, 842, 844, 845, 846, 847, 850, 851, 853, 858, 859, 860, 861, 863, 864, 865, 867, 868, 869, 871, 874, 878, 881, 882, 883, 886, 887, 888, 890, 891, 892, 894, 897, 901, 904, 905, 906, 909, 910, 911, 914, 917, 924, 925, 926, 931, 932, 933, 938, 939, 940, 941, 942, 944, 947, 948, 949, 951, 954, 958, 959, 960, 962, 963, 964, 967, 969, 970, 971, 972, 973, 974, 975, 978, 979, 980, 982, 983, 984, 985, 986, 987, 988, 989, 991, 992, 993, 995, 998, 999, 1000, 1004, 1005, 1006, 1011, 1012, 1013, 1015, 1017, 1018, 1019, 1020, 1022, 1023, 1025, 1026, 1027, 1028, 1030, 1031, 1032, 1037, 1038, 1041, 1042, 1043, 1045, 1048, 1052, 1053, 1054, 1057, 1058, 1059, 1061, 1062, 1067, 1068, 1069, 1070, 1072, 1075, 1079, 1082, 1083, 1086, 1087, 1088, 1090, 1091, 1094, 1099, 1100, 1101, 1102, 1104, 1107, 1111, 1114, 1115, 1116, 1118, 1121, 1125, 1128, 1129, 1130, 1132, 1135, 1139, 1142, 1147, 1148, 1150, 1151, 1157, 1162, 1163, 1164, 1165, 1166, 1167, 1168, 1169, 1170, 1171, 1174, 1176, 1177, 1178, 1186, 1188, 1190, 1191};
/* BEGIN LINEINFO 
assign 1 26 337
typenameGet 0 26 337
assign 1 26 338
TRANSUNITGet 0 26 338
assign 1 26 339
equals 1 26 339
assign 1 27 341
new 0 27 341
heldSet 1 27 342
assign 1 29 344
typenameGet 0 29 344
assign 1 29 345
VARGet 0 29 345
assign 1 29 346
equals 1 29 346
assign 1 30 348
heldGet 0 30 348
assign 1 30 349
undef 1 30 354
assign 1 0 355
assign 1 30 358
heldGet 0 30 358
assign 1 30 359
new 0 30 359
assign 1 30 360
emptyGet 0 30 360
assign 1 30 361
sameType 1 30 361
assign 1 0 363
assign 1 0 366
assign 1 31 370
new 0 31 370
heldSet 1 32 371
assign 1 35 374
nextPeerGet 0 35 374
assign 1 36 375
def 1 36 380
assign 1 36 381
typenameGet 0 36 381
assign 1 36 382
IDGet 0 36 382
assign 1 36 383
equals 1 36 383
assign 1 0 385
assign 1 36 388
typenameGet 0 36 388
assign 1 36 389
NAMEPATHGet 0 36 389
assign 1 36 390
equals 1 36 390
assign 1 0 392
assign 1 0 395
assign 1 0 399
assign 1 0 402
assign 1 0 406
assign 1 36 409
typenameGet 0 36 409
assign 1 36 410
IDGet 0 36 410
assign 1 36 411
equals 1 36 411
assign 1 0 413
assign 1 0 416
assign 1 0 420
assign 1 38 423
typenameGet 0 38 423
assign 1 38 424
IDGet 0 38 424
assign 1 38 425
equals 1 38 425
assign 1 39 427
new 0 39 427
assign 1 40 428
heldGet 0 40 428
addStep 1 40 429
assign 1 42 432
heldGet 0 42 432
assign 1 44 434
new 0 44 434
assign 1 45 435
new 0 45 435
isTypedSet 1 45 436
namepathSet 1 47 437
assign 1 48 438
VARGet 0 48 438
typenameSet 1 48 439
heldSet 1 49 440
assign 1 51 442
typenameGet 0 51 442
assign 1 51 443
USEGet 0 51 443
assign 1 51 444
equals 1 51 444
assign 1 53 446
nextPeerGet 0 53 446
assign 1 54 449
def 1 54 454
assign 1 54 455
typenameGet 0 54 455
assign 1 54 456
DEFMODGet 0 54 456
assign 1 54 457
equals 1 54 457
assign 1 0 459
assign 1 0 462
assign 1 0 466
assign 1 55 469
nextPeerGet 0 55 469
assign 1 57 475
def 1 57 480
assign 1 57 481
typenameGet 0 57 481
assign 1 57 482
CLASSGet 0 57 482
assign 1 57 483
equals 1 57 483
assign 1 0 485
assign 1 0 488
assign 1 0 492
assign 1 58 495
assign 1 59 496
containedGet 0 59 496
assign 1 59 497
firstGet 0 59 497
assign 1 61 500
assign 1 64 502
undef 1 64 507
assign 1 65 508
new 0 65 508
assign 1 65 509
new 2 65 509
throw 1 65 510
assign 1 68 512
typenameGet 0 68 512
assign 1 68 513
IDGet 0 68 513
assign 1 68 514
equals 1 68 514
assign 1 69 516
new 0 69 516
assign 1 70 517
heldGet 0 70 517
addStep 1 70 518
assign 1 71 521
typenameGet 0 71 521
assign 1 71 522
NAMEPATHGet 0 71 522
assign 1 71 523
equals 1 71 523
assign 1 72 525
heldGet 0 72 525
assign 1 74 528
new 0 74 528
assign 1 74 529
new 2 74 529
throw 1 74 530
assign 1 77 533
assign 1 78 534
nextPeerGet 0 78 534
assign 1 79 535
typenameGet 0 79 535
assign 1 79 536
ASGet 0 79 536
assign 1 79 537
equals 1 79 537
assign 1 80 539
nextPeerGet 0 80 539
assign 1 81 540
typenameGet 0 81 540
assign 1 81 541
IDGet 0 81 541
assign 1 81 542
notEquals 1 81 542
assign 1 82 544
new 0 82 544
assign 1 82 545
new 2 82 545
throw 1 82 546
assign 1 84 548
heldGet 0 84 548
assign 1 87 550
undef 1 87 555
assign 1 88 556
nextPeerGet 0 88 556
delete 0 89 557
assign 1 91 558
typenameGet 0 91 558
assign 1 91 559
SEMIGet 0 91 559
assign 1 91 560
equals 1 91 560
assign 1 92 562
assign 1 93 563
nextPeerGet 0 93 563
delete 0 94 564
assign 1 97 568
heldSet 1 99 570
assign 1 101 571
transUnitGet 0 101 571
assign 1 103 572
undef 1 103 577
assign 1 104 578
new 0 104 578
assign 1 104 579
new 2 104 579
throw 1 104 580
assign 1 107 582
undef 1 107 587
assign 1 108 588
labelGet 0 108 588
assign 1 110 590
heldGet 0 110 590
assign 1 110 591
aliasedGet 0 110 591
put 2 110 592
return 1 112 593
assign 1 114 595
typenameGet 0 114 595
assign 1 114 596
CLASSGet 0 114 596
assign 1 114 597
equals 1 114 597
assign 1 115 599
new 0 115 599
assign 1 116 600
new 0 116 600
assign 1 117 601
new 0 117 601
assign 1 118 602
priorPeerGet 0 118 602
assign 1 119 603
new 0 119 603
assign 1 119 606
new 0 119 606
assign 1 119 607
lesser 1 119 607
assign 1 120 609
def 1 120 614
assign 1 121 615
typenameGet 0 121 615
assign 1 121 616
DEFMODGet 0 121 616
assign 1 121 617
equals 1 121 617
assign 1 122 619
typenameGet 0 122 619
assign 1 122 620
DEFMODGet 0 122 620
assign 1 122 621
equals 1 122 621
assign 1 122 623
heldGet 0 122 623
assign 1 122 624
new 0 122 624
assign 1 122 625
equals 1 122 625
assign 1 0 627
assign 1 0 630
assign 1 0 634
assign 1 123 637
new 0 123 637
assign 1 124 640
typenameGet 0 124 640
assign 1 124 641
DEFMODGet 0 124 641
assign 1 124 642
equals 1 124 642
assign 1 124 644
heldGet 0 124 644
assign 1 124 645
new 0 124 645
assign 1 124 646
equals 1 124 646
assign 1 0 648
assign 1 0 651
assign 1 0 655
assign 1 125 658
new 0 125 658
assign 1 126 661
typenameGet 0 126 661
assign 1 126 662
DEFMODGet 0 126 662
assign 1 126 663
equals 1 126 663
assign 1 126 665
heldGet 0 126 665
assign 1 126 666
new 0 126 666
assign 1 126 667
equals 1 126 667
assign 1 0 669
assign 1 0 672
assign 1 0 676
assign 1 127 679
new 0 127 679
assign 1 129 683
priorPeerGet 0 129 683
delete 0 130 684
assign 1 131 685
assign 1 133 688
assign 1 119 691
increment 0 119 691
assign 1 137 697
new 0 137 697
heldSet 1 137 698
assign 1 138 699
heldGet 0 138 699
assign 1 138 700
fromFileGet 0 138 700
fromFileSet 1 138 701
assign 1 140 703
containedGet 0 140 703
assign 1 140 704
firstGet 0 140 704
assign 1 141 705
typenameGet 0 141 705
assign 1 141 706
IDGet 0 141 706
assign 1 141 707
equals 1 141 707
assign 1 142 709
new 0 142 709
assign 1 143 710
heldGet 0 143 710
addStep 1 143 711
assign 1 144 714
typenameGet 0 144 714
assign 1 144 715
NAMEPATHGet 0 144 715
assign 1 144 716
equals 1 144 716
assign 1 145 718
heldGet 0 145 718
assign 1 147 721
new 0 147 721
assign 1 147 722
new 2 147 722
throw 1 147 723
assign 1 149 726
heldGet 0 149 726
namepathSet 1 149 727
assign 1 150 728
heldGet 0 150 728
isFinalSet 1 150 729
assign 1 151 730
heldGet 0 151 730
isLocalSet 1 151 731
assign 1 152 732
heldGet 0 152 732
isNotNullSet 1 152 733
delete 0 153 734
print 0 155 738
assign 1 156 739
new 0 156 739
assign 1 156 740
new 2 156 740
throw 1 156 741
assign 1 159 744
containedGet 0 159 744
assign 1 159 745
firstGet 0 159 745
assign 1 160 746
typenameGet 0 160 746
assign 1 160 747
PARENSGet 0 160 747
assign 1 160 748
equals 1 160 748
assign 1 161 750
containedGet 0 161 750
assign 1 161 751
lengthGet 0 161 751
assign 1 161 752
new 0 161 752
assign 1 161 753
greater 1 161 753
assign 1 162 755
new 0 162 755
assign 1 162 756
new 2 162 756
throw 1 162 757
assign 1 165 760
containedGet 0 165 760
assign 1 165 761
firstGet 0 165 761
assign 1 166 762
typenameGet 0 166 762
assign 1 166 763
IDGet 0 166 763
assign 1 166 764
equals 1 166 764
assign 1 167 766
heldGet 0 167 766
assign 1 167 767
new 0 167 767
extendsSet 1 167 768
assign 1 168 769
heldGet 0 168 769
assign 1 168 770
extendsGet 0 168 770
assign 1 168 771
heldGet 0 168 771
addStep 1 168 772
assign 1 169 775
typenameGet 0 169 775
assign 1 169 776
NAMEPATHGet 0 169 776
assign 1 169 777
equals 1 169 777
assign 1 170 779
heldGet 0 170 779
assign 1 170 780
heldGet 0 170 780
extendsSet 1 170 781
assign 1 172 784
new 0 172 784
assign 1 172 785
new 2 172 785
throw 1 172 786
print 0 176 792
assign 1 177 793
new 0 177 793
assign 1 177 794
new 2 177 794
throw 1 177 795
delete 0 179 797
print 0 182 802
assign 1 183 803
new 0 183 803
assign 1 183 804
new 2 183 804
throw 1 183 805
assign 1 186 807
heldGet 0 186 807
assign 1 186 808
extendsGet 0 186 808
assign 1 186 809
undef 1 186 814
assign 1 186 815
heldGet 0 186 815
assign 1 186 816
namepathGet 0 186 816
assign 1 186 817
toString 0 186 817
assign 1 186 818
new 0 186 818
assign 1 186 819
notEquals 1 186 819
assign 1 0 821
assign 1 0 824
assign 1 0 828
assign 1 187 831
heldGet 0 187 831
assign 1 187 832
new 0 187 832
assign 1 187 833
new 0 187 833
assign 1 187 834
fromString 1 187 834
extendsSet 1 187 835
assign 1 190 837
nextDescendGet 0 190 837
return 1 190 838
assign 1 192 840
typenameGet 0 192 840
assign 1 192 841
METHODGet 0 192 841
assign 1 192 842
equals 1 192 842
assign 1 193 844
new 0 193 844
heldSet 1 193 845
assign 1 194 846
priorPeerGet 0 194 846
assign 1 195 847
new 0 195 847
assign 1 195 850
new 0 195 850
assign 1 195 851
lesser 1 195 851
assign 1 196 853
def 1 196 858
assign 1 197 859
typenameGet 0 197 859
assign 1 197 860
DEFMODGet 0 197 860
assign 1 197 861
equals 1 197 861
assign 1 198 863
typenameGet 0 198 863
assign 1 198 864
DEFMODGet 0 198 864
assign 1 198 865
equals 1 198 865
assign 1 198 867
heldGet 0 198 867
assign 1 198 868
new 0 198 868
assign 1 198 869
equals 1 198 869
assign 1 0 871
assign 1 0 874
assign 1 0 878
assign 1 199 881
heldGet 0 199 881
assign 1 199 882
new 0 199 882
isFinalSet 1 199 883
assign 1 200 886
typenameGet 0 200 886
assign 1 200 887
DEFMODGet 0 200 887
assign 1 200 888
equals 1 200 888
assign 1 200 890
heldGet 0 200 890
assign 1 200 891
new 0 200 891
assign 1 200 892
equals 1 200 892
assign 1 0 894
assign 1 0 897
assign 1 0 901
assign 1 202 904
new 0 202 904
assign 1 202 905
new 2 202 905
throw 1 202 906
assign 1 204 909
priorPeerGet 0 204 909
delete 0 205 910
assign 1 206 911
assign 1 208 914
assign 1 195 917
increment 0 195 917
assign 1 213 924
containedGet 0 213 924
assign 1 213 925
firstGet 0 213 925
assign 1 214 926
def 1 214 931
assign 1 215 932
nextPeerGet 0 215 932
assign 1 216 933
def 1 216 938
assign 1 217 939
nextPeerGet 0 217 939
assign 1 218 940
typenameGet 0 218 940
assign 1 218 941
IDGet 0 218 941
assign 1 218 942
equals 1 218 942
assign 1 0 944
assign 1 218 947
typenameGet 0 218 947
assign 1 218 948
NAMEPATHGet 0 218 948
assign 1 218 949
equals 1 218 949
assign 1 0 951
assign 1 0 954
assign 1 220 958
typenameGet 0 220 958
assign 1 220 959
IDGet 0 220 959
assign 1 220 960
equals 1 220 960
assign 1 221 962
new 0 221 962
assign 1 222 963
heldGet 0 222 963
addStep 1 222 964
assign 1 224 967
heldGet 0 224 967
assign 1 226 969
new 0 226 969
assign 1 227 970
new 0 227 970
isTypedSet 1 227 971
namepathSet 1 228 972
assign 1 229 973
VARGet 0 229 973
typenameSet 1 229 974
heldSet 1 230 975
assign 1 233 978
typenameGet 0 233 978
assign 1 233 979
IDGet 0 233 979
assign 1 233 980
equals 1 233 980
assign 1 234 982
heldGet 0 234 982
assign 1 234 983
heldGet 0 234 983
nameSet 1 234 984
assign 1 235 985
heldGet 0 235 985
assign 1 235 986
nameGet 0 235 986
assign 1 235 987
new 0 235 987
assign 1 235 988
getPoint 1 235 988
assign 1 235 989
isInteger 0 235 989
assign 1 236 991
new 0 236 991
assign 1 236 992
new 2 236 992
throw 1 236 993
delete 0 238 995
assign 1 240 998
new 0 240 998
assign 1 240 999
new 2 240 999
throw 1 240 1000
assign 1 243 1004
new 0 243 1004
assign 1 243 1005
new 2 243 1005
throw 1 243 1006
assign 1 246 1011
classNameGet 0 246 1011
assign 1 246 1012
new 0 246 1012
assign 1 246 1013
equals 1 246 1013
throw 1 246 1015
print 0 247 1017
assign 1 248 1018
new 0 248 1018
assign 1 248 1019
new 2 248 1019
throw 1 248 1020
assign 1 250 1022
nextDescendGet 0 250 1022
return 1 250 1023
assign 1 252 1025
constantsGet 0 252 1025
assign 1 252 1026
parensReqGet 0 252 1026
assign 1 252 1027
typenameGet 0 252 1027
assign 1 252 1028
has 1 252 1028
assign 1 253 1030
containedGet 0 253 1030
assign 1 253 1031
firstGet 0 253 1031
assign 1 254 1032
undef 1 254 1037
assign 1 0 1038
assign 1 254 1041
typenameGet 0 254 1041
assign 1 254 1042
PARENSGet 0 254 1042
assign 1 254 1043
notEquals 1 254 1043
assign 1 0 1045
assign 1 0 1048
assign 1 255 1052
new 0 255 1052
assign 1 255 1053
new 2 255 1053
throw 1 255 1054
assign 1 259 1057
typenameGet 0 259 1057
assign 1 259 1058
BRACESGet 0 259 1058
assign 1 259 1059
equals 1 259 1059
assign 1 260 1061
containerGet 0 260 1061
assign 1 261 1062
def 1 261 1067
assign 1 261 1068
typenameGet 0 261 1068
assign 1 261 1069
EXPRGet 0 261 1069
assign 1 261 1070
equals 1 261 1070
assign 1 0 1072
assign 1 0 1075
assign 1 0 1079
assign 1 262 1082
PARENSGet 0 262 1082
typenameSet 1 262 1083
assign 1 265 1086
typenameGet 0 265 1086
assign 1 265 1087
SEMIGet 0 265 1087
assign 1 265 1088
equals 1 265 1088
assign 1 266 1090
priorPeerGet 0 266 1090
assign 1 267 1091
nextAscendGet 0 267 1091
assign 1 271 1094
def 1 271 1099
assign 1 271 1100
typenameGet 0 271 1100
assign 1 271 1101
SEMIGet 0 271 1101
assign 1 271 1102
notEquals 1 271 1102
assign 1 0 1104
assign 1 0 1107
assign 1 0 1111
assign 1 271 1114
typenameGet 0 271 1114
assign 1 271 1115
BRACESGet 0 271 1115
assign 1 271 1116
notEquals 1 271 1116
assign 1 0 1118
assign 1 0 1121
assign 1 0 1125
assign 1 271 1128
typenameGet 0 271 1128
assign 1 271 1129
EXPRGet 0 271 1129
assign 1 271 1130
notEquals 1 271 1130
assign 1 0 1132
assign 1 0 1135
assign 1 0 1139
assign 1 272 1142
undef 1 272 1147
assign 1 273 1148
new 0 273 1148
prepend 1 275 1150
assign 1 276 1151
priorPeerGet 0 276 1151
assign 1 278 1157
def 1 278 1162
assign 1 279 1163
EXPRGet 0 279 1163
typenameSet 1 279 1164
heldSet 1 280 1165
assign 1 281 1166
new 1 281 1166
assign 1 282 1167
PARENSGet 0 282 1167
typenameSet 1 282 1168
addValue 1 283 1169
copyLoc 1 284 1170
assign 1 285 1171
iteratorGet 0 285 1171
assign 1 285 1174
hasNextGet 0 285 1174
assign 1 286 1176
nextGet 0 286 1176
delete 0 287 1177
addValue 1 288 1178
delete 0 295 1186
return 1 297 1188
assign 1 300 1190
nextDescendGet 0 300 1190
return 1 300 1191
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_5_BuildVisitPass5();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_5_BuildVisitPass5.bevs_inst = (BEC_5_5_5_BuildVisitPass5)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_5_BuildVisitPass5.bevs_inst;
}
}
