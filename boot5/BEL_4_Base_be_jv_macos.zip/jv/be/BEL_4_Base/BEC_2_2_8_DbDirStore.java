package be.BEL_4_Base;
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_8_DbDirStore extends BEC_2_6_6_SystemObject {
public BEC_2_2_8_DbDirStore() { }
private static byte[] becc_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_0, 0));
private static byte[] bels_1 = {};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_1, 0));
private static byte[] bels_2 = {};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_2, 0));
private static byte[] bels_3 = {};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_3, 0));
public static BEC_2_2_8_DbDirStore bevs_inst;
public BEC_2_6_10_SystemSerializer bevp_ser;
public BEC_3_2_4_4_IOFilePath bevp_storageDir;
public BEC_2_6_6_SystemObject bevp_keyEncoder;
public BEC_2_2_8_DbDirStore bem_new_2(BEC_2_4_6_TextString beva_storageDir, BEC_2_6_6_SystemObject beva__keyEncoder) throws Throwable {
this.bem_new_1(beva_storageDir);
bevp_keyEncoder = beva__keyEncoder;
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_new_1(BEC_2_4_6_TextString beva_storageDir) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_storageDir);
this.bem_pathNew_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__storageDir) throws Throwable {
bevp_ser = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevp_storageDir = beva__storageDir;
bevp_keyEncoder = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getStoreId_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_keyEncoder == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 376 */ {
bevl_storeId = (BEC_2_4_6_TextString) bevp_keyEncoder.bemd_1(1711217736, BEL_4_Base.bevn_encode_1, beva_id);
} /* Line: 377 */
 else  /* Line: 378 */ {
bevl_storeId = beva_id;
} /* Line: 379 */
return bevl_storeId;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_getPath_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpvar_phold = null;
if (beva_id == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 386 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_id.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 386 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 386 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 386 */
 else  /* Line: 386 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 386 */ {
bevt_6_tmpvar_phold = bevp_storageDir.bem_fileGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_existsGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 387 */ {
bevt_7_tmpvar_phold = bevp_storageDir.bem_fileGet_0();
bevt_7_tmpvar_phold.bem_makeDirs_0();
} /* Line: 388 */
bevl_storeId = (BEC_2_4_6_TextString) this.bem_getStoreId_1(beva_id);
bevt_8_tmpvar_phold = bevp_storageDir.bem_copy_0();
bevl_p = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpvar_phold.bem_addStep_1(bevl_storeId);
} /* Line: 391 */
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpvar_phold = null;
if (beva_id == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 397 */ {
bevt_3_tmpvar_phold = bevo_1;
bevt_2_tmpvar_phold = beva_id.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 397 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 397 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 397 */
 else  /* Line: 397 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 397 */ {
bevl_p = this.bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 399 */ {
bevt_7_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_writerGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevp_ser.bem_serialize_2(beva_object, bevt_5_tmpvar_phold);
bevt_9_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_writerGet_0();
bevt_8_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 401 */
} /* Line: 399 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_6_6_SystemObject bevl_object = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_12_tmpvar_phold = null;
if (beva_id == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevt_4_tmpvar_phold = bevo_2;
bevt_3_tmpvar_phold = beva_id.bem_notEquals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 407 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 407 */
 else  /* Line: 407 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 407 */ {
bevl_p = this.bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 409 */ {
bevt_7_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_existsGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 409 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 409 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 409 */
 else  /* Line: 409 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 409 */ {
bevt_10_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_readerGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_object = bevp_ser.bem_deserialize_1(bevt_8_tmpvar_phold);
bevt_12_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_readerGet_0();
bevt_11_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return bevl_object;
} /* Line: 412 */
} /* Line: 409 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
if (beva_id == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 419 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 419 */ {
bevt_3_tmpvar_phold = bevo_3;
bevt_2_tmpvar_phold = beva_id.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 419 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 419 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 419 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 419 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 419 */
bevl_p = this.bem_getPath_1(beva_id);
bevt_6_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_existsGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 421 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 422 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_delete_1(BEC_2_4_6_TextString beva_id) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_2_4_IOFile bevt_0_tmpvar_phold = null;
bevl_p = this.bem_getPath_1(beva_id);
bevt_0_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_0_tmpvar_phold.bem_delete_0();
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serGet_0() throws Throwable {
return bevp_ser;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_storageDirGet_0() throws Throwable {
return bevp_storageDir;
} /*method end*/
public BEC_2_6_6_SystemObject bem_storageDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_keyEncoderGet_0() throws Throwable {
return bevp_keyEncoder;
} /*method end*/
public BEC_2_6_6_SystemObject bem_keyEncoderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_keyEncoder = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {358, 359, 363, 363, 368, 369, 370, 376, 376, 377, 379, 381, 386, 386, 386, 386, 0, 0, 0, 387, 387, 387, 387, 388, 388, 390, 391, 391, 393, 397, 397, 397, 397, 0, 0, 0, 398, 399, 399, 400, 400, 400, 400, 401, 401, 401, 407, 407, 407, 407, 0, 0, 0, 408, 409, 409, 409, 409, 0, 0, 0, 410, 410, 410, 410, 411, 411, 411, 412, 415, 419, 419, 0, 419, 419, 0, 0, 419, 419, 420, 421, 421, 422, 422, 424, 424, 428, 429, 429, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 26, 27, 31, 32, 33, 39, 44, 45, 48, 50, 64, 69, 70, 71, 73, 76, 80, 83, 84, 85, 90, 91, 92, 94, 95, 96, 98, 112, 117, 118, 119, 121, 124, 128, 131, 132, 137, 138, 139, 140, 141, 142, 143, 144, 165, 170, 171, 172, 174, 177, 181, 184, 185, 190, 191, 192, 194, 197, 201, 204, 205, 206, 207, 208, 209, 210, 211, 214, 227, 232, 233, 236, 237, 239, 242, 246, 247, 249, 250, 251, 253, 254, 256, 257, 262, 263, 264, 268, 271, 275, 278, 282, 285};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 1 358 20
assign 1 359 21
assign 1 363 26
apNew 1 363 26
pathNew 1 363 27
assign 1 368 31
new 0 368 31
assign 1 369 32
assign 1 370 33
assign 1 376 39
def 1 376 44
assign 1 377 45
encode 1 377 45
assign 1 379 48
return 1 381 50
assign 1 386 64
def 1 386 69
assign 1 386 70
new 0 386 70
assign 1 386 71
notEquals 1 386 71
assign 1 0 73
assign 1 0 76
assign 1 0 80
assign 1 387 83
fileGet 0 387 83
assign 1 387 84
existsGet 0 387 84
assign 1 387 85
not 0 387 90
assign 1 388 91
fileGet 0 388 91
makeDirs 0 388 92
assign 1 390 94
getStoreId 1 390 94
assign 1 391 95
copy 0 391 95
assign 1 391 96
addStep 1 391 96
return 1 393 98
assign 1 397 112
def 1 397 117
assign 1 397 118
new 0 397 118
assign 1 397 119
notEquals 1 397 119
assign 1 0 121
assign 1 0 124
assign 1 0 128
assign 1 398 131
getPath 1 398 131
assign 1 399 132
def 1 399 137
assign 1 400 138
fileGet 0 400 138
assign 1 400 139
writerGet 0 400 139
assign 1 400 140
open 0 400 140
serialize 2 400 141
assign 1 401 142
fileGet 0 401 142
assign 1 401 143
writerGet 0 401 143
close 0 401 144
assign 1 407 165
def 1 407 170
assign 1 407 171
new 0 407 171
assign 1 407 172
notEquals 1 407 172
assign 1 0 174
assign 1 0 177
assign 1 0 181
assign 1 408 184
getPath 1 408 184
assign 1 409 185
def 1 409 190
assign 1 409 191
fileGet 0 409 191
assign 1 409 192
existsGet 0 409 192
assign 1 0 194
assign 1 0 197
assign 1 0 201
assign 1 410 204
fileGet 0 410 204
assign 1 410 205
readerGet 0 410 205
assign 1 410 206
open 0 410 206
assign 1 410 207
deserialize 1 410 207
assign 1 411 208
fileGet 0 411 208
assign 1 411 209
readerGet 0 411 209
close 0 411 210
return 1 412 211
return 1 415 214
assign 1 419 227
undef 1 419 232
assign 1 0 233
assign 1 419 236
new 0 419 236
assign 1 419 237
equals 1 419 237
assign 1 0 239
assign 1 0 242
assign 1 419 246
new 0 419 246
return 1 419 247
assign 1 420 249
getPath 1 420 249
assign 1 421 250
fileGet 0 421 250
assign 1 421 251
existsGet 0 421 251
assign 1 422 253
new 0 422 253
return 1 422 254
assign 1 424 256
new 0 424 256
return 1 424 257
assign 1 428 262
getPath 1 428 262
assign 1 429 263
fileGet 0 429 263
delete 0 429 264
return 1 0 268
assign 1 0 271
return 1 0 275
assign 1 0 278
return 1 0 282
assign 1 0 285
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -770804587: return bem_storageDirGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1335700743: return bem_serGet_0();
case 1102720804: return bem_classNameGet_0();
case 1875432906: return bem_keyEncoderGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -759722334: return bem_storageDirSet_1(bevd_0);
case 99049420: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 819712669: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 700652941: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 98246024: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1682031576: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case -393721811: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1346782996: return bem_serSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1886515159: return bem_keyEncoderSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 107034370: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_8_DbDirStore();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_8_DbDirStore.bevs_inst = (BEC_2_2_8_DbDirStore)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_8_DbDirStore.bevs_inst;
}
}
