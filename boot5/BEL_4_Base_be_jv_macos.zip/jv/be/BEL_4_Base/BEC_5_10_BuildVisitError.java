package be.BEL_4_Base;
/* File: source/build/Errors.be */
public class BEC_5_10_BuildVisitError extends BEC_6_9_SystemException {
public BEC_5_10_BuildVisitError() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {};
private static byte[] bels_1 = {0x20};
public static BEC_5_10_BuildVisitError bevs_inst;
public BEC_6_6_SystemObject bevp_msg;
public BEC_6_6_SystemObject bevp_node;
public BEC_5_10_BuildVisitError bem_new_1(BEC_6_6_SystemObject beva_msgi) throws Throwable {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public BEC_5_10_BuildVisitError bem_new_2(BEC_6_6_SystemObject beva_msgi, BEC_6_6_SystemObject beva_nodei) throws Throwable {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_6_6_SystemObject bevl_toRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
bevl_toRet = (new BEC_4_6_TextString(0, bels_0));
if (bevp_msg == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_msg);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(1, bels_1));
bevl_toRet = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
} /* Line: 28 */
if (bevp_node == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 30 */ {
bevt_6_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_newlineGet_0();
bevt_4_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_node.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
} /* Line: 31 */
bevt_8_tmpvar_phold = this.bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_8_tmpvar_phold);
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_6_6_SystemObject bem_msgGet_0() throws Throwable {
return bevp_msg;
} /*method end*/
public BEC_6_6_SystemObject bem_msgSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_msg = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_nodeGet_0() throws Throwable {
return bevp_node;
} /*method end*/
public BEC_6_6_SystemObject bem_nodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_node = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {14, 19, 20, 26, 27, 27, 28, 28, 28, 30, 30, 31, 31, 31, 31, 31, 33, 33, 34, 0, 0, 0, 0};
public static int[] bevs_smnlec
 = new int[] {13, 17, 18, 32, 33, 38, 39, 40, 41, 43, 48, 49, 50, 51, 52, 53, 55, 56, 57, 60, 63, 67, 70};
/* BEGIN LINEINFO 
assign 1 14 13
assign 1 19 17
assign 1 20 18
assign 1 26 32
new 0 26 32
assign 1 27 33
def 1 27 38
assign 1 28 39
add 1 28 39
assign 1 28 40
new 0 28 40
assign 1 28 41
add 1 28 41
assign 1 30 43
def 1 30 48
assign 1 31 49
new 0 31 49
assign 1 31 50
newlineGet 0 31 50
assign 1 31 51
add 1 31 51
assign 1 31 52
toString 0 31 52
assign 1 31 53
add 1 31 53
assign 1 33 55
getFrameText 0 33 55
assign 1 33 56
add 1 33 56
return 1 34 57
return 1 0 60
assign 1 0 63
return 1 0 67
assign 1 0 70
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1475977273: return bem_langGet_0();
case 1307921883: return bem_methodNameGet_0();
case 287040793: return bem_hashGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 786424307: return bem_tagGet_0();
case 1353219100: return bem_klassNameGet_0();
case 1820417453: return bem_create_0();
case 556476320: return bem_fileNameGet_0();
case 764669899: return bem_getFrameText_0();
case 220901978: return bem_emitLangGet_0();
case 1141730732: return bem_framesTextGet_0();
case 1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case 1305997690: return bem_msgGet_0();
case 1012494862: return bem_once_0();
case 154290862: return bem_translateEmittedException_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 314718434: return bem_print_0();
case 443216037: return bem_nodeGet_0();
case 1102720804: return bem_classNameGet_0();
case 484558571: return bem_descriptionGet_0();
case 1611190486: return bem_lineNumberGet_0();
case 2055025483: return bem_serializeContents_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1354714650: return bem_copy_0();
case 729571811: return bem_serializeToString_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1184167343: return bem_translatedGet_0();
case 734830721: return bem_framesGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1286797640: return bem_extractKlassLib_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1600108233: return bem_lineNumberSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 495640824: return bem_descriptionSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 567558573: return bem_fileNameSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1364301353: return bem_klassNameSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 745912974: return bem_framesSet_1(bevd_0);
case 454298290: return bem_nodeSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1487059526: return bem_langSet_1(bevd_0);
case 813541388: return bem_extractMethod_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1294915437: return bem_msgSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1173085090: return bem_translatedSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 205231606: return bem_getSourceFileName_1((BEC_4_6_TextString) bevd_0);
case 1319004136: return bem_methodNameSet_1(bevd_0);
case 1300981246: return bem_addFrame_1((BEC_6_9_5_SystemExceptionFrame) bevd_0);
case 371136143: return bem_extractKlass_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1130648479: return bem_framesTextSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1300981249: return bem_addFrame_4((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_10_BuildVisitError();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_10_BuildVisitError.bevs_inst = (BEC_5_10_BuildVisitError)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_10_BuildVisitError.bevs_inst;
}
}
