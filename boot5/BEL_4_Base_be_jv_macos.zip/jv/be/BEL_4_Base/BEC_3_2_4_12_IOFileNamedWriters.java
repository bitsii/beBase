package be.BEL_4_Base;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_12_IOFileNamedWriters extends BEC_2_6_6_SystemObject {
public BEC_3_2_4_12_IOFileNamedWriters() { }
private static byte[] becc_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x57,0x72,0x69,0x74,0x65,0x72,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_3_2_4_12_IOFileNamedWriters bevs_inst;
public BEC_3_2_4_6_IOFileWriter bevp_output;
public BEC_3_2_4_6_IOFileWriter bevp_error;
public BEC_3_2_4_6_IOFileWriter bevp_exceptionConsole;
public BEC_3_2_4_12_IOFileNamedWriters bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_default_0() throws Throwable {
BEC_4_2_4_6_6_IOFileWriterStdout bevt_0_tmpvar_phold = null;
BEC_4_2_4_6_6_IOFileWriterStderr bevt_1_tmpvar_phold = null;
BEC_4_2_4_6_8_IOFileWriterNoOutput bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = BEC_4_2_4_6_6_IOFileWriterStdout.bevs_inst.bem_new_0();
this.bem_outputSet_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = BEC_4_2_4_6_6_IOFileWriterStderr.bevs_inst.bem_new_0();
this.bem_errorSet_1(bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_4_2_4_6_8_IOFileWriterNoOutput) BEC_4_2_4_6_8_IOFileWriterNoOutput.bevs_inst.bem_new_0();
this.bem_exceptionConsoleSet_1(bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputSet_1(BEC_3_2_4_6_IOFileWriter beva__output) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevp_output = beva__output;
bevt_0_tmpvar_phold = bevp_output.bem_isClosedGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 579 */ {
bevp_output.bem_open_0();
} /* Line: 580 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_errorSet_1(BEC_3_2_4_6_IOFileWriter beva__error) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevp_error = beva__error;
bevt_0_tmpvar_phold = bevp_error.bem_isClosedGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 586 */ {
bevp_error.bem_open_0();
} /* Line: 587 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptionConsoleSet_1(BEC_3_2_4_6_IOFileWriter beva__exceptionConsole) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevp_exceptionConsole = beva__exceptionConsole;
bevt_0_tmpvar_phold = bevp_exceptionConsole.bem_isClosedGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 593 */ {
bevp_exceptionConsole.bem_open_0();
} /* Line: 594 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_outputGet_0() throws Throwable {
return bevp_output;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_errorGet_0() throws Throwable {
return bevp_error;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_exceptionConsoleGet_0() throws Throwable {
return bevp_exceptionConsole;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {572, 572, 573, 573, 574, 574, 578, 579, 580, 585, 586, 587, 592, 593, 594, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 21, 22, 23, 28, 29, 31, 37, 38, 40, 46, 47, 49, 54, 57, 60};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 572 18
new 0 572 18
outputSet 1 572 19
assign 1 573 20
new 0 573 20
errorSet 1 573 21
assign 1 574 22
new 0 574 22
exceptionConsoleSet 1 574 23
assign 1 578 28
assign 1 579 29
isClosedGet 0 579 29
open 0 580 31
assign 1 585 37
assign 1 586 38
isClosedGet 0 586 38
open 0 587 40
assign 1 592 46
assign 1 593 47
isClosedGet 0 593 47
open 0 594 49
return 1 0 54
return 1 0 57
return 1 0 60
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1502128718: return bem_default_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1699730337: return bem_exceptionConsoleGet_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 847016698: return bem_outputGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 1613586527: return bem_errorGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1688648084: return bem_exceptionConsoleSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1624668780: return bem_errorSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 835934445: return bem_outputSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_12_IOFileNamedWriters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_12_IOFileNamedWriters.bevs_inst = (BEC_3_2_4_12_IOFileNamedWriters)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_12_IOFileNamedWriters.bevs_inst;
}
}
