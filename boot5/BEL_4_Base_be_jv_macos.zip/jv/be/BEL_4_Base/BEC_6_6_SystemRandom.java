package be.BEL_4_Base;

import java.util.concurrent.locks.ReentrantLock;
/* File: source/base/System.be */
public class BEC_6_6_SystemRandom extends BEC_6_6_SystemObject {
public BEC_6_6_SystemRandom() { }

   
    public java.security.SecureRandom srand = new java.security.SecureRandom();
    
   private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(26));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(65));
public static BEC_6_6_SystemRandom bevs_inst;
public BEC_6_6_SystemObject bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemRandom bem_default_0() throws Throwable {
this.bem_seedNow_0();
return this;
} /*method end*/
public BEC_6_6_SystemRandom bem_seedNow_0() throws Throwable {

      srand.setSeed(srand.generateSeed(8));
      return this;
} /*method end*/
public BEC_4_3_MathInt bem_getInt_1(BEC_4_3_MathInt beva_value) throws Throwable {

      beva_value.bevi_int = srand.nextInt();
      return beva_value;
} /*method end*/
public BEC_4_3_MathInt bem_getInt_2(BEC_4_3_MathInt beva_value, BEC_4_3_MathInt beva_max) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = this.bem_getInt_1(beva_value);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_absValue_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_getString_1(BEC_4_3_MathInt beva_size) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_1(beva_size);
bevt_0_tmpvar_phold = this.bem_getString_2(bevt_1_tmpvar_phold, beva_size);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_getString_2(BEC_4_6_TextString beva_str, BEC_4_3_MathInt beva_size) throws Throwable {
BEC_4_3_MathInt bevl_value = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_str.bem_capacityGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_lesser_1(beva_size);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 274 */ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 275 */
bevt_2_tmpvar_phold = beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_tmpvar_phold);
bevl_value = (new BEC_4_3_MathInt()).bem_new_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 283 */ {
bevt_5_tmpvar_phold = bevl_i.bem_lesser_1(beva_size);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 283 */ {
bevt_9_tmpvar_phold = bevo_0;
bevt_8_tmpvar_phold = (BEC_4_3_MathInt) bevt_9_tmpvar_phold.bem_once_0();
bevt_7_tmpvar_phold = this.bem_getInt_2(bevl_value, bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_1;
bevt_10_tmpvar_phold = (BEC_4_3_MathInt) bevt_11_tmpvar_phold.bem_once_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_6_tmpvar_phold);
bevl_i.bem_incrementValue_0();
} /* Line: 283 */
 else  /* Line: 283 */ {
break;
} /* Line: 283 */
} /* Line: 283 */
return beva_str;
} /*method end*/
//int[] bevs_nlcs = {221, 262, 266, 266, 266, 266, 270, 270, 270, 274, 274, 275, 277, 277, 282, 283, 283, 285, 285, 285, 285, 285, 285, 285, 283, 287};
//int[] bevs_nlecs = {20, 31, 37, 38, 39, 40, 45, 46, 47, 64, 65, 67, 69, 70, 71, 72, 75, 77, 78, 79, 80, 81, 82, 83, 84, 90};
/* BEGIN LINEINFO 
seedNow 0 221 20
return 1 262 31
assign 1 266 37
getInt 1 266 37
assign 1 266 38
absValue 0 266 38
assign 1 266 39
modulusValue 1 266 39
return 1 266 40
assign 1 270 45
new 1 270 45
assign 1 270 46
getString 2 270 46
return 1 270 47
assign 1 274 64
capacityGet 0 274 64
assign 1 274 65
lesser 1 274 65
capacitySet 1 275 67
assign 1 277 69
copy 0 277 69
sizeSet 1 277 70
assign 1 282 71
new 0 282 71
assign 1 283 72
new 0 283 72
assign 1 283 75
lesser 1 283 75
assign 1 285 77
new 0 285 77
assign 1 285 78
once 0 285 78
assign 1 285 79
getInt 2 285 79
assign 1 285 80
new 0 285 80
assign 1 285 81
once 0 285 81
assign 1 285 82
addValue 1 285 82
setIntUnchecked 2 285 83
incrementValue 0 283 84
return 1 287 90
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 613284118: return bem_seedNow_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 422057735: return bem_getString_1((BEC_4_3_MathInt) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1956186667: return bem_getInt_1((BEC_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1956186668: return bem_getInt_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 422057734: return bem_getString_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_6_SystemRandom();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_6_SystemRandom.bevs_inst = (BEC_6_6_SystemRandom)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_6_SystemRandom.bevs_inst;
}
}
