package be.BEL_4_Base;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList extends BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_10_ContainerLinkedList bevs_inst;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public BEC_2_9_10_ContainerLinkedList bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_copy_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) this.bem_create_0();
bevl_iter = this.bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 142 */ {
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /* Line: 143 */
while (true)
 /* Line: 147 */ {
if (bevl_f == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 147 */ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 149 */ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 150 */
if (bevl_fnode == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 153 */ {
bevl_fnode = bevl_f;
} /* Line: 154 */
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 157 */
 else  /* Line: 147 */ {
break;
} /* Line: 147 */
} /* Line: 147 */
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_9_10_ContainerLinkedList) bevl_other;
} /*method end*/
public BEC_2_6_6_SystemObject bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, null);
if (bevp_lastNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 166 */ {
beva_node.bemd_1(957596394, BEL_4_Base.bevn_priorSet_1, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 169 */
 else  /* Line: 170 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 172 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, null);
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 178 */ {
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 181 */
 else  /* Line: 182 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 184 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_1(1505376950, BEL_4_Base.bevn_insertBefore_1, beva_toIns);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
if (beva_pos.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 197 */ {
bevt_2_tmpvar_phold = bevp_firstNode.bem_heldGet_0();
return bevt_2_tmpvar_phold;
} /* Line: 198 */
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 201 */ {
bevt_3_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 201 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 203 */
 else  /* Line: 204 */ {
break;
} /* Line: 205 */
bevl_i.bevi_int++;
} /* Line: 207 */
 else  /* Line: 201 */ {
break;
} /* Line: 201 */
} /* Line: 201 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 209 */ {
return null;
} /* Line: 210 */
bevt_6_tmpvar_phold = bevl_iter.bem_nextGet_0();
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_1;
beva_pos = beva_pos.bem_add_1(bevt_0_tmpvar_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 218 */ {
bevt_1_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 218 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 219 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 220 */
 else  /* Line: 221 */ {
break;
} /* Line: 222 */
bevl_i.bevi_int++;
} /* Line: 224 */
 else  /* Line: 218 */ {
break;
} /* Line: 218 */
} /* Line: 218 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 226 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 227 */
bevt_5_tmpvar_phold = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 233 */ {
return null;
} /* Line: 233 */
bevt_1_tmpvar_phold = bevp_firstNode.bem_heldGet_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_3_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
 else  /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 238 */ {
bevt_5_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_heldGet_0();
return bevt_4_tmpvar_phold;
} /* Line: 239 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_4_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 245 */
 else  /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 245 */ {
bevt_7_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_nextGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 245 */
 else  /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 245 */ {
bevt_10_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_nextGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_heldGet_0();
return bevt_8_tmpvar_phold;
} /* Line: 246 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (bevp_lastNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 252 */ {
return null;
} /* Line: 252 */
bevt_1_tmpvar_phold = bevp_lastNode.bem_heldGet_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpvar_phold = beva_pos.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 257 */ {
return bevp_firstNode;
} /* Line: 258 */
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 261 */ {
bevt_2_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 261 */ {
bevt_3_tmpvar_phold = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 263 */
 else  /* Line: 264 */ {
break;
} /* Line: 265 */
bevl_i.bevi_int++;
} /* Line: 267 */
 else  /* Line: 261 */ {
break;
} /* Line: 261 */
} /* Line: 261 */
bevt_4_tmpvar_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 269 */ {
return null;
} /* Line: 270 */
bevt_5_tmpvar_phold = bevl_iter.bem_nextNodeGet_0();
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = this.bem_newNode_1(beva_held);
this.bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addValue_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_held == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 281 */ {
bevt_2_tmpvar_phold = beva_held.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 281 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 281 */
 else  /* Line: 281 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 281 */ {
this.bem_addAll_1(beva_held);
} /* Line: 282 */
 else  /* Line: 283 */ {
this.bem_addValueWhole_1(beva_held);
} /* Line: 284 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 289 */ {
while (true)
 /* Line: 290 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpvar_phold);
} /* Line: 291 */
 else  /* Line: 290 */ {
break;
} /* Line: 290 */
} /* Line: 290 */
} /* Line: 290 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 298 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepend_1(BEC_2_6_6_SystemObject beva_held) throws Throwable {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = this.bem_newNode_1(beva_held);
this.bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
return bevl_cnt;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_lengthGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_1_tmpvar_phold;
} /* Line: 322 */
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_toNodeArray_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_5_ContainerArray bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_len = this.bem_lengthGet_0();
bevl_toret = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 331 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 331 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 332 */ {
bevt_2_tmpvar_phold = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpvar_phold);
} /* Line: 333 */
bevl_cnt.bevi_int++;
} /* Line: 335 */
 else  /* Line: 331 */ {
break;
} /* Line: 331 */
} /* Line: 331 */
return bevl_toret;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_toArray_0() throws Throwable {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_5_ContainerArray bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_len = this.bem_lengthGet_0();
bevl_toret = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_2_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 344 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 344 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 345 */ {
bevt_3_tmpvar_phold = bevl_i.bem_nextNodeGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpvar_phold);
} /* Line: 346 */
bevl_cnt.bevi_int++;
} /* Line: 348 */
 else  /* Line: 344 */ {
break;
} /* Line: 344 */
} /* Line: 344 */
return bevl_toret;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_4_MathInts bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bevs_inst;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_maxGet_0();
bevt_0_tmpvar_phold = this.bem_subList_2(beva_start, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) this.bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 371 */ {
return bevl_res;
} /* Line: 372 */
bevl_iter = this.bem_linkedListIteratorGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 375 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 375 */ {
bevt_3_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 376 */ {
return bevl_res;
} /* Line: 377 */
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 381 */
bevl_i.bevi_int++;
} /* Line: 375 */
 else  /* Line: 375 */ {
break;
} /* Line: 375 */
} /* Line: 375 */
return bevl_res;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_reverse_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_tmpvar_phold = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
 /* Line: 424 */ {
if (bevl_current == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_tmpvar_phold = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_tmpvar_phold);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 429 */
 else  /* Line: 424 */ {
break;
} /* Line: 424 */
} /* Line: 424 */
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {134, 134, 139, 140, 141, 142, 142, 143, 147, 147, 148, 149, 149, 150, 153, 153, 154, 156, 157, 159, 160, 161, 165, 166, 166, 167, 168, 169, 171, 172, 177, 178, 178, 179, 180, 181, 183, 184, 189, 193, 197, 197, 197, 198, 198, 200, 201, 201, 202, 202, 203, 207, 209, 209, 210, 212, 212, 216, 216, 217, 218, 218, 219, 219, 220, 224, 226, 226, 227, 227, 229, 229, 233, 233, 233, 234, 234, 238, 238, 238, 238, 238, 0, 0, 0, 239, 239, 239, 241, 245, 245, 245, 245, 245, 0, 0, 0, 245, 245, 245, 245, 0, 0, 0, 246, 246, 246, 246, 248, 252, 252, 252, 253, 253, 257, 257, 258, 260, 261, 261, 262, 263, 267, 269, 270, 272, 272, 276, 277, 281, 281, 281, 0, 0, 0, 282, 284, 289, 289, 290, 291, 291, 297, 297, 298, 298, 303, 304, 308, 309, 309, 310, 311, 313, 317, 317, 321, 321, 322, 322, 324, 324, 328, 329, 330, 331, 331, 332, 332, 333, 333, 335, 337, 341, 342, 343, 344, 344, 345, 345, 346, 346, 346, 348, 350, 354, 354, 358, 358, 362, 362, 366, 366, 366, 366, 370, 371, 371, 372, 374, 375, 375, 375, 376, 376, 377, 379, 380, 380, 381, 375, 384, 422, 423, 424, 424, 425, 426, 426, 427, 428, 429, 431, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 30, 31, 32, 33, 38, 39, 43, 48, 49, 50, 55, 56, 58, 63, 64, 66, 67, 73, 74, 75, 79, 80, 85, 86, 87, 88, 91, 92, 98, 99, 104, 105, 106, 107, 110, 111, 116, 120, 133, 134, 139, 140, 141, 143, 144, 147, 149, 154, 155, 160, 166, 171, 172, 174, 175, 186, 187, 188, 189, 192, 194, 199, 200, 205, 211, 216, 217, 218, 220, 221, 226, 231, 232, 234, 235, 244, 249, 250, 251, 256, 257, 260, 264, 267, 268, 269, 271, 285, 290, 291, 292, 297, 298, 301, 305, 308, 309, 310, 315, 316, 319, 323, 326, 327, 328, 329, 331, 336, 341, 342, 344, 345, 356, 357, 359, 361, 362, 365, 367, 369, 374, 380, 382, 384, 385, 389, 390, 397, 402, 403, 405, 408, 412, 415, 418, 426, 431, 434, 436, 437, 449, 454, 455, 456, 462, 463, 470, 471, 474, 476, 477, 483, 487, 488, 494, 499, 500, 501, 503, 504, 514, 515, 516, 517, 520, 522, 527, 528, 529, 531, 537, 548, 549, 550, 551, 554, 556, 561, 562, 563, 564, 566, 572, 576, 577, 581, 582, 586, 587, 593, 594, 595, 596, 608, 609, 614, 615, 617, 618, 621, 626, 627, 628, 630, 632, 633, 638, 639, 641, 647, 655, 656, 659, 664, 665, 666, 667, 668, 669, 670, 676, 680, 683, 687, 690};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 134 17
new 2 134 17
return 1 134 18
assign 1 139 30
create 0 139 30
assign 1 140 31
linkedListIteratorGet 0 140 31
assign 1 141 32
nextNodeGet 0 141 32
assign 1 142 33
undef 1 142 38
return 1 143 39
assign 1 147 43
def 1 147 48
assign 1 148 49
copy 0 148 49
assign 1 149 50
def 1 149 55
nextSet 1 150 56
assign 1 153 58
undef 1 153 63
assign 1 154 64
assign 1 156 66
assign 1 157 67
nextNodeGet 0 157 67
firstNodeSet 1 159 73
lastNodeSet 1 160 74
return 1 161 75
nextSet 1 165 79
assign 1 166 80
def 1 166 85
priorSet 1 167 86
nextSet 1 168 87
assign 1 169 88
assign 1 171 91
assign 1 172 92
nextSet 1 177 98
assign 1 178 99
def 1 178 104
nextSet 1 179 105
priorSet 1 180 106
assign 1 181 107
assign 1 183 110
assign 1 184 111
delete 0 189 116
insertBefore 1 193 120
assign 1 197 133
new 0 197 133
assign 1 197 134
equals 1 197 139
assign 1 198 140
heldGet 0 198 140
return 1 198 141
assign 1 200 143
new 0 200 143
assign 1 201 144
linkedListIteratorGet 0 201 144
assign 1 201 147
hasNextGet 0 201 147
assign 1 202 149
lesser 1 202 154
nextGet 0 203 155
incrementValue 0 207 160
assign 1 209 166
notEquals 1 209 171
return 1 210 172
assign 1 212 174
nextGet 0 212 174
return 1 212 175
assign 1 216 186
new 0 216 186
assign 1 216 187
add 1 216 187
assign 1 217 188
new 0 217 188
assign 1 218 189
linkedListIteratorGet 0 218 189
assign 1 218 192
hasNextGet 0 218 192
assign 1 219 194
lesser 1 219 199
nextGet 0 220 200
incrementValue 0 224 205
assign 1 226 211
notEquals 1 226 216
assign 1 227 217
new 0 227 217
return 1 227 218
assign 1 229 220
currentSet 1 229 220
return 1 229 221
assign 1 233 226
undef 1 233 231
return 1 233 232
assign 1 234 234
heldGet 0 234 234
return 1 234 235
assign 1 238 244
def 1 238 249
assign 1 238 250
nextGet 0 238 250
assign 1 238 251
def 1 238 256
assign 1 0 257
assign 1 0 260
assign 1 0 264
assign 1 239 267
nextGet 0 239 267
assign 1 239 268
heldGet 0 239 268
return 1 239 269
return 1 241 271
assign 1 245 285
def 1 245 290
assign 1 245 291
nextGet 0 245 291
assign 1 245 292
def 1 245 297
assign 1 0 298
assign 1 0 301
assign 1 0 305
assign 1 245 308
nextGet 0 245 308
assign 1 245 309
nextGet 0 245 309
assign 1 245 310
def 1 245 315
assign 1 0 316
assign 1 0 319
assign 1 0 323
assign 1 246 326
nextGet 0 246 326
assign 1 246 327
nextGet 0 246 327
assign 1 246 328
heldGet 0 246 328
return 1 246 329
return 1 248 331
assign 1 252 336
undef 1 252 341
return 1 252 342
assign 1 253 344
heldGet 0 253 344
return 1 253 345
assign 1 257 356
new 0 257 356
assign 1 257 357
equals 1 257 357
return 1 258 359
assign 1 260 361
new 0 260 361
assign 1 261 362
linkedListIteratorGet 0 261 362
assign 1 261 365
hasNextGet 0 261 365
assign 1 262 367
lesser 1 262 367
nextGet 0 263 369
incrementValue 0 267 374
assign 1 269 380
notEquals 1 269 380
return 1 270 382
assign 1 272 384
nextNodeGet 0 272 384
return 1 272 385
assign 1 276 389
newNode 1 276 389
appendNode 1 277 390
assign 1 281 397
def 1 281 402
assign 1 281 403
sameType 1 281 403
assign 1 0 405
assign 1 0 408
assign 1 0 412
addAll 1 282 415
addValueWhole 1 284 418
assign 1 289 426
def 1 289 431
assign 1 290 434
hasNextGet 0 290 434
assign 1 291 436
nextGet 0 291 436
addValueWhole 1 291 437
assign 1 297 449
def 1 297 454
assign 1 298 455
iteratorGet 0 298 455
iterateAdd 1 298 456
assign 1 303 462
newNode 1 303 462
prependNode 1 304 463
assign 1 308 470
new 0 308 470
assign 1 309 471
linkedListIteratorGet 0 309 471
assign 1 309 474
hasNextGet 0 309 474
nextGet 0 310 476
incrementValue 0 311 477
return 1 313 483
assign 1 317 487
lengthGet 0 317 487
return 1 317 488
assign 1 321 494
undef 1 321 499
assign 1 322 500
new 0 322 500
return 1 322 501
assign 1 324 503
new 0 324 503
return 1 324 504
assign 1 328 514
lengthGet 0 328 514
assign 1 329 515
new 1 329 515
assign 1 330 516
new 0 330 516
assign 1 331 517
linkedListIteratorGet 0 331 517
assign 1 331 520
hasNextGet 0 331 520
assign 1 332 522
lesser 1 332 527
assign 1 333 528
nextNodeGet 0 333 528
put 2 333 529
incrementValue 0 335 531
return 1 337 537
assign 1 341 548
lengthGet 0 341 548
assign 1 342 549
new 1 342 549
assign 1 343 550
new 0 343 550
assign 1 344 551
linkedListIteratorGet 0 344 551
assign 1 344 554
hasNextGet 0 344 554
assign 1 345 556
lesser 1 345 561
assign 1 346 562
nextNodeGet 0 346 562
assign 1 346 563
heldGet 0 346 563
put 2 346 564
incrementValue 0 348 566
return 1 350 572
assign 1 354 576
new 1 354 576
return 1 354 577
assign 1 358 581
new 1 358 581
return 1 358 582
assign 1 362 586
iteratorGet 0 362 586
return 1 362 587
assign 1 366 593
new 0 366 593
assign 1 366 594
maxGet 0 366 594
assign 1 366 595
subList 2 366 595
return 1 366 596
assign 1 370 608
create 0 370 608
assign 1 371 609
lesserEquals 1 371 614
return 1 372 615
assign 1 374 617
linkedListIteratorGet 0 374 617
assign 1 375 618
new 0 375 618
assign 1 375 621
lesser 1 375 626
assign 1 376 627
hasNextGet 0 376 627
assign 1 376 628
not 0 376 628
return 1 377 630
assign 1 379 632
nextGet 0 379 632
assign 1 380 633
greaterEquals 1 380 638
addValue 1 381 639
incrementValue 0 375 641
return 1 384 647
assign 1 422 655
assign 1 423 656
assign 1 424 659
def 1 424 664
assign 1 425 665
nextGet 0 425 665
assign 1 426 666
priorGet 0 426 666
nextSet 1 426 667
priorSet 1 427 668
assign 1 428 669
assign 1 429 670
assign 1 431 676
return 1 0 680
assign 1 0 683
return 1 0 687
assign 1 0 690
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 789570067: return bem_toNodeArray_0();
case 390409747: return bem_reverse_0();
case 1696089045: return bem_firstNodeGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1616433729: return bem_lengthGet_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 183400265: return bem_firstGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1897309391: return bem_toArray_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 978128800: return bem_thirdGet_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1820417453: return bem_create_0();
case 1990707345: return bem_lastGet_0();
case 1351154001: return bem_lastNodeGet_0();
case 786424307: return bem_tagGet_0();
case 242848115: return bem_secondGet_0();
case 1354714650: return bem_copy_0();
case 874473310: return bem_linkedListIteratorGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 228068295: return bem_addValueWhole_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 908228929: return bem_deleteNode_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1707171298: return bem_firstNodeSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 655844394: return bem_getNode_1(bevd_0);
case 596113616: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 743891212: return bem_newNode_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1167376622: return bem_appendNode_1(bevd_0);
case 1340071748: return bem_lastNodeSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1007846464: return bem_prepend_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1142954398: return bem_prependNode_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 107034370: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 596113615: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1098622227: return bem_insertBeforeNode_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_10_ContainerLinkedList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_10_ContainerLinkedList.bevs_inst = (BEC_2_9_10_ContainerLinkedList)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_10_ContainerLinkedList.bevs_inst;
}
}
