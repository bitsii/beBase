package be.BEL_4_Base;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_3_ContainerSet bevs_inst;
public BEC_2_9_5_ContainerArray bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_5_ContainerArray()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
if (bevp_size.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 241 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
if (bevp_size.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /* Line: 248 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_5_ContainerArray beva_ninner, BEC_2_9_5_ContainerArray beva_ir) throws Throwable {
BEC_3_9_5_8_ContainerArrayIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
 /* Line: 266 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevt_4_tmpvar_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpvar_phold = this.bem_innerPut_4(bevt_4_tmpvar_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 269 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 270 */
} /* Line: 269 */
} /* Line: 268 */
 else  /* Line: 266 */ {
break;
} /* Line: 266 */
} /* Line: 266 */
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_5_ContainerArray beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_5_ContainerArray bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpvar_phold = bevo_2;
bevl_nslots = bevt_0_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
bevl_ninner = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 281 */ {
bevt_4_tmpvar_phold = this.bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevl_nslots);
} /* Line: 283 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (beva_other == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 289 */ {
bevt_4_tmpvar_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpvar_phold = this.bem_sizeGet_0();
if (bevt_4_tmpvar_phold.bevi_int != bevt_5_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 289 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 289 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 289 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 290 */
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 292 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevl_i = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_9_tmpvar_phold = beva_other.bem_has_1(bevl_i);
if (bevt_9_tmpvar_phold.bevi_bool) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_10_tmpvar_phold;
} /* Line: 293 */
} /* Line: 293 */
 else  /* Line: 292 */ {
break;
} /* Line: 292 */
} /* Line: 292 */
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_5_ContainerArray beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_3;
if (bevl_hval.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 302 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 303 */
} /* Line: 302 */
 else  /* Line: 305 */ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(449328306, BEL_4_Base.bevn_hvalGet_0);
} /* Line: 306 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 310 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 312 */ {
if (beva_inode == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_6_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpvar_phold);
} /* Line: 314 */
 else  /* Line: 315 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 316 */
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 319 */
 else  /* Line: 312 */ {
bevt_10_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_9_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 320 */ {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /* Line: 321 */
 else  /* Line: 312 */ {
bevt_13_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpvar_phold, beva_k);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 322 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_14_tmpvar_phold;
} /* Line: 326 */
 else  /* Line: 327 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 329 */ {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_16_tmpvar_phold;
} /* Line: 330 */
} /* Line: 329 */
} /* Line: 312 */
} /* Line: 312 */
} /* Line: 312 */
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 337 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 340 */ {
bevt_3_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 340 */ {
bevl_slt = (BEC_2_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
} /* Line: 341 */
 else  /* Line: 340 */ {
break;
} /* Line: 340 */
} /* Line: 340 */
bevp_slots = bevl_slt;
} /* Line: 343 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 345 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 346 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_4;
if (bevl_hval.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 355 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 359 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 361 */ {
return null;
} /* Line: 362 */
 else  /* Line: 361 */ {
bevt_5_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_4_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 363 */ {
return null;
} /* Line: 364 */
 else  /* Line: 361 */ {
bevt_7_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpvar_phold, beva_k);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 365 */ {
bevt_8_tmpvar_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpvar_phold;
} /* Line: 366 */
 else  /* Line: 367 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 369 */ {
return null;
} /* Line: 370 */
} /* Line: 369 */
} /* Line: 361 */
} /* Line: 361 */
} /* Line: 361 */
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_5;
if (bevl_hval.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 381 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 385 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 387 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 388 */
 else  /* Line: 387 */ {
bevt_6_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_5_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /* Line: 390 */
 else  /* Line: 387 */ {
bevt_9_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpvar_phold, beva_k);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 391 */ {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 392 */
 else  /* Line: 393 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 395 */ {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /* Line: 396 */
} /* Line: 395 */
} /* Line: 387 */
} /* Line: 387 */
} /* Line: 387 */
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_6;
if (bevl_hval.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 408 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 412 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 414 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 415 */
 else  /* Line: 414 */ {
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_6_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 416 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 417 */
 else  /* Line: 414 */ {
bevt_10_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpvar_phold, beva_k);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 418 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 422 */ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 422 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 424 */ {
bevt_15_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_14_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 424 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 424 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 424 */ {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_16_tmpvar_phold;
} /* Line: 425 */
 else  /* Line: 426 */ {
bevt_18_tmpvar_phold = bevo_7;
bevt_17_tmpvar_phold = bevl_sl.bem_subtract_1(bevt_18_tmpvar_phold);
bevl_slt.bem_put_2(bevt_17_tmpvar_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 428 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 430 */
 else  /* Line: 422 */ {
break;
} /* Line: 422 */
} /* Line: 422 */
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_19_tmpvar_phold;
} /* Line: 432 */
 else  /* Line: 433 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 435 */ {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_21_tmpvar_phold;
} /* Line: 436 */
} /* Line: 435 */
} /* Line: 414 */
} /* Line: 414 */
} /* Line: 414 */
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
bevl_other = this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = bevp_slots.bem_copy_0();
bevl_other.bemd_1(365988447, BEL_4_Base.bevn_slotsSet_1, bevt_0_tmpvar_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 446 */ {
bevt_2_tmpvar_phold = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 446 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 448 */ {
bevt_4_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_6_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_new_3(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_4_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_5_tmpvar_phold);
} /* Line: 449 */
 else  /* Line: 450 */ {
bevt_10_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_10_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, null);
} /* Line: 451 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 446 */
 else  /* Line: 446 */ {
break;
} /* Line: 446 */
} /* Line: 446 */
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_6_6_SystemObject bem_clear_0() throws Throwable {
bevp_slots.bem_clear_0();
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_keyIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_nodeIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 489 */ {
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 490 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 490 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_3_tmpvar_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 491 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 492 */
} /* Line: 491 */
 else  /* Line: 490 */ {
break;
} /* Line: 490 */
} /* Line: 490 */
} /* Line: 490 */
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 501 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 501 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 502 */
 else  /* Line: 501 */ {
break;
} /* Line: 501 */
} /* Line: 501 */
if (beva_other == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 504 */ {
bevt_1_tmpvar_loop = beva_other.bem_setIteratorGet_0();
while (true)
 /* Line: 505 */ {
bevt_4_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 505 */ {
bevl_x = bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 506 */
 else  /* Line: 505 */ {
break;
} /* Line: 505 */
} /* Line: 505 */
} /* Line: 505 */
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = this.bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 519 */ {
bevt_2_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 520 */ {
bevt_0_tmpvar_loop = beva_other.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 521 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 521 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_put_1(bevl_x);
} /* Line: 522 */
 else  /* Line: 521 */ {
break;
} /* Line: 521 */
} /* Line: 521 */
} /* Line: 521 */
 else  /* Line: 520 */ {
bevt_4_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 524 */ {
bevt_5_tmpvar_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
this.bem_put_1(bevt_5_tmpvar_phold);
} /* Line: 525 */
 else  /* Line: 526 */ {
this.bem_put_1(beva_other);
} /* Line: 527 */
} /* Line: 520 */
} /* Line: 520 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_2_6_6_SystemObject bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_slots = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_2_6_6_SystemObject bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiGet_0() throws Throwable {
return bevp_multi;
} /*method end*/
public BEC_2_6_6_SystemObject bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() throws Throwable {
return bevp_rel;
} /*method end*/
public BEC_2_6_6_SystemObject bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {222, 222, 228, 229, 230, 231, 232, 233, 234, 240, 240, 240, 241, 241, 243, 243, 247, 247, 247, 248, 248, 250, 250, 254, 254, 258, 258, 262, 262, 266, 266, 267, 268, 268, 269, 269, 269, 270, 270, 274, 274, 279, 279, 279, 279, 280, 281, 281, 282, 283, 285, 289, 289, 0, 289, 289, 289, 289, 0, 0, 290, 290, 292, 0, 292, 292, 293, 293, 293, 293, 293, 295, 295, 299, 300, 300, 301, 302, 302, 302, 303, 306, 308, 309, 311, 312, 312, 313, 313, 314, 314, 314, 316, 318, 319, 319, 320, 320, 320, 320, 321, 321, 322, 322, 323, 325, 326, 326, 328, 329, 329, 330, 330, 337, 337, 338, 339, 340, 340, 341, 343, 346, 351, 352, 353, 354, 354, 354, 355, 357, 358, 360, 361, 361, 362, 363, 363, 363, 363, 364, 365, 365, 366, 366, 368, 369, 369, 370, 377, 378, 379, 380, 380, 380, 381, 383, 384, 386, 387, 387, 388, 388, 389, 389, 389, 389, 390, 390, 391, 391, 392, 392, 394, 395, 395, 396, 396, 403, 404, 406, 407, 407, 407, 408, 410, 411, 413, 414, 414, 415, 415, 416, 416, 416, 416, 417, 417, 418, 418, 419, 420, 421, 422, 422, 423, 424, 424, 0, 424, 424, 424, 424, 0, 0, 425, 425, 427, 427, 427, 428, 430, 432, 432, 434, 435, 435, 436, 436, 443, 444, 445, 445, 446, 446, 446, 446, 447, 448, 448, 449, 449, 449, 449, 449, 449, 449, 451, 451, 446, 454, 459, 460, 464, 464, 468, 468, 472, 472, 476, 476, 480, 480, 484, 484, 488, 489, 489, 490, 0, 490, 490, 491, 492, 496, 500, 501, 0, 501, 501, 502, 504, 504, 505, 0, 505, 505, 506, 509, 513, 514, 515, 519, 519, 520, 521, 0, 521, 521, 522, 524, 525, 525, 527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 30, 31, 32, 33, 34, 35, 36, 44, 45, 50, 51, 52, 54, 55, 62, 63, 68, 69, 70, 72, 73, 77, 78, 82, 83, 88, 89, 101, 104, 106, 107, 112, 113, 114, 115, 117, 118, 126, 127, 137, 138, 139, 140, 141, 144, 145, 147, 148, 154, 170, 175, 176, 179, 180, 181, 186, 187, 190, 194, 195, 197, 197, 200, 202, 203, 204, 209, 210, 211, 218, 219, 244, 245, 250, 251, 252, 253, 258, 259, 263, 265, 266, 269, 270, 275, 276, 281, 282, 283, 284, 287, 289, 290, 291, 294, 295, 296, 301, 302, 303, 306, 307, 309, 310, 311, 312, 315, 316, 321, 322, 323, 336, 337, 339, 340, 343, 344, 346, 352, 355, 376, 377, 378, 379, 380, 385, 386, 388, 389, 392, 393, 398, 399, 402, 403, 404, 409, 410, 413, 414, 416, 417, 420, 421, 426, 427, 454, 455, 456, 457, 458, 463, 464, 466, 467, 470, 471, 476, 477, 478, 481, 482, 483, 488, 489, 490, 493, 494, 496, 497, 500, 501, 506, 507, 508, 544, 545, 546, 547, 548, 553, 554, 556, 557, 560, 561, 566, 567, 568, 571, 572, 573, 578, 579, 580, 583, 584, 586, 587, 588, 591, 596, 597, 598, 603, 604, 607, 608, 609, 614, 615, 618, 622, 623, 626, 627, 628, 629, 631, 637, 638, 641, 642, 647, 648, 649, 671, 672, 673, 674, 675, 678, 679, 684, 685, 686, 691, 692, 693, 694, 695, 696, 697, 698, 701, 702, 704, 710, 713, 714, 719, 720, 724, 725, 729, 730, 734, 735, 739, 740, 744, 745, 754, 755, 760, 761, 761, 764, 766, 767, 769, 777, 787, 788, 788, 791, 793, 794, 800, 805, 806, 806, 809, 811, 812, 819, 823, 824, 825, 835, 840, 841, 843, 843, 846, 848, 849, 857, 859, 860, 863, 870, 873, 877, 880, 884, 887, 891, 894, 898, 901, 905, 908, 912, 915};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 222 25
new 0 222 25
new 1 222 26
assign 1 228 30
new 1 228 30
assign 1 229 31
assign 1 230 32
new 0 230 32
assign 1 231 33
new 0 231 33
assign 1 232 34
new 0 232 34
assign 1 233 35
new 0 233 35
assign 1 234 36
new 0 234 36
assign 1 240 44
new 0 240 44
assign 1 240 45
equals 1 240 50
assign 1 241 51
new 0 241 51
return 1 241 52
assign 1 243 54
new 0 243 54
return 1 243 55
assign 1 247 62
new 0 247 62
assign 1 247 63
equals 1 247 68
assign 1 248 69
new 0 248 69
return 1 248 70
assign 1 250 72
new 0 250 72
return 1 250 73
assign 1 254 77
toString 0 254 77
return 1 254 78
assign 1 258 82
new 1 258 82
new 1 258 83
assign 1 262 88
new 1 262 88
return 1 262 89
assign 1 266 101
arrayIteratorGet 0 266 101
assign 1 266 104
hasNextGet 0 266 104
assign 1 267 106
nextGet 0 267 106
assign 1 268 107
def 1 268 112
assign 1 269 113
keyGet 0 269 113
assign 1 269 114
innerPut 4 269 114
assign 1 269 115
not 0 269 115
assign 1 270 117
new 0 270 117
return 1 270 118
assign 1 274 126
new 0 274 126
return 1 274 127
assign 1 279 137
sizeGet 0 279 137
assign 1 279 138
multiply 1 279 138
assign 1 279 139
new 0 279 139
assign 1 279 140
add 1 279 140
assign 1 280 141
new 1 280 141
assign 1 281 144
insertAll 2 281 144
assign 1 281 145
not 0 281 145
assign 1 282 147
increment 0 282 147
assign 1 283 148
new 1 283 148
return 1 285 154
assign 1 289 170
undef 1 289 175
assign 1 0 176
assign 1 289 179
sizeGet 0 289 179
assign 1 289 180
sizeGet 0 289 180
assign 1 289 181
notEquals 1 289 186
assign 1 0 187
assign 1 0 190
assign 1 290 194
new 0 290 194
return 1 290 195
assign 1 292 197
setIteratorGet 0 0 197
assign 1 292 200
hasNextGet 0 292 200
assign 1 292 202
nextGet 0 292 202
assign 1 293 203
has 1 293 203
assign 1 293 204
not 0 293 209
assign 1 293 210
new 0 293 210
return 1 293 211
assign 1 295 218
new 0 295 218
return 1 295 219
assign 1 299 244
sizeGet 0 299 244
assign 1 300 245
undef 1 300 250
assign 1 301 251
getHash 1 301 251
assign 1 302 252
new 0 302 252
assign 1 302 253
lesser 1 302 258
assign 1 303 259
abs 0 303 259
assign 1 306 263
hvalGet 0 306 263
assign 1 308 265
modulus 1 308 265
assign 1 309 266
assign 1 311 269
get 1 311 269
assign 1 312 270
undef 1 312 275
assign 1 313 276
undef 1 313 281
assign 1 314 282
create 0 314 282
assign 1 314 283
new 3 314 283
put 2 314 284
put 2 316 287
assign 1 318 289
new 0 318 289
assign 1 319 290
new 0 319 290
return 1 319 291
assign 1 320 294
hvalGet 0 320 294
assign 1 320 295
modulus 1 320 295
assign 1 320 296
notEquals 1 320 301
assign 1 321 302
new 0 321 302
return 1 321 303
assign 1 322 306
keyGet 0 322 306
assign 1 322 307
isEqual 2 322 307
putTo 2 323 309
assign 1 325 310
new 0 325 310
assign 1 326 311
new 0 326 311
return 1 326 312
assign 1 328 315
increment 0 328 315
assign 1 329 316
greaterEquals 1 329 321
assign 1 330 322
new 0 330 322
return 1 330 323
assign 1 337 336
innerPut 4 337 336
assign 1 337 337
not 0 337 337
assign 1 338 339
assign 1 339 340
rehash 1 339 340
assign 1 340 343
innerPut 4 340 343
assign 1 340 344
not 0 340 344
assign 1 341 346
rehash 1 341 346
assign 1 343 352
assign 1 346 355
increment 0 346 355
assign 1 351 376
assign 1 352 377
sizeGet 0 352 377
assign 1 353 378
getHash 1 353 378
assign 1 354 379
new 0 354 379
assign 1 354 380
lesser 1 354 385
assign 1 355 386
abs 0 355 386
assign 1 357 388
modulus 1 357 388
assign 1 358 389
assign 1 360 392
get 1 360 392
assign 1 361 393
undef 1 361 398
return 1 362 399
assign 1 363 402
hvalGet 0 363 402
assign 1 363 403
modulus 1 363 403
assign 1 363 404
notEquals 1 363 409
return 1 364 410
assign 1 365 413
keyGet 0 365 413
assign 1 365 414
isEqual 2 365 414
assign 1 366 416
getFrom 0 366 416
return 1 366 417
assign 1 368 420
increment 0 368 420
assign 1 369 421
greaterEquals 1 369 426
return 1 370 427
assign 1 377 454
assign 1 378 455
sizeGet 0 378 455
assign 1 379 456
getHash 1 379 456
assign 1 380 457
new 0 380 457
assign 1 380 458
lesser 1 380 463
assign 1 381 464
abs 0 381 464
assign 1 383 466
modulus 1 383 466
assign 1 384 467
assign 1 386 470
get 1 386 470
assign 1 387 471
undef 1 387 476
assign 1 388 477
new 0 388 477
return 1 388 478
assign 1 389 481
hvalGet 0 389 481
assign 1 389 482
modulus 1 389 482
assign 1 389 483
notEquals 1 389 488
assign 1 390 489
new 0 390 489
return 1 390 490
assign 1 391 493
keyGet 0 391 493
assign 1 391 494
isEqual 2 391 494
assign 1 392 496
new 0 392 496
return 1 392 497
assign 1 394 500
increment 0 394 500
assign 1 395 501
greaterEquals 1 395 506
assign 1 396 507
new 0 396 507
return 1 396 508
assign 1 403 544
assign 1 404 545
sizeGet 0 404 545
assign 1 406 546
getHash 1 406 546
assign 1 407 547
new 0 407 547
assign 1 407 548
lesser 1 407 553
assign 1 408 554
abs 0 408 554
assign 1 410 556
modulus 1 410 556
assign 1 411 557
assign 1 413 560
get 1 413 560
assign 1 414 561
undef 1 414 566
assign 1 415 567
new 0 415 567
return 1 415 568
assign 1 416 571
hvalGet 0 416 571
assign 1 416 572
modulus 1 416 572
assign 1 416 573
notEquals 1 416 578
assign 1 417 579
new 0 417 579
return 1 417 580
assign 1 418 583
keyGet 0 418 583
assign 1 418 584
isEqual 2 418 584
put 2 419 586
assign 1 420 587
decrement 0 420 587
assign 1 421 588
increment 0 421 588
assign 1 422 591
lesser 1 422 596
assign 1 423 597
get 1 423 597
assign 1 424 598
undef 1 424 603
assign 1 0 604
assign 1 424 607
hvalGet 0 424 607
assign 1 424 608
modulus 1 424 608
assign 1 424 609
notEquals 1 424 614
assign 1 0 615
assign 1 0 618
assign 1 425 622
new 0 425 622
return 1 425 623
assign 1 427 626
new 0 427 626
assign 1 427 627
subtract 1 427 627
put 2 427 628
put 2 428 629
assign 1 430 631
increment 0 430 631
assign 1 432 637
new 0 432 637
return 1 432 638
assign 1 434 641
increment 0 434 641
assign 1 435 642
greaterEquals 1 435 647
assign 1 436 648
new 0 436 648
return 1 436 649
assign 1 443 671
create 0 443 671
copyTo 1 444 672
assign 1 445 673
copy 0 445 673
slotsSet 1 445 674
assign 1 446 675
new 0 446 675
assign 1 446 678
lengthGet 0 446 678
assign 1 446 679
lesser 1 446 684
assign 1 447 685
get 1 447 685
assign 1 448 686
def 1 448 691
assign 1 449 692
slotsGet 0 449 692
assign 1 449 693
create 0 449 693
assign 1 449 694
hvalGet 0 449 694
assign 1 449 695
keyGet 0 449 695
assign 1 449 696
getFrom 0 449 696
assign 1 449 697
new 3 449 697
put 2 449 698
assign 1 451 701
slotsGet 0 451 701
put 2 451 702
assign 1 446 704
increment 0 446 704
return 1 454 710
clear 0 459 713
assign 1 460 714
new 0 460 714
assign 1 464 719
new 1 464 719
return 1 464 720
assign 1 468 724
new 1 468 724
return 1 468 725
assign 1 472 729
new 1 472 729
return 1 472 730
assign 1 476 734
keyIteratorGet 0 476 734
return 1 476 735
assign 1 480 739
new 1 480 739
return 1 480 740
assign 1 484 744
nodeIteratorGet 0 484 744
return 1 484 745
assign 1 488 754
new 0 488 754
assign 1 489 755
def 1 489 760
assign 1 490 761
setIteratorGet 0 0 761
assign 1 490 764
hasNextGet 0 490 764
assign 1 490 766
nextGet 0 490 766
assign 1 491 767
has 1 491 767
put 1 492 769
return 1 496 777
assign 1 500 787
new 0 500 787
assign 1 501 788
setIteratorGet 0 0 788
assign 1 501 791
hasNextGet 0 501 791
assign 1 501 793
nextGet 0 501 793
put 1 502 794
assign 1 504 800
def 1 504 805
assign 1 505 806
setIteratorGet 0 0 806
assign 1 505 809
hasNextGet 0 505 809
assign 1 505 811
nextGet 0 505 811
put 1 506 812
return 1 509 819
assign 1 513 823
copy 0 513 823
addValue 1 514 824
return 1 515 825
assign 1 519 835
def 1 519 840
assign 1 520 841
sameType 1 520 841
assign 1 521 843
iteratorGet 0 0 843
assign 1 521 846
hasNextGet 0 521 846
assign 1 521 848
nextGet 0 521 848
put 1 522 849
assign 1 524 857
sameType 1 524 857
assign 1 525 859
keyGet 0 525 859
put 1 525 860
put 1 527 863
return 1 0 870
assign 1 0 873
return 1 0 877
assign 1 0 880
return 1 0 884
assign 1 0 887
return 1 0 891
assign 1 0 894
return 1 0 898
assign 1 0 901
return 1 0 905
assign 1 0 908
return 1 0 912
assign 1 0 915
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 712928736: return bem_innerPutAddedGet_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1586230380: return bem_moduGet_0();
case 1114073101: return bem_keysGet_0();
case 104713553: return bem_new_0();
case 2086347094: return bem_nodesGet_0();
case 287040793: return bem_hashGet_0();
case 2056412570: return bem_keyIteratorGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case 2142483603: return bem_notEmptyGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1431826729: return bem_nodeIteratorGet_0();
case 1820417453: return bem_create_0();
case 1227011022: return bem_multiGet_0();
case 578884498: return bem_relGet_0();
case 786424307: return bem_tagGet_0();
case 235611348: return bem_baseNodeGet_0();
case 499932279: return bem_setIteratorGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1575148127: return bem_moduSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 567802245: return bem_relSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 79841285: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 286659903: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 668984013: return bem_rehash_1((BEC_2_9_5_ContainerArray) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 131089957: return bem_insertAll_2((BEC_2_9_5_ContainerArray) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_5_ContainerArray) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bevs_inst = (BEC_2_9_3_ContainerSet)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bevs_inst;
}
}
