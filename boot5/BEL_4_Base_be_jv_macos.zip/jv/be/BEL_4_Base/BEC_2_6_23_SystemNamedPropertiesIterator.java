package be.BEL_4_Base;
/* IO:File: source/extended/Serialize.be */
public class BEC_2_6_23_SystemNamedPropertiesIterator extends BEC_2_6_6_SystemObject {
public BEC_2_6_23_SystemNamedPropertiesIterator() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x69,0x65,0x73,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x47,0x65,0x74};
private static byte[] bels_1 = {0x53,0x65,0x74};
public static BEC_2_6_23_SystemNamedPropertiesIterator bevs_inst;
public BEC_2_9_5_ContainerArray bevp_propNames;
public BEC_3_9_5_8_ContainerArrayIterator bevp_subIter;
public BEC_2_6_6_SystemObject bevp_inst;
public BEC_2_9_5_ContainerArray bevp_setArgs;
public BEC_2_9_5_ContainerArray bevp_getArgs;
public BEC_2_6_6_SystemObject bem_new_2(BEC_2_6_6_SystemObject beva__inst, BEC_2_9_5_ContainerArray beva__propNames) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_propNames = beva__propNames;
bevp_inst = beva__inst;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevp_setArgs = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevp_getArgs = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_3_9_5_8_ContainerArrayIterator bem_subIterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_subIter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 448 */ {
bevp_subIter = bevp_propNames.bem_arrayIteratorGet_0();
} /* Line: 449 */
return bevp_subIter;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_subIterGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_hasNextGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_subIterGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_nextGet_0();
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_0));
bevl_name = (BEC_2_4_6_TextString) bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_3_tmpvar_phold = bevp_inst.bemd_2(94427011, BEL_4_Base.bevn_can_2, bevl_name, bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 460 */ {
bevt_5_tmpvar_phold = bevp_inst.bemd_2(636686891, BEL_4_Base.bevn_invoke_2, bevl_name, bevp_getArgs);
return bevt_5_tmpvar_phold;
} /* Line: 461 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_subIterGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_nextGet_0();
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_1));
bevl_name = (BEC_2_4_6_TextString) bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevt_3_tmpvar_phold = bevp_inst.bemd_2(94427011, BEL_4_Base.bevn_can_2, bevl_name, bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 468 */ {
bevt_5_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevp_setArgs.bem_put_2(bevt_5_tmpvar_phold, beva_value);
bevp_inst.bemd_2(636686891, BEL_4_Base.bevn_invoke_2, bevl_name, bevp_setArgs);
} /* Line: 470 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 475 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 475 */ {
this.bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 475 */
 else  /* Line: 475 */ {
break;
} /* Line: 475 */
} /* Line: 475 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_propNamesGet_0() throws Throwable {
return bevp_propNames;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_propNames = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subIterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_subIter = (BEC_3_9_5_8_ContainerArrayIterator) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instGet_0() throws Throwable {
return bevp_inst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inst = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_setArgsGet_0() throws Throwable {
return bevp_setArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_setArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_setArgs = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_getArgsGet_0() throws Throwable {
return bevp_getArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_getArgs = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {439, 441, 442, 442, 443, 443, 448, 448, 449, 451, 455, 455, 455, 459, 459, 459, 459, 460, 460, 461, 461, 463, 467, 467, 467, 467, 468, 468, 469, 469, 470, 475, 475, 475, 476, 475, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 21, 22, 23, 28, 33, 34, 36, 41, 42, 43, 53, 54, 55, 56, 57, 58, 60, 61, 63, 73, 74, 75, 76, 77, 78, 80, 81, 82, 89, 92, 97, 98, 99, 108, 111, 115, 119, 122, 126, 129, 133, 136};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 439 18
assign 1 441 19
assign 1 442 20
new 0 442 20
assign 1 442 21
new 1 442 21
assign 1 443 22
new 0 443 22
assign 1 443 23
new 1 443 23
assign 1 448 28
undef 1 448 33
assign 1 449 34
arrayIteratorGet 0 449 34
return 1 451 36
assign 1 455 41
subIterGet 0 455 41
assign 1 455 42
hasNextGet 0 455 42
return 1 455 43
assign 1 459 53
subIterGet 0 459 53
assign 1 459 54
nextGet 0 459 54
assign 1 459 55
new 0 459 55
assign 1 459 56
add 1 459 56
assign 1 460 57
new 0 460 57
assign 1 460 58
can 2 460 58
assign 1 461 60
invoke 2 461 60
return 1 461 61
return 1 463 63
assign 1 467 73
subIterGet 0 467 73
assign 1 467 74
nextGet 0 467 74
assign 1 467 75
new 0 467 75
assign 1 467 76
add 1 467 76
assign 1 468 77
new 0 468 77
assign 1 468 78
can 2 468 78
assign 1 469 80
new 0 469 80
put 2 469 81
invoke 2 470 82
assign 1 475 89
new 0 475 89
assign 1 475 92
lesser 1 475 97
nextSet 1 476 98
assign 1 475 99
increment 0 475 99
return 1 0 108
assign 1 0 111
assign 1 0 115
return 1 0 119
assign 1 0 122
return 1 0 126
assign 1 0 129
return 1 0 133
assign 1 0 136
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 4834017: return bem_instGet_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 2137468940: return bem_getArgsGet_0();
case 1012494862: return bem_once_0();
case 74599151: return bem_subIterGet_0();
case 1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case 588476312: return bem_setArgsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 3177758: return bem_propNamesGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 108485850: return bem_hasNextGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 577394059: return bem_setArgsSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2126386687: return bem_getArgsSet_1(bevd_0);
case 15916270: return bem_instSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 85681404: return bem_subIterSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 900559503: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 7904495: return bem_propNamesSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_23_SystemNamedPropertiesIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_23_SystemNamedPropertiesIterator.bevs_inst = (BEC_2_6_23_SystemNamedPropertiesIterator)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_23_SystemNamedPropertiesIterator.bevs_inst;
}
}
