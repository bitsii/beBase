package be.BEL_4_Base;
/* IO:File: source/base/Array.be */
public class BEC_2_9_5_ContainerArray extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerArray() { }

   
    public BEC_2_6_6_SystemObject[] bevi_array;
    
   
   
   public BEC_2_9_5_ContainerArray(BEC_2_6_6_SystemObject[] bevi_array) {
        this.bevi_array = bevi_array;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_array.length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_array.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x41,0x72,0x72,0x61,0x79,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(16));
private static byte[] bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(2));
private static byte[] bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(2));
public static BEC_2_9_5_ContainerArray bevs_inst;
public BEC_2_6_6_SystemObject bevp_varray;
public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public BEC_2_9_5_ContainerArray bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
this.bem_new_2(bevt_0_tmpvar_phold, bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_new_1(BEC_2_4_3_MathInt beva_leni) throws Throwable {
this.bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_leni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
if (beva_capi == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_4_tmpvar_phold = (new BEC_2_4_6_TextString(61, bels_0));
bevt_3_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 142 */
if (bevp_length == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 144 */ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 147 */ {
return this;
} /* Line: 148 */
} /* Line: 147 */

      bevi_array = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = beva_leni.bem_copy_0();
bevp_capacity = beva_capi.bem_copy_0();
bevp_multiplier = bevo_2;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
if (bevp_length.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 175 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 176 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_varrayGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_varraySet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_length.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_5;
bevt_1_tmpvar_phold = bevp_length.bem_subtract_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_6;
if (beva_posi.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(36, bels_1));
bevt_2_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_2_tmpvar_phold);
} /* Line: 209 */
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_6_tmpvar_phold = bevo_7;
bevt_5_tmpvar_phold = beva_posi.bem_add_1(bevt_6_tmpvar_phold);
this.bem_lengthSet_1(bevt_5_tmpvar_phold);
} /* Line: 212 */

      this.bevi_array[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_8;
if (beva_posi.bevi_int >= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 223 */ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 223 */
 else  /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 223 */ {

      bevl_val = this.bevi_array[beva_posi.bevi_int];
      } /* Line: 224 */
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_1_tmpvar_phold = bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpvar_phold);
bevl_i = beva_pos;
while (true)
 /* Line: 236 */ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 236 */ {
bevt_5_tmpvar_phold = bevo_10;
bevt_4_tmpvar_phold = bevl_i.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = this.bem_get_1(bevt_4_tmpvar_phold);
this.bem_put_2(bevl_i, bevt_3_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 236 */
 else  /* Line: 236 */ {
break;
} /* Line: 236 */
} /* Line: 236 */
this.bem_put_2(bevl_fl, null);
bevt_7_tmpvar_phold = bevo_11;
bevt_6_tmpvar_phold = bevp_length.bem_subtract_1(bevt_7_tmpvar_phold);
this.bem_lengthSet_1(bevt_6_tmpvar_phold);
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 241 */
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_5_8_ContainerArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_5_8_ContainerArrayIterator bem_arrayIteratorGet_0() throws Throwable {
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_5_8_ContainerArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_clear_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 255 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 255 */ {
this.bem_put_2(bevl_i, null);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 255 */
 else  /* Line: 255 */ {
break;
} /* Line: 255 */
} /* Line: 255 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_copy_0() throws Throwable {
BEC_2_9_5_ContainerArray bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_n = this.bem_create_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 262 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevt_1_tmpvar_phold = this.bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 262 */
 else  /* Line: 262 */ {
break;
} /* Line: 262 */
} /* Line: 262 */
return (BEC_2_9_5_ContainerArray) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_9_5_ContainerArray()).bem_new_1(beva_len);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_create_0() throws Throwable {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevp_length);
return (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_add_1(BEC_2_9_5_ContainerArray beva_xi) throws Throwable {
BEC_2_9_5_ContainerArray bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_1_tmpvar_loop = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_4_tmpvar_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpvar_phold = bevp_length.bem_add_1(bevt_4_tmpvar_phold);
bevl_yi = (new BEC_2_9_5_ContainerArray()).bem_new_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_loop = this.bem_arrayIteratorGet_0();
while (true)
 /* Line: 274 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 274 */ {
bevl_c = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 275 */
 else  /* Line: 274 */ {
break;
} /* Line: 274 */
} /* Line: 274 */
bevt_1_tmpvar_loop = beva_xi.bem_arrayIteratorGet_0();
while (true)
 /* Line: 277 */ {
bevt_6_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevl_c = bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 278 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
return (BEC_2_9_5_ContainerArray) bevl_yi;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_sort_0() throws Throwable {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_mergeSort_0();
return (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_sortValue_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
this.bem_sortValue_2(bevt_0_tmpvar_phold, bevp_length);
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_i = beva_start;
while (true)
 /* Line: 292 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevl_c = bevl_i;
bevl_j = bevl_i;
while (true)
 /* Line: 294 */ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevt_3_tmpvar_phold = this.bem_get_1(bevl_j);
bevt_4_tmpvar_phold = this.bem_get_1(bevl_c);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 295 */ {
bevl_c = bevl_j;
} /* Line: 296 */
bevl_j = bevl_j.bem_increment_0();
} /* Line: 294 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
bevl_hold = this.bem_get_1(bevl_i);
bevt_5_tmpvar_phold = this.bem_get_1(bevl_c);
this.bem_put_2(bevl_i, bevt_5_tmpvar_phold);
this.bem_put_2(bevl_c, bevl_hold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 292 */
 else  /* Line: 292 */ {
break;
} /* Line: 292 */
} /* Line: 292 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_mergeIn_2(BEC_2_9_5_ContainerArray beva_first, BEC_2_9_5_ContainerArray beva_second) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_fi = (new BEC_2_4_3_MathInt(0));
bevl_si = (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 311 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 311 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 312 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 312 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 312 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 312 */
 else  /* Line: 312 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 312 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpvar_phold = bevl_so.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fo);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 315 */ {
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 317 */
 else  /* Line: 318 */ {
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 320 */
} /* Line: 315 */
 else  /* Line: 312 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 322 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 325 */
 else  /* Line: 312 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 326 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 329 */
} /* Line: 312 */
} /* Line: 312 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 331 */
 else  /* Line: 311 */ {
break;
} /* Line: 311 */
} /* Line: 311 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_mergeSort_0() throws Throwable {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpvar_phold = this.bem_mergeSort_2(bevt_1_tmpvar_phold, bevp_length);
return (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_5_ContainerArray bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_5_ContainerArray bevl_fa = null;
BEC_2_9_5_ContainerArray bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpvar_phold = bevo_12;
if (bevl_mlen.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 341 */ {
bevt_3_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_2_tmpvar_phold = this.bem_create_1(bevt_3_tmpvar_phold);
return (BEC_2_9_5_ContainerArray) bevt_2_tmpvar_phold;
} /* Line: 342 */
 else  /* Line: 341 */ {
bevt_5_tmpvar_phold = bevo_13;
if (bevl_mlen.bevi_int == bevt_5_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 343 */ {
bevt_6_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_5_ContainerArray) this.bem_create_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_8_tmpvar_phold = this.bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold);
return (BEC_2_9_5_ContainerArray) bevl_ra;
} /* Line: 346 */
 else  /* Line: 347 */ {
bevt_9_tmpvar_phold = bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpvar_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = this.bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = this.bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_5_ContainerArray) this.bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_5_ContainerArray) bevl_ra;
} /* Line: 355 */
} /* Line: 341 */
} /*method end*/
public BEC_2_6_6_SystemObject bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 360 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_2));
bevt_1_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 361 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) throws Throwable {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 367 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         this.bevi_array = java.util.Arrays.copyOf(this.bevi_array, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 384 */
while (true)
 /* Line: 387 */ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 387 */ {

         this.bevi_array[this.bevp_length.bevi_int] = null;
         bevp_length.bem_incrementValue_0();
} /* Line: 393 */
 else  /* Line: 387 */ {
break;
} /* Line: 387 */
} /* Line: 387 */
bevp_length.bem_setValue_1(beva_newlen);
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 399 */ {
while (true)
 /* Line: 400 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 400 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpvar_phold);
} /* Line: 401 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
} /* Line: 400 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 408 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 413 */ {

       this.bevi_array[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bem_incrementValue_0();
} /* Line: 419 */
 else  /* Line: 420 */ {
bevt_1_tmpvar_phold = bevp_length.bem_copy_0();
this.bem_put_2(bevt_1_tmpvar_phold, beva_val);
} /* Line: 422 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_addValue_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 427 */ {
bevt_2_tmpvar_phold = beva_val.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 427 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 427 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 427 */
 else  /* Line: 427 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 427 */ {
this.bem_addAll_1(beva_val);
} /* Line: 428 */
 else  /* Line: 429 */ {
this.bem_addValueWhole_1(beva_val);
} /* Line: 430 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 436 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 436 */ {
bevl_aval = this.bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 438 */ {
bevt_3_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 438 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 438 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 438 */
 else  /* Line: 438 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 438 */ {
return bevl_i;
} /* Line: 439 */
bevl_i.bem_incrementValue_0();
} /* Line: 436 */
 else  /* Line: 436 */ {
break;
} /* Line: 436 */
} /* Line: 436 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_find_1(beva_value);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 446 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 447 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_phold = this.bem_sortedFind_2(beva_value, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) throws Throwable {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_high = bevp_length;
bevl_low = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 466 */ {
bevt_3_tmpvar_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpvar_phold = bevo_15;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_divide_1(bevt_4_tmpvar_phold);
bevl_mid = bevt_2_tmpvar_phold.bem_add_1(bevl_low);
bevl_aval = this.bem_get_1(bevl_mid);
bevt_5_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 469 */ {
return bevl_mid;
} /* Line: 470 */
 else  /* Line: 469 */ {
bevt_6_tmpvar_phold = beva_value.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevl_aval);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 471 */ {
bevl_low = bevl_mid;
} /* Line: 473 */
 else  /* Line: 469 */ {
bevt_7_tmpvar_phold = beva_value.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_aval);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 474 */ {
bevl_high = bevl_mid;
} /* Line: 476 */
} /* Line: 469 */
} /* Line: 469 */
if (bevl_lastMid == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 479 */ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 479 */
 else  /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 479 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 480 */ {
bevt_11_tmpvar_phold = this.bem_get_1(bevl_low);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, beva_value);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 480 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 480 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 480 */
 else  /* Line: 480 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 480 */ {
return bevl_low;
} /* Line: 481 */
return null;
} /* Line: 483 */
bevl_lastMid = bevl_mid;
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 486 */ {
return null;
} /* Line: 487 */
} /* Line: 486 */
} /*method end*/
public BEC_2_6_6_SystemObject bem_varraySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_varray = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public BEC_2_6_6_SystemObject bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {133, 133, 133, 133, 133, 137, 141, 141, 0, 141, 141, 0, 0, 142, 142, 142, 144, 144, 147, 147, 148, 164, 165, 166, 171, 175, 175, 175, 176, 176, 178, 178, 188, 188, 192, 192, 196, 196, 200, 200, 200, 204, 204, 204, 204, 208, 208, 208, 209, 209, 209, 211, 211, 212, 212, 212, 223, 223, 223, 223, 223, 0, 0, 0, 230, 234, 234, 235, 235, 236, 236, 236, 237, 237, 237, 237, 236, 239, 240, 240, 240, 241, 241, 243, 243, 247, 247, 251, 251, 255, 255, 255, 256, 255, 261, 262, 262, 262, 263, 263, 262, 265, 268, 268, 270, 270, 273, 273, 273, 273, 274, 0, 274, 274, 275, 277, 0, 277, 277, 278, 280, 284, 284, 288, 288, 292, 292, 292, 293, 294, 294, 294, 295, 295, 295, 296, 294, 299, 300, 300, 301, 292, 306, 307, 308, 309, 310, 311, 311, 312, 312, 312, 312, 0, 0, 0, 313, 314, 315, 316, 317, 319, 320, 322, 322, 323, 324, 325, 326, 326, 327, 328, 329, 331, 336, 336, 336, 340, 341, 341, 341, 342, 342, 342, 343, 343, 343, 344, 344, 345, 345, 345, 346, 348, 348, 349, 350, 351, 352, 353, 354, 355, 360, 361, 361, 361, 367, 367, 368, 384, 387, 387, 393, 395, 399, 399, 400, 401, 401, 407, 407, 408, 408, 413, 413, 419, 422, 422, 427, 427, 427, 0, 0, 0, 428, 430, 436, 436, 436, 437, 438, 438, 438, 0, 0, 0, 439, 436, 442, 446, 446, 446, 447, 447, 449, 449, 455, 455, 455, 462, 463, 467, 467, 467, 467, 468, 469, 470, 471, 473, 474, 476, 479, 479, 479, 479, 0, 0, 0, 480, 480, 0, 0, 0, 481, 483, 485, 486, 487, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {49, 50, 51, 52, 53, 57, 68, 73, 74, 77, 82, 83, 86, 90, 91, 92, 94, 99, 100, 105, 106, 111, 112, 113, 117, 124, 125, 130, 131, 132, 134, 135, 145, 146, 150, 151, 156, 157, 162, 163, 164, 170, 171, 172, 173, 183, 184, 189, 190, 191, 192, 194, 199, 200, 201, 202, 214, 215, 220, 221, 226, 227, 230, 234, 240, 255, 260, 261, 262, 263, 266, 271, 272, 273, 274, 275, 276, 282, 283, 284, 285, 286, 287, 289, 290, 294, 295, 299, 300, 305, 308, 313, 314, 315, 328, 329, 332, 337, 338, 339, 340, 346, 350, 351, 355, 356, 368, 369, 370, 371, 372, 372, 375, 377, 378, 384, 384, 387, 389, 390, 396, 400, 401, 405, 406, 420, 423, 428, 429, 430, 433, 438, 439, 440, 441, 443, 445, 451, 452, 453, 454, 455, 478, 479, 480, 481, 482, 485, 490, 491, 496, 497, 502, 503, 506, 510, 513, 514, 515, 517, 518, 521, 522, 526, 531, 532, 533, 534, 537, 542, 543, 544, 545, 549, 560, 561, 562, 582, 583, 584, 589, 590, 591, 592, 595, 596, 601, 602, 603, 604, 605, 606, 607, 610, 611, 612, 613, 614, 615, 616, 617, 618, 626, 628, 629, 630, 638, 643, 644, 647, 651, 656, 659, 665, 672, 677, 680, 682, 683, 695, 700, 701, 702, 709, 714, 717, 720, 721, 729, 734, 735, 737, 740, 744, 747, 750, 761, 764, 769, 770, 771, 776, 777, 779, 782, 786, 789, 791, 797, 804, 805, 810, 811, 812, 814, 815, 820, 821, 822, 843, 844, 847, 848, 849, 850, 851, 852, 854, 857, 859, 862, 864, 868, 873, 874, 879, 880, 883, 887, 891, 892, 894, 897, 901, 904, 906, 908, 909, 911, 916, 920, 923, 926, 929};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 133 49
new 0 133 49
assign 1 133 50
once 0 133 50
assign 1 133 51
new 0 133 51
assign 1 133 52
once 0 133 52
new 2 133 53
new 2 137 57
assign 1 141 68
undef 1 141 73
assign 1 0 74
assign 1 141 77
undef 1 141 82
assign 1 0 83
assign 1 0 86
assign 1 142 90
new 0 142 90
assign 1 142 91
new 1 142 91
throw 1 142 92
assign 1 144 94
def 1 144 99
assign 1 147 100
equals 1 147 105
return 1 148 106
assign 1 164 111
copy 0 164 111
assign 1 165 112
copy 0 165 112
assign 1 166 113
new 0 166 113
return 1 171 117
assign 1 175 124
new 0 175 124
assign 1 175 125
equals 1 175 130
assign 1 176 131
new 0 176 131
return 1 176 132
assign 1 178 134
new 0 178 134
return 1 178 135
assign 1 188 145
toString 0 188 145
return 1 188 146
assign 1 192 150
new 1 192 150
new 1 192 151
assign 1 196 156
iteratorGet 0 196 156
return 1 196 157
assign 1 200 162
new 0 200 162
assign 1 200 163
get 1 200 163
return 1 200 164
assign 1 204 170
new 0 204 170
assign 1 204 171
subtract 1 204 171
assign 1 204 172
get 1 204 172
return 1 204 173
assign 1 208 183
new 0 208 183
assign 1 208 184
lesser 1 208 189
assign 1 209 190
new 0 209 190
assign 1 209 191
new 1 209 191
throw 1 209 192
assign 1 211 194
greaterEquals 1 211 199
assign 1 212 200
new 0 212 200
assign 1 212 201
add 1 212 201
lengthSet 1 212 202
assign 1 223 214
new 0 223 214
assign 1 223 215
greaterEquals 1 223 220
assign 1 223 221
lesser 1 223 226
assign 1 0 227
assign 1 0 230
assign 1 0 234
return 1 230 240
assign 1 234 255
lesser 1 234 260
assign 1 235 261
new 0 235 261
assign 1 235 262
subtract 1 235 262
assign 1 236 263
assign 1 236 266
lesser 1 236 271
assign 1 237 272
new 0 237 272
assign 1 237 273
add 1 237 273
assign 1 237 274
get 1 237 274
put 2 237 275
assign 1 236 276
increment 0 236 276
put 2 239 282
assign 1 240 283
new 0 240 283
assign 1 240 284
subtract 1 240 284
lengthSet 1 240 285
assign 1 241 286
new 0 241 286
return 1 241 287
assign 1 243 289
new 0 243 289
return 1 243 290
assign 1 247 294
new 1 247 294
return 1 247 295
assign 1 251 299
new 1 251 299
return 1 251 300
assign 1 255 305
new 0 255 305
assign 1 255 308
lesser 1 255 313
put 2 256 314
assign 1 255 315
increment 0 255 315
assign 1 261 328
create 0 261 328
assign 1 262 329
new 0 262 329
assign 1 262 332
lesser 1 262 337
assign 1 263 338
get 1 263 338
put 2 263 339
assign 1 262 340
increment 0 262 340
return 1 265 346
assign 1 268 350
new 1 268 350
return 1 268 351
assign 1 270 355
new 1 270 355
return 1 270 356
assign 1 273 368
new 0 273 368
assign 1 273 369
lengthGet 0 273 369
assign 1 273 370
add 1 273 370
assign 1 273 371
new 2 273 371
assign 1 274 372
arrayIteratorGet 0 0 372
assign 1 274 375
hasNextGet 0 274 375
assign 1 274 377
nextGet 0 274 377
addValueWhole 1 275 378
assign 1 277 384
arrayIteratorGet 0 0 384
assign 1 277 387
hasNextGet 0 277 387
assign 1 277 389
nextGet 0 277 389
addValueWhole 1 278 390
return 1 280 396
assign 1 284 400
mergeSort 0 284 400
return 1 284 401
assign 1 288 405
new 0 288 405
sortValue 2 288 406
assign 1 292 420
assign 1 292 423
lesser 1 292 428
assign 1 293 429
assign 1 294 430
assign 1 294 433
lesser 1 294 438
assign 1 295 439
get 1 295 439
assign 1 295 440
get 1 295 440
assign 1 295 441
lesser 1 295 441
assign 1 296 443
assign 1 294 445
increment 0 294 445
assign 1 299 451
get 1 299 451
assign 1 300 452
get 1 300 452
put 2 300 453
put 2 301 454
assign 1 292 455
increment 0 292 455
assign 1 306 478
new 0 306 478
assign 1 307 479
new 0 307 479
assign 1 308 480
new 0 308 480
assign 1 309 481
lengthGet 0 309 481
assign 1 310 482
lengthGet 0 310 482
assign 1 311 485
lesser 1 311 490
assign 1 312 491
lesser 1 312 496
assign 1 312 497
lesser 1 312 502
assign 1 0 503
assign 1 0 506
assign 1 0 510
assign 1 313 513
get 1 313 513
assign 1 314 514
get 1 314 514
assign 1 315 515
lesser 1 315 515
assign 1 316 517
increment 0 316 517
put 2 317 518
assign 1 319 521
increment 0 319 521
put 2 320 522
assign 1 322 526
lesser 1 322 531
assign 1 323 532
get 1 323 532
assign 1 324 533
increment 0 324 533
put 2 325 534
assign 1 326 537
lesser 1 326 542
assign 1 327 543
get 1 327 543
assign 1 328 544
increment 0 328 544
put 2 329 545
assign 1 331 549
increment 0 331 549
assign 1 336 560
new 0 336 560
assign 1 336 561
mergeSort 2 336 561
return 1 336 562
assign 1 340 582
subtract 1 340 582
assign 1 341 583
new 0 341 583
assign 1 341 584
equals 1 341 589
assign 1 342 590
new 0 342 590
assign 1 342 591
create 1 342 591
return 1 342 592
assign 1 343 595
new 0 343 595
assign 1 343 596
equals 1 343 601
assign 1 344 602
new 0 344 602
assign 1 344 603
create 1 344 603
assign 1 345 604
new 0 345 604
assign 1 345 605
get 1 345 605
put 2 345 606
return 1 346 607
assign 1 348 610
new 0 348 610
assign 1 348 611
divide 1 348 611
assign 1 349 612
subtract 1 349 612
assign 1 350 613
add 1 350 613
assign 1 351 614
mergeSort 2 351 614
assign 1 352 615
mergeSort 2 352 615
assign 1 353 616
create 1 353 616
mergeIn 2 354 617
return 1 355 618
assign 1 360 626
new 0 360 626
assign 1 361 628
new 0 361 628
assign 1 361 629
new 1 361 629
throw 1 361 630
assign 1 367 638
greater 1 367 643
assign 1 368 644
multiply 1 368 644
assign 1 384 647
assign 1 387 651
lesser 1 387 656
incrementValue 0 393 659
setValue 1 395 665
assign 1 399 672
def 1 399 677
assign 1 400 680
hasNextGet 0 400 680
assign 1 401 682
nextGet 0 401 682
addValueWhole 1 401 683
assign 1 407 695
def 1 407 700
assign 1 408 701
iteratorGet 0 408 701
iterateAdd 1 408 702
assign 1 413 709
lesser 1 413 714
incrementValue 0 419 717
assign 1 422 720
copy 0 422 720
put 2 422 721
assign 1 427 729
def 1 427 734
assign 1 427 735
sameType 1 427 735
assign 1 0 737
assign 1 0 740
assign 1 0 744
addAll 1 428 747
addValueWhole 1 430 750
assign 1 436 761
new 0 436 761
assign 1 436 764
lesser 1 436 769
assign 1 437 770
get 1 437 770
assign 1 438 771
def 1 438 776
assign 1 438 777
equals 1 438 777
assign 1 0 779
assign 1 0 782
assign 1 0 786
return 1 439 789
incrementValue 0 436 791
return 1 442 797
assign 1 446 804
find 1 446 804
assign 1 446 805
def 1 446 810
assign 1 447 811
new 0 447 811
return 1 447 812
assign 1 449 814
new 0 449 814
return 1 449 815
assign 1 455 820
new 0 455 820
assign 1 455 821
sortedFind 2 455 821
return 1 455 822
assign 1 462 843
assign 1 463 844
new 0 463 844
assign 1 467 847
subtract 1 467 847
assign 1 467 848
new 0 467 848
assign 1 467 849
divide 1 467 849
assign 1 467 850
add 1 467 850
assign 1 468 851
get 1 468 851
assign 1 469 852
equals 1 469 852
return 1 470 854
assign 1 471 857
greater 1 471 857
assign 1 473 859
assign 1 474 862
lesser 1 474 862
assign 1 476 864
assign 1 479 868
def 1 479 873
assign 1 479 874
equals 1 479 879
assign 1 0 880
assign 1 0 883
assign 1 0 887
assign 1 480 891
get 1 480 891
assign 1 480 892
lesser 1 480 892
assign 1 0 894
assign 1 0 897
assign 1 0 901
return 1 481 904
return 1 483 906
assign 1 485 908
assign 1 486 909
new 0 486 909
return 1 487 911
assign 1 0 916
return 1 0 920
return 1 0 923
return 1 0 926
assign 1 0 929
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 188061735: return bem_mergeSort_0();
case 856777406: return bem_clear_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 1616433729: return bem_lengthGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 183400265: return bem_firstGet_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1525854240: return bem_arrayIteratorGet_0();
case 474162694: return bem_sizeGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1484114352: return bem_varraySet_0();
case 1473032100: return bem_varrayGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1478277476: return bem_sortValue_0();
case 729571811: return bem_serializeToString_0();
case 1990707345: return bem_lastGet_0();
case 1479417926: return bem_multiplierGet_0();
case 1751843603: return bem_capacityGet_0();
case 1354714650: return bem_copy_0();
case 896593457: return bem_sort_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1484114353: return bem_varraySet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 819712669: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case 1627515982: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 1820417454: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1490500179: return bem_multiplierSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1274448085: return bem_find_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_5_ContainerArray) bevd_0);
case 228068295: return bem_addValueWhole_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 518108232: return bem_sortedFind_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 518108233: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 188061737: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 104713555: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1478277478: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1626710000: return bem_mergeIn_2((BEC_2_9_5_ContainerArray) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerArray();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerArray.bevs_inst = (BEC_2_9_5_ContainerArray)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerArray.bevs_inst;
}
}
