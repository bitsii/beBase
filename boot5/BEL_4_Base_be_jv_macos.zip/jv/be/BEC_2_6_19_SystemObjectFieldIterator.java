package be;
/* IO:File: source/base/OpiFc.be */
public final class BEC_2_6_19_SystemObjectFieldIterator extends BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemObjectFieldIterator() { }

public java.lang.reflect.Field[] fields;
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x46,0x69,0x65,0x6C,0x64,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
public static BEC_2_6_19_SystemObjectFieldIterator bevs_inst;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_6_6_SystemObject bevp_instance;
public BEC_2_5_4_LogicBool bevp_advanced;
public BEC_2_5_4_LogicBool bevp_done;
public BEC_2_5_4_LogicBool bevp_tval;
public BEC_2_6_19_SystemObjectFieldIterator bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_1(BEC_2_6_6_SystemObject beva__instance) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = this.bem_new_2(beva__instance, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_2(BEC_2_6_6_SystemObject beva__instance, BEC_2_5_4_LogicBool beva_forceFirstSlot) throws Throwable {
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevp_instance = beva__instance;
bevp_advanced = be.BECS_Runtime.boolFalse;
bevp_done = be.BECS_Runtime.boolFalse;
bevp_tval = be.BECS_Runtime.boolTrue;

    fields = bevp_instance.getClass().getFields();
    return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advance_0() throws Throwable {

    String prefix = "bevp_";
    int i = bevp_pos.bevi_int;
    i++;
    while (i < fields.length) {
      if (fields[i].getName().startsWith(prefix)) {
        bevp_advanced = bevp_tval;
        bevp_pos.bevi_int = i;
        return this;
      }
      i++;
    }
    bevp_done = bevp_tval;
    return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
if (bevp_done.bevi_bool) /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 106 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 106 */ {
this.bem_advance_0();
} /* Line: 107 */
if (!(bevp_done.bevi_bool)) /* Line: 109 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 110 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextNameGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
if (bevp_done.bevi_bool) /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 116 */ {
this.bem_advance_0();
} /* Line: 117 */
if (bevp_done.bevi_bool) /* Line: 119 */ {
return null;
} /* Line: 120 */
bevp_advanced = be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = this.bem_currentNameGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_currentNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;

    bevl_res = new BEC_2_4_6_TextString(fields[bevp_pos.bevi_int].getName());
    bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(5));
bevt_0_tmpany_phold = bevl_res.bem_substring_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 147 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 147 */ {
if (bevp_done.bevi_bool) /* Line: 147 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 147 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 147 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 147 */ {
this.bem_advance_0();
} /* Line: 148 */
if (bevp_done.bevi_bool) /* Line: 150 */ {
return null;
} /* Line: 151 */
bevp_advanced = be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = this.bem_currentGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_res = null;

    bevl_res = (BEC_2_6_6_SystemObject) (fields[bevp_pos.bevi_int].get(bevp_instance));
    return bevl_res;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 178 */ {
if (bevp_done.bevi_bool) /* Line: 178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 178 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 178 */ {
this.bem_advance_0();
} /* Line: 179 */
if (bevp_done.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 181 */ {
this.bem_currentSet_1(beva_value);
} /* Line: 182 */
bevp_advanced = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_currentSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {

    fields[bevp_pos.bevi_int].set(bevp_instance, beva_value);
    return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 206 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 206 */ {
this.bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 206 */
 else  /* Line: 206 */ {
break;
} /* Line: 206 */
} /* Line: 206 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceGet_0() throws Throwable {
return bevp_instance;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instanceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instance = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_advancedGet_0() throws Throwable {
return bevp_advanced;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advancedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_advanced = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doneGet_0() throws Throwable {
return bevp_done;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_doneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_done = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_tvalGet_0() throws Throwable {
return bevp_tval;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_tvalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tval = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {35, 35, 35, 40, 41, 42, 43, 44, 0, 0, 0, 107, 110, 110, 112, 112, 0, 0, 0, 117, 120, 122, 123, 123, 143, 143, 143, 0, 0, 0, 148, 151, 153, 154, 154, 174, 0, 0, 0, 179, 181, 181, 182, 184, 206, 206, 206, 207, 206, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 23, 26, 27, 28, 29, 30, 56, 60, 63, 67, 70, 71, 73, 74, 80, 84, 87, 91, 94, 96, 97, 98, 106, 107, 108, 114, 118, 121, 125, 128, 130, 131, 132, 138, 144, 148, 151, 155, 157, 162, 163, 165, 176, 179, 184, 185, 186, 195, 198, 202, 205, 209, 212, 216, 219, 223, 226};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 35 21
new 0 35 21
assign 1 35 22
new 2 35 22
return 1 35 23
assign 1 40 26
new 0 40 26
assign 1 41 27
assign 1 42 28
new 0 42 28
assign 1 43 29
new 0 43 29
assign 1 44 30
new 0 44 30
assign 1 0 56
assign 1 0 60
assign 1 0 63
advance 0 107 67
assign 1 110 70
new 0 110 70
return 1 110 71
assign 1 112 73
new 0 112 73
return 1 112 74
assign 1 0 80
assign 1 0 84
assign 1 0 87
advance 0 117 91
return 1 120 94
assign 1 122 96
new 0 122 96
assign 1 123 97
currentNameGet 0 123 97
return 1 123 98
assign 1 143 106
new 0 143 106
assign 1 143 107
substring 1 143 107
return 1 143 108
assign 1 0 114
assign 1 0 118
assign 1 0 121
advance 0 148 125
return 1 151 128
assign 1 153 130
new 0 153 130
assign 1 154 131
currentGet 0 154 131
return 1 154 132
return 1 174 138
assign 1 0 144
assign 1 0 148
assign 1 0 151
advance 0 179 155
assign 1 181 157
not 0 181 162
currentSet 1 182 163
assign 1 184 165
new 0 184 165
assign 1 206 176
new 0 206 176
assign 1 206 179
lesser 1 206 184
nextSet 1 207 185
incrementValue 0 206 186
return 1 0 195
assign 1 0 198
return 1 0 202
assign 1 0 205
return 1 0 209
assign 1 0 212
return 1 0 216
assign 1 0 219
return 1 0 223
assign 1 0 226
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -809133133: return bem_advance_0();
case 104713553: return bem_new_0();
case 715968403: return bem_posGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -1944843197: return bem_currentNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 22448773: return bem_advancedGet_0();
case 1622993701: return bem_doneGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case -1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -663945382: return bem_tvalGet_0();
case 1820417453: return bem_create_0();
case -1405080078: return bem_instanceGet_0();
case -786424307: return bem_tagGet_0();
case -1048393719: return bem_nextNameGet_0();
case -1354714650: return bem_copy_0();
case 108485850: return bem_hasNextGet_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -900559503: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -652863129: return bem_tvalSet_1(bevd_0);
case -1393997825: return bem_instanceSet_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 33531026: return bem_advancedSet_1(bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 727050656: return bem_posSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1634075954: return bem_doneSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 104713555: return bem_new_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator.bevs_inst = (BEC_2_6_19_SystemObjectFieldIterator)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemObjectFieldIterator.bevs_inst;
}
}
