package be;
/* IO:File: source/base/List.be */
public final class BEC_2_9_4_ContainerList extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(16));
private static byte[] bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(2));
private static byte[] bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(2));
public static BEC_2_9_4_ContainerList bevs_inst;
public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public BEC_2_9_4_ContainerList bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
this.bem_new_2(bevt_0_tmpany_phold, bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) throws Throwable {
this.bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_leni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 142 */ {
if (beva_capi == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 142 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 142 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 142 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(61, bels_0));
bevt_3_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 143 */
if (bevp_length == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 145 */ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 148 */ {
return this;
} /* Line: 149 */
} /* Line: 148 */

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = beva_leni.bem_copy_0();
bevp_capacity = beva_capi.bem_copy_0();
bevp_multiplier = bevo_2;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_3;
if (bevp_length.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 176 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 177 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_length.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_4;
bevt_0_tmpany_phold = this.bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_5;
bevt_1_tmpany_phold = bevp_length.bem_subtract_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = this.bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_6;
if (beva_posi.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 209 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(36, bels_1));
bevt_2_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 210 */
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevt_6_tmpany_phold = bevo_7;
bevt_5_tmpany_phold = beva_posi.bem_add_1(bevt_6_tmpany_phold);
this.bem_lengthSet_1(bevt_5_tmpany_phold);
} /* Line: 213 */

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_8;
if (beva_posi.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 224 */ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 224 */
 else  /* Line: 224 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 224 */ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 225 */
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_1_tmpany_phold = bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bevo_10;
bevl_j = beva_pos.bem_add_1(bevt_2_tmpany_phold);
bevl_i = beva_pos.bem_copy_0();
while (true)
 /* Line: 238 */ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_4_tmpany_phold = this.bem_get_1(bevl_j);
this.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 238 */
 else  /* Line: 238 */ {
break;
} /* Line: 238 */
} /* Line: 238 */
this.bem_put_2(bevl_fl, null);
bevt_6_tmpany_phold = bevo_11;
bevt_5_tmpany_phold = bevp_length.bem_subtract_1(bevt_6_tmpany_phold);
this.bem_lengthSet_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 244 */
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 258 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 258 */ {
this.bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 258 */
 else  /* Line: 258 */ {
break;
} /* Line: 258 */
} /* Line: 258 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_copy_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_n = this.bem_create_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 265 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 265 */ {
bevt_1_tmpany_phold = this.bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 265 */
 else  /* Line: 265 */ {
break;
} /* Line: 265 */
} /* Line: 265 */
return (BEC_2_9_4_ContainerList) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_create_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) throws Throwable {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_4_tmpany_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpany_phold = bevp_length.bem_add_1(bevt_4_tmpany_phold);
bevl_yi = (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 277 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevl_c = bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 278 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
bevt_1_tmpany_loop = beva_xi.bem_iteratorGet_0();
while (true)
 /* Line: 280 */ {
bevt_6_tmpany_phold = bevt_1_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 280 */ {
bevl_c = bevt_1_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 281 */
 else  /* Line: 280 */ {
break;
} /* Line: 280 */
} /* Line: 280 */
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
this.bem_sortValue_2(bevt_0_tmpany_phold, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = beva_start.bem_copy_0();
while (true)
 /* Line: 295 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 295 */ {
bevl_c = bevl_i.bem_copy_0();
bevl_j = bevl_i.bem_copy_0();
while (true)
 /* Line: 297 */ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_3_tmpany_phold = this.bem_get_1(bevl_j);
bevt_4_tmpany_phold = this.bem_get_1(bevl_c);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_4_tmpany_phold);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 298 */ {
bevl_c = bevl_j.bem_copy_0();
} /* Line: 299 */
bevl_j.bevi_int++;
} /* Line: 297 */
 else  /* Line: 297 */ {
break;
} /* Line: 297 */
} /* Line: 297 */
bevl_hold = this.bem_get_1(bevl_i);
bevt_5_tmpany_phold = this.bem_get_1(bevl_c);
this.bem_put_2(bevl_i, bevt_5_tmpany_phold);
this.bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 295 */
 else  /* Line: 295 */ {
break;
} /* Line: 295 */
} /* Line: 295 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_fi = (new BEC_2_4_3_MathInt(0));
bevl_si = (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 314 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 314 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 315 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 315 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 315 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 315 */
 else  /* Line: 315 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 315 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpany_phold = bevl_so.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fo);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpany_phold).bevi_bool) /* Line: 318 */ {
bevl_si.bevi_int++;
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 320 */
 else  /* Line: 321 */ {
bevl_fi.bevi_int++;
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 323 */
} /* Line: 318 */
 else  /* Line: 315 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 328 */
 else  /* Line: 315 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 329 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 332 */
} /* Line: 315 */
} /* Line: 315 */
bevl_i.bevi_int++;
} /* Line: 334 */
 else  /* Line: 314 */ {
break;
} /* Line: 314 */
} /* Line: 314 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = this.bem_mergeSort_2(bevt_1_tmpany_phold, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpany_phold = bevo_12;
if (bevl_mlen.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_2_tmpany_phold = this.bem_create_1(bevt_3_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevt_2_tmpany_phold;
} /* Line: 345 */
 else  /* Line: 344 */ {
bevt_5_tmpany_phold = bevo_13;
if (bevl_mlen.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) this.bem_create_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_8_tmpany_phold = this.bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 349 */
 else  /* Line: 350 */ {
bevt_9_tmpany_phold = bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpany_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = this.bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = this.bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) this.bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 358 */
} /* Line: 344 */
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 363 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(13, bels_2));
bevt_1_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 364 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) throws Throwable {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 370 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         this.bevi_list = java.util.Arrays.copyOf(this.bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 387 */
while (true)
 /* Line: 390 */ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 390 */ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 396 */
 else  /* Line: 390 */ {
break;
} /* Line: 390 */
} /* Line: 390 */
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 402 */ {
while (true)
 /* Line: 403 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 403 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 404 */
 else  /* Line: 403 */ {
break;
} /* Line: 403 */
} /* Line: 403 */
} /* Line: 403 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 410 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 411 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 416 */ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 422 */
 else  /* Line: 423 */ {
bevt_1_tmpany_phold = bevp_length.bem_copy_0();
this.bem_put_2(bevt_1_tmpany_phold, beva_val);
} /* Line: 425 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 430 */ {
bevt_2_tmpany_phold = beva_val.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 430 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 430 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 430 */
 else  /* Line: 430 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 430 */ {
this.bem_addAll_1(beva_val);
} /* Line: 431 */
 else  /* Line: 432 */ {
this.bem_addValueWhole_1(beva_val);
} /* Line: 433 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 439 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevl_aval = this.bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 441 */ {
bevt_3_tmpany_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 441 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 441 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 441 */
 else  /* Line: 441 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 441 */ {
return bevl_i;
} /* Line: 442 */
bevl_i.bevi_int++;
} /* Line: 439 */
 else  /* Line: 439 */ {
break;
} /* Line: 439 */
} /* Line: 439 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_find_1(beva_value);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 449 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 450 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = this.bem_sortedFind_2(beva_value, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) throws Throwable {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_high = bevp_length;
bevl_low = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 469 */ {
bevt_3_tmpany_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpany_phold = bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_divide_1(bevt_4_tmpany_phold);
bevl_mid = bevt_2_tmpany_phold.bem_add_1(bevl_low);
bevl_aval = this.bem_get_1(bevl_mid);
bevt_5_tmpany_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 472 */ {
return bevl_mid;
} /* Line: 473 */
 else  /* Line: 472 */ {
bevt_6_tmpany_phold = beva_value.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevl_aval);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 474 */ {
bevl_low = bevl_mid;
} /* Line: 476 */
 else  /* Line: 472 */ {
bevt_7_tmpany_phold = beva_value.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_aval);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpany_phold).bevi_bool) /* Line: 477 */ {
bevl_high = bevl_mid;
} /* Line: 479 */
} /* Line: 472 */
} /* Line: 472 */
if (bevl_lastMid == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 482 */ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 482 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 482 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 482 */
 else  /* Line: 482 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 482 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 483 */ {
bevt_11_tmpany_phold = this.bem_get_1(bevl_low);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, beva_value);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpany_phold).bevi_bool) /* Line: 483 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 483 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 483 */
 else  /* Line: 483 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 483 */ {
return bevl_low;
} /* Line: 484 */
return null;
} /* Line: 486 */
bevl_lastMid = bevl_mid;
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 489 */ {
return null;
} /* Line: 490 */
} /* Line: 489 */
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {134, 134, 134, 134, 134, 138, 142, 142, 0, 142, 142, 0, 0, 143, 143, 143, 145, 145, 148, 148, 149, 165, 166, 167, 172, 176, 176, 176, 177, 177, 179, 179, 189, 189, 193, 193, 197, 197, 201, 201, 201, 205, 205, 205, 205, 209, 209, 209, 210, 210, 210, 212, 212, 213, 213, 213, 224, 224, 224, 224, 224, 0, 0, 0, 231, 235, 235, 236, 236, 237, 237, 238, 238, 238, 239, 239, 240, 238, 242, 243, 243, 243, 244, 244, 246, 246, 250, 250, 254, 254, 258, 258, 258, 259, 258, 264, 265, 265, 265, 266, 266, 265, 268, 271, 271, 273, 273, 276, 276, 276, 276, 277, 0, 277, 277, 278, 280, 0, 280, 280, 281, 283, 287, 287, 291, 291, 295, 295, 295, 296, 297, 297, 297, 298, 298, 298, 299, 297, 302, 303, 303, 304, 295, 309, 310, 311, 312, 313, 314, 314, 315, 315, 315, 315, 0, 0, 0, 316, 317, 318, 319, 320, 322, 323, 325, 325, 326, 327, 328, 329, 329, 330, 331, 332, 334, 339, 339, 339, 343, 344, 344, 344, 345, 345, 345, 346, 346, 346, 347, 347, 348, 348, 348, 349, 351, 351, 352, 353, 354, 355, 356, 357, 358, 363, 364, 364, 364, 370, 370, 371, 387, 390, 390, 396, 398, 402, 402, 403, 404, 404, 410, 410, 411, 411, 416, 416, 422, 425, 425, 430, 430, 430, 0, 0, 0, 431, 433, 439, 439, 439, 440, 441, 441, 441, 0, 0, 0, 442, 439, 445, 449, 449, 449, 450, 450, 452, 452, 458, 458, 458, 465, 466, 470, 470, 470, 470, 471, 472, 473, 474, 476, 477, 479, 482, 482, 482, 482, 0, 0, 0, 483, 483, 0, 0, 0, 484, 486, 488, 489, 490, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {48, 49, 50, 51, 52, 56, 67, 72, 73, 76, 81, 82, 85, 89, 90, 91, 93, 98, 99, 104, 105, 110, 111, 112, 116, 123, 124, 129, 130, 131, 133, 134, 144, 145, 149, 150, 155, 156, 161, 162, 163, 169, 170, 171, 172, 182, 183, 188, 189, 190, 191, 193, 198, 199, 200, 201, 213, 214, 219, 220, 225, 226, 229, 233, 239, 254, 259, 260, 261, 262, 263, 264, 267, 272, 273, 274, 275, 276, 282, 283, 284, 285, 286, 287, 289, 290, 294, 295, 299, 300, 305, 308, 313, 314, 315, 328, 329, 332, 337, 338, 339, 340, 346, 350, 351, 355, 356, 368, 369, 370, 371, 372, 372, 375, 377, 378, 384, 384, 387, 389, 390, 396, 400, 401, 405, 406, 420, 423, 428, 429, 430, 433, 438, 439, 440, 441, 443, 445, 451, 452, 453, 454, 455, 478, 479, 480, 481, 482, 485, 490, 491, 496, 497, 502, 503, 506, 510, 513, 514, 515, 517, 518, 521, 522, 526, 531, 532, 533, 534, 537, 542, 543, 544, 545, 549, 560, 561, 562, 582, 583, 584, 589, 590, 591, 592, 595, 596, 601, 602, 603, 604, 605, 606, 607, 610, 611, 612, 613, 614, 615, 616, 617, 618, 626, 628, 629, 630, 638, 643, 644, 647, 651, 656, 659, 665, 672, 677, 680, 682, 683, 695, 700, 701, 702, 709, 714, 717, 720, 721, 729, 734, 735, 737, 740, 744, 747, 750, 761, 764, 769, 770, 771, 776, 777, 779, 782, 786, 789, 791, 797, 804, 805, 810, 811, 812, 814, 815, 820, 821, 822, 843, 844, 847, 848, 849, 850, 851, 852, 854, 857, 859, 862, 864, 868, 873, 874, 879, 880, 883, 887, 891, 892, 894, 897, 901, 904, 906, 908, 909, 911, 916, 919, 922, 925};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 134 48
new 0 134 48
assign 1 134 49
once 0 134 49
assign 1 134 50
new 0 134 50
assign 1 134 51
once 0 134 51
new 2 134 52
new 2 138 56
assign 1 142 67
undef 1 142 72
assign 1 0 73
assign 1 142 76
undef 1 142 81
assign 1 0 82
assign 1 0 85
assign 1 143 89
new 0 143 89
assign 1 143 90
new 1 143 90
throw 1 143 91
assign 1 145 93
def 1 145 98
assign 1 148 99
equals 1 148 104
return 1 149 105
assign 1 165 110
copy 0 165 110
assign 1 166 111
copy 0 166 111
assign 1 167 112
new 0 167 112
return 1 172 116
assign 1 176 123
new 0 176 123
assign 1 176 124
equals 1 176 129
assign 1 177 130
new 0 177 130
return 1 177 131
assign 1 179 133
new 0 179 133
return 1 179 134
assign 1 189 144
toString 0 189 144
return 1 189 145
assign 1 193 149
new 1 193 149
new 1 193 150
assign 1 197 155
iteratorGet 0 197 155
return 1 197 156
assign 1 201 161
new 0 201 161
assign 1 201 162
get 1 201 162
return 1 201 163
assign 1 205 169
new 0 205 169
assign 1 205 170
subtract 1 205 170
assign 1 205 171
get 1 205 171
return 1 205 172
assign 1 209 182
new 0 209 182
assign 1 209 183
lesser 1 209 188
assign 1 210 189
new 0 210 189
assign 1 210 190
new 1 210 190
throw 1 210 191
assign 1 212 193
greaterEquals 1 212 198
assign 1 213 199
new 0 213 199
assign 1 213 200
add 1 213 200
lengthSet 1 213 201
assign 1 224 213
new 0 224 213
assign 1 224 214
greaterEquals 1 224 219
assign 1 224 220
lesser 1 224 225
assign 1 0 226
assign 1 0 229
assign 1 0 233
return 1 231 239
assign 1 235 254
lesser 1 235 259
assign 1 236 260
new 0 236 260
assign 1 236 261
subtract 1 236 261
assign 1 237 262
new 0 237 262
assign 1 237 263
add 1 237 263
assign 1 238 264
copy 0 238 264
assign 1 238 267
lesser 1 238 272
assign 1 239 273
get 1 239 273
put 2 239 274
incrementValue 0 240 275
incrementValue 0 238 276
put 2 242 282
assign 1 243 283
new 0 243 283
assign 1 243 284
subtract 1 243 284
lengthSet 1 243 285
assign 1 244 286
new 0 244 286
return 1 244 287
assign 1 246 289
new 0 246 289
return 1 246 290
assign 1 250 294
new 1 250 294
return 1 250 295
assign 1 254 299
new 1 254 299
return 1 254 300
assign 1 258 305
new 0 258 305
assign 1 258 308
lesser 1 258 313
put 2 259 314
incrementValue 0 258 315
assign 1 264 328
create 0 264 328
assign 1 265 329
new 0 265 329
assign 1 265 332
lesser 1 265 337
assign 1 266 338
get 1 266 338
put 2 266 339
incrementValue 0 265 340
return 1 268 346
assign 1 271 350
new 1 271 350
return 1 271 351
assign 1 273 355
new 1 273 355
return 1 273 356
assign 1 276 368
new 0 276 368
assign 1 276 369
lengthGet 0 276 369
assign 1 276 370
add 1 276 370
assign 1 276 371
new 2 276 371
assign 1 277 372
iteratorGet 0 0 372
assign 1 277 375
hasNextGet 0 277 375
assign 1 277 377
nextGet 0 277 377
addValueWhole 1 278 378
assign 1 280 384
iteratorGet 0 0 384
assign 1 280 387
hasNextGet 0 280 387
assign 1 280 389
nextGet 0 280 389
addValueWhole 1 281 390
return 1 283 396
assign 1 287 400
mergeSort 0 287 400
return 1 287 401
assign 1 291 405
new 0 291 405
sortValue 2 291 406
assign 1 295 420
copy 0 295 420
assign 1 295 423
lesser 1 295 428
assign 1 296 429
copy 0 296 429
assign 1 297 430
copy 0 297 430
assign 1 297 433
lesser 1 297 438
assign 1 298 439
get 1 298 439
assign 1 298 440
get 1 298 440
assign 1 298 441
lesser 1 298 441
assign 1 299 443
copy 0 299 443
incrementValue 0 297 445
assign 1 302 451
get 1 302 451
assign 1 303 452
get 1 303 452
put 2 303 453
put 2 304 454
incrementValue 0 295 455
assign 1 309 478
new 0 309 478
assign 1 310 479
new 0 310 479
assign 1 311 480
new 0 311 480
assign 1 312 481
lengthGet 0 312 481
assign 1 313 482
lengthGet 0 313 482
assign 1 314 485
lesser 1 314 490
assign 1 315 491
lesser 1 315 496
assign 1 315 497
lesser 1 315 502
assign 1 0 503
assign 1 0 506
assign 1 0 510
assign 1 316 513
get 1 316 513
assign 1 317 514
get 1 317 514
assign 1 318 515
lesser 1 318 515
incrementValue 0 319 517
put 2 320 518
incrementValue 0 322 521
put 2 323 522
assign 1 325 526
lesser 1 325 531
assign 1 326 532
get 1 326 532
incrementValue 0 327 533
put 2 328 534
assign 1 329 537
lesser 1 329 542
assign 1 330 543
get 1 330 543
incrementValue 0 331 544
put 2 332 545
incrementValue 0 334 549
assign 1 339 560
new 0 339 560
assign 1 339 561
mergeSort 2 339 561
return 1 339 562
assign 1 343 582
subtract 1 343 582
assign 1 344 583
new 0 344 583
assign 1 344 584
equals 1 344 589
assign 1 345 590
new 0 345 590
assign 1 345 591
create 1 345 591
return 1 345 592
assign 1 346 595
new 0 346 595
assign 1 346 596
equals 1 346 601
assign 1 347 602
new 0 347 602
assign 1 347 603
create 1 347 603
assign 1 348 604
new 0 348 604
assign 1 348 605
get 1 348 605
put 2 348 606
return 1 349 607
assign 1 351 610
new 0 351 610
assign 1 351 611
divide 1 351 611
assign 1 352 612
subtract 1 352 612
assign 1 353 613
add 1 353 613
assign 1 354 614
mergeSort 2 354 614
assign 1 355 615
mergeSort 2 355 615
assign 1 356 616
create 1 356 616
mergeIn 2 357 617
return 1 358 618
assign 1 363 626
new 0 363 626
assign 1 364 628
new 0 364 628
assign 1 364 629
new 1 364 629
throw 1 364 630
assign 1 370 638
greater 1 370 643
assign 1 371 644
multiply 1 371 644
assign 1 387 647
assign 1 390 651
lesser 1 390 656
incrementValue 0 396 659
setValue 1 398 665
assign 1 402 672
def 1 402 677
assign 1 403 680
hasNextGet 0 403 680
assign 1 404 682
nextGet 0 404 682
addValueWhole 1 404 683
assign 1 410 695
def 1 410 700
assign 1 411 701
iteratorGet 0 411 701
iterateAdd 1 411 702
assign 1 416 709
lesser 1 416 714
incrementValue 0 422 717
assign 1 425 720
copy 0 425 720
put 2 425 721
assign 1 430 729
def 1 430 734
assign 1 430 735
sameType 1 430 735
assign 1 0 737
assign 1 0 740
assign 1 0 744
addAll 1 431 747
addValueWhole 1 433 750
assign 1 439 761
new 0 439 761
assign 1 439 764
lesser 1 439 769
assign 1 440 770
get 1 440 770
assign 1 441 771
def 1 441 776
assign 1 441 777
equals 1 441 777
assign 1 0 779
assign 1 0 782
assign 1 0 786
return 1 442 789
incrementValue 0 439 791
return 1 445 797
assign 1 449 804
find 1 449 804
assign 1 449 805
def 1 449 810
assign 1 450 811
new 0 450 811
return 1 450 812
assign 1 452 814
new 0 452 814
return 1 452 815
assign 1 458 820
new 0 458 820
assign 1 458 821
sortedFind 2 458 821
return 1 458 822
assign 1 465 843
assign 1 466 844
new 0 466 844
assign 1 470 847
subtract 1 470 847
assign 1 470 848
new 0 470 848
assign 1 470 849
divide 1 470 849
assign 1 470 850
add 1 470 850
assign 1 471 851
get 1 471 851
assign 1 472 852
equals 1 472 852
return 1 473 854
assign 1 474 857
greater 1 474 857
assign 1 476 859
assign 1 477 862
lesser 1 477 862
assign 1 479 864
assign 1 482 868
def 1 482 873
assign 1 482 874
equals 1 482 879
assign 1 0 880
assign 1 0 883
assign 1 0 887
assign 1 483 891
get 1 483 891
assign 1 483 892
lesser 1 483 892
assign 1 0 894
assign 1 0 897
assign 1 0 901
return 1 484 904
return 1 486 906
assign 1 488 908
assign 1 489 909
new 0 489 909
return 1 490 911
return 1 0 916
return 1 0 919
return 1 0 922
assign 1 0 925
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1525854240: return bem_arrayIteratorGet_0();
case 1990707345: return bem_lastGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1774940957: return bem_toString_0();
case -183400265: return bem_firstGet_0();
case -1354714650: return bem_copy_0();
case -1308786538: return bem_echo_0();
case 856777406: return bem_clear_0();
case 188061735: return bem_mergeSort_0();
case -729571811: return bem_serializeToString_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 474162694: return bem_sizeGet_0();
case 1479417926: return bem_multiplierGet_0();
case 1616433729: return bem_lengthGet_0();
case -1756567691: return bem_anyraySet_0();
case -1767649943: return bem_anyrayGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1751843603: return bem_capacityGet_0();
case -1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case -1081412016: return bem_many_0();
case -896593457: return bem_sort_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 1089531140: return bem_isEmptyGet_0();
case -845792839: return bem_iteratorGet_0();
case -314718434: return bem_print_0();
case 1478277476: return bem_sortValue_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 819712669: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case 1627515982: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -1263766286: return bem_addAll_1(bevd_0);
case 1820417454: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case -1740761350: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1490500179: return bem_multiplierSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1274448085: return bem_find_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case -228068295: return bem_addValueWhole_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 518108232: return bem_sortedFind_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 518108233: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 188061737: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 104713555: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1478277478: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1626710000: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerList.bevs_inst = (BEC_2_9_4_ContainerList)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerList.bevs_inst;
}
}
