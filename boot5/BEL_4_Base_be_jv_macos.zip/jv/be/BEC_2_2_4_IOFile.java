package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_2_4_IOFile extends BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOFile() { }
private static byte[] becc_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_2_2_4_IOFile bevs_inst;
public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_2_6_6_SystemObject bevp_reader;
public BEC_2_6_6_SystemObject bevp_writer;
public BEC_2_2_4_IOFile bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_new_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath);
this.bem_pathSet_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_apNew_1(BEC_2_6_6_SystemObject beva_fpath) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) beva_fpath);
this.bem_pathSet_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__path) throws Throwable {
this.bem_pathSet_1(beva__path);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
if (bevp_reader == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 62 */ {
bevt_1_tmpvar_phold = bevp_path.bem_toString_0();
bevp_reader = (new BEC_3_2_4_6_IOFileReader()).bem_new_1(bevt_1_tmpvar_phold);
} /* Line: 63 */
return bevp_reader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
if (bevp_writer == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 69 */ {
bevt_1_tmpvar_phold = bevp_path.bem_toString_0();
bevp_writer = (new BEC_3_2_4_6_IOFileWriter()).bem_new_1(bevt_1_tmpvar_phold);
} /* Line: 70 */
return bevp_writer;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_llpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_existsGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 86 */ {

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
         bevls_f.delete();
         } /* Line: 99 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copyFile_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_outw = null;
BEC_3_2_4_6_IOFileReader bevl_inr = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bemd_0(-400189342, BEL_4_Base.bevn_pathGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(992607997, BEL_4_Base.bevn_parentGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_0_tmpvar_phold.bemd_0(-181594299, BEL_4_Base.bevn_makeDirs_0);
bevt_3_tmpvar_phold = beva_other.bemd_0(-2037163820, BEL_4_Base.bevn_writerGet_0);
bevl_outw = (BEC_3_2_4_6_IOFileWriter) bevt_3_tmpvar_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_4_tmpvar_phold = this.bem_readerGet_0();
bevl_inr = (BEC_3_2_4_6_IOFileReader) bevt_4_tmpvar_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_inr.bem_copyData_1(bevl_outw);
bevl_inr.bem_close_0();
bevl_outw.bem_close_0();
bevt_5_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mkdirs_0() throws Throwable {
this.bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mkdir_0() throws Throwable {
this.bem_makeDirs_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeDirs_0() throws Throwable {
BEC_2_4_6_TextString bevl_frs = null;
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_5_4_LogicBool bevl_t = null;
BEC_2_6_6_SystemObject bevl_strn = null;
BEC_2_6_6_SystemObject bevl_parentpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
bevl_frs = bevp_path.bem_toString_0();
bevl_r = be.BECS_Runtime.boolFalse;
bevl_t = be.BECS_Runtime.boolTrue;
bevl_strn = BEC_2_4_7_TextStrings.bevs_inst;
bevt_2_tmpvar_phold = bevp_path.bem_toString_0();
bevt_3_tmpvar_phold = bevl_strn.bemd_0(-1081741254, BEL_4_Base.bevn_emptyGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 138 */ {
bevt_5_tmpvar_phold = this.bem_existsGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
 else  /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevl_parentpath = bevp_path.bem_parentGet_0();
bevt_6_tmpvar_phold = bevp_path.bem_equals_1(bevl_parentpath);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 140 */ {
return this;
} /* Line: 142 */
bevt_7_tmpvar_phold = bevl_parentpath.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold.bemd_0(-181594299, BEL_4_Base.bevn_makeDirs_0);

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
         bevls_f.mkdir();
         } /* Line: 167 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDirectoryGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_isDirGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDirGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpvar_phold = this.bem_existsGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 194 */ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
          if (bevls_f.isDirectory()) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 219 */
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFileGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_result = be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpvar_phold = this.bem_existsGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 242 */ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
          if (bevls_f.isFile()) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 267 */
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeFile_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_writerGet_0();
bevt_0_tmpvar_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_1_tmpvar_phold = this.bem_writerGet_0();
bevt_1_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_existsGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 285 */ {
return null;
} /* Line: 286 */
bevt_2_tmpvar_phold = this.bem_contentsNoCheckGet_0();
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsNoCheckGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_4_6_TextString bevl_res = null;
bevl_r = this.bem_readerGet_0();
bevl_r.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_res = (BEC_2_4_6_TextString) bevl_r.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_r.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return bevl_res;
} /*method end*/
public BEC_2_2_4_IOFile bem_contentsSet_1(BEC_2_4_6_TextString beva_contents) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpvar_phold = null;
bevt_4_tmpvar_phold = this.bem_pathGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_parentGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_fileGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_existsGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevt_7_tmpvar_phold = this.bem_pathGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_parentGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_fileGet_0();
bevt_5_tmpvar_phold.bem_makeDirs_0();
} /* Line: 301 */
this.bem_contentsNoCheckSet_1(beva_contents);
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_contentsNoCheckSet_1(BEC_2_4_6_TextString beva_contents) throws Throwable {
BEC_2_6_6_SystemObject bevl_w = null;
bevl_w = this.bem_writerGet_0();
bevl_w.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, beva_contents);
bevl_w.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
bevl_sz = (new BEC_2_4_3_MathInt());

    java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
    bevl_sz.bevi_int = (int) bevls_f.length();
    return bevl_sz;
} /*method end*/
public BEC_2_5_4_LogicBool bem_existsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_tvala = null;
BEC_2_6_6_SystemObject bevl_mpath = null;
bevl_tvala = be.BECS_Runtime.boolFalse;
bevl_mpath = bevp_path.bem_toString_0();

      java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
      if (bevls_f.exists()) {
        bevl_tvala = be.BECS_Runtime.boolTrue;
      }
      return bevl_tvala;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_absPathGet_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_absp = null;
BEC_2_4_6_TextString bevl_abstr = null;
 /* Line: 377 */ {

        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
        //bevl_abstr = new BEC_2_4_6_TextString(bevls_f.toPath().toRealPath().toString());
        bevl_abstr = new BEC_2_4_6_TextString(bevls_f.getCanonicalPath());
        } /* Line: 378 */
bevl_absp = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_abstr);
return bevl_absp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_close_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
if (bevp_reader == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevp_reader.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 392 */
if (bevp_writer == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 394 */ {
bevp_writer.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 395 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_2_4_17_IOFileDirectoryIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_2_4_17_IOFileDirectoryIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_6_6_SystemObject bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_reader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_writer = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {50, 50, 54, 54, 58, 62, 62, 63, 63, 65, 69, 69, 70, 70, 72, 86, 109, 109, 109, 109, 110, 110, 111, 111, 112, 113, 114, 115, 115, 120, 123, 134, 135, 136, 137, 138, 138, 138, 138, 138, 138, 0, 0, 0, 139, 140, 142, 144, 144, 180, 180, 192, 193, 194, 228, 240, 241, 242, 276, 280, 280, 281, 281, 285, 285, 285, 286, 288, 288, 292, 293, 294, 295, 296, 300, 300, 300, 300, 300, 300, 301, 301, 301, 301, 303, 307, 308, 309, 310, 315, 322, 334, 335, 369, 386, 387, 391, 391, 392, 394, 394, 395, 400, 400, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 24, 25, 29, 35, 40, 41, 42, 44, 49, 54, 55, 56, 58, 63, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 95, 99, 116, 117, 118, 119, 120, 121, 122, 124, 125, 130, 131, 134, 138, 141, 142, 144, 146, 147, 156, 157, 163, 164, 165, 173, 179, 180, 181, 189, 194, 195, 196, 197, 204, 205, 210, 211, 213, 214, 219, 220, 221, 222, 223, 234, 235, 236, 237, 238, 243, 244, 245, 246, 247, 249, 254, 255, 256, 257, 262, 266, 271, 272, 278, 289, 290, 295, 300, 301, 303, 308, 309, 315, 316, 319, 322, 326, 330};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 50 18
new 1 50 18
pathSet 1 50 19
assign 1 54 24
apNew 1 54 24
pathSet 1 54 25
pathSet 1 58 29
assign 1 62 35
undef 1 62 40
assign 1 63 41
toString 0 63 41
assign 1 63 42
new 1 63 42
return 1 65 44
assign 1 69 49
undef 1 69 54
assign 1 70 55
toString 0 70 55
assign 1 70 56
new 1 70 56
return 1 72 58
assign 1 86 63
existsGet 0 86 63
assign 1 109 80
pathGet 0 109 80
assign 1 109 81
parentGet 0 109 81
assign 1 109 82
fileGet 0 109 82
makeDirs 0 109 83
assign 1 110 84
writerGet 0 110 84
assign 1 110 85
open 0 110 85
assign 1 111 86
readerGet 0 111 86
assign 1 111 87
open 0 111 87
copyData 1 112 88
close 0 113 89
close 0 114 90
assign 1 115 91
new 0 115 91
return 1 115 92
makeDirs 0 120 95
makeDirs 0 123 99
assign 1 134 116
toString 0 134 116
assign 1 135 117
new 0 135 117
assign 1 136 118
new 0 136 118
assign 1 137 119
new 0 137 119
assign 1 138 120
toString 0 138 120
assign 1 138 121
emptyGet 0 138 121
assign 1 138 122
notEquals 1 138 122
assign 1 138 124
existsGet 0 138 124
assign 1 138 125
not 0 138 130
assign 1 0 131
assign 1 0 134
assign 1 0 138
assign 1 139 141
parentGet 0 139 141
assign 1 140 142
equals 1 140 142
return 1 142 144
assign 1 144 146
fileGet 0 144 146
makeDirs 0 144 147
assign 1 180 156
isDirGet 0 180 156
return 1 180 157
assign 1 192 163
new 0 192 163
assign 1 193 164
toString 0 193 164
assign 1 194 165
existsGet 0 194 165
return 1 228 173
assign 1 240 179
new 0 240 179
assign 1 241 180
toString 0 241 180
assign 1 242 181
existsGet 0 242 181
return 1 276 189
assign 1 280 194
writerGet 0 280 194
open 0 280 195
assign 1 281 196
writerGet 0 281 196
close 0 281 197
assign 1 285 204
existsGet 0 285 204
assign 1 285 205
not 0 285 210
return 1 286 211
assign 1 288 213
contentsNoCheckGet 0 288 213
return 1 288 214
assign 1 292 219
readerGet 0 292 219
open 0 293 220
assign 1 294 221
readString 0 294 221
close 0 295 222
return 1 296 223
assign 1 300 234
pathGet 0 300 234
assign 1 300 235
parentGet 0 300 235
assign 1 300 236
fileGet 0 300 236
assign 1 300 237
existsGet 0 300 237
assign 1 300 238
not 0 300 243
assign 1 301 244
pathGet 0 301 244
assign 1 301 245
parentGet 0 301 245
assign 1 301 246
fileGet 0 301 246
makeDirs 0 301 247
contentsNoCheckSet 1 303 249
assign 1 307 254
writerGet 0 307 254
open 0 308 255
write 1 309 256
close 0 310 257
assign 1 315 262
new 0 315 262
return 1 322 266
assign 1 334 271
new 0 334 271
assign 1 335 272
toString 0 335 272
return 1 369 278
assign 1 386 289
apNew 1 386 289
return 1 387 290
assign 1 391 295
def 1 391 300
close 0 392 301
assign 1 394 303
def 1 394 308
close 0 395 309
assign 1 400 315
new 1 400 315
return 1 400 316
return 1 0 319
assign 1 0 322
assign 1 0 326
assign 1 0 330
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 371906180: return bem_readerGet_0();
case -209284380: return bem_isDirectoryGet_0();
case -1081412016: return bem_many_0();
case -181594299: return bem_makeDirs_0();
case 129806037: return bem_mkdirs_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -574873532: return bem_isDirGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case -160463007: return bem_isFileGet_0();
case 2072547979: return bem_existsGet_0();
case 108109840: return bem_absPathGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 866536361: return bem_close_0();
case 547861133: return bem_contentsGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -124528197: return bem_makeFile_0();
case -729571811: return bem_serializeToString_0();
case 439054906: return bem_contentsNoCheckGet_0();
case -1354714650: return bem_copy_0();
case 819712668: return bem_delete_0();
case -400189342: return bem_pathGet_0();
case 1112565280: return bem_mkdir_0();
case -2037163820: return bem_writerGet_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 450137159: return bem_contentsNoCheckSet_1((BEC_2_4_6_TextString) bevd_0);
case -389107089: return bem_pathSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1294597629: return bem_copyFile_1(bevd_0);
case 382988433: return bem_readerSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -393721811: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -824830365: return bem_apNew_1(bevd_0);
case -2026081567: return bem_writerSet_1(bevd_0);
case 558943386: return bem_contentsSet_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_4_IOFile();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_4_IOFile.bevs_inst = (BEC_2_2_4_IOFile)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_4_IOFile.bevs_inst;
}
}
