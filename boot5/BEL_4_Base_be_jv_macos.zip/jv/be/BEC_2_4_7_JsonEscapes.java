package be;
/* IO:File: source/extended/Json.be */
public final class BEC_2_4_7_JsonEscapes extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_JsonEscapes() { }
private static byte[] becc_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x45,0x73,0x63,0x61,0x70,0x65,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x5C};
private static byte[] bels_1 = {0x5C,0x5C};
private static byte[] bels_2 = {0x5C};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_2, 1));
private static byte[] bels_3 = {0x08};
private static byte[] bels_4 = {0x5C,0x62};
private static byte[] bels_5 = {0x0C};
private static byte[] bels_6 = {0x5C,0x66};
private static byte[] bels_7 = {0x0A};
private static byte[] bels_8 = {0x5C,0x6E};
private static byte[] bels_9 = {0x0D};
private static byte[] bels_10 = {0x5C,0x72};
private static byte[] bels_11 = {0x09};
private static byte[] bels_12 = {0x5C,0x74};
private static byte[] bels_13 = {0x2F};
private static byte[] bels_14 = {0x5C,0x2F};
private static byte[] bels_15 = {0x5C};
private static byte[] bels_16 = {0x5C};
private static byte[] bels_17 = {0x62};
private static byte[] bels_18 = {0x08};
private static byte[] bels_19 = {0x66};
private static byte[] bels_20 = {0x0C};
private static byte[] bels_21 = {0x6E};
private static byte[] bels_22 = {0x0A};
private static byte[] bels_23 = {0x72};
private static byte[] bels_24 = {0x0D};
private static byte[] bels_25 = {0x74};
private static byte[] bels_26 = {0x09};
private static byte[] bels_27 = {0x2F};
private static byte[] bels_28 = {0x2F};
public static BEC_2_4_7_JsonEscapes bevs_inst;
public BEC_2_9_3_ContainerMap bevp_toEscapes;
public BEC_2_9_3_ContainerMap bevp_fromEscapes;
public BEC_2_4_7_JsonEscapes bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
bevp_toEscapes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_fromEscapes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_0));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_1));
bevp_toEscapes.bem_put_2(bevt_0_tmpany_phold, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_quoteGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_9_tmpany_phold = bevo_0;
bevt_11_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_quoteGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevp_toEscapes.bem_put_2(bevt_4_tmpany_phold, bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_3));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_4));
bevp_toEscapes.bem_put_2(bevt_12_tmpany_phold, bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_5));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_6));
bevp_toEscapes.bem_put_2(bevt_16_tmpany_phold, bevt_19_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_7));
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_8));
bevp_toEscapes.bem_put_2(bevt_20_tmpany_phold, bevt_23_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_9));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_10));
bevp_toEscapes.bem_put_2(bevt_24_tmpany_phold, bevt_27_tmpany_phold);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_11));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_12));
bevp_toEscapes.bem_put_2(bevt_28_tmpany_phold, bevt_31_tmpany_phold);
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_13));
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_14));
bevp_toEscapes.bem_put_2(bevt_32_tmpany_phold, bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_15));
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_16));
bevp_fromEscapes.bem_put_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_quoteGet_0();
bevt_41_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_quoteGet_0();
bevp_fromEscapes.bem_put_2(bevt_38_tmpany_phold, bevt_40_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_17));
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_18));
bevp_fromEscapes.bem_put_2(bevt_42_tmpany_phold, bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_19));
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_20));
bevp_fromEscapes.bem_put_2(bevt_44_tmpany_phold, bevt_45_tmpany_phold);
bevt_46_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_21));
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_22));
bevp_fromEscapes.bem_put_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_23));
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_24));
bevp_fromEscapes.bem_put_2(bevt_48_tmpany_phold, bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_25));
bevt_51_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_26));
bevp_fromEscapes.bem_put_2(bevt_50_tmpany_phold, bevt_51_tmpany_phold);
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_27));
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_28));
bevp_fromEscapes.bem_put_2(bevt_52_tmpany_phold, bevt_53_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_toEscapesGet_0() throws Throwable {
return bevp_toEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_toEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fromEscapesGet_0() throws Throwable {
return bevp_fromEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_fromEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {265, 266, 268, 268, 268, 268, 268, 269, 269, 269, 269, 269, 269, 269, 269, 269, 270, 270, 270, 270, 270, 271, 271, 271, 271, 271, 272, 272, 272, 272, 272, 273, 273, 273, 273, 273, 274, 274, 274, 274, 274, 275, 275, 275, 275, 275, 277, 277, 277, 278, 278, 278, 278, 278, 279, 279, 279, 280, 280, 280, 281, 281, 281, 282, 282, 282, 283, 283, 283, 284, 284, 284, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 173, 176, 180, 183};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 265 98
new 0 265 98
assign 1 266 99
new 0 266 99
assign 1 268 100
new 0 268 100
assign 1 268 101
new 0 268 101
assign 1 268 102
addValue 1 268 102
assign 1 268 103
new 0 268 103
put 2 268 104
assign 1 269 105
new 0 269 105
assign 1 269 106
new 0 269 106
assign 1 269 107
quoteGet 0 269 107
assign 1 269 108
addValue 1 269 108
assign 1 269 109
new 0 269 109
assign 1 269 110
new 0 269 110
assign 1 269 111
quoteGet 0 269 111
assign 1 269 112
add 1 269 112
put 2 269 113
assign 1 270 114
new 0 270 114
assign 1 270 115
new 0 270 115
assign 1 270 116
addValue 1 270 116
assign 1 270 117
new 0 270 117
put 2 270 118
assign 1 271 119
new 0 271 119
assign 1 271 120
new 0 271 120
assign 1 271 121
addValue 1 271 121
assign 1 271 122
new 0 271 122
put 2 271 123
assign 1 272 124
new 0 272 124
assign 1 272 125
new 0 272 125
assign 1 272 126
addValue 1 272 126
assign 1 272 127
new 0 272 127
put 2 272 128
assign 1 273 129
new 0 273 129
assign 1 273 130
new 0 273 130
assign 1 273 131
addValue 1 273 131
assign 1 273 132
new 0 273 132
put 2 273 133
assign 1 274 134
new 0 274 134
assign 1 274 135
new 0 274 135
assign 1 274 136
addValue 1 274 136
assign 1 274 137
new 0 274 137
put 2 274 138
assign 1 275 139
new 0 275 139
assign 1 275 140
new 0 275 140
assign 1 275 141
addValue 1 275 141
assign 1 275 142
new 0 275 142
put 2 275 143
assign 1 277 144
new 0 277 144
assign 1 277 145
new 0 277 145
put 2 277 146
assign 1 278 147
new 0 278 147
assign 1 278 148
quoteGet 0 278 148
assign 1 278 149
new 0 278 149
assign 1 278 150
quoteGet 0 278 150
put 2 278 151
assign 1 279 152
new 0 279 152
assign 1 279 153
new 0 279 153
put 2 279 154
assign 1 280 155
new 0 280 155
assign 1 280 156
new 0 280 156
put 2 280 157
assign 1 281 158
new 0 281 158
assign 1 281 159
new 0 281 159
put 2 281 160
assign 1 282 161
new 0 282 161
assign 1 282 162
new 0 282 162
put 2 282 163
assign 1 283 164
new 0 283 164
assign 1 283 165
new 0 283 165
put 2 283 166
assign 1 284 167
new 0 284 167
assign 1 284 168
new 0 284 168
put 2 284 169
return 1 0 173
assign 1 0 176
return 1 0 180
assign 1 0 183
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 375985503: return bem_fromEscapesGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case 2029017776: return bem_toEscapesGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -1211344638: return bem_undefined_1(bevd_0);
case 387067756: return bem_fromEscapesSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2040100029: return bem_toEscapesSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_JsonEscapes();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_JsonEscapes.bevs_inst = (BEC_2_4_7_JsonEscapes)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_JsonEscapes.bevs_inst;
}
}
