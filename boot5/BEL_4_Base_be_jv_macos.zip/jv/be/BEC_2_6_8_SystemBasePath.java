package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemBasePath extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public BEC_2_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_tmpany_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_8_SystemBasePath bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_other.bemd_0(-400189342, BEL_4_Base.bevn_pathGet_0);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 378 */ {
bevt_4_tmpany_phold = this.bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_tmpany_phold;
} /* Line: 379 */
bevt_5_tmpany_phold = beva_other.bemd_0(1359432006, BEL_4_Base.bevn_isAbsoluteGet_0);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 381 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
return (BEC_2_6_8_SystemBasePath) bevt_6_tmpany_phold;
} /* Line: 382 */
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpany_phold = beva_other.bemd_0(-400189342, BEL_4_Base.bevn_pathGet_0);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_tmpany_phold.bemd_1(-2001811380, BEL_4_Base.bevn_split_1, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 386 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 386 */ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 388 */
 else  /* Line: 386 */ {
break;
} /* Line: 386 */
} /* Line: 386 */
bevt_9_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_tmpany_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = this.bem_copy_0();
bevl_rpath = bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = this.bem_copy_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 404 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 404 */ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_tmpany_phold);
} /* Line: 406 */
 else  /* Line: 407 */ {
bevl_i.bem_nextGet_0();
} /* Line: 408 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 410 */
 else  /* Line: 404 */ {
break;
} /* Line: 404 */
} /* Line: 404 */
bevt_4_tmpany_phold = this.bem_isAbsoluteGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 412 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 413 */
return bevl_rpath;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (bevp_path == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 419 */ {
bevt_4_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_sizeGet_0();
bevt_5_tmpany_phold = bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 419 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 419 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 419 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 419 */
bevt_9_tmpany_phold = bevo_1;
bevt_8_tmpany_phold = bevp_path.bem_getPoint_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 420 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 421 */
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 427 */ {
bevt_1_tmpany_phold = bevo_2;
bevt_2_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 428 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_isAbsoluteGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 433 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 434 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_3;
if (beva_howMany.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 439 */ {
this.bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 444 */ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 444 */ {
if (bevl_next == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 445 */ {
break;
} /* Line: 445 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 444 */
 else  /* Line: 444 */ {
break;
} /* Line: 444 */
} /* Line: 444 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 450 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 462 */ {
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_tmpany_phold.bem_emptyGet_0();
} /* Line: 463 */
 else  /* Line: 464 */ {
bevt_3_tmpany_phold = bevo_4;
bevt_2_tmpany_phold = bevl_fp.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
} /* Line: 465 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 471 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 471 */ {
bevt_1_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_tmpany_phold);
} /* Line: 472 */
 else  /* Line: 471 */ {
break;
} /* Line: 471 */
} /* Line: 471 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_addStep_1(beva_step);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_copy_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_2_6_8_SystemBasePath) this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
return (BEC_2_6_8_SystemBasePath) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 511 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 511 */ {
bevt_3_tmpany_phold = beva_x.bemd_1(-1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 511 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 511 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 511 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 511 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 511 */ {
bevt_5_tmpany_phold = beva_x.bemd_0(-400189342, BEL_4_Base.bevn_pathGet_0);
bevt_4_tmpany_phold = bevp_path.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 511 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 511 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 511 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 511 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 512 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_subPath_2(beva_start, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevl_st = this.bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 523 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 524 */
 else  /* Line: 525 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 526 */
bevl_res = this.bem_create_0();
bevl_res.bemd_1(410741679, BEL_4_Base.bevn_separatorSet_1, bevp_separator);
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(-389107089, BEL_4_Base.bevn_pathSet_1, bevt_1_tmpany_phold);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {339, 339, 343, 344, 348, 352, 356, 356, 360, 361, 361, 362, 366, 366, 370, 370, 370, 374, 374, 374, 378, 378, 378, 378, 379, 379, 381, 382, 382, 384, 385, 385, 386, 386, 387, 388, 390, 390, 391, 392, 394, 398, 399, 400, 400, 401, 402, 403, 404, 404, 405, 405, 406, 406, 408, 410, 412, 413, 415, 419, 419, 0, 419, 419, 419, 419, 419, 0, 0, 419, 419, 420, 420, 420, 421, 421, 423, 423, 427, 428, 428, 428, 433, 433, 433, 434, 439, 439, 439, 440, 441, 443, 444, 444, 444, 445, 445, 446, 447, 448, 444, 450, 455, 456, 457, 461, 462, 462, 463, 463, 465, 465, 465, 465, 470, 471, 471, 472, 472, 474, 478, 478, 482, 483, 484, 485, 489, 490, 491, 491, 492, 496, 496, 500, 500, 504, 504, 504, 511, 511, 0, 511, 0, 0, 0, 511, 511, 0, 0, 512, 512, 514, 514, 518, 518, 522, 523, 523, 524, 526, 528, 529, 530, 530, 530, 531, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 25, 26, 30, 34, 38, 39, 45, 46, 47, 48, 52, 53, 58, 59, 60, 65, 66, 67, 86, 87, 88, 89, 91, 92, 94, 96, 97, 99, 100, 101, 102, 105, 107, 108, 114, 115, 116, 117, 118, 131, 132, 133, 134, 135, 136, 137, 138, 141, 143, 148, 149, 150, 153, 155, 161, 163, 165, 180, 185, 186, 189, 190, 191, 192, 197, 198, 201, 205, 206, 208, 209, 210, 212, 213, 215, 216, 222, 224, 225, 226, 233, 234, 239, 240, 253, 254, 259, 260, 261, 262, 263, 266, 271, 272, 277, 280, 281, 282, 283, 289, 295, 296, 297, 307, 308, 313, 314, 315, 318, 319, 320, 321, 330, 331, 334, 336, 337, 343, 348, 349, 353, 354, 355, 356, 362, 363, 364, 365, 366, 370, 371, 375, 376, 381, 382, 387, 398, 403, 404, 407, 409, 412, 416, 419, 420, 422, 425, 429, 430, 432, 433, 437, 438, 447, 448, 453, 454, 457, 459, 460, 461, 462, 463, 464, 467, 470, 474, 477};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 339 20
new 0 339 20
new 1 339 21
assign 1 343 25
new 0 343 25
fromString 1 344 26
assign 1 348 30
return 1 352 34
assign 1 356 38
toStringWithSeparator 1 356 38
return 1 356 39
assign 1 360 45
split 1 360 45
assign 1 361 46
new 0 361 46
assign 1 361 47
join 2 361 47
return 1 362 48
assign 1 366 52
split 1 366 52
return 1 366 53
assign 1 370 58
split 1 370 58
assign 1 370 59
firstGet 0 370 59
return 1 370 60
assign 1 374 65
split 1 374 65
assign 1 374 66
lastGet 0 374 66
return 1 374 67
assign 1 378 86
pathGet 0 378 86
assign 1 378 87
new 0 378 87
assign 1 378 88
emptyGet 0 378 88
assign 1 378 89
equals 1 378 89
assign 1 379 91
copy 0 379 91
return 1 379 92
assign 1 381 94
isAbsoluteGet 0 381 94
assign 1 382 96
copy 0 382 96
return 1 382 97
assign 1 384 99
split 1 384 99
assign 1 385 100
pathGet 0 385 100
assign 1 385 101
split 1 385 101
assign 1 386 102
linkedListIteratorGet 0 386 102
assign 1 386 105
hasNextGet 0 386 105
assign 1 387 107
nextGet 0 387 107
addValue 1 388 108
assign 1 390 114
new 0 390 114
assign 1 390 115
join 2 390 115
assign 1 391 116
copy 0 391 116
assign 1 392 117
fromString 1 392 117
return 1 394 118
assign 1 398 131
split 1 398 131
assign 1 399 132
copy 0 399 132
assign 1 400 133
new 0 400 133
pathSet 1 400 134
assign 1 401 135
lengthGet 0 401 135
assign 1 402 136
decrement 0 402 136
assign 1 403 137
new 0 403 137
assign 1 404 138
linkedListIteratorGet 0 404 138
assign 1 404 141
hasNextGet 0 404 141
assign 1 405 143
lesser 1 405 148
assign 1 406 149
nextGet 0 406 149
addStep 1 406 150
nextGet 0 408 153
assign 1 410 155
increment 0 410 155
assign 1 412 161
isAbsoluteGet 0 412 161
makeAbsolute 0 413 163
return 1 415 165
assign 1 419 180
undef 1 419 185
assign 1 0 186
assign 1 419 189
toString 0 419 189
assign 1 419 190
sizeGet 0 419 190
assign 1 419 191
new 0 419 191
assign 1 419 192
lesser 1 419 197
assign 1 0 198
assign 1 0 201
assign 1 419 205
new 0 419 205
return 1 419 206
assign 1 420 208
new 0 420 208
assign 1 420 209
getPoint 1 420 209
assign 1 420 210
equals 1 420 210
assign 1 421 212
new 0 421 212
return 1 421 213
assign 1 423 215
new 0 423 215
return 1 423 216
assign 1 427 222
isAbsoluteGet 0 427 222
assign 1 428 224
new 0 428 224
assign 1 428 225
sizeGet 0 428 225
assign 1 428 226
substring 2 428 226
assign 1 433 233
isAbsoluteGet 0 433 233
assign 1 433 234
not 0 433 239
assign 1 434 240
add 1 434 240
assign 1 439 253
new 0 439 253
assign 1 439 254
greater 1 439 259
makeNonAbsolute 0 440 260
assign 1 441 261
split 1 441 261
assign 1 443 262
firstNodeGet 0 443 262
assign 1 444 263
new 0 444 263
assign 1 444 266
lesser 1 444 271
assign 1 445 272
undef 1 445 277
assign 1 446 280
assign 1 447 281
nextGet 0 447 281
delete 0 448 282
assign 1 444 283
increment 0 444 283
assign 1 450 289
join 2 450 289
assign 1 455 295
split 1 455 295
addValue 1 456 296
assign 1 457 297
join 2 457 297
assign 1 461 307
find 1 461 307
assign 1 462 308
undef 1 462 313
assign 1 463 314
new 0 463 314
assign 1 463 315
emptyGet 0 463 315
assign 1 465 318
new 0 465 318
assign 1 465 319
add 1 465 319
assign 1 465 320
sizeGet 0 465 320
assign 1 465 321
substring 2 465 321
assign 1 470 330
split 1 470 330
assign 1 471 331
linkedListIteratorGet 0 471 331
assign 1 471 334
hasNextGet 0 471 334
assign 1 472 336
nextGet 0 472 336
addValue 1 472 337
assign 1 474 343
join 2 474 343
assign 1 478 348
addStep 1 478 348
return 1 478 349
assign 1 482 353
split 1 482 353
addValue 1 483 354
addValue 1 484 355
assign 1 485 356
join 2 485 356
assign 1 489 362
create 0 489 362
copyTo 1 490 363
assign 1 491 364
copy 0 491 364
pathSet 1 491 365
return 1 492 366
assign 1 496 370
split 1 496 370
return 1 496 371
assign 1 500 375
hashGet 0 500 375
return 1 500 376
assign 1 504 381
equals 1 504 381
assign 1 504 382
not 0 504 387
return 1 504 387
assign 1 511 398
undef 1 511 403
assign 1 0 404
assign 1 511 407
otherType 1 511 407
assign 1 0 409
assign 1 0 412
assign 1 0 416
assign 1 511 419
pathGet 0 511 419
assign 1 511 420
notEquals 1 511 420
assign 1 0 422
assign 1 0 425
assign 1 512 429
new 0 512 429
return 1 512 430
assign 1 514 432
new 0 514 432
return 1 514 433
assign 1 518 437
subPath 2 518 437
return 1 518 438
assign 1 522 447
stepsGet 0 522 447
assign 1 523 448
undef 1 523 453
assign 1 524 454
subList 1 524 454
assign 1 526 457
subList 2 526 457
assign 1 528 459
create 0 528 459
separatorSet 1 529 460
assign 1 530 461
new 0 530 461
assign 1 530 462
join 2 530 462
pathSet 1 530 463
return 1 531 464
return 1 0 467
assign 1 0 470
return 1 0 474
assign 1 0 477
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1081412016: return bem_many_0();
case 1359432006: return bem_isAbsoluteGet_0();
case -1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -471950299: return bem_lastStepGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case -935459934: return bem_deleteFirstStep_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -729571811: return bem_serializeToString_0();
case -1719674549: return bem_firstStepGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -723109216: return bem_stepsGet_0();
case -1354714650: return bem_copy_0();
case -400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case -1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -630006451: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -488966921: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -389107089: return bem_pathSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1787791811: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 14682424: return bem_addSteps_1(bevd_0);
case -2006569863: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -488966920: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
}
