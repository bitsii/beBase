package be;
/* IO:File: source/build/Pass9.be */
public final class BEC_3_5_5_5_BuildVisitPass9 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass9() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x39};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x39,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x66,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x74,0x6F,0x6F,0x20,0x67,0x72,0x65,0x61,0x74,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_0, 44));
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x53,0x45,0x54};
private static byte[] bels_3 = {0x47,0x45,0x54};
private static byte[] bels_4 = {0x53,0x45,0x54};
private static byte[] bels_5 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_6 = {0x70,0x75,0x74};
private static byte[] bels_7 = {0x67,0x65,0x74};
private static byte[] bels_8 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bels_9 = {0x69,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_11 = {0x68,0x61,0x73,0x4E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bels_12 = {0x6E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bels_13 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_14 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bels_15 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_16 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x66,0x6F,0x72,0x20,0x6C,0x6F,0x6F,0x70,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x74,0x77,0x6F,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64};
public static BEC_3_5_5_5_BuildVisitPass9 bevs_inst;
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_lbrnode = null;
BEC_2_6_6_SystemObject bevl_loopif = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_6_6_SystemObject bevl_cond = null;
BEC_2_6_6_SystemObject bevl_atStep = null;
BEC_2_6_6_SystemObject bevl_estr = null;
BEC_2_6_6_SystemObject bevl_ac = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevl_ntarg = null;
BEC_2_6_6_SystemObject bevl_isPut = null;
BEC_2_5_4_BuildNode bevl_narg2 = null;
BEC_2_5_4_BuildNode bevl_narg3 = null;
BEC_2_6_6_SystemObject bevl_lin = null;
BEC_2_6_6_SystemObject bevl_lvar = null;
BEC_2_6_6_SystemObject bevl_toit = null;
BEC_2_6_6_SystemObject bevl_tmpn = null;
BEC_2_6_6_SystemObject bevl_tmpv = null;
BEC_2_6_6_SystemObject bevl_gin = null;
BEC_2_6_6_SystemObject bevl_gic = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_asc = null;
BEC_2_6_6_SystemObject bevl_tmpnt = null;
BEC_2_6_6_SystemObject bevl_tcn = null;
BEC_2_6_6_SystemObject bevl_tcc = null;
BEC_2_6_6_SystemObject bevl_tmpng = null;
BEC_2_6_6_SystemObject bevl_iagn = null;
BEC_2_6_6_SystemObject bevl_iagc = null;
BEC_2_6_6_SystemObject bevl_iasn = null;
BEC_2_6_6_SystemObject bevl_iasc = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_22_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_44_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_49_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_50_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_58_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_67_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_72_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_73_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_74_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_75_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_78_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_83_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_113_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_114_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_119_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_121_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_125_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_135_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_141_tmpvar_phold = null;
bevt_6_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_7_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_6_tmpvar_phold.bevi_int == bevt_7_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 34 */ {
beva_node.bem_initContained_0();
bevt_8_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_it = bevt_8_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 39 */ {
bevt_9_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 39 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_11_tmpvar_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 42 */ {
bevt_15_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(1696089045, BEL_4_Base.bevn_firstNodeGet_0);
if (bevt_14_tmpvar_phold == null) {
bevt_13_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 43 */ {
bevt_17_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_i.bemd_1(-1671186230, BEL_4_Base.bevn_beforeInsert_1, bevt_16_tmpvar_phold);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 45 */
 else  /* Line: 46 */ {
bevt_18_tmpvar_phold = bevo_0;
bevt_21_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_estr = bevt_18_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_22_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevl_estr, beva_node);
throw new be.BECS_ThrowBack(bevt_22_tmpvar_phold);
} /* Line: 48 */
} /* Line: 43 */
} /* Line: 42 */
 else  /* Line: 39 */ {
break;
} /* Line: 39 */
} /* Line: 39 */
bevt_23_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_23_tmpvar_phold;
} /* Line: 52 */
 else  /* Line: 34 */ {
bevt_25_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
if (bevt_25_tmpvar_phold.bevi_int == bevt_26_tmpvar_phold.bevi_int) {
bevt_24_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_27_tmpvar_phold = be.BECS_Runtime.boolTrue;
bevl_c.bemd_1(-671626972, BEL_4_Base.bevn_wasAccessorSet_1, bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_typenameGet_0();
bevt_31_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_29_tmpvar_phold.bevi_int == bevt_31_tmpvar_phold.bevi_int) {
bevt_28_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_35_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bem_heldGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_36_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_1));
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_36_tmpvar_phold);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevt_37_tmpvar_phold = beva_node.bem_isFirstGet_0();
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevt_38_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_2));
bevl_c.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_38_tmpvar_phold);
} /* Line: 61 */
 else  /* Line: 62 */ {
bevt_39_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_3));
bevl_c.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_39_tmpvar_phold);
} /* Line: 63 */
bevt_40_tmpvar_phold = bevl_ac.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_40_tmpvar_phold);
bevl_c.bemd_0(-173192194, BEL_4_Base.bevn_toAccessorName_0);
bevt_42_tmpvar_phold = bevl_c.bemd_0(783669222, BEL_4_Base.bevn_accessorTypeGet_0);
bevt_43_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_4));
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_43_tmpvar_phold);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 67 */ {
bevt_44_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_44_tmpvar_phold.bem_heldSet_1(bevl_c);
bevt_45_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_45_tmpvar_phold.bem_firstGet_0();
bevt_46_tmpvar_phold = bevl_ntarg.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
beva_node.bem_typenameSet_1(bevt_46_tmpvar_phold);
bevt_47_tmpvar_phold = bevl_ntarg.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_47_tmpvar_phold);
bevt_48_tmpvar_phold = bevl_ntarg.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
beva_node.bem_containedSet_1(bevt_48_tmpvar_phold);
bevt_50_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_nextDescendGet_0();
return bevt_49_tmpvar_phold;
} /* Line: 74 */
 else  /* Line: 75 */ {
bevt_51_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_51_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 77 */
bevt_52_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_52_tmpvar_phold;
} /* Line: 79 */
 else  /* Line: 34 */ {
bevt_54_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpvar_phold = bevp_ntypes.bem_IDXACCGet_0();
if (bevt_54_tmpvar_phold.bevi_int == bevt_55_tmpvar_phold.bevi_int) {
bevt_53_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 80 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_58_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_typenameGet_0();
bevt_59_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_57_tmpvar_phold.bevi_int == bevt_59_tmpvar_phold.bevi_int) {
bevt_56_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 84 */ {
bevt_63_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_heldGet_0();
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_64_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_5));
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_64_tmpvar_phold);
if (bevt_60_tmpvar_phold != null && bevt_60_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_60_tmpvar_phold).bevi_bool) /* Line: 84 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
 else  /* Line: 84 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 84 */ {
bevt_65_tmpvar_phold = beva_node.bem_isFirstGet_0();
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 84 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
 else  /* Line: 84 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 84 */ {
bevl_isPut = be.BECS_Runtime.boolTrue;
} /* Line: 86 */
 else  /* Line: 87 */ {
bevl_isPut = be.BECS_Runtime.boolFalse;
} /* Line: 89 */
if (bevl_isPut != null && bevl_isPut instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_isPut).bevi_bool) /* Line: 91 */ {
bevt_66_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_6));
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_66_tmpvar_phold);
bevt_67_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_67_tmpvar_phold.bem_heldSet_1(bevl_c);
bevt_68_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_68_tmpvar_phold.bem_firstGet_0();
bevl_narg2 = (BEC_2_5_4_BuildNode) bevl_ntarg.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_narg3 = beva_node.bem_nextPeerGet_0();
bevl_narg2.bem_delete_0();
bevl_narg3.bem_delete_0();
bevt_69_tmpvar_phold = bevl_ntarg.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
beva_node.bem_typenameSet_1(bevt_69_tmpvar_phold);
bevt_70_tmpvar_phold = bevl_ntarg.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_70_tmpvar_phold);
bevt_71_tmpvar_phold = bevl_ntarg.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
beva_node.bem_containedSet_1(bevt_71_tmpvar_phold);
bevt_72_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_72_tmpvar_phold.bem_addValue_1(bevl_narg2);
bevt_73_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_73_tmpvar_phold.bem_addValue_1(bevl_narg3);
bevt_75_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bem_nextDescendGet_0();
return bevt_74_tmpvar_phold;
} /* Line: 109 */
 else  /* Line: 110 */ {
bevt_76_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_7));
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_77_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 117 */
bevt_78_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_78_tmpvar_phold;
} /* Line: 119 */
} /* Line: 34 */
} /* Line: 34 */
bevt_80_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_81_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
if (bevt_80_tmpvar_phold.bevi_int == bevt_81_tmpvar_phold.bevi_int) {
bevt_79_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_79_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_82_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
beva_node.bem_typenameSet_1(bevt_82_tmpvar_phold);
bevt_83_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_83_tmpvar_phold.bem_firstGet_0();
bevl_brnode = beva_node.bem_secondGet_0();
bevt_84_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_lin = bevt_84_tmpvar_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_85_tmpvar_phold = bevl_lin.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_lvar = bevt_85_tmpvar_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_toit = bevl_lin.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_pnode.bemd_1(443337441, BEL_4_Base.bevn_containedSet_1, null);
bevl_tmpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_86_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_8));
bevl_tmpv = beva_node.bem_tmpVar_2(bevt_87_tmpvar_phold, bevp_build);
bevl_tmpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_gin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_88_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_gin.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_88_tmpvar_phold);
bevl_gic = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_gin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gic);
bevt_89_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_9));
bevl_gic.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = be.BECS_Runtime.boolTrue;
bevl_gic.bemd_1(666017654, BEL_4_Base.bevn_wasForeachGennedSet_1, bevt_90_tmpvar_phold);
bevl_gin.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_toit);
bevl_asn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_91_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_91_tmpvar_phold);
bevl_asc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_asn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_asc);
bevt_92_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_10));
bevl_asc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_92_tmpvar_phold);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpn);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_gin);
beva_node.bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevl_asn);
bevl_tmpn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_tmpnt = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_93_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpnt.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_93_tmpvar_phold);
bevl_tmpnt.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_tcn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tcn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_94_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_tcn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_94_tmpvar_phold);
bevl_tcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_tcn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tcc);
bevt_95_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_11));
bevl_tcc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_95_tmpvar_phold);
bevl_tcn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpnt);
bevl_pnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tcn);
bevl_tmpng = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpng.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_96_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpng.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_96_tmpvar_phold);
bevl_tmpng.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_iagn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iagn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_97_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iagn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_97_tmpvar_phold);
bevl_iagc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iagn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_iagc);
bevt_98_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_12));
bevl_iagc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_98_tmpvar_phold);
bevl_iagn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpng);
bevl_iasn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iasn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_99_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iasn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_99_tmpvar_phold);
bevl_iasc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iasn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_iasc);
bevt_100_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_13));
bevl_iasc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_100_tmpvar_phold);
bevl_iasn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lvar);
bevl_iasn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_iagn);
bevl_brnode.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_iasn);
return (BEC_2_5_4_BuildNode) bevl_toit;
} /* Line: 211 */
bevt_102_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_103_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
if (bevt_102_tmpvar_phold.bevi_int == bevt_103_tmpvar_phold.bevi_int) {
bevt_101_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_101_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_101_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_104_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_104_tmpvar_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_105_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_105_tmpvar_phold);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lbrnode);
bevl_loopif = beva_node;
bevt_106_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_106_tmpvar_phold);
bevl_lbrnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_loopif);
bevt_108_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_108_tmpvar_phold == null) {
bevt_107_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevt_110_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_111_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_14));
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_111_tmpvar_phold);
if (bevt_109_tmpvar_phold != null && bevt_109_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_109_tmpvar_phold).bevi_bool) /* Line: 225 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 225 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 225 */
 else  /* Line: 225 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 225 */ {
bevt_112_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_15));
bevl_loopif.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_112_tmpvar_phold);
} /* Line: 226 */
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_113_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_113_tmpvar_phold);
bevl_loopif.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_114_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_114_tmpvar_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_115_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_115_tmpvar_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_116_tmpvar_phold = bevl_lnode.bemd_0(-1779180144, BEL_4_Base.bevn_nextDescendGet_0);
return (BEC_2_5_4_BuildNode) bevt_116_tmpvar_phold;
} /* Line: 240 */
 else  /* Line: 213 */ {
bevt_118_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_119_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
if (bevt_118_tmpvar_phold.bevi_int == bevt_119_tmpvar_phold.bevi_int) {
bevt_117_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_117_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 241 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_120_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_120_tmpvar_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevt_121_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_121_tmpvar_phold.bem_firstGet_0();
bevl_pnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_124_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_125_tmpvar_phold = (new BEC_2_4_3_MathInt(2));
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_125_tmpvar_phold);
if (bevt_122_tmpvar_phold != null && bevt_122_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_122_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevt_127_tmpvar_phold = (new BEC_2_4_6_TextString(55, bels_16));
bevt_126_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_127_tmpvar_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_126_tmpvar_phold);
} /* Line: 249 */
bevt_128_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_init = bevt_128_tmpvar_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_cond = bevl_pnode.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_atStep = null;
bevt_131_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_130_tmpvar_phold = bevt_131_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_132_tmpvar_phold = (new BEC_2_4_3_MathInt(2));
bevt_129_tmpvar_phold = bevt_130_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_132_tmpvar_phold);
if (bevt_129_tmpvar_phold != null && bevt_129_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_129_tmpvar_phold).bevi_bool) /* Line: 254 */ {
bevl_atStep = bevl_pnode.bemd_0(-978128800, BEL_4_Base.bevn_thirdGet_0);
bevl_atStep.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 256 */
bevl_init.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode);
bevl_lnode.bemd_1(-1671186230, BEL_4_Base.bevn_beforeInsert_1, bevl_init);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_133_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_133_tmpvar_phold);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lbrnode);
bevl_loopif = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_loopif.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_134_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_134_tmpvar_phold);
bevl_loopif.bemd_1(875977779, BEL_4_Base.bevn_takeContents_1, beva_node);
if (bevl_atStep == null) {
bevt_135_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_135_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_135_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_137_tmpvar_phold = bevl_loopif.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_136_tmpvar_phold = bevt_137_tmpvar_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_136_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_atStep);
} /* Line: 272 */
bevl_loopif.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_pnode);
bevl_lbrnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_loopif);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_138_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_138_tmpvar_phold);
bevl_loopif.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_139_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_139_tmpvar_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_140_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_140_tmpvar_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
return (BEC_2_5_4_BuildNode) bevl_init;
} /* Line: 289 */
} /* Line: 213 */
bevt_141_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_141_tmpvar_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {34, 34, 34, 34, 38, 39, 39, 39, 41, 42, 42, 42, 43, 43, 43, 43, 44, 44, 44, 45, 47, 47, 47, 47, 47, 48, 48, 52, 52, 53, 53, 53, 53, 57, 58, 59, 59, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 0, 0, 0, 60, 0, 0, 0, 61, 61, 63, 63, 65, 65, 66, 67, 67, 67, 68, 68, 69, 69, 71, 71, 72, 72, 73, 73, 74, 74, 74, 76, 76, 77, 79, 79, 80, 80, 80, 80, 82, 83, 84, 84, 84, 84, 84, 84, 84, 84, 84, 84, 0, 0, 0, 84, 0, 0, 0, 86, 89, 92, 92, 93, 93, 94, 94, 97, 98, 100, 101, 103, 103, 104, 104, 105, 105, 107, 107, 108, 108, 109, 109, 109, 115, 115, 116, 116, 117, 119, 119, 121, 121, 121, 121, 122, 122, 123, 123, 124, 125, 125, 126, 126, 127, 128, 147, 148, 149, 149, 150, 150, 151, 153, 154, 154, 155, 156, 157, 157, 158, 158, 159, 161, 162, 163, 163, 164, 165, 166, 166, 167, 168, 170, 171, 173, 174, 175, 175, 176, 178, 179, 180, 180, 181, 182, 183, 183, 184, 186, 188, 189, 190, 190, 191, 193, 194, 195, 195, 196, 197, 198, 198, 199, 201, 202, 203, 203, 204, 205, 206, 206, 207, 208, 210, 211, 213, 213, 213, 213, 214, 215, 216, 216, 217, 218, 219, 220, 220, 221, 222, 223, 223, 224, 225, 225, 225, 225, 225, 225, 0, 0, 0, 226, 226, 228, 229, 230, 230, 231, 232, 233, 234, 234, 235, 236, 237, 238, 238, 239, 240, 240, 241, 241, 241, 241, 242, 243, 244, 244, 245, 246, 246, 247, 248, 248, 248, 248, 249, 249, 249, 251, 251, 252, 253, 254, 254, 254, 254, 255, 256, 258, 260, 261, 263, 264, 265, 265, 266, 267, 268, 269, 269, 270, 271, 271, 272, 272, 272, 274, 275, 276, 277, 278, 278, 279, 280, 281, 282, 282, 283, 284, 285, 286, 286, 287, 289, 291, 291};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {206, 207, 208, 213, 214, 215, 216, 219, 221, 222, 223, 224, 226, 227, 228, 233, 234, 235, 236, 237, 240, 241, 242, 243, 244, 245, 246, 254, 255, 258, 259, 260, 265, 266, 267, 268, 269, 270, 271, 272, 273, 278, 279, 280, 281, 282, 283, 285, 288, 292, 295, 297, 300, 304, 307, 308, 311, 312, 314, 315, 316, 317, 318, 319, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 336, 337, 338, 340, 341, 344, 345, 346, 351, 352, 353, 354, 355, 356, 357, 362, 363, 364, 365, 366, 367, 369, 372, 376, 379, 381, 384, 388, 391, 394, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 422, 423, 424, 425, 426, 428, 429, 433, 434, 435, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 523, 524, 525, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 551, 552, 553, 554, 556, 559, 563, 566, 567, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 588, 589, 590, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 609, 610, 611, 613, 614, 615, 616, 617, 618, 619, 620, 622, 623, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 643, 644, 645, 646, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 668, 669};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 34 206
typenameGet 0 34 206
assign 1 34 207
CALLGet 0 34 207
assign 1 34 208
equals 1 34 213
initContained 0 38 214
assign 1 39 215
containedGet 0 39 215
assign 1 39 216
iteratorGet 0 39 216
assign 1 39 219
hasNextGet 0 39 219
assign 1 41 221
nextGet 0 41 221
assign 1 42 222
typenameGet 0 42 222
assign 1 42 223
PARENSGet 0 42 223
assign 1 42 224
equals 1 42 224
assign 1 43 226
containedGet 0 43 226
assign 1 43 227
firstNodeGet 0 43 227
assign 1 43 228
def 1 43 233
assign 1 44 234
containedGet 0 44 234
assign 1 44 235
firstGet 0 44 235
beforeInsert 1 44 236
delete 0 45 237
assign 1 47 240
new 0 47 240
assign 1 47 241
containedGet 0 47 241
assign 1 47 242
lengthGet 0 47 242
assign 1 47 243
toString 0 47 243
assign 1 47 244
add 1 47 244
assign 1 48 245
new 2 48 245
throw 1 48 246
assign 1 52 254
nextDescendGet 0 52 254
return 1 52 255
assign 1 53 258
typenameGet 0 53 258
assign 1 53 259
ACCESSORGet 0 53 259
assign 1 53 260
equals 1 53 265
assign 1 57 266
heldGet 0 57 266
assign 1 58 267
new 0 58 267
assign 1 59 268
new 0 59 268
wasAccessorSet 1 59 269
assign 1 60 270
containerGet 0 60 270
assign 1 60 271
typenameGet 0 60 271
assign 1 60 272
CALLGet 0 60 272
assign 1 60 273
equals 1 60 278
assign 1 60 279
containerGet 0 60 279
assign 1 60 280
heldGet 0 60 280
assign 1 60 281
nameGet 0 60 281
assign 1 60 282
new 0 60 282
assign 1 60 283
equals 1 60 283
assign 1 0 285
assign 1 0 288
assign 1 0 292
assign 1 60 295
isFirstGet 0 60 295
assign 1 0 297
assign 1 0 300
assign 1 0 304
assign 1 61 307
new 0 61 307
accessorTypeSet 1 61 308
assign 1 63 311
new 0 63 311
accessorTypeSet 1 63 312
assign 1 65 314
nameGet 0 65 314
nameSet 1 65 315
toAccessorName 0 66 316
assign 1 67 317
accessorTypeGet 0 67 317
assign 1 67 318
new 0 67 318
assign 1 67 319
equals 1 67 319
assign 1 68 321
containerGet 0 68 321
heldSet 1 68 322
assign 1 69 323
containedGet 0 69 323
assign 1 69 324
firstGet 0 69 324
assign 1 71 325
typenameGet 0 71 325
typenameSet 1 71 326
assign 1 72 327
heldGet 0 72 327
heldSet 1 72 328
assign 1 73 329
containedGet 0 73 329
containedSet 1 73 330
assign 1 74 331
containerGet 0 74 331
assign 1 74 332
nextDescendGet 0 74 332
return 1 74 333
assign 1 76 336
CALLGet 0 76 336
typenameSet 1 76 337
heldSet 1 77 338
assign 1 79 340
nextDescendGet 0 79 340
return 1 79 341
assign 1 80 344
typenameGet 0 80 344
assign 1 80 345
IDXACCGet 0 80 345
assign 1 80 346
equals 1 80 351
assign 1 82 352
heldGet 0 82 352
assign 1 83 353
new 0 83 353
assign 1 84 354
containerGet 0 84 354
assign 1 84 355
typenameGet 0 84 355
assign 1 84 356
CALLGet 0 84 356
assign 1 84 357
equals 1 84 362
assign 1 84 363
containerGet 0 84 363
assign 1 84 364
heldGet 0 84 364
assign 1 84 365
nameGet 0 84 365
assign 1 84 366
new 0 84 366
assign 1 84 367
equals 1 84 367
assign 1 0 369
assign 1 0 372
assign 1 0 376
assign 1 84 379
isFirstGet 0 84 379
assign 1 0 381
assign 1 0 384
assign 1 0 388
assign 1 86 391
new 0 86 391
assign 1 89 394
new 0 89 394
assign 1 92 397
new 0 92 397
nameSet 1 92 398
assign 1 93 399
containerGet 0 93 399
heldSet 1 93 400
assign 1 94 401
containedGet 0 94 401
assign 1 94 402
firstGet 0 94 402
assign 1 97 403
nextPeerGet 0 97 403
assign 1 98 404
nextPeerGet 0 98 404
delete 0 100 405
delete 0 101 406
assign 1 103 407
typenameGet 0 103 407
typenameSet 1 103 408
assign 1 104 409
heldGet 0 104 409
heldSet 1 104 410
assign 1 105 411
containedGet 0 105 411
containedSet 1 105 412
assign 1 107 413
containerGet 0 107 413
addValue 1 107 414
assign 1 108 415
containerGet 0 108 415
addValue 1 108 416
assign 1 109 417
containerGet 0 109 417
assign 1 109 418
nextDescendGet 0 109 418
return 1 109 419
assign 1 115 422
new 0 115 422
nameSet 1 115 423
assign 1 116 424
CALLGet 0 116 424
typenameSet 1 116 425
heldSet 1 117 426
assign 1 119 428
nextDescendGet 0 119 428
return 1 119 429
assign 1 121 433
typenameGet 0 121 433
assign 1 121 434
FOREACHGet 0 121 434
assign 1 121 435
equals 1 121 440
assign 1 122 441
WHILEGet 0 122 441
typenameSet 1 122 442
assign 1 123 443
containedGet 0 123 443
assign 1 123 444
firstGet 0 123 444
assign 1 124 445
secondGet 0 124 445
assign 1 125 446
containedGet 0 125 446
assign 1 125 447
firstGet 0 125 447
assign 1 126 448
containedGet 0 126 448
assign 1 126 449
firstGet 0 126 449
assign 1 127 450
secondGet 0 127 450
containedSet 1 128 451
assign 1 147 452
new 1 147 452
copyLoc 1 148 453
assign 1 149 454
VARGet 0 149 454
typenameSet 1 149 455
assign 1 150 456
new 0 150 456
assign 1 150 457
tmpVar 2 150 457
heldSet 1 151 458
assign 1 153 459
new 1 153 459
assign 1 154 460
CALLGet 0 154 460
typenameSet 1 154 461
assign 1 155 462
new 0 155 462
heldSet 1 156 463
assign 1 157 464
new 0 157 464
nameSet 1 157 465
assign 1 158 466
new 0 158 466
wasForeachGennedSet 1 158 467
addValue 1 159 468
assign 1 161 469
new 1 161 469
copyLoc 1 162 470
assign 1 163 471
CALLGet 0 163 471
typenameSet 1 163 472
assign 1 164 473
new 0 164 473
heldSet 1 165 474
assign 1 166 475
new 0 166 475
nameSet 1 166 476
addValue 1 167 477
addValue 1 168 478
beforeInsert 1 170 479
addVariable 0 171 480
assign 1 173 481
new 1 173 481
copyLoc 1 174 482
assign 1 175 483
VARGet 0 175 483
typenameSet 1 175 484
heldSet 1 176 485
assign 1 178 486
new 1 178 486
copyLoc 1 179 487
assign 1 180 488
CALLGet 0 180 488
typenameSet 1 180 489
assign 1 181 490
new 0 181 490
heldSet 1 182 491
assign 1 183 492
new 0 183 492
nameSet 1 183 493
addValue 1 184 494
addValue 1 186 495
assign 1 188 496
new 1 188 496
copyLoc 1 189 497
assign 1 190 498
VARGet 0 190 498
typenameSet 1 190 499
heldSet 1 191 500
assign 1 193 501
new 1 193 501
copyLoc 1 194 502
assign 1 195 503
CALLGet 0 195 503
typenameSet 1 195 504
assign 1 196 505
new 0 196 505
heldSet 1 197 506
assign 1 198 507
new 0 198 507
nameSet 1 198 508
addValue 1 199 509
assign 1 201 510
new 1 201 510
copyLoc 1 202 511
assign 1 203 512
CALLGet 0 203 512
typenameSet 1 203 513
assign 1 204 514
new 0 204 514
heldSet 1 205 515
assign 1 206 516
new 0 206 516
nameSet 1 206 517
addValue 1 207 518
addValue 1 208 519
prepend 1 210 520
return 1 211 521
assign 1 213 523
typenameGet 0 213 523
assign 1 213 524
WHILEGet 0 213 524
assign 1 213 525
equals 1 213 530
assign 1 214 531
new 1 214 531
copyLoc 1 215 532
assign 1 216 533
LOOPGet 0 216 533
typenameSet 1 216 534
replaceWith 1 217 535
assign 1 218 536
new 1 218 536
copyLoc 1 219 537
assign 1 220 538
BRACESGet 0 220 538
typenameSet 1 220 539
addValue 1 221 540
assign 1 222 541
assign 1 223 542
IFGet 0 223 542
typenameSet 1 223 543
addValue 1 224 544
assign 1 225 545
heldGet 0 225 545
assign 1 225 546
def 1 225 551
assign 1 225 552
heldGet 0 225 552
assign 1 225 553
new 0 225 553
assign 1 225 554
equals 1 225 554
assign 1 0 556
assign 1 0 559
assign 1 0 563
assign 1 226 566
new 0 226 566
heldSet 1 226 567
assign 1 228 569
new 1 228 569
copyLoc 1 229 570
assign 1 230 571
ELSEGet 0 230 571
typenameSet 1 230 572
addValue 1 231 573
assign 1 232 574
new 1 232 574
copyLoc 1 233 575
assign 1 234 576
BRACESGet 0 234 576
typenameSet 1 234 577
addValue 1 235 578
assign 1 236 579
new 1 236 579
copyLoc 1 237 580
assign 1 238 581
BREAKGet 0 238 581
typenameSet 1 238 582
addValue 1 239 583
assign 1 240 584
nextDescendGet 0 240 584
return 1 240 585
assign 1 241 588
typenameGet 0 241 588
assign 1 241 589
FORGet 0 241 589
assign 1 241 590
equals 1 241 595
assign 1 242 596
new 1 242 596
copyLoc 1 243 597
assign 1 244 598
LOOPGet 0 244 598
typenameSet 1 244 599
replaceWith 1 245 600
assign 1 246 601
containedGet 0 246 601
assign 1 246 602
firstGet 0 246 602
delete 0 247 603
assign 1 248 604
containedGet 0 248 604
assign 1 248 605
lengthGet 0 248 605
assign 1 248 606
new 0 248 606
assign 1 248 607
lesser 1 248 607
assign 1 249 609
new 0 249 609
assign 1 249 610
new 2 249 610
throw 1 249 611
assign 1 251 613
containedGet 0 251 613
assign 1 251 614
firstGet 0 251 614
assign 1 252 615
secondGet 0 252 615
assign 1 253 616
assign 1 254 617
containedGet 0 254 617
assign 1 254 618
lengthGet 0 254 618
assign 1 254 619
new 0 254 619
assign 1 254 620
greater 1 254 620
assign 1 255 622
thirdGet 0 255 622
delete 0 256 623
delete 0 258 625
replaceWith 1 260 626
beforeInsert 1 261 627
assign 1 263 628
new 1 263 628
copyLoc 1 264 629
assign 1 265 630
BRACESGet 0 265 630
typenameSet 1 265 631
addValue 1 266 632
assign 1 267 633
new 1 267 633
copyLoc 1 268 634
assign 1 269 635
IFGet 0 269 635
typenameSet 1 269 636
takeContents 1 270 637
assign 1 271 638
def 1 271 643
assign 1 272 644
containedGet 0 272 644
assign 1 272 645
firstGet 0 272 645
addValue 1 272 646
prepend 1 274 648
addValue 1 275 649
assign 1 276 650
new 1 276 650
copyLoc 1 277 651
assign 1 278 652
ELSEGet 0 278 652
typenameSet 1 278 653
addValue 1 279 654
assign 1 280 655
new 1 280 655
copyLoc 1 281 656
assign 1 282 657
BRACESGet 0 282 657
typenameSet 1 282 658
addValue 1 283 659
assign 1 284 660
new 1 284 660
copyLoc 1 285 661
assign 1 286 662
BREAKGet 0 286 662
typenameSet 1 286 663
addValue 1 287 664
return 1 289 665
assign 1 291 668
nextDescendGet 0 291 668
return 1 291 669
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass9();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass9.bevs_inst = (BEC_3_5_5_5_BuildVisitPass9)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass9.bevs_inst;
}
}
