package be;
/* IO:File: source/extended/FilePath.be */
public class BEC_3_2_4_4_IOFilePath extends BEC_2_6_8_SystemBasePath {
public BEC_3_2_4_4_IOFilePath() { }
private static byte[] becc_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x50,0x61,0x74,0x68};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x50,0x61,0x74,0x68,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_0 = {0x3A};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_0, 1));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(2));
public static BEC_3_2_4_4_IOFilePath bevs_inst;
public BEC_2_2_4_IOFile bevp_file;
public BEC_2_4_6_TextString bevp_driveLetter;
public BEC_3_2_4_4_IOFilePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevp_separator = bevt_0_tmpany_phold.bem_separatorGet_0();
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_apNew_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_6_8_SystemPlatform bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = beva_spath.bem_sizeGet_0();
bevt_3_tmpany_phold = bevo_0;
if (bevt_2_tmpany_phold.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 25 */ {
bevt_6_tmpany_phold = bevo_1;
bevt_5_tmpany_phold = beva_spath.bem_getPoint_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevo_2;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 25 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 25 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 25 */
 else  /* Line: 25 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 25 */ {
bevt_8_tmpany_phold = bevo_3;
bevt_9_tmpany_phold = bevo_4;
bevp_driveLetter = beva_spath.bem_substring_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevo_5;
bevt_11_tmpany_phold = beva_spath.bem_sizeGet_0();
beva_spath = beva_spath.bem_substring_2(bevt_10_tmpany_phold, bevt_11_tmpany_phold);
} /* Line: 27 */
bevt_12_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevl_p = bevt_12_tmpany_phold.bem_platformGet_0();
bevt_13_tmpany_phold = bevl_p.bem_otherSeparatorGet_0();
bevt_14_tmpany_phold = bevl_p.bem_separatorGet_0();
beva_spath = (BEC_2_4_6_TextString) beva_spath.bem_swap_2(bevt_13_tmpany_phold, bevt_14_tmpany_phold);
bevt_15_tmpany_phold = this.bem_new_1(beva_spath);
return (BEC_3_2_4_4_IOFilePath) bevt_15_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = super.bem_isAbsoluteGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
this.bem_apNew_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_fileGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_file == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevp_file = (new BEC_2_2_4_IOFile()).bem_new_0();
bevp_file.bem_pathSet_1(this);
} /* Line: 58 */
return bevp_file;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_copy_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_3_2_4_4_IOFilePath) this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_other.bem_fileSet_1(null);
return (BEC_3_2_4_4_IOFilePath) bevl_other;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_driveLetter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_1_tmpany_phold = bevp_driveLetter.bem_add_1(bevp_path);
return bevt_1_tmpany_phold;
} /* Line: 73 */
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_parentGet_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = super.bem_parentGet_0();
return (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevp_driveLetter = null;
super.bem_makeNonAbsolute_0();
} /* Line: 85 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_matchesGlob_1(BEC_2_4_6_TextString beva_glob) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_4_TextGlob bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_4_TextGlob()).bem_new_1(beva_glob);
bevt_2_tmpany_phold = this.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_match_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_6_6_SystemObject bevl_res = null;
bevl_res = super.bem_subPath_2(beva_start, beva_end);
bevl_res.bemd_1(975920932, BEL_4_Base.bevn_driveLetterSet_1, bevp_driveLetter);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_lastStepGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_file = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_driveLetterGet_0() throws Throwable {
return bevp_driveLetter;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_driveLetterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_driveLetter = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {19, 19, 20, 25, 25, 25, 25, 25, 25, 25, 25, 0, 0, 0, 26, 26, 26, 27, 27, 27, 29, 29, 30, 30, 30, 31, 31, 38, 38, 42, 42, 46, 50, 50, 56, 56, 57, 58, 60, 64, 65, 66, 66, 67, 68, 72, 72, 73, 73, 75, 79, 79, 83, 84, 85, 90, 90, 90, 90, 94, 95, 96, 100, 100, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 21, 42, 43, 44, 49, 50, 51, 52, 53, 55, 58, 62, 65, 66, 67, 68, 69, 70, 72, 73, 74, 75, 76, 77, 78, 82, 83, 87, 88, 91, 96, 97, 101, 106, 107, 108, 110, 115, 116, 117, 118, 119, 120, 125, 130, 131, 132, 134, 138, 139, 143, 145, 146, 154, 155, 156, 157, 161, 162, 163, 167, 168, 171, 175, 178};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 19 19
new 0 19 19
assign 1 19 20
separatorGet 0 19 20
fromString 1 20 21
assign 1 25 42
sizeGet 0 25 42
assign 1 25 43
new 0 25 43
assign 1 25 44
greater 1 25 49
assign 1 25 50
new 0 25 50
assign 1 25 51
getPoint 1 25 51
assign 1 25 52
new 0 25 52
assign 1 25 53
equals 1 25 53
assign 1 0 55
assign 1 0 58
assign 1 0 62
assign 1 26 65
new 0 26 65
assign 1 26 66
new 0 26 66
assign 1 26 67
substring 2 26 67
assign 1 27 68
new 0 27 68
assign 1 27 69
sizeGet 0 27 69
assign 1 27 70
substring 2 27 70
assign 1 29 72
new 0 29 72
assign 1 29 73
platformGet 0 29 73
assign 1 30 74
otherSeparatorGet 0 30 74
assign 1 30 75
separatorGet 0 30 75
assign 1 30 76
swap 2 30 76
assign 1 31 77
new 1 31 77
return 1 31 78
assign 1 38 82
isAbsoluteGet 0 38 82
return 1 38 83
assign 1 42 87
toString 0 42 87
return 1 42 88
apNew 1 46 91
assign 1 50 96
new 0 50 96
return 1 50 97
assign 1 56 101
undef 1 56 106
assign 1 57 107
new 0 57 107
pathSet 1 58 108
return 1 60 110
assign 1 64 115
create 0 64 115
copyTo 1 65 116
assign 1 66 117
copy 0 66 117
pathSet 1 66 118
fileSet 1 67 119
return 1 68 120
assign 1 72 125
def 1 72 130
assign 1 73 131
add 1 73 131
return 1 73 132
return 1 75 134
assign 1 79 138
parentGet 0 79 138
return 1 79 139
assign 1 83 143
isAbsoluteGet 0 83 143
assign 1 84 145
makeNonAbsolute 0 85 146
assign 1 90 154
new 1 90 154
assign 1 90 155
toString 0 90 155
assign 1 90 156
match 1 90 156
return 1 90 157
assign 1 94 161
subPath 2 94 161
driveLetterSet 1 95 162
return 1 96 163
assign 1 100 167
lastStepGet 0 100 167
return 1 100 168
assign 1 0 171
return 1 0 175
assign 1 0 178
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1081412016: return bem_many_0();
case -1338882709: return bem_fileGet_0();
case 964838679: return bem_driveLetterGet_0();
case 1359432006: return bem_isAbsoluteGet_0();
case -1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case 1211273660: return bem_nameGet_0();
case -471950299: return bem_lastStepGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case -935459934: return bem_deleteFirstStep_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -729571811: return bem_serializeToString_0();
case -1719674549: return bem_firstStepGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -723109216: return bem_stepsGet_0();
case -1354714650: return bem_copy_0();
case -400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case -1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 14682424: return bem_addSteps_1(bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -824830365: return bem_apNew_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -630006451: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1787791811: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 975920932: return bem_driveLetterSet_1(bevd_0);
case -494959043: return bem_matchesGlob_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -488966921: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case -2006569863: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1327800456: return bem_fileSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -389107089: return bem_pathSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 92659731: return bem_add_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -488966920: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_2_4_4_IOFilePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_2_4_4_IOFilePath.bevs_inst = (BEC_3_2_4_4_IOFilePath)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_2_4_4_IOFilePath.bevs_inst;
}
}
