package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_21_ContainerSetSerializationIterator extends BEC_3_9_3_11_ContainerSetKeyIterator {
public BEC_3_9_3_21_ContainerSetSerializationIterator() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_21_ContainerSetSerializationIterator bevs_inst;
public BEC_2_9_4_ContainerList bevp_contents;
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) throws Throwable {
bevp_contents = (new BEC_2_9_4_ContainerList()).bem_new_0();
super.bem_new_1(beva__set);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
bevp_contents.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 552 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 552 */ {
this.bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 552 */
 else  /* Line: 552 */ {
break;
} /* Line: 552 */
} /* Line: 552 */
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_postDeserialize_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_loop = bevp_contents.bem_iteratorGet_0();
while (true)
 /* Line: 558 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 558 */ {
bevl_value = bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevp_set.bem_put_1(bevl_value);
} /* Line: 559 */
 else  /* Line: 558 */ {
break;
} /* Line: 558 */
} /* Line: 558 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_contentsGet_0() throws Throwable {
return bevp_contents;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {542, 544, 548, 552, 552, 552, 553, 552, 558, 0, 558, 558, 559, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {10, 11, 15, 21, 24, 29, 30, 31, 43, 43, 46, 48, 49, 58, 61};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 542 10
new 0 542 10
new 1 544 11
addValue 1 548 15
assign 1 552 21
new 0 552 21
assign 1 552 24
lesser 1 552 29
nextSet 1 553 30
assign 1 552 31
increment 0 552 31
assign 1 558 43
iteratorGet 0 0 43
assign 1 558 46
hasNextGet 0 558 46
assign 1 558 48
nextGet 0 558 48
put 1 559 49
return 1 0 58
assign 1 0 61
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 1392959045: return bem_setGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1586230380: return bem_moduGet_0();
case 104713553: return bem_new_0();
case -1471882487: return bem_nodeIteratorIteratorGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case -1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case 1194623572: return bem_nextGet_0();
case 819712668: return bem_delete_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1820417453: return bem_create_0();
case 547861133: return bem_contentsGet_0();
case -510157136: return bem_postDeserialize_0();
case -786424307: return bem_tagGet_0();
case 108485850: return bem_hasNextGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1404041298: return bem_setSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
case 558943386: return bem_contentsSet_1(bevd_0);
case -900559503: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1575148127: return bem_moduSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_21_ContainerSetSerializationIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator.bevs_inst = (BEC_3_9_3_21_ContainerSetSerializationIterator)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_21_ContainerSetSerializationIterator.bevs_inst;
}
}
