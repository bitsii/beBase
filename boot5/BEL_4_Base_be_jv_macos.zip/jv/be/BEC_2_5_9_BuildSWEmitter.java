package be;
/* IO:File: source/build/SWEmitter.be */
public final class BEC_2_5_9_BuildSWEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildSWEmitter() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x53,0x57,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x57,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x73,0x77};
private static byte[] bels_1 = {0x2E,0x73,0x77,0x69,0x66,0x74};
private static byte[] bels_2 = {};
private static byte[] bels_3 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bels_4 = {0x76,0x61,0x72,0x20};
private static byte[] bels_5 = {0x3A,0x5B,0x55,0x49,0x6E,0x74,0x38,0x5D,0x20,0x3D,0x20,0x5B};
private static byte[] bels_6 = {0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_6, 7));
private static byte[] bels_7 = {0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_7, 7));
private static byte[] bels_8 = {0x5D,0x3B};
private static byte[] bels_9 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_9, 5));
private static byte[] bels_10 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bels_11 = {0x29,0x20,0x7B};
private static byte[] bels_12 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_12, 31));
private static byte[] bels_13 = {0x29,0x29};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bels_15 = {0x66,0x75,0x6E,0x63,0x20};
private static byte[] bels_16 = {0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x75,0x6E,0x63,0x20};
private static byte[] bels_17 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_18 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_18, 6));
private static byte[] bels_19 = {0x20};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_19, 1));
private static byte[] bels_20 = {0x30,0x78};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_20, 2));
private static byte[] bels_21 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_21, 6));
private static byte[] bels_22 = {0x20};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_22, 1));
private static byte[] bels_23 = {0x6D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_23, 19));
private static byte[] bels_24 = {0x20,0x7B};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_24, 2));
private static byte[] bels_25 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bels_26 = {0x29,0x29,0x20,0x7B};
private static byte[] bels_27 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bels_28 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bels_29 = {0x22,0x3B};
private static byte[] bels_30 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_30, 3));
public static BEC_2_5_9_BuildSWEmitter bevs_inst;
public BEC_2_5_9_BuildSWEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(6, bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_3));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_4));
bevt_1_tmpany_phold = beva_sdec.bem_addValue_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(12, bels_5));
bevt_0_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_buildClassInfo_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevo_0;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_5_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
this.bem_buildClassInfo_2(bevt_0_tmpany_phold, (BEC_2_4_6_TextString) bevt_3_tmpany_phold);
bevt_7_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_8_tmpany_phold = bevo_1;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
this.bem_buildClassInfo_2(bevt_6_tmpany_phold, bevp_inFilePathed);
return this;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_8));
bevt_0_tmpany_phold = beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bevo_2;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(25, bels_10));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_11));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpany_phold = bevo_3;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold, bevt_12_tmpany_phold, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_14));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_15));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(14, bels_16));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_17));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_5;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bevo_6;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildSWEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bevo_7;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bevo_8;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_10;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(13, bels_25));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_26));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(25, bels_27));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(29, bels_28));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_29));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_12;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 31, 31, 31, 31, 31, 35, 35, 35, 35, 35, 35, 35, 36, 36, 36, 36, 41, 41, 41, 45, 45, 45, 46, 47, 47, 47, 47, 47, 47, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 54, 54, 58, 58, 62, 62, 66, 66, 70, 70, 70, 70, 70, 75, 76, 77, 77, 77, 78, 84, 84, 84, 84, 84, 84, 88, 88, 88, 88, 88, 89, 89, 89, 89, 89, 89, 90, 90, 90, 91, 91, 91, 91, 91, 91, 91, 91, 92, 96, 96, 96, 96};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {53, 54, 55, 56, 61, 62, 69, 70, 71, 72, 73, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 102, 103, 104, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 149, 150, 154, 155, 159, 160, 164, 165, 172, 173, 174, 175, 176, 182, 183, 184, 185, 186, 187, 196, 197, 198, 199, 200, 201, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 251, 252, 253, 254};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 53
new 0 17 53
assign 1 18 54
new 0 18 54
assign 1 19 55
new 0 19 55
new 1 23 56
assign 1 27 61
new 0 27 61
return 1 27 62
assign 1 31 69
new 0 31 69
assign 1 31 70
addValue 1 31 70
assign 1 31 71
addValue 1 31 71
assign 1 31 72
new 0 31 72
addValue 1 31 73
assign 1 35 86
emitNameGet 0 35 86
assign 1 35 87
new 0 35 87
assign 1 35 88
add 1 35 88
assign 1 35 89
heldGet 0 35 89
assign 1 35 90
namepathGet 0 35 90
assign 1 35 91
toString 0 35 91
buildClassInfo 2 35 92
assign 1 36 93
emitNameGet 0 36 93
assign 1 36 94
new 0 36 94
assign 1 36 95
add 1 36 95
buildClassInfo 2 36 96
assign 1 41 102
new 0 41 102
assign 1 41 103
addValue 1 41 103
addValue 1 41 104
assign 1 45 125
new 0 45 125
assign 1 45 126
toString 0 45 126
assign 1 45 127
add 1 45 127
incrementValue 0 46 128
assign 1 47 129
new 0 47 129
assign 1 47 130
addValue 1 47 130
assign 1 47 131
addValue 1 47 131
assign 1 47 132
new 0 47 132
assign 1 47 133
addValue 1 47 133
addValue 1 47 134
assign 1 49 135
containedGet 0 49 135
assign 1 49 136
firstGet 0 49 136
assign 1 49 137
containedGet 0 49 137
assign 1 49 138
firstGet 0 49 138
assign 1 49 139
new 0 49 139
assign 1 49 140
add 1 49 140
assign 1 49 141
new 0 49 141
assign 1 49 142
add 1 49 142
assign 1 49 143
finalAssign 3 49 143
addValue 1 49 144
assign 1 54 149
new 0 54 149
return 1 54 150
assign 1 58 154
new 0 58 154
return 1 58 155
assign 1 62 159
new 0 62 159
return 1 62 160
assign 1 66 164
new 0 66 164
return 1 66 165
assign 1 70 172
new 0 70 172
assign 1 70 173
add 1 70 173
assign 1 70 174
new 0 70 174
assign 1 70 175
add 1 70 175
return 1 70 176
getCode 2 75 182
assign 1 76 183
toHexString 1 76 183
assign 1 77 184
new 0 77 184
assign 1 77 185
once 0 77 185
addValue 1 77 186
addValue 1 78 187
assign 1 84 196
new 0 84 196
assign 1 84 197
add 1 84 197
assign 1 84 198
new 0 84 198
assign 1 84 199
add 1 84 199
assign 1 84 200
add 1 84 200
return 1 84 201
assign 1 88 223
new 0 88 223
assign 1 88 224
add 1 88 224
assign 1 88 225
new 0 88 225
assign 1 88 226
add 1 88 226
assign 1 88 227
add 1 88 227
assign 1 89 228
new 0 89 228
assign 1 89 229
addValue 1 89 229
assign 1 89 230
addValue 1 89 230
assign 1 89 231
new 0 89 231
assign 1 89 232
addValue 1 89 232
addValue 1 89 233
assign 1 90 234
new 0 90 234
assign 1 90 235
addValue 1 90 235
addValue 1 90 236
assign 1 91 237
new 0 91 237
assign 1 91 238
addValue 1 91 238
assign 1 91 239
outputPlatformGet 0 91 239
assign 1 91 240
nameGet 0 91 240
assign 1 91 241
addValue 1 91 241
assign 1 91 242
new 0 91 242
assign 1 91 243
addValue 1 91 243
addValue 1 91 244
return 1 92 245
assign 1 96 251
new 0 96 251
assign 1 96 252
once 0 96 252
assign 1 96 253
add 1 96 253
return 1 96 254
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1073009537: return bem_beginNs_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1926693913: return bem_synEmitPathGet_0();
case -1052944126: return bem_csynGet_0();
case -1910715228: return bem_libEmitNameGet_0();
case 1774940957: return bem_toString_0();
case -1413054881: return bem_smnlcsGet_0();
case -797225458: return bem_dynMethodsGet_0();
case -622039562: return bem_intNpGet_0();
case -1923547459: return bem_boolCcGet_0();
case -729571811: return bem_serializeToString_0();
case 498080472: return bem_mnodeGet_0();
case 2001798761: return bem_nlGet_0();
case -1841706211: return bem_returnTypeGet_0();
case -2039613615: return bem_instanceNotEqualGet_0();
case 1240611285: return bem_onceDecsGet_0();
case -206157822: return bem_coanyiantReturnsGet_0();
case -1727672536: return bem_propDecGet_0();
case 916491491: return bem_emitLib_0();
case -722876119: return bem_buildClassInfo_0();
case -402158238: return bem_inFilePathedGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case 1327064356: return bem_methodBodyGet_0();
case -786424307: return bem_tagGet_0();
case 1529527065: return bem_onceCountGet_0();
case -1081275759: return bem_classesInDepthOrderGet_0();
case -1369896794: return bem_objectNpGet_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case -1064889660: return bem_trueValueGet_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 104713553: return bem_new_0();
case -1795655423: return bem_propertyDecsGet_0();
case 89706405: return bem_ccCacheGet_0();
case -1317806639: return bem_baseMtdDecGet_0();
case 362974009: return bem_parentConfGet_0();
case -902412214: return bem_classCallsGet_0();
case -220901978: return bem_emitLangGet_0();
case -1498619679: return bem_getLibOutput_0();
case -946095539: return bem_mainInClassGet_0();
case -1241388883: return bem_lastMethodBodySizeGet_0();
case -101343106: return bem_nativeCSlotsGet_0();
case 2055025483: return bem_serializeContents_0();
case 5583797: return bem_maxDynArgsGet_0();
case -314718434: return bem_print_0();
case -681402717: return bem_boolTypeGet_0();
case 1820417453: return bem_create_0();
case -388723214: return bem_preClassGet_0();
case -991179882: return bem_qGet_0();
case -1109279973: return bem_spropDecGet_0();
case -1487140092: return bem_classEndGet_0();
case -727049506: return bem_exceptDecGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 361542143: return bem_classEmitsGet_0();
case -1449942744: return bem_instanceEqualGet_0();
case 1859739893: return bem_methodsGet_0();
case 236269941: return bem_ccMethodsGet_0();
case -1786051763: return bem_methodCatchGet_0();
case -1354714650: return bem_copy_0();
case -2085643372: return bem_stringNpGet_0();
case -1500143225: return bem_useDynMethodsGet_0();
case -1831751774: return bem_cnodeGet_0();
case 287040793: return bem_hashGet_0();
case 57260628: return bem_getClassOutput_0();
case -1755995201: return bem_transGet_0();
case -991255330: return bem_mainStartGet_0();
case -493012039: return bem_buildGet_0();
case 604504089: return bem_falseValueGet_0();
case -644675716: return bem_ntypesGet_0();
case -4647121: return bem_doEmit_0();
case 1102720804: return bem_classNameGet_0();
case -944442837: return bem_classConfGet_0();
case 1372235405: return bem_superCallsGet_0();
case -103017121: return bem_runtimeInitGet_0();
case -1703922349: return bem_fullLibEmitNameGet_0();
case -1747980150: return bem_smnlecsGet_0();
case 772789066: return bem_libEmitPathGet_0();
case 1177623581: return bem_callNamesGet_0();
case 36542021: return bem_mainEndGet_0();
case -397629001: return bem_maxSpillArgsLenGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case -1152064310: return bem_instOfGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case -294732055: return bem_floatNpGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case 1178070402: return bem_fileExtGet_0();
case 1312373307: return bem_buildCreate_0();
case -1711936384: return bem_baseSmtdDecGet_0();
case 1181505319: return bem_buildInitial_0();
case -229958684: return bem_constGet_0();
case -955058175: return bem_lastMethodBodyLinesGet_0();
case -1607412815: return bem_endNs_0();
case -845792839: return bem_iteratorGet_0();
case -378762597: return bem_boolNpGet_0();
case 1431933907: return bem_lastCallGet_0();
case 1074463609: return bem_saveSyns_0();
case 483359873: return bem_superNameGet_0();
case -1308786538: return bem_echo_0();
case -628036310: return bem_lastMethodsSizeGet_0();
case 1380285640: return bem_objectCcGet_0();
case -1947619572: return bem_msynGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1638160588: return bem_lineCountGet_0();
case -1967844855: return bem_initialDecGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -571409003: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -1053807407: return bem_trueValueSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 2142670547: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 2144776371: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 165152860: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1227314505: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -541207893: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case -1915611660: return bem_synEmitPathSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case -1702694534: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case -610957309: return bem_intNpSet_1(bevd_0);
case -386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -593061802: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case -891329961: return bem_classCallsSet_1(bevd_0);
case -1887784556: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -980097629: return bem_qSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1820669521: return bem_cnodeSet_1(bevd_0);
case -945327254: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case -1073009536: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -90260853: return bem_nativeCSlotsSet_1(bevd_0);
case -1022041723: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case -1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1901078234: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case -596365949: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1912465206: return bem_boolCcSet_1(bevd_0);
case -377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case -943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case -1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -70425956: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case -16141842: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case -1980754914: return bem_oldacceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1936537319: return bem_msynSet_1(bevd_0);
case -551679723: return bem_formCast_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case -209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1438860491: return bem_instanceEqualSet_1(bevd_0);
case -1899632975: return bem_libEmitNameSet_1(bevd_0);
case -478502832: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -2110408325: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -193407613: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -391075985: return bem_inFilePathedSet_1(bevd_0);
case -36312873: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1041861873: return bem_csynSet_1(bevd_0);
case -1931824221: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -715967253: return bem_exceptDecSet_1(bevd_0);
case -1830623958: return bem_returnTypeSet_1(bevd_0);
case -1562282714: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case -1774969510: return bem_methodCatchSet_1(bevd_0);
case 2118534024: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case -1358814541: return bem_objectNpSet_1(bevd_0);
case -1820890036: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case -2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case -65026440: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -627952553: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -508002125: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -707569329: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -724180734: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1604046278: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1697242261: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1978614329: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1671519971: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 297627956: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_5_8_BuildNamePath) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -722876117: return bem_buildClassInfo_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -569933480: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -6388749: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case -316092711: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -2023930725: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1591575024: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildSWEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildSWEmitter.bevs_inst = (BEC_2_5_9_BuildSWEmitter)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildSWEmitter.bevs_inst;
}
}
