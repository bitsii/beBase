package be;
/* IO:File: source/build/Build.be */
public final class BEC_2_5_5_BuildBuild extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bels_6 = {0x31};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_12, 5));
private static byte[] bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_23 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_24 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_25 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_26 = {0x74,0x72,0x75,0x65};
private static byte[] bels_27 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_28 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_29 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_30 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_31 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_33 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_34 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_35 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_36 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_38 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_39 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_40 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_41 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_45 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_46 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_47 = {0x72,0x75,0x6E};
private static byte[] bels_48 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_49 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_50 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bels_51 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_52 = {0x67,0x63,0x63};
private static byte[] bels_53 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_54 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_55 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_55, 9));
private static byte[] bels_56 = {};
private static byte[] bels_57 = {0x63};
private static byte[] bels_58 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_58, 8));
private static byte[] bels_59 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_59, 7));
private static byte[] bels_60 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_61 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_62 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_62, 2));
private static byte[] bels_63 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_63, 2));
private static byte[] bels_64 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_64, 2));
private static byte[] bels_65 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_66 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_66, 19));
private static byte[] bels_67 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_67, 31));
private static byte[] bels_68 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_68, 41));
private static byte[] bels_69 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_13 = (new BEC_2_4_6_TextString(bels_69, 30));
private static byte[] bels_70 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_14 = (new BEC_2_4_6_TextString(bels_70, 31));
private static byte[] bels_71 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_15 = (new BEC_2_4_6_TextString(bels_71, 41));
private static byte[] bels_72 = {0x2F};
private static BEC_2_4_6_TextString bevo_16 = (new BEC_2_4_6_TextString(bels_72, 1));
private static byte[] bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_17 = (new BEC_2_4_6_TextString(bels_73, 31));
private static byte[] bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_18 = (new BEC_2_4_6_TextString(bels_74, 41));
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_19 = (new BEC_2_4_6_TextString(bels_75, 51));
private static byte[] bels_76 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_20 = (new BEC_2_4_6_TextString(bels_76, 14));
private static byte[] bels_77 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bevo_21 = (new BEC_2_4_6_TextString(bels_77, 19));
private static byte[] bels_78 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_22 = (new BEC_2_4_6_TextString(bels_78, 9));
private static byte[] bels_79 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_23 = (new BEC_2_4_6_TextString(bels_79, 13));
private static byte[] bels_80 = {0x2E,0x20};
private static BEC_2_4_6_TextString bevo_24 = (new BEC_2_4_6_TextString(bels_80, 2));
private static byte[] bels_81 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bevo_25 = (new BEC_2_4_6_TextString(bels_81, 22));
private static byte[] bels_82 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_26 = (new BEC_2_4_6_TextString(bels_82, 3));
private static byte[] bels_83 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bevo_27 = (new BEC_2_4_6_TextString(bels_83, 15));
private static byte[] bels_84 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_28 = (new BEC_2_4_6_TextString(bels_84, 4));
private static byte[] bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bevo_29 = (new BEC_2_4_6_TextString(bels_85, 15));
private static byte[] bels_86 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_30 = (new BEC_2_4_6_TextString(bels_86, 5));
private static byte[] bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bevo_31 = (new BEC_2_4_6_TextString(bels_87, 15));
private static byte[] bels_88 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_32 = (new BEC_2_4_6_TextString(bels_88, 6));
private static byte[] bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bevo_33 = (new BEC_2_4_6_TextString(bels_89, 15));
private static byte[] bels_90 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_34 = (new BEC_2_4_6_TextString(bels_90, 7));
private static byte[] bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bevo_35 = (new BEC_2_4_6_TextString(bels_91, 15));
private static byte[] bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_36 = (new BEC_2_4_6_TextString(bels_92, 8));
private static byte[] bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bevo_37 = (new BEC_2_4_6_TextString(bels_93, 15));
private static byte[] bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_38 = (new BEC_2_4_6_TextString(bels_94, 9));
private static byte[] bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bevo_39 = (new BEC_2_4_6_TextString(bels_95, 15));
private static byte[] bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_40 = (new BEC_2_4_6_TextString(bels_96, 10));
private static byte[] bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bevo_41 = (new BEC_2_4_6_TextString(bels_97, 15));
private static byte[] bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_42 = (new BEC_2_4_6_TextString(bels_98, 11));
private static byte[] bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bevo_43 = (new BEC_2_4_6_TextString(bels_99, 16));
private static byte[] bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_44 = (new BEC_2_4_6_TextString(bels_100, 12));
private static byte[] bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bevo_45 = (new BEC_2_4_6_TextString(bels_101, 16));
private static byte[] bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_46 = (new BEC_2_4_6_TextString(bels_102, 13));
private static byte[] bels_103 = {0x20};
private static BEC_2_4_6_TextString bevo_47 = (new BEC_2_4_6_TextString(bels_103, 1));
private static byte[] bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bevo_48 = (new BEC_2_4_6_TextString(bels_104, 16));
public static BEC_2_5_5_BuildBuild bevs_inst;
public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_dynConditionsAll;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_2_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BECS_Runtime.boolFalse;
bevp_printAst = be.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BECS_Runtime.boolFalse;
bevp_doEmit = be.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BECS_Runtime.boolFalse;
bevp_parse = be.BECS_Runtime.boolFalse;
bevp_prepMake = be.BECS_Runtime.boolFalse;
bevp_make = be.BECS_Runtime.boolFalse;
bevp_genOnly = be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_0));
bevp_lctok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = be.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 96 */ {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 97 */
bevt_7_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevt_2_tmpvar_phold = this.bem_main_1(bevl__args);
bevt_1_tmpvar_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_5));
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevp_params.bem_get_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_firstGet_0();
bevl_times = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpvar_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 115 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevl_res = this.bem_go_0();
bevl_i.bevi_int++;
} /* Line: 115 */
 else  /* Line: 115 */ {
break;
} /* Line: 115 */
} /* Line: 115 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() throws Throwable {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = be.BECS_Runtime.boolFalse;
try  /* Line: 125 */ {
bevp_buildMessage = (new BEC_2_4_6_TextString(16, bels_7));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(14, bels_8));
} /* Line: 128 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = be.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
} /* Line: 133 */
if (bevp_printSteps.bevi_bool) /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 135 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 136 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_10));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 142 */ {
} /* Line: 142 */
return beva_addTo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_config_0() throws Throwable {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_113_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_116_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_119_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_120_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
bevl_bfiles = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_2_4_6_TextString(9, bels_11));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 152 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 153 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 153 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpvar_phold.bevi_bool) {
bevt_8_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 156 */
} /* Line: 154 */
 else  /* Line: 153 */ {
break;
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
bevt_13_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_3;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 162 */
bevt_16_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_13));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_14));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 165 */ {
bevt_20_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_15));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 166 */
 else  /* Line: 167 */ {
bevp_exeName = bevp_libName;
} /* Line: 168 */
bevt_24_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_16));
bevt_25_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_17));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_19));
bevt_31_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_20));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_21));
bevt_36_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (new BEC_2_4_6_TextString(14, bels_22));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_2_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (new BEC_2_4_6_TextString(16, bels_23));
bevt_44_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_24));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_47_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_25));
bevt_48_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_26));
bevt_46_tmpvar_phold = bevp_params.bem_get_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpvar_phold);
bevt_50_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_27));
bevt_49_tmpvar_phold = bevp_params.bem_get_1(bevt_50_tmpvar_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_49_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_28));
bevt_51_tmpvar_phold = bevp_params.bem_get_1(bevt_52_tmpvar_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_51_tmpvar_phold.bem_firstGet_0();
bevt_53_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_29));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_54_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 182 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 183 */
bevt_55_tmpvar_phold = (new BEC_2_4_6_TextString(15, bels_30));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_56_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 186 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 187 */
bevt_57_tmpvar_phold = (new BEC_2_4_6_TextString(14, bels_31));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_58_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 190 */ {
bevp_deployFilesFrom = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 191 */
bevt_59_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_32));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_60_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevp_deployFilesTo = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 195 */
bevt_61_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_33));
bevp_extIncludes = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_62_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 198 */ {
bevp_extIncludes = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 199 */
bevt_63_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_34));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_64_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevp_ccObjArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 203 */
bevt_65_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_35));
bevp_extLibs = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_66_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 206 */ {
bevp_extLibs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 207 */
bevt_67_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_36));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_68_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevp_linkLibArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 211 */
bevt_69_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_37));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_70_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 214 */ {
bevp_extLinkObjects = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 215 */
bevt_71_tmpvar_phold = (new BEC_2_4_6_TextString(14, bels_38));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_71_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_72_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 219 */
bevt_73_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_39));
bevp_runArgs = bevp_params.bem_get_1(bevt_73_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_74_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 222 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 223 */
 else  /* Line: 224 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 225 */
bevt_75_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_40));
bevt_76_tmpvar_phold = be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_41));
bevt_78_tmpvar_phold = be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_77_tmpvar_phold, bevt_78_tmpvar_phold);
bevt_79_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_42));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_43));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_80_tmpvar_phold);
bevp_printAstElements = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_81_tmpvar_phold = (new BEC_2_4_6_TextString(15, bels_44));
bevl_pacm = bevp_params.bem_get_1(bevt_81_tmpvar_phold);
if (bevl_pacm == null) {
bevt_82_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 233 */ {
bevt_84_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_84_tmpvar_phold.bevi_bool) {
bevt_83_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_83_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 233 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 233 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 233 */
 else  /* Line: 233 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 233 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 234 */ {
bevt_85_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_85_tmpvar_phold != null && bevt_85_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_85_tmpvar_phold).bevi_bool) /* Line: 234 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 235 */
 else  /* Line: 234 */ {
break;
} /* Line: 234 */
} /* Line: 234 */
} /* Line: 234 */
bevt_86_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_45));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (new BEC_2_4_6_TextString(19, bels_46));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_47));
bevp_run = bevp_params.bem_isTrue_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (new BEC_2_4_6_TextString(21, bels_48));
bevt_90_tmpvar_phold = be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_89_tmpvar_phold, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_49));
bevp_emitLangs = bevp_params.bem_get_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_50));
bevp_emitFlags = bevp_params.bem_get_1(bevt_92_tmpvar_phold);
bevt_94_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_51));
bevt_95_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_52));
bevt_93_tmpvar_phold = bevp_params.bem_get_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_93_tmpvar_phold.bem_firstGet_0();
bevt_97_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_53));
bevt_98_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_54));
bevt_96_tmpvar_phold = bevp_params.bem_get_2(bevt_97_tmpvar_phold, bevt_98_tmpvar_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_96_tmpvar_phold.bem_firstGet_0();
bevt_101_tmpvar_phold = bevo_4;
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_102_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_56));
bevt_99_tmpvar_phold = bevp_params.bem_get_2(bevt_100_tmpvar_phold, bevt_102_tmpvar_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_99_tmpvar_phold.bem_firstGet_0();
bevp_parse = be.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BECS_Runtime.boolTrue;
bevp_doEmit = be.BECS_Runtime.boolTrue;
bevp_prepMake = be.BECS_Runtime.boolTrue;
bevp_make = be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_103_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_103_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 255 */
 else  /* Line: 256 */ {
bevl_outLang = (new BEC_2_4_6_TextString(1, bels_57));
} /* Line: 257 */
bevt_106_tmpvar_phold = bevo_5;
bevt_105_tmpvar_phold = bevl_outLang.bem_add_1(bevt_106_tmpvar_phold);
bevt_107_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_add_1(bevt_107_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_104_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_108_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 265 */ {
bevt_109_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_109_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 266 */
bevt_111_tmpvar_phold = bevo_6;
bevt_110_tmpvar_phold = bevl_outLang.bem_add_1(bevt_111_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_110_tmpvar_phold);
if (bevl_langSources == null) {
bevt_112_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_112_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_112_tmpvar_phold.bevi_bool) /* Line: 270 */ {
bevt_113_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_113_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 271 */
bevp_toBuild = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_114_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_114_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 275 */ {
bevt_115_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_115_tmpvar_phold != null && bevt_115_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_115_tmpvar_phold).bevi_bool) /* Line: 275 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_116_tmpvar_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_116_tmpvar_phold);
} /* Line: 276 */
 else  /* Line: 275 */ {
break;
} /* Line: 275 */
} /* Line: 275 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_119_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bem_existsGet_0();
if (bevt_118_tmpvar_phold.bevi_bool) {
bevt_117_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_117_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 283 */ {
bevt_120_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_120_tmpvar_phold.bem_makeDirs_0();
} /* Line: 284 */
if (bevp_emitFileHeader == null) {
bevt_121_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_121_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 286 */ {
bevt_122_tmpvar_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_122_tmpvar_phold.bem_readerGet_0();
bevt_123_tmpvar_phold = bevl_emr.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_123_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 289 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_60));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_61));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_setClassesToWrite_0() throws Throwable {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 303 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 303 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 305 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 308 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 309 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 310 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
} /* Line: 309 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 315 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 316 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 314 */
} /* Line: 305 */
 else  /* Line: 303 */ {
break;
} /* Line: 303 */
} /* Line: 303 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 321 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 321 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 323 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 334 */ {
return bevp_emitCommon;
} /* Line: 335 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 340 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_7;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 342 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 343 */
 else  /* Line: 342 */ {
bevt_5_tmpvar_phold = bevo_8;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 344 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 345 */
 else  /* Line: 342 */ {
bevt_7_tmpvar_phold = bevo_9;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 346 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 347 */
 else  /* Line: 348 */ {
bevt_9_tmpvar_phold = (new BEC_2_4_6_TextString(49, bels_65));
bevt_8_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 349 */
} /* Line: 342 */
} /* Line: 342 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 352 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_4_8_TimeInterval bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_16_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_21_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_23_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_24_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_37_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_38_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_64_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_76_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpvar_phold = null;
bevt_4_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_4_tmpvar_phold.bem_now_0();
bevp_emitData = (new BEC_2_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_5_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 362 */ {
bevp_deployLibrary = (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 365 */ {
bevt_7_tmpvar_phold = bevo_10;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_libName);
bevt_6_tmpvar_phold.bem_print_0();
} /* Line: 366 */
} /* Line: 365 */
bevl_ulibs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 371 */ {
bevt_8_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 371 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_10_tmpvar_phold.bevi_bool) {
bevt_9_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 372 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 375 */
} /* Line: 372 */
 else  /* Line: 371 */ {
break;
} /* Line: 371 */
} /* Line: 371 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 378 */ {
bevt_11_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 378 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_13_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpvar_phold.bevi_bool) {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 379 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_14_tmpvar_phold = bevl_pack.bemd_0(-1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_14_tmpvar_phold);
} /* Line: 383 */
} /* Line: 379 */
 else  /* Line: 378 */ {
break;
} /* Line: 378 */
} /* Line: 378 */
if (bevp_parse.bevi_bool) /* Line: 386 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 388 */ {
bevt_15_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 388 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 391 */
 else  /* Line: 388 */ {
break;
} /* Line: 388 */
} /* Line: 388 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 393 */
bevt_17_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_now_0();
bevp_parseTime = bevt_16_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_19_tmpvar_phold = bevo_11;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_18_tmpvar_phold.bem_print_0();
bevt_21_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_21_tmpvar_phold == null) {
bevt_20_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 400 */ {
bevt_22_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = bevt_22_tmpvar_phold.bem_now_0();
bevt_23_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_23_tmpvar_phold.bem_doEmit_0();
bevt_25_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_24_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_27_tmpvar_phold = bevo_12;
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_26_tmpvar_phold.bem_print_0();
bevt_29_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_now_0();
bevl_emitTime = bevt_28_tmpvar_phold.bem_subtract_1(bevl_emitStart);
bevt_31_tmpvar_phold = bevo_13;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevl_emitTime);
bevt_30_tmpvar_phold.bem_print_0();
bevt_32_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
return bevt_32_tmpvar_phold;
} /* Line: 408 */
if (bevp_doEmit.bevi_bool) /* Line: 410 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_33_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_33_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 414 */ {
bevt_34_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_34_tmpvar_phold != null && bevt_34_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpvar_phold).bevi_bool) /* Line: 414 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(-4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 416 */
 else  /* Line: 414 */ {
break;
} /* Line: 414 */
} /* Line: 414 */
bevl_em.bemd_0(-1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_35_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_35_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 420 */ {
bevt_36_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 420 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 422 */
 else  /* Line: 420 */ {
break;
} /* Line: 420 */
} /* Line: 420 */
} /* Line: 420 */
bevt_38_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_37_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_39_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 427 */ {
bevt_41_tmpvar_phold = bevo_14;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_40_tmpvar_phold.bem_print_0();
} /* Line: 428 */
bevt_43_tmpvar_phold = bevo_15;
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_42_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 431 */ {
bevl_em.bemd_1(-1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 433 */
if (bevp_make.bevi_bool) /* Line: 436 */ {
if (bevp_genOnly.bevi_bool) {
bevt_44_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 437 */ {
bevl_em.bemd_1(-1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 440 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 441 */ {
bevt_45_tmpvar_phold = bevt_2_tmpvar_loop.bem_hasNextGet_0();
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 441 */ {
bevl_bp = bevt_2_tmpvar_loop.bem_nextGet_0();
bevt_46_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_46_tmpvar_phold.bemd_0(-159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_47_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_47_tmpvar_phold.bem_copy_0();
bevt_49_tmpvar_phold = bevl_cpFrom.bemd_0(-723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_48_tmpvar_phold);
bevt_51_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 445 */ {
bevt_52_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_52_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 446 */
bevt_55_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_53_tmpvar_phold != null && bevt_53_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_53_tmpvar_phold).bevi_bool) /* Line: 448 */ {
bevt_56_tmpvar_phold = bevl_cpFrom.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_57_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEL_4_Base.bevn_deployFile_2, bevt_56_tmpvar_phold, bevt_57_tmpvar_phold);
} /* Line: 449 */
} /* Line: 448 */
 else  /* Line: 441 */ {
break;
} /* Line: 441 */
} /* Line: 441 */
} /* Line: 441 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 456 */ {
bevt_58_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_58_tmpvar_phold != null && bevt_58_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_58_tmpvar_phold).bevi_bool) /* Line: 456 */ {
bevt_59_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 456 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 456 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 456 */
 else  /* Line: 456 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 456 */ {
bevt_60_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_60_tmpvar_phold);
bevt_65_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bem_copy_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_toString_0();
bevt_66_tmpvar_phold = bevo_16;
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_add_1(bevt_66_tmpvar_phold);
bevt_67_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bem_add_1(bevt_67_tmpvar_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_61_tmpvar_phold);
bevt_69_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_68_tmpvar_phold != null && bevt_68_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_68_tmpvar_phold).bevi_bool) /* Line: 460 */ {
bevt_70_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_70_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 461 */
bevt_73_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_71_tmpvar_phold != null && bevt_71_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_71_tmpvar_phold).bevi_bool) /* Line: 463 */ {
bevt_74_tmpvar_phold = bevl_cpFrom.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_75_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEL_4_Base.bevn_deployFile_2, bevt_74_tmpvar_phold, bevt_75_tmpvar_phold);
} /* Line: 464 */
} /* Line: 463 */
 else  /* Line: 456 */ {
break;
} /* Line: 456 */
} /* Line: 456 */
} /* Line: 456 */
} /* Line: 437 */
bevt_77_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_76_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_78_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 471 */ {
bevt_80_tmpvar_phold = bevo_17;
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_79_tmpvar_phold.bem_print_0();
} /* Line: 472 */
if (bevp_parseEmitTime == null) {
bevt_81_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 474 */ {
bevt_83_tmpvar_phold = bevo_18;
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_82_tmpvar_phold.bem_print_0();
} /* Line: 475 */
if (bevp_parseEmitCompileTime == null) {
bevt_84_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpvar_phold.bevi_bool) /* Line: 477 */ {
bevt_86_tmpvar_phold = bevo_19;
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_85_tmpvar_phold.bem_print_0();
} /* Line: 478 */
if (bevp_run.bevi_bool) /* Line: 481 */ {
bevt_87_tmpvar_phold = bevo_20;
bevt_87_tmpvar_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_90_tmpvar_phold = bevo_21;
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bem_add_1(bevl_result);
bevt_91_tmpvar_phold = bevo_22;
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_add_1(bevt_91_tmpvar_phold);
bevt_88_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 485 */
bevt_92_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
return bevt_92_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 491 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 491 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 495 */
 else  /* Line: 491 */ {
break;
} /* Line: 491 */
} /* Line: 491 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 497 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 497 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 501 */
 else  /* Line: 497 */ {
break;
} /* Line: 497 */
} /* Line: 497 */
bevt_6_tmpvar_phold = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 507 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 508 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 511 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 512 */
 else  /* Line: 513 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 518 */
 else  /* Line: 519 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 521 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 523 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpvar_phold, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) throws Throwable {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 533 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 534 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 549 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 550 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) throws Throwable {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 563 */ {
if (bevp_printSteps.bevi_bool) /* Line: 564 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 564 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 564 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 564 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 564 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 564 */ {
bevt_4_tmpvar_phold = bevo_23;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 565 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 574 */ {
bevt_11_tmpvar_phold = bevo_24;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 575 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(-1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 578 */ {
bevt_13_tmpvar_phold = bevo_25;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 580 */
if (bevp_printSteps.bevi_bool) /* Line: 583 */ {
bevt_15_tmpvar_phold = bevo_26;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 584 */
bevt_16_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 587 */ {
bevt_17_tmpvar_phold = bevo_27;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 589 */
if (bevp_printSteps.bevi_bool) /* Line: 591 */ {
bevt_19_tmpvar_phold = bevo_28;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 592 */
bevt_20_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(-410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 597 */ {
bevt_21_tmpvar_phold = bevo_29;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 599 */
if (bevp_printSteps.bevi_bool) /* Line: 602 */ {
bevt_23_tmpvar_phold = bevo_30;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 603 */
bevt_24_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 606 */ {
bevt_25_tmpvar_phold = bevo_31;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 608 */
if (bevp_printSteps.bevi_bool) /* Line: 611 */ {
bevt_27_tmpvar_phold = bevo_32;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 612 */
bevt_28_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 615 */ {
bevt_29_tmpvar_phold = bevo_33;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 617 */
if (bevp_printSteps.bevi_bool) /* Line: 620 */ {
bevt_31_tmpvar_phold = bevo_34;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 621 */
bevt_32_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 624 */ {
bevt_33_tmpvar_phold = bevo_35;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 626 */
if (bevp_printSteps.bevi_bool) /* Line: 629 */ {
bevt_35_tmpvar_phold = bevo_36;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 630 */
bevt_36_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 633 */ {
bevt_37_tmpvar_phold = bevo_37;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 635 */
if (bevp_printSteps.bevi_bool) /* Line: 638 */ {
bevt_39_tmpvar_phold = bevo_38;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 639 */
bevt_40_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 642 */ {
bevt_41_tmpvar_phold = bevo_39;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 644 */
if (bevp_printSteps.bevi_bool) /* Line: 647 */ {
bevt_43_tmpvar_phold = bevo_40;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 648 */
bevt_44_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 651 */ {
bevt_45_tmpvar_phold = bevo_41;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 653 */
if (bevp_printSteps.bevi_bool) /* Line: 656 */ {
bevt_47_tmpvar_phold = bevo_42;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 657 */
bevt_48_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 660 */ {
bevt_49_tmpvar_phold = bevo_43;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 662 */
if (bevp_printSteps.bevi_bool) /* Line: 664 */ {
bevt_51_tmpvar_phold = bevo_44;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 665 */
bevt_52_tmpvar_phold = (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 668 */ {
bevt_53_tmpvar_phold = bevo_45;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 670 */
if (bevp_printSteps.bevi_bool) /* Line: 673 */ {
bevt_55_tmpvar_phold = bevo_46;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_47;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 675 */
bevt_57_tmpvar_phold = (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 678 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 678 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 678 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 678 */ {
bevt_58_tmpvar_phold = bevo_48;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 680 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 682 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 682 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(-1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(-568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(-557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 693 */
 else  /* Line: 682 */ {
break;
} /* Line: 682 */
} /* Line: 682 */
} /* Line: 682 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 703 */ {
bevt_1_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 703 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(-1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 707 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 708 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 710 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 712 */
} /* Line: 710 */
 else  /* Line: 703 */ {
break;
} /* Line: 703 */
} /* Line: 703 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_6_SystemObject bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_6_SystemObject bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_2_6_6_SystemObject bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_2_6_6_SystemObject bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_2_6_6_SystemObject bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_6_6_SystemObject bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_6_6_SystemObject bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_6_6_SystemObject bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_dynConditionsAllGet_0() throws Throwable {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_2_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {53, 55, 56, 57, 58, 60, 61, 62, 63, 64, 65, 66, 70, 72, 73, 74, 75, 75, 78, 81, 82, 88, 89, 90, 91, 91, 96, 96, 96, 96, 0, 96, 96, 0, 0, 0, 0, 0, 97, 97, 99, 99, 103, 103, 103, 103, 107, 107, 108, 108, 108, 112, 113, 114, 114, 114, 114, 114, 115, 115, 115, 116, 115, 118, 122, 123, 124, 126, 127, 128, 130, 131, 132, 132, 133, 0, 0, 0, 136, 138, 142, 142, 142, 144, 149, 151, 152, 152, 152, 153, 153, 0, 153, 153, 154, 154, 154, 155, 156, 156, 161, 161, 161, 161, 162, 164, 164, 164, 165, 165, 166, 166, 166, 168, 170, 170, 170, 170, 170, 170, 171, 172, 172, 173, 173, 173, 173, 173, 173, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 179, 179, 179, 180, 180, 180, 181, 181, 182, 182, 183, 185, 185, 186, 186, 187, 189, 189, 190, 190, 191, 193, 193, 194, 194, 195, 197, 197, 198, 198, 199, 201, 201, 202, 202, 203, 205, 205, 206, 206, 207, 209, 209, 210, 210, 211, 213, 213, 214, 214, 215, 217, 217, 218, 218, 219, 221, 221, 222, 222, 223, 225, 227, 227, 227, 228, 228, 228, 229, 229, 230, 230, 231, 232, 232, 233, 233, 233, 233, 233, 0, 0, 0, 234, 0, 234, 234, 235, 238, 238, 239, 239, 240, 240, 241, 241, 241, 242, 242, 243, 243, 244, 244, 244, 244, 245, 245, 245, 245, 246, 246, 246, 246, 246, 247, 248, 249, 250, 251, 254, 254, 255, 257, 264, 264, 264, 264, 264, 265, 265, 266, 266, 269, 269, 269, 270, 270, 271, 271, 274, 275, 275, 0, 275, 275, 276, 276, 278, 279, 280, 282, 283, 283, 283, 283, 284, 284, 286, 286, 287, 287, 288, 288, 289, 295, 296, 296, 296, 296, 296, 297, 297, 297, 297, 297, 298, 302, 303, 303, 303, 304, 305, 305, 305, 305, 306, 306, 306, 306, 307, 307, 307, 307, 307, 308, 308, 309, 0, 309, 309, 310, 313, 313, 313, 313, 313, 314, 314, 315, 0, 315, 315, 316, 321, 321, 321, 322, 323, 323, 323, 323, 323, 323, 330, 330, 334, 334, 335, 340, 340, 341, 342, 342, 343, 344, 344, 345, 346, 346, 347, 349, 349, 349, 351, 352, 354, 359, 359, 360, 361, 362, 362, 363, 364, 366, 366, 366, 369, 371, 0, 371, 371, 372, 372, 372, 373, 374, 375, 378, 0, 378, 378, 379, 379, 379, 380, 381, 382, 383, 383, 388, 388, 389, 391, 393, 396, 396, 396, 398, 398, 398, 400, 400, 400, 402, 402, 403, 403, 404, 404, 404, 405, 405, 405, 406, 406, 406, 407, 407, 407, 408, 408, 411, 412, 414, 414, 414, 415, 416, 418, 419, 420, 420, 420, 421, 422, 426, 426, 426, 427, 427, 428, 428, 428, 430, 430, 430, 433, 437, 437, 438, 439, 441, 0, 441, 441, 442, 442, 443, 443, 444, 444, 444, 445, 445, 446, 446, 448, 448, 448, 449, 449, 449, 453, 454, 456, 456, 0, 0, 0, 457, 457, 458, 458, 458, 458, 458, 458, 458, 458, 460, 460, 461, 461, 463, 463, 463, 464, 464, 464, 469, 469, 469, 471, 471, 472, 472, 472, 474, 474, 475, 475, 475, 477, 477, 478, 478, 478, 482, 482, 483, 484, 484, 484, 484, 484, 485, 487, 487, 491, 491, 491, 492, 493, 493, 494, 495, 497, 497, 497, 498, 499, 499, 500, 501, 503, 503, 507, 507, 507, 507, 508, 508, 508, 510, 510, 511, 511, 511, 511, 512, 514, 514, 514, 514, 514, 516, 516, 517, 517, 518, 521, 521, 521, 523, 525, 525, 526, 526, 526, 526, 527, 531, 532, 532, 533, 533, 534, 540, 540, 541, 542, 549, 549, 550, 552, 557, 558, 559, 560, 561, 562, 562, 0, 0, 0, 565, 565, 565, 565, 567, 569, 569, 569, 569, 570, 570, 570, 571, 575, 575, 577, 577, 579, 579, 580, 580, 584, 584, 586, 586, 588, 588, 589, 589, 592, 592, 595, 595, 596, 598, 598, 599, 599, 603, 603, 605, 605, 607, 607, 608, 608, 612, 612, 614, 614, 616, 616, 617, 617, 621, 621, 623, 623, 625, 625, 626, 626, 630, 630, 632, 632, 634, 634, 635, 635, 639, 639, 641, 641, 643, 643, 644, 644, 648, 648, 650, 650, 652, 652, 653, 653, 657, 657, 659, 659, 661, 661, 662, 662, 665, 665, 667, 667, 669, 669, 670, 670, 674, 674, 675, 675, 677, 677, 0, 0, 0, 679, 679, 680, 680, 682, 682, 682, 683, 685, 686, 687, 687, 688, 689, 689, 689, 690, 691, 692, 693, 699, 700, 701, 702, 702, 703, 703, 704, 705, 705, 706, 707, 707, 708, 710, 710, 711, 712, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 271, 276, 277, 278, 280, 283, 284, 286, 289, 293, 296, 300, 303, 304, 306, 307, 313, 314, 315, 316, 323, 324, 325, 326, 327, 339, 340, 341, 342, 343, 344, 345, 346, 349, 354, 355, 356, 362, 370, 371, 372, 374, 375, 376, 380, 381, 382, 383, 384, 387, 391, 394, 398, 400, 406, 407, 408, 411, 547, 548, 549, 550, 555, 556, 557, 557, 560, 562, 563, 564, 569, 570, 571, 572, 580, 581, 582, 583, 585, 587, 588, 589, 590, 591, 593, 594, 595, 598, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 649, 650, 652, 653, 654, 659, 660, 662, 663, 664, 669, 670, 672, 673, 674, 679, 680, 682, 683, 684, 689, 690, 692, 693, 694, 699, 700, 702, 703, 704, 709, 710, 712, 713, 714, 719, 720, 722, 723, 724, 729, 730, 732, 733, 734, 739, 740, 742, 743, 744, 749, 750, 753, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 773, 774, 775, 780, 781, 784, 788, 791, 791, 794, 796, 797, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 840, 841, 844, 846, 847, 848, 849, 850, 851, 856, 857, 858, 860, 861, 862, 863, 868, 869, 870, 872, 873, 874, 874, 877, 879, 880, 881, 887, 888, 889, 890, 891, 892, 893, 898, 899, 900, 902, 907, 908, 909, 910, 911, 912, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 977, 978, 979, 982, 984, 985, 986, 987, 988, 990, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1004, 1005, 1005, 1008, 1010, 1011, 1018, 1019, 1020, 1021, 1022, 1023, 1028, 1029, 1029, 1032, 1034, 1035, 1048, 1049, 1052, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1070, 1071, 1085, 1090, 1091, 1093, 1098, 1099, 1100, 1101, 1103, 1106, 1107, 1109, 1112, 1113, 1115, 1118, 1119, 1120, 1124, 1125, 1127, 1239, 1240, 1241, 1242, 1243, 1248, 1249, 1250, 1252, 1253, 1254, 1257, 1258, 1258, 1261, 1263, 1264, 1265, 1270, 1271, 1272, 1273, 1280, 1280, 1283, 1285, 1286, 1287, 1292, 1293, 1294, 1295, 1296, 1297, 1305, 1308, 1310, 1311, 1317, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1331, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1345, 1346, 1347, 1348, 1349, 1352, 1353, 1354, 1355, 1358, 1360, 1361, 1367, 1368, 1369, 1370, 1373, 1375, 1376, 1383, 1384, 1385, 1386, 1391, 1392, 1393, 1394, 1396, 1397, 1398, 1400, 1403, 1408, 1409, 1410, 1412, 1412, 1415, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1428, 1429, 1431, 1432, 1433, 1435, 1436, 1437, 1445, 1446, 1449, 1451, 1453, 1456, 1460, 1463, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1473, 1474, 1476, 1477, 1479, 1480, 1481, 1483, 1484, 1485, 1494, 1495, 1496, 1497, 1502, 1503, 1504, 1505, 1507, 1512, 1513, 1514, 1515, 1517, 1522, 1523, 1524, 1525, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1538, 1539, 1552, 1553, 1556, 1558, 1559, 1560, 1561, 1562, 1568, 1569, 1572, 1574, 1575, 1576, 1577, 1578, 1584, 1585, 1613, 1614, 1615, 1620, 1621, 1622, 1623, 1625, 1626, 1627, 1628, 1629, 1634, 1635, 1638, 1639, 1640, 1641, 1642, 1643, 1648, 1649, 1650, 1651, 1654, 1655, 1656, 1658, 1660, 1661, 1662, 1663, 1664, 1665, 1666, 1674, 1675, 1676, 1677, 1682, 1683, 1685, 1686, 1687, 1688, 1692, 1697, 1698, 1700, 1779, 1780, 1781, 1782, 1783, 1784, 1785, 1788, 1792, 1795, 1799, 1800, 1801, 1802, 1804, 1805, 1806, 1807, 1808, 1809, 1810, 1811, 1812, 1814, 1815, 1817, 1818, 1820, 1821, 1822, 1823, 1826, 1827, 1829, 1830, 1832, 1833, 1834, 1835, 1838, 1839, 1841, 1842, 1843, 1845, 1846, 1847, 1848, 1851, 1852, 1854, 1855, 1857, 1858, 1859, 1860, 1863, 1864, 1866, 1867, 1869, 1870, 1871, 1872, 1875, 1876, 1878, 1879, 1881, 1882, 1883, 1884, 1887, 1888, 1890, 1891, 1893, 1894, 1895, 1896, 1899, 1900, 1902, 1903, 1905, 1906, 1907, 1908, 1911, 1912, 1914, 1915, 1917, 1918, 1919, 1920, 1923, 1924, 1926, 1927, 1929, 1930, 1931, 1932, 1935, 1936, 1938, 1939, 1941, 1942, 1943, 1944, 1947, 1948, 1949, 1950, 1952, 1953, 1955, 1959, 1962, 1966, 1967, 1968, 1969, 1971, 1972, 1975, 1977, 1978, 1979, 1980, 1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 2011, 2012, 2013, 2014, 2015, 2016, 2019, 2021, 2022, 2023, 2024, 2025, 2026, 2028, 2030, 2031, 2033, 2034, 2044, 2047, 2051, 2054, 2058, 2061, 2065, 2068, 2072, 2075, 2079, 2082, 2086, 2089, 2093, 2096, 2100, 2103, 2107, 2110, 2114, 2117, 2121, 2124, 2128, 2131, 2135, 2138, 2142, 2145, 2149, 2152, 2156, 2159, 2163, 2166, 2170, 2173, 2177, 2180, 2184, 2187, 2191, 2194, 2198, 2201, 2205, 2208, 2212, 2215, 2219, 2222, 2226, 2229, 2233, 2236, 2240, 2243, 2247, 2250, 2254, 2257, 2261, 2264, 2268, 2271, 2275, 2278, 2282, 2285, 2289, 2292, 2296, 2299, 2303, 2306, 2310, 2313, 2317, 2320, 2324, 2327, 2331, 2334, 2338, 2341, 2345, 2348, 2352, 2355, 2359, 2362, 2366, 2369, 2373, 2376, 2380, 2383, 2387, 2390, 2394, 2397, 2401, 2404, 2408, 2411, 2415, 2418, 2422, 2425, 2429, 2432, 2436, 2439, 2443, 2446, 2450, 2453, 2457, 2460, 2464, 2467, 2471, 2474, 2478, 2481, 2485, 2488, 2492, 2495, 2499, 2502, 2506, 2509, 2513, 2516, 2520};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 53 234
new 0 53 234
assign 1 55 235
new 0 55 235
assign 1 56 236
new 0 56 236
assign 1 57 237
new 0 57 237
assign 1 58 238
new 0 58 238
assign 1 60 239
new 0 60 239
assign 1 61 240
new 0 61 240
assign 1 62 241
new 0 62 241
assign 1 63 242
new 0 63 242
assign 1 64 243
new 0 64 243
assign 1 65 244
new 0 65 244
assign 1 66 245
new 0 66 245
assign 1 70 246
new 0 70 246
assign 1 72 247
new 1 72 247
assign 1 73 248
ntypesGet 0 73 248
assign 1 74 249
twtokGet 0 74 249
assign 1 75 250
new 0 75 250
assign 1 75 251
new 1 75 251
assign 1 78 252
new 0 78 252
assign 1 81 253
new 0 81 253
assign 1 82 254
new 0 82 254
assign 1 88 255
new 0 88 255
assign 1 89 256
new 0 89 256
assign 1 90 257
new 0 90 257
assign 1 91 258
new 0 91 258
assign 1 91 259
new 1 91 259
assign 1 96 271
def 1 96 276
assign 1 96 277
new 0 96 277
assign 1 96 278
equals 1 96 278
assign 1 0 280
assign 1 96 283
new 0 96 283
assign 1 96 284
ends 1 96 284
assign 1 0 286
assign 1 0 289
assign 1 0 293
assign 1 0 296
assign 1 0 300
assign 1 97 303
new 0 97 303
return 1 97 304
assign 1 99 306
new 0 99 306
return 1 99 307
assign 1 103 313
new 0 103 313
assign 1 103 314
new 0 103 314
assign 1 103 315
swap 2 103 315
return 1 103 316
assign 1 107 323
new 0 107 323
assign 1 107 324
argsGet 0 107 324
assign 1 108 325
new 0 108 325
assign 1 108 326
main 1 108 326
exit 1 108 327
assign 1 112 339
assign 1 113 340
new 1 113 340
assign 1 114 341
new 0 114 341
assign 1 114 342
new 0 114 342
assign 1 114 343
get 2 114 343
assign 1 114 344
firstGet 0 114 344
assign 1 114 345
new 1 114 345
assign 1 115 346
new 0 115 346
assign 1 115 349
lesser 1 115 354
assign 1 116 355
go 0 116 355
incrementValue 0 115 356
return 1 118 362
assign 1 122 370
new 0 122 370
config 0 123 371
assign 1 124 372
new 0 124 372
assign 1 126 374
new 0 126 374
assign 1 127 375
doWhat 0 127 375
assign 1 128 376
new 0 128 376
assign 1 130 380
toString 0 130 380
assign 1 131 381
new 0 131 381
assign 1 132 382
new 0 132 382
assign 1 132 383
add 1 132 383
assign 1 133 384
new 0 133 384
assign 1 0 387
assign 1 0 391
assign 1 0 394
print 0 136 398
return 1 138 400
assign 1 142 406
nameGet 0 142 406
assign 1 142 407
new 0 142 407
assign 1 142 408
equals 1 142 408
return 1 144 411
assign 1 149 547
new 0 149 547
assign 1 151 548
new 0 151 548
assign 1 152 549
get 1 152 549
assign 1 152 550
def 1 152 555
assign 1 153 556
get 1 153 556
assign 1 153 557
iteratorGet 0 0 557
assign 1 153 560
hasNextGet 0 153 560
assign 1 153 562
nextGet 0 153 562
assign 1 154 563
has 1 154 563
assign 1 154 564
not 0 154 569
put 1 155 570
assign 1 156 571
new 1 156 571
addFile 1 156 572
assign 1 161 580
new 0 161 580
assign 1 161 581
nameGet 0 161 581
assign 1 161 582
new 0 161 582
assign 1 161 583
equals 1 161 583
preProcessorSet 1 162 585
assign 1 164 587
new 0 164 587
assign 1 164 588
get 1 164 588
assign 1 164 589
firstGet 0 164 589
assign 1 165 590
new 0 165 590
assign 1 165 591
has 1 165 591
assign 1 166 593
new 0 166 593
assign 1 166 594
get 1 166 594
assign 1 166 595
firstGet 0 166 595
assign 1 168 598
assign 1 170 600
new 0 170 600
assign 1 170 601
new 0 170 601
assign 1 170 602
get 2 170 602
assign 1 170 603
firstGet 0 170 603
assign 1 170 604
new 1 170 604
assign 1 170 605
pathGet 0 170 605
addStep 1 171 606
assign 1 172 607
new 0 172 607
addStep 1 172 608
assign 1 173 609
new 0 173 609
assign 1 173 610
new 0 173 610
assign 1 173 611
get 2 173 611
assign 1 173 612
firstGet 0 173 612
assign 1 173 613
new 1 173 613
assign 1 173 614
pathGet 0 173 614
assign 1 174 615
new 0 174 615
assign 1 174 616
new 0 174 616
assign 1 174 617
nameGet 0 174 617
assign 1 174 618
get 2 174 618
assign 1 174 619
firstGet 0 174 619
assign 1 174 620
new 1 174 620
assign 1 175 621
new 0 175 621
assign 1 175 622
nameGet 0 175 622
assign 1 175 623
get 2 175 623
assign 1 175 624
firstGet 0 175 624
assign 1 175 625
new 1 175 625
assign 1 176 626
new 0 176 626
assign 1 176 627
new 0 176 627
assign 1 176 628
get 2 176 628
assign 1 176 629
firstGet 0 176 629
assign 1 176 630
new 1 176 630
assign 1 177 631
new 0 177 631
assign 1 177 632
new 0 177 632
assign 1 177 633
get 2 177 633
assign 1 177 634
firstGet 0 177 634
assign 1 177 635
new 1 177 635
assign 1 179 636
new 0 179 636
assign 1 179 637
get 1 179 637
assign 1 179 638
firstGet 0 179 638
assign 1 180 639
new 0 180 639
assign 1 180 640
get 1 180 640
assign 1 180 641
firstGet 0 180 641
assign 1 181 642
new 0 181 642
assign 1 181 643
get 1 181 643
assign 1 182 644
undef 1 182 649
assign 1 183 650
new 0 183 650
assign 1 185 652
new 0 185 652
assign 1 185 653
get 1 185 653
assign 1 186 654
undef 1 186 659
assign 1 187 660
new 0 187 660
assign 1 189 662
new 0 189 662
assign 1 189 663
get 1 189 663
assign 1 190 664
undef 1 190 669
assign 1 191 670
new 0 191 670
assign 1 193 672
new 0 193 672
assign 1 193 673
get 1 193 673
assign 1 194 674
undef 1 194 679
assign 1 195 680
new 0 195 680
assign 1 197 682
new 0 197 682
assign 1 197 683
get 1 197 683
assign 1 198 684
undef 1 198 689
assign 1 199 690
new 0 199 690
assign 1 201 692
new 0 201 692
assign 1 201 693
get 1 201 693
assign 1 202 694
undef 1 202 699
assign 1 203 700
new 0 203 700
assign 1 205 702
new 0 205 702
assign 1 205 703
get 1 205 703
assign 1 206 704
undef 1 206 709
assign 1 207 710
new 0 207 710
assign 1 209 712
new 0 209 712
assign 1 209 713
get 1 209 713
assign 1 210 714
undef 1 210 719
assign 1 211 720
new 0 211 720
assign 1 213 722
new 0 213 722
assign 1 213 723
get 1 213 723
assign 1 214 724
undef 1 214 729
assign 1 215 730
new 0 215 730
assign 1 217 732
new 0 217 732
assign 1 217 733
get 1 217 733
assign 1 218 734
def 1 218 739
assign 1 219 740
firstGet 0 219 740
assign 1 221 742
new 0 221 742
assign 1 221 743
get 1 221 743
assign 1 222 744
def 1 222 749
assign 1 223 750
firstGet 0 223 750
assign 1 225 753
new 0 225 753
assign 1 227 755
new 0 227 755
assign 1 227 756
new 0 227 756
assign 1 227 757
isTrue 2 227 757
assign 1 228 758
new 0 228 758
assign 1 228 759
new 0 228 759
assign 1 228 760
isTrue 2 228 760
assign 1 229 761
new 0 229 761
assign 1 229 762
isTrue 1 229 762
assign 1 230 763
new 0 230 763
assign 1 230 764
isTrue 1 230 764
assign 1 231 765
new 0 231 765
assign 1 232 766
new 0 232 766
assign 1 232 767
get 1 232 767
assign 1 233 768
def 1 233 773
assign 1 233 774
isEmptyGet 0 233 774
assign 1 233 775
not 0 233 780
assign 1 0 781
assign 1 0 784
assign 1 0 788
assign 1 234 791
linkedListIteratorGet 0 0 791
assign 1 234 794
hasNextGet 0 234 794
assign 1 234 796
nextGet 0 234 796
put 1 235 797
assign 1 238 804
new 0 238 804
assign 1 238 805
isTrue 1 238 805
assign 1 239 806
new 0 239 806
assign 1 239 807
isTrue 1 239 807
assign 1 240 808
new 0 240 808
assign 1 240 809
isTrue 1 240 809
assign 1 241 810
new 0 241 810
assign 1 241 811
new 0 241 811
assign 1 241 812
isTrue 2 241 812
assign 1 242 813
new 0 242 813
assign 1 242 814
get 1 242 814
assign 1 243 815
new 0 243 815
assign 1 243 816
get 1 243 816
assign 1 244 817
new 0 244 817
assign 1 244 818
new 0 244 818
assign 1 244 819
get 2 244 819
assign 1 244 820
firstGet 0 244 820
assign 1 245 821
new 0 245 821
assign 1 245 822
new 0 245 822
assign 1 245 823
get 2 245 823
assign 1 245 824
firstGet 0 245 824
assign 1 246 825
new 0 246 825
assign 1 246 826
add 1 246 826
assign 1 246 827
new 0 246 827
assign 1 246 828
get 2 246 828
assign 1 246 829
firstGet 0 246 829
assign 1 247 830
new 0 247 830
assign 1 248 831
new 0 248 831
assign 1 249 832
new 0 249 832
assign 1 250 833
new 0 250 833
assign 1 251 834
new 0 251 834
assign 1 254 835
def 1 254 840
assign 1 255 841
firstGet 0 255 841
assign 1 257 844
new 0 257 844
assign 1 264 846
new 0 264 846
assign 1 264 847
add 1 264 847
assign 1 264 848
nameGet 0 264 848
assign 1 264 849
add 1 264 849
assign 1 264 850
get 1 264 850
assign 1 265 851
def 1 265 856
assign 1 266 857
orderedGet 0 266 857
addAll 1 266 858
assign 1 269 860
new 0 269 860
assign 1 269 861
add 1 269 861
assign 1 269 862
get 1 269 862
assign 1 270 863
def 1 270 868
assign 1 271 869
orderedGet 0 271 869
addAll 1 271 870
assign 1 274 872
new 0 274 872
assign 1 275 873
orderedGet 0 275 873
assign 1 275 874
iteratorGet 0 0 874
assign 1 275 877
hasNextGet 0 275 877
assign 1 275 879
nextGet 0 275 879
assign 1 276 880
new 1 276 880
addValue 1 276 881
assign 1 278 887
newlineGet 0 278 887
assign 1 279 888
assign 1 280 889
new 1 280 889
assign 1 282 890
copy 0 282 890
assign 1 283 891
fileGet 0 283 891
assign 1 283 892
existsGet 0 283 892
assign 1 283 893
not 0 283 898
assign 1 284 899
fileGet 0 284 899
makeDirs 0 284 900
assign 1 286 902
def 1 286 907
assign 1 287 908
new 1 287 908
assign 1 287 909
readerGet 0 287 909
assign 1 288 910
open 0 288 910
assign 1 288 911
readString 0 288 911
close 0 289 912
assign 1 295 926
classNameGet 0 295 926
assign 1 296 927
add 1 296 927
assign 1 296 928
new 0 296 928
assign 1 296 929
add 1 296 929
assign 1 296 930
toString 0 296 930
assign 1 296 931
add 1 296 931
assign 1 297 932
add 1 297 932
assign 1 297 933
new 0 297 933
assign 1 297 934
add 1 297 934
assign 1 297 935
toString 0 297 935
assign 1 297 936
add 1 297 936
return 1 298 937
assign 1 302 977
new 0 302 977
assign 1 303 978
classesGet 0 303 978
assign 1 303 979
valueIteratorGet 0 303 979
assign 1 303 982
hasNextGet 0 303 982
assign 1 304 984
nextGet 0 304 984
assign 1 305 985
shouldEmitGet 0 305 985
assign 1 305 986
heldGet 0 305 986
assign 1 305 987
fromFileGet 0 305 987
assign 1 305 988
has 1 305 988
assign 1 306 990
heldGet 0 306 990
assign 1 306 991
namepathGet 0 306 991
assign 1 306 992
toString 0 306 992
put 1 306 993
assign 1 307 994
usedByGet 0 307 994
assign 1 307 995
heldGet 0 307 995
assign 1 307 996
namepathGet 0 307 996
assign 1 307 997
toString 0 307 997
assign 1 307 998
get 1 307 998
assign 1 308 999
def 1 308 1004
assign 1 309 1005
setIteratorGet 0 0 1005
assign 1 309 1008
hasNextGet 0 309 1008
assign 1 309 1010
nextGet 0 309 1010
put 1 310 1011
assign 1 313 1018
subClassesGet 0 313 1018
assign 1 313 1019
heldGet 0 313 1019
assign 1 313 1020
namepathGet 0 313 1020
assign 1 313 1021
toString 0 313 1021
assign 1 313 1022
get 1 313 1022
assign 1 314 1023
def 1 314 1028
assign 1 315 1029
setIteratorGet 0 0 1029
assign 1 315 1032
hasNextGet 0 315 1032
assign 1 315 1034
nextGet 0 315 1034
put 1 316 1035
assign 1 321 1048
classesGet 0 321 1048
assign 1 321 1049
valueIteratorGet 0 321 1049
assign 1 321 1052
hasNextGet 0 321 1052
assign 1 322 1054
nextGet 0 322 1054
assign 1 323 1055
heldGet 0 323 1055
assign 1 323 1056
heldGet 0 323 1056
assign 1 323 1057
namepathGet 0 323 1057
assign 1 323 1058
toString 0 323 1058
assign 1 323 1059
has 1 323 1059
shouldWriteSet 1 323 1060
assign 1 330 1070
new 0 330 1070
return 1 330 1071
assign 1 334 1085
def 1 334 1090
return 1 335 1091
assign 1 340 1093
def 1 340 1098
assign 1 341 1099
firstGet 0 341 1099
assign 1 342 1100
new 0 342 1100
assign 1 342 1101
equals 1 342 1101
assign 1 343 1103
new 1 343 1103
assign 1 344 1106
new 0 344 1106
assign 1 344 1107
equals 1 344 1107
assign 1 345 1109
new 1 345 1109
assign 1 346 1112
new 0 346 1112
assign 1 346 1113
equals 1 346 1113
assign 1 347 1115
new 1 347 1115
assign 1 349 1118
new 0 349 1118
assign 1 349 1119
new 1 349 1119
throw 1 349 1120
dynConditionsAllSet 1 351 1124
return 1 352 1125
return 1 354 1127
assign 1 359 1239
new 0 359 1239
assign 1 359 1240
now 0 359 1240
assign 1 360 1241
new 0 360 1241
assign 1 361 1242
emitterGet 0 361 1242
assign 1 362 1243
def 1 362 1248
assign 1 363 1249
new 4 363 1249
put 1 364 1250
assign 1 366 1252
new 0 366 1252
assign 1 366 1253
add 1 366 1253
print 0 366 1254
assign 1 369 1257
new 0 369 1257
assign 1 371 1258
iteratorGet 0 0 1258
assign 1 371 1261
hasNextGet 0 371 1261
assign 1 371 1263
nextGet 0 371 1263
assign 1 372 1264
has 1 372 1264
assign 1 372 1265
not 0 372 1270
put 1 373 1271
assign 1 374 1272
new 2 374 1272
addValue 1 375 1273
assign 1 378 1280
iteratorGet 0 0 1280
assign 1 378 1283
hasNextGet 0 378 1283
assign 1 378 1285
nextGet 0 378 1285
assign 1 379 1286
has 1 379 1286
assign 1 379 1287
not 0 379 1292
put 1 380 1293
assign 1 381 1294
new 2 381 1294
addValue 1 382 1295
assign 1 383 1296
libNameGet 0 383 1296
put 1 383 1297
assign 1 388 1305
iteratorGet 0 388 1305
assign 1 388 1308
hasNextGet 0 388 1308
assign 1 389 1310
nextGet 0 389 1310
doParse 1 391 1311
buildSyns 1 393 1317
assign 1 396 1319
new 0 396 1319
assign 1 396 1320
now 0 396 1320
assign 1 396 1321
subtract 1 396 1321
assign 1 398 1322
new 0 398 1322
assign 1 398 1323
add 1 398 1323
print 0 398 1324
assign 1 400 1325
emitCommonGet 0 400 1325
assign 1 400 1326
def 1 400 1331
assign 1 402 1332
new 0 402 1332
assign 1 402 1333
now 0 402 1333
assign 1 403 1334
emitCommonGet 0 403 1334
doEmit 0 403 1335
assign 1 404 1336
new 0 404 1336
assign 1 404 1337
now 0 404 1337
assign 1 404 1338
subtract 1 404 1338
assign 1 405 1339
new 0 405 1339
assign 1 405 1340
add 1 405 1340
print 0 405 1341
assign 1 406 1342
new 0 406 1342
assign 1 406 1343
now 0 406 1343
assign 1 406 1344
subtract 1 406 1344
assign 1 407 1345
new 0 407 1345
assign 1 407 1346
add 1 407 1346
print 0 407 1347
assign 1 408 1348
new 0 408 1348
return 1 408 1349
setClassesToWrite 0 411 1352
libnameInfoGet 0 412 1353
assign 1 414 1354
classesGet 0 414 1354
assign 1 414 1355
valueIteratorGet 0 414 1355
assign 1 414 1358
hasNextGet 0 414 1358
assign 1 415 1360
nextGet 0 415 1360
doEmit 1 416 1361
emitMain 0 418 1367
emitCUInit 0 419 1368
assign 1 420 1369
classesGet 0 420 1369
assign 1 420 1370
valueIteratorGet 0 420 1370
assign 1 420 1373
hasNextGet 0 420 1373
assign 1 421 1375
nextGet 0 421 1375
emitSyn 1 422 1376
assign 1 426 1383
new 0 426 1383
assign 1 426 1384
now 0 426 1384
assign 1 426 1385
subtract 1 426 1385
assign 1 427 1386
def 1 427 1391
assign 1 428 1392
new 0 428 1392
assign 1 428 1393
add 1 428 1393
print 0 428 1394
assign 1 430 1396
new 0 430 1396
assign 1 430 1397
add 1 430 1397
print 0 430 1398
prepMake 1 433 1400
assign 1 437 1403
not 0 437 1408
make 1 438 1409
deployLibrary 1 439 1410
assign 1 441 1412
linkedListIteratorGet 0 0 1412
assign 1 441 1415
hasNextGet 0 441 1415
assign 1 441 1417
nextGet 0 441 1417
assign 1 442 1418
libnameInfoGet 0 442 1418
assign 1 442 1419
unitShlibGet 0 442 1419
assign 1 443 1420
emitPathGet 0 443 1420
assign 1 443 1421
copy 0 443 1421
assign 1 444 1422
stepsGet 0 444 1422
assign 1 444 1423
lastGet 0 444 1423
addStep 1 444 1424
assign 1 445 1425
fileGet 0 445 1425
assign 1 445 1426
existsGet 0 445 1426
assign 1 446 1428
fileGet 0 446 1428
delete 0 446 1429
assign 1 448 1431
fileGet 0 448 1431
assign 1 448 1432
existsGet 0 448 1432
assign 1 448 1433
not 0 448 1433
assign 1 449 1435
fileGet 0 449 1435
assign 1 449 1436
fileGet 0 449 1436
deployFile 2 449 1437
assign 1 453 1445
iteratorGet 0 453 1445
assign 1 454 1446
iteratorGet 0 454 1446
assign 1 456 1449
hasNextGet 0 456 1449
assign 1 456 1451
hasNextGet 0 456 1451
assign 1 0 1453
assign 1 0 1456
assign 1 0 1460
assign 1 457 1463
nextGet 0 457 1463
assign 1 457 1464
apNew 1 457 1464
assign 1 458 1465
emitPathGet 0 458 1465
assign 1 458 1466
copy 0 458 1466
assign 1 458 1467
toString 0 458 1467
assign 1 458 1468
new 0 458 1468
assign 1 458 1469
add 1 458 1469
assign 1 458 1470
nextGet 0 458 1470
assign 1 458 1471
add 1 458 1471
assign 1 458 1472
apNew 1 458 1472
assign 1 460 1473
fileGet 0 460 1473
assign 1 460 1474
existsGet 0 460 1474
assign 1 461 1476
fileGet 0 461 1476
delete 0 461 1477
assign 1 463 1479
fileGet 0 463 1479
assign 1 463 1480
existsGet 0 463 1480
assign 1 463 1481
not 0 463 1481
assign 1 464 1483
fileGet 0 464 1483
assign 1 464 1484
fileGet 0 464 1484
deployFile 2 464 1485
assign 1 469 1494
new 0 469 1494
assign 1 469 1495
now 0 469 1495
assign 1 469 1496
subtract 1 469 1496
assign 1 471 1497
def 1 471 1502
assign 1 472 1503
new 0 472 1503
assign 1 472 1504
add 1 472 1504
print 0 472 1505
assign 1 474 1507
def 1 474 1512
assign 1 475 1513
new 0 475 1513
assign 1 475 1514
add 1 475 1514
print 0 475 1515
assign 1 477 1517
def 1 477 1522
assign 1 478 1523
new 0 478 1523
assign 1 478 1524
add 1 478 1524
print 0 478 1525
assign 1 482 1528
new 0 482 1528
print 0 482 1529
assign 1 483 1530
run 2 483 1530
assign 1 484 1531
new 0 484 1531
assign 1 484 1532
add 1 484 1532
assign 1 484 1533
new 0 484 1533
assign 1 484 1534
add 1 484 1534
print 0 484 1535
return 1 485 1536
assign 1 487 1538
new 0 487 1538
return 1 487 1539
assign 1 491 1552
justParsedGet 0 491 1552
assign 1 491 1553
valueIteratorGet 0 491 1553
assign 1 491 1556
hasNextGet 0 491 1556
assign 1 492 1558
nextGet 0 492 1558
assign 1 493 1559
heldGet 0 493 1559
libNameSet 1 493 1560
assign 1 494 1561
getSyn 2 494 1561
libNameSet 1 495 1562
assign 1 497 1568
justParsedGet 0 497 1568
assign 1 497 1569
valueIteratorGet 0 497 1569
assign 1 497 1572
hasNextGet 0 497 1572
assign 1 498 1574
nextGet 0 498 1574
assign 1 499 1575
heldGet 0 499 1575
assign 1 499 1576
synGet 0 499 1576
checkInheritance 2 500 1577
integrate 1 501 1578
assign 1 503 1584
new 0 503 1584
justParsedSet 1 503 1585
assign 1 507 1613
heldGet 0 507 1613
assign 1 507 1614
synGet 0 507 1614
assign 1 507 1615
def 1 507 1620
assign 1 508 1621
heldGet 0 508 1621
assign 1 508 1622
synGet 0 508 1622
return 1 508 1623
assign 1 510 1625
heldGet 0 510 1625
libNameSet 1 510 1626
assign 1 511 1627
heldGet 0 511 1627
assign 1 511 1628
extendsGet 0 511 1628
assign 1 511 1629
undef 1 511 1634
assign 1 512 1635
new 1 512 1635
assign 1 514 1638
classesGet 0 514 1638
assign 1 514 1639
heldGet 0 514 1639
assign 1 514 1640
extendsGet 0 514 1640
assign 1 514 1641
toString 0 514 1641
assign 1 514 1642
get 1 514 1642
assign 1 516 1643
def 1 516 1648
assign 1 517 1649
heldGet 0 517 1649
libNameSet 1 517 1650
assign 1 518 1651
getSyn 2 518 1651
assign 1 521 1654
heldGet 0 521 1654
assign 1 521 1655
extendsGet 0 521 1655
assign 1 521 1656
loadSyn 1 521 1656
assign 1 523 1658
new 2 523 1658
assign 1 525 1660
heldGet 0 525 1660
synSet 1 525 1661
assign 1 526 1662
heldGet 0 526 1662
assign 1 526 1663
namepathGet 0 526 1663
assign 1 526 1664
toString 0 526 1664
addSynClass 2 526 1665
return 1 527 1666
assign 1 531 1674
toString 0 531 1674
assign 1 532 1675
synClassesGet 0 532 1675
assign 1 532 1676
get 1 532 1676
assign 1 533 1677
def 1 533 1682
return 1 534 1683
assign 1 540 1685
emitterGet 0 540 1685
assign 1 540 1686
loadSyn 1 540 1686
addSynClass 2 541 1687
return 1 542 1688
assign 1 549 1692
undef 1 549 1697
assign 1 550 1698
new 1 550 1698
return 1 552 1700
assign 1 557 1779
new 1 557 1779
assign 1 558 1780
new 0 558 1780
assign 1 559 1781
emitterGet 0 559 1781
assign 1 560 1782
assign 1 561 1783
new 0 561 1783
assign 1 562 1784
shouldEmitGet 0 562 1784
put 1 562 1785
assign 1 0 1788
assign 1 0 1792
assign 1 0 1795
assign 1 565 1799
new 0 565 1799
assign 1 565 1800
toString 0 565 1800
assign 1 565 1801
add 1 565 1801
print 0 565 1802
assign 1 567 1804
assign 1 569 1805
fileGet 0 569 1805
assign 1 569 1806
readerGet 0 569 1806
assign 1 569 1807
open 0 569 1807
assign 1 569 1808
readBuffer 1 569 1808
assign 1 570 1809
fileGet 0 570 1809
assign 1 570 1810
readerGet 0 570 1810
close 0 570 1811
assign 1 571 1812
tokenize 1 571 1812
assign 1 575 1814
new 0 575 1814
echo 0 575 1815
assign 1 577 1817
outermostGet 0 577 1817
nodify 2 577 1818
assign 1 579 1820
new 0 579 1820
print 0 579 1821
assign 1 580 1822
new 2 580 1822
traverse 1 580 1823
assign 1 584 1826
new 0 584 1826
echo 0 584 1827
assign 1 586 1829
new 0 586 1829
traverse 1 586 1830
assign 1 588 1832
new 0 588 1832
print 0 588 1833
assign 1 589 1834
new 2 589 1834
traverse 1 589 1835
assign 1 592 1838
new 0 592 1838
echo 0 592 1839
assign 1 595 1841
new 0 595 1841
traverse 1 595 1842
contain 0 596 1843
assign 1 598 1845
new 0 598 1845
print 0 598 1846
assign 1 599 1847
new 2 599 1847
traverse 1 599 1848
assign 1 603 1851
new 0 603 1851
echo 0 603 1852
assign 1 605 1854
new 0 605 1854
traverse 1 605 1855
assign 1 607 1857
new 0 607 1857
print 0 607 1858
assign 1 608 1859
new 2 608 1859
traverse 1 608 1860
assign 1 612 1863
new 0 612 1863
echo 0 612 1864
assign 1 614 1866
new 0 614 1866
traverse 1 614 1867
assign 1 616 1869
new 0 616 1869
print 0 616 1870
assign 1 617 1871
new 2 617 1871
traverse 1 617 1872
assign 1 621 1875
new 0 621 1875
echo 0 621 1876
assign 1 623 1878
new 0 623 1878
traverse 1 623 1879
assign 1 625 1881
new 0 625 1881
print 0 625 1882
assign 1 626 1883
new 2 626 1883
traverse 1 626 1884
assign 1 630 1887
new 0 630 1887
echo 0 630 1888
assign 1 632 1890
new 0 632 1890
traverse 1 632 1891
assign 1 634 1893
new 0 634 1893
print 0 634 1894
assign 1 635 1895
new 2 635 1895
traverse 1 635 1896
assign 1 639 1899
new 0 639 1899
echo 0 639 1900
assign 1 641 1902
new 0 641 1902
traverse 1 641 1903
assign 1 643 1905
new 0 643 1905
print 0 643 1906
assign 1 644 1907
new 2 644 1907
traverse 1 644 1908
assign 1 648 1911
new 0 648 1911
echo 0 648 1912
assign 1 650 1914
new 0 650 1914
traverse 1 650 1915
assign 1 652 1917
new 0 652 1917
print 0 652 1918
assign 1 653 1919
new 2 653 1919
traverse 1 653 1920
assign 1 657 1923
new 0 657 1923
echo 0 657 1924
assign 1 659 1926
new 0 659 1926
traverse 1 659 1927
assign 1 661 1929
new 0 661 1929
print 0 661 1930
assign 1 662 1931
new 2 662 1931
traverse 1 662 1932
assign 1 665 1935
new 0 665 1935
echo 0 665 1936
assign 1 667 1938
new 0 667 1938
traverse 1 667 1939
assign 1 669 1941
new 0 669 1941
print 0 669 1942
assign 1 670 1943
new 2 670 1943
traverse 1 670 1944
assign 1 674 1947
new 0 674 1947
echo 0 674 1948
assign 1 675 1949
new 0 675 1949
print 0 675 1950
assign 1 677 1952
new 0 677 1952
traverse 1 677 1953
assign 1 0 1955
assign 1 0 1959
assign 1 0 1962
assign 1 679 1966
new 0 679 1966
print 0 679 1967
assign 1 680 1968
new 2 680 1968
traverse 1 680 1969
assign 1 682 1971
classesGet 0 682 1971
assign 1 682 1972
valueIteratorGet 0 682 1972
assign 1 682 1975
hasNextGet 0 682 1975
assign 1 683 1977
nextGet 0 683 1977
assign 1 685 1978
transUnitGet 0 685 1978
assign 1 686 1979
new 1 686 1979
assign 1 687 1980
TRANSUNITGet 0 687 1980
typenameSet 1 687 1981
assign 1 688 1982
new 0 688 1982
assign 1 689 1983
heldGet 0 689 1983
assign 1 689 1984
emitsGet 0 689 1984
emitsSet 1 689 1985
heldSet 1 690 1986
delete 0 691 1987
addValue 1 692 1988
copyLoc 1 693 1989
reInitContained 0 699 2011
assign 1 700 2012
containedGet 0 700 2012
assign 1 701 2013
new 0 701 2013
assign 1 702 2014
new 0 702 2014
assign 1 702 2015
crGet 0 702 2015
assign 1 703 2016
linkedListIteratorGet 0 703 2016
assign 1 703 2019
hasNextGet 0 703 2019
assign 1 704 2021
new 1 704 2021
assign 1 705 2022
nextGet 0 705 2022
heldSet 1 705 2023
nlcSet 1 706 2024
assign 1 707 2025
heldGet 0 707 2025
assign 1 707 2026
equals 1 707 2026
assign 1 708 2028
increment 0 708 2028
assign 1 710 2030
heldGet 0 710 2030
assign 1 710 2031
notEquals 1 710 2031
addValue 1 711 2033
containerSet 1 712 2034
return 1 0 2044
assign 1 0 2047
return 1 0 2051
assign 1 0 2054
return 1 0 2058
assign 1 0 2061
return 1 0 2065
assign 1 0 2068
return 1 0 2072
assign 1 0 2075
return 1 0 2079
assign 1 0 2082
return 1 0 2086
assign 1 0 2089
return 1 0 2093
assign 1 0 2096
return 1 0 2100
assign 1 0 2103
return 1 0 2107
assign 1 0 2110
return 1 0 2114
assign 1 0 2117
return 1 0 2121
assign 1 0 2124
return 1 0 2128
assign 1 0 2131
return 1 0 2135
assign 1 0 2138
return 1 0 2142
assign 1 0 2145
return 1 0 2149
assign 1 0 2152
return 1 0 2156
assign 1 0 2159
return 1 0 2163
assign 1 0 2166
return 1 0 2170
assign 1 0 2173
return 1 0 2177
assign 1 0 2180
return 1 0 2184
assign 1 0 2187
return 1 0 2191
assign 1 0 2194
return 1 0 2198
assign 1 0 2201
return 1 0 2205
assign 1 0 2208
return 1 0 2212
assign 1 0 2215
return 1 0 2219
assign 1 0 2222
return 1 0 2226
assign 1 0 2229
return 1 0 2233
assign 1 0 2236
return 1 0 2240
assign 1 0 2243
return 1 0 2247
assign 1 0 2250
return 1 0 2254
assign 1 0 2257
return 1 0 2261
assign 1 0 2264
return 1 0 2268
assign 1 0 2271
return 1 0 2275
assign 1 0 2278
return 1 0 2282
assign 1 0 2285
return 1 0 2289
assign 1 0 2292
return 1 0 2296
assign 1 0 2299
return 1 0 2303
assign 1 0 2306
return 1 0 2310
assign 1 0 2313
return 1 0 2317
assign 1 0 2320
return 1 0 2324
assign 1 0 2327
return 1 0 2331
assign 1 0 2334
return 1 0 2338
assign 1 0 2341
return 1 0 2345
assign 1 0 2348
return 1 0 2352
assign 1 0 2355
return 1 0 2359
assign 1 0 2362
return 1 0 2366
assign 1 0 2369
return 1 0 2373
assign 1 0 2376
return 1 0 2380
assign 1 0 2383
return 1 0 2387
assign 1 0 2390
return 1 0 2394
assign 1 0 2397
return 1 0 2401
assign 1 0 2404
return 1 0 2408
assign 1 0 2411
return 1 0 2415
assign 1 0 2418
return 1 0 2422
assign 1 0 2425
return 1 0 2429
assign 1 0 2432
return 1 0 2436
assign 1 0 2439
return 1 0 2443
assign 1 0 2446
return 1 0 2450
assign 1 0 2453
return 1 0 2457
assign 1 0 2460
return 1 0 2464
assign 1 0 2467
return 1 0 2471
assign 1 0 2474
return 1 0 2478
assign 1 0 2481
return 1 0 2485
assign 1 0 2488
return 1 0 2492
assign 1 0 2495
return 1 0 2499
assign 1 0 2502
return 1 0 2506
assign 1 0 2509
return 1 0 2513
assign 1 0 2516
assign 1 0 2520
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1308786538: return bem_echo_0();
case -404051026: return bem_printPlacesGet_0();
case -729571811: return bem_serializeToString_0();
case -2113443821: return bem_deployLibraryGet_0();
case -34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case -340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case -580139405: return bem_config_0();
case -2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case -1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case -1803479881: return bem_libNameGet_0();
case -314718434: return bem_print_0();
case -2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case -186098742: return bem_exeNameGet_0();
case -1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case -829911139: return bem_compilerProfileGet_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case -658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case -2082855574: return bem_emitDataGet_0();
case -786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case -2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case -271866114: return bem_ownProcessGet_0();
case 443668840: return bem_methodNotDefined_0();
case -2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case -1919619119: return bem_setClassesToWrite_0();
case -2127864150: return bem_argsGet_0();
case -400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case -1003238764: return bem_parseGet_0();
case -902949587: return bem_printStepsGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 268778355: return bem_emitFlagsGet_0();
case -1505775346: return bem_putLineNumbersInTraceGet_0();
case -1713520961: return bem_linkLibArgsGet_0();
case -1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case -644675716: return bem_ntypesGet_0();
case -1185503219: return bem_deployFilesFromGet_0();
case -1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case -1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case -560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case -733055122: return bem_makeNameGet_0();
case -328200718: return bem_printAstGet_0();
case -126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case -1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case -1458327669: return bem_emitFileHeaderGet_0();
case -1220511308: return bem_buildSucceededGet_0();
case -845792839: return bem_iteratorGet_0();
case -1149621350: return bem_codeGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -505952126: return bem_copyTo_1(bevd_0);
case -392968773: return bem_printPlacesSet_1(bevd_0);
case -2071773321: return bem_emitDataSet_1(bevd_0);
case -1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case -1702438708: return bem_linkLibArgsSet_1(bevd_0);
case -891867334: return bem_printStepsSet_1(bevd_0);
case -647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -721972869: return bem_makeNameSet_1(bevd_0);
case -175016489: return bem_exeNameSet_1(bevd_0);
case -972018826: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case -2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case -1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case -115429536: return bem_outputPlatformSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case -818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case -1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1094759839: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case -706249818: return bem_getSynNp_1(bevd_0);
case -1310359934: return bem_emitLangsSet_1(bevd_0);
case -329197947: return bem_startTimeSet_1(bevd_0);
case -1792397628: return bem_libNameSet_1(bevd_0);
case -549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case -1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case -1174420966: return bem_deployFilesFromSet_1(bevd_0);
case -389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case -2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case -1138539097: return bem_codeSet_1(bevd_0);
case -23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case -2036609109: return bem_buildSyns_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 279860608: return bem_emitFlagsSet_1(bevd_0);
case -992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case -1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case -260783861: return bem_ownProcessSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case -1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case -2116781897: return bem_argsSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1081571541: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 593264218: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case -2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildBuild.bevs_inst = (BEC_2_5_5_BuildBuild)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildBuild.bevs_inst;
}
}
