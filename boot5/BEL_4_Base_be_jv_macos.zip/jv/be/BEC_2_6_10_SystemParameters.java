package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x0D,0x0A};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(3));
private static byte[] bels_1 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_1, 2));
private static BEC_2_4_3_MathInt bevo_10 = (new BEC_2_4_3_MathInt(2));
private static byte[] bels_2 = {0x2D};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_2, 1));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_3 = {0x3D};
private static BEC_2_4_6_TextString bevo_13 = (new BEC_2_4_6_TextString(bels_3, 1));
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_4 = {0x23,0x2D,0x2D};
private static BEC_2_4_6_TextString bevo_16 = (new BEC_2_4_6_TextString(bels_4, 3));
private static BEC_2_4_3_MathInt bevo_17 = (new BEC_2_4_3_MathInt(3));
private static byte[] bels_5 = {0x23};
private static BEC_2_4_6_TextString bevo_18 = (new BEC_2_4_6_TextString(bels_5, 1));
public static BEC_2_6_10_SystemParameters bevs_inst;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public BEC_2_6_10_SystemParameters bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_0));
bevp_fileTok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
this.bem_new_0();
this.bem_addArgs_1(beva__args);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
if (bevp_preProcessor == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevl_ii = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 127 */ {
bevt_7_tmpany_phold = beva__args.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_6_tmpany_phold = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 127 */ {
bevt_9_tmpany_phold = beva__args.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_ii);
bevt_8_tmpany_phold = bevp_preProcessor.bemd_1(-1094759839, BEL_4_Base.bevn_process_1, bevt_9_tmpany_phold);
beva__args.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_ii, bevt_8_tmpany_phold);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 127 */
 else  /* Line: 127 */ {
break;
} /* Line: 127 */
} /* Line: 127 */
} /* Line: 127 */
if (bevp_args == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevp_args = (BEC_2_9_4_ContainerList) beva__args;
bevp_params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (new BEC_2_9_4_ContainerList()).bem_new_0();
} /* Line: 134 */
 else  /* Line: 135 */ {
bevp_args = bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args);
} /* Line: 136 */
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_loop = beva__args.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 140 */ {
bevt_11_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_13_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_14_tmpany_phold = bevo_0;
if (bevt_13_tmpany_phold.bevi_int > bevt_14_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 144 */ {
bevt_15_tmpany_phold = bevo_1;
bevt_16_tmpany_phold = bevo_2;
bevl_fa = bevl_i.bem_substring_2(bevt_15_tmpany_phold, bevt_16_tmpany_phold);
bevt_18_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_19_tmpany_phold = bevo_3;
if (bevt_18_tmpany_phold.bevi_int > bevt_19_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 146 */ {
bevt_20_tmpany_phold = bevo_4;
bevt_21_tmpany_phold = bevo_5;
bevl_fb = bevl_i.bem_substring_2(bevt_20_tmpany_phold, bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_24_tmpany_phold = bevo_6;
if (bevt_23_tmpany_phold.bevi_int > bevt_24_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevt_25_tmpany_phold = bevo_7;
bevt_26_tmpany_phold = bevo_8;
bevl_fc = bevl_i.bem_substring_2(bevt_25_tmpany_phold, bevt_26_tmpany_phold);
} /* Line: 149 */
} /* Line: 148 */
} /* Line: 146 */
if (bevl_pname == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 153 */ {
if (bevl_pnameComment.bevi_bool) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 154 */ {
this.bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 155 */
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
} /* Line: 158 */
 else  /* Line: 153 */ {
if (bevl_fb == null) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 159 */ {
bevt_31_tmpany_phold = bevo_9;
bevt_30_tmpany_phold = bevl_fb.bem_equals_1(bevt_31_tmpany_phold);
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 159 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 159 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 159 */
 else  /* Line: 159 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 159 */ {
bevt_32_tmpany_phold = bevo_10;
bevt_33_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
} /* Line: 160 */
 else  /* Line: 153 */ {
if (bevl_fa == null) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevt_36_tmpany_phold = bevo_11;
bevt_35_tmpany_phold = bevl_fa.bem_equals_1(bevt_36_tmpany_phold);
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 161 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 161 */
 else  /* Line: 161 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 161 */ {
bevt_37_tmpany_phold = bevo_12;
bevt_38_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_37_tmpany_phold, bevt_38_tmpany_phold);
bevt_39_tmpany_phold = bevo_13;
bevl_pos = bevl_par.bem_find_1(bevt_39_tmpany_phold);
if (bevl_pos == null) {
bevt_40_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 164 */ {
bevt_41_tmpany_phold = bevo_14;
bevl_key = bevl_par.bem_substring_2(bevt_41_tmpany_phold, bevl_pos);
bevt_43_tmpany_phold = bevo_15;
bevt_42_tmpany_phold = bevl_pos.bem_add_1(bevt_43_tmpany_phold);
bevl_value = bevl_par.bem_substring_1(bevt_42_tmpany_phold);
this.bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 167 */
} /* Line: 164 */
 else  /* Line: 153 */ {
if (bevl_fc == null) {
bevt_44_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_46_tmpany_phold = bevo_16;
bevt_45_tmpany_phold = bevl_fc.bem_equals_1(bevt_46_tmpany_phold);
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 169 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 169 */
 else  /* Line: 169 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 169 */ {
bevt_47_tmpany_phold = bevo_17;
bevt_48_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevl_pnameComment = be.BECS_Runtime.boolTrue;
} /* Line: 171 */
 else  /* Line: 153 */ {
if (bevl_fa == null) {
bevt_49_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_49_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevt_51_tmpany_phold = bevo_18;
bevt_50_tmpany_phold = bevl_fa.bem_equals_1(bevt_51_tmpany_phold);
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 172 */
 else  /* Line: 172 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 173 */
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
 else  /* Line: 140 */ {
break;
} /* Line: 140 */
} /* Line: 140 */
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 180 */ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 181 */ {
bevt_3_tmpany_phold = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 181 */ {
bevt_5_tmpany_phold = bevp_args.bem_get_1(bevl_i);
bevt_4_tmpany_phold = bevp_preProcessor.bemd_1(-1094759839, BEL_4_Base.bevn_process_1, bevt_5_tmpany_phold);
bevp_args.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 181 */
 else  /* Line: 181 */ {
break;
} /* Line: 181 */
} /* Line: 181 */
} /* Line: 181 */
if (bevp_ordered == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 185 */ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 186 */ {
bevt_8_tmpany_phold = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_10_tmpany_phold = bevp_ordered.bem_get_1(bevl_i);
bevt_9_tmpany_phold = bevp_preProcessor.bemd_1(-1094759839, BEL_4_Base.bevn_process_1, bevt_10_tmpany_phold);
bevp_ordered.bem_put_2(bevl_i, bevt_9_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 186 */
 else  /* Line: 186 */ {
break;
} /* Line: 186 */
} /* Line: 186 */
} /* Line: 186 */
if (bevp_params == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevl__params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
 /* Line: 192 */ {
bevt_12_tmpany_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 192 */ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpany_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 196 */ {
bevt_13_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpany_phold).bevi_bool) /* Line: 196 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevt_14_tmpany_phold = bevp_preProcessor.bemd_1(-1094759839, BEL_4_Base.bevn_process_1, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_tmpany_phold);
} /* Line: 197 */
 else  /* Line: 196 */ {
break;
} /* Line: 196 */
} /* Line: 196 */
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(-1094759839, BEL_4_Base.bevn_process_1, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 200 */
 else  /* Line: 192 */ {
break;
} /* Line: 192 */
} /* Line: 192 */
bevp_params = bevl__params;
} /* Line: 202 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_res = this.bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 208 */ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 210 */
return beva_isit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = this.bem_isTrue_2(beva_name, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_has_1(beva_name);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 230 */ {
bevl_pl = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 232 */
return bevl_pl;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_getFirst_2(beva_name, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 243 */ {
return beva_default;
} /* Line: 244 */
bevt_1_tmpany_phold = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 252 */ {
bevl_vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 254 */
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) throws Throwable {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = beva_file.bem_readerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_fcontents = bevt_0_tmpany_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_2_tmpany_phold = beva_file.bem_readerGet_0();
bevt_2_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevt_3_tmpany_phold = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_tmpany_phold.bemd_0(-1987444950, BEL_4_Base.bevn_toList_0);
this.bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_orderedGet_0() throws Throwable {
return bevp_ordered;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_fileTokGet_0() throws Throwable {
return bevp_fileTok;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_preProcessorGet_0() throws Throwable {
return bevp_preProcessor;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {114, 114, 121, 122, 126, 126, 127, 127, 127, 128, 128, 128, 127, 131, 131, 132, 133, 134, 136, 138, 139, 140, 0, 140, 140, 141, 142, 143, 144, 144, 144, 144, 145, 145, 145, 146, 146, 146, 146, 147, 147, 147, 148, 148, 148, 148, 149, 149, 149, 153, 153, 154, 154, 155, 157, 158, 159, 159, 159, 159, 0, 0, 0, 160, 160, 160, 161, 161, 161, 161, 0, 0, 0, 162, 162, 162, 163, 163, 164, 164, 165, 165, 166, 166, 166, 167, 169, 169, 169, 169, 0, 0, 0, 170, 170, 170, 171, 172, 172, 172, 172, 0, 0, 0, 172, 172, 173, 179, 180, 180, 181, 181, 181, 181, 182, 182, 182, 181, 185, 185, 186, 186, 186, 186, 187, 187, 187, 186, 190, 190, 191, 192, 192, 193, 194, 195, 196, 0, 196, 196, 197, 197, 199, 200, 202, 207, 208, 208, 210, 213, 217, 217, 217, 221, 221, 225, 225, 229, 230, 230, 231, 232, 234, 238, 238, 242, 243, 243, 244, 246, 246, 251, 252, 252, 253, 254, 256, 260, 260, 260, 261, 261, 262, 262, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {40, 41, 45, 46, 114, 119, 120, 123, 124, 126, 127, 128, 129, 136, 141, 142, 143, 144, 147, 149, 150, 151, 151, 154, 156, 157, 158, 159, 160, 161, 162, 167, 168, 169, 170, 171, 172, 173, 178, 179, 180, 181, 182, 183, 184, 189, 190, 191, 192, 196, 201, 202, 207, 208, 210, 211, 214, 219, 220, 221, 223, 226, 230, 233, 234, 235, 238, 243, 244, 245, 247, 250, 254, 257, 258, 259, 260, 261, 262, 267, 268, 269, 270, 271, 272, 273, 277, 282, 283, 284, 286, 289, 293, 296, 297, 298, 299, 302, 307, 308, 309, 311, 314, 318, 320, 325, 326, 362, 363, 368, 369, 372, 373, 378, 379, 380, 381, 382, 389, 394, 395, 398, 399, 404, 405, 406, 407, 408, 415, 420, 421, 422, 425, 427, 428, 429, 430, 430, 433, 435, 436, 437, 443, 444, 450, 457, 458, 463, 464, 466, 471, 472, 473, 477, 478, 482, 483, 488, 489, 494, 495, 496, 498, 502, 503, 509, 510, 515, 516, 518, 519, 524, 525, 530, 531, 532, 534, 544, 545, 546, 547, 548, 549, 550, 551, 555, 558, 562, 565, 569, 572, 576, 579, 583};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 114 40
new 0 114 40
assign 1 114 41
new 1 114 41
new 0 121 45
addArgs 1 122 46
assign 1 126 114
def 1 126 119
assign 1 127 120
new 0 127 120
assign 1 127 123
lengthGet 0 127 123
assign 1 127 124
lesser 1 127 124
assign 1 128 126
get 1 128 126
assign 1 128 127
process 1 128 127
put 2 128 128
assign 1 127 129
increment 0 127 129
assign 1 131 136
undef 1 131 141
assign 1 132 142
assign 1 133 143
new 0 133 143
assign 1 134 144
new 0 134 144
assign 1 136 147
add 1 136 147
assign 1 138 149
assign 1 139 150
new 0 139 150
assign 1 140 151
iteratorGet 0 0 151
assign 1 140 154
hasNextGet 0 140 154
assign 1 140 156
nextGet 0 140 156
assign 1 141 157
assign 1 142 158
assign 1 143 159
assign 1 144 160
sizeGet 0 144 160
assign 1 144 161
new 0 144 161
assign 1 144 162
greater 1 144 167
assign 1 145 168
new 0 145 168
assign 1 145 169
new 0 145 169
assign 1 145 170
substring 2 145 170
assign 1 146 171
sizeGet 0 146 171
assign 1 146 172
new 0 146 172
assign 1 146 173
greater 1 146 178
assign 1 147 179
new 0 147 179
assign 1 147 180
new 0 147 180
assign 1 147 181
substring 2 147 181
assign 1 148 182
sizeGet 0 148 182
assign 1 148 183
new 0 148 183
assign 1 148 184
greater 1 148 189
assign 1 149 190
new 0 149 190
assign 1 149 191
new 0 149 191
assign 1 149 192
substring 2 149 192
assign 1 153 196
def 1 153 201
assign 1 154 202
not 0 154 207
addParameter 2 155 208
assign 1 157 210
assign 1 158 211
new 0 158 211
assign 1 159 214
def 1 159 219
assign 1 159 220
new 0 159 220
assign 1 159 221
equals 1 159 221
assign 1 0 223
assign 1 0 226
assign 1 0 230
assign 1 160 233
new 0 160 233
assign 1 160 234
sizeGet 0 160 234
assign 1 160 235
substring 2 160 235
assign 1 161 238
def 1 161 243
assign 1 161 244
new 0 161 244
assign 1 161 245
equals 1 161 245
assign 1 0 247
assign 1 0 250
assign 1 0 254
assign 1 162 257
new 0 162 257
assign 1 162 258
sizeGet 0 162 258
assign 1 162 259
substring 2 162 259
assign 1 163 260
new 0 163 260
assign 1 163 261
find 1 163 261
assign 1 164 262
def 1 164 267
assign 1 165 268
new 0 165 268
assign 1 165 269
substring 2 165 269
assign 1 166 270
new 0 166 270
assign 1 166 271
add 1 166 271
assign 1 166 272
substring 1 166 272
addParameter 2 167 273
assign 1 169 277
def 1 169 282
assign 1 169 283
new 0 169 283
assign 1 169 284
equals 1 169 284
assign 1 0 286
assign 1 0 289
assign 1 0 293
assign 1 170 296
new 0 170 296
assign 1 170 297
sizeGet 0 170 297
assign 1 170 298
substring 2 170 298
assign 1 171 299
new 0 171 299
assign 1 172 302
def 1 172 307
assign 1 172 308
new 0 172 308
assign 1 172 309
equals 1 172 309
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 172 320
not 0 172 325
addValue 1 173 326
assign 1 179 362
assign 1 180 363
def 1 180 368
assign 1 181 369
new 0 181 369
assign 1 181 372
lengthGet 0 181 372
assign 1 181 373
lesser 1 181 378
assign 1 182 379
get 1 182 379
assign 1 182 380
process 1 182 380
put 2 182 381
assign 1 181 382
increment 0 181 382
assign 1 185 389
def 1 185 394
assign 1 186 395
new 0 186 395
assign 1 186 398
lengthGet 0 186 398
assign 1 186 399
lesser 1 186 404
assign 1 187 405
get 1 187 405
assign 1 187 406
process 1 187 406
put 2 187 407
assign 1 186 408
increment 0 186 408
assign 1 190 415
def 1 190 420
assign 1 191 421
new 0 191 421
assign 1 192 422
keyIteratorGet 0 192 422
assign 1 192 425
hasNextGet 0 192 425
assign 1 193 427
nextGet 0 193 427
assign 1 194 428
get 1 194 428
assign 1 195 429
new 0 195 429
assign 1 196 430
linkedListIteratorGet 0 0 430
assign 1 196 433
hasNextGet 0 196 433
assign 1 196 435
nextGet 0 196 435
assign 1 197 436
process 1 197 436
addValue 1 197 437
assign 1 199 443
process 1 199 443
put 2 200 444
assign 1 202 450
assign 1 207 457
getFirst 1 207 457
assign 1 208 458
def 1 208 463
assign 1 210 464
new 1 210 464
return 1 213 466
assign 1 217 471
new 0 217 471
assign 1 217 472
isTrue 2 217 472
return 1 217 473
assign 1 221 477
has 1 221 477
return 1 221 478
assign 1 225 482
get 1 225 482
return 1 225 483
assign 1 229 488
get 1 229 488
assign 1 230 489
undef 1 230 494
assign 1 231 495
new 0 231 495
addValue 1 232 496
return 1 234 498
assign 1 238 502
getFirst 2 238 502
return 1 238 503
assign 1 242 509
get 1 242 509
assign 1 243 510
undef 1 243 515
return 1 244 516
assign 1 246 518
firstGet 0 246 518
return 1 246 519
assign 1 251 524
get 1 251 524
assign 1 252 525
undef 1 252 530
assign 1 253 531
new 0 253 531
put 2 254 532
addValue 1 256 534
assign 1 260 544
readerGet 0 260 544
assign 1 260 545
open 0 260 545
assign 1 260 546
readString 0 260 546
assign 1 261 547
readerGet 0 261 547
close 0 261 548
assign 1 262 549
tokenize 1 262 549
assign 1 262 550
toList 0 262 550
addArgs 1 263 551
return 1 0 555
assign 1 0 558
return 1 0 562
assign 1 0 565
return 1 0 569
assign 1 0 572
return 1 0 576
assign 1 0 579
return 1 0 583
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 1695168417: return bem_paramsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1600549146: return bem_orderedGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1895160755: return bem_fileTokGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case -2127864150: return bem_argsGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 1128894872: return bem_preProcessorGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 99049420: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case 187837996: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1139977125: return bem_preProcessorSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 98246024: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1611631399: return bem_orderedSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1906243008: return bem_fileTokSet_1(bevd_0);
case -2116781897: return bem_argsSet_1(bevd_0);
case -516636336: return bem_addArgs_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -381666769: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
case -191084662: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 187837997: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 98246025: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1957079483: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -191084661: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemParameters.bevs_inst = (BEC_2_6_10_SystemParameters)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemParameters.bevs_inst;
}
}
