package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_3_BuildVar extends BEC_2_6_6_SystemObject {
public BEC_2_5_3_BuildVar() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(-1));
private static byte[] bels_0 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_0, 7));
private static byte[] bels_1 = {0x20,0x69,0x73,0x41,0x72,0x67};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_1, 6));
private static byte[] bels_2 = {0x20,0x69,0x73,0x54,0x6D,0x70,0x56,0x61,0x72};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_2, 9));
private static byte[] bels_3 = {0x20,0x6E,0x6F,0x74,0x44,0x65,0x63,0x6C,0x61,0x72,0x65,0x64};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_3, 12));
private static byte[] bels_4 = {0x20,0x69,0x73,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_4, 11));
public static BEC_2_5_3_BuildVar bevs_inst;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_6_6_SystemObject bevp_refs;
public BEC_2_9_3_ContainerSet bevp_allCalls;
public BEC_2_4_6_TextString bevp_suffix;
public BEC_2_5_4_LogicBool bevp_isArg;
public BEC_2_5_4_LogicBool bevp_isAdded;
public BEC_2_5_4_LogicBool bevp_isTmpVar;
public BEC_2_5_4_LogicBool bevp_isDeclared;
public BEC_2_5_4_LogicBool bevp_isProperty;
public BEC_2_4_3_MathInt bevp_numAssigns;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_4_3_MathInt bevp_vpos;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_4_3_MathInt bevp_maxCpos;
public BEC_2_4_3_MathInt bevp_minCpos;
public BEC_2_4_6_TextString bevp_nativeName;
public BEC_2_5_3_BuildVar bem_new_0() throws Throwable {
BEC_2_4_4_MathInts bevt_0_tmpany_phold = null;
bevp_isArg = be.BECS_Runtime.boolFalse;
bevp_isAdded = be.BECS_Runtime.boolFalse;
bevp_isTmpVar = be.BECS_Runtime.boolFalse;
bevp_isDeclared = be.BECS_Runtime.boolTrue;
bevp_isProperty = be.BECS_Runtime.boolFalse;
bevp_numAssigns = (new BEC_2_4_3_MathInt(0));
bevp_isTyped = be.BECS_Runtime.boolFalse;
bevp_vpos = (new BEC_2_4_3_MathInt(-1));
bevp_isSelf = be.BECS_Runtime.boolFalse;
bevp_maxCpos = (new BEC_2_4_3_MathInt(-1));
bevt_0_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bevs_inst;
bevp_minCpos = bevt_0_tmpany_phold.bem_maxGet_0();
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_synNew_1(BEC_2_5_3_BuildVar beva_full) throws Throwable {
bevp_isArg = beva_full.bem_isArgGet_0();
bevp_name = beva_full.bem_nameGet_0();
bevp_isAdded = beva_full.bem_isAddedGet_0();
bevp_isTmpVar = beva_full.bem_isTmpVarGet_0();
bevp_isProperty = beva_full.bem_isPropertyGet_0();
bevp_numAssigns = (new BEC_2_4_3_MathInt(0));
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_vpos = beva_full.bem_vposGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addCall_1(BEC_2_5_4_BuildNode beva_call) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_allCalls == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevp_allCalls = (new BEC_2_9_3_ContainerSet()).bem_new_0();
} /* Line: 236 */
bevp_allCalls.bem_addValue_1(beva_call);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxCposGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_0;
if (bevp_maxCpos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 242 */ {
return bevp_maxCpos;
} /* Line: 242 */
bevt_0_tmpany_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
 /* Line: 243 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevl_n = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_6_tmpany_phold = bevl_n.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-2128364298, BEL_4_Base.bevn_cposGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevp_maxCpos);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpany_phold).bevi_bool) /* Line: 244 */ {
bevt_7_tmpany_phold = bevl_n.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bemd_0(-2128364298, BEL_4_Base.bevn_cposGet_0);
} /* Line: 245 */
} /* Line: 244 */
 else  /* Line: 243 */ {
break;
} /* Line: 243 */
} /* Line: 243 */
return bevp_maxCpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_minCposGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_bigun = null;
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_4_4_MathInts bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bevs_inst;
bevl_bigun = bevt_1_tmpany_phold.bem_maxGet_0();
if (bevp_minCpos.bevi_int < bevl_bigun.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 254 */ {
return bevp_minCpos;
} /* Line: 254 */
bevt_0_tmpany_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
 /* Line: 255 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevl_n = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_6_tmpany_phold = bevl_n.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-2128364298, BEL_4_Base.bevn_cposGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevp_minCpos);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpany_phold).bevi_bool) /* Line: 256 */ {
bevt_7_tmpany_phold = bevl_n.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bemd_0(-2128364298, BEL_4_Base.bevn_cposGet_0);
} /* Line: 257 */
} /* Line: 256 */
 else  /* Line: 255 */ {
break;
} /* Line: 255 */
} /* Line: 255 */
return bevp_minCpos;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_ret = this.bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 265 */ {
bevt_2_tmpany_phold = bevo_1;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 266 */
if (bevp_isArg.bevi_bool) /* Line: 268 */ {
bevt_4_tmpany_phold = bevo_2;
bevl_ret = bevl_ret.bem_add_1(bevt_4_tmpany_phold);
} /* Line: 269 */
if (bevp_isTmpVar.bevi_bool) /* Line: 271 */ {
bevt_5_tmpany_phold = bevo_3;
bevl_ret = bevl_ret.bem_add_1(bevt_5_tmpany_phold);
} /* Line: 272 */
if (bevp_isDeclared.bevi_bool) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 274 */ {
bevt_7_tmpany_phold = bevo_4;
bevl_ret = bevl_ret.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 275 */
if (bevp_isProperty.bevi_bool) /* Line: 277 */ {
bevt_8_tmpany_phold = bevo_5;
bevl_ret = bevl_ret.bem_add_1(bevt_8_tmpany_phold);
} /* Line: 278 */
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_refsGet_0() throws Throwable {
return bevp_refs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_refsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_refs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_allCallsGet_0() throws Throwable {
return bevp_allCalls;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allCallsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allCalls = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_suffixGet_0() throws Throwable {
return bevp_suffix;
} /*method end*/
public BEC_2_6_6_SystemObject bem_suffixSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_suffix = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isArgGet_0() throws Throwable {
return bevp_isArg;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isArgSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isArg = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAddedGet_0() throws Throwable {
return bevp_isAdded;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTmpVarGet_0() throws Throwable {
return bevp_isTmpVar;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isTmpVarSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isTmpVar = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDeclaredGet_0() throws Throwable {
return bevp_isDeclared;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isDeclaredSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isDeclared = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isPropertyGet_0() throws Throwable {
return bevp_isProperty;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isPropertySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isProperty = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numAssignsGet_0() throws Throwable {
return bevp_numAssigns;
} /*method end*/
public BEC_2_6_6_SystemObject bem_numAssignsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_numAssigns = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() throws Throwable {
return bevp_isTyped;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vposGet_0() throws Throwable {
return bevp_vpos;
} /*method end*/
public BEC_2_6_6_SystemObject bem_vposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() throws Throwable {
return bevp_isSelf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_maxCposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_minCposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nativeNameGet_0() throws Throwable {
return bevp_nativeName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nativeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nativeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 215, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 235, 235, 236, 238, 242, 242, 242, 242, 243, 0, 243, 243, 244, 244, 244, 245, 245, 248, 252, 252, 254, 254, 254, 255, 0, 255, 255, 256, 256, 256, 257, 257, 260, 264, 265, 265, 266, 266, 266, 266, 269, 269, 272, 272, 274, 274, 275, 275, 278, 278, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 67, 72, 73, 75, 88, 89, 94, 95, 97, 97, 100, 102, 103, 104, 105, 107, 108, 115, 128, 129, 130, 135, 136, 138, 138, 141, 143, 144, 145, 146, 148, 149, 156, 169, 170, 175, 176, 177, 178, 179, 182, 183, 186, 187, 189, 194, 195, 196, 199, 200, 202, 205, 208, 212, 215, 219, 222, 226, 229, 233, 236, 240, 243, 247, 250, 254, 257, 261, 264, 268, 271, 275, 278, 282, 285, 289, 292, 296, 299, 303, 307, 311, 314};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 205 38
new 0 205 38
assign 1 206 39
new 0 206 39
assign 1 207 40
new 0 207 40
assign 1 208 41
new 0 208 41
assign 1 209 42
new 0 209 42
assign 1 210 43
new 0 210 43
assign 1 211 44
new 0 211 44
assign 1 212 45
new 0 212 45
assign 1 213 46
new 0 213 46
assign 1 214 47
new 0 214 47
assign 1 215 48
new 0 215 48
assign 1 215 49
maxGet 0 215 49
assign 1 222 53
isArgGet 0 222 53
assign 1 223 54
nameGet 0 223 54
assign 1 224 55
isAddedGet 0 224 55
assign 1 225 56
isTmpVarGet 0 225 56
assign 1 226 57
isPropertyGet 0 226 57
assign 1 227 58
new 0 227 58
assign 1 228 59
namepathGet 0 228 59
assign 1 229 60
isTypedGet 0 229 60
assign 1 230 61
vposGet 0 230 61
assign 1 231 62
isSelfGet 0 231 62
assign 1 235 67
undef 1 235 72
assign 1 236 73
new 0 236 73
addValue 1 238 75
assign 1 242 88
new 0 242 88
assign 1 242 89
greater 1 242 94
return 1 242 95
assign 1 243 97
setIteratorGet 0 0 97
assign 1 243 100
hasNextGet 0 243 100
assign 1 243 102
nextGet 0 243 102
assign 1 244 103
heldGet 0 244 103
assign 1 244 104
cposGet 0 244 104
assign 1 244 105
greater 1 244 105
assign 1 245 107
heldGet 0 245 107
assign 1 245 108
cposGet 0 245 108
return 1 248 115
assign 1 252 128
new 0 252 128
assign 1 252 129
maxGet 0 252 129
assign 1 254 130
lesser 1 254 135
return 1 254 136
assign 1 255 138
setIteratorGet 0 0 138
assign 1 255 141
hasNextGet 0 255 141
assign 1 255 143
nextGet 0 255 143
assign 1 256 144
heldGet 0 256 144
assign 1 256 145
cposGet 0 256 145
assign 1 256 146
lesser 1 256 146
assign 1 257 148
heldGet 0 257 148
assign 1 257 149
cposGet 0 257 149
return 1 260 156
assign 1 264 169
classNameGet 0 264 169
assign 1 265 170
def 1 265 175
assign 1 266 176
new 0 266 176
assign 1 266 177
add 1 266 177
assign 1 266 178
toString 0 266 178
assign 1 266 179
add 1 266 179
assign 1 269 182
new 0 269 182
assign 1 269 183
add 1 269 183
assign 1 272 186
new 0 272 186
assign 1 272 187
add 1 272 187
assign 1 274 189
not 0 274 194
assign 1 275 195
new 0 275 195
assign 1 275 196
add 1 275 196
assign 1 278 199
new 0 278 199
assign 1 278 200
add 1 278 200
return 1 280 202
return 1 0 205
assign 1 0 208
return 1 0 212
assign 1 0 215
return 1 0 219
assign 1 0 222
return 1 0 226
assign 1 0 229
return 1 0 233
assign 1 0 236
return 1 0 240
assign 1 0 243
return 1 0 247
assign 1 0 250
return 1 0 254
assign 1 0 257
return 1 0 261
assign 1 0 264
return 1 0 268
assign 1 0 271
return 1 0 275
assign 1 0 278
return 1 0 282
assign 1 0 285
return 1 0 289
assign 1 0 292
return 1 0 296
assign 1 0 299
assign 1 0 303
assign 1 0 307
return 1 0 311
assign 1 0 314
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 781552485: return bem_nativeNameGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 495053105: return bem_isAddedGet_0();
case 1774940957: return bem_toString_0();
case -1354714650: return bem_copy_0();
case 354142775: return bem_namepathGet_0();
case 1126433704: return bem_isPropertyGet_0();
case -1135771315: return bem_isTmpVarGet_0();
case -1308786538: return bem_echo_0();
case 1193313287: return bem_isTypedGet_0();
case -729571811: return bem_serializeToString_0();
case 389100841: return bem_numAssignsGet_0();
case 1454846051: return bem_isDeclaredGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 2024716595: return bem_allCallsGet_0();
case -535212143: return bem_isSelfGet_0();
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case -2110260727: return bem_vposGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1211273660: return bem_nameGet_0();
case -1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case -1081412016: return bem_many_0();
case -564053209: return bem_refsGet_0();
case 443668840: return bem_methodNotDefined_0();
case 743311346: return bem_maxCposGet_0();
case -2104155978: return bem_suffixGet_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 1869307931: return bem_isArgGet_0();
case -845792839: return bem_iteratorGet_0();
case -314718434: return bem_print_0();
case 1217737412: return bem_minCposGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1797856106: return bem_synNew_1((BEC_2_5_3_BuildVar) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 792634738: return bem_nativeNameSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -2099178474: return bem_vposSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 506135358: return bem_isAddedSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case -552970956: return bem_refsSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1124689062: return bem_isTmpVarSet_1(bevd_0);
case 754393599: return bem_maxCposSet_1(bevd_0);
case 1137515957: return bem_isPropertySet_1(bevd_0);
case -2093073725: return bem_suffixSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1880390184: return bem_isArgSet_1(bevd_0);
case 1204395540: return bem_isTypedSet_1(bevd_0);
case 400183094: return bem_numAssignsSet_1(bevd_0);
case 1465928304: return bem_isDeclaredSet_1(bevd_0);
case -524129890: return bem_isSelfSet_1(bevd_0);
case -474935663: return bem_addCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1228819665: return bem_minCposSet_1(bevd_0);
case 2035798848: return bem_allCallsSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_3_BuildVar();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_3_BuildVar.bevs_inst = (BEC_2_5_3_BuildVar)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_3_BuildVar.bevs_inst;
}
}
