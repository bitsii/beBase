package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_3_6_6_12_SystemThreadObjectLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_12_SystemThreadObjectLocker() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_12_SystemThreadObjectLocker bevs_inst;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_obj;
public BEC_3_6_6_12_SystemThreadObjectLocker bem_new_0() throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_new_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
this.bem_new_0();
bevp_lock.bem_lock_0();
try  /* Line: 1136 */ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1138 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1141 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_oGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1147 */ {
bevl_r = bevp_obj;
bevp_lock.bem_unlock_0();
} /* Line: 1149 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1152 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1159 */ {
bevl_r = bevp_obj;
bevp_obj = null;
bevp_lock.bem_unlock_0();
} /* Line: 1162 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1165 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_setIfClear_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_5_4_LogicBool bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
bevl_res = be.BECS_Runtime.boolFalse;
try  /* Line: 1173 */ {
if (bevp_obj == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1174 */ {
bevp_obj = beva__obj;
bevl_res = be.BECS_Runtime.boolTrue;
} /* Line: 1176 */
bevp_lock.bem_unlock_0();
} /* Line: 1178 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1181 */
return bevl_res;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_oSet_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1188 */ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1190 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1193 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objectGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_oGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objectSet_1(BEC_2_6_6_SystemObject beva__obj) throws Throwable {
BEC_3_6_6_12_SystemThreadObjectLocker bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_oSet_1(beva__obj);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objGet_0() throws Throwable {
return bevp_obj;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_objSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_obj = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1126, 1131, 1135, 1137, 1138, 1140, 1141, 1146, 1148, 1149, 1151, 1152, 1154, 1158, 1160, 1161, 1162, 1164, 1165, 1167, 1171, 1172, 1174, 1174, 1175, 1176, 1178, 1180, 1181, 1183, 1187, 1189, 1190, 1192, 1193, 1198, 1198, 1202, 1202, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 18, 19, 21, 22, 26, 27, 34, 36, 37, 41, 42, 44, 49, 51, 52, 53, 57, 58, 60, 66, 67, 69, 74, 75, 76, 78, 82, 83, 85, 89, 91, 92, 96, 97, 103, 104, 108, 109, 112, 115, 119, 122};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1126 13
new 0 1126 13
new 0 1131 18
lock 0 1135 19
assign 1 1137 21
unlock 0 1138 22
unlock 0 1140 26
throw 1 1141 27
lock 0 1146 34
assign 1 1148 36
unlock 0 1149 37
unlock 0 1151 41
throw 1 1152 42
return 1 1154 44
lock 0 1158 49
assign 1 1160 51
assign 1 1161 52
unlock 0 1162 53
unlock 0 1164 57
throw 1 1165 58
return 1 1167 60
lock 0 1171 66
assign 1 1172 67
new 0 1172 67
assign 1 1174 69
undef 1 1174 74
assign 1 1175 75
assign 1 1176 76
new 0 1176 76
unlock 0 1178 78
unlock 0 1180 82
throw 1 1181 83
return 1 1183 85
lock 0 1187 89
assign 1 1189 91
unlock 0 1190 92
unlock 0 1192 96
throw 1 1193 97
assign 1 1198 103
oGet 0 1198 103
return 1 1198 104
assign 1 1202 108
oSet 1 1202 108
return 1 1202 109
return 1 0 112
assign 1 0 115
return 1 0 119
assign 1 0 122
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case -952571108: return bem_lockGet_0();
case -1048438184: return bem_oGet_0();
case 2055025483: return bem_serializeContents_0();
case -1299793528: return bem_objectGet_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 62849744: return bem_objGet_0();
case 1572587741: return bem_getAndClear_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1037355931: return bem_oSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 634688672: return bem_setIfClear_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1288711275: return bem_objectSet_1(bevd_0);
case -868745803: return bem_forwardCall_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 73931997: return bem_objSet_1(bevd_0);
case -941488855: return bem_lockSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_12_SystemThreadObjectLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_12_SystemThreadObjectLocker.bevs_inst = (BEC_3_6_6_12_SystemThreadObjectLocker)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_12_SystemThreadObjectLocker.bevs_inst;
}
}
