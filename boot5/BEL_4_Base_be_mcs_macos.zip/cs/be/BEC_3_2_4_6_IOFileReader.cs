namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_6_IOFileReader : BEC_2_2_6_IOReader {
public BEC_3_2_4_6_IOFileReader() { }
static BEC_3_2_4_6_IOFileReader() { }
private static byte[] becc_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] BEC_3_2_4_6_IOFileReader_bels_0 = {0x46,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_2_4_6_IOFileReader_bels_0, 5));
private static byte[] BEC_3_2_4_6_IOFileReader_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_2_4_6_IOFileReader_bels_1, 30));
public static new BEC_3_2_4_6_IOFileReader bevs_inst;
public BEC_3_2_4_4_IOFilePath bevp_path;
public virtual BEC_3_2_4_6_IOFileReader bem_new_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
this.bem_new_0();
bevp_blockSize = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1024));
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath);
this.bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileReader bem_open_0() {
BEC_2_4_6_TextString bevl_fhpatha = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_fhpatha = bevp_path.bem_toString_0();

      if (this.bevi_is == null) {
        string bevls_spath = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
        this.bevi_is = new FileStream(bevls_spath, FileMode.Open);
      }
      bevp_isClosed = be.BECS_Runtime.boolFalse;
      if (bevp_isClosed == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 129 */ {
if (bevp_isClosed.bevi_bool) /* Line: 129 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 129 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 129 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 129 */ {
bevt_5_tmpany_phold = bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_fhpatha);
bevt_6_tmpany_phold = bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 130 */
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_pathGet_0() {
return bevp_path;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileReader bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {64, 65, 69, 69, 84, 129, 129, 0, 0, 0, 130, 130, 130, 130, 130, 130, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 20, 21, 22, 35, 42, 47, 48, 52, 55, 59, 60, 61, 62, 63, 64, 69, 72};
/* BEGIN LINEINFO 
new 0 64 19
assign 1 65 20
new 0 65 20
assign 1 69 21
new 1 69 21
pathSet 1 69 22
assign 1 84 35
toString 0 84 35
assign 1 129 42
undef 1 129 47
assign 1 0 48
assign 1 0 52
assign 1 0 55
assign 1 130 59
new 0 130 59
assign 1 130 60
add 1 130 60
assign 1 130 61
new 0 130 61
assign 1 130 62
add 1 130 62
assign 1 130 63
new 1 130 63
throw 1 130 64
return 1 0 69
assign 1 0 72
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case -1109612452: return bem_byteReaderGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case 1325881255: return bem_readBuffer_0();
case -1358082055: return bem_blockSizeGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 1242327477: return bem_vfileGet_0();
case 287040793: return bem_hashGet_0();
case 698342331: return bem_readBufferLine_0();
case 1774940957: return bem_toString_0();
case -1714939806: return bem_readStringClose_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case -1240964868: return bem_extOpen_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 866536361: return bem_close_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 347960120: return bem_readString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1010579589: return bem_open_0();
case 1820417453: return bem_create_0();
case -792269839: return bem_isClosedGet_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
case -400189342: return bem_pathGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1992292136: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -781187586: return bem_isClosedSet_1(bevd_0);
case -389107089: return bem_pathSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1385004253: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1359009615: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 698342332: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 347960121: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1253409730: return bem_vfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1346999802: return bem_blockSizeSet_1(bevd_0);
case 1325881256: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1992292137: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 1992292138: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1359009613: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_6_IOFileReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_6_IOFileReader.bevs_inst = (BEC_3_2_4_6_IOFileReader)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_6_IOFileReader.bevs_inst;
}
}
}
