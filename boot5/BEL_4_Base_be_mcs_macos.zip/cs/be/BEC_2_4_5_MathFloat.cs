namespace be {
/* IO:File: source/base/Float.be */
public sealed class BEC_2_4_5_MathFloat : BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }
static BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2D};
private static byte[] bels_1 = {0x2E};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
private static byte[] bels_2 = {0x2E};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 1));
public static new BEC_2_4_5_MathFloat bevs_inst;
public BEC_2_6_6_SystemObject bem_vfloatGet_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_vfloatSet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_21_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_22_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevt_0_tmpany_phold = beva_si.bemd_1(1489442332, BEL_4_Base.bevn_begins_1, bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 60 */ {
bevl_neg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(-1250088509, BEL_4_Base.bevn_substring_1, bevt_2_tmpany_phold);
} /* Line: 62 */
 else  /* Line: 63 */ {
bevl_neg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 64 */
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(-1274448085, BEL_4_Base.bevn_find_1, bevt_3_tmpany_phold);
if (bevl_dec == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 67 */ {
bevt_6_tmpany_phold = bevo_0;
if (bevl_dec.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 68 */ {
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_7_tmpany_phold = beva_si.bemd_2(-1250088508, BEL_4_Base.bevn_substring_2, bevt_8_tmpany_phold, bevl_dec);
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_tmpany_phold);
} /* Line: 69 */
 else  /* Line: 70 */ {
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 71 */
bevt_11_tmpany_phold = bevo_1;
bevt_10_tmpany_phold = bevl_dec.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = beva_si.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_15_tmpany_phold = bevo_2;
bevt_14_tmpany_phold = bevl_dec.bem_add_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = beva_si.bemd_1(-1250088509, BEL_4_Base.bevn_substring_1, bevt_14_tmpany_phold);
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_tmpany_phold);
} /* Line: 74 */
 else  /* Line: 75 */ {
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 76 */
} /* Line: 73 */
 else  /* Line: 78 */ {
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 80 */
bevt_16_tmpany_phold = bevo_3;
bevt_18_tmpany_phold = bevl_rhs.bem_toString_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_sizeGet_0();
bevl_divby = bevt_16_tmpany_phold.bem_power_1(bevt_17_tmpany_phold);
if (bevl_neg.bevi_bool) /* Line: 83 */ {
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_tmpany_phold);
} /* Line: 85 */
bevt_21_tmpany_phold = bevl_rhs.bem_toFloat_0();
bevt_22_tmpany_phold = bevl_divby.bem_toFloat_0();
bevl_rhsf = bevt_21_tmpany_phold.bem_divide_1(bevt_22_tmpany_phold);
bevl_lhsf = bevl_lhs.bem_toFloat_0();
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
this.bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return bevl_ii;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toInt_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_lhi = this.bem_toInt_0();
bevt_0_tmpany_phold = bevl_lhi.bem_toFloat_0();
bevl_rh = this.bem_subtract_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_tmpany_phold);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_tmpany_phold = bevl_lhi.bem_toString_0();
bevt_5_tmpany_phold = bevo_4;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bevl_rhi.bem_toString_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_5_MathFloat bem_increment_0() {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 140 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 147 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrement_0() {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 155 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 162 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 170 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 177 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 185 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 192 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 200 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 207 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 215 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 222 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_5_MathFloat;
      if (this.bevi_float == bevls_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_5_MathFloat;
      if (this.bevi_float != bevls_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {60, 60, 61, 62, 62, 64, 66, 66, 67, 67, 68, 68, 68, 69, 69, 69, 71, 73, 73, 73, 73, 74, 74, 74, 74, 76, 79, 80, 82, 82, 82, 82, 84, 84, 85, 85, 87, 87, 87, 88, 89, 90, 93, 93, 96, 96, 100, 104, 104, 115, 123, 128, 128, 132, 133, 133, 134, 134, 135, 136, 136, 136, 136, 136, 136, 141, 147, 156, 162, 171, 177, 186, 192, 201, 207, 216, 222, 230, 230, 259, 259, 288, 288, 309, 309, 330, 330, 351, 351, 372, 372};
public static new int[] bevs_smnlec
 = new int[] {63, 64, 66, 67, 68, 71, 73, 74, 75, 80, 81, 82, 87, 88, 89, 90, 93, 95, 96, 97, 98, 100, 101, 102, 103, 106, 110, 111, 113, 114, 115, 116, 118, 119, 120, 121, 123, 124, 125, 126, 127, 128, 132, 133, 137, 138, 141, 146, 147, 151, 152, 156, 157, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 187, 190, 197, 200, 207, 210, 217, 220, 227, 230, 237, 240, 245, 246, 256, 257, 267, 268, 277, 278, 287, 288, 297, 298, 307, 308};
/* BEGIN LINEINFO 
assign 1 60 63
new 0 60 63
assign 1 60 64
begins 1 60 64
assign 1 61 66
new 0 61 66
assign 1 62 67
new 0 62 67
assign 1 62 68
substring 1 62 68
assign 1 64 71
new 0 64 71
assign 1 66 73
new 0 66 73
assign 1 66 74
find 1 66 74
assign 1 67 75
def 1 67 80
assign 1 68 81
new 0 68 81
assign 1 68 82
greater 1 68 87
assign 1 69 88
new 0 69 88
assign 1 69 89
substring 2 69 89
assign 1 69 90
new 1 69 90
assign 1 71 93
new 0 71 93
assign 1 73 95
new 0 73 95
assign 1 73 96
add 1 73 96
assign 1 73 97
sizeGet 0 73 97
assign 1 73 98
lesser 1 73 98
assign 1 74 100
new 0 74 100
assign 1 74 101
add 1 74 101
assign 1 74 102
substring 1 74 102
assign 1 74 103
new 1 74 103
assign 1 76 106
new 0 76 106
assign 1 79 110
new 1 79 110
assign 1 80 111
new 0 80 111
assign 1 82 113
new 0 82 113
assign 1 82 114
toString 0 82 114
assign 1 82 115
sizeGet 0 82 115
assign 1 82 116
power 1 82 116
assign 1 84 118
new 0 84 118
multiplyValue 1 84 119
assign 1 85 120
new 0 85 120
multiplyValue 1 85 121
assign 1 87 123
toFloat 0 87 123
assign 1 87 124
toFloat 0 87 124
assign 1 87 125
divide 1 87 125
assign 1 88 126
toFloat 0 88 126
assign 1 89 127
add 1 89 127
return 1 90 128
assign 1 93 132
new 0 93 132
return 1 93 133
assign 1 96 137
toString 0 96 137
return 1 96 138
new 1 100 141
assign 1 104 146
new 0 104 146
return 1 104 147
assign 1 115 151
new 0 115 151
return 1 123 152
assign 1 128 156
toInt 0 128 156
return 1 128 157
assign 1 132 170
toInt 0 132 170
assign 1 133 171
toFloat 0 133 171
assign 1 133 172
subtract 1 133 172
assign 1 134 173
new 0 134 173
assign 1 134 174
multiply 1 134 174
assign 1 135 175
toInt 0 135 175
assign 1 136 176
toString 0 136 176
assign 1 136 177
new 0 136 177
assign 1 136 178
add 1 136 178
assign 1 136 179
toString 0 136 179
assign 1 136 180
add 1 136 180
return 1 136 181
assign 1 141 187
new 0 141 187
return 1 147 190
assign 1 156 197
new 0 156 197
return 1 162 200
assign 1 171 207
new 0 171 207
return 1 177 210
assign 1 186 217
new 0 186 217
return 1 192 220
assign 1 201 227
new 0 201 227
return 1 207 230
assign 1 216 237
new 0 216 237
return 1 222 240
assign 1 230 245
new 0 230 245
return 1 230 246
assign 1 259 256
new 0 259 256
return 1 259 257
assign 1 288 267
new 0 288 267
return 1 288 268
assign 1 309 277
new 0 309 277
return 1 309 278
assign 1 330 287
new 0 330 287
return 1 330 288
assign 1 351 297
new 0 351 297
return 1 351 298
assign 1 372 307
new 0 372 307
return 1 372 308
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case -1046151292: return bem_decrement_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -1175111131: return bem_toInt_0();
case 443668840: return bem_methodNotDefined_0();
case 1679729549: return bem_vfloatSet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1085372256: return bem_increment_0();
case 1102720804: return bem_classNameGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case 1668647297: return bem_vfloatGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
case -1551584407: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case 81310150: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 364269035: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
case 1265088726: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1220624855: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -979186229: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_5_MathFloat();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_5_MathFloat.bevs_inst = (BEC_2_4_5_MathFloat)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_5_MathFloat.bevs_inst;
}
}
}
