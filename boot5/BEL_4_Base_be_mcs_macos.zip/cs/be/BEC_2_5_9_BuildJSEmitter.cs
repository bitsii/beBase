namespace be {
/* IO:File: source/build/JSEmitter.be */
public sealed class BEC_2_5_9_BuildJSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
static BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_7 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_8 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_9 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_9, 5));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_10 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_11 = {0x29,0x20,0x7B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_12 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_12, 31));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x29};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_13, 2));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_14 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_15 = {0x20,0x3D,0x20,0x5B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_18 = {0x28,0x29,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_19 = {0x7D};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_20 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_21 = {0x2C,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_22 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_23 = {0x5D,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_24 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_25 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_26 = {0x7D};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_27 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_28 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_29 = {0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_30 = {0x7D};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_31 = {0x5D,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_32 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_32, 10));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_33 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x5B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_34 = {0x5D,0x20,0x3D,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_35 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_36 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_36, 4));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_37 = {0x28,0x29};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_37, 2));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_38 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_39 = {0x29,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_41 = {0x29,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_43 = {0x2C,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_44 = {0x29,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_45 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_46 = {0x2C,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_47 = {0x29,0x3B};
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_50 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_51 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_52 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_53 = {0x28,0x29,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_54 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_55 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_56 = {0x22,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_57 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_58 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_59 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_60 = {0x76,0x61,0x72,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_61 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_62 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_62, 25));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_63 = {0x20,0x7B};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_63, 2));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_64 = {0x74,0x68,0x69,0x73};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_65 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_65, 17));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_66 = {0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_66, 3));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_67 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_67, 38));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_68 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_68, 4));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_69 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_69, 21));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_70 = {0x29};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_70, 1));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_71 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_71, 4));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_72 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_72, 23));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_73 = {0x29};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_73, 1));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_74 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_74, 4));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_75 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_75, 27));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_76 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_76, 22));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_77 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_77, 2));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_78 = {0x29};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_78, 1));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_79 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_79, 4));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_80 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_80, 32));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_81 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_81, 22));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_82 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_82, 2));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_83 = {0x29};
private static BEC_2_4_6_TextString bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_83, 1));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_84 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_85 = {0x76,0x61,0x72,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_86 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_87 = {0x7D};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_88 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_88, 5));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_89 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_89, 4));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_90 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_91 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_91, 11));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_92 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_92, 5));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_93 = {0x20,0x3D,0x20};
private static BEC_2_4_6_TextString bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_93, 3));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_94 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_94, 11));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_95 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_95, 4));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_96 = {0x3B};
private static BEC_2_4_6_TextString bevo_35 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_96, 1));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_97 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_98 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_99 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_100 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_101 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_102 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_103 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_104 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_105 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_106 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_107 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_108 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bevo_36 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_108, 7));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_109 = {0x3A,0x20};
private static BEC_2_4_6_TextString bevo_37 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_109, 2));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_110 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_111 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bevo_38 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_111, 31));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_112 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_112, 22));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_113 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bevo_40 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_113, 5));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_114 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_115 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_116 = {0x29,0x20,0x7B};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_117 = {};
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_118 = {0x5F};
private static BEC_2_4_6_TextString bevo_41 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_2_5_9_BuildJSEmitter_bels_118, 1));
private static byte[] BEC_2_5_9_BuildJSEmitter_bels_119 = {0x62,0x65};
public static new BEC_2_5_9_BuildJSEmitter bevs_inst;
public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_2));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, BEC_2_5_9_BuildJSEmitter_bels_7));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = this.bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, BEC_2_5_9_BuildJSEmitter_bels_8));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, BEC_2_5_9_BuildJSEmitter_bels_11));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpany_phold = bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold, bevt_12_tmpany_phold, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_1(BEC_2_4_6_TextString beva_belsBase) {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, BEC_2_5_9_BuildJSEmitter_bels_14));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, BEC_2_5_9_BuildJSEmitter_bels_15));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_9_tmpany_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_tmpany_phold);
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 70 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 70 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_first.bevi_bool) /* Line: 71 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 72 */
 else  /* Line: 73 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_21));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 74 */
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 76 */
 else  /* Line: 70 */ {
break;
} /* Line: 70 */
} /* Line: 70 */
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_tmpany_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(50, BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_21_tmpany_phold);
bevt_20_tmpany_phold.bem_addValue_1(bevp_nl);
this.bem_buildPropList_0();
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_31));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_2_tmpany_phold = bevo_3;
bevt_3_tmpany_phold = beva_v.bem_nameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_1_tmpany_phold;
} /* Line: 121 */
bevt_4_tmpany_phold = base.bem_nameForVar_1(beva_v);
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_typeInstances = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
bevl_libe = this.bem_getLibOutput_0();
bevl_typeInstances = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_libInit = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 135 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 135 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(40, BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevp_q);
bevt_12_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_q);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, BEC_2_5_9_BuildJSEmitter_bels_34));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_17_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpany_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_tmpany_phold);
bevt_18_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_relEmitName_1(bevt_18_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_20_tmpany_phold != null && bevt_20_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevt_24_tmpany_phold = bevo_4;
bevt_28_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpany_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_tmpany_phold);
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bevo_5;
bevl_nc = bevt_23_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_31_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_36_tmpany_phold != null && bevt_36_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpany_phold).bevi_bool) /* Line: 150 */ {
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) bevt_41_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) bevt_40_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_39_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 151 */
} /* Line: 150 */
} /* Line: 141 */
 else  /* Line: 135 */ {
break;
} /* Line: 135 */
} /* Line: 135 */
bevl_smap = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_tmpany_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpany_loop = bevt_44_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 159 */ {
bevt_45_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_45_tmpany_phold != null && bevt_45_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpany_phold).bevi_bool) /* Line: 159 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_quoteGet_0();
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_quoteGet_0();
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) bevt_50_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) bevt_49_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_59_tmpany_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevt_48_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevt_47_tmpany_phold.bem_addValue_1(bevt_60_tmpany_phold);
bevt_46_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(43, BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_quoteGet_0();
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) bevt_67_tmpany_phold.bem_addValue_1(bevt_69_tmpany_phold);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) bevt_66_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_quoteGet_0();
bevt_64_tmpany_phold = (BEC_2_4_6_TextString) bevt_65_tmpany_phold.bem_addValue_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) bevt_64_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) bevt_63_tmpany_phold.bem_addValue_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bem_addValue_1(bevt_75_tmpany_phold);
bevt_61_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 162 */
 else  /* Line: 159 */ {
break;
} /* Line: 159 */
} /* Line: 159 */
bevl_libe.bem_write_1(bevl_smap);
bevl_libe.bem_write_1(bevl_typeInstances);
bevt_78_tmpany_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bem_sizeGet_0();
bevt_79_tmpany_phold = bevo_6;
if (bevt_77_tmpany_phold.bevi_int == bevt_79_tmpany_phold.bevi_int) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(91, BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_81_tmpany_phold);
bevt_80_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(93, BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_83_tmpany_phold);
bevt_82_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(78, BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_85_tmpany_phold);
bevt_84_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 174 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpany_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpany_phold);
bevl_maincc = this.bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, BEC_2_5_9_BuildJSEmitter_bels_54));
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_95_tmpany_phold);
bevt_94_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 188 */
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, BEC_2_5_9_BuildJSEmitter_bels_55));
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_56));
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) bevt_97_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevt_96_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_57));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_103_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, BEC_2_5_9_BuildJSEmitter_bels_58));
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_105_tmpany_phold);
bevt_104_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, BEC_2_5_9_BuildJSEmitter_bels_59));
bevt_106_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_107_tmpany_phold);
bevt_106_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 197 */
bevl_libe.bem_write_1(bevl_main);
this.bem_finishLibOutput_1(bevl_libe);
bevt_108_tmpany_phold = bevp_build.bem_saveSynsGet_0();
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 203 */ {
this.bem_saveSyns_0();
} /* Line: 204 */
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_decForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 210 */ {
} /* Line: 210 */
 else  /* Line: 212 */ {
bevt_2_tmpany_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, BEC_2_5_9_BuildJSEmitter_bels_60));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 214 */
bevt_4_tmpany_phold = this.bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 216 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, BEC_2_5_9_BuildJSEmitter_bels_61));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpany_phold = bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, BEC_2_5_9_BuildJSEmitter_bels_64));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bevo_9;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_parent);
bevt_5_tmpany_phold = bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevl_extstr.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevo_11;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bevo_12;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevo_13;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bevo_14;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bevo_15;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevo_16;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bevo_17;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 248 */ {
bevt_8_tmpany_phold = bevo_18;
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bevo_19;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bevo_20;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_14_tmpany_phold = bevo_21;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bevo_22;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 249 */
bevt_24_tmpany_phold = bevo_23;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevo_24;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = bevo_25;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(beva_belsName);
bevt_30_tmpany_phold = bevo_26;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_lisz);
bevt_31_tmpany_phold = bevo_27;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = this.bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 256 */
 else  /* Line: 257 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, BEC_2_5_9_BuildJSEmitter_bels_84));
bevl_extends = this.bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 258 */
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, BEC_2_5_9_BuildJSEmitter_bels_85));
bevt_6_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, BEC_2_5_9_BuildJSEmitter_bels_86));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, BEC_2_5_9_BuildJSEmitter_bels_87));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_9_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public override BEC_2_4_6_TextString bem_emitNameForCall_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1796577138, BEL_4_Base.bevn_superCallGet_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 274 */ {
bevt_3_tmpany_phold = bevo_28;
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 275 */
bevt_7_tmpany_phold = bevo_29;
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_6_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_90));
bevt_0_tmpany_loop = bevp_superCalls.bem_iteratorGet_0();
while (true)
 /* Line: 282 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 282 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpany_phold = bevo_30;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevo_31;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevl_node.bem_heldGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = bevo_32;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = bevo_33;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevo_34;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bevl_node.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevo_35;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_nl);
bevl_end.bem_addValue_1(bevt_2_tmpany_phold);
} /* Line: 283 */
 else  /* Line: 282 */ {
break;
} /* Line: 282 */
} /* Line: 282 */
return bevl_end;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 292 */ {
bevp_allOnceDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 293 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 309 */ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 312 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_11_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, BEC_2_5_9_BuildJSEmitter_bels_97));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_has_1(bevt_12_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 316 */ {
bevt_14_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, BEC_2_5_9_BuildJSEmitter_bels_98));
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_get_1(bevt_15_tmpany_phold);
bevt_0_tmpany_loop = bevt_13_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 317 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpany_phold != null && bevt_16_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_16_tmpany_phold).bevi_bool) /* Line: 317 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_17_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevt_21_tmpany_phold = this.bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 322 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
} /* Line: 317 */
} /* Line: 316 */
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_99));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_100));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_101));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_102));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, BEC_2_5_9_BuildJSEmitter_bels_103));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_spropDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_104));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_105));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_106));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_107));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bevo_36;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_anyName);
bevt_4_tmpany_phold = bevo_37;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_typeName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_110));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevo_38;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bevo_39;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevo_40;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, BEC_2_5_9_BuildJSEmitter_bels_114));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, BEC_2_5_9_BuildJSEmitter_bels_115));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, BEC_2_5_9_BuildJSEmitter_bels_116));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_1(BEC_2_5_11_BuildClassConfig beva_cc) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, BEC_2_5_9_BuildJSEmitter_bels_117));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_41;
bevt_1_tmpany_phold = beva_nameSpace.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_emitName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, BEC_2_5_9_BuildJSEmitter_bels_119));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = base.bem_getClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = base.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 23, 25, 26, 28, 29, 33, 33, 33, 33, 33, 33, 33, 33, 37, 37, 37, 38, 39, 39, 39, 39, 39, 39, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 52, 52, 52, 52, 52, 52, 52, 56, 56, 56, 56, 56, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 59, 59, 59, 64, 64, 65, 67, 67, 67, 67, 69, 70, 0, 70, 70, 72, 74, 74, 76, 76, 76, 76, 76, 76, 80, 80, 80, 85, 85, 85, 86, 88, 88, 88, 88, 88, 91, 91, 91, 91, 93, 93, 93, 95, 95, 95, 95, 95, 98, 98, 98, 98, 98, 98, 100, 100, 100, 102, 107, 108, 109, 115, 115, 115, 120, 121, 121, 121, 121, 123, 123, 129, 131, 132, 133, 134, 135, 135, 137, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 141, 141, 141, 143, 143, 143, 143, 143, 143, 143, 143, 143, 149, 149, 149, 149, 149, 149, 150, 150, 150, 151, 151, 151, 151, 151, 151, 157, 159, 159, 0, 159, 159, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 166, 168, 171, 171, 171, 171, 171, 172, 172, 172, 173, 173, 173, 174, 174, 174, 177, 178, 181, 182, 182, 183, 185, 186, 186, 186, 186, 186, 186, 186, 187, 188, 188, 188, 190, 190, 190, 190, 190, 190, 190, 190, 191, 192, 193, 194, 195, 196, 196, 196, 197, 197, 197, 199, 201, 203, 204, 210, 213, 213, 213, 214, 214, 216, 216, 221, 221, 225, 225, 225, 225, 225, 225, 229, 229, 234, 234, 234, 234, 234, 234, 234, 235, 235, 235, 235, 235, 236, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 255, 255, 256, 256, 256, 258, 258, 260, 260, 260, 260, 260, 268, 268, 268, 269, 270, 274, 274, 275, 275, 275, 275, 275, 277, 277, 277, 277, 277, 281, 282, 0, 282, 282, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 283, 285, 292, 292, 293, 295, 296, 296, 301, 301, 309, 309, 310, 311, 311, 311, 311, 311, 312, 312, 312, 314, 314, 314, 316, 316, 316, 317, 317, 317, 317, 0, 317, 317, 318, 318, 319, 319, 319, 320, 320, 321, 321, 322, 328, 332, 333, 338, 338, 342, 342, 346, 346, 350, 350, 354, 354, 358, 358, 362, 362, 367, 367, 372, 372, 376, 376, 376, 376, 376, 376, 380, 380, 384, 384, 384, 384, 384, 389, 389, 389, 389, 389, 389, 389, 394, 394, 394, 394, 394, 394, 394, 396, 398, 398, 398, 403, 403, 407, 407, 411, 411, 411, 411, 416, 416, 420, 421, 421, 422, 426, 427, 427, 428, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {174, 175, 176, 177, 178, 179, 180, 181, 192, 193, 194, 195, 196, 197, 198, 199, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 252, 253, 254, 255, 256, 257, 258, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 318, 319, 320, 321, 322, 323, 324, 325, 326, 326, 329, 331, 333, 336, 337, 339, 340, 341, 342, 343, 344, 350, 351, 352, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 415, 416, 417, 423, 424, 425, 434, 436, 437, 438, 439, 441, 442, 567, 568, 569, 570, 571, 572, 575, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 620, 621, 622, 623, 624, 625, 633, 634, 635, 635, 638, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 678, 679, 680, 681, 682, 683, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 715, 716, 717, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 733, 734, 735, 736, 737, 738, 740, 741, 742, 744, 754, 758, 759, 764, 765, 766, 768, 769, 775, 776, 784, 785, 786, 787, 788, 789, 793, 794, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 955, 960, 961, 962, 963, 966, 967, 969, 970, 971, 972, 973, 974, 975, 976, 977, 978, 991, 992, 994, 995, 996, 997, 998, 1000, 1001, 1002, 1003, 1004, 1033, 1034, 1034, 1037, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1068, 1073, 1078, 1079, 1081, 1082, 1083, 1087, 1088, 1119, 1124, 1125, 1126, 1127, 1128, 1129, 1134, 1135, 1136, 1137, 1139, 1140, 1141, 1142, 1143, 1144, 1146, 1147, 1148, 1149, 1149, 1152, 1154, 1155, 1156, 1157, 1158, 1159, 1160, 1161, 1162, 1163, 1164, 1172, 1175, 1176, 1181, 1182, 1186, 1187, 1191, 1192, 1196, 1197, 1201, 1202, 1206, 1207, 1211, 1212, 1216, 1217, 1221, 1222, 1230, 1231, 1232, 1233, 1234, 1235, 1239, 1240, 1247, 1248, 1249, 1250, 1251, 1260, 1261, 1262, 1263, 1264, 1265, 1266, 1277, 1278, 1279, 1280, 1281, 1282, 1283, 1284, 1285, 1286, 1287, 1292, 1293, 1297, 1298, 1304, 1305, 1306, 1307, 1311, 1312, 1317, 1318, 1319, 1320, 1325, 1326, 1327, 1328, 1331, 1334, 1338, 1341};
/* BEGIN LINEINFO 
assign 1 17 174
new 0 17 174
assign 1 18 175
new 0 18 175
assign 1 19 176
new 0 19 176
new 1 23 177
assign 1 25 178
new 0 25 178
assign 1 26 179
new 0 26 179
assign 1 28 180
new 0 28 180
assign 1 29 181
new 0 29 181
assign 1 33 192
new 0 33 192
assign 1 33 193
addValue 1 33 193
assign 1 33 194
secondGet 0 33 194
assign 1 33 195
formTarg 1 33 195
assign 1 33 196
addValue 1 33 196
assign 1 33 197
new 0 33 197
assign 1 33 198
addValue 1 33 198
addValue 1 33 199
assign 1 37 220
new 0 37 220
assign 1 37 221
toString 0 37 221
assign 1 37 222
add 1 37 222
incrementValue 0 38 223
assign 1 39 224
new 0 39 224
assign 1 39 225
addValue 1 39 225
assign 1 39 226
addValue 1 39 226
assign 1 39 227
new 0 39 227
assign 1 39 228
addValue 1 39 228
addValue 1 39 229
assign 1 44 230
containedGet 0 44 230
assign 1 44 231
firstGet 0 44 231
assign 1 44 232
containedGet 0 44 232
assign 1 44 233
firstGet 0 44 233
assign 1 44 234
new 0 44 234
assign 1 44 235
add 1 44 235
assign 1 44 236
new 0 44 236
assign 1 44 237
add 1 44 237
assign 1 44 238
finalAssign 3 44 238
addValue 1 44 239
assign 1 52 252
emitNameGet 0 52 252
assign 1 52 253
addValue 1 52 253
assign 1 52 254
new 0 52 254
assign 1 52 255
addValue 1 52 255
assign 1 52 256
addValue 1 52 256
assign 1 52 257
new 0 52 257
addValue 1 52 258
assign 1 56 278
emitNameGet 0 56 278
assign 1 56 279
addValue 1 56 279
assign 1 56 280
new 0 56 280
assign 1 56 281
addValue 1 56 281
addValue 1 56 282
assign 1 57 283
new 0 57 283
assign 1 57 284
addValue 1 57 284
assign 1 57 285
heldGet 0 57 285
assign 1 57 286
namepathGet 0 57 286
assign 1 57 287
getClassConfig 1 57 287
assign 1 57 288
libNameGet 0 57 288
assign 1 57 289
relEmitName 1 57 289
assign 1 57 290
addValue 1 57 290
assign 1 57 291
new 0 57 291
assign 1 57 292
addValue 1 57 292
addValue 1 57 293
assign 1 59 294
new 0 59 294
assign 1 59 295
addValue 1 59 295
addValue 1 59 296
assign 1 64 318
heldGet 0 64 318
assign 1 64 319
synGet 0 64 319
assign 1 65 320
ptyListGet 0 65 320
assign 1 67 321
emitNameGet 0 67 321
assign 1 67 322
addValue 1 67 322
assign 1 67 323
new 0 67 323
addValue 1 67 324
assign 1 69 325
new 0 69 325
assign 1 70 326
iteratorGet 0 0 326
assign 1 70 329
hasNextGet 0 70 329
assign 1 70 331
nextGet 0 70 331
assign 1 72 333
new 0 72 333
assign 1 74 336
new 0 74 336
addValue 1 74 337
assign 1 76 339
addValue 1 76 339
assign 1 76 340
new 0 76 340
assign 1 76 341
addValue 1 76 341
assign 1 76 342
nameGet 0 76 342
assign 1 76 343
addValue 1 76 343
addValue 1 76 344
assign 1 80 350
new 0 80 350
assign 1 80 351
addValue 1 80 351
addValue 1 80 352
assign 1 85 380
heldGet 0 85 380
assign 1 85 381
namepathGet 0 85 381
assign 1 85 382
getClassConfig 1 85 382
assign 1 86 383
getInitialInst 1 86 383
assign 1 88 384
emitNameGet 0 88 384
assign 1 88 385
addValue 1 88 385
assign 1 88 386
new 0 88 386
assign 1 88 387
addValue 1 88 387
addValue 1 88 388
assign 1 91 389
addValue 1 91 389
assign 1 91 390
new 0 91 390
assign 1 91 391
addValue 1 91 391
addValue 1 91 392
assign 1 93 393
new 0 93 393
assign 1 93 394
addValue 1 93 394
addValue 1 93 395
assign 1 95 396
emitNameGet 0 95 396
assign 1 95 397
addValue 1 95 397
assign 1 95 398
new 0 95 398
assign 1 95 399
addValue 1 95 399
addValue 1 95 400
assign 1 98 401
new 0 98 401
assign 1 98 402
addValue 1 98 402
assign 1 98 403
addValue 1 98 403
assign 1 98 404
new 0 98 404
assign 1 98 405
addValue 1 98 405
addValue 1 98 406
assign 1 100 407
new 0 100 407
assign 1 100 408
addValue 1 100 408
addValue 1 100 409
buildPropList 0 102 410
getCode 2 107 415
assign 1 108 416
toString 0 108 416
addValue 1 109 417
assign 1 115 423
new 0 115 423
assign 1 115 424
addValue 1 115 424
addValue 1 115 425
assign 1 120 434
isPropertyGet 0 120 434
assign 1 121 436
new 0 121 436
assign 1 121 437
nameGet 0 121 437
assign 1 121 438
add 1 121 438
return 1 121 439
assign 1 123 441
nameForVar 1 123 441
return 1 123 442
assign 1 129 567
getLibOutput 0 129 567
assign 1 131 568
new 0 131 568
assign 1 132 569
new 0 132 569
assign 1 133 570
new 0 133 570
assign 1 134 571
new 0 134 571
assign 1 135 572
iteratorGet 0 135 572
assign 1 135 575
hasNextGet 0 135 575
assign 1 137 577
nextGet 0 137 577
assign 1 139 578
new 0 139 578
assign 1 139 579
addValue 1 139 579
assign 1 139 580
addValue 1 139 580
assign 1 139 581
heldGet 0 139 581
assign 1 139 582
namepathGet 0 139 582
assign 1 139 583
toString 0 139 583
assign 1 139 584
addValue 1 139 584
assign 1 139 585
addValue 1 139 585
assign 1 139 586
new 0 139 586
assign 1 139 587
addValue 1 139 587
assign 1 139 588
heldGet 0 139 588
assign 1 139 589
namepathGet 0 139 589
assign 1 139 590
getClassConfig 1 139 590
assign 1 139 591
libNameGet 0 139 591
assign 1 139 592
relEmitName 1 139 592
assign 1 139 593
addValue 1 139 593
assign 1 139 594
new 0 139 594
assign 1 139 595
addValue 1 139 595
addValue 1 139 596
assign 1 141 597
heldGet 0 141 597
assign 1 141 598
synGet 0 141 598
assign 1 141 599
hasDefaultGet 0 141 599
assign 1 143 601
new 0 143 601
assign 1 143 602
heldGet 0 143 602
assign 1 143 603
namepathGet 0 143 603
assign 1 143 604
getClassConfig 1 143 604
assign 1 143 605
libNameGet 0 143 605
assign 1 143 606
relEmitName 1 143 606
assign 1 143 607
add 1 143 607
assign 1 143 608
new 0 143 608
assign 1 143 609
add 1 143 609
assign 1 149 610
new 0 149 610
assign 1 149 611
addValue 1 149 611
assign 1 149 612
addValue 1 149 612
assign 1 149 613
new 0 149 613
assign 1 149 614
addValue 1 149 614
addValue 1 149 615
assign 1 150 616
heldGet 0 150 616
assign 1 150 617
synGet 0 150 617
assign 1 150 618
hasDefaultGet 0 150 618
assign 1 151 620
new 0 151 620
assign 1 151 621
addValue 1 151 621
assign 1 151 622
addValue 1 151 622
assign 1 151 623
new 0 151 623
assign 1 151 624
addValue 1 151 624
addValue 1 151 625
assign 1 157 633
new 0 157 633
assign 1 159 634
keysGet 0 159 634
assign 1 159 635
iteratorGet 0 0 635
assign 1 159 638
hasNextGet 0 159 638
assign 1 159 640
nextGet 0 159 640
assign 1 161 641
new 0 161 641
assign 1 161 642
addValue 1 161 642
assign 1 161 643
new 0 161 643
assign 1 161 644
quoteGet 0 161 644
assign 1 161 645
addValue 1 161 645
assign 1 161 646
addValue 1 161 646
assign 1 161 647
new 0 161 647
assign 1 161 648
quoteGet 0 161 648
assign 1 161 649
addValue 1 161 649
assign 1 161 650
new 0 161 650
assign 1 161 651
addValue 1 161 651
assign 1 161 652
get 1 161 652
assign 1 161 653
addValue 1 161 653
assign 1 161 654
new 0 161 654
assign 1 161 655
addValue 1 161 655
addValue 1 161 656
assign 1 162 657
new 0 162 657
assign 1 162 658
addValue 1 162 658
assign 1 162 659
new 0 162 659
assign 1 162 660
quoteGet 0 162 660
assign 1 162 661
addValue 1 162 661
assign 1 162 662
addValue 1 162 662
assign 1 162 663
new 0 162 663
assign 1 162 664
quoteGet 0 162 664
assign 1 162 665
addValue 1 162 665
assign 1 162 666
new 0 162 666
assign 1 162 667
addValue 1 162 667
assign 1 162 668
get 1 162 668
assign 1 162 669
addValue 1 162 669
assign 1 162 670
new 0 162 670
assign 1 162 671
addValue 1 162 671
addValue 1 162 672
write 1 166 678
write 1 168 679
assign 1 171 680
usedLibrarysGet 0 171 680
assign 1 171 681
sizeGet 0 171 681
assign 1 171 682
new 0 171 682
assign 1 171 683
equals 1 171 688
assign 1 172 689
new 0 172 689
assign 1 172 690
addValue 1 172 690
addValue 1 172 691
assign 1 173 692
new 0 173 692
assign 1 173 693
addValue 1 173 693
addValue 1 173 694
assign 1 174 695
new 0 174 695
assign 1 174 696
addValue 1 174 696
addValue 1 174 697
write 1 177 699
write 1 178 700
assign 1 181 701
new 0 181 701
assign 1 182 702
mainNameGet 0 182 702
fromString 1 182 703
assign 1 183 704
getClassConfig 1 183 704
assign 1 185 705
new 0 185 705
assign 1 186 706
new 0 186 706
assign 1 186 707
addValue 1 186 707
assign 1 186 708
fullEmitNameGet 0 186 708
assign 1 186 709
addValue 1 186 709
assign 1 186 710
new 0 186 710
assign 1 186 711
addValue 1 186 711
addValue 1 186 712
assign 1 187 713
ownProcessGet 0 187 713
assign 1 188 715
new 0 188 715
assign 1 188 716
addValue 1 188 716
addValue 1 188 717
assign 1 190 719
new 0 190 719
assign 1 190 720
addValue 1 190 720
assign 1 190 721
outputPlatformGet 0 190 721
assign 1 190 722
nameGet 0 190 722
assign 1 190 723
addValue 1 190 723
assign 1 190 724
new 0 190 724
assign 1 190 725
addValue 1 190 725
addValue 1 190 726
write 1 191 727
assign 1 192 728
new 0 192 728
write 1 193 729
write 1 194 730
assign 1 195 731
ownProcessGet 0 195 731
assign 1 196 733
new 0 196 733
assign 1 196 734
addValue 1 196 734
addValue 1 196 735
assign 1 197 736
new 0 197 736
assign 1 197 737
addValue 1 197 737
addValue 1 197 738
write 1 199 740
finishLibOutput 1 201 741
assign 1 203 742
saveSynsGet 0 203 742
saveSyns 0 204 744
assign 1 210 754
isPropertyGet 0 210 754
assign 1 213 758
isArgGet 0 213 758
assign 1 213 759
not 0 213 764
assign 1 214 765
new 0 214 765
addValue 1 214 766
assign 1 216 768
nameForVar 1 216 768
addValue 1 216 769
assign 1 221 775
new 0 221 775
return 1 221 776
assign 1 225 784
new 0 225 784
assign 1 225 785
add 1 225 785
assign 1 225 786
new 0 225 786
assign 1 225 787
add 1 225 787
assign 1 225 788
add 1 225 788
return 1 225 789
assign 1 229 793
new 0 229 793
return 1 229 794
assign 1 234 808
emitNameGet 0 234 808
assign 1 234 809
new 0 234 809
assign 1 234 810
add 1 234 810
assign 1 234 811
add 1 234 811
assign 1 234 812
new 0 234 812
assign 1 234 813
add 1 234 813
assign 1 234 814
addValue 1 234 814
assign 1 235 815
emitNameGet 0 235 815
assign 1 235 816
add 1 235 816
assign 1 235 817
new 0 235 817
assign 1 235 818
add 1 235 818
assign 1 235 819
addValue 1 235 819
return 1 236 820
assign 1 240 834
new 0 240 834
assign 1 240 835
libNameGet 0 240 835
assign 1 240 836
relEmitName 1 240 836
assign 1 240 837
add 1 240 837
assign 1 240 838
new 0 240 838
assign 1 240 839
add 1 240 839
assign 1 240 840
heldGet 0 240 840
assign 1 240 841
literalValueGet 0 240 841
assign 1 240 842
add 1 240 842
assign 1 240 843
new 0 240 843
assign 1 240 844
add 1 240 844
return 1 240 845
assign 1 244 859
new 0 244 859
assign 1 244 860
libNameGet 0 244 860
assign 1 244 861
relEmitName 1 244 861
assign 1 244 862
add 1 244 862
assign 1 244 863
new 0 244 863
assign 1 244 864
add 1 244 864
assign 1 244 865
heldGet 0 244 865
assign 1 244 866
literalValueGet 0 244 866
assign 1 244 867
add 1 244 867
assign 1 244 868
new 0 244 868
assign 1 244 869
add 1 244 869
return 1 244 870
assign 1 249 906
new 0 249 906
assign 1 249 907
libNameGet 0 249 907
assign 1 249 908
relEmitName 1 249 908
assign 1 249 909
add 1 249 909
assign 1 249 910
new 0 249 910
assign 1 249 911
add 1 249 911
assign 1 249 912
emitNameGet 0 249 912
assign 1 249 913
add 1 249 913
assign 1 249 914
new 0 249 914
assign 1 249 915
add 1 249 915
assign 1 249 916
add 1 249 916
assign 1 249 917
new 0 249 917
assign 1 249 918
add 1 249 918
assign 1 249 919
add 1 249 919
assign 1 249 920
new 0 249 920
assign 1 249 921
add 1 249 921
return 1 249 922
assign 1 251 924
new 0 251 924
assign 1 251 925
libNameGet 0 251 925
assign 1 251 926
relEmitName 1 251 926
assign 1 251 927
add 1 251 927
assign 1 251 928
new 0 251 928
assign 1 251 929
add 1 251 929
assign 1 251 930
emitNameGet 0 251 930
assign 1 251 931
add 1 251 931
assign 1 251 932
new 0 251 932
assign 1 251 933
add 1 251 933
assign 1 251 934
add 1 251 934
assign 1 251 935
new 0 251 935
assign 1 251 936
add 1 251 936
assign 1 251 937
add 1 251 937
assign 1 251 938
new 0 251 938
assign 1 251 939
add 1 251 939
return 1 251 940
assign 1 255 955
def 1 255 960
assign 1 256 961
libNameGet 0 256 961
assign 1 256 962
relEmitName 1 256 962
assign 1 256 963
extend 1 256 963
assign 1 258 966
new 0 258 966
assign 1 258 967
extend 1 258 967
assign 1 260 969
new 0 260 969
assign 1 260 970
emitNameGet 0 260 970
assign 1 260 971
addValue 1 260 971
assign 1 260 972
new 0 260 972
assign 1 260 973
addValue 1 260 973
assign 1 268 974
new 0 268 974
assign 1 268 975
addValue 1 268 975
addValue 1 268 976
addValue 1 269 977
return 1 270 978
assign 1 274 991
heldGet 0 274 991
assign 1 274 992
superCallGet 0 274 992
assign 1 275 994
new 0 275 994
assign 1 275 995
heldGet 0 275 995
assign 1 275 996
nameGet 0 275 996
assign 1 275 997
add 1 275 997
return 1 275 998
assign 1 277 1000
new 0 277 1000
assign 1 277 1001
heldGet 0 277 1001
assign 1 277 1002
nameGet 0 277 1002
assign 1 277 1003
add 1 277 1003
return 1 277 1004
assign 1 281 1033
new 0 281 1033
assign 1 282 1034
iteratorGet 0 0 1034
assign 1 282 1037
hasNextGet 0 282 1037
assign 1 282 1039
nextGet 0 282 1039
assign 1 283 1040
emitNameGet 0 283 1040
assign 1 283 1041
new 0 283 1041
assign 1 283 1042
add 1 283 1042
assign 1 283 1043
new 0 283 1043
assign 1 283 1044
add 1 283 1044
assign 1 283 1045
heldGet 0 283 1045
assign 1 283 1046
nameGet 0 283 1046
assign 1 283 1047
add 1 283 1047
assign 1 283 1048
new 0 283 1048
assign 1 283 1049
add 1 283 1049
assign 1 283 1050
emitNameGet 0 283 1050
assign 1 283 1051
add 1 283 1051
assign 1 283 1052
new 0 283 1052
assign 1 283 1053
add 1 283 1053
assign 1 283 1054
new 0 283 1054
assign 1 283 1055
add 1 283 1055
assign 1 283 1056
heldGet 0 283 1056
assign 1 283 1057
nameGet 0 283 1057
assign 1 283 1058
add 1 283 1058
assign 1 283 1059
new 0 283 1059
assign 1 283 1060
add 1 283 1060
assign 1 283 1061
add 1 283 1061
addValue 1 283 1062
return 1 285 1068
assign 1 292 1073
undef 1 292 1078
assign 1 293 1079
new 0 293 1079
addValue 1 295 1081
assign 1 296 1082
new 0 296 1082
return 1 296 1083
assign 1 301 1087
getLibOutput 0 301 1087
return 1 301 1088
assign 1 309 1119
undef 1 309 1124
assign 1 310 1125
new 0 310 1125
assign 1 311 1126
parentGet 0 311 1126
assign 1 311 1127
fileGet 0 311 1127
assign 1 311 1128
existsGet 0 311 1128
assign 1 311 1129
not 0 311 1134
assign 1 312 1135
parentGet 0 312 1135
assign 1 312 1136
fileGet 0 312 1136
makeDirs 0 312 1137
assign 1 314 1139
fileGet 0 314 1139
assign 1 314 1140
writerGet 0 314 1140
assign 1 314 1141
open 0 314 1141
assign 1 316 1142
paramsGet 0 316 1142
assign 1 316 1143
new 0 316 1143
assign 1 316 1144
has 1 316 1144
assign 1 317 1146
paramsGet 0 317 1146
assign 1 317 1147
new 0 317 1147
assign 1 317 1148
get 1 317 1148
assign 1 317 1149
iteratorGet 0 0 1149
assign 1 317 1152
hasNextGet 0 317 1152
assign 1 317 1154
nextGet 0 317 1154
assign 1 318 1155
apNew 1 318 1155
assign 1 318 1156
fileGet 0 318 1156
assign 1 319 1157
readerGet 0 319 1157
assign 1 319 1158
open 0 319 1158
assign 1 319 1159
readString 0 319 1159
assign 1 320 1160
readerGet 0 320 1160
close 0 320 1161
assign 1 321 1162
countLines 1 321 1162
addValue 1 321 1163
write 1 322 1164
return 1 328 1172
close 0 332 1175
assign 1 333 1176
assign 1 338 1181
new 0 338 1181
return 1 338 1182
assign 1 342 1186
new 0 342 1186
return 1 342 1187
assign 1 346 1191
new 0 346 1191
return 1 346 1192
assign 1 350 1196
new 0 350 1196
return 1 350 1197
assign 1 354 1201
new 0 354 1201
return 1 354 1202
assign 1 358 1206
new 0 358 1206
return 1 358 1207
assign 1 362 1211
new 0 362 1211
return 1 362 1212
assign 1 367 1216
new 0 367 1216
return 1 367 1217
assign 1 372 1221
new 0 372 1221
return 1 372 1222
assign 1 376 1230
new 0 376 1230
assign 1 376 1231
add 1 376 1231
assign 1 376 1232
new 0 376 1232
assign 1 376 1233
add 1 376 1233
assign 1 376 1234
add 1 376 1234
return 1 376 1235
assign 1 380 1239
new 0 380 1239
return 1 380 1240
assign 1 384 1247
libNameGet 0 384 1247
assign 1 384 1248
relEmitName 1 384 1248
assign 1 384 1249
new 0 384 1249
assign 1 384 1250
add 1 384 1250
return 1 384 1251
assign 1 389 1260
emitNameGet 0 389 1260
assign 1 389 1261
new 0 389 1261
assign 1 389 1262
add 1 389 1262
assign 1 389 1263
new 0 389 1263
assign 1 389 1264
add 1 389 1264
assign 1 389 1265
add 1 389 1265
return 1 389 1266
assign 1 394 1277
emitNameGet 0 394 1277
assign 1 394 1278
addValue 1 394 1278
assign 1 394 1279
new 0 394 1279
assign 1 394 1280
addValue 1 394 1280
assign 1 394 1281
addValue 1 394 1281
assign 1 394 1282
new 0 394 1282
addValue 1 394 1283
addValue 1 396 1284
assign 1 398 1285
new 0 398 1285
assign 1 398 1286
addValue 1 398 1286
addValue 1 398 1287
assign 1 403 1292
new 0 403 1292
return 1 403 1293
assign 1 407 1297
new 0 407 1297
return 1 407 1298
assign 1 411 1304
new 0 411 1304
assign 1 411 1305
add 1 411 1305
assign 1 411 1306
add 1 411 1306
return 1 411 1307
assign 1 416 1311
new 0 416 1311
return 1 416 1312
assign 1 420 1317
getClassConfig 1 420 1317
assign 1 421 1318
fullEmitNameGet 0 421 1318
emitNameSet 1 421 1319
return 1 422 1320
assign 1 426 1325
getLocalClassConfig 1 426 1325
assign 1 427 1326
fullEmitNameGet 0 427 1326
emitNameSet 1 427 1327
return 1 428 1328
return 1 0 1331
assign 1 0 1334
return 1 0 1338
assign 1 0 1341
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1073009537: return bem_beginNs_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1926693913: return bem_synEmitPathGet_0();
case -1052944126: return bem_csynGet_0();
case -1910715228: return bem_libEmitNameGet_0();
case 1774940957: return bem_toString_0();
case -1413054881: return bem_smnlcsGet_0();
case -797225458: return bem_dynMethodsGet_0();
case -622039562: return bem_intNpGet_0();
case -1923547459: return bem_boolCcGet_0();
case -729571811: return bem_serializeToString_0();
case 498080472: return bem_mnodeGet_0();
case 2001798761: return bem_nlGet_0();
case -1841706211: return bem_returnTypeGet_0();
case -2039613615: return bem_instanceNotEqualGet_0();
case 1240611285: return bem_onceDecsGet_0();
case -206157822: return bem_coanyiantReturnsGet_0();
case -1727672536: return bem_propDecGet_0();
case 916491491: return bem_emitLib_0();
case -722876119: return bem_buildClassInfo_0();
case -402158238: return bem_inFilePathedGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case 1327064356: return bem_methodBodyGet_0();
case -786424307: return bem_tagGet_0();
case 1529527065: return bem_onceCountGet_0();
case -1081275759: return bem_classesInDepthOrderGet_0();
case -1369896794: return bem_objectNpGet_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case -1064889660: return bem_trueValueGet_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 104713553: return bem_new_0();
case -1795655423: return bem_propertyDecsGet_0();
case 89706405: return bem_ccCacheGet_0();
case 962646066: return bem_shlibeGet_0();
case -1317806639: return bem_baseMtdDecGet_0();
case 362974009: return bem_parentConfGet_0();
case -902412214: return bem_classCallsGet_0();
case -220901978: return bem_emitLangGet_0();
case -1498619679: return bem_getLibOutput_0();
case -946095539: return bem_mainInClassGet_0();
case -1241388883: return bem_lastMethodBodySizeGet_0();
case -101343106: return bem_nativeCSlotsGet_0();
case 2055025483: return bem_serializeContents_0();
case 5583797: return bem_maxDynArgsGet_0();
case -314718434: return bem_print_0();
case -681402717: return bem_boolTypeGet_0();
case 1820417453: return bem_create_0();
case -388723214: return bem_preClassGet_0();
case -991179882: return bem_qGet_0();
case -1109279973: return bem_spropDecGet_0();
case -1487140092: return bem_classEndGet_0();
case -727049506: return bem_exceptDecGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 361542143: return bem_classEmitsGet_0();
case -1449942744: return bem_instanceEqualGet_0();
case 1859739893: return bem_methodsGet_0();
case 236269941: return bem_ccMethodsGet_0();
case -1786051763: return bem_methodCatchGet_0();
case -1354714650: return bem_copy_0();
case -2085643372: return bem_stringNpGet_0();
case -1500143225: return bem_useDynMethodsGet_0();
case -1831751774: return bem_cnodeGet_0();
case 287040793: return bem_hashGet_0();
case 57260628: return bem_getClassOutput_0();
case -1755995201: return bem_transGet_0();
case -991255330: return bem_mainStartGet_0();
case -493012039: return bem_buildGet_0();
case 604504089: return bem_falseValueGet_0();
case -644675716: return bem_ntypesGet_0();
case -4647121: return bem_doEmit_0();
case 1102720804: return bem_classNameGet_0();
case -944442837: return bem_classConfGet_0();
case 1372235405: return bem_superCallsGet_0();
case -103017121: return bem_runtimeInitGet_0();
case -254265568: return bem_buildPropList_0();
case -1703922349: return bem_fullLibEmitNameGet_0();
case -1747980150: return bem_smnlecsGet_0();
case 772789066: return bem_libEmitPathGet_0();
case 603479476: return bem_allOnceDecsGet_0();
case 1177623581: return bem_callNamesGet_0();
case 36542021: return bem_mainEndGet_0();
case -397629001: return bem_maxSpillArgsLenGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case -1152064310: return bem_instOfGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case -294732055: return bem_floatNpGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case 1178070402: return bem_fileExtGet_0();
case 1312373307: return bem_buildCreate_0();
case -1711936384: return bem_baseSmtdDecGet_0();
case 1181505319: return bem_buildInitial_0();
case -229958684: return bem_constGet_0();
case -955058175: return bem_lastMethodBodyLinesGet_0();
case -1607412815: return bem_endNs_0();
case -845792839: return bem_iteratorGet_0();
case -378762597: return bem_boolNpGet_0();
case 1431933907: return bem_lastCallGet_0();
case 1074463609: return bem_saveSyns_0();
case 483359873: return bem_superNameGet_0();
case -1308786538: return bem_echo_0();
case -628036310: return bem_lastMethodsSizeGet_0();
case 1380285640: return bem_objectCcGet_0();
case -1947619572: return bem_msynGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1638160588: return bem_lineCountGet_0();
case -1967844855: return bem_initialDecGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -571409003: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -1053807407: return bem_trueValueSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 2142670547: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 2144776371: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 165152860: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1227314505: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -541207893: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case -1915611660: return bem_synEmitPathSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case -1702694534: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case -610957309: return bem_intNpSet_1(bevd_0);
case -386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -593061802: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 973728319: return bem_shlibeSet_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case -891329961: return bem_classCallsSet_1(bevd_0);
case -1887784556: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -980097629: return bem_qSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1820669521: return bem_cnodeSet_1(bevd_0);
case -945327254: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case -1073009536: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -90260853: return bem_nativeCSlotsSet_1(bevd_0);
case -1022041723: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case -1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1901078234: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case -596365949: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1912465206: return bem_boolCcSet_1(bevd_0);
case -377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case -943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case -1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -70425956: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case -16141842: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case -1980754914: return bem_oldacceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1936537319: return bem_msynSet_1(bevd_0);
case -551679723: return bem_formCast_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case -209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1438860491: return bem_instanceEqualSet_1(bevd_0);
case -1899632975: return bem_libEmitNameSet_1(bevd_0);
case -478502832: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -2110408325: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -193407613: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -391075985: return bem_inFilePathedSet_1(bevd_0);
case -36312873: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1041861873: return bem_csynSet_1(bevd_0);
case -1931824221: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -715967253: return bem_exceptDecSet_1(bevd_0);
case -1830623958: return bem_returnTypeSet_1(bevd_0);
case -1562282714: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case -1774969510: return bem_methodCatchSet_1(bevd_0);
case 614561729: return bem_allOnceDecsSet_1(bevd_0);
case 2118534024: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case -1358814541: return bem_objectNpSet_1(bevd_0);
case -1820890036: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case -2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case -65026440: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -627952553: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -508002125: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -707569329: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -724180734: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1604046278: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1697242261: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1978614329: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1671519971: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 297627956: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_5_8_BuildNamePath) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -722876117: return bem_buildClassInfo_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -569933480: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -6388749: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callHash) {
case -316092711: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -2023930725: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1591575024: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJSEmitter.bevs_inst = (BEC_2_5_9_BuildJSEmitter)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJSEmitter.bevs_inst;
}
}
}
