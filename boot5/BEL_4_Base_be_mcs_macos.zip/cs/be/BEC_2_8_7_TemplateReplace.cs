namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_8_7_TemplateReplace : BEC_2_6_6_SystemObject {
public BEC_2_8_7_TemplateReplace() { }
static BEC_2_8_7_TemplateReplace() { }
private static byte[] becc_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x65,0x70,0x6C,0x61,0x63,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x3C,0x3F,0x74,0x74};
private static byte[] bels_1 = {0x3F,0x3E};
private static byte[] bels_2 = {0x20};
public static new BEC_2_8_7_TemplateReplace bevs_inst;
public BEC_2_9_10_ContainerLinkedList bevp_steps;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_append;
public BEC_2_8_6_TemplateRunner bevp_runner;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_append = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_load_1(BEC_2_4_6_TextString beva_template) {
this.bem_load_2(beva_template, null);
return this;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_load_2(BEC_2_4_6_TextString beva_template, BEC_2_8_6_TemplateRunner beva__runner) {
BEC_2_4_6_TextString bevl_blStart = null;
BEC_2_4_6_TextString bevl_blEnd = null;
BEC_2_5_4_LogicBool bevl_onStart = null;
BEC_2_5_4_LogicBool bevl_nextIsCall = null;
BEC_2_4_6_TextString bevl_delim = null;
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_4_6_TextString bevl_payload = null;
BEC_2_9_10_ContainerLinkedList bevl_payloads = null;
BEC_2_7_8_ReplaceCallStep bevl_rcs = null;
BEC_2_4_6_TextString bevl_paypart = null;
BEC_2_7_7_ReplaceRunStep bevl_rs = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_7_10_ReplaceStringStep bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_7_10_ReplaceStringStep bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
bevp_runner = beva__runner;
bevp_size = beva_template.bem_sizeGet_0();
bevl_blStart = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_0));
bevl_blEnd = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_1));
bevl_onStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blStart;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
bevl_ds = bevl_delim.bem_sizeGet_0();
while (true)
 /* Line: 86 */ {
if (bevl_i == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 86 */ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 87 */ {
if (bevl_nextIsCall.bevi_bool) /* Line: 88 */ {
bevt_3_tmpany_phold = beva_template.bem_substring_2(bevl_last, bevl_i);
bevl_payload = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_strip_0();
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_2));
bevl_payloads = bevl_payload.bem_split_1(bevt_4_tmpany_phold);
if (bevp_runner == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 91 */ {
bevl_rcs = (BEC_2_7_8_ReplaceCallStep) (new BEC_2_7_8_ReplaceCallStep()).bem_new_1(bevl_payloads);
bevl_splits.bem_addValue_1(bevl_rcs);
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 95 */
 else  /* Line: 96 */ {
bevt_0_tmpany_loop = bevl_payloads.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 98 */ {
bevt_6_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 98 */ {
bevl_paypart = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_rs = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep()).bem_new_2(this, bevl_paypart);
bevl_splits.bem_addValue_1(bevl_rs);
} /* Line: 100 */
 else  /* Line: 98 */ {
break;
} /* Line: 98 */
} /* Line: 98 */
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 102 */
} /* Line: 91 */
 else  /* Line: 104 */ {
bevt_8_tmpany_phold = beva_template.bem_substring_2(bevl_last, bevl_i);
bevt_7_tmpany_phold = (BEC_2_7_10_ReplaceStringStep) (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_8_tmpany_phold);
bevl_splits.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 105 */
} /* Line: 88 */
bevl_last = bevl_i.bem_add_1(bevl_ds);
if (bevl_onStart.bevi_bool) /* Line: 109 */ {
bevl_onStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blEnd;
bevl_ds = bevl_delim.bem_sizeGet_0();
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 113 */
 else  /* Line: 114 */ {
bevl_onStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_delim = bevl_blStart;
bevl_ds = bevl_delim.bem_sizeGet_0();
} /* Line: 117 */
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
} /* Line: 119 */
 else  /* Line: 86 */ {
break;
} /* Line: 86 */
} /* Line: 86 */
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 121 */ {
bevt_11_tmpany_phold = beva_template.bem_substring_2(bevl_last, bevp_size);
bevt_10_tmpany_phold = (BEC_2_7_10_ReplaceStringStep) (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_11_tmpany_phold);
bevl_splits.bem_addValue_1(bevt_10_tmpany_phold);
} /* Line: 122 */
bevp_steps = bevl_splits;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_accept_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_out) {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_iter = bevp_steps.bem_iteratorGet_0();
while (true)
 /* Line: 129 */ {
bevt_0_tmpany_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 129 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_append.bevi_bool) /* Line: 131 */ {
bevt_1_tmpany_phold = bevl_s.bemd_1(2068442, BEL_4_Base.bevn_handle_1, beva_inst);
beva_out.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_1_tmpany_phold);
} /* Line: 132 */
} /* Line: 131 */
 else  /* Line: 129 */ {
break;
} /* Line: 129 */
} /* Line: 129 */
return beva_out;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() {
return bevp_steps;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_stepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_steps = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_appendGet_0() {
return bevp_append;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_appendSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_append = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_runnerGet_0() {
return bevp_runner;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_runnerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runner = (BEC_2_8_6_TemplateRunner) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {62, 69, 73, 74, 76, 77, 78, 79, 81, 82, 83, 84, 85, 86, 86, 87, 87, 89, 89, 90, 90, 91, 91, 93, 94, 95, 98, 0, 98, 98, 99, 100, 102, 105, 105, 105, 108, 110, 111, 112, 113, 115, 116, 117, 119, 121, 121, 122, 122, 122, 124, 128, 129, 130, 132, 132, 135, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 21, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 64, 69, 70, 75, 77, 78, 79, 80, 81, 86, 87, 88, 89, 92, 92, 95, 97, 98, 99, 105, 109, 110, 111, 114, 116, 117, 118, 119, 122, 123, 124, 126, 132, 137, 138, 139, 140, 142, 150, 153, 155, 157, 158, 165, 168, 171, 175, 178, 182, 185, 189, 192};
/* BEGIN LINEINFO 
assign 1 62 17
new 0 62 17
load 2 69 21
assign 1 73 51
assign 1 74 52
sizeGet 0 74 52
assign 1 76 53
new 0 76 53
assign 1 77 54
new 0 77 54
assign 1 78 55
new 0 78 55
assign 1 79 56
new 0 79 56
assign 1 81 57
assign 1 82 58
new 0 82 58
assign 1 83 59
new 0 83 59
assign 1 84 60
find 2 84 60
assign 1 85 61
sizeGet 0 85 61
assign 1 86 64
def 1 86 69
assign 1 87 70
greater 1 87 75
assign 1 89 77
substring 2 89 77
assign 1 89 78
strip 0 89 78
assign 1 90 79
new 0 90 79
assign 1 90 80
split 1 90 80
assign 1 91 81
undef 1 91 86
assign 1 93 87
new 1 93 87
addValue 1 94 88
assign 1 95 89
new 0 95 89
assign 1 98 92
linkedListIteratorGet 0 0 92
assign 1 98 95
hasNextGet 0 98 95
assign 1 98 97
nextGet 0 98 97
assign 1 99 98
new 2 99 98
addValue 1 100 99
assign 1 102 105
new 0 102 105
assign 1 105 109
substring 2 105 109
assign 1 105 110
new 1 105 110
addValue 1 105 111
assign 1 108 114
add 1 108 114
assign 1 110 116
new 0 110 116
assign 1 111 117
assign 1 112 118
sizeGet 0 112 118
assign 1 113 119
new 0 113 119
assign 1 115 122
new 0 115 122
assign 1 116 123
assign 1 117 124
sizeGet 0 117 124
assign 1 119 126
find 2 119 126
assign 1 121 132
lesser 1 121 137
assign 1 122 138
substring 2 122 138
assign 1 122 139
new 1 122 139
addValue 1 122 140
assign 1 124 142
assign 1 128 150
iteratorGet 0 128 150
assign 1 129 153
hasNextGet 0 129 153
assign 1 130 155
nextGet 0 130 155
assign 1 132 157
handle 1 132 157
write 1 132 158
return 1 135 165
return 1 0 168
assign 1 0 171
return 1 0 175
assign 1 0 178
return 1 0 182
assign 1 0 185
return 1 0 189
assign 1 0 192
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -723109216: return bem_stepsGet_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1908752755: return bem_appendGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -251179977: return bem_runnerGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case 474162694: return bem_sizeGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1097519336: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -712026963: return bem_stepsSet_1(bevd_0);
case -240097724: return bem_runnerSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1897670502: return bem_appendSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1097519335: return bem_load_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_8_6_TemplateRunner) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2146525509: return bem_accept_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_8_7_TemplateReplace();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_8_7_TemplateReplace.bevs_inst = (BEC_2_8_7_TemplateReplace)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_8_7_TemplateReplace.bevs_inst;
}
}
}
