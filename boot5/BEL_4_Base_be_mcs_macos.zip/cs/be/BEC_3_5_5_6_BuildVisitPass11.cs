namespace be {
/* IO:File: source/build/Pass11.be */
public sealed class BEC_3_5_5_6_BuildVisitPass11 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass11() { }
static BEC_3_5_5_6_BuildVisitPass11() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x31};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x31,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_1 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_2 = {0x74,0x68,0x72,0x6F,0x77};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_3 = {0x54,0x68,0x69,0x73,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x75,0x73,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x65,0x78,0x61,0x63,0x74,0x6C,0x79,0x20,0x6F,0x6E,0x65,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x2C,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 46));
private static byte[] bels_4 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_6 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_7 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_8 = {0x43,0x61,0x6C,0x6C,0x20,0x6E,0x6F,0x74,0x20,0x69,0x6E,0x20,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x70,0x6F,0x73,0x69,0x74,0x69,0x6F,0x6E};
private static byte[] bels_9 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_10 = {0x70,0x68,0x6F,0x6C,0x64};
private static byte[] bels_11 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_3_5_5_6_BuildVisitPass11 bevs_inst;
public BEC_2_5_4_BuildNode bevp_inMtd;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_fnode = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_5_4_BuildNode bevl_inode = null;
BEC_2_5_3_BuildVar bevl_ts = null;
BEC_2_5_4_BuildNode bevl_nsc = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_unwind = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_lastStep = null;
BEC_2_6_6_SystemObject bevl_pholdv = null;
BEC_2_6_6_SystemObject bevl_phold = null;
BEC_2_6_6_SystemObject bevl_prc = null;
BEC_2_6_6_SystemObject bevl_prcc = null;
BEC_2_6_6_SystemObject bevl_phold2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_108_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_109_tmpany_phold = null;
bevt_8_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_9_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
if (bevt_8_tmpany_phold.bevi_int == bevt_9_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 26 */ {
bevl_fnode = null;
bevt_14_tmpany_phold = beva_node.bem_containedGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_firstGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1696089045, BEL_4_Base.bevn_firstNodeGet_0);
if (bevt_11_tmpany_phold == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 28 */ {
bevl_fnode = beva_node.bem_nextDescendGet_0();
} /* Line: 29 */
bevt_17_tmpany_phold = beva_node.bem_containedGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_firstGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_it = bevt_15_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 31 */ {
bevt_18_tmpany_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_18_tmpany_phold != null && bevt_18_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpany_phold).bevi_bool) /* Line: 31 */ {
bevl_inode = (BEC_2_5_4_BuildNode) bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_fnode == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 33 */ {
bevl_fnode = bevl_inode;
} /* Line: 34 */
beva_node.bem_beforeInsert_1(bevl_inode);
} /* Line: 36 */
 else  /* Line: 31 */ {
break;
} /* Line: 31 */
} /* Line: 31 */
beva_node.bem_delete_0();
return bevl_fnode;
} /* Line: 39 */
bevt_21_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_22_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_21_tmpany_phold.bevi_int == bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 41 */ {
bevp_inMtd = beva_node;
bevt_25_tmpany_phold = beva_node.bem_heldGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_0));
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_26_tmpany_phold);
bevl_ts = (BEC_2_5_3_BuildVar) bevt_23_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_27_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_ts.bem_isTypedSet_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_node.bem_classGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_ts.bem_namepathSet_1(bevt_28_tmpany_phold);
} /* Line: 45 */
bevt_32_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_33_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_32_tmpany_phold.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_36_tmpany_phold = beva_node.bem_heldGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_1));
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_37_tmpany_phold);
if (bevt_34_tmpany_phold != null && bevt_34_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpany_phold).bevi_bool) /* Line: 52 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_40_tmpany_phold = beva_node.bem_heldGet_0();
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_2));
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_41_tmpany_phold);
if (bevt_38_tmpany_phold != null && bevt_38_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_38_tmpany_phold).bevi_bool) /* Line: 52 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 52 */ {
bevt_44_tmpany_phold = beva_node.bem_containedGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_lengthGet_0();
bevt_45_tmpany_phold = bevo_0;
if (bevt_43_tmpany_phold.bevi_int > bevt_45_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 52 */ {
bevt_48_tmpany_phold = bevo_1;
bevt_51_tmpany_phold = beva_node.bem_containedGet_0();
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_lengthGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_toString_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_49_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_47_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_46_tmpany_phold);
} /* Line: 53 */
bevt_54_tmpany_phold = beva_node.bem_heldGet_0();
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_4));
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_55_tmpany_phold);
if (bevt_52_tmpany_phold != null && bevt_52_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_52_tmpany_phold).bevi_bool) /* Line: 55 */ {
bevt_58_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_57_tmpany_phold == null) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevt_61_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(590009791, BEL_4_Base.bevn_impliedGet_0);
if (bevt_59_tmpany_phold != null && bevt_59_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpany_phold).bevi_bool) /* Line: 56 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 56 */
 else  /* Line: 56 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 56 */ {
bevl_nsc = beva_node.bem_firstGet_0();
if (bevl_nsc == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 64 */ {
bevt_64_tmpany_phold = bevl_nsc.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 64 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 64 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 64 */
 else  /* Line: 64 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 64 */ {
bevt_68_tmpany_phold = bevl_nsc.bem_heldGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_5));
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpany_phold);
if (bevt_66_tmpany_phold != null && bevt_66_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_66_tmpany_phold).bevi_bool) /* Line: 64 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 64 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 64 */
 else  /* Line: 64 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 64 */ {
} /* Line: 64 */
 else  /* Line: 66 */ {
bevt_70_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_70_tmpany_phold.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, null);
} /* Line: 68 */
} /* Line: 64 */
} /* Line: 56 */
bevt_73_tmpany_phold = beva_node.bem_heldGet_0();
bevt_72_tmpany_phold = bevt_73_tmpany_phold.bemd_0(-1319292247, BEL_4_Base.bevn_boundGet_0);
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_71_tmpany_phold != null && bevt_71_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_71_tmpany_phold).bevi_bool) /* Line: 72 */ {
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_75_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(-2084785257, BEL_4_Base.bevn_anyMapGet_0);
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_6));
bevl_v = bevt_74_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_76_tmpany_phold);
bevt_77_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_nd.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevl_v.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nd.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_78_tmpany_phold);
bevt_79_tmpany_phold = beva_node.bem_heldGet_0();
bevt_80_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_79_tmpany_phold.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_80_tmpany_phold);
beva_node.bem_prepend_1((BEC_2_5_4_BuildNode) bevl_nd);
} /* Line: 79 */
bevt_83_tmpany_phold = beva_node.bem_heldGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_7));
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_84_tmpany_phold);
if (bevt_81_tmpany_phold != null && bevt_81_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_81_tmpany_phold).bevi_bool) /* Line: 82 */ {
bevt_85_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpany_phold;
} /* Line: 83 */
bevl_unwind = be.BECS_Runtime.boolTrue;
bevl_c0 = beva_node.bem_containerGet_0();
if (bevl_c0 == null) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bels_8));
bevt_87_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_88_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_87_tmpany_phold);
} /* Line: 88 */
bevt_90_tmpany_phold = bevl_c0.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_91_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_91_tmpany_phold);
if (bevt_89_tmpany_phold != null && bevt_89_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_89_tmpany_phold).bevi_bool) /* Line: 92 */ {
bevt_94_tmpany_phold = bevl_c0.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_9));
bevt_92_tmpany_phold = bevt_93_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_95_tmpany_phold);
if (bevt_92_tmpany_phold != null && bevt_92_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_92_tmpany_phold).bevi_bool) /* Line: 92 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 92 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 92 */
 else  /* Line: 92 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 92 */ {
bevt_96_tmpany_phold = beva_node.bem_isSecondGet_0();
if (bevt_96_tmpany_phold.bevi_bool) /* Line: 92 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 92 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 92 */
 else  /* Line: 92 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 92 */ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 93 */
 else  /* Line: 92 */ {
bevt_98_tmpany_phold = bevl_c0.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_99_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_99_tmpany_phold);
if (bevt_97_tmpany_phold != null && bevt_97_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_97_tmpany_phold).bevi_bool) /* Line: 94 */ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 95 */
} /* Line: 92 */
if (bevl_unwind != null && bevl_unwind is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_unwind).bevi_bool) /* Line: 97 */ {
bevl_cnode = bevl_c0;
bevl_lastStep = null;
while (true)
 /* Line: 102 */ {
bevt_101_tmpany_phold = bevl_cnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_102_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_102_tmpany_phold);
if (bevt_100_tmpany_phold != null && bevt_100_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_100_tmpany_phold).bevi_bool) /* Line: 102 */ {
bevl_lastStep = bevl_cnode;
bevl_cnode = bevl_cnode.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 105 */
 else  /* Line: 102 */ {
break;
} /* Line: 102 */
} /* Line: 102 */
bevt_103_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_10));
bevl_pholdv = bevl_lastStep.bemd_2(1545079363, BEL_4_Base.bevn_tmpVar_2, bevt_103_tmpany_phold, bevp_build);
bevl_phold = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_104_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_104_tmpany_phold);
bevl_phold.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_pholdv);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_phold);
bevl_phold.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_prc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_prc.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_105_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_prc.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_105_tmpany_phold);
bevl_prcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_106_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_11));
bevl_prcc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_106_tmpany_phold);
bevl_prc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_prcc);
bevl_phold2 = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold2.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_107_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold2.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_107_tmpany_phold);
bevl_phold2.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_pholdv);
bevl_prc.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_phold2);
bevl_prc.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
bevl_lastStep.bemd_1(-1671186230, BEL_4_Base.bevn_beforeInsert_1, bevl_prc);
bevt_108_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_108_tmpany_phold;
} /* Line: 130 */
} /* Line: 97 */
bevt_109_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_109_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inMtdGet_0() {
return bevp_inMtd;
} /*method end*/
public BEC_3_5_5_6_BuildVisitPass11 bem_inMtdSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inMtd = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {26, 26, 26, 26, 27, 28, 28, 28, 28, 28, 28, 29, 31, 31, 31, 31, 31, 32, 33, 33, 34, 36, 38, 39, 41, 41, 41, 41, 42, 43, 43, 43, 43, 43, 44, 44, 45, 45, 45, 45, 50, 50, 50, 50, 52, 52, 52, 52, 0, 52, 52, 52, 52, 0, 0, 52, 52, 52, 52, 52, 0, 0, 0, 53, 53, 53, 53, 53, 53, 53, 55, 55, 55, 55, 56, 56, 56, 56, 56, 56, 56, 0, 0, 0, 63, 64, 64, 64, 64, 64, 64, 0, 0, 0, 64, 64, 64, 64, 0, 0, 0, 68, 68, 72, 72, 72, 73, 74, 75, 75, 75, 75, 76, 76, 77, 77, 78, 78, 78, 79, 82, 82, 82, 82, 83, 83, 85, 86, 87, 87, 88, 88, 88, 92, 92, 92, 92, 92, 92, 92, 0, 0, 0, 92, 0, 0, 0, 93, 94, 94, 94, 95, 98, 99, 102, 102, 102, 104, 105, 110, 110, 111, 112, 113, 113, 114, 115, 116, 117, 118, 119, 119, 120, 121, 121, 122, 123, 124, 125, 125, 126, 127, 128, 129, 130, 130, 133, 133, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {154, 155, 156, 161, 162, 163, 164, 165, 166, 167, 172, 173, 175, 176, 177, 178, 181, 183, 184, 189, 190, 192, 198, 199, 201, 202, 203, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 222, 223, 224, 229, 230, 231, 232, 233, 235, 238, 239, 240, 241, 243, 246, 250, 251, 252, 253, 258, 259, 262, 266, 269, 270, 271, 272, 273, 274, 275, 277, 278, 279, 280, 282, 283, 284, 289, 290, 291, 292, 294, 297, 301, 304, 305, 310, 311, 312, 313, 318, 319, 322, 326, 329, 330, 331, 332, 334, 337, 341, 346, 347, 351, 352, 353, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 370, 371, 372, 373, 375, 376, 378, 379, 380, 385, 386, 387, 388, 390, 391, 392, 394, 395, 396, 397, 399, 402, 406, 409, 411, 414, 418, 421, 424, 425, 426, 428, 432, 433, 436, 437, 438, 440, 441, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 476, 477, 480, 483};
/* BEGIN LINEINFO 
assign 1 26 154
typenameGet 0 26 154
assign 1 26 155
EXPRGet 0 26 155
assign 1 26 156
equals 1 26 161
assign 1 27 162
assign 1 28 163
containedGet 0 28 163
assign 1 28 164
firstGet 0 28 164
assign 1 28 165
containedGet 0 28 165
assign 1 28 166
firstNodeGet 0 28 166
assign 1 28 167
undef 1 28 172
assign 1 29 173
nextDescendGet 0 29 173
assign 1 31 175
containedGet 0 31 175
assign 1 31 176
firstGet 0 31 176
assign 1 31 177
containedGet 0 31 177
assign 1 31 178
iteratorGet 0 31 178
assign 1 31 181
hasNextGet 0 31 181
assign 1 32 183
nextGet 0 32 183
assign 1 33 184
undef 1 33 189
assign 1 34 190
beforeInsert 1 36 192
delete 0 38 198
return 1 39 199
assign 1 41 201
typenameGet 0 41 201
assign 1 41 202
METHODGet 0 41 202
assign 1 41 203
equals 1 41 208
assign 1 42 209
assign 1 43 210
heldGet 0 43 210
assign 1 43 211
anyMapGet 0 43 211
assign 1 43 212
new 0 43 212
assign 1 43 213
get 1 43 213
assign 1 43 214
heldGet 0 43 214
assign 1 44 215
new 0 44 215
isTypedSet 1 44 216
assign 1 45 217
classGet 0 45 217
assign 1 45 218
heldGet 0 45 218
assign 1 45 219
namepathGet 0 45 219
namepathSet 1 45 220
assign 1 50 222
typenameGet 0 50 222
assign 1 50 223
CALLGet 0 50 223
assign 1 50 224
equals 1 50 229
assign 1 52 230
heldGet 0 52 230
assign 1 52 231
nameGet 0 52 231
assign 1 52 232
new 0 52 232
assign 1 52 233
equals 1 52 233
assign 1 0 235
assign 1 52 238
heldGet 0 52 238
assign 1 52 239
nameGet 0 52 239
assign 1 52 240
new 0 52 240
assign 1 52 241
equals 1 52 241
assign 1 0 243
assign 1 0 246
assign 1 52 250
containedGet 0 52 250
assign 1 52 251
lengthGet 0 52 251
assign 1 52 252
new 0 52 252
assign 1 52 253
greater 1 52 258
assign 1 0 259
assign 1 0 262
assign 1 0 266
assign 1 53 269
new 0 53 269
assign 1 53 270
containedGet 0 53 270
assign 1 53 271
lengthGet 0 53 271
assign 1 53 272
toString 0 53 272
assign 1 53 273
add 1 53 273
assign 1 53 274
new 2 53 274
throw 1 53 275
assign 1 55 277
heldGet 0 55 277
assign 1 55 278
nameGet 0 55 278
assign 1 55 279
new 0 55 279
assign 1 55 280
equals 1 55 280
assign 1 56 282
heldGet 0 56 282
assign 1 56 283
rtypeGet 0 56 283
assign 1 56 284
def 1 56 289
assign 1 56 290
heldGet 0 56 290
assign 1 56 291
rtypeGet 0 56 291
assign 1 56 292
impliedGet 0 56 292
assign 1 0 294
assign 1 0 297
assign 1 0 301
assign 1 63 304
firstGet 0 63 304
assign 1 64 305
def 1 64 310
assign 1 64 311
typenameGet 0 64 311
assign 1 64 312
VARGet 0 64 312
assign 1 64 313
equals 1 64 318
assign 1 0 319
assign 1 0 322
assign 1 0 326
assign 1 64 329
heldGet 0 64 329
assign 1 64 330
nameGet 0 64 330
assign 1 64 331
new 0 64 331
assign 1 64 332
equals 1 64 332
assign 1 0 334
assign 1 0 337
assign 1 0 341
assign 1 68 346
heldGet 0 68 346
rtypeSet 1 68 347
assign 1 72 351
heldGet 0 72 351
assign 1 72 352
boundGet 0 72 352
assign 1 72 353
not 0 72 353
assign 1 73 355
new 1 73 355
copyLoc 1 74 356
assign 1 75 357
heldGet 0 75 357
assign 1 75 358
anyMapGet 0 75 358
assign 1 75 359
new 0 75 359
assign 1 75 360
get 1 75 360
assign 1 76 361
VARGet 0 76 361
typenameSet 1 76 362
assign 1 77 363
heldGet 0 77 363
heldSet 1 77 364
assign 1 78 365
heldGet 0 78 365
assign 1 78 366
new 0 78 366
boundSet 1 78 367
prepend 1 79 368
assign 1 82 370
heldGet 0 82 370
assign 1 82 371
nameGet 0 82 371
assign 1 82 372
new 0 82 372
assign 1 82 373
equals 1 82 373
assign 1 83 375
nextDescendGet 0 83 375
return 1 83 376
assign 1 85 378
new 0 85 378
assign 1 86 379
containerGet 0 86 379
assign 1 87 380
undef 1 87 385
assign 1 88 386
new 0 88 386
assign 1 88 387
new 2 88 387
throw 1 88 388
assign 1 92 390
typenameGet 0 92 390
assign 1 92 391
CALLGet 0 92 391
assign 1 92 392
equals 1 92 392
assign 1 92 394
heldGet 0 92 394
assign 1 92 395
nameGet 0 92 395
assign 1 92 396
new 0 92 396
assign 1 92 397
equals 1 92 397
assign 1 0 399
assign 1 0 402
assign 1 0 406
assign 1 92 409
isSecondGet 0 92 409
assign 1 0 411
assign 1 0 414
assign 1 0 418
assign 1 93 421
new 0 93 421
assign 1 94 424
typenameGet 0 94 424
assign 1 94 425
BRACESGet 0 94 425
assign 1 94 426
equals 1 94 426
assign 1 95 428
new 0 95 428
assign 1 98 432
assign 1 99 433
assign 1 102 436
typenameGet 0 102 436
assign 1 102 437
BRACESGet 0 102 437
assign 1 102 438
notEquals 1 102 438
assign 1 104 440
assign 1 105 441
containerGet 0 105 441
assign 1 110 447
new 0 110 447
assign 1 110 448
tmpVar 2 110 448
assign 1 111 449
new 1 111 449
copyLoc 1 112 450
assign 1 113 451
VARGet 0 113 451
typenameSet 1 113 452
heldSet 1 114 453
replaceWith 1 115 454
addVariable 0 116 455
assign 1 117 456
new 1 117 456
copyLoc 1 118 457
assign 1 119 458
CALLGet 0 119 458
typenameSet 1 119 459
assign 1 120 460
new 0 120 460
assign 1 121 461
new 0 121 461
nameSet 1 121 462
heldSet 1 122 463
assign 1 123 464
new 1 123 464
copyLoc 1 124 465
assign 1 125 466
VARGet 0 125 466
typenameSet 1 125 467
heldSet 1 126 468
addValue 1 127 469
addValue 1 128 470
beforeInsert 1 129 471
assign 1 130 472
nextDescendGet 0 130 472
return 1 130 473
assign 1 133 476
nextDescendGet 0 133 476
return 1 133 477
return 1 0 480
assign 1 0 483
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -850314193: return bem_inMtdGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -839231940: return bem_inMtdSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitPass11();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitPass11.bevs_inst = (BEC_3_5_5_6_BuildVisitPass11)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitPass11.bevs_inst;
}
}
}
