namespace be {

using System;
    /* IO:File: source/base/OpiFc.be */
public sealed class BEC_2_6_19_SystemObjectFieldIterator : BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemObjectFieldIterator() { }
static BEC_2_6_19_SystemObjectFieldIterator() { }

public System.Reflection.FieldInfo[] fields;
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x46,0x69,0x65,0x6C,0x64,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
public static new BEC_2_6_19_SystemObjectFieldIterator bevs_inst;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_6_6_SystemObject bevp_instance;
public BEC_2_5_4_LogicBool bevp_advanced;
public BEC_2_5_4_LogicBool bevp_done;
public BEC_2_5_4_LogicBool bevp_tval;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_1(BEC_2_6_6_SystemObject beva__instance) {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = this.bem_new_2(beva__instance, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_2(BEC_2_6_6_SystemObject beva__instance, BEC_2_5_4_LogicBool beva_forceFirstSlot) {
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_instance = beva__instance;
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_done = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_tval = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;

    fields = bevp_instance.GetType().GetFields();
    return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advance_0() {

    string prefix = "bevp_";
    int i = bevp_pos.bevi_int;
    i++;
    while (i < fields.Length) {
      if (fields[i].Name.StartsWith(prefix)) {
        bevp_advanced = bevp_tval;
        bevp_pos.bevi_int = i;
        return this;
      }
      i++;
    }
    bevp_done = bevp_tval;
    return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 107 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 107 */ {
if (bevp_done.bevi_bool) /* Line: 107 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 107 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 107 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 107 */ {
this.bem_advance_0();
} /* Line: 108 */
if (!(bevp_done.bevi_bool)) /* Line: 110 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 111 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextNameGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 117 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 117 */ {
if (bevp_done.bevi_bool) /* Line: 117 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 117 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 117 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 117 */ {
this.bem_advance_0();
} /* Line: 118 */
if (bevp_done.bevi_bool) /* Line: 120 */ {
return null;
} /* Line: 121 */
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = this.bem_currentNameGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_currentNameGet_0() {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;

    bevl_res = new BEC_2_4_6_TextString(fields[bevp_pos.bevi_int].Name);
    bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevt_0_tmpany_phold = bevl_res.bem_substring_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 148 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 148 */ {
if (bevp_done.bevi_bool) /* Line: 148 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 148 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 148 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 148 */ {
this.bem_advance_0();
} /* Line: 149 */
if (bevp_done.bevi_bool) /* Line: 151 */ {
return null;
} /* Line: 152 */
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = this.bem_currentGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() {
BEC_2_6_6_SystemObject bevl_res = null;

    bevl_res = (BEC_2_6_6_SystemObject) (fields[bevp_pos.bevi_int].GetValue(bevp_instance));
    return bevl_res;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_advanced.bevi_bool) /* Line: 179 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 179 */ {
if (bevp_done.bevi_bool) /* Line: 179 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 179 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 179 */
if (!(bevt_0_tmpany_anchor.bevi_bool)) /* Line: 179 */ {
this.bem_advance_0();
} /* Line: 180 */
if (bevp_done.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 182 */ {
this.bem_currentSet_1(beva_value);
} /* Line: 183 */
bevp_advanced = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_currentSet_1(BEC_2_6_6_SystemObject beva_value) {

    fields[bevp_pos.bevi_int].SetValue(bevp_instance, beva_value);
    return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 207 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 207 */ {
this.bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 207 */
 else  /* Line: 207 */ {
break;
} /* Line: 207 */
} /* Line: 207 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceGet_0() {
return bevp_instance;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instanceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_instance = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_advancedGet_0() {
return bevp_advanced;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advancedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_advanced = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doneGet_0() {
return bevp_done;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_doneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_done = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_tvalGet_0() {
return bevp_tval;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_tvalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tval = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {36, 36, 36, 41, 42, 43, 44, 45, 0, 0, 0, 108, 111, 111, 113, 113, 0, 0, 0, 118, 121, 123, 124, 124, 144, 144, 144, 0, 0, 0, 149, 152, 154, 155, 155, 175, 0, 0, 0, 180, 182, 182, 183, 185, 207, 207, 207, 208, 207, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 26, 29, 30, 31, 32, 33, 59, 63, 66, 70, 73, 74, 76, 77, 83, 87, 90, 94, 97, 99, 100, 101, 109, 110, 111, 117, 121, 124, 128, 131, 133, 134, 135, 141, 147, 151, 154, 158, 160, 165, 166, 168, 179, 182, 187, 188, 189, 198, 201, 205, 208, 212, 215, 219, 222, 226, 229};
/* BEGIN LINEINFO 
assign 1 36 24
new 0 36 24
assign 1 36 25
new 2 36 25
return 1 36 26
assign 1 41 29
new 0 41 29
assign 1 42 30
assign 1 43 31
new 0 43 31
assign 1 44 32
new 0 44 32
assign 1 45 33
new 0 45 33
assign 1 0 59
assign 1 0 63
assign 1 0 66
advance 0 108 70
assign 1 111 73
new 0 111 73
return 1 111 74
assign 1 113 76
new 0 113 76
return 1 113 77
assign 1 0 83
assign 1 0 87
assign 1 0 90
advance 0 118 94
return 1 121 97
assign 1 123 99
new 0 123 99
assign 1 124 100
currentNameGet 0 124 100
return 1 124 101
assign 1 144 109
new 0 144 109
assign 1 144 110
substring 1 144 110
return 1 144 111
assign 1 0 117
assign 1 0 121
assign 1 0 124
advance 0 149 128
return 1 152 131
assign 1 154 133
new 0 154 133
assign 1 155 134
currentGet 0 155 134
return 1 155 135
return 1 175 141
assign 1 0 147
assign 1 0 151
assign 1 0 154
advance 0 180 158
assign 1 182 160
not 0 182 165
currentSet 1 183 166
assign 1 185 168
new 0 185 168
assign 1 207 179
new 0 207 179
assign 1 207 182
lesser 1 207 187
nextSet 1 208 188
incrementValue 0 207 189
return 1 0 198
assign 1 0 201
return 1 0 205
assign 1 0 208
return 1 0 212
assign 1 0 215
return 1 0 219
assign 1 0 222
return 1 0 226
assign 1 0 229
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -809133133: return bem_advance_0();
case 104713553: return bem_new_0();
case 715968403: return bem_posGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -1944843197: return bem_currentNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 22448773: return bem_advancedGet_0();
case 1622993701: return bem_doneGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case -1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -663945382: return bem_tvalGet_0();
case 1820417453: return bem_create_0();
case -1405080078: return bem_instanceGet_0();
case -786424307: return bem_tagGet_0();
case -1048393719: return bem_nextNameGet_0();
case -1354714650: return bem_copy_0();
case 108485850: return bem_hasNextGet_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -900559503: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -652863129: return bem_tvalSet_1(bevd_0);
case -1393997825: return bem_instanceSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 33531026: return bem_advancedSet_1(bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 727050656: return bem_posSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1634075954: return bem_doneSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_19_SystemObjectFieldIterator.bevs_inst = (BEC_2_6_19_SystemObjectFieldIterator)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_19_SystemObjectFieldIterator.bevs_inst;
}
}
}
