namespace be {
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_11_BuildClassConfig : BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildClassConfig() { }
static BEC_2_5_11_BuildClassConfig() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x43,0x6F,0x6E,0x66,0x69,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x62,0x65};
private static byte[] bels_1 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 4));
public static new BEC_2_5_11_BuildClassConfig bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_5_10_BuildEmitCommon bevp_emitter;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_nameSpace;
public BEC_2_4_6_TextString bevp_emitName;
public BEC_2_4_6_TextString bevp_fullEmitName;
public BEC_3_2_4_4_IOFilePath bevp_classPath;
public BEC_3_2_4_4_IOFilePath bevp_classDir;
public BEC_3_2_4_4_IOFilePath bevp_synPath;
public virtual BEC_2_5_11_BuildClassConfig bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_5_10_BuildEmitCommon beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevp_emitPath = beva__emitPath;
bevp_libName = beva__libName;
bevp_nameSpace = bevp_emitter.bem_getNameSpace_1(bevp_libName);
bevp_emitName = bevp_emitter.bem_getEmitName_1(bevp_np);
bevp_fullEmitName = (BEC_2_4_6_TextString) bevp_emitter.bem_getFullEmitName_2(bevp_nameSpace, bevp_emitName);
bevt_2_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_emitPath.bem_copy_0();
bevt_3_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_1_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_2_tmpany_phold.bem_addStep_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_0));
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_1_tmpany_phold.bem_addStep_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_5_tmpany_phold = bevp_emitName.bem_add_1(bevt_6_tmpany_phold);
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bem_addStep_1(bevt_5_tmpany_phold);
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevp_classPath.bem_parentGet_0();
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_classDir.bem_copy_0();
bevt_9_tmpany_phold = bevo_0;
bevt_8_tmpany_phold = bevp_emitName.bem_add_1(bevt_9_tmpany_phold);
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_7_tmpany_phold.bem_addStep_1(bevt_8_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_relEmitName_1(BEC_2_4_6_TextString beva_forLibName) {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_npGet_0() {
return bevp_np;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildEmitCommon bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameSpaceGet_0() {
return bevp_nameSpace;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nameSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitNameGet_0() {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_fullEmitNameGet_0() {
return bevp_fullEmitName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fullEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classPathGet_0() {
return bevp_classPath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_classPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classDirGet_0() {
return bevp_classDir;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_classDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_synPathGet_0() {
return bevp_synPath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_synPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {2059, 2060, 2061, 2062, 2064, 2065, 2066, 2067, 2067, 2067, 2067, 2067, 2067, 2067, 2067, 2068, 2069, 2069, 2069, 2069, 2076, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 56, 59, 62, 66, 69, 73, 76, 80, 83, 87, 90, 94, 97, 101, 104, 108, 111, 115, 118, 122, 125};
/* BEGIN LINEINFO 
assign 1 2059 33
assign 1 2060 34
assign 1 2061 35
assign 1 2062 36
assign 1 2064 37
getNameSpace 1 2064 37
assign 1 2065 38
getEmitName 1 2065 38
assign 1 2066 39
getFullEmitName 2 2066 39
assign 1 2067 40
copy 0 2067 40
assign 1 2067 41
emitLangGet 0 2067 41
assign 1 2067 42
addStep 1 2067 42
assign 1 2067 43
new 0 2067 43
assign 1 2067 44
addStep 1 2067 44
assign 1 2067 45
fileExtGet 0 2067 45
assign 1 2067 46
add 1 2067 46
assign 1 2067 47
addStep 1 2067 47
assign 1 2068 48
parentGet 0 2068 48
assign 1 2069 49
copy 0 2069 49
assign 1 2069 50
new 0 2069 50
assign 1 2069 51
add 1 2069 51
assign 1 2069 52
addStep 1 2069 52
return 1 2076 56
return 1 0 59
assign 1 0 62
return 1 0 66
assign 1 0 69
return 1 0 73
assign 1 0 76
return 1 0 80
assign 1 0 83
return 1 0 87
assign 1 0 90
return 1 0 94
assign 1 0 97
return 1 0 101
assign 1 0 104
return 1 0 108
assign 1 0 111
return 1 0 115
assign 1 0 118
return 1 0 122
assign 1 0 125
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -2144850726: return bem_fullEmitNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -2028575047: return bem_emitterGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -2097068593: return bem_emitPathGet_0();
case -485605591: return bem_emitNameGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 2116315365: return bem_npGet_0();
case -1803479881: return bem_libNameGet_0();
case 89969932: return bem_nameSpaceGet_0();
case 1820417453: return bem_create_0();
case 1323273874: return bem_classDirGet_0();
case -786424307: return bem_tagGet_0();
case -508742198: return bem_classPathGet_0();
case -1354714650: return bem_copy_0();
case 738990714: return bem_synPathGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 750072967: return bem_synPathSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1792397628: return bem_libNameSet_1(bevd_0);
case 101052185: return bem_nameSpaceSet_1(bevd_0);
case -2133768473: return bem_fullEmitNameSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -474523338: return bem_emitNameSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 2127397618: return bem_npSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 657164969: return bem_relEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1334356127: return bem_classDirSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -2017492794: return bem_emitterSet_1(bevd_0);
case -2085986340: return bem_emitPathSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -497659945: return bem_classPathSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 104713557: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, (BEC_2_5_10_BuildEmitCommon) bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_11_BuildClassConfig();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_11_BuildClassConfig.bevs_inst = (BEC_2_5_11_BuildClassConfig)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_11_BuildClassConfig.bevs_inst;
}
}
}
