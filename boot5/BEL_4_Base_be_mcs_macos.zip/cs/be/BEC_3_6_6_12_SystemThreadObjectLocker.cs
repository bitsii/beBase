namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_3_6_6_12_SystemThreadObjectLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_12_SystemThreadObjectLocker() { }
static BEC_3_6_6_12_SystemThreadObjectLocker() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_12_SystemThreadObjectLocker bevs_inst;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_obj;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
return this;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_new_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_6_6_SystemObject bevl_e = null;
this.bem_new_0();
bevp_lock.bem_lock_0();
try  /* Line: 1139 */ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1141 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1144 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_oGet_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1150 */ {
bevl_r = bevp_obj;
bevp_lock.bem_unlock_0();
} /* Line: 1152 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1155 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1162 */ {
bevl_r = bevp_obj;
bevp_obj = null;
bevp_lock.bem_unlock_0();
} /* Line: 1165 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1168 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_setIfClear_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_5_4_LogicBool bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevp_lock.bem_lock_0();
bevl_res = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 1176 */ {
if (bevp_obj == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1177 */ {
bevp_obj = beva__obj;
bevl_res = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1179 */
bevp_lock.bem_unlock_0();
} /* Line: 1181 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1184 */
return bevl_res;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_oSet_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1191 */ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1193 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1196 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objectGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_oGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objectSet_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_oSet_1(beva__obj);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objGet_0() {
return bevp_obj;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_obj = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1129, 1134, 1138, 1140, 1141, 1143, 1144, 1149, 1151, 1152, 1154, 1155, 1157, 1161, 1163, 1164, 1165, 1167, 1168, 1170, 1174, 1175, 1177, 1177, 1178, 1179, 1181, 1183, 1184, 1186, 1190, 1192, 1193, 1195, 1196, 1201, 1201, 1205, 1205, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 22, 23, 25, 26, 30, 31, 38, 40, 41, 45, 46, 48, 53, 55, 56, 57, 61, 62, 64, 70, 71, 73, 78, 79, 80, 82, 86, 87, 89, 93, 95, 96, 100, 101, 107, 108, 112, 113, 116, 119, 123, 126};
/* BEGIN LINEINFO 
assign 1 1129 17
new 0 1129 17
new 0 1134 22
lock 0 1138 23
assign 1 1140 25
unlock 0 1141 26
unlock 0 1143 30
throw 1 1144 31
lock 0 1149 38
assign 1 1151 40
unlock 0 1152 41
unlock 0 1154 45
throw 1 1155 46
return 1 1157 48
lock 0 1161 53
assign 1 1163 55
assign 1 1164 56
unlock 0 1165 57
unlock 0 1167 61
throw 1 1168 62
return 1 1170 64
lock 0 1174 70
assign 1 1175 71
new 0 1175 71
assign 1 1177 73
undef 1 1177 78
assign 1 1178 79
assign 1 1179 80
new 0 1179 80
unlock 0 1181 82
unlock 0 1183 86
throw 1 1184 87
return 1 1186 89
lock 0 1190 93
assign 1 1192 95
unlock 0 1193 96
unlock 0 1195 100
throw 1 1196 101
assign 1 1201 107
oGet 0 1201 107
return 1 1201 108
assign 1 1205 112
oSet 1 1205 112
return 1 1205 113
return 1 0 116
assign 1 0 119
return 1 0 123
assign 1 0 126
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case -952571108: return bem_lockGet_0();
case -1048438184: return bem_oGet_0();
case 2055025483: return bem_serializeContents_0();
case -1299793528: return bem_objectGet_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 62849744: return bem_objGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1572587741: return bem_getAndClear_0();
case 1102720804: return bem_classNameGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1037355931: return bem_oSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 634688672: return bem_setIfClear_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1288711275: return bem_objectSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 73931997: return bem_objSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -941488855: return bem_lockSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_12_SystemThreadObjectLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_12_SystemThreadObjectLocker.bevs_inst = (BEC_3_6_6_12_SystemThreadObjectLocker)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_12_SystemThreadObjectLocker.bevs_inst;
}
}
}
