namespace be {
/* IO:File: source/build/Transport.be */
public sealed class BEC_2_5_9_BuildTransport : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransport() { }
static BEC_2_5_9_BuildTransport() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 37));
private static byte[] bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 10));
private static byte[] bels_3 = {0x4E,0x6F,0x64,0x65,0x3A};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 5));
private static byte[] bels_4 = {0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x62,0x79};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_4, 12));
private static byte[] bels_5 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_5, 44));
private static byte[] bels_6 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_6, 10));
private static byte[] bels_7 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bels_8 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_9 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bels_10 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_11 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_12 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static new BEC_2_5_9_BuildTransport bevs_inst;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_5_4_BuildNode bevp_outermost;
public BEC_2_5_4_BuildNode bevp_current;
public BEC_2_5_9_BuildTransport bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_new_2(BEC_2_5_5_BuildBuild beva__build, BEC_2_5_4_BuildNode beva__outermost) {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_traverse_1(BEC_3_5_5_7_BuildVisitVisitor beva_visitor) {
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
try  /* Line: 38 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 43 */ {
if (bevl_node == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 44 */
 else  /* Line: 43 */ {
break;
} /* Line: 43 */
} /* Line: 43 */
beva_visitor.bem_end_1(this);
} /* Line: 47 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_2_tmpany_phold = bevo_0;
bevt_2_tmpany_phold.bem_print_0();
bevt_3_tmpany_phold = bevo_1;
bevt_3_tmpany_phold.bem_print_0();
bevl_e.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
bevt_4_tmpany_phold = bevo_2;
bevt_4_tmpany_phold.bem_print_0();
bevl_node.bem_print_0();
bevl_nc = bevl_node.bem_containerGet_0();
while (true)
 /* Line: 56 */ {
if (bevl_nc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevt_6_tmpany_phold = bevo_3;
bevt_6_tmpany_phold.bem_print_0();
bevl_nc.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
bevl_nc = bevl_nc.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 59 */
 else  /* Line: 56 */ {
break;
} /* Line: 56 */
} /* Line: 56 */
} /* Line: 56 */
 else  /* Line: 61 */ {
bevt_7_tmpany_phold = bevo_4;
bevt_7_tmpany_phold.bem_print_0();
bevt_8_tmpany_phold = bevo_5;
bevt_8_tmpany_phold.bem_print_0();
bevl_e.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
} /* Line: 64 */
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 66 */
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_contain_0() {
BEC_2_9_3_ContainerMap bevl_conTypes = null;
BEC_2_5_4_BuildNode bevl_curr = null;
BEC_2_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_5_4_BuildNode bevl_wf = null;
BEC_2_5_4_BuildNode bevl_cnode = null;
BEC_2_5_4_BuildNode bevl_mnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_9_BuildConstants bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
bevt_7_tmpany_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_tmpany_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 75 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 75 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevl_i.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_node.bem_delayDeleteGet_0();
if (bevt_10_tmpany_phold.bevi_bool) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevt_12_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_13_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_12_tmpany_phold.bevi_int == bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevt_15_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_16_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_15_tmpany_phold.bevi_int == bevt_16_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 80 */
 else  /* Line: 80 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 80 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 84 */ {
if (bevl_wf == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_19_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_20_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_19_tmpany_phold.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_22_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_23_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_22_tmpany_phold.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 85 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_25_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_26_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
if (bevt_25_tmpany_phold.bevi_int == bevt_26_tmpany_phold.bevi_int) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 85 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 84 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
 else  /* Line: 84 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 85 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 86 */
 else  /* Line: 84 */ {
break;
} /* Line: 84 */
} /* Line: 84 */
if (bevl_wf == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_29_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_30_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_29_tmpany_phold.bevi_int == bevt_30_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_32_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_33_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_32_tmpany_phold.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 88 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 88 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 88 */
 else  /* Line: 88 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 88 */ {
bevl_cnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_7));
bevl_cnode.bem_heldSet_1(bevt_35_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 95 */
} /* Line: 88 */
bevt_37_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_38_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_37_tmpany_phold.bevi_int == bevt_38_tmpany_phold.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_41_tmpany_phold = bevl_curr.bem_containerGet_0();
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_typenameGet_0();
bevt_42_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_40_tmpany_phold.bevi_int == bevt_42_tmpany_phold.bevi_int) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevt_44_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_45_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_44_tmpany_phold.bevi_int == bevt_45_tmpany_phold.bevi_int) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 98 */ {
bevl_mnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_8));
bevl_mnode.bem_heldSet_1(bevt_47_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 104 */
bevt_49_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_50_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_49_tmpany_phold.bevi_int == bevt_50_tmpany_phold.bevi_int) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 107 */ {
bevt_52_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_53_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_52_tmpany_phold.bevi_int == bevt_53_tmpany_phold.bevi_int) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 107 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 107 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 107 */
 else  /* Line: 107 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 107 */ {
bevl_mnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_9));
bevl_mnode.bem_heldSet_1(bevt_55_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 113 */
bevt_57_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_58_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
if (bevt_57_tmpany_phold.bevi_int == bevt_58_tmpany_phold.bevi_int) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 117 */
 else  /* Line: 116 */ {
bevt_60_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_61_tmpany_phold = bevp_ntypes.bem_RIDXGet_0();
if (bevt_60_tmpany_phold.bevi_int == bevt_61_tmpany_phold.bevi_int) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 119 */
 else  /* Line: 116 */ {
bevt_63_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_64_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_63_tmpany_phold.bevi_int == bevt_64_tmpany_phold.bevi_int) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 122 */ {
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bels_10));
bevt_66_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_67_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_66_tmpany_phold);
} /* Line: 123 */
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bels_11));
bevt_69_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_70_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_69_tmpany_phold);
} /* Line: 127 */
} /* Line: 126 */
 else  /* Line: 129 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 130 */
} /* Line: 116 */
} /* Line: 116 */
bevt_72_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_71_tmpany_phold = bevl_conTypes.bem_has_1(bevt_72_tmpany_phold);
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevl_curr = bevl_node;
} /* Line: 133 */
} /* Line: 132 */
} /* Line: 79 */
 else  /* Line: 75 */ {
break;
} /* Line: 75 */
} /* Line: 75 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_stepBack_1(BEC_2_5_4_BuildNode beva_curr) {
BEC_2_5_4_BuildNode bevl_hop = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 141 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bels_12));
bevt_1_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpany_phold, beva_curr);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 142 */
return bevl_hop;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_outermostGet_0() {
return bevp_outermost;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_outermostSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {20, 21, 21, 22, 23, 25, 25, 26, 26, 30, 31, 31, 32, 33, 39, 41, 43, 43, 44, 47, 49, 49, 50, 50, 51, 51, 52, 53, 53, 54, 55, 56, 56, 57, 57, 58, 59, 62, 62, 63, 63, 64, 66, 71, 71, 72, 73, 74, 75, 75, 78, 79, 79, 79, 80, 80, 80, 80, 80, 80, 80, 80, 0, 0, 0, 83, 84, 84, 84, 84, 84, 84, 0, 84, 84, 84, 84, 0, 0, 0, 85, 85, 85, 85, 0, 0, 0, 0, 0, 86, 88, 88, 88, 88, 88, 88, 0, 88, 88, 88, 88, 0, 0, 0, 0, 0, 91, 92, 92, 93, 93, 94, 95, 98, 98, 98, 98, 98, 98, 98, 98, 98, 0, 0, 0, 98, 98, 98, 98, 0, 0, 0, 100, 101, 101, 102, 102, 103, 104, 107, 107, 107, 107, 107, 107, 107, 107, 0, 0, 0, 109, 110, 110, 111, 111, 112, 113, 116, 116, 116, 116, 117, 118, 118, 118, 118, 119, 120, 120, 120, 120, 121, 122, 122, 123, 123, 123, 125, 126, 126, 127, 127, 127, 130, 132, 132, 133, 140, 141, 141, 142, 142, 142, 144, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {36, 37, 38, 39, 40, 41, 42, 43, 44, 49, 50, 51, 52, 53, 70, 71, 74, 79, 80, 86, 90, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 107, 112, 113, 114, 115, 116, 124, 125, 126, 127, 128, 130, 216, 217, 218, 219, 220, 221, 224, 226, 227, 228, 233, 234, 235, 236, 241, 242, 243, 244, 249, 250, 253, 257, 260, 263, 268, 269, 270, 271, 276, 277, 280, 281, 282, 287, 288, 291, 295, 298, 299, 300, 305, 306, 309, 313, 316, 320, 323, 329, 334, 335, 336, 337, 342, 343, 346, 347, 348, 353, 354, 357, 361, 364, 368, 371, 372, 373, 374, 375, 376, 377, 380, 381, 382, 387, 388, 389, 390, 391, 396, 397, 400, 404, 407, 408, 409, 414, 415, 418, 422, 425, 426, 427, 428, 429, 430, 431, 433, 434, 435, 440, 441, 442, 443, 448, 449, 452, 456, 459, 460, 461, 462, 463, 464, 465, 467, 468, 469, 474, 475, 478, 479, 480, 485, 486, 489, 490, 491, 496, 497, 498, 503, 504, 505, 506, 508, 509, 514, 515, 516, 517, 521, 525, 526, 528, 543, 544, 549, 550, 551, 552, 554, 557, 560, 564, 567, 571, 574, 578, 581};
/* BEGIN LINEINFO 
assign 1 20 36
assign 1 21 37
constantsGet 0 21 37
assign 1 21 38
ntypesGet 0 21 38
assign 1 22 39
new 1 22 39
assign 1 23 40
assign 1 25 41
TRANSUNITGet 0 25 41
typenameSet 1 25 42
assign 1 26 43
new 0 26 43
heldSet 1 26 44
assign 1 30 49
assign 1 31 50
constantsGet 0 31 50
assign 1 31 51
ntypesGet 0 31 51
assign 1 32 52
assign 1 33 53
begin 1 39 70
assign 1 41 71
accept 1 41 71
assign 1 43 74
def 1 43 79
assign 1 44 80
accept 1 44 80
end 1 47 86
assign 1 49 90
def 1 49 95
assign 1 50 96
new 0 50 96
print 0 50 97
assign 1 51 98
new 0 51 98
print 0 51 99
print 0 52 100
assign 1 53 101
new 0 53 101
print 0 53 102
print 0 54 103
assign 1 55 104
containerGet 0 55 104
assign 1 56 107
def 1 56 112
assign 1 57 113
new 0 57 113
print 0 57 114
print 0 58 115
assign 1 59 116
containerGet 0 59 116
assign 1 62 124
new 0 62 124
print 0 62 125
assign 1 63 126
new 0 63 126
print 0 63 127
print 0 64 128
throw 1 66 130
assign 1 71 216
constantsGet 0 71 216
assign 1 71 217
conTypesGet 0 71 217
assign 1 72 218
assign 1 73 219
containedGet 0 73 219
containedSet 1 74 220
assign 1 75 221
linkedListIteratorGet 0 75 221
assign 1 75 224
hasNextGet 0 75 224
assign 1 78 226
nextGet 0 78 226
assign 1 79 227
delayDeleteGet 0 79 227
assign 1 79 228
not 0 79 233
assign 1 80 234
typenameGet 0 80 234
assign 1 80 235
TRANSUNITGet 0 80 235
assign 1 80 236
equals 1 80 241
assign 1 80 242
typenameGet 0 80 242
assign 1 80 243
IDGet 0 80 243
assign 1 80 244
equals 1 80 249
assign 1 0 250
assign 1 0 253
assign 1 0 257
assign 1 83 260
assign 1 84 263
def 1 84 268
assign 1 84 269
typenameGet 0 84 269
assign 1 84 270
IDGet 0 84 270
assign 1 84 271
equals 1 84 276
assign 1 0 277
assign 1 84 280
typenameGet 0 84 280
assign 1 84 281
COLONGet 0 84 281
assign 1 84 282
equals 1 84 287
assign 1 0 288
assign 1 0 291
assign 1 0 295
assign 1 85 298
typenameGet 0 85 298
assign 1 85 299
SPACEGet 0 85 299
assign 1 85 300
equals 1 85 305
assign 1 0 306
assign 1 0 309
assign 1 0 313
assign 1 0 316
assign 1 0 320
assign 1 86 323
nextPeerGet 0 86 323
assign 1 88 329
def 1 88 334
assign 1 88 335
typenameGet 0 88 335
assign 1 88 336
PARENSGet 0 88 336
assign 1 88 337
equals 1 88 342
assign 1 0 343
assign 1 88 346
typenameGet 0 88 346
assign 1 88 347
BRACESGet 0 88 347
assign 1 88 348
equals 1 88 353
assign 1 0 354
assign 1 0 357
assign 1 0 361
assign 1 0 364
assign 1 0 368
assign 1 91 371
new 1 91 371
assign 1 92 372
CLASSGet 0 92 372
typenameSet 1 92 373
assign 1 93 374
new 0 93 374
heldSet 1 93 375
addValue 1 94 376
assign 1 95 377
assign 1 98 380
typenameGet 0 98 380
assign 1 98 381
BRACESGet 0 98 381
assign 1 98 382
equals 1 98 387
assign 1 98 388
containerGet 0 98 388
assign 1 98 389
typenameGet 0 98 389
assign 1 98 390
CLASSGet 0 98 390
assign 1 98 391
equals 1 98 396
assign 1 0 397
assign 1 0 400
assign 1 0 404
assign 1 98 407
typenameGet 0 98 407
assign 1 98 408
IDGet 0 98 408
assign 1 98 409
equals 1 98 414
assign 1 0 415
assign 1 0 418
assign 1 0 422
assign 1 100 425
new 1 100 425
assign 1 101 426
METHODGet 0 101 426
typenameSet 1 101 427
assign 1 102 428
new 0 102 428
heldSet 1 102 429
addValue 1 103 430
assign 1 104 431
assign 1 107 433
typenameGet 0 107 433
assign 1 107 434
BRACESGet 0 107 434
assign 1 107 435
equals 1 107 440
assign 1 107 441
typenameGet 0 107 441
assign 1 107 442
BRACESGet 0 107 442
assign 1 107 443
equals 1 107 448
assign 1 0 449
assign 1 0 452
assign 1 0 456
assign 1 109 459
new 1 109 459
assign 1 110 460
PROPERTIESGet 0 110 460
typenameSet 1 110 461
assign 1 111 462
new 0 111 462
heldSet 1 111 463
addValue 1 112 464
assign 1 113 465
assign 1 116 467
typenameGet 0 116 467
assign 1 116 468
RPARENSGet 0 116 468
assign 1 116 469
equals 1 116 474
assign 1 117 475
stepBack 1 117 475
assign 1 118 478
typenameGet 0 118 478
assign 1 118 479
RIDXGet 0 118 479
assign 1 118 480
equals 1 118 485
assign 1 119 486
stepBack 1 119 486
assign 1 120 489
typenameGet 0 120 489
assign 1 120 490
RBRACESGet 0 120 490
assign 1 120 491
equals 1 120 496
assign 1 121 497
stepBack 1 121 497
assign 1 122 498
undef 1 122 503
assign 1 123 504
new 0 123 504
assign 1 123 505
new 2 123 505
throw 1 123 506
assign 1 125 508
stepBack 1 125 508
assign 1 126 509
undef 1 126 514
assign 1 127 515
new 0 127 515
assign 1 127 516
new 2 127 516
throw 1 127 517
addValue 1 130 521
assign 1 132 525
typenameGet 0 132 525
assign 1 132 526
has 1 132 526
assign 1 133 528
assign 1 140 543
containerGet 0 140 543
assign 1 141 544
undef 1 141 549
assign 1 142 550
new 0 142 550
assign 1 142 551
new 2 142 551
throw 1 142 552
return 1 144 554
return 1 0 557
assign 1 0 560
return 1 0 564
assign 1 0 567
return 1 0 571
assign 1 0 574
return 1 0 578
assign 1 0 581
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case -410956923: return bem_contain_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case -1081412016: return bem_many_0();
case -1380522583: return bem_outermostGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -2101994299: return bem_stepBack_1((BEC_2_5_4_BuildNode) bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1369440330: return bem_outermostSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 688372900: return bem_traverse_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_5_5_BuildBuild) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildTransport();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildTransport.bevs_inst = (BEC_2_5_9_BuildTransport)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildTransport.bevs_inst;
}
}
}
