namespace be {
/* IO:File: source/base/Tokenize.be */
public sealed class BEC_2_4_9_TextTokenizer : BEC_2_6_6_SystemObject {
public BEC_2_4_9_TextTokenizer() { }
static BEC_2_4_9_TextTokenizer() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
public static new BEC_2_4_9_TextTokenizer bevs_inst;
public BEC_2_9_3_ContainerMap bevp_tmap;
public BEC_2_5_4_LogicBool bevp_includeTokens;
public BEC_2_4_9_TextTokenizer bem_new_1(BEC_2_4_6_TextString beva_delims) {
bevp_includeTokens = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
this.bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_new_2(BEC_2_4_6_TextString beva_delims, BEC_2_5_4_LogicBool beva__includeTokens) {
bevp_includeTokens = beva__includeTokens;
this.bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokensStringSet_1(BEC_2_4_6_TextString beva_delims) {
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_tmap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_loop = beva_delims.bem_stringIteratorGet_0();
while (true)
 /* Line: 24 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevl_chi = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_chi.bem_toString_0();
bevp_tmap.bem_put_2(bevl_chi, bevt_2_tmpany_phold);
} /* Line: 25 */
 else  /* Line: 24 */ {
break;
} /* Line: 24 */
} /* Line: 24 */
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_addToken_1(BEC_2_4_6_TextString beva__delim) {
BEC_2_4_6_TextString bevl_delim = null;
bevl_delim = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_delim.bem_addValue_1(beva__delim);
bevp_tmap.bem_put_2(bevl_delim, beva__delim);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str);
bevt_0_tmpany_phold = this.bem_tokenizeIterator_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_2(BEC_2_6_6_SystemObject beva_str, BEC_2_6_6_SystemObject beva_tokenAcceptor) {
BEC_2_4_9_TextTokenizer bevt_0_tmpany_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str);
bevt_0_tmpany_phold = (BEC_2_4_9_TextTokenizer) this.bem_tokenizeIterator_2(bevt_1_tmpany_phold, beva_tokenAcceptor);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokenizeIterator_2(BEC_2_6_6_SystemObject beva_i, BEC_2_6_6_SystemObject beva_acceptor) {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
 /* Line: 46 */ {
bevt_0_tmpany_phold = beva_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 46 */ {
beva_i.bemd_1(-1048795675, BEL_4_Base.bevn_next_1, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_3_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_4_tmpany_phold = bevo_0;
if (bevt_3_tmpany_phold.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_5_tmpany_phold = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(1573180739, BEL_4_Base.bevn_acceptToken_1, bevt_5_tmpany_phold);
} /* Line: 51 */
if (bevp_includeTokens.bevi_bool) /* Line: 53 */ {
beva_acceptor.bemd_1(1573180739, BEL_4_Base.bevn_acceptToken_1, bevl_cc);
} /* Line: 54 */
} /* Line: 53 */
 else  /* Line: 56 */ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 57 */
} /* Line: 49 */
 else  /* Line: 46 */ {
break;
} /* Line: 46 */
} /* Line: 46 */
bevt_7_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_8_tmpany_phold = bevo_1;
if (bevt_7_tmpany_phold.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_9_tmpany_phold = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(1573180739, BEL_4_Base.bevn_acceptToken_1, bevt_9_tmpany_phold);
} /* Line: 61 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenizeIterator_1(BEC_2_6_6_SystemObject beva_i) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
 /* Line: 69 */ {
bevt_0_tmpany_phold = beva_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 69 */ {
beva_i.bemd_1(-1048795675, BEL_4_Base.bevn_next_1, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_3_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_4_tmpany_phold = bevo_2;
if (bevt_3_tmpany_phold.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_5_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 74 */
if (bevp_includeTokens.bevi_bool) /* Line: 76 */ {
bevl_splits.bem_addValue_1(bevl_cc);
} /* Line: 77 */
} /* Line: 76 */
 else  /* Line: 79 */ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 80 */
} /* Line: 72 */
 else  /* Line: 69 */ {
break;
} /* Line: 69 */
} /* Line: 69 */
bevt_7_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_8_tmpany_phold = bevo_3;
if (bevt_7_tmpany_phold.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_9_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_9_tmpany_phold);
} /* Line: 84 */
return bevl_splits;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_tmapGet_0() {
return bevp_tmap;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_includeTokensGet_0() {
return bevp_includeTokens;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_includeTokensSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includeTokens = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {13, 14, 18, 19, 23, 24, 0, 24, 24, 25, 25, 30, 31, 32, 36, 36, 36, 40, 40, 40, 44, 45, 46, 47, 48, 49, 49, 50, 50, 50, 50, 51, 51, 54, 57, 60, 60, 60, 60, 61, 61, 66, 67, 68, 69, 70, 71, 72, 72, 73, 73, 73, 73, 74, 74, 77, 80, 83, 83, 83, 83, 84, 84, 86, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 17, 21, 22, 30, 31, 31, 34, 36, 37, 38, 48, 49, 50, 56, 57, 58, 63, 64, 65, 81, 82, 85, 87, 88, 89, 94, 95, 96, 97, 102, 103, 104, 107, 111, 118, 119, 120, 125, 126, 127, 146, 147, 148, 151, 153, 154, 155, 160, 161, 162, 163, 168, 169, 170, 173, 177, 184, 185, 186, 191, 192, 193, 195, 198, 201, 205, 208};
/* BEGIN LINEINFO 
assign 1 13 16
new 0 13 16
tokensStringSet 1 14 17
assign 1 18 21
tokensStringSet 1 19 22
assign 1 23 30
new 0 23 30
assign 1 24 31
stringIteratorGet 0 0 31
assign 1 24 34
hasNextGet 0 24 34
assign 1 24 36
nextGet 0 24 36
assign 1 25 37
toString 0 25 37
put 2 25 38
assign 1 30 48
new 0 30 48
addValue 1 31 49
put 2 32 50
assign 1 36 56
new 1 36 56
assign 1 36 57
tokenizeIterator 1 36 57
return 1 36 58
assign 1 40 63
new 1 40 63
assign 1 40 64
tokenizeIterator 2 40 64
return 1 40 65
assign 1 44 81
new 0 44 81
assign 1 45 82
new 0 45 82
assign 1 46 85
hasNextGet 0 46 85
next 1 47 87
assign 1 48 88
get 1 48 88
assign 1 49 89
def 1 49 94
assign 1 50 95
sizeGet 0 50 95
assign 1 50 96
new 0 50 96
assign 1 50 97
greater 1 50 102
assign 1 51 103
extractString 0 51 103
acceptToken 1 51 104
acceptToken 1 54 107
addValue 1 57 111
assign 1 60 118
sizeGet 0 60 118
assign 1 60 119
new 0 60 119
assign 1 60 120
greater 1 60 125
assign 1 61 126
extractString 0 61 126
acceptToken 1 61 127
assign 1 66 146
new 0 66 146
assign 1 67 147
new 0 67 147
assign 1 68 148
new 0 68 148
assign 1 69 151
hasNextGet 0 69 151
next 1 70 153
assign 1 71 154
get 1 71 154
assign 1 72 155
def 1 72 160
assign 1 73 161
sizeGet 0 73 161
assign 1 73 162
new 0 73 162
assign 1 73 163
greater 1 73 168
assign 1 74 169
extractString 0 74 169
addValue 1 74 170
addValue 1 77 173
addValue 1 80 177
assign 1 83 184
sizeGet 0 83 184
assign 1 83 185
new 0 83 185
assign 1 83 186
greater 1 83 191
assign 1 84 192
extractString 0 84 192
addValue 1 84 193
return 1 86 195
return 1 0 198
assign 1 0 201
return 1 0 205
assign 1 0 208
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 436564549: return bem_includeTokensGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case 945147391: return bem_tmapGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 3917833: return bem_tokensStringSet_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 110901677: return bem_tokenize_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 764248970: return bem_addToken_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 447646802: return bem_includeTokensSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 956229644: return bem_tmapSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 530943931: return bem_tokenizeIterator_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 110901678: return bem_tokenize_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 104713555: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 530943932: return bem_tokenizeIterator_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_9_TextTokenizer();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_9_TextTokenizer.bevs_inst = (BEC_2_4_9_TextTokenizer)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_9_TextTokenizer.bevs_inst;
}
}
}
