namespace be {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_4_EncodeHtml : BEC_2_6_6_SystemObject {
public BEC_2_6_4_EncodeHtml() { }
static BEC_2_6_4_EncodeHtml() { }
private static byte[] becc_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x74,0x6D,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(127));
private static byte[] bels_0 = {0x22};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 1));
private static byte[] bels_1 = {0x3C};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 1));
private static byte[] bels_2 = {0x3E};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 1));
private static byte[] bels_3 = {0x26};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 1));
private static byte[] bels_4 = {0x26,0x23};
private static byte[] bels_5 = {0x3B};
public static new BEC_2_6_4_EncodeHtml bevs_inst;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_4_EncodeHtml bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
bevt_5_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_6_tmpany_phold = bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_multiply_1(bevt_6_tmpany_phold);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_4_tmpany_phold);
bevl_tb = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_7_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_pt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_7_tmpany_phold);
while (true)
 /* Line: 132 */ {
bevt_8_tmpany_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevl_tb.bem_next_1(bevl_pt);
bevt_9_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bevo_1;
if (bevl_ac.bevi_int > bevt_11_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_13_tmpany_phold = bevo_2;
bevt_12_tmpany_phold = bevl_pt.bem_equals_1(bevt_13_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_15_tmpany_phold = bevo_3;
bevt_14_tmpany_phold = bevl_pt.bem_equals_1(bevt_15_tmpany_phold);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_17_tmpany_phold = bevo_4;
bevt_16_tmpany_phold = bevl_pt.bem_equals_1(bevt_17_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_19_tmpany_phold = bevo_5;
bevt_18_tmpany_phold = bevl_pt.bem_equals_1(bevt_19_tmpany_phold);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_4));
bevl_r.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = bevl_ac.bem_toString_0();
bevl_r.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_5));
bevl_r.bem_addValue_1(bevt_22_tmpany_phold);
} /* Line: 138 */
 else  /* Line: 139 */ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 140 */
} /* Line: 135 */
 else  /* Line: 132 */ {
break;
} /* Line: 132 */
} /* Line: 132 */
return bevl_r;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {129, 129, 129, 129, 130, 131, 131, 132, 133, 134, 134, 135, 135, 135, 0, 135, 135, 0, 0, 0, 135, 135, 0, 0, 0, 135, 135, 0, 0, 0, 135, 135, 0, 0, 136, 136, 137, 137, 138, 138, 140, 143};
public static new int[] bevs_smnlec
 = new int[] {57, 58, 59, 60, 61, 62, 63, 66, 68, 69, 70, 71, 72, 77, 78, 81, 82, 84, 87, 91, 94, 95, 97, 100, 104, 107, 108, 110, 113, 117, 120, 121, 123, 126, 130, 131, 132, 133, 134, 135, 138, 145};
/* BEGIN LINEINFO 
assign 1 129 57
sizeGet 0 129 57
assign 1 129 58
new 0 129 58
assign 1 129 59
multiply 1 129 59
assign 1 129 60
new 1 129 60
assign 1 130 61
new 1 130 61
assign 1 131 62
new 0 131 62
assign 1 131 63
new 1 131 63
assign 1 132 66
hasNextGet 0 132 66
next 1 133 68
assign 1 134 69
new 0 134 69
assign 1 134 70
getCode 1 134 70
assign 1 135 71
new 0 135 71
assign 1 135 72
greater 1 135 77
assign 1 0 78
assign 1 135 81
new 0 135 81
assign 1 135 82
equals 1 135 82
assign 1 0 84
assign 1 0 87
assign 1 0 91
assign 1 135 94
new 0 135 94
assign 1 135 95
equals 1 135 95
assign 1 0 97
assign 1 0 100
assign 1 0 104
assign 1 135 107
new 0 135 107
assign 1 135 108
equals 1 135 108
assign 1 0 110
assign 1 0 113
assign 1 0 117
assign 1 135 120
new 0 135 120
assign 1 135 121
equals 1 135 121
assign 1 0 123
assign 1 0 126
assign 1 136 130
new 0 136 130
addValue 1 136 131
assign 1 137 132
toString 0 137 132
addValue 1 137 133
assign 1 138 134
new 0 138 134
addValue 1 138 135
addValue 1 140 138
return 1 143 145
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -1502128718: return bem_default_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 95462007: return bem_def_1(bevd_0);
case 1711217736: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_4_EncodeHtml();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_4_EncodeHtml.bevs_inst = (BEC_2_6_4_EncodeHtml)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_4_EncodeHtml.bevs_inst;
}
}
}
