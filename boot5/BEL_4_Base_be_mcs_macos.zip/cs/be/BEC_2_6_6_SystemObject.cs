namespace be {

using System;
    /* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject : be.BECS_Object {
public BEC_2_6_6_SystemObject() { }
static BEC_2_6_6_SystemObject() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 8));
private static byte[] bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 23));
private static byte[] bels_2 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_3 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 16));
private static byte[] bels_4 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_5 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_6 = {0x5F};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_6, 1));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
private static byte[] bels_7 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_8 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_9 = {0x5F};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 1));
public static BEC_2_6_6_SystemObject bevs_inst;
public virtual BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toAny_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_forwardCall_1(BEC_2_6_11_SystemForwardCall beva_forwardCall) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_5_tmpany_phold = bevo_0;
bevt_6_tmpany_phold = beva_forwardCall.bem_nameGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = this.bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 74 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_phold = this.bem_createInstance_2(beva_cname, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_4_6_TextString bevl_mname = null;
BEC_2_4_3_MathInt bevl_mhash = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_11_SystemInitializer bevt_9_tmpany_phold = null;
if (beva_cname == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bels_2));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 99 */
bevl_result = null;

        string key = System.Text.Encoding.UTF8.GetString(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int);
        Type ti = be.BECS_Runtime.typeInstances[key];
        if (ti != null) {
            bevl_result = (BEC_2_6_6_SystemObject) Activator.CreateInstance(ti);
        }
        if (bevl_result == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 177 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 178 */ {
bevt_7_tmpany_phold = bevo_2;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_cname);
bevt_5_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 179 */
 else  /* Line: 180 */ {
return null;
} /* Line: 181 */
} /* Line: 178 */
bevt_9_tmpany_phold = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_initializeIfShould_1(bevl_result);
return bevt_8_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bels_4));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 220 */
if (beva_args == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bels_5));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 223 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpany_phold = bevo_3;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevl_chash = bevl_cname.bem_hashGet_0();
 /* Line: 232 */ {
bevt_10_tmpany_phold = bevo_4;
if (bevl_numargs.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_12_tmpany_phold = bevo_5;
bevt_11_tmpany_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpany_phold);
bevl_args2 = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
while (true)
 /* Line: 235 */ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_15_tmpany_phold = bevo_6;
bevt_14_tmpany_phold = bevl_i.bem_subtract_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpany_phold, bevt_16_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 235 */
 else  /* Line: 235 */ {
break;
} /* Line: 235 */
} /* Line: 235 */
} /* Line: 235 */
} /* Line: 233 */

        int ci = be.BECS_Ids.callIds[System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int)];
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(bevl_chash.bevi_int, ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(bevl_chash.bevi_int, ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 361 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 363 */
return bevl_rval;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 390 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bels_7));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 391 */
if (beva_numargs == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 393 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bels_8));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 394 */
bevt_7_tmpany_phold = bevo_7;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevl_chash = bevl_cname.bem_hashGet_0();

      string name = "bem_" + System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int);
      System.Reflection.MethodInfo[] methods = this.GetType().GetMethods();
      for (int i = 0;i < methods.Length;i++) {
        if (methods[i].Name.Equals(name)) {
            return be.BECS_Runtime.boolTrue;
        }
      }
      bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 450 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 451 */
if (bevl_rval == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 453 */ {
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /* Line: 454 */
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clname();
      bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      return bevl_xi;
} /*method end*/
public BEC_2_4_6_TextString bem_sourceFileNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clfile();
      bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      return bevl_xi;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_tagGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_print_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toString_0();
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_echo_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toString_0();
bevt_0_tmpany_phold.bem_echo_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_6_6_SystemObject) this.bem_create_0();
bevt_0_tmpany_phold = (BEC_2_6_6_SystemObject) this.bem_copyTo_1(bevt_1_tmpany_phold);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
if (beva_copy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 674 */ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 675 */
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_tmpany_phold);
while (true)
 /* Line: 679 */ {
bevt_3_tmpany_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 679 */ {
bevt_4_tmpany_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpany_phold);
} /* Line: 680 */
 else  /* Line: 679 */ {
break;
} /* Line: 679 */
} /* Line: 679 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_serializeToString_0() {
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_fieldIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && this.GetType() == beva_other.GetType()) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_sameClass_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && beva_other.GetType().IsAssignableFrom(this.GetType())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_sameType_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_once_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_many_0() {
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {32, 32, 43, 43, 54, 54, 65, 65, 69, 73, 74, 74, 74, 74, 74, 74, 74, 74, 74, 79, 79, 79, 98, 98, 99, 99, 99, 101, 177, 177, 179, 179, 179, 179, 181, 184, 184, 184, 219, 219, 220, 220, 220, 222, 222, 223, 223, 223, 225, 226, 226, 226, 226, 227, 233, 233, 233, 234, 234, 234, 235, 235, 235, 236, 236, 236, 236, 235, 361, 363, 365, 390, 390, 391, 391, 391, 393, 393, 394, 394, 394, 396, 396, 396, 396, 397, 450, 451, 453, 453, 454, 454, 456, 456, 490, 512, 544, 544, 576, 576, 587, 613, 624, 650, 654, 654, 654, 658, 658, 662, 662, 666, 666, 670, 670, 670, 674, 674, 675, 677, 677, 678, 678, 679, 680, 680, 686, 686, 692, 698, 698, 702, 702, 706, 706, 710, 710, 733, 780, 780, 784, 784, 784, 839, 839, 843, 843, 843};
public static int[] bevs_smnlec
 = new int[] {34, 35, 39, 40, 44, 45, 49, 50, 53, 65, 67, 68, 69, 70, 71, 72, 73, 74, 75, 82, 83, 84, 101, 106, 107, 108, 109, 111, 118, 123, 125, 126, 127, 128, 131, 134, 135, 136, 163, 168, 169, 170, 171, 173, 178, 179, 180, 181, 183, 184, 185, 186, 187, 188, 190, 191, 196, 197, 198, 199, 200, 203, 208, 209, 210, 211, 212, 213, 243, 245, 247, 266, 271, 272, 273, 274, 276, 281, 282, 283, 284, 286, 287, 288, 289, 290, 299, 301, 303, 308, 309, 310, 312, 313, 320, 327, 335, 336, 344, 345, 349, 352, 356, 359, 364, 365, 370, 374, 375, 379, 380, 385, 386, 392, 393, 394, 404, 409, 410, 412, 413, 414, 415, 418, 420, 421, 431, 432, 438, 445, 446, 450, 451, 455, 456, 460, 461, 467, 475, 476, 481, 482, 487, 495, 496, 501, 502, 507};
/* BEGIN LINEINFO 
assign 1 32 34
new 0 32 34
return 1 32 35
assign 1 43 39
new 0 43 39
return 1 43 40
assign 1 54 44
new 0 54 44
return 1 54 45
assign 1 65 49
new 0 65 49
return 1 65 50
return 1 69 53
assign 1 73 65
new 0 73 65
assign 1 74 67
new 0 74 67
assign 1 74 68
nameGet 0 74 68
assign 1 74 69
add 1 74 69
assign 1 74 70
new 0 74 70
assign 1 74 71
add 1 74 71
assign 1 74 72
classNameGet 0 74 72
assign 1 74 73
add 1 74 73
assign 1 74 74
new 1 74 74
throw 1 74 75
assign 1 79 82
new 0 79 82
assign 1 79 83
createInstance 2 79 83
return 1 79 84
assign 1 98 101
undef 1 98 106
assign 1 99 107
new 0 99 107
assign 1 99 108
new 1 99 108
throw 1 99 109
assign 1 101 111
assign 1 177 118
undef 1 177 123
assign 1 179 125
new 0 179 125
assign 1 179 126
add 1 179 126
assign 1 179 127
new 1 179 127
throw 1 179 128
return 1 181 131
assign 1 184 134
new 0 184 134
assign 1 184 135
initializeIfShould 1 184 135
return 1 184 136
assign 1 219 163
undef 1 219 168
assign 1 220 169
new 0 220 169
assign 1 220 170
new 1 220 170
throw 1 220 171
assign 1 222 173
undef 1 222 178
assign 1 223 179
new 0 223 179
assign 1 223 180
new 1 223 180
throw 1 223 181
assign 1 225 183
lengthGet 0 225 183
assign 1 226 184
new 0 226 184
assign 1 226 185
add 1 226 185
assign 1 226 186
toString 0 226 186
assign 1 226 187
add 1 226 187
assign 1 227 188
hashGet 0 227 188
assign 1 233 190
new 0 233 190
assign 1 233 191
greater 1 233 196
assign 1 234 197
new 0 234 197
assign 1 234 198
subtract 1 234 198
assign 1 234 199
new 1 234 199
assign 1 235 200
new 0 235 200
assign 1 235 203
lesser 1 235 208
assign 1 236 209
new 0 236 209
assign 1 236 210
subtract 1 236 210
assign 1 236 211
get 1 236 211
put 2 236 212
incrementValue 0 235 213
assign 1 361 243
new 0 361 243
toString 0 363 245
return 1 365 247
assign 1 390 266
undef 1 390 271
assign 1 391 272
new 0 391 272
assign 1 391 273
new 1 391 273
throw 1 391 274
assign 1 393 276
undef 1 393 281
assign 1 394 282
new 0 394 282
assign 1 394 283
new 1 394 283
throw 1 394 284
assign 1 396 286
new 0 396 286
assign 1 396 287
add 1 396 287
assign 1 396 288
toString 0 396 288
assign 1 396 289
add 1 396 289
assign 1 397 290
hashGet 0 397 290
assign 1 450 299
new 0 450 299
toString 0 451 301
assign 1 453 303
def 1 453 308
assign 1 454 309
new 0 454 309
return 1 454 310
assign 1 456 312
new 0 456 312
return 1 456 313
return 1 490 320
return 1 512 327
assign 1 544 335
new 0 544 335
return 1 544 336
assign 1 576 344
new 0 576 344
return 1 576 345
assign 1 587 349
new 0 587 349
return 1 613 352
assign 1 624 356
new 0 624 356
return 1 650 359
assign 1 654 364
equals 1 654 364
assign 1 654 365
not 0 654 370
return 1 654 370
assign 1 658 374
classNameGet 0 658 374
return 1 658 375
assign 1 662 379
toString 0 662 379
print 0 662 380
assign 1 666 385
toString 0 666 385
echo 0 666 386
assign 1 670 392
create 0 670 392
assign 1 670 393
copyTo 1 670 393
return 1 670 394
assign 1 674 404
undef 1 674 409
return 1 675 410
assign 1 677 412
new 0 677 412
assign 1 677 413
new 2 677 413
assign 1 678 414
new 0 678 414
assign 1 678 415
new 2 678 415
assign 1 679 418
hasNextGet 0 679 418
assign 1 680 420
nextGet 0 680 420
nextSet 1 680 421
assign 1 686 431
classNameGet 0 686 431
return 1 686 432
return 1 692 438
assign 1 698 445
new 1 698 445
return 1 698 446
assign 1 702 450
new 1 702 450
return 1 702 451
assign 1 706 455
new 1 706 455
return 1 706 456
assign 1 710 460
new 0 710 460
return 1 710 461
return 1 733 467
assign 1 780 475
new 0 780 475
return 1 780 476
assign 1 784 481
sameClass 1 784 481
assign 1 784 482
not 0 784 487
return 1 784 487
assign 1 839 495
new 0 839 495
return 1 839 496
assign 1 843 501
sameType 1 843 501
assign 1 843 502
not 0 843 507
return 1 843 507
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -868745803: return bem_forwardCall_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemObject();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemObject.bevs_inst = becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemObject.bevs_inst;
}
}
}
