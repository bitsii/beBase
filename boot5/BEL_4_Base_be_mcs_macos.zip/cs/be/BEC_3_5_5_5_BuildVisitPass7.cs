namespace be {
/* IO:File: source/build/Pass7.be */
public sealed class BEC_3_5_5_5_BuildVisitPass7 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
static BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x65,0x77};
private static byte[] bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_2 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_3 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_4 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_5 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_6 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_7 = {0x74,0x72,0x75,0x65};
private static byte[] bels_8 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_9 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_10 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 41));
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_15 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_16 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_17 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_18 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_20 = {0x6E,0x65,0x77};
public static new BEC_3_5_5_5_BuildVisitPass7 bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-630006451, BEL_4_Base.bevn_fromString_1, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_5_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_5_tmpvar_phold);
bevl_nlnpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlnp);
bevl_nlnpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_0));
bevl_nlc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1580478063, BEL_4_Base.bevn_isLiteralSet_1, bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_11_tmpvar_phold);
beva_node.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nlnpn);
bevt_12_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_12_tmpvar_phold);
beva_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlc);
bevl_nlnpn.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_1));
bevt_13_tmpvar_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 49 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_2));
bevt_15_tmpvar_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 49 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 49 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 49 */ {
bevl_pn = beva_node.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn == null) {
bevt_17_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_19_tmpvar_phold = bevl_pn.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_20_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_20_tmpvar_phold);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_22_tmpvar_phold = bevl_pn.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_23_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_23_tmpvar_phold);
if (bevt_21_tmpvar_phold != null && bevt_21_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_21_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
 else  /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevl_pn2 = bevl_pn.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn2 == null) {
bevt_24_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_26_tmpvar_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_27_tmpvar_phold);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_29_tmpvar_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_30_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_30_tmpvar_phold);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_32_tmpvar_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_33_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_35_tmpvar_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_36_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_36_tmpvar_phold);
if (bevt_34_tmpvar_phold != null && bevt_34_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_38_tmpvar_phold = bevl_pn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_39_tmpvar_phold = bevl_nlc.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_39_tmpvar_phold);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_37_tmpvar_phold);
bevl_pn.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 60 */
} /* Line: 53 */
} /* Line: 51 */
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_62_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_104_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_105_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_111_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_117_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_130_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_131_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_135_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_138_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_142_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_154_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_166_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_167_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_171_tmpvar_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_tmpvar_phold.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 89 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_13_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 91 */
if (bevp_inClassNp == null) {
bevt_14_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 93 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 95 */
bevt_16_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpvar_phold = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_tmpvar_phold.bevi_int == bevt_17_tmpvar_phold.bevi_int) {
bevt_15_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 97 */ {
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_3));
this.bem_buildLiteral_2(beva_node, bevt_18_tmpvar_phold);
} /* Line: 98 */
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_tmpvar_phold.bevi_int == bevt_21_tmpvar_phold.bevi_int) {
bevt_19_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_22_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_4));
this.bem_buildLiteral_2(beva_node, bevt_22_tmpvar_phold);
} /* Line: 101 */
bevt_24_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_tmpvar_phold.bevi_int == bevt_25_tmpvar_phold.bevi_int) {
bevt_23_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_5));
this.bem_buildLiteral_2(beva_node, bevt_26_tmpvar_phold);
} /* Line: 104 */
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_tmpvar_phold.bevi_int == bevt_29_tmpvar_phold.bevi_int) {
bevt_27_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 106 */ {
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_6));
this.bem_buildLiteral_2(beva_node, bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpvar_phold);
} /* Line: 109 */
bevt_33_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_tmpvar_phold.bevi_int == bevt_34_tmpvar_phold.bevi_int) {
bevt_32_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 111 */ {
bevt_35_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_7));
beva_node.bem_heldSet_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_8));
this.bem_buildLiteral_2(beva_node, bevt_36_tmpvar_phold);
} /* Line: 113 */
bevt_38_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_tmpvar_phold.bevi_int == bevt_39_tmpvar_phold.bevi_int) {
bevt_37_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 119 */ {
bevt_40_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_9));
beva_node.bem_heldSet_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_10));
this.bem_buildLiteral_2(beva_node, bevt_41_tmpvar_phold);
} /* Line: 121 */
 else  /* Line: 119 */ {
bevt_43_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_43_tmpvar_phold.bevi_int == bevt_44_tmpvar_phold.bevi_int) {
bevt_42_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_47_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(1869307931, BEL_4_Base.bevn_isArgGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
 else  /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 123 */ {
bevt_50_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
if (bevt_49_tmpvar_phold == null) {
bevt_48_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 124 */ {
if (bevl_nnode == null) {
bevt_51_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_53_tmpvar_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_54_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_54_tmpvar_phold);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 124 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 124 */
 else  /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 124 */ {
bevt_57_tmpvar_phold = bevo_0;
bevt_59_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_55_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpvar_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_55_tmpvar_phold);
} /* Line: 125 */
 else  /* Line: 126 */ {
bevt_60_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_61_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_61_tmpvar_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_62_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpvar_phold;
} /* Line: 133 */
} /* Line: 124 */
 else  /* Line: 119 */ {
bevt_64_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_64_tmpvar_phold.bevi_int == bevt_65_tmpvar_phold.bevi_int) {
bevt_63_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpvar_phold.bevi_bool) /* Line: 135 */ {
if (bevl_nnode == null) {
bevt_66_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevt_68_tmpvar_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_69_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 136 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 136 */
 else  /* Line: 136 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 136 */ {
bevt_71_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_71_tmpvar_phold == null) {
bevt_70_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 137 */ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_72_tmpvar_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 139 */ {
bevt_73_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 139 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_75_tmpvar_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_74_tmpvar_phold != null && bevt_74_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 142 */
} /* Line: 141 */
 else  /* Line: 139 */ {
break;
} /* Line: 139 */
} /* Line: 139 */
bevl_ii = bevl_toremove.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 145 */ {
bevt_77_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_77_tmpvar_phold != null && bevt_77_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_77_tmpvar_phold).bevi_bool) /* Line: 145 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 147 */
 else  /* Line: 145 */ {
break;
} /* Line: 145 */
} /* Line: 145 */
} /* Line: 145 */
bevl_pc = bevl_nnode;
bevt_78_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpvar_phold);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_79_tmpvar_phold);
bevl_pc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 158 */ {
bevt_82_tmpvar_phold = bevl_dnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_83_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_83_tmpvar_phold);
if (bevt_81_tmpvar_phold != null && bevt_81_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_81_tmpvar_phold).bevi_bool) /* Line: 158 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 158 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 158 */
 else  /* Line: 158 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 158 */ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_onode == null) {
bevt_84_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpvar_phold.bevi_bool) /* Line: 160 */ {
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(38, bels_12));
bevt_85_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpvar_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_85_tmpvar_phold);
} /* Line: 161 */
 else  /* Line: 160 */ {
bevt_88_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_tmpvar_phold.bevi_int == bevt_89_tmpvar_phold.bevi_int) {
bevt_87_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpvar_phold.bevi_bool) /* Line: 162 */ {
bevt_91_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_90_tmpvar_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_tmpvar_phold);
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 163 */ {
bevt_92_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_92_tmpvar_phold);
bevt_93_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_93_tmpvar_phold);
bevt_94_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_94_tmpvar_phold);
} /* Line: 166 */
 else  /* Line: 167 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 168 */
} /* Line: 163 */
 else  /* Line: 160 */ {
bevt_96_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_97_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_96_tmpvar_phold.bevi_int == bevt_97_tmpvar_phold.bevi_int) {
bevt_95_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_95_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_95_tmpvar_phold.bevi_bool) /* Line: 170 */ {
bevt_101_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_102_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_98_tmpvar_phold = bevt_99_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_102_tmpvar_phold);
if (bevt_98_tmpvar_phold != null && bevt_98_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_98_tmpvar_phold).bevi_bool) /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 170 */ {
bevt_105_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_aliasedGet_0();
bevt_106_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bem_has_1(bevt_106_tmpvar_phold);
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 170 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 170 */
 else  /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 170 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_tmpvar_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_tmpvar_phold);
bevl_onode.bem_resolveNp_0();
bevt_110_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_109_tmpvar_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_tmpvar_phold);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 176 */ {
bevt_111_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_111_tmpvar_phold);
bevt_112_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_112_tmpvar_phold);
bevt_113_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_113_tmpvar_phold);
} /* Line: 179 */
 else  /* Line: 180 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 181 */
} /* Line: 176 */
 else  /* Line: 160 */ {
bevt_115_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_116_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_13));
bevt_114_tmpvar_phold = bevt_115_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_116_tmpvar_phold);
if (bevt_114_tmpvar_phold != null && bevt_114_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpvar_phold).bevi_bool) /* Line: 183 */ {
bevt_118_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(70, bels_14));
bevt_117_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_tmpvar_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_117_tmpvar_phold);
} /* Line: 184 */
 else  /* Line: 160 */ {
bevt_120_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_121_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_15));
bevt_119_tmpvar_phold = bevt_120_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_121_tmpvar_phold);
if (bevt_119_tmpvar_phold != null && bevt_119_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_119_tmpvar_phold).bevi_bool) /* Line: 185 */ {
bevt_123_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bels_16));
bevt_122_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_tmpvar_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_122_tmpvar_phold);
} /* Line: 186 */
} /* Line: 160 */
} /* Line: 160 */
} /* Line: 160 */
} /* Line: 160 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_onode);
bevl_dnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 191 */
 else  /* Line: 192 */ {
bevt_124_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_124_tmpvar_phold);
bevt_125_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_125_tmpvar_phold);
} /* Line: 194 */
} /* Line: 158 */
} /* Line: 136 */
 else  /* Line: 119 */ {
bevt_127_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_128_tmpvar_phold = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_tmpvar_phold.bevi_int == bevt_128_tmpvar_phold.bevi_int) {
bevt_126_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_126_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_126_tmpvar_phold.bevi_bool) /* Line: 198 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_129_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_131_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bels_17));
bevt_130_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_tmpvar_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_130_tmpvar_phold);
} /* Line: 203 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_134_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_tmpvar_phold.bevi_int == bevt_134_tmpvar_phold.bevi_int) {
bevt_132_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevt_136_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(84, bels_18));
bevt_135_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_tmpvar_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_135_tmpvar_phold);
} /* Line: 208 */
bevt_137_tmpvar_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_tmpvar_phold);
} /* Line: 210 */
 else  /* Line: 119 */ {
bevt_139_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_140_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_tmpvar_phold.bevi_int == bevt_140_tmpvar_phold.bevi_int) {
bevt_138_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_138_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_141_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_141_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevt_5_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 216 */ {
if (bevl_onode == null) {
bevt_142_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_142_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_142_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevt_5_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 216 */ {
bevt_5_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 216 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 216 */ {
bevt_144_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bels_19));
bevt_143_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpvar_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_143_tmpvar_phold);
} /* Line: 217 */
bevt_146_tmpvar_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_147_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpvar_phold = bevt_146_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_147_tmpvar_phold);
if (bevt_145_tmpvar_phold != null && bevt_145_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_145_tmpvar_phold).bevi_bool) /* Line: 219 */ {
bevl_pnode = bevl_nnode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_pnode == null) {
bevt_148_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_148_tmpvar_phold.bevi_bool) /* Line: 221 */ {
bevt_6_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_150_tmpvar_phold = bevl_pnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_151_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_149_tmpvar_phold = bevt_150_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_151_tmpvar_phold);
if (bevt_149_tmpvar_phold != null && bevt_149_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_149_tmpvar_phold).bevi_bool) /* Line: 221 */ {
bevt_6_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_6_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 221 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 221 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_tmpvar_phold);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_ga.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_153_tmpvar_phold);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_156_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_tmpvar_phold.bevi_int == bevt_156_tmpvar_phold.bevi_int) {
bevt_154_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_154_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_154_tmpvar_phold.bevi_bool) /* Line: 230 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 231 */
 else  /* Line: 230 */ {
bevt_158_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_159_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_158_tmpvar_phold.bevi_int == bevt_159_tmpvar_phold.bevi_int) {
bevt_157_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_157_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_157_tmpvar_phold.bevi_bool) /* Line: 232 */ {
bevt_163_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_161_tmpvar_phold = bevt_162_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_164_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_160_tmpvar_phold = bevt_161_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_164_tmpvar_phold);
if (bevt_160_tmpvar_phold != null && bevt_160_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_160_tmpvar_phold).bevi_bool) /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 232 */ {
bevt_167_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_166_tmpvar_phold = bevt_167_tmpvar_phold.bem_aliasedGet_0();
bevt_168_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_165_tmpvar_phold = bevt_166_tmpvar_phold.bem_has_1(bevt_168_tmpvar_phold);
if (bevt_165_tmpvar_phold.bevi_bool) /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 232 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 232 */
 else  /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 232 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_tmpvar_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_tmpvar_phold);
bevl_onode.bem_resolveNp_0();
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 238 */
} /* Line: 230 */
} /* Line: 230 */
} /* Line: 221 */
} /* Line: 219 */
} /* Line: 119 */
} /* Line: 119 */
} /* Line: 119 */
} /* Line: 119 */
bevt_171_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_171_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpvar_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (BEC_2_5_4_BuildCall) (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_20));
bevl_gnc.bem_nameSet_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpvar_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {26, 27, 29, 30, 30, 31, 32, 34, 35, 35, 36, 36, 37, 37, 38, 38, 39, 39, 40, 40, 42, 44, 44, 45, 47, 49, 49, 0, 49, 49, 0, 0, 50, 51, 51, 51, 51, 51, 0, 51, 51, 51, 0, 0, 0, 0, 0, 52, 53, 53, 0, 53, 53, 53, 53, 53, 53, 0, 0, 0, 53, 53, 53, 0, 0, 0, 53, 53, 53, 0, 0, 0, 0, 0, 59, 59, 59, 59, 60, 86, 89, 89, 89, 89, 90, 90, 91, 91, 91, 93, 93, 94, 95, 97, 97, 97, 97, 98, 98, 100, 100, 100, 100, 101, 101, 103, 103, 103, 103, 104, 104, 106, 106, 106, 106, 108, 108, 109, 109, 111, 111, 111, 111, 112, 112, 113, 113, 119, 119, 119, 119, 120, 120, 121, 121, 123, 123, 123, 123, 123, 123, 123, 0, 0, 0, 124, 124, 124, 124, 124, 124, 0, 124, 124, 124, 0, 0, 0, 0, 0, 125, 125, 125, 125, 125, 125, 127, 127, 127, 128, 129, 133, 133, 135, 135, 135, 135, 136, 136, 136, 136, 136, 0, 0, 0, 137, 137, 137, 138, 139, 139, 139, 140, 141, 141, 141, 142, 145, 145, 146, 147, 150, 151, 151, 152, 153, 153, 154, 155, 156, 157, 158, 158, 158, 158, 158, 0, 0, 0, 159, 160, 160, 161, 161, 161, 162, 162, 162, 162, 163, 163, 164, 164, 165, 165, 166, 166, 168, 170, 170, 170, 170, 170, 170, 170, 170, 170, 0, 170, 170, 170, 170, 0, 0, 0, 0, 0, 171, 172, 172, 173, 174, 174, 175, 176, 176, 177, 177, 178, 178, 179, 179, 181, 183, 183, 183, 184, 184, 184, 185, 185, 185, 186, 186, 186, 189, 190, 191, 193, 193, 194, 194, 198, 198, 198, 198, 201, 202, 202, 203, 203, 203, 205, 206, 207, 207, 207, 207, 208, 208, 208, 210, 210, 211, 211, 211, 211, 213, 216, 216, 0, 216, 216, 0, 0, 217, 217, 217, 219, 219, 219, 220, 221, 221, 0, 221, 221, 221, 0, 0, 222, 223, 223, 224, 225, 225, 226, 227, 228, 229, 230, 230, 230, 230, 231, 232, 232, 232, 232, 232, 232, 232, 232, 232, 0, 232, 232, 232, 232, 0, 0, 0, 0, 0, 233, 234, 234, 235, 236, 236, 237, 238, 243, 243, 247, 248, 249, 249, 250, 250, 251, 253, 254, 254, 255, 255, 256, 256, 257, 257, 258, 258, 259, 260, 260, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 110, 113, 114, 116, 119, 123, 124, 129, 130, 131, 132, 134, 137, 138, 139, 141, 144, 148, 151, 155, 158, 159, 164, 165, 168, 169, 170, 172, 173, 174, 176, 179, 183, 186, 187, 188, 190, 193, 197, 200, 201, 202, 204, 207, 211, 214, 217, 221, 222, 223, 224, 225, 418, 419, 420, 421, 426, 427, 428, 429, 430, 431, 433, 438, 439, 440, 442, 443, 444, 449, 450, 451, 453, 454, 455, 460, 461, 462, 464, 465, 466, 471, 472, 473, 475, 476, 477, 482, 483, 484, 485, 486, 488, 489, 490, 495, 496, 497, 498, 499, 501, 502, 503, 508, 509, 510, 511, 512, 515, 516, 517, 522, 523, 524, 525, 527, 530, 534, 537, 538, 539, 544, 545, 550, 551, 554, 555, 556, 558, 561, 565, 568, 572, 575, 576, 577, 578, 579, 580, 583, 584, 585, 586, 587, 588, 589, 593, 594, 595, 600, 601, 606, 607, 608, 609, 611, 614, 618, 621, 622, 627, 628, 629, 630, 633, 635, 636, 637, 638, 640, 647, 650, 652, 653, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 675, 676, 677, 678, 680, 683, 687, 690, 691, 696, 697, 698, 699, 702, 703, 704, 709, 710, 711, 713, 714, 715, 716, 717, 718, 721, 725, 726, 727, 732, 733, 734, 735, 736, 737, 739, 742, 743, 744, 745, 747, 750, 754, 757, 761, 764, 765, 766, 767, 768, 769, 770, 771, 772, 774, 775, 776, 777, 778, 779, 782, 786, 787, 788, 790, 791, 792, 795, 796, 797, 799, 800, 801, 807, 808, 809, 812, 813, 814, 815, 820, 821, 822, 827, 828, 829, 834, 835, 836, 837, 839, 840, 841, 842, 843, 848, 849, 850, 851, 853, 854, 857, 858, 859, 864, 865, 866, 871, 872, 875, 880, 881, 884, 888, 889, 890, 892, 893, 894, 896, 897, 902, 903, 906, 907, 908, 910, 913, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 934, 935, 938, 939, 940, 945, 946, 947, 948, 949, 950, 952, 955, 956, 957, 958, 960, 963, 967, 970, 974, 977, 978, 979, 980, 981, 982, 983, 984, 994, 995, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1032, 1035, 1039, 1042};
/* BEGIN LINEINFO 
assign 1 26 82
new 0 26 82
fromString 1 27 83
assign 1 29 84
new 1 29 84
assign 1 30 85
NAMEPATHGet 0 30 85
typenameSet 1 30 86
heldSet 1 31 87
copyLoc 1 32 88
assign 1 34 89
new 0 34 89
assign 1 35 90
new 0 35 90
nameSet 1 35 91
assign 1 36 92
new 0 36 92
wasBoundSet 1 36 93
assign 1 37 94
new 0 37 94
boundSet 1 37 95
assign 1 38 96
new 0 38 96
isConstructSet 1 38 97
assign 1 39 98
new 0 39 98
isLiteralSet 1 39 99
assign 1 40 100
heldGet 0 40 100
literalValueSet 1 40 101
addValue 1 42 102
assign 1 44 103
CALLGet 0 44 103
typenameSet 1 44 104
heldSet 1 45 105
resolveNp 0 47 106
assign 1 49 107
new 0 49 107
assign 1 49 108
equals 1 49 108
assign 1 0 110
assign 1 49 113
new 0 49 113
assign 1 49 114
equals 1 49 114
assign 1 0 116
assign 1 0 119
assign 1 50 123
priorPeerGet 0 50 123
assign 1 51 124
def 1 51 129
assign 1 51 130
typenameGet 0 51 130
assign 1 51 131
SUBTRACTGet 0 51 131
assign 1 51 132
equals 1 51 132
assign 1 0 134
assign 1 51 137
typenameGet 0 51 137
assign 1 51 138
ADDGet 0 51 138
assign 1 51 139
equals 1 51 139
assign 1 0 141
assign 1 0 144
assign 1 0 148
assign 1 0 151
assign 1 0 155
assign 1 52 158
priorPeerGet 0 52 158
assign 1 53 159
undef 1 53 164
assign 1 0 165
assign 1 53 168
typenameGet 0 53 168
assign 1 53 169
CALLGet 0 53 169
assign 1 53 170
notEquals 1 53 170
assign 1 53 172
typenameGet 0 53 172
assign 1 53 173
IDGet 0 53 173
assign 1 53 174
notEquals 1 53 174
assign 1 0 176
assign 1 0 179
assign 1 0 183
assign 1 53 186
typenameGet 0 53 186
assign 1 53 187
VARGet 0 53 187
assign 1 53 188
notEquals 1 53 188
assign 1 0 190
assign 1 0 193
assign 1 0 197
assign 1 53 200
typenameGet 0 53 200
assign 1 53 201
ACCESSORGet 0 53 201
assign 1 53 202
notEquals 1 53 202
assign 1 0 204
assign 1 0 207
assign 1 0 211
assign 1 0 214
assign 1 0 217
assign 1 59 221
heldGet 0 59 221
assign 1 59 222
literalValueGet 0 59 222
assign 1 59 223
add 1 59 223
literalValueSet 1 59 224
delete 0 60 225
assign 1 86 418
nextPeerGet 0 86 418
assign 1 89 419
typenameGet 0 89 419
assign 1 89 420
CLASSGet 0 89 420
assign 1 89 421
equals 1 89 426
assign 1 90 427
heldGet 0 90 427
assign 1 90 428
namepathGet 0 90 428
assign 1 91 429
heldGet 0 91 429
assign 1 91 430
fromFileGet 0 91 430
assign 1 91 431
toString 0 91 431
assign 1 93 433
def 1 93 438
inClassNpSet 1 94 439
inFileSet 1 95 440
assign 1 97 442
typenameGet 0 97 442
assign 1 97 443
INTLGet 0 97 443
assign 1 97 444
equals 1 97 449
assign 1 98 450
new 0 98 450
buildLiteral 2 98 451
assign 1 100 453
typenameGet 0 100 453
assign 1 100 454
FLOATLGet 0 100 454
assign 1 100 455
equals 1 100 460
assign 1 101 461
new 0 101 461
buildLiteral 2 101 462
assign 1 103 464
typenameGet 0 103 464
assign 1 103 465
STRINGLGet 0 103 465
assign 1 103 466
equals 1 103 471
assign 1 104 472
new 0 104 472
buildLiteral 2 104 473
assign 1 106 475
typenameGet 0 106 475
assign 1 106 476
WSTRINGLGet 0 106 476
assign 1 106 477
equals 1 106 482
assign 1 108 483
new 0 108 483
buildLiteral 2 108 484
assign 1 109 485
new 0 109 485
wideStringSet 1 109 486
assign 1 111 488
typenameGet 0 111 488
assign 1 111 489
TRUEGet 0 111 489
assign 1 111 490
equals 1 111 495
assign 1 112 496
new 0 112 496
heldSet 1 112 497
assign 1 113 498
new 0 113 498
buildLiteral 2 113 499
assign 1 119 501
typenameGet 0 119 501
assign 1 119 502
FALSEGet 0 119 502
assign 1 119 503
equals 1 119 508
assign 1 120 509
new 0 120 509
heldSet 1 120 510
assign 1 121 511
new 0 121 511
buildLiteral 2 121 512
assign 1 123 515
typenameGet 0 123 515
assign 1 123 516
VARGet 0 123 516
assign 1 123 517
equals 1 123 522
assign 1 123 523
heldGet 0 123 523
assign 1 123 524
isArgGet 0 123 524
assign 1 123 525
not 0 123 525
assign 1 0 527
assign 1 0 530
assign 1 0 534
assign 1 124 537
heldGet 0 124 537
assign 1 124 538
nameGet 0 124 538
assign 1 124 539
undef 1 124 544
assign 1 124 545
undef 1 124 550
assign 1 0 551
assign 1 124 554
typenameGet 0 124 554
assign 1 124 555
IDGet 0 124 555
assign 1 124 556
notEquals 1 124 556
assign 1 0 558
assign 1 0 561
assign 1 0 565
assign 1 0 568
assign 1 0 572
assign 1 125 575
new 0 125 575
assign 1 125 576
heldGet 0 125 576
assign 1 125 577
nameGet 0 125 577
assign 1 125 578
add 1 125 578
assign 1 125 579
new 2 125 579
throw 1 125 580
assign 1 127 583
heldGet 0 127 583
assign 1 127 584
heldGet 0 127 584
nameSet 1 127 585
addVariable 0 128 586
delete 0 129 587
assign 1 133 588
nextDescendGet 0 133 588
return 1 133 589
assign 1 135 593
typenameGet 0 135 593
assign 1 135 594
IDGet 0 135 594
assign 1 135 595
equals 1 135 600
assign 1 136 601
def 1 136 606
assign 1 136 607
typenameGet 0 136 607
assign 1 136 608
PARENSGet 0 136 608
assign 1 136 609
equals 1 136 609
assign 1 0 611
assign 1 0 614
assign 1 0 618
assign 1 137 621
containedGet 0 137 621
assign 1 137 622
def 1 137 627
assign 1 138 628
new 0 138 628
assign 1 139 629
containedGet 0 139 629
assign 1 139 630
iteratorGet 0 139 630
assign 1 139 633
hasNextGet 0 139 633
assign 1 140 635
nextGet 0 140 635
assign 1 141 636
typenameGet 0 141 636
assign 1 141 637
COMMAGet 0 141 637
assign 1 141 638
equals 1 141 638
addValue 1 142 640
assign 1 145 647
iteratorGet 0 145 647
assign 1 145 650
hasNextGet 0 145 650
assign 1 146 652
nextGet 0 146 652
delete 0 147 653
assign 1 150 660
assign 1 151 661
CALLGet 0 151 661
typenameSet 1 151 662
assign 1 152 663
new 0 152 663
assign 1 153 664
heldGet 0 153 664
nameSet 1 153 665
heldSet 1 154 666
delete 0 155 667
assign 1 156 668
assign 1 157 669
priorPeerGet 0 157 669
assign 1 158 670
def 1 158 675
assign 1 158 676
typenameGet 0 158 676
assign 1 158 677
DOTGet 0 158 677
assign 1 158 678
equals 1 158 678
assign 1 0 680
assign 1 0 683
assign 1 0 687
assign 1 159 690
priorPeerGet 0 159 690
assign 1 160 691
undef 1 160 696
assign 1 161 697
new 0 161 697
assign 1 161 698
new 2 161 698
throw 1 161 699
assign 1 162 702
typenameGet 0 162 702
assign 1 162 703
NAMEPATHGet 0 162 703
assign 1 162 704
equals 1 162 709
assign 1 163 710
nameGet 0 163 710
assign 1 163 711
isNewish 1 163 711
assign 1 164 713
new 0 164 713
wasBoundSet 1 164 714
assign 1 165 715
new 0 165 715
boundSet 1 165 716
assign 1 166 717
new 0 166 717
isConstructSet 1 166 718
createImpliedConstruct 2 168 721
assign 1 170 725
typenameGet 0 170 725
assign 1 170 726
IDGet 0 170 726
assign 1 170 727
equals 1 170 732
assign 1 170 733
transUnitGet 0 170 733
assign 1 170 734
heldGet 0 170 734
assign 1 170 735
aliasedGet 0 170 735
assign 1 170 736
heldGet 0 170 736
assign 1 170 737
has 1 170 737
assign 1 0 739
assign 1 170 742
emitDataGet 0 170 742
assign 1 170 743
aliasedGet 0 170 743
assign 1 170 744
heldGet 0 170 744
assign 1 170 745
has 1 170 745
assign 1 0 747
assign 1 0 750
assign 1 0 754
assign 1 0 757
assign 1 0 761
assign 1 171 764
new 0 171 764
assign 1 172 765
heldGet 0 172 765
addStep 1 172 766
heldSet 1 173 767
assign 1 174 768
NAMEPATHGet 0 174 768
typenameSet 1 174 769
resolveNp 0 175 770
assign 1 176 771
nameGet 0 176 771
assign 1 176 772
isNewish 1 176 772
assign 1 177 774
new 0 177 774
wasBoundSet 1 177 775
assign 1 178 776
new 0 178 776
boundSet 1 178 777
assign 1 179 778
new 0 179 778
isConstructSet 1 179 779
createImpliedConstruct 2 181 782
assign 1 183 786
nameGet 0 183 786
assign 1 183 787
new 0 183 787
assign 1 183 788
equals 1 183 788
assign 1 184 790
new 0 184 790
assign 1 184 791
new 2 184 791
throw 1 184 792
assign 1 185 795
nameGet 0 185 795
assign 1 185 796
new 0 185 796
assign 1 185 797
equals 1 185 797
assign 1 186 799
new 0 186 799
assign 1 186 800
new 2 186 800
throw 1 186 801
delete 0 189 807
prepend 1 190 808
delete 0 191 809
assign 1 193 812
new 0 193 812
boundSet 1 193 813
assign 1 194 814
new 0 194 814
wasBoundSet 1 194 815
assign 1 198 820
typenameGet 0 198 820
assign 1 198 821
IDXGet 0 198 821
assign 1 198 822
equals 1 198 827
assign 1 201 828
priorPeerGet 0 201 828
assign 1 202 829
undef 1 202 834
assign 1 203 835
new 0 203 835
assign 1 203 836
new 2 203 836
throw 1 203 837
delete 0 205 839
prepend 1 206 840
assign 1 207 841
typenameGet 0 207 841
assign 1 207 842
NAMEPATHGet 0 207 842
assign 1 207 843
equals 1 207 848
assign 1 208 849
new 0 208 849
assign 1 208 850
new 2 208 850
throw 1 208 851
assign 1 210 853
IDXACCGet 0 210 853
typenameSet 1 210 854
assign 1 211 857
typenameGet 0 211 857
assign 1 211 858
DOTGet 0 211 858
assign 1 211 859
equals 1 211 864
assign 1 213 865
priorPeerGet 0 213 865
assign 1 216 866
undef 1 216 871
assign 1 0 872
assign 1 216 875
undef 1 216 880
assign 1 0 881
assign 1 0 884
assign 1 217 888
new 0 217 888
assign 1 217 889
new 2 217 889
throw 1 217 890
assign 1 219 892
typenameGet 0 219 892
assign 1 219 893
IDGet 0 219 893
assign 1 219 894
equals 1 219 894
assign 1 220 896
nextPeerGet 0 220 896
assign 1 221 897
undef 1 221 902
assign 1 0 903
assign 1 221 906
typenameGet 0 221 906
assign 1 221 907
PARENSGet 0 221 907
assign 1 221 908
notEquals 1 221 908
assign 1 0 910
assign 1 0 913
assign 1 222 917
priorPeerGet 0 222 917
assign 1 223 918
ACCESSORGet 0 223 918
typenameSet 1 223 919
assign 1 224 920
new 0 224 920
assign 1 225 921
heldGet 0 225 921
nameSet 1 225 922
delete 0 226 923
delete 0 227 924
heldSet 1 228 925
addValue 1 229 926
assign 1 230 927
typenameGet 0 230 927
assign 1 230 928
NAMEPATHGet 0 230 928
assign 1 230 929
equals 1 230 934
createImpliedConstruct 2 231 935
assign 1 232 938
typenameGet 0 232 938
assign 1 232 939
IDGet 0 232 939
assign 1 232 940
equals 1 232 945
assign 1 232 946
transUnitGet 0 232 946
assign 1 232 947
heldGet 0 232 947
assign 1 232 948
aliasedGet 0 232 948
assign 1 232 949
heldGet 0 232 949
assign 1 232 950
has 1 232 950
assign 1 0 952
assign 1 232 955
emitDataGet 0 232 955
assign 1 232 956
aliasedGet 0 232 956
assign 1 232 957
heldGet 0 232 957
assign 1 232 958
has 1 232 958
assign 1 0 960
assign 1 0 963
assign 1 0 967
assign 1 0 970
assign 1 0 974
assign 1 233 977
new 0 233 977
assign 1 234 978
heldGet 0 234 978
addStep 1 234 979
heldSet 1 235 980
assign 1 236 981
NAMEPATHGet 0 236 981
typenameSet 1 236 982
resolveNp 0 237 983
createImpliedConstruct 2 238 984
assign 1 243 994
nextDescendGet 0 243 994
return 1 243 995
assign 1 247 1008
new 0 247 1008
heldSet 1 248 1009
assign 1 249 1010
NAMEPATHGet 0 249 1010
typenameSet 1 249 1011
assign 1 250 1012
heldGet 0 250 1012
heldSet 1 250 1013
prepend 1 251 1014
assign 1 253 1015
new 0 253 1015
assign 1 254 1016
new 0 254 1016
nameSet 1 254 1017
assign 1 255 1018
new 0 255 1018
wasBoundSet 1 255 1019
assign 1 256 1020
new 0 256 1020
boundSet 1 256 1021
assign 1 257 1022
new 0 257 1022
isConstructSet 1 257 1023
assign 1 258 1024
new 0 258 1024
wasImpliedConstructSet 1 258 1025
heldSet 1 259 1026
assign 1 260 1027
CALLGet 0 260 1027
typenameSet 1 260 1028
return 1 0 1032
assign 1 0 1035
return 1 0 1039
assign 1 0 1042
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1308786538: return bem_echo_0();
case -1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1755995201: return bem_transGet_0();
case 822104518: return bem_inFileGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 856627742: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
case 681472468: return bem_buildLiteral_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass7.bevs_inst = (BEC_3_5_5_5_BuildVisitPass7)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass7.bevs_inst;
}
}
}
