namespace be {
/* IO:File: source/build/EmitData.be */
public sealed class BEC_2_5_13_BuildPropertyIndex : BEC_2_6_6_SystemObject {
public BEC_2_5_13_BuildPropertyIndex() { }
static BEC_2_5_13_BuildPropertyIndex() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x49,0x6E,0x64,0x65,0x78};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static new BEC_2_5_13_BuildPropertyIndex bevs_inst;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_5_6_BuildPtySyn bevp_psyn;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_13_BuildPropertyIndex bem_new_2(BEC_2_5_8_BuildClassSyn beva__syn, BEC_2_5_6_BuildPtySyn beva__psyn) {
bevp_syn = beva__syn;
bevp_psyn = beva__psyn;
bevp_origin = bevp_psyn.bem_originGet_0();
bevp_name = bevp_psyn.bem_nameGet_0();
return this;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_origin.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_name);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_4_tmpany_phold = this.bem_sameClass_1(beva_x);
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 87 */
bevt_7_tmpany_phold = beva_x.bemd_0(1707345409, BEL_4_Base.bevn_originGet_0);
bevt_6_tmpany_phold = bevp_origin.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_9_tmpany_phold = beva_x.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 88 */
 else  /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 88 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 89 */
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_psynGet_0() {
return bevp_psyn;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_psynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_psyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() {
return bevp_origin;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {75, 76, 77, 78, 83, 83, 83, 83, 87, 87, 0, 87, 87, 87, 0, 0, 87, 87, 88, 88, 88, 88, 0, 0, 0, 89, 89, 91, 91, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 16, 17, 24, 25, 26, 27, 42, 47, 48, 51, 52, 57, 58, 61, 65, 66, 68, 69, 71, 72, 74, 77, 81, 84, 85, 87, 88, 91, 94, 98, 101, 105, 108, 112, 115};
/* BEGIN LINEINFO 
assign 1 75 14
assign 1 76 15
assign 1 77 16
originGet 0 77 16
assign 1 78 17
nameGet 0 78 17
assign 1 83 24
toString 0 83 24
assign 1 83 25
add 1 83 25
assign 1 83 26
hashGet 0 83 26
return 1 83 27
assign 1 87 42
undef 1 87 47
assign 1 0 48
assign 1 87 51
sameClass 1 87 51
assign 1 87 52
not 0 87 57
assign 1 0 58
assign 1 0 61
assign 1 87 65
new 0 87 65
return 1 87 66
assign 1 88 68
originGet 0 88 68
assign 1 88 69
equals 1 88 69
assign 1 88 71
nameGet 0 88 71
assign 1 88 72
equals 1 88 72
assign 1 0 74
assign 1 0 77
assign 1 0 81
assign 1 89 84
new 0 89 84
return 1 89 85
assign 1 91 87
new 0 91 87
return 1 91 88
return 1 0 91
assign 1 0 94
return 1 0 98
assign 1 0 101
return 1 0 105
assign 1 0 108
return 1 0 112
assign 1 0 115
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1707345409: return bem_originGet_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 1219951631: return bem_psynGet_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1791388575: return bem_synGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case 1211273660: return bem_nameGet_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1718427662: return bem_originSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1802470828: return bem_synSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1231033884: return bem_psynSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 104713555: return bem_new_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_6_BuildPtySyn) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_13_BuildPropertyIndex();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_13_BuildPropertyIndex.bevs_inst = (BEC_2_5_13_BuildPropertyIndex)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_13_BuildPropertyIndex.bevs_inst;
}
}
}
