namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerQueue : BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerQueue() { }
static BEC_2_9_5_ContainerQueue() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_2_9_5_ContainerQueue bevs_inst;
public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_bottom;
public BEC_3_9_5_4_ContainerStackNode bevp_end;
public BEC_2_4_3_MathInt bevp_size;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_addValue_1(BEC_2_6_6_SystemObject beva_item) {
this.bem_enqueue_1(beva_item);
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_end = bevp_top;
bevp_bottom = bevp_top;
} /* Line: 129 */
 else  /* Line: 126 */ {
if (bevp_bottom == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevt_3_tmpany_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_4_tmpany_phold = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpany_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
bevp_end = bevp_top;
} /* Line: 135 */
 else  /* Line: 136 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 137 */
} /* Line: 131 */
 else  /* Line: 139 */ {
bevp_bottom = bevp_top;
} /* Line: 140 */
} /* Line: 126 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_dequeue_0() {
BEC_2_6_6_SystemObject bevl_item = null;
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 147 */ {
return null;
} /* Line: 148 */
bevl_item = bevp_bottom.bem_heldGet_0();
bevp_bottom.bem_heldSet_1(null);
bevt_1_tmpany_phold = bevp_bottom.bem_equals_1(bevp_top);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevp_bottom = null;
} /* Line: 153 */
 else  /* Line: 154 */ {
bevl_last = bevp_bottom;
bevp_bottom = bevp_bottom.bem_nextGet_0();
bevl_last.bem_nextSet_1(null);
bevl_last.bem_priorSet_1(bevp_end);
bevp_end.bem_nextSet_1(bevl_last);
bevp_end = bevl_last;
} /* Line: 161 */
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_dequeue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_9_5_ContainerQueue bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_5_ContainerQueue) this.bem_enqueue_1(beva_item);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_topGet_0() {
return bevp_top;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_bottomGet_0() {
return bevp_bottom;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_bottomSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bottom = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_endGet_0() {
return bevp_end;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_endSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_end = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {116, 122, 126, 126, 127, 128, 129, 130, 130, 131, 131, 131, 132, 132, 133, 133, 134, 135, 137, 140, 142, 143, 147, 147, 148, 150, 151, 152, 153, 156, 157, 158, 159, 160, 161, 163, 164, 168, 168, 172, 172, 176, 176, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 18, 28, 33, 34, 35, 36, 39, 44, 45, 46, 51, 52, 53, 54, 55, 56, 57, 60, 64, 67, 68, 76, 81, 82, 84, 85, 86, 88, 91, 92, 93, 94, 95, 96, 98, 99, 103, 108, 112, 113, 117, 118, 121, 124, 128, 131, 135, 138, 142, 145};
/* BEGIN LINEINFO 
assign 1 116 14
new 0 116 14
enqueue 1 122 18
assign 1 126 28
undef 1 126 33
assign 1 127 34
new 0 127 34
assign 1 128 35
assign 1 129 36
assign 1 130 39
def 1 130 44
assign 1 131 45
nextGet 0 131 45
assign 1 131 46
undef 1 131 51
assign 1 132 52
new 0 132 52
nextSet 1 132 53
assign 1 133 54
nextGet 0 133 54
priorSet 1 133 55
assign 1 134 56
nextGet 0 134 56
assign 1 135 57
assign 1 137 60
nextGet 0 137 60
assign 1 140 64
heldSet 1 142 67
assign 1 143 68
increment 0 143 68
assign 1 147 76
undef 1 147 81
return 1 148 82
assign 1 150 84
heldGet 0 150 84
heldSet 1 151 85
assign 1 152 86
equals 1 152 86
assign 1 153 88
assign 1 156 91
assign 1 157 92
nextGet 0 157 92
nextSet 1 158 93
priorSet 1 159 94
nextSet 1 160 95
assign 1 161 96
assign 1 163 98
decrement 0 163 98
return 1 164 99
assign 1 168 103
undef 1 168 108
return 1 168 108
assign 1 172 112
dequeue 0 172 112
return 1 172 113
assign 1 176 117
enqueue 1 176 117
return 1 176 118
return 1 0 121
assign 1 0 124
return 1 0 128
assign 1 0 131
return 1 0 135
assign 1 0 138
return 1 0 142
assign 1 0 145
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case 98246023: return bem_get_0();
case -1308786538: return bem_echo_0();
case 1702950252: return bem_endGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case -631556580: return bem_bottomGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 228537569: return bem_dequeue_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1820417453: return bem_create_0();
case -988612302: return bem_topGet_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 107034369: return bem_put_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -620474327: return bem_bottomSet_1(bevd_0);
case 1221474234: return bem_enqueue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -977530049: return bem_topSet_1(bevd_0);
case 1714032505: return bem_endSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_5_ContainerQueue();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_5_ContainerQueue.bevs_inst = (BEC_2_9_5_ContainerQueue)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_5_ContainerQueue.bevs_inst;
}
}
}
