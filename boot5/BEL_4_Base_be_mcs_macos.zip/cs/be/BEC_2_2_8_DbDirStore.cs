namespace be {
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_8_DbDirStore : BEC_2_6_6_SystemObject {
public BEC_2_2_8_DbDirStore() { }
static BEC_2_2_8_DbDirStore() { }
private static byte[] becc_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 0));
private static byte[] bels_1 = {};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 0));
private static byte[] bels_2 = {};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 0));
private static byte[] bels_3 = {};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 0));
public static new BEC_2_2_8_DbDirStore bevs_inst;
public BEC_2_6_10_SystemSerializer bevp_ser;
public BEC_3_2_4_4_IOFilePath bevp_storageDir;
public BEC_2_6_6_SystemObject bevp_keyEncoder;
public virtual BEC_2_2_8_DbDirStore bem_new_2(BEC_2_4_6_TextString beva_storageDir, BEC_2_6_6_SystemObject beva__keyEncoder) {
this.bem_new_1(beva_storageDir);
bevp_keyEncoder = beva__keyEncoder;
return this;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_new_1(BEC_2_4_6_TextString beva_storageDir) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_storageDir);
this.bem_pathNew_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__storageDir) {
bevp_ser = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevp_storageDir = beva__storageDir;
bevp_keyEncoder = null;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getStoreId_1(BEC_2_4_6_TextString beva_id) {
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_keyEncoder == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevl_storeId = (BEC_2_4_6_TextString) bevp_keyEncoder.bemd_1(1711217736, BEL_4_Base.bevn_encode_1, beva_id);
} /* Line: 374 */
 else  /* Line: 375 */ {
bevl_storeId = beva_id;
} /* Line: 376 */
return bevl_storeId;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_getPath_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_3_tmpany_phold = bevo_0;
bevt_2_tmpany_phold = beva_id.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 383 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 383 */
 else  /* Line: 383 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 383 */ {
bevt_6_tmpany_phold = bevp_storageDir.bem_fileGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_7_tmpany_phold = bevp_storageDir.bem_fileGet_0();
bevt_7_tmpany_phold.bem_makeDirs_0();
} /* Line: 385 */
bevl_storeId = (BEC_2_4_6_TextString) this.bem_getStoreId_1(beva_id);
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_storageDir.bem_copy_0();
bevl_p = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpany_phold.bem_addStep_1(bevl_storeId);
} /* Line: 388 */
return bevl_p;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevt_3_tmpany_phold = bevo_1;
bevt_2_tmpany_phold = beva_id.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 394 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 394 */
 else  /* Line: 394 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 394 */ {
bevl_p = this.bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_7_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_writerGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevp_ser.bem_serialize_2(beva_object, bevt_5_tmpany_phold);
bevt_9_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevt_8_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 398 */
} /* Line: 396 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_6_6_SystemObject bevl_object = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_12_tmpany_phold = null;
if (beva_id == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevt_4_tmpany_phold = bevo_2;
bevt_3_tmpany_phold = beva_id.bem_notEquals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 404 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 404 */
 else  /* Line: 404 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 404 */ {
bevl_p = this.bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 406 */ {
bevt_7_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_existsGet_0();
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 406 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 406 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 406 */
 else  /* Line: 406 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 406 */ {
bevt_10_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_readerGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_object = bevp_ser.bem_deserialize_1(bevt_8_tmpany_phold);
bevt_12_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_readerGet_0();
bevt_11_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return bevl_object;
} /* Line: 409 */
} /* Line: 406 */
return null;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 416 */ {
bevt_3_tmpany_phold = bevo_3;
bevt_2_tmpany_phold = beva_id.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 416 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 416 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 416 */
bevl_p = this.bem_getPath_1(beva_id);
bevt_6_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 418 */ {
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 419 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_delete_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_2_4_IOFile bevt_0_tmpany_phold = null;
bevl_p = this.bem_getPath_1(beva_id);
bevt_0_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_0_tmpany_phold.bem_delete_0();
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemSerializer bem_serGet_0() {
return bevp_ser;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_serSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_storageDirGet_0() {
return bevp_storageDir;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_storageDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_keyEncoderGet_0() {
return bevp_keyEncoder;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_keyEncoderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_keyEncoder = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {355, 356, 360, 360, 365, 366, 367, 373, 373, 374, 376, 378, 383, 383, 383, 383, 0, 0, 0, 384, 384, 384, 384, 385, 385, 387, 388, 388, 390, 394, 394, 394, 394, 0, 0, 0, 395, 396, 396, 397, 397, 397, 397, 398, 398, 398, 404, 404, 404, 404, 0, 0, 0, 405, 406, 406, 406, 406, 0, 0, 0, 407, 407, 407, 407, 408, 408, 408, 409, 412, 416, 416, 0, 416, 416, 0, 0, 416, 416, 417, 418, 418, 419, 419, 421, 421, 425, 426, 426, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 27, 28, 32, 33, 34, 40, 45, 46, 49, 51, 65, 70, 71, 72, 74, 77, 81, 84, 85, 86, 91, 92, 93, 95, 96, 97, 99, 113, 118, 119, 120, 122, 125, 129, 132, 133, 138, 139, 140, 141, 142, 143, 144, 145, 166, 171, 172, 173, 175, 178, 182, 185, 186, 191, 192, 193, 195, 198, 202, 205, 206, 207, 208, 209, 210, 211, 212, 215, 228, 233, 234, 237, 238, 240, 243, 247, 248, 250, 251, 252, 254, 255, 257, 258, 263, 264, 265, 269, 272, 276, 279, 283, 286};
/* BEGIN LINEINFO 
new 1 355 21
assign 1 356 22
assign 1 360 27
apNew 1 360 27
pathNew 1 360 28
assign 1 365 32
new 0 365 32
assign 1 366 33
assign 1 367 34
assign 1 373 40
def 1 373 45
assign 1 374 46
encode 1 374 46
assign 1 376 49
return 1 378 51
assign 1 383 65
def 1 383 70
assign 1 383 71
new 0 383 71
assign 1 383 72
notEquals 1 383 72
assign 1 0 74
assign 1 0 77
assign 1 0 81
assign 1 384 84
fileGet 0 384 84
assign 1 384 85
existsGet 0 384 85
assign 1 384 86
not 0 384 91
assign 1 385 92
fileGet 0 385 92
makeDirs 0 385 93
assign 1 387 95
getStoreId 1 387 95
assign 1 388 96
copy 0 388 96
assign 1 388 97
addStep 1 388 97
return 1 390 99
assign 1 394 113
def 1 394 118
assign 1 394 119
new 0 394 119
assign 1 394 120
notEquals 1 394 120
assign 1 0 122
assign 1 0 125
assign 1 0 129
assign 1 395 132
getPath 1 395 132
assign 1 396 133
def 1 396 138
assign 1 397 139
fileGet 0 397 139
assign 1 397 140
writerGet 0 397 140
assign 1 397 141
open 0 397 141
serialize 2 397 142
assign 1 398 143
fileGet 0 398 143
assign 1 398 144
writerGet 0 398 144
close 0 398 145
assign 1 404 166
def 1 404 171
assign 1 404 172
new 0 404 172
assign 1 404 173
notEquals 1 404 173
assign 1 0 175
assign 1 0 178
assign 1 0 182
assign 1 405 185
getPath 1 405 185
assign 1 406 186
def 1 406 191
assign 1 406 192
fileGet 0 406 192
assign 1 406 193
existsGet 0 406 193
assign 1 0 195
assign 1 0 198
assign 1 0 202
assign 1 407 205
fileGet 0 407 205
assign 1 407 206
readerGet 0 407 206
assign 1 407 207
open 0 407 207
assign 1 407 208
deserialize 1 407 208
assign 1 408 209
fileGet 0 408 209
assign 1 408 210
readerGet 0 408 210
close 0 408 211
return 1 409 212
return 1 412 215
assign 1 416 228
undef 1 416 233
assign 1 0 234
assign 1 416 237
new 0 416 237
assign 1 416 238
equals 1 416 238
assign 1 0 240
assign 1 0 243
assign 1 416 247
new 0 416 247
return 1 416 248
assign 1 417 250
getPath 1 417 250
assign 1 418 251
fileGet 0 418 251
assign 1 418 252
existsGet 0 418 252
assign 1 419 254
new 0 419 254
return 1 419 255
assign 1 421 257
new 0 421 257
return 1 421 258
assign 1 425 263
getPath 1 425 263
assign 1 426 264
fileGet 0 426 264
delete 0 426 265
return 1 0 269
assign 1 0 272
return 1 0 276
assign 1 0 279
return 1 0 283
assign 1 0 286
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -770804587: return bem_storageDirGet_0();
case 1335700743: return bem_serGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 1875432906: return bem_keyEncoderGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -759722334: return bem_storageDirSet_1(bevd_0);
case 99049420: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 819712669: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 700652941: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1682031576: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case -393721811: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1346782996: return bem_serSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1886515159: return bem_keyEncoderSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 107034370: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 104713555: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_8_DbDirStore();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_8_DbDirStore.bevs_inst = (BEC_2_2_8_DbDirStore)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_8_DbDirStore.bevs_inst;
}
}
}
