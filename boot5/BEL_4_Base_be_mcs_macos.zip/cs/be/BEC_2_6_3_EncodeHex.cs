namespace be {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeHex : BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeHex() { }
static BEC_2_6_3_EncodeHex() { }
private static byte[] becc_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x65,0x78};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_0 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x68,0x65,0x78,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 26));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
public static new BEC_2_6_3_EncodeHex bevs_inst;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_3_EncodeHex bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl_ac = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_cur = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_2_tmpany_phold = bevo_0;
bevt_1_tmpany_phold = bevl_ssz.bem_multiply_1(bevt_2_tmpany_phold);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
bevl_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 24 */ {
if (bevl_pos.bevi_int < bevl_ssz.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 24 */ {
beva_str.bem_getCode_2(bevl_pos, bevl_ac);
bevt_4_tmpany_phold = bevl_ac.bem_toHexString_1(bevl_cur);
bevl_r.bem_addValue_1(bevt_4_tmpany_phold);
bevl_pos.bevi_int++;
} /* Line: 24 */
 else  /* Line: 24 */ {
break;
} /* Line: 24 */
} /* Line: 24 */
return bevl_r;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pta = null;
BEC_2_4_6_TextString bevl_ptb = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_1_tmpany_phold = bevo_1;
if (bevl_ssz.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 33 */ {
return beva_str;
} /* Line: 34 */
bevt_4_tmpany_phold = bevo_2;
bevt_3_tmpany_phold = bevl_ssz.bem_modulus_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevo_3;
if (bevt_3_tmpany_phold.bevi_int != bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 36 */ {
bevt_8_tmpany_phold = bevo_4;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevl_ssz);
bevt_6_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 37 */
bevt_9_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_cur = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bevo_5;
bevt_10_tmpany_phold = bevl_ssz.bem_divide_1(bevt_11_tmpany_phold);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = bevo_6;
bevt_12_tmpany_phold = bevl_ssz.bem_divide_1(bevt_13_tmpany_phold);
bevl_r.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_tb = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_14_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_pta = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ptb = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_15_tmpany_phold);
bevl_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 46 */ {
bevt_16_tmpany_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevl_tb.bem_next_1(bevl_pta);
bevl_tb.bem_next_1(bevl_ptb);
bevt_18_tmpany_phold = bevl_pta.bem_add_1(bevl_ptb);
bevt_17_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_tmpany_phold);
bevl_r.bem_setCodeUnchecked_2(bevl_pos, bevt_17_tmpany_phold);
bevl_pos.bevi_int++;
} /* Line: 50 */
 else  /* Line: 46 */ {
break;
} /* Line: 46 */
} /* Line: 46 */
return bevl_r;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {20, 21, 21, 22, 23, 23, 23, 24, 24, 24, 25, 26, 26, 24, 28, 32, 33, 33, 33, 34, 36, 36, 36, 36, 36, 37, 37, 37, 37, 39, 39, 40, 40, 40, 41, 41, 41, 42, 43, 43, 44, 44, 45, 46, 47, 48, 49, 49, 49, 50, 52};
public static new int[] bevs_smnlec
 = new int[] {36, 37, 38, 39, 40, 41, 42, 43, 46, 51, 52, 53, 54, 55, 61, 90, 91, 92, 97, 98, 100, 101, 102, 103, 108, 109, 110, 111, 112, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130, 132, 133, 134, 135, 136, 137, 143};
/* BEGIN LINEINFO 
assign 1 20 36
new 0 20 36
assign 1 21 37
new 0 21 37
assign 1 21 38
new 1 21 38
assign 1 22 39
sizeGet 0 22 39
assign 1 23 40
new 0 23 40
assign 1 23 41
multiply 1 23 41
assign 1 23 42
new 1 23 42
assign 1 24 43
new 0 24 43
assign 1 24 46
lesser 1 24 51
getCode 2 25 52
assign 1 26 53
toHexString 1 26 53
addValue 1 26 54
incrementValue 0 24 55
return 1 28 61
assign 1 32 90
sizeGet 0 32 90
assign 1 33 91
new 0 33 91
assign 1 33 92
lesser 1 33 97
return 1 34 98
assign 1 36 100
new 0 36 100
assign 1 36 101
modulus 1 36 101
assign 1 36 102
new 0 36 102
assign 1 36 103
notEquals 1 36 108
assign 1 37 109
new 0 37 109
assign 1 37 110
add 1 37 110
assign 1 37 111
new 1 37 111
throw 1 37 112
assign 1 39 114
new 0 39 114
assign 1 39 115
new 1 39 115
assign 1 40 116
new 0 40 116
assign 1 40 117
divide 1 40 117
assign 1 40 118
new 1 40 118
assign 1 41 119
new 0 41 119
assign 1 41 120
divide 1 41 120
sizeSet 1 41 121
assign 1 42 122
new 1 42 122
assign 1 43 123
new 0 43 123
assign 1 43 124
new 1 43 124
assign 1 44 125
new 0 44 125
assign 1 44 126
new 1 44 126
assign 1 45 127
new 0 45 127
assign 1 46 130
hasNextGet 0 46 130
next 1 47 132
next 1 48 133
assign 1 49 134
add 1 49 134
assign 1 49 135
hexNew 1 49 135
setCodeUnchecked 2 49 136
incrementValue 0 50 137
return 1 52 143
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1711217736: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 570808864: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_3_EncodeHex();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_3_EncodeHex.bevs_inst = (BEC_2_6_3_EncodeHex)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_3_EncodeHex.bevs_inst;
}
}
}
