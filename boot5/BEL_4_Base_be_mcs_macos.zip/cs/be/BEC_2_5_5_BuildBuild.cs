namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bels_6 = {0x31};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_12, 5));
private static byte[] bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_23 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_24 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_25 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_26 = {0x74,0x72,0x75,0x65};
private static byte[] bels_27 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_29 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bels_30 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_51 = {0x72,0x75,0x6E};
private static byte[] bels_52 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_53 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_54 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bels_55 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_56 = {0x67,0x63,0x63};
private static byte[] bels_57 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_59 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_59, 9));
private static byte[] bels_60 = {};
private static byte[] bels_61 = {0x63};
private static byte[] bels_62 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_62, 8));
private static byte[] bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_63, 7));
private static byte[] bels_64 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_65 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_66 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_66, 2));
private static byte[] bels_67 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_67, 2));
private static byte[] bels_68 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_68, 2));
private static byte[] bels_69 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_70 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_70, 13));
private static byte[] bels_71 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_71, 18));
private static byte[] bels_72 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_72, 19));
private static byte[] bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_73, 31));
private static byte[] bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_74, 30));
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_75, 41));
private static byte[] bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_76, 31));
private static byte[] bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_77, 41));
private static byte[] bels_78 = {0x2F};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_78, 1));
private static byte[] bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_79, 31));
private static byte[] bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_80, 41));
private static byte[] bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_81, 51));
private static byte[] bels_82 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_82, 14));
private static byte[] bels_83 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_83, 19));
private static byte[] bels_84 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_84, 9));
private static byte[] bels_85 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_85, 13));
private static byte[] bels_86 = {0x2E,0x20};
private static BEC_2_4_6_TextString bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_86, 2));
private static byte[] bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_87, 22));
private static byte[] bels_88 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_88, 3));
private static byte[] bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_89, 15));
private static byte[] bels_90 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_90, 4));
private static byte[] bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_91, 15));
private static byte[] bels_92 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_92, 5));
private static byte[] bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_93, 15));
private static byte[] bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_94, 6));
private static byte[] bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bevo_35 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_95, 15));
private static byte[] bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_36 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_96, 7));
private static byte[] bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bevo_37 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_97, 15));
private static byte[] bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_38 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_98, 8));
private static byte[] bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_99, 15));
private static byte[] bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_40 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_100, 9));
private static byte[] bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bevo_41 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_101, 15));
private static byte[] bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_42 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_102, 10));
private static byte[] bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bevo_43 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_103, 15));
private static byte[] bels_104 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_44 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_104, 11));
private static byte[] bels_105 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bevo_45 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_105, 16));
private static byte[] bels_106 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_46 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_106, 12));
private static byte[] bels_107 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bevo_47 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_107, 16));
private static byte[] bels_108 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_48 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_108, 13));
private static byte[] bels_109 = {0x20};
private static BEC_2_4_6_TextString bevo_49 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_109, 1));
private static byte[] bels_110 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bevo_50 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_110, 16));
private static byte[] bels_111 = {0x6E,0x65,0x77};
private static byte[] bels_112 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_113 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static new BEC_2_5_5_BuildBuild bevs_inst;
public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_dynConditionsAll;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_saveSyns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_3_tmpany_phold = bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_5_tmpany_phold = bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
 else  /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 96 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 97 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevt_2_tmpany_phold = this.bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_5));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 115 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevl_res = this.bem_go_0();
bevl_i.bevi_int++;
} /* Line: 115 */
 else  /* Line: 115 */ {
break;
} /* Line: 115 */
} /* Line: 115 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 125 */ {
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_7));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_8));
} /* Line: 128 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 133 */
if (bevp_printSteps.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 136 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 142 */ {
} /* Line: 142 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_119_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_122_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_125_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_126_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_127_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_11));
bevt_5_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_6_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 153 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpany_phold).bevi_bool) /* Line: 153 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpany_phold);
} /* Line: 156 */
} /* Line: 154 */
 else  /* Line: 153 */ {
break;
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
bevt_13_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_nameGet_0();
bevt_14_tmpany_phold = bevo_3;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_equals_1(bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 162 */
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_13));
bevt_15_tmpany_phold = bevp_params.bem_get_1(bevt_16_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_14));
bevt_17_tmpany_phold = bevp_params.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 165 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_15));
bevt_19_tmpany_phold = bevp_params.bem_get_1(bevt_20_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_firstGet_0();
} /* Line: 166 */
 else  /* Line: 167 */ {
bevp_exeName = bevp_libName;
} /* Line: 168 */
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_16));
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_17));
bevt_23_tmpany_phold = bevp_params.bem_get_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_firstGet_0();
bevt_21_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpany_phold);
bevp_buildPath = bevt_21_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_19));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_20));
bevt_29_tmpany_phold = bevp_params.bem_get_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_firstGet_0();
bevt_27_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpany_phold);
bevp_includePath = bevt_27_tmpany_phold.bem_pathGet_0();
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_21));
bevt_36_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_nameGet_0();
bevt_33_tmpany_phold = bevp_params.bem_get_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_22));
bevt_40_tmpany_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpany_phold = bevp_params.bem_get_2(bevt_39_tmpany_phold, (BEC_2_4_6_TextString) bevt_40_tmpany_phold);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_23));
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_24));
bevt_42_tmpany_phold = bevp_params.bem_get_2(bevt_43_tmpany_phold, bevt_44_tmpany_phold);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_25));
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_26));
bevt_46_tmpany_phold = bevp_params.bem_get_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpany_phold);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_27));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_28));
bevt_50_tmpany_phold = bevp_params.bem_get_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_29));
bevp_loadSyns = bevp_params.bem_get_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_30));
bevp_initLibs = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_31));
bevt_55_tmpany_phold = bevp_params.bem_get_1(bevt_56_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_55_tmpany_phold.bem_firstGet_0();
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_32));
bevt_57_tmpany_phold = bevp_params.bem_get_1(bevt_58_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_57_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_59_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 185 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 186 */
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_61_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 190 */
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_63_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 193 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 194 */
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_65_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 198 */
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_67_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 201 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 202 */
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_69_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 206 */
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_71_tmpany_phold);
if (bevp_extLibs == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 209 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 210 */
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_73_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_74_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 214 */
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_75_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 218 */
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_77_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 222 */
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_79_tmpany_phold);
if (bevp_runArgs == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 226 */
 else  /* Line: 227 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 228 */
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_44));
bevt_82_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_45));
bevt_84_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_86_tmpany_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_87_tmpany_phold);
if (bevl_pacm == null) {
bevt_88_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpany_phold.bevi_bool) /* Line: 236 */ {
bevt_90_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_90_tmpany_phold.bevi_bool) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 236 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 236 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 236 */
 else  /* Line: 236 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 236 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 237 */ {
bevt_91_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_91_tmpany_phold != null && bevt_91_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_91_tmpany_phold).bevi_bool) /* Line: 237 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 238 */
 else  /* Line: 237 */ {
break;
} /* Line: 237 */
} /* Line: 237 */
} /* Line: 237 */
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bels_52));
bevt_96_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_95_tmpany_phold, bevt_96_tmpany_phold);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_53));
bevp_emitLangs = bevp_params.bem_get_1(bevt_97_tmpany_phold);
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_54));
bevp_emitFlags = bevp_params.bem_get_1(bevt_98_tmpany_phold);
bevt_100_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_55));
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_56));
bevt_99_tmpany_phold = bevp_params.bem_get_2(bevt_100_tmpany_phold, bevt_101_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_99_tmpany_phold.bem_firstGet_0();
bevt_103_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_57));
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_58));
bevt_102_tmpany_phold = bevp_params.bem_get_2(bevt_103_tmpany_phold, bevt_104_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_102_tmpany_phold.bem_firstGet_0();
bevt_107_tmpany_phold = bevo_4;
bevt_106_tmpany_phold = bevt_107_tmpany_phold.bem_add_1(bevp_makeName);
bevt_108_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_60));
bevt_105_tmpany_phold = bevp_params.bem_get_2(bevt_106_tmpany_phold, bevt_108_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_105_tmpany_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_109_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_109_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 257 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 258 */
 else  /* Line: 259 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_61));
} /* Line: 260 */
bevt_112_tmpany_phold = bevo_5;
bevt_111_tmpany_phold = bevl_outLang.bem_add_1(bevt_112_tmpany_phold);
bevt_113_tmpany_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_110_tmpany_phold = bevt_111_tmpany_phold.bem_add_1(bevt_113_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_110_tmpany_phold);
if (bevl_platformSources == null) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevt_115_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_115_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 269 */
bevt_117_tmpany_phold = bevo_6;
bevt_116_tmpany_phold = bevl_outLang.bem_add_1(bevt_117_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_116_tmpany_phold);
if (bevl_langSources == null) {
bevt_118_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_118_tmpany_phold.bevi_bool) /* Line: 273 */ {
bevt_119_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_119_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 274 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_120_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpany_loop = bevt_120_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 278 */ {
bevt_121_tmpany_phold = bevt_2_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_121_tmpany_phold != null && bevt_121_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_121_tmpany_phold).bevi_bool) /* Line: 278 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_122_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_122_tmpany_phold);
} /* Line: 279 */
 else  /* Line: 278 */ {
break;
} /* Line: 278 */
} /* Line: 278 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_125_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_124_tmpany_phold = bevt_125_tmpany_phold.bem_existsGet_0();
if (bevt_124_tmpany_phold.bevi_bool) {
bevt_123_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_123_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_126_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_126_tmpany_phold.bem_makeDirs_0();
} /* Line: 287 */
if (bevp_emitFileHeader == null) {
bevt_127_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_127_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_127_tmpany_phold.bevi_bool) /* Line: 289 */ {
bevt_128_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_128_tmpany_phold.bem_readerGet_0();
bevt_129_tmpany_phold = bevl_emr.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_129_tmpany_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 292 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_64));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_65));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 306 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 306 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 308 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 312 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 313 */
 else  /* Line: 312 */ {
break;
} /* Line: 312 */
} /* Line: 312 */
} /* Line: 312 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 317 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 318 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 319 */
 else  /* Line: 318 */ {
break;
} /* Line: 318 */
} /* Line: 318 */
} /* Line: 318 */
} /* Line: 317 */
} /* Line: 308 */
 else  /* Line: 306 */ {
break;
} /* Line: 306 */
} /* Line: 306 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 324 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpany_phold != null && bevt_24_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_24_tmpany_phold).bevi_bool) /* Line: 324 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpany_phold);
} /* Line: 326 */
 else  /* Line: 324 */ {
break;
} /* Line: 324 */
} /* Line: 324 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 337 */ {
return bevp_emitCommon;
} /* Line: 338 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 346 */
 else  /* Line: 345 */ {
bevt_5_tmpany_phold = bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 347 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 348 */
 else  /* Line: 345 */ {
bevt_7_tmpany_phold = bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 350 */
 else  /* Line: 351 */ {
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bels_69));
bevt_8_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpany_phold);
} /* Line: 352 */
} /* Line: 345 */
} /* Line: 345 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 355 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = (BEC_2_4_8_TimeInterval) bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_5_tmpany_phold = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bevo_11;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 378 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 379 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpany_phold).bevi_bool) /* Line: 379 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
this.bem_loadSyns_1(bevl_lsp);
} /* Line: 380 */
 else  /* Line: 379 */ {
break;
} /* Line: 379 */
} /* Line: 379 */
} /* Line: 379 */
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 387 */ {
bevt_10_tmpany_phold = bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 388 */
} /* Line: 387 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 393 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 393 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 397 */
} /* Line: 394 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 400 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 400 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 401 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(-1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 405 */
} /* Line: 401 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
if (bevp_parse.bevi_bool) /* Line: 408 */ {
bevl_built = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 411 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_18_tmpany_phold != null && bevt_18_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_20_tmpany_phold = bevl_tb.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 414 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
this.bem_doParse_1(bevl_tb);
} /* Line: 416 */
} /* Line: 414 */
 else  /* Line: 411 */ {
break;
} /* Line: 411 */
} /* Line: 411 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 419 */
bevt_23_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = this.bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 425 */ {
bevt_26_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = this.bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bevo_13;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bevo_14;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bevo_15;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 434 */
if (bevp_doEmit.bevi_bool) /* Line: 436 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 440 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpany_phold != null && bevt_40_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpany_phold).bevi_bool) /* Line: 440 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(-4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 442 */
 else  /* Line: 440 */ {
break;
} /* Line: 440 */
} /* Line: 440 */
bevl_em.bemd_0(-1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 446 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_42_tmpany_phold != null && bevt_42_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_42_tmpany_phold).bevi_bool) /* Line: 446 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 448 */
 else  /* Line: 446 */ {
break;
} /* Line: 446 */
} /* Line: 446 */
} /* Line: 446 */
bevt_44_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 453 */ {
bevt_47_tmpany_phold = bevo_16;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 454 */
bevt_49_tmpany_phold = bevo_17;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 457 */ {
bevl_em.bemd_1(-1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 459 */
if (bevp_make.bevi_bool) /* Line: 462 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 463 */ {
bevl_em.bemd_1(-1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 466 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 467 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (bevt_51_tmpany_phold != null && bevt_51_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_51_tmpany_phold).bevi_bool) /* Line: 467 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(-159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(-723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_56_tmpany_phold != null && bevt_56_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_56_tmpany_phold).bevi_bool) /* Line: 471 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_58_tmpany_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 472 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_59_tmpany_phold != null && bevt_59_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpany_phold).bevi_bool) /* Line: 474 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEL_4_Base.bevn_deployFile_2, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 475 */
} /* Line: 474 */
 else  /* Line: 467 */ {
break;
} /* Line: 467 */
} /* Line: 467 */
} /* Line: 467 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 482 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_64_tmpany_phold != null && bevt_64_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_64_tmpany_phold).bevi_bool) /* Line: 482 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_65_tmpany_phold != null && bevt_65_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_65_tmpany_phold).bevi_bool) /* Line: 482 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 482 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 482 */
 else  /* Line: 482 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 482 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold);
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bevo_18;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_74_tmpany_phold != null && bevt_74_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_76_tmpany_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 487 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_77_tmpany_phold != null && bevt_77_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_77_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEL_4_Base.bevn_deployFile_2, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 490 */
} /* Line: 489 */
 else  /* Line: 482 */ {
break;
} /* Line: 482 */
} /* Line: 482 */
} /* Line: 482 */
} /* Line: 463 */
bevt_83_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 497 */ {
bevt_86_tmpany_phold = bevo_19;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 498 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 500 */ {
bevt_89_tmpany_phold = bevo_20;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 501 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevt_92_tmpany_phold = bevo_21;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 504 */
if (bevp_run.bevi_bool) /* Line: 507 */ {
bevt_93_tmpany_phold = bevo_22;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bevo_23;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bevo_24;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 511 */
bevt_98_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 517 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 517 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpany_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpany_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 521 */
 else  /* Line: 517 */ {
break;
} /* Line: 517 */
} /* Line: 517 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 523 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpany_phold).bevi_bool) /* Line: 523 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpany_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 527 */
 else  /* Line: 523 */ {
break;
} /* Line: 523 */
} /* Line: 523 */
bevt_6_tmpany_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 533 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpany_phold;
} /* Line: 534 */
bevt_5_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpany_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 537 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 538 */
 else  /* Line: 539 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 542 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpany_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 544 */
 else  /* Line: 545 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = this.bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 548 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 550 */
bevt_17_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpany_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 560 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 561 */
bevt_2_tmpany_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 576 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 577 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 590 */ {
if (bevp_printSteps.bevi_bool) /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 591 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 591 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 591 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 591 */ {
bevt_4_tmpany_phold = bevo_25;
bevt_5_tmpany_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 592 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpany_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 601 */ {
bevt_11_tmpany_phold = bevo_26;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 602 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(-1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 605 */ {
bevt_13_tmpany_phold = bevo_27;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpany_phold);
} /* Line: 607 */
if (bevp_printSteps.bevi_bool) /* Line: 610 */ {
bevt_15_tmpany_phold = bevo_28;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 611 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 614 */ {
bevt_17_tmpany_phold = bevo_29;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpany_phold);
} /* Line: 616 */
if (bevp_printSteps.bevi_bool) /* Line: 618 */ {
bevt_19_tmpany_phold = bevo_30;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 619 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpany_phold);
bevl_trans.bemd_0(-410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 624 */ {
bevt_21_tmpany_phold = bevo_31;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpany_phold);
} /* Line: 626 */
if (bevp_printSteps.bevi_bool) /* Line: 629 */ {
bevt_23_tmpany_phold = bevo_32;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 630 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 633 */ {
bevt_25_tmpany_phold = bevo_33;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpany_phold);
} /* Line: 635 */
if (bevp_printSteps.bevi_bool) /* Line: 638 */ {
bevt_27_tmpany_phold = bevo_34;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 639 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 642 */ {
bevt_29_tmpany_phold = bevo_35;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpany_phold);
} /* Line: 644 */
if (bevp_printSteps.bevi_bool) /* Line: 647 */ {
bevt_31_tmpany_phold = bevo_36;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 648 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 651 */ {
bevt_33_tmpany_phold = bevo_37;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpany_phold);
} /* Line: 653 */
if (bevp_printSteps.bevi_bool) /* Line: 656 */ {
bevt_35_tmpany_phold = bevo_38;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 657 */
bevt_36_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 660 */ {
bevt_37_tmpany_phold = bevo_39;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpany_phold);
} /* Line: 662 */
if (bevp_printSteps.bevi_bool) /* Line: 665 */ {
bevt_39_tmpany_phold = bevo_40;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 666 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 669 */ {
bevt_41_tmpany_phold = bevo_41;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpany_phold);
} /* Line: 671 */
if (bevp_printSteps.bevi_bool) /* Line: 674 */ {
bevt_43_tmpany_phold = bevo_42;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 675 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 678 */ {
bevt_45_tmpany_phold = bevo_43;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpany_phold);
} /* Line: 680 */
if (bevp_printSteps.bevi_bool) /* Line: 683 */ {
bevt_47_tmpany_phold = bevo_44;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 684 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 687 */ {
bevt_49_tmpany_phold = bevo_45;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpany_phold);
} /* Line: 689 */
if (bevp_printSteps.bevi_bool) /* Line: 691 */ {
bevt_51_tmpany_phold = bevo_46;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 692 */
bevt_52_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 695 */ {
bevt_53_tmpany_phold = bevo_47;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpany_phold);
} /* Line: 697 */
if (bevp_printSteps.bevi_bool) /* Line: 700 */ {
bevt_55_tmpany_phold = bevo_48;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bevo_49;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 702 */
bevt_57_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 705 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 705 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 705 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 705 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 705 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 705 */ {
bevt_58_tmpany_phold = bevo_50;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpany_phold);
} /* Line: 707 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 709 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpany_phold != null && bevt_61_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpany_phold).bevi_bool) /* Line: 709 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(-1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(-557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 720 */
 else  /* Line: 709 */ {
break;
} /* Line: 709 */
} /* Line: 709 */
} /* Line: 709 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 730 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 730 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpany_phold);
bevl_node.bemd_1(-1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 734 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 735 */
bevt_6_tmpany_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 737 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 739 */
} /* Line: 737 */
 else  /* Line: 730 */ {
break;
} /* Line: 730 */
} /* Line: 730 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-630006451, BEL_4_Base.bevn_fromString_1, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlnp);
bevl_nlnpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_111));
bevl_nlc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1580478063, BEL_4_Base.bevn_isLiteralSet_1, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_11_tmpany_phold);
beva_node.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_12_tmpany_phold);
beva_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlc);
bevl_nlnpn.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_112));
bevt_13_tmpany_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpany_phold);
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpany_phold).bevi_bool) /* Line: 769 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 769 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_113));
bevt_15_tmpany_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 769 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 769 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 769 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 769 */ {
bevl_pn = beva_node.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 771 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_20_tmpany_phold);
if (bevt_18_tmpany_phold != null && bevt_18_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpany_phold).bevi_bool) /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 771 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_23_tmpany_phold);
if (bevt_21_tmpany_phold != null && bevt_21_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_21_tmpany_phold).bevi_bool) /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 771 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 771 */
 else  /* Line: 771 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 771 */ {
bevl_pn2 = bevl_pn.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_27_tmpany_phold);
if (bevt_25_tmpany_phold != null && bevt_25_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_25_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold != null && bevt_28_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
 else  /* Line: 773 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_33_tmpany_phold);
if (bevt_31_tmpany_phold != null && bevt_31_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
 else  /* Line: 773 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_36_tmpany_phold);
if (bevt_34_tmpany_phold != null && bevt_34_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpany_phold).bevi_bool) /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
 else  /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 773 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 773 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 773 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_37_tmpany_phold);
bevl_pn.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 780 */
} /* Line: 773 */
} /* Line: 771 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_dynConditionsAllGet_0() {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_dynConditionsAllSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {50, 52, 53, 54, 55, 57, 58, 59, 60, 61, 62, 63, 67, 69, 70, 71, 72, 72, 75, 78, 79, 85, 86, 87, 88, 89, 89, 96, 96, 96, 96, 0, 96, 96, 0, 0, 0, 0, 0, 97, 97, 99, 99, 103, 103, 103, 103, 107, 107, 108, 108, 108, 112, 113, 114, 114, 114, 114, 114, 115, 115, 115, 116, 115, 118, 122, 123, 124, 126, 127, 128, 130, 131, 132, 132, 133, 0, 0, 0, 136, 138, 142, 142, 142, 144, 149, 151, 152, 152, 152, 153, 153, 0, 153, 153, 154, 154, 154, 155, 156, 156, 161, 161, 161, 161, 162, 164, 164, 164, 165, 165, 166, 166, 166, 168, 170, 170, 170, 170, 170, 170, 171, 172, 172, 173, 173, 173, 173, 173, 173, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 180, 180, 182, 182, 182, 183, 183, 183, 184, 184, 185, 185, 186, 188, 188, 189, 189, 190, 192, 192, 193, 193, 194, 196, 196, 197, 197, 198, 200, 200, 201, 201, 202, 204, 204, 205, 205, 206, 208, 208, 209, 209, 210, 212, 212, 213, 213, 214, 216, 216, 217, 217, 218, 220, 220, 221, 221, 222, 224, 224, 225, 225, 226, 228, 230, 230, 230, 231, 231, 231, 232, 232, 233, 233, 234, 235, 235, 236, 236, 236, 236, 236, 0, 0, 0, 237, 0, 237, 237, 238, 241, 241, 242, 242, 243, 243, 244, 244, 244, 245, 245, 246, 246, 247, 247, 247, 247, 248, 248, 248, 248, 249, 249, 249, 249, 249, 250, 251, 252, 253, 254, 257, 257, 258, 260, 267, 267, 267, 267, 267, 268, 268, 269, 269, 272, 272, 272, 273, 273, 274, 274, 277, 278, 278, 0, 278, 278, 279, 279, 281, 282, 283, 285, 286, 286, 286, 286, 287, 287, 289, 289, 290, 290, 291, 291, 292, 298, 299, 299, 299, 299, 299, 300, 300, 300, 300, 300, 301, 305, 306, 306, 306, 307, 308, 308, 308, 308, 309, 309, 309, 309, 310, 310, 310, 310, 310, 311, 311, 312, 0, 312, 312, 313, 316, 316, 316, 316, 316, 317, 317, 318, 0, 318, 318, 319, 324, 324, 324, 325, 326, 326, 326, 326, 326, 326, 333, 333, 337, 337, 338, 343, 343, 344, 345, 345, 346, 347, 347, 348, 349, 349, 350, 352, 352, 352, 354, 355, 357, 361, 363, 363, 363, 364, 364, 365, 365, 365, 366, 366, 367, 368, 368, 369, 369, 369, 370, 370, 370, 376, 376, 377, 378, 378, 379, 0, 379, 379, 380, 383, 384, 384, 385, 386, 388, 388, 388, 391, 393, 0, 393, 393, 394, 394, 394, 395, 396, 397, 400, 0, 400, 400, 401, 401, 401, 402, 403, 404, 405, 405, 410, 411, 411, 412, 414, 414, 415, 415, 416, 419, 422, 422, 422, 425, 425, 425, 427, 427, 428, 428, 429, 429, 429, 430, 430, 430, 431, 431, 431, 432, 432, 432, 433, 433, 433, 434, 434, 437, 438, 440, 440, 440, 441, 442, 444, 445, 446, 446, 446, 447, 448, 452, 452, 452, 453, 453, 454, 454, 454, 456, 456, 456, 459, 463, 463, 464, 465, 467, 0, 467, 467, 468, 468, 469, 469, 470, 470, 470, 471, 471, 472, 472, 474, 474, 474, 475, 475, 475, 479, 480, 482, 482, 0, 0, 0, 483, 483, 484, 484, 484, 484, 484, 484, 484, 484, 486, 486, 487, 487, 489, 489, 489, 490, 490, 490, 495, 495, 495, 497, 497, 498, 498, 498, 500, 500, 501, 501, 501, 503, 503, 504, 504, 504, 508, 508, 509, 510, 510, 510, 510, 510, 511, 513, 513, 517, 517, 517, 518, 519, 519, 520, 521, 523, 523, 523, 524, 525, 525, 526, 527, 529, 529, 533, 533, 533, 533, 534, 534, 534, 536, 536, 537, 537, 537, 537, 538, 540, 540, 540, 540, 540, 542, 542, 543, 543, 544, 548, 548, 548, 550, 552, 552, 553, 553, 553, 553, 554, 558, 559, 559, 560, 560, 561, 567, 567, 568, 569, 576, 576, 577, 579, 584, 585, 586, 587, 588, 589, 589, 0, 0, 0, 592, 592, 592, 592, 594, 596, 596, 596, 596, 597, 597, 597, 598, 602, 602, 604, 604, 606, 606, 607, 607, 611, 611, 613, 613, 615, 615, 616, 616, 619, 619, 622, 622, 623, 625, 625, 626, 626, 630, 630, 632, 632, 634, 634, 635, 635, 639, 639, 641, 641, 643, 643, 644, 644, 648, 648, 650, 650, 652, 652, 653, 653, 657, 657, 659, 659, 661, 661, 662, 662, 666, 666, 668, 668, 670, 670, 671, 671, 675, 675, 677, 677, 679, 679, 680, 680, 684, 684, 686, 686, 688, 688, 689, 689, 692, 692, 694, 694, 696, 696, 697, 697, 701, 701, 702, 702, 704, 704, 0, 0, 0, 706, 706, 707, 707, 709, 709, 709, 710, 712, 713, 714, 714, 715, 716, 716, 716, 717, 718, 719, 720, 726, 727, 728, 729, 729, 730, 730, 731, 732, 732, 733, 734, 734, 735, 737, 737, 738, 739, 746, 747, 749, 750, 750, 751, 752, 754, 755, 755, 756, 756, 757, 757, 758, 758, 759, 759, 760, 760, 762, 764, 764, 765, 767, 769, 769, 0, 769, 769, 0, 0, 770, 771, 771, 771, 771, 771, 0, 771, 771, 771, 0, 0, 0, 0, 0, 772, 773, 773, 0, 773, 773, 773, 773, 773, 773, 0, 0, 0, 773, 773, 773, 0, 0, 0, 773, 773, 773, 0, 0, 0, 0, 0, 779, 779, 779, 779, 780, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 287, 292, 293, 294, 296, 299, 300, 302, 305, 309, 312, 316, 319, 320, 322, 323, 329, 330, 331, 332, 339, 340, 341, 342, 343, 355, 356, 357, 358, 359, 360, 361, 362, 365, 370, 371, 372, 378, 386, 387, 388, 390, 391, 392, 396, 397, 398, 399, 400, 403, 407, 410, 414, 416, 422, 423, 424, 427, 569, 570, 571, 572, 577, 578, 579, 579, 582, 584, 585, 586, 591, 592, 593, 594, 602, 603, 604, 605, 607, 609, 610, 611, 612, 613, 615, 616, 617, 620, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 680, 681, 683, 684, 685, 690, 691, 693, 694, 695, 700, 701, 703, 704, 705, 710, 711, 713, 714, 715, 720, 721, 723, 724, 725, 730, 731, 733, 734, 735, 740, 741, 743, 744, 745, 750, 751, 753, 754, 755, 760, 761, 763, 764, 765, 770, 771, 773, 774, 775, 780, 781, 784, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 804, 805, 806, 811, 812, 815, 819, 822, 822, 825, 827, 828, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 871, 872, 875, 877, 878, 879, 880, 881, 882, 887, 888, 889, 891, 892, 893, 894, 899, 900, 901, 903, 904, 905, 905, 908, 910, 911, 912, 918, 919, 920, 921, 922, 923, 924, 929, 930, 931, 933, 938, 939, 940, 941, 942, 943, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 1008, 1009, 1010, 1013, 1015, 1016, 1017, 1018, 1019, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1035, 1036, 1036, 1039, 1041, 1042, 1049, 1050, 1051, 1052, 1053, 1054, 1059, 1060, 1060, 1063, 1065, 1066, 1079, 1080, 1083, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1101, 1102, 1116, 1121, 1122, 1124, 1129, 1130, 1131, 1132, 1134, 1137, 1138, 1140, 1143, 1144, 1146, 1149, 1150, 1151, 1155, 1156, 1158, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1317, 1318, 1319, 1320, 1325, 1326, 1326, 1329, 1331, 1332, 1339, 1340, 1345, 1346, 1347, 1349, 1350, 1351, 1354, 1355, 1355, 1358, 1360, 1361, 1362, 1367, 1368, 1369, 1370, 1377, 1377, 1380, 1382, 1383, 1384, 1389, 1390, 1391, 1392, 1393, 1394, 1402, 1403, 1406, 1408, 1409, 1410, 1412, 1413, 1414, 1421, 1423, 1424, 1425, 1426, 1427, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1453, 1456, 1457, 1458, 1459, 1462, 1464, 1465, 1471, 1472, 1473, 1474, 1477, 1479, 1480, 1487, 1488, 1489, 1490, 1495, 1496, 1497, 1498, 1500, 1501, 1502, 1504, 1507, 1512, 1513, 1514, 1516, 1516, 1519, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1530, 1532, 1533, 1535, 1536, 1537, 1539, 1540, 1541, 1549, 1550, 1553, 1555, 1557, 1560, 1564, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1580, 1581, 1583, 1584, 1585, 1587, 1588, 1589, 1598, 1599, 1600, 1601, 1606, 1607, 1608, 1609, 1611, 1616, 1617, 1618, 1619, 1621, 1626, 1627, 1628, 1629, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1642, 1643, 1656, 1657, 1660, 1662, 1663, 1664, 1665, 1666, 1672, 1673, 1676, 1678, 1679, 1680, 1681, 1682, 1688, 1689, 1717, 1718, 1719, 1724, 1725, 1726, 1727, 1729, 1730, 1731, 1732, 1733, 1738, 1739, 1742, 1743, 1744, 1745, 1746, 1747, 1752, 1753, 1754, 1755, 1758, 1759, 1760, 1762, 1764, 1765, 1766, 1767, 1768, 1769, 1770, 1778, 1779, 1780, 1781, 1786, 1787, 1789, 1790, 1791, 1792, 1796, 1801, 1802, 1804, 1883, 1884, 1885, 1886, 1887, 1888, 1889, 1892, 1896, 1899, 1903, 1904, 1905, 1906, 1908, 1909, 1910, 1911, 1912, 1913, 1914, 1915, 1916, 1918, 1919, 1921, 1922, 1924, 1925, 1926, 1927, 1930, 1931, 1933, 1934, 1936, 1937, 1938, 1939, 1942, 1943, 1945, 1946, 1947, 1949, 1950, 1951, 1952, 1955, 1956, 1958, 1959, 1961, 1962, 1963, 1964, 1967, 1968, 1970, 1971, 1973, 1974, 1975, 1976, 1979, 1980, 1982, 1983, 1985, 1986, 1987, 1988, 1991, 1992, 1994, 1995, 1997, 1998, 1999, 2000, 2003, 2004, 2006, 2007, 2009, 2010, 2011, 2012, 2015, 2016, 2018, 2019, 2021, 2022, 2023, 2024, 2027, 2028, 2030, 2031, 2033, 2034, 2035, 2036, 2039, 2040, 2042, 2043, 2045, 2046, 2047, 2048, 2051, 2052, 2053, 2054, 2056, 2057, 2059, 2063, 2066, 2070, 2071, 2072, 2073, 2075, 2076, 2079, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2091, 2092, 2093, 2115, 2116, 2117, 2118, 2119, 2120, 2123, 2125, 2126, 2127, 2128, 2129, 2130, 2132, 2134, 2135, 2137, 2138, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2221, 2224, 2225, 2227, 2230, 2234, 2235, 2240, 2241, 2242, 2243, 2245, 2248, 2249, 2250, 2252, 2255, 2259, 2262, 2266, 2269, 2270, 2275, 2276, 2279, 2280, 2281, 2283, 2284, 2285, 2287, 2290, 2294, 2297, 2298, 2299, 2301, 2304, 2308, 2311, 2312, 2313, 2315, 2318, 2322, 2325, 2328, 2332, 2333, 2334, 2335, 2336, 2343, 2346, 2350, 2353, 2357, 2360, 2364, 2367, 2371, 2374, 2378, 2381, 2385, 2388, 2392, 2395, 2399, 2402, 2406, 2409, 2413, 2416, 2420, 2423, 2427, 2430, 2434, 2437, 2441, 2444, 2448, 2451, 2455, 2458, 2462, 2465, 2469, 2472, 2476, 2479, 2483, 2486, 2490, 2493, 2497, 2500, 2504, 2507, 2511, 2514, 2518, 2521, 2525, 2528, 2532, 2535, 2539, 2542, 2546, 2549, 2553, 2556, 2560, 2563, 2567, 2570, 2574, 2577, 2581, 2584, 2588, 2591, 2595, 2598, 2602, 2605, 2609, 2612, 2616, 2619, 2623, 2626, 2630, 2633, 2637, 2640, 2644, 2647, 2651, 2654, 2658, 2661, 2665, 2668, 2672, 2675, 2679, 2682, 2686, 2689, 2693, 2696, 2700, 2703, 2707, 2710, 2714, 2717, 2721, 2724, 2728, 2731, 2735, 2738, 2742, 2745, 2749, 2752, 2756, 2759, 2763, 2766, 2770, 2773, 2777, 2780, 2784, 2787, 2791, 2794, 2798, 2801, 2805, 2808, 2812, 2815, 2819, 2822, 2826, 2829, 2833, 2836, 2840};
/* BEGIN LINEINFO 
assign 1 50 249
new 0 50 249
assign 1 52 250
new 0 52 250
assign 1 53 251
new 0 53 251
assign 1 54 252
new 0 54 252
assign 1 55 253
new 0 55 253
assign 1 57 254
new 0 57 254
assign 1 58 255
new 0 58 255
assign 1 59 256
new 0 59 256
assign 1 60 257
new 0 60 257
assign 1 61 258
new 0 61 258
assign 1 62 259
new 0 62 259
assign 1 63 260
new 0 63 260
assign 1 67 261
new 0 67 261
assign 1 69 262
new 1 69 262
assign 1 70 263
ntypesGet 0 70 263
assign 1 71 264
twtokGet 0 71 264
assign 1 72 265
new 0 72 265
assign 1 72 266
new 1 72 266
assign 1 75 267
new 0 75 267
assign 1 78 268
new 0 78 268
assign 1 79 269
new 0 79 269
assign 1 85 270
new 0 85 270
assign 1 86 271
new 0 86 271
assign 1 87 272
new 0 87 272
assign 1 88 273
new 0 88 273
assign 1 89 274
new 0 89 274
assign 1 89 275
new 1 89 275
assign 1 96 287
def 1 96 292
assign 1 96 293
new 0 96 293
assign 1 96 294
equals 1 96 294
assign 1 0 296
assign 1 96 299
new 0 96 299
assign 1 96 300
ends 1 96 300
assign 1 0 302
assign 1 0 305
assign 1 0 309
assign 1 0 312
assign 1 0 316
assign 1 97 319
new 0 97 319
return 1 97 320
assign 1 99 322
new 0 99 322
return 1 99 323
assign 1 103 329
new 0 103 329
assign 1 103 330
new 0 103 330
assign 1 103 331
swap 2 103 331
return 1 103 332
assign 1 107 339
new 0 107 339
assign 1 107 340
argsGet 0 107 340
assign 1 108 341
new 0 108 341
assign 1 108 342
main 1 108 342
exit 1 108 343
assign 1 112 355
assign 1 113 356
new 1 113 356
assign 1 114 357
new 0 114 357
assign 1 114 358
new 0 114 358
assign 1 114 359
get 2 114 359
assign 1 114 360
firstGet 0 114 360
assign 1 114 361
new 1 114 361
assign 1 115 362
new 0 115 362
assign 1 115 365
lesser 1 115 370
assign 1 116 371
go 0 116 371
incrementValue 0 115 372
return 1 118 378
assign 1 122 386
new 0 122 386
config 0 123 387
assign 1 124 388
new 0 124 388
assign 1 126 390
new 0 126 390
assign 1 127 391
doWhat 0 127 391
assign 1 128 392
new 0 128 392
assign 1 130 396
toString 0 130 396
assign 1 131 397
new 0 131 397
assign 1 132 398
new 0 132 398
assign 1 132 399
add 1 132 399
assign 1 133 400
new 0 133 400
assign 1 0 403
assign 1 0 407
assign 1 0 410
print 0 136 414
return 1 138 416
assign 1 142 422
nameGet 0 142 422
assign 1 142 423
new 0 142 423
assign 1 142 424
equals 1 142 424
return 1 144 427
assign 1 149 569
new 0 149 569
assign 1 151 570
new 0 151 570
assign 1 152 571
get 1 152 571
assign 1 152 572
def 1 152 577
assign 1 153 578
get 1 153 578
assign 1 153 579
iteratorGet 0 0 579
assign 1 153 582
hasNextGet 0 153 582
assign 1 153 584
nextGet 0 153 584
assign 1 154 585
has 1 154 585
assign 1 154 586
not 0 154 591
put 1 155 592
assign 1 156 593
new 1 156 593
addFile 1 156 594
assign 1 161 602
new 0 161 602
assign 1 161 603
nameGet 0 161 603
assign 1 161 604
new 0 161 604
assign 1 161 605
equals 1 161 605
preProcessorSet 1 162 607
assign 1 164 609
new 0 164 609
assign 1 164 610
get 1 164 610
assign 1 164 611
firstGet 0 164 611
assign 1 165 612
new 0 165 612
assign 1 165 613
has 1 165 613
assign 1 166 615
new 0 166 615
assign 1 166 616
get 1 166 616
assign 1 166 617
firstGet 0 166 617
assign 1 168 620
assign 1 170 622
new 0 170 622
assign 1 170 623
new 0 170 623
assign 1 170 624
get 2 170 624
assign 1 170 625
firstGet 0 170 625
assign 1 170 626
new 1 170 626
assign 1 170 627
pathGet 0 170 627
addStep 1 171 628
assign 1 172 629
new 0 172 629
addStep 1 172 630
assign 1 173 631
new 0 173 631
assign 1 173 632
new 0 173 632
assign 1 173 633
get 2 173 633
assign 1 173 634
firstGet 0 173 634
assign 1 173 635
new 1 173 635
assign 1 173 636
pathGet 0 173 636
assign 1 174 637
new 0 174 637
assign 1 174 638
new 0 174 638
assign 1 174 639
nameGet 0 174 639
assign 1 174 640
get 2 174 640
assign 1 174 641
firstGet 0 174 641
assign 1 174 642
new 1 174 642
assign 1 175 643
new 0 175 643
assign 1 175 644
nameGet 0 175 644
assign 1 175 645
get 2 175 645
assign 1 175 646
firstGet 0 175 646
assign 1 175 647
new 1 175 647
assign 1 176 648
new 0 176 648
assign 1 176 649
new 0 176 649
assign 1 176 650
get 2 176 650
assign 1 176 651
firstGet 0 176 651
assign 1 176 652
new 1 176 652
assign 1 177 653
new 0 177 653
assign 1 177 654
new 0 177 654
assign 1 177 655
get 2 177 655
assign 1 177 656
firstGet 0 177 656
assign 1 177 657
new 1 177 657
assign 1 178 658
new 0 178 658
assign 1 178 659
new 0 178 659
assign 1 178 660
get 2 178 660
assign 1 178 661
firstGet 0 178 661
assign 1 178 662
new 1 178 662
assign 1 179 663
new 0 179 663
assign 1 179 664
get 1 179 664
assign 1 180 665
new 0 180 665
assign 1 180 666
get 1 180 666
assign 1 182 667
new 0 182 667
assign 1 182 668
get 1 182 668
assign 1 182 669
firstGet 0 182 669
assign 1 183 670
new 0 183 670
assign 1 183 671
get 1 183 671
assign 1 183 672
firstGet 0 183 672
assign 1 184 673
new 0 184 673
assign 1 184 674
get 1 184 674
assign 1 185 675
undef 1 185 680
assign 1 186 681
new 0 186 681
assign 1 188 683
new 0 188 683
assign 1 188 684
get 1 188 684
assign 1 189 685
undef 1 189 690
assign 1 190 691
new 0 190 691
assign 1 192 693
new 0 192 693
assign 1 192 694
get 1 192 694
assign 1 193 695
undef 1 193 700
assign 1 194 701
new 0 194 701
assign 1 196 703
new 0 196 703
assign 1 196 704
get 1 196 704
assign 1 197 705
undef 1 197 710
assign 1 198 711
new 0 198 711
assign 1 200 713
new 0 200 713
assign 1 200 714
get 1 200 714
assign 1 201 715
undef 1 201 720
assign 1 202 721
new 0 202 721
assign 1 204 723
new 0 204 723
assign 1 204 724
get 1 204 724
assign 1 205 725
undef 1 205 730
assign 1 206 731
new 0 206 731
assign 1 208 733
new 0 208 733
assign 1 208 734
get 1 208 734
assign 1 209 735
undef 1 209 740
assign 1 210 741
new 0 210 741
assign 1 212 743
new 0 212 743
assign 1 212 744
get 1 212 744
assign 1 213 745
undef 1 213 750
assign 1 214 751
new 0 214 751
assign 1 216 753
new 0 216 753
assign 1 216 754
get 1 216 754
assign 1 217 755
undef 1 217 760
assign 1 218 761
new 0 218 761
assign 1 220 763
new 0 220 763
assign 1 220 764
get 1 220 764
assign 1 221 765
def 1 221 770
assign 1 222 771
firstGet 0 222 771
assign 1 224 773
new 0 224 773
assign 1 224 774
get 1 224 774
assign 1 225 775
def 1 225 780
assign 1 226 781
firstGet 0 226 781
assign 1 228 784
new 0 228 784
assign 1 230 786
new 0 230 786
assign 1 230 787
new 0 230 787
assign 1 230 788
isTrue 2 230 788
assign 1 231 789
new 0 231 789
assign 1 231 790
new 0 231 790
assign 1 231 791
isTrue 2 231 791
assign 1 232 792
new 0 232 792
assign 1 232 793
isTrue 1 232 793
assign 1 233 794
new 0 233 794
assign 1 233 795
isTrue 1 233 795
assign 1 234 796
new 0 234 796
assign 1 235 797
new 0 235 797
assign 1 235 798
get 1 235 798
assign 1 236 799
def 1 236 804
assign 1 236 805
isEmptyGet 0 236 805
assign 1 236 806
not 0 236 811
assign 1 0 812
assign 1 0 815
assign 1 0 819
assign 1 237 822
linkedListIteratorGet 0 0 822
assign 1 237 825
hasNextGet 0 237 825
assign 1 237 827
nextGet 0 237 827
put 1 238 828
assign 1 241 835
new 0 241 835
assign 1 241 836
isTrue 1 241 836
assign 1 242 837
new 0 242 837
assign 1 242 838
isTrue 1 242 838
assign 1 243 839
new 0 243 839
assign 1 243 840
isTrue 1 243 840
assign 1 244 841
new 0 244 841
assign 1 244 842
new 0 244 842
assign 1 244 843
isTrue 2 244 843
assign 1 245 844
new 0 245 844
assign 1 245 845
get 1 245 845
assign 1 246 846
new 0 246 846
assign 1 246 847
get 1 246 847
assign 1 247 848
new 0 247 848
assign 1 247 849
new 0 247 849
assign 1 247 850
get 2 247 850
assign 1 247 851
firstGet 0 247 851
assign 1 248 852
new 0 248 852
assign 1 248 853
new 0 248 853
assign 1 248 854
get 2 248 854
assign 1 248 855
firstGet 0 248 855
assign 1 249 856
new 0 249 856
assign 1 249 857
add 1 249 857
assign 1 249 858
new 0 249 858
assign 1 249 859
get 2 249 859
assign 1 249 860
firstGet 0 249 860
assign 1 250 861
new 0 250 861
assign 1 251 862
new 0 251 862
assign 1 252 863
new 0 252 863
assign 1 253 864
new 0 253 864
assign 1 254 865
new 0 254 865
assign 1 257 866
def 1 257 871
assign 1 258 872
firstGet 0 258 872
assign 1 260 875
new 0 260 875
assign 1 267 877
new 0 267 877
assign 1 267 878
add 1 267 878
assign 1 267 879
nameGet 0 267 879
assign 1 267 880
add 1 267 880
assign 1 267 881
get 1 267 881
assign 1 268 882
def 1 268 887
assign 1 269 888
orderedGet 0 269 888
addAll 1 269 889
assign 1 272 891
new 0 272 891
assign 1 272 892
add 1 272 892
assign 1 272 893
get 1 272 893
assign 1 273 894
def 1 273 899
assign 1 274 900
orderedGet 0 274 900
addAll 1 274 901
assign 1 277 903
new 0 277 903
assign 1 278 904
orderedGet 0 278 904
assign 1 278 905
iteratorGet 0 0 905
assign 1 278 908
hasNextGet 0 278 908
assign 1 278 910
nextGet 0 278 910
assign 1 279 911
new 1 279 911
addValue 1 279 912
assign 1 281 918
newlineGet 0 281 918
assign 1 282 919
assign 1 283 920
new 1 283 920
assign 1 285 921
copy 0 285 921
assign 1 286 922
fileGet 0 286 922
assign 1 286 923
existsGet 0 286 923
assign 1 286 924
not 0 286 929
assign 1 287 930
fileGet 0 287 930
makeDirs 0 287 931
assign 1 289 933
def 1 289 938
assign 1 290 939
new 1 290 939
assign 1 290 940
readerGet 0 290 940
assign 1 291 941
open 0 291 941
assign 1 291 942
readString 0 291 942
close 0 292 943
assign 1 298 957
classNameGet 0 298 957
assign 1 299 958
add 1 299 958
assign 1 299 959
new 0 299 959
assign 1 299 960
add 1 299 960
assign 1 299 961
toString 0 299 961
assign 1 299 962
add 1 299 962
assign 1 300 963
add 1 300 963
assign 1 300 964
new 0 300 964
assign 1 300 965
add 1 300 965
assign 1 300 966
toString 0 300 966
assign 1 300 967
add 1 300 967
return 1 301 968
assign 1 305 1008
new 0 305 1008
assign 1 306 1009
classesGet 0 306 1009
assign 1 306 1010
valueIteratorGet 0 306 1010
assign 1 306 1013
hasNextGet 0 306 1013
assign 1 307 1015
nextGet 0 307 1015
assign 1 308 1016
shouldEmitGet 0 308 1016
assign 1 308 1017
heldGet 0 308 1017
assign 1 308 1018
fromFileGet 0 308 1018
assign 1 308 1019
has 1 308 1019
assign 1 309 1021
heldGet 0 309 1021
assign 1 309 1022
namepathGet 0 309 1022
assign 1 309 1023
toString 0 309 1023
put 1 309 1024
assign 1 310 1025
usedByGet 0 310 1025
assign 1 310 1026
heldGet 0 310 1026
assign 1 310 1027
namepathGet 0 310 1027
assign 1 310 1028
toString 0 310 1028
assign 1 310 1029
get 1 310 1029
assign 1 311 1030
def 1 311 1035
assign 1 312 1036
setIteratorGet 0 0 1036
assign 1 312 1039
hasNextGet 0 312 1039
assign 1 312 1041
nextGet 0 312 1041
put 1 313 1042
assign 1 316 1049
subClassesGet 0 316 1049
assign 1 316 1050
heldGet 0 316 1050
assign 1 316 1051
namepathGet 0 316 1051
assign 1 316 1052
toString 0 316 1052
assign 1 316 1053
get 1 316 1053
assign 1 317 1054
def 1 317 1059
assign 1 318 1060
setIteratorGet 0 0 1060
assign 1 318 1063
hasNextGet 0 318 1063
assign 1 318 1065
nextGet 0 318 1065
put 1 319 1066
assign 1 324 1079
classesGet 0 324 1079
assign 1 324 1080
valueIteratorGet 0 324 1080
assign 1 324 1083
hasNextGet 0 324 1083
assign 1 325 1085
nextGet 0 325 1085
assign 1 326 1086
heldGet 0 326 1086
assign 1 326 1087
heldGet 0 326 1087
assign 1 326 1088
namepathGet 0 326 1088
assign 1 326 1089
toString 0 326 1089
assign 1 326 1090
has 1 326 1090
shouldWriteSet 1 326 1091
assign 1 333 1101
new 0 333 1101
return 1 333 1102
assign 1 337 1116
def 1 337 1121
return 1 338 1122
assign 1 343 1124
def 1 343 1129
assign 1 344 1130
firstGet 0 344 1130
assign 1 345 1131
new 0 345 1131
assign 1 345 1132
equals 1 345 1132
assign 1 346 1134
new 1 346 1134
assign 1 347 1137
new 0 347 1137
assign 1 347 1138
equals 1 347 1138
assign 1 348 1140
new 1 348 1140
assign 1 349 1143
new 0 349 1143
assign 1 349 1144
equals 1 349 1144
assign 1 350 1146
new 1 350 1146
assign 1 352 1149
new 0 352 1149
assign 1 352 1150
new 1 352 1150
throw 1 352 1151
dynConditionsAllSet 1 354 1155
return 1 355 1156
return 1 357 1158
assign 1 361 1177
apNew 1 361 1177
assign 1 363 1178
new 0 363 1178
assign 1 363 1179
add 1 363 1179
print 0 363 1180
assign 1 364 1181
new 0 364 1181
assign 1 364 1182
now 0 364 1182
assign 1 365 1183
fileGet 0 365 1183
assign 1 365 1184
readerGet 0 365 1184
assign 1 365 1185
open 0 365 1185
assign 1 366 1186
new 0 366 1186
assign 1 366 1187
deserialize 1 366 1187
close 0 367 1188
assign 1 368 1189
synClassesGet 0 368 1189
addValue 1 368 1190
assign 1 369 1191
new 0 369 1191
assign 1 369 1192
now 0 369 1192
assign 1 369 1193
subtract 1 369 1193
assign 1 370 1194
new 0 370 1194
assign 1 370 1195
add 1 370 1195
print 0 370 1196
assign 1 376 1317
new 0 376 1317
assign 1 376 1318
now 0 376 1318
assign 1 377 1319
new 0 377 1319
assign 1 378 1320
def 1 378 1325
assign 1 379 1326
linkedListIteratorGet 0 0 1326
assign 1 379 1329
hasNextGet 0 379 1329
assign 1 379 1331
nextGet 0 379 1331
loadSyns 1 380 1332
assign 1 383 1339
emitterGet 0 383 1339
assign 1 384 1340
def 1 384 1345
assign 1 385 1346
new 4 385 1346
put 1 386 1347
assign 1 388 1349
new 0 388 1349
assign 1 388 1350
add 1 388 1350
print 0 388 1351
assign 1 391 1354
new 0 391 1354
assign 1 393 1355
iteratorGet 0 0 1355
assign 1 393 1358
hasNextGet 0 393 1358
assign 1 393 1360
nextGet 0 393 1360
assign 1 394 1361
has 1 394 1361
assign 1 394 1362
not 0 394 1367
put 1 395 1368
assign 1 396 1369
new 2 396 1369
addValue 1 397 1370
assign 1 400 1377
iteratorGet 0 0 1377
assign 1 400 1380
hasNextGet 0 400 1380
assign 1 400 1382
nextGet 0 400 1382
assign 1 401 1383
has 1 401 1383
assign 1 401 1384
not 0 401 1389
put 1 402 1390
assign 1 403 1391
new 2 403 1391
addValue 1 404 1392
assign 1 405 1393
libNameGet 0 405 1393
put 1 405 1394
assign 1 410 1402
new 0 410 1402
assign 1 411 1403
iteratorGet 0 411 1403
assign 1 411 1406
hasNextGet 0 411 1406
assign 1 412 1408
nextGet 0 412 1408
assign 1 414 1409
toString 0 414 1409
assign 1 414 1410
has 1 414 1410
assign 1 415 1412
toString 0 415 1412
put 1 415 1413
doParse 1 416 1414
buildSyns 1 419 1421
assign 1 422 1423
new 0 422 1423
assign 1 422 1424
now 0 422 1424
assign 1 422 1425
subtract 1 422 1425
assign 1 425 1426
emitCommonGet 0 425 1426
assign 1 425 1427
def 1 425 1432
assign 1 427 1433
new 0 427 1433
assign 1 427 1434
now 0 427 1434
assign 1 428 1435
emitCommonGet 0 428 1435
doEmit 0 428 1436
assign 1 429 1437
new 0 429 1437
assign 1 429 1438
now 0 429 1438
assign 1 429 1439
subtract 1 429 1439
assign 1 430 1440
new 0 430 1440
assign 1 430 1441
now 0 430 1441
assign 1 430 1442
subtract 1 430 1442
assign 1 431 1443
new 0 431 1443
assign 1 431 1444
add 1 431 1444
print 0 431 1445
assign 1 432 1446
new 0 432 1446
assign 1 432 1447
add 1 432 1447
print 0 432 1448
assign 1 433 1449
new 0 433 1449
assign 1 433 1450
add 1 433 1450
print 0 433 1451
assign 1 434 1452
new 0 434 1452
return 1 434 1453
setClassesToWrite 0 437 1456
libnameInfoGet 0 438 1457
assign 1 440 1458
classesGet 0 440 1458
assign 1 440 1459
valueIteratorGet 0 440 1459
assign 1 440 1462
hasNextGet 0 440 1462
assign 1 441 1464
nextGet 0 441 1464
doEmit 1 442 1465
emitMain 0 444 1471
emitCUInit 0 445 1472
assign 1 446 1473
classesGet 0 446 1473
assign 1 446 1474
valueIteratorGet 0 446 1474
assign 1 446 1477
hasNextGet 0 446 1477
assign 1 447 1479
nextGet 0 447 1479
emitSyn 1 448 1480
assign 1 452 1487
new 0 452 1487
assign 1 452 1488
now 0 452 1488
assign 1 452 1489
subtract 1 452 1489
assign 1 453 1490
def 1 453 1495
assign 1 454 1496
new 0 454 1496
assign 1 454 1497
add 1 454 1497
print 0 454 1498
assign 1 456 1500
new 0 456 1500
assign 1 456 1501
add 1 456 1501
print 0 456 1502
prepMake 1 459 1504
assign 1 463 1507
not 0 463 1512
make 1 464 1513
deployLibrary 1 465 1514
assign 1 467 1516
linkedListIteratorGet 0 0 1516
assign 1 467 1519
hasNextGet 0 467 1519
assign 1 467 1521
nextGet 0 467 1521
assign 1 468 1522
libnameInfoGet 0 468 1522
assign 1 468 1523
unitShlibGet 0 468 1523
assign 1 469 1524
emitPathGet 0 469 1524
assign 1 469 1525
copy 0 469 1525
assign 1 470 1526
stepsGet 0 470 1526
assign 1 470 1527
lastGet 0 470 1527
addStep 1 470 1528
assign 1 471 1529
fileGet 0 471 1529
assign 1 471 1530
existsGet 0 471 1530
assign 1 472 1532
fileGet 0 472 1532
delete 0 472 1533
assign 1 474 1535
fileGet 0 474 1535
assign 1 474 1536
existsGet 0 474 1536
assign 1 474 1537
not 0 474 1537
assign 1 475 1539
fileGet 0 475 1539
assign 1 475 1540
fileGet 0 475 1540
deployFile 2 475 1541
assign 1 479 1549
iteratorGet 0 479 1549
assign 1 480 1550
iteratorGet 0 480 1550
assign 1 482 1553
hasNextGet 0 482 1553
assign 1 482 1555
hasNextGet 0 482 1555
assign 1 0 1557
assign 1 0 1560
assign 1 0 1564
assign 1 483 1567
nextGet 0 483 1567
assign 1 483 1568
apNew 1 483 1568
assign 1 484 1569
emitPathGet 0 484 1569
assign 1 484 1570
copy 0 484 1570
assign 1 484 1571
toString 0 484 1571
assign 1 484 1572
new 0 484 1572
assign 1 484 1573
add 1 484 1573
assign 1 484 1574
nextGet 0 484 1574
assign 1 484 1575
add 1 484 1575
assign 1 484 1576
apNew 1 484 1576
assign 1 486 1577
fileGet 0 486 1577
assign 1 486 1578
existsGet 0 486 1578
assign 1 487 1580
fileGet 0 487 1580
delete 0 487 1581
assign 1 489 1583
fileGet 0 489 1583
assign 1 489 1584
existsGet 0 489 1584
assign 1 489 1585
not 0 489 1585
assign 1 490 1587
fileGet 0 490 1587
assign 1 490 1588
fileGet 0 490 1588
deployFile 2 490 1589
assign 1 495 1598
new 0 495 1598
assign 1 495 1599
now 0 495 1599
assign 1 495 1600
subtract 1 495 1600
assign 1 497 1601
def 1 497 1606
assign 1 498 1607
new 0 498 1607
assign 1 498 1608
add 1 498 1608
print 0 498 1609
assign 1 500 1611
def 1 500 1616
assign 1 501 1617
new 0 501 1617
assign 1 501 1618
add 1 501 1618
print 0 501 1619
assign 1 503 1621
def 1 503 1626
assign 1 504 1627
new 0 504 1627
assign 1 504 1628
add 1 504 1628
print 0 504 1629
assign 1 508 1632
new 0 508 1632
print 0 508 1633
assign 1 509 1634
run 2 509 1634
assign 1 510 1635
new 0 510 1635
assign 1 510 1636
add 1 510 1636
assign 1 510 1637
new 0 510 1637
assign 1 510 1638
add 1 510 1638
print 0 510 1639
return 1 511 1640
assign 1 513 1642
new 0 513 1642
return 1 513 1643
assign 1 517 1656
justParsedGet 0 517 1656
assign 1 517 1657
valueIteratorGet 0 517 1657
assign 1 517 1660
hasNextGet 0 517 1660
assign 1 518 1662
nextGet 0 518 1662
assign 1 519 1663
heldGet 0 519 1663
libNameSet 1 519 1664
assign 1 520 1665
getSyn 2 520 1665
libNameSet 1 521 1666
assign 1 523 1672
justParsedGet 0 523 1672
assign 1 523 1673
valueIteratorGet 0 523 1673
assign 1 523 1676
hasNextGet 0 523 1676
assign 1 524 1678
nextGet 0 524 1678
assign 1 525 1679
heldGet 0 525 1679
assign 1 525 1680
synGet 0 525 1680
checkInheritance 2 526 1681
integrate 1 527 1682
assign 1 529 1688
new 0 529 1688
justParsedSet 1 529 1689
assign 1 533 1717
heldGet 0 533 1717
assign 1 533 1718
synGet 0 533 1718
assign 1 533 1719
def 1 533 1724
assign 1 534 1725
heldGet 0 534 1725
assign 1 534 1726
synGet 0 534 1726
return 1 534 1727
assign 1 536 1729
heldGet 0 536 1729
libNameSet 1 536 1730
assign 1 537 1731
heldGet 0 537 1731
assign 1 537 1732
extendsGet 0 537 1732
assign 1 537 1733
undef 1 537 1738
assign 1 538 1739
new 1 538 1739
assign 1 540 1742
classesGet 0 540 1742
assign 1 540 1743
heldGet 0 540 1743
assign 1 540 1744
extendsGet 0 540 1744
assign 1 540 1745
toString 0 540 1745
assign 1 540 1746
get 1 540 1746
assign 1 542 1747
def 1 542 1752
assign 1 543 1753
heldGet 0 543 1753
libNameSet 1 543 1754
assign 1 544 1755
getSyn 2 544 1755
assign 1 548 1758
heldGet 0 548 1758
assign 1 548 1759
extendsGet 0 548 1759
assign 1 548 1760
getSynNp 1 548 1760
assign 1 550 1762
new 2 550 1762
assign 1 552 1764
heldGet 0 552 1764
synSet 1 552 1765
assign 1 553 1766
heldGet 0 553 1766
assign 1 553 1767
namepathGet 0 553 1767
assign 1 553 1768
toString 0 553 1768
addSynClass 2 553 1769
return 1 554 1770
assign 1 558 1778
toString 0 558 1778
assign 1 559 1779
synClassesGet 0 559 1779
assign 1 559 1780
get 1 559 1780
assign 1 560 1781
def 1 560 1786
return 1 561 1787
assign 1 567 1789
emitterGet 0 567 1789
assign 1 567 1790
loadSyn 1 567 1790
addSynClass 2 568 1791
return 1 569 1792
assign 1 576 1796
undef 1 576 1801
assign 1 577 1802
new 1 577 1802
return 1 579 1804
assign 1 584 1883
new 1 584 1883
assign 1 585 1884
new 0 585 1884
assign 1 586 1885
emitterGet 0 586 1885
assign 1 587 1886
assign 1 588 1887
new 0 588 1887
assign 1 589 1888
shouldEmitGet 0 589 1888
put 1 589 1889
assign 1 0 1892
assign 1 0 1896
assign 1 0 1899
assign 1 592 1903
new 0 592 1903
assign 1 592 1904
toString 0 592 1904
assign 1 592 1905
add 1 592 1905
print 0 592 1906
assign 1 594 1908
assign 1 596 1909
fileGet 0 596 1909
assign 1 596 1910
readerGet 0 596 1910
assign 1 596 1911
open 0 596 1911
assign 1 596 1912
readBuffer 1 596 1912
assign 1 597 1913
fileGet 0 597 1913
assign 1 597 1914
readerGet 0 597 1914
close 0 597 1915
assign 1 598 1916
tokenize 1 598 1916
assign 1 602 1918
new 0 602 1918
echo 0 602 1919
assign 1 604 1921
outermostGet 0 604 1921
nodify 2 604 1922
assign 1 606 1924
new 0 606 1924
print 0 606 1925
assign 1 607 1926
new 2 607 1926
traverse 1 607 1927
assign 1 611 1930
new 0 611 1930
echo 0 611 1931
assign 1 613 1933
new 0 613 1933
traverse 1 613 1934
assign 1 615 1936
new 0 615 1936
print 0 615 1937
assign 1 616 1938
new 2 616 1938
traverse 1 616 1939
assign 1 619 1942
new 0 619 1942
echo 0 619 1943
assign 1 622 1945
new 0 622 1945
traverse 1 622 1946
contain 0 623 1947
assign 1 625 1949
new 0 625 1949
print 0 625 1950
assign 1 626 1951
new 2 626 1951
traverse 1 626 1952
assign 1 630 1955
new 0 630 1955
echo 0 630 1956
assign 1 632 1958
new 0 632 1958
traverse 1 632 1959
assign 1 634 1961
new 0 634 1961
print 0 634 1962
assign 1 635 1963
new 2 635 1963
traverse 1 635 1964
assign 1 639 1967
new 0 639 1967
echo 0 639 1968
assign 1 641 1970
new 0 641 1970
traverse 1 641 1971
assign 1 643 1973
new 0 643 1973
print 0 643 1974
assign 1 644 1975
new 2 644 1975
traverse 1 644 1976
assign 1 648 1979
new 0 648 1979
echo 0 648 1980
assign 1 650 1982
new 0 650 1982
traverse 1 650 1983
assign 1 652 1985
new 0 652 1985
print 0 652 1986
assign 1 653 1987
new 2 653 1987
traverse 1 653 1988
assign 1 657 1991
new 0 657 1991
echo 0 657 1992
assign 1 659 1994
new 0 659 1994
traverse 1 659 1995
assign 1 661 1997
new 0 661 1997
print 0 661 1998
assign 1 662 1999
new 2 662 1999
traverse 1 662 2000
assign 1 666 2003
new 0 666 2003
echo 0 666 2004
assign 1 668 2006
new 0 668 2006
traverse 1 668 2007
assign 1 670 2009
new 0 670 2009
print 0 670 2010
assign 1 671 2011
new 2 671 2011
traverse 1 671 2012
assign 1 675 2015
new 0 675 2015
echo 0 675 2016
assign 1 677 2018
new 0 677 2018
traverse 1 677 2019
assign 1 679 2021
new 0 679 2021
print 0 679 2022
assign 1 680 2023
new 2 680 2023
traverse 1 680 2024
assign 1 684 2027
new 0 684 2027
echo 0 684 2028
assign 1 686 2030
new 0 686 2030
traverse 1 686 2031
assign 1 688 2033
new 0 688 2033
print 0 688 2034
assign 1 689 2035
new 2 689 2035
traverse 1 689 2036
assign 1 692 2039
new 0 692 2039
echo 0 692 2040
assign 1 694 2042
new 0 694 2042
traverse 1 694 2043
assign 1 696 2045
new 0 696 2045
print 0 696 2046
assign 1 697 2047
new 2 697 2047
traverse 1 697 2048
assign 1 701 2051
new 0 701 2051
echo 0 701 2052
assign 1 702 2053
new 0 702 2053
print 0 702 2054
assign 1 704 2056
new 0 704 2056
traverse 1 704 2057
assign 1 0 2059
assign 1 0 2063
assign 1 0 2066
assign 1 706 2070
new 0 706 2070
print 0 706 2071
assign 1 707 2072
new 2 707 2072
traverse 1 707 2073
assign 1 709 2075
classesGet 0 709 2075
assign 1 709 2076
valueIteratorGet 0 709 2076
assign 1 709 2079
hasNextGet 0 709 2079
assign 1 710 2081
nextGet 0 710 2081
assign 1 712 2082
transUnitGet 0 712 2082
assign 1 713 2083
new 1 713 2083
assign 1 714 2084
TRANSUNITGet 0 714 2084
typenameSet 1 714 2085
assign 1 715 2086
new 0 715 2086
assign 1 716 2087
heldGet 0 716 2087
assign 1 716 2088
emitsGet 0 716 2088
emitsSet 1 716 2089
heldSet 1 717 2090
delete 0 718 2091
addValue 1 719 2092
copyLoc 1 720 2093
reInitContained 0 726 2115
assign 1 727 2116
containedGet 0 727 2116
assign 1 728 2117
new 0 728 2117
assign 1 729 2118
new 0 729 2118
assign 1 729 2119
crGet 0 729 2119
assign 1 730 2120
linkedListIteratorGet 0 730 2120
assign 1 730 2123
hasNextGet 0 730 2123
assign 1 731 2125
new 1 731 2125
assign 1 732 2126
nextGet 0 732 2126
heldSet 1 732 2127
nlcSet 1 733 2128
assign 1 734 2129
heldGet 0 734 2129
assign 1 734 2130
equals 1 734 2130
assign 1 735 2132
increment 0 735 2132
assign 1 737 2134
heldGet 0 737 2134
assign 1 737 2135
notEquals 1 737 2135
addValue 1 738 2137
containerSet 1 739 2138
assign 1 746 2193
new 0 746 2193
fromString 1 747 2194
assign 1 749 2195
new 1 749 2195
assign 1 750 2196
NAMEPATHGet 0 750 2196
typenameSet 1 750 2197
heldSet 1 751 2198
copyLoc 1 752 2199
assign 1 754 2200
new 0 754 2200
assign 1 755 2201
new 0 755 2201
nameSet 1 755 2202
assign 1 756 2203
new 0 756 2203
wasBoundSet 1 756 2204
assign 1 757 2205
new 0 757 2205
boundSet 1 757 2206
assign 1 758 2207
new 0 758 2207
isConstructSet 1 758 2208
assign 1 759 2209
new 0 759 2209
isLiteralSet 1 759 2210
assign 1 760 2211
heldGet 0 760 2211
literalValueSet 1 760 2212
addValue 1 762 2213
assign 1 764 2214
CALLGet 0 764 2214
typenameSet 1 764 2215
heldSet 1 765 2216
resolveNp 0 767 2217
assign 1 769 2218
new 0 769 2218
assign 1 769 2219
equals 1 769 2219
assign 1 0 2221
assign 1 769 2224
new 0 769 2224
assign 1 769 2225
equals 1 769 2225
assign 1 0 2227
assign 1 0 2230
assign 1 770 2234
priorPeerGet 0 770 2234
assign 1 771 2235
def 1 771 2240
assign 1 771 2241
typenameGet 0 771 2241
assign 1 771 2242
SUBTRACTGet 0 771 2242
assign 1 771 2243
equals 1 771 2243
assign 1 0 2245
assign 1 771 2248
typenameGet 0 771 2248
assign 1 771 2249
ADDGet 0 771 2249
assign 1 771 2250
equals 1 771 2250
assign 1 0 2252
assign 1 0 2255
assign 1 0 2259
assign 1 0 2262
assign 1 0 2266
assign 1 772 2269
priorPeerGet 0 772 2269
assign 1 773 2270
undef 1 773 2275
assign 1 0 2276
assign 1 773 2279
typenameGet 0 773 2279
assign 1 773 2280
CALLGet 0 773 2280
assign 1 773 2281
notEquals 1 773 2281
assign 1 773 2283
typenameGet 0 773 2283
assign 1 773 2284
IDGet 0 773 2284
assign 1 773 2285
notEquals 1 773 2285
assign 1 0 2287
assign 1 0 2290
assign 1 0 2294
assign 1 773 2297
typenameGet 0 773 2297
assign 1 773 2298
VARGet 0 773 2298
assign 1 773 2299
notEquals 1 773 2299
assign 1 0 2301
assign 1 0 2304
assign 1 0 2308
assign 1 773 2311
typenameGet 0 773 2311
assign 1 773 2312
ACCESSORGet 0 773 2312
assign 1 773 2313
notEquals 1 773 2313
assign 1 0 2315
assign 1 0 2318
assign 1 0 2322
assign 1 0 2325
assign 1 0 2328
assign 1 779 2332
heldGet 0 779 2332
assign 1 779 2333
literalValueGet 0 779 2333
assign 1 779 2334
add 1 779 2334
literalValueSet 1 779 2335
delete 0 780 2336
return 1 0 2343
assign 1 0 2346
return 1 0 2350
assign 1 0 2353
return 1 0 2357
assign 1 0 2360
return 1 0 2364
assign 1 0 2367
return 1 0 2371
assign 1 0 2374
return 1 0 2378
assign 1 0 2381
return 1 0 2385
assign 1 0 2388
return 1 0 2392
assign 1 0 2395
return 1 0 2399
assign 1 0 2402
return 1 0 2406
assign 1 0 2409
return 1 0 2413
assign 1 0 2416
return 1 0 2420
assign 1 0 2423
return 1 0 2427
assign 1 0 2430
return 1 0 2434
assign 1 0 2437
return 1 0 2441
assign 1 0 2444
return 1 0 2448
assign 1 0 2451
return 1 0 2455
assign 1 0 2458
return 1 0 2462
assign 1 0 2465
return 1 0 2469
assign 1 0 2472
return 1 0 2476
assign 1 0 2479
return 1 0 2483
assign 1 0 2486
return 1 0 2490
assign 1 0 2493
return 1 0 2497
assign 1 0 2500
return 1 0 2504
assign 1 0 2507
return 1 0 2511
assign 1 0 2514
return 1 0 2518
assign 1 0 2521
return 1 0 2525
assign 1 0 2528
return 1 0 2532
assign 1 0 2535
return 1 0 2539
assign 1 0 2542
return 1 0 2546
assign 1 0 2549
return 1 0 2553
assign 1 0 2556
return 1 0 2560
assign 1 0 2563
return 1 0 2567
assign 1 0 2570
return 1 0 2574
assign 1 0 2577
return 1 0 2581
assign 1 0 2584
return 1 0 2588
assign 1 0 2591
return 1 0 2595
assign 1 0 2598
return 1 0 2602
assign 1 0 2605
return 1 0 2609
assign 1 0 2612
return 1 0 2616
assign 1 0 2619
return 1 0 2623
assign 1 0 2626
return 1 0 2630
assign 1 0 2633
return 1 0 2637
assign 1 0 2640
return 1 0 2644
assign 1 0 2647
return 1 0 2651
assign 1 0 2654
return 1 0 2658
assign 1 0 2661
return 1 0 2665
assign 1 0 2668
return 1 0 2672
assign 1 0 2675
return 1 0 2679
assign 1 0 2682
return 1 0 2686
assign 1 0 2689
return 1 0 2693
assign 1 0 2696
return 1 0 2700
assign 1 0 2703
return 1 0 2707
assign 1 0 2710
return 1 0 2714
assign 1 0 2717
return 1 0 2721
assign 1 0 2724
return 1 0 2728
assign 1 0 2731
return 1 0 2735
assign 1 0 2738
return 1 0 2742
assign 1 0 2745
return 1 0 2749
assign 1 0 2752
return 1 0 2756
assign 1 0 2759
return 1 0 2763
assign 1 0 2766
return 1 0 2770
assign 1 0 2773
return 1 0 2777
assign 1 0 2780
return 1 0 2784
assign 1 0 2787
return 1 0 2791
assign 1 0 2794
return 1 0 2798
assign 1 0 2801
return 1 0 2805
assign 1 0 2808
return 1 0 2812
assign 1 0 2815
return 1 0 2819
assign 1 0 2822
return 1 0 2826
assign 1 0 2829
return 1 0 2833
assign 1 0 2836
assign 1 0 2840
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1308786538: return bem_echo_0();
case -404051026: return bem_printPlacesGet_0();
case -729571811: return bem_serializeToString_0();
case -2113443821: return bem_deployLibraryGet_0();
case -34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case -340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case -580139405: return bem_config_0();
case -2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case -1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case -1803479881: return bem_libNameGet_0();
case -314718434: return bem_print_0();
case -2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case -186098742: return bem_exeNameGet_0();
case -1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case -829911139: return bem_compilerProfileGet_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case -658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case -2082855574: return bem_emitDataGet_0();
case -786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case -2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case -271866114: return bem_ownProcessGet_0();
case -2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case -1919619119: return bem_setClassesToWrite_0();
case -2127864150: return bem_argsGet_0();
case -400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case -1003238764: return bem_parseGet_0();
case -1924410263: return bem_initLibsGet_0();
case -902949587: return bem_printStepsGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 268778355: return bem_emitFlagsGet_0();
case 2072413014: return bem_loadSynsGet_0();
case -1505775346: return bem_putLineNumbersInTraceGet_0();
case -1713520961: return bem_linkLibArgsGet_0();
case -1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case -644675716: return bem_ntypesGet_0();
case -1185503219: return bem_deployFilesFromGet_0();
case -1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case -1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case -1066352481: return bem_saveSynsGet_0();
case -1182494494: return bem_toAny_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case -560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case -733055122: return bem_makeNameGet_0();
case -328200718: return bem_printAstGet_0();
case -126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case -1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case -1458327669: return bem_emitFileHeaderGet_0();
case -1220511308: return bem_buildSucceededGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -845792839: return bem_iteratorGet_0();
case -1149621350: return bem_codeGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case -1094759839: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2036609109: return bem_buildSyns_1(bevd_0);
case -972018826: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 279860608: return bem_emitFlagsSet_1(bevd_0);
case -1081571541: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case -1012817098: return bem_doEmitSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -317118465: return bem_printAstSet_1(bevd_0);
case -2116781897: return bem_argsSet_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case -647691617: return bem_usedLibrarysSet_1(bevd_0);
case -1702438708: return bem_linkLibArgsSet_1(bevd_0);
case -1913328010: return bem_initLibsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -721972869: return bem_makeNameSet_1(bevd_0);
case -1055270228: return bem_saveSynsSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case -1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case -1792397628: return bem_libNameSet_1(bevd_0);
case -1209429055: return bem_buildSucceededSet_1(bevd_0);
case -329197947: return bem_startTimeSet_1(bevd_0);
case -2071773321: return bem_emitDataSet_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1310359934: return bem_emitLangsSet_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case -2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case -2014823769: return bem_includePathSet_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case -1685807348: return bem_emitLibrarySet_1(bevd_0);
case -992156511: return bem_parseSet_1(bevd_0);
case 2083495267: return bem_loadSynsSet_1(bevd_0);
case -211282909: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case -23863370: return bem_builtSet_1(bevd_0);
case -115429536: return bem_outputPlatformSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case -1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case -1138539097: return bem_codeSet_1(bevd_0);
case -1495142466: return bem_readBufferSet_1(bevd_0);
case -891867334: return bem_printStepsSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case -175016489: return bem_exeNameSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case -2102361568: return bem_deployLibrarySet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -260783861: return bem_ownProcessSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case -1467862522: return bem_printAllAstSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case -2085986340: return bem_emitPathSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case -818828886: return bem_compilerProfileSet_1(bevd_0);
case -706249818: return bem_getSynNp_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -392968773: return bem_printPlacesSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case -549675370: return bem_emitCommonSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 593264218: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case -389838008: return bem_estrSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 681472468: return bem_buildLiteral_2(bevd_0, bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bevs_inst = (BEC_2_5_5_BuildBuild)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bevs_inst;
}
}
}
